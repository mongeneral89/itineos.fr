import { test } from 'node:test';
import assert from 'node:assert/strict';
import { paymentState } from '@itineo/shared';
import { ACCOUNTS, invoiceListCsv, salesJournal, salesJournalCsv, type ExportDocument } from '../src/services/accounting.js';

const invoice: ExportDocument = {
  kind: 'INVOICE', number: 'FR-FAC-2026-00001', issueDate: '2026-10-10', dueDate: '2026-11-09',
  clientName: 'Cabinet Durand', clientAccount: 'DURAND', title: 'Intervention',
  lines: [
    { quantity: 1, unitPriceCents: 100_000, vatRateBp: 2000 },
    { quantity: 2, unitPriceCents: 5_000, vatRateBp: 1000 },
  ],
  settledCents: 0,
};

test('journal des ventes : chaque facture est équilibrée (débit = crédit)', () => {
  const entries = salesJournal([invoice]);
  const debit = entries.reduce((s, e) => s + e.debitCents, 0);
  const credit = entries.reduce((s, e) => s + e.creditCents, 0);
  assert.equal(debit, credit);
  assert.equal(debit, 120_000 + 11_000); // 1 000 € HT + 20 % = 1 200 €, et 100 € HT + 10 % = 110 € : 1 310 € TTC
  const client = entries.find((e) => e.account === ACCOUNTS.client)!;
  assert.equal(client.auxiliary, 'DURAND');
  assert.equal(entries.filter((e) => e.account === ACCOUNTS.vat).map((e) => e.creditCents).sort().join(','), '1000,20000');
});

test('un avoir passe les écritures en sens inverse', () => {
  const credit = salesJournal([{ ...invoice, kind: 'CREDIT_NOTE', number: 'FR-AVO-2026-00001' }]);
  const client = credit.find((e) => e.account === ACCOUNTS.client)!;
  assert.equal(client.debitCents, 0);
  assert.equal(client.creditCents, 131_000);
  assert.ok(credit.filter((e) => e.account !== ACCOUNTS.client).every((e) => e.debitCents > 0 && e.creditCents === 0));
});

test('CSV lisible par Excel : BOM, point-virgule, virgule décimale, pas de formule', () => {
  const csv = salesJournalCsv([{ ...invoice, clientName: '=HYPERLINK("x")' }]);
  assert.equal(csv.charCodeAt(0), 0xfeff);
  const lines = csv.slice(1).trim().split('\r\n');
  assert.equal(lines[0], 'JournalCode;EcritureDate;PieceRef;CompteNum;CompteAux;EcritureLib;Debit;Credit');
  assert.match(lines[1], /^VT;10\/10\/2026;FR-FAC-2026-00001;411000;DURAND;.*;1310,00;0,00$/);
  assert.ok(!/;=/.test(csv), 'une cellule ne commence jamais par =');

  const list = invoiceListCsv([{ ...invoice, settledCents: 50_000 }]).slice(1).split('\r\n');
  assert.match(list[1], /;1100,00;210,00;1310,00;500,00;810,00$/);
});

test('état de paiement', () => {
  const base = { status: 'ISSUED' as const, kind: 'INVOICE' as const, grossCents: 1000, dueDate: '2026-11-01' };
  assert.equal(paymentState({ ...base, status: 'DRAFT', paidCents: 0 }, '2026-10-10'), 'DRAFT');
  assert.equal(paymentState({ ...base, paidCents: 0 }, '2026-10-10'), 'UNPAID');
  assert.equal(paymentState({ ...base, paidCents: 400 }, '2026-10-10'), 'PARTIAL');
  assert.equal(paymentState({ ...base, paidCents: 1000 }, '2026-12-01'), 'PAID');
  assert.equal(paymentState({ ...base, paidCents: 400 }, '2026-11-02'), 'OVERDUE');
  assert.equal(paymentState({ ...base, kind: 'CREDIT_NOTE', paidCents: 0 }, '2026-12-01'), 'PAID');
});
