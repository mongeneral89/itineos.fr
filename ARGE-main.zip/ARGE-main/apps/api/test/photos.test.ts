import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MAX_PHOTO_BYTES, parsePhotoDataUrl } from '../src/services/photos.js';

const dataUrl = (mime: string, bytes: number[]) => `data:${mime};base64,${Buffer.from(bytes).toString('base64')}`;

test('une vraie photo JPEG ou PNG est acceptée', () => {
  const jpeg = parsePhotoDataUrl(dataUrl('image/jpeg', [0xff, 0xd8, 0xff, 0xe0, 1, 2, 3]));
  assert.equal(jpeg?.mime, 'image/jpeg');
  assert.equal(jpeg?.ext, 'jpg');
  const png = parsePhotoDataUrl(dataUrl('image/png', [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a]));
  assert.equal(png?.ext, 'png');
});

test("un fichier déguisé en photo est refusé (le contenu est vérifié, pas seulement l'en-tête)", () => {
  assert.equal(parsePhotoDataUrl(dataUrl('image/jpeg', [0x3c, 0x73, 0x76, 0x67])), null); // « <svg »
  assert.equal(parsePhotoDataUrl(dataUrl('image/png', [0xff, 0xd8, 0xff])), null);
  assert.equal(parsePhotoDataUrl(dataUrl('image/svg+xml', [0x3c])), null);
  assert.equal(parsePhotoDataUrl('pas une image'), null);
});

test('une photo trop lourde est refusée', () => {
  const big = Buffer.alloc(MAX_PHOTO_BYTES + 1);
  big.set([0xff, 0xd8, 0xff]);
  assert.equal(parsePhotoDataUrl(`data:image/jpeg;base64,${big.toString('base64')}`), null);
});
