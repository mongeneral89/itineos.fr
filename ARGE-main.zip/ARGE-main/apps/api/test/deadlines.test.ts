import { test } from 'node:test';
import assert from 'node:assert/strict';
import { certificationState, daysBetween, nextVehicleDeadline, vehicleDeadlineState } from '@itineo/shared';
import { digestText } from '../src/services/digest.js';

const today = '2026-10-10';

test('habilitation : valable, expire bientôt (60 jours), expirée, sans date', () => {
  assert.equal(certificationState('2027-06-01', today), 'OK');
  assert.equal(certificationState('2026-12-01', today), 'SOON');
  assert.equal(certificationState('2026-10-09', today), 'OVERDUE');
  assert.equal(certificationState('2026-10-10', today), 'SOON', "valable jusqu'au soir");
  assert.equal(certificationState(null, today), 'OK');
});

test('échéance véhicule : par date, par kilométrage, ou la première des deux', () => {
  assert.equal(vehicleDeadlineState({ dueDate: '2027-01-01', dueMileage: null }, today, 50_000), 'OK');
  assert.equal(vehicleDeadlineState({ dueDate: '2026-11-01', dueMileage: null }, today, null), 'SOON');
  assert.equal(vehicleDeadlineState({ dueDate: '2026-10-01', dueMileage: null }, today, null), 'OVERDUE');
  assert.equal(vehicleDeadlineState({ dueDate: null, dueMileage: 85_000 }, today, 84_200), 'SOON', 'à 800 km');
  assert.equal(vehicleDeadlineState({ dueDate: null, dueMileage: 85_000 }, today, 85_100), 'OVERDUE');
  assert.equal(vehicleDeadlineState({ dueDate: '2027-05-01', dueMileage: 85_000 }, today, 85_100), 'OVERDUE', 'le kilométrage passe avant la date');
  assert.equal(vehicleDeadlineState({ dueDate: null, dueMileage: 85_000 }, today, null), 'NONE', 'kilométrage inconnu');
});

test("après l'entretien, l'échéance suivante est recalculée", () => {
  assert.deepEqual(nextVehicleDeadline({ intervalMonths: 12, intervalKm: 20_000 }, '2026-10-10', 85_200), { dueDate: '2027-10-10', dueMileage: 105_200 });
  assert.deepEqual(nextVehicleDeadline({ intervalMonths: 24, intervalKm: null }, '2026-10-10', null), { dueDate: '2028-10-10', dueMileage: null });
  assert.deepEqual(nextVehicleDeadline({ intervalMonths: null, intervalKm: null }, '2026-10-10', 1000), { dueDate: null, dueMileage: null });
  assert.equal(daysBetween('2026-10-10', '2026-11-09'), 30);
});

test('le récapitulatif liste les véhicules et les habilitations, avec les rendez-vous', () => {
  const text = digestText('Exemple Services France', [
    { id: '1', vehicleId: 'v', plate: 'AB-123-CD', make: 'Renault', model: 'Kangoo', agencyId: null, kind: 'TECH_INSPECTION', label: null,
      dueDate: '2026-10-30', dueMileage: null, mileage: 84_200, appointmentOn: null, appointmentWith: null, state: 'SOON' },
    { id: '2', vehicleId: 'w', plate: 'EF-456-GH', make: 'Peugeot', model: 'Partner', agencyId: null, kind: 'TIRES', label: 'Pneus hiver',
      dueDate: '2026-10-25', dueMileage: null, mileage: 41_000, appointmentOn: '2026-10-22', appointmentWith: 'Garage du Centre', state: 'SOON' },
  ], [
    { id: '3', userId: 'u', firstName: 'Julien', lastName: 'Simon', agencyId: null, typeCode: 'SST', typeName: 'Sauveteur secouriste du travail', expiresOn: '2026-09-10', state: 'OVERDUE' },
  ]);
  assert.match(text, /AB-123-CD Renault Kangoo : Contrôle technique le 30\/10\/2026 – à programmer/);
  assert.match(text, /Pneus hiver le 25\/10\/2026 – RDV le 22\/10\/2026 \(Garage du Centre\)/);
  assert.match(text, /\[Expirée\] Julien Simon : Sauveteur secouriste du travail – expirée le 10\/09\/2026/);
});
