import { test } from 'node:test';
import assert from 'node:assert/strict';
import { deviceTime } from '../src/services/device-time.js';

const now = new Date('2026-10-10T18:00:00Z');

test("l'heure réelle d'une action faite hors connexion est conservée", () => {
  const signedOffline = new Date('2026-10-10T11:42:00Z');
  assert.equal(deviceTime(signedOffline, now).toISOString(), signedOffline.toISOString());
});

test("une horloge d'appareil incohérente est remplacée par l'heure du serveur", () => {
  assert.equal(deviceTime(new Date('2026-10-11T18:00:00Z'), now), now); // dans le futur
  assert.equal(deviceTime(new Date('2026-09-01T00:00:00Z'), now), now); // trop ancienne
  assert.equal(deviceTime(undefined, now), now);
  // Légère avance (horloge mal réglée de 2 min) : ramenée à maintenant, pas refusée
  assert.equal(deviceTime(new Date('2026-10-10T18:02:00Z'), now), now);
});
