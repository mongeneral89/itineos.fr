import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createResetToken, hashResetToken, newPassword, passwordVersion, resetMail, sessionStillValid,
} from '../src/services/password.js';

test('le lien de réinitialisation est imprévisible et seule son empreinte est stockée', () => {
  const a = createResetToken();
  const b = createResetToken();
  assert.notEqual(a.token, b.token);
  assert.ok(a.token.length >= 40);
  assert.notEqual(a.tokenHash, a.token);
  assert.equal(hashResetToken(a.token), a.tokenHash);
});

test('un changement de mot de passe ferme les sessions ouvertes avant, même dans la même seconde', () => {
  const first = new Date('2026-10-10T12:00:00.100Z');
  const second = new Date('2026-10-10T12:00:00.900Z');
  assert.equal(sessionStillValid(passwordVersion(null), null), true); // jamais changé
  assert.equal(sessionStillValid(undefined, null), true); // ancien jeton, mot de passe jamais changé
  assert.equal(sessionStillValid(passwordVersion(null), first), false);
  assert.equal(sessionStillValid(passwordVersion(first), first), true);
  assert.equal(sessionStillValid(passwordVersion(first), second), false);
  assert.equal(sessionStillValid(undefined, first), false);
});

test('le nouveau mot de passe fait au moins 8 caractères', () => {
  assert.equal(newPassword.safeParse('court').success, false);
  assert.equal(newPassword.safeParse('assez-long').success, true);
});

test("l'e-mail de réinitialisation suit la langue du compte", () => {
  assert.match(resetMail('fr-FR', 'Julien', 'http://x').subject, /Réinitialisation/);
  assert.match(resetMail('en-GB', 'Sam', 'http://x').subject, /Reset/);
  assert.match(resetMail('fr-FR', 'Julien', 'http://lien').text, /http:\/\/lien/);
});

test('passwordMatches : vrai seulement pour le bon mot de passe, faux sans compte', async () => {
  const bcrypt = (await import('bcryptjs')).default;
  const { passwordMatches } = await import('../src/services/password.js');
  const hash = await bcrypt.hash('bon-mot-de-passe', 4);
  assert.equal(await passwordMatches('bon-mot-de-passe', hash), true);
  assert.equal(await passwordMatches('mauvais', hash), false);
  assert.equal(await passwordMatches('nimporte', undefined), false);
  assert.equal(await passwordMatches('nimporte', null), false);
});

test('les jetons des liens ne sont pas écrits dans le journal', async () => {
  const { redactUrl } = await import('../src/http.js');
  assert.equal(redactUrl('/api/portal/auth/link?token=abc123'), '/api/portal/auth/link?token=[masqué]');
  assert.equal(redactUrl('/api/x?a=1&token=abc&b=2'), '/api/x?a=1&token=[masqué]&b=2');
  assert.equal(redactUrl('/api/interventions'), '/api/interventions');
});
