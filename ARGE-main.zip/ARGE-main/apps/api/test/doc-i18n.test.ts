import { test } from 'node:test';
import assert from 'node:assert/strict';
import { UI_LOCALES } from '@itineo/shared';
import { clientLocale, docLang, docTexts, DOC_LANGS, formatLocale, longDay } from '../src/services/doc-i18n.js';
import { generateInvoicePdf, generateQuotePdf } from '../src/services/document-pdf.js';

test('documents : chaque langue de l’interface a ses textes, sinon anglais', () => {
  for (const l of UI_LOCALES) assert.ok(DOC_LANGS.includes(docLang(l)), l);
  assert.equal(docLang('es-ES'), 'es');
  assert.equal(docLang('sv-SE'), 'en');
  assert.equal(docTexts('de-DE').quote, 'ANGEBOT');
  assert.equal(docTexts('ja-JP').invoiceMail({ company: 'X', number: 'N1', credit: false, due: null }).subject, 'X – 請求書 N1');
});

test('documents : langue du client, sinon celle de la société ; dates en chiffres latins pour l’arabe', () => {
  assert.equal(clientLocale({ locale: 'it-IT' }, { locale: 'fr-FR' }), 'it-IT');
  assert.equal(clientLocale({ locale: null }, { locale: 'fr-FR' }), 'fr-FR');
  assert.equal(formatLocale('ar-SA'), 'ar-MA');
  assert.match(longDay('2026-10-11', 'ar-MA'), /2026/);
  assert.match(longDay('2026-10-11', 'fr-FR'), /11 octobre 2026/);
});

test('documents : un devis et une facture se fabriquent dans les 16 langues (polices de chaque écriture)', async () => {
  const lines = [{ description: 'Remplacement du compresseur – Компрессор – 压缩机 – ضاغط', quantity: 1, unit: 'u', unitPriceCents: 125050, vatRateBp: 2000 }];
  const common = {
    currency: 'EUR',
    company: { name: 'Exemple Services', countryCode: 'FR', legalMentions: 'SAS au capital de 10 000 €' },
    client: { name: 'Résidence Les Tilleuls', address: '12 rue des Lilas, 54000 Nancy' },
    site: null, lines,
  };
  for (const locale of UI_LOCALES) {
    const quote = await generateQuotePdf({
      ...common, locale,
      quote: { number: 'FR-DEV-2026-00001', title: 'Climatisation', intro: null, notes: 'Validité 30 jours', kind: 'CONTRACT', contractFrequencyMonths: 12, date: '2026-10-11', validUntil: '2026-11-10' },
    });
    assert.equal(quote.subarray(0, 4).toString(), '%PDF', locale);
    const invoice = await generateInvoicePdf({
      ...common, locale,
      invoice: { kind: 'INVOICE', number: 'FR-2026-00001', title: 'Dépannage', notes: null, issueDate: '2026-10-11', serviceDate: '2026-10-10', dueDate: '2026-11-10', creditedNumber: null, paidCents: 10000 },
    });
    assert.ok(invoice.length > 1000, locale);
  }
});
