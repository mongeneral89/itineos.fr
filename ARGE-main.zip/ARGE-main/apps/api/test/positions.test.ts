import { test } from 'node:test';
import assert from 'node:assert/strict';
import { acceptablePositions, localDayStart } from '../src/services/positions.js';

const now = new Date('2026-10-11T10:00:00Z');
const since = new Date('2026-10-11T07:00:00Z');
const at = (iso: string) => ({ lat: 48.69, lng: 6.18, accuracy: 15, recordedAt: iso });

test('positions : coordonnées, heure, précision et accord du technicien vérifiés', () => {
  const kept = acceptablePositions([
    at('2026-10-11T09:58:00Z'),
    at('2026-10-11T08:00:00Z'),
    { ...at('2026-10-11T09:00:00Z'), lat: 95 }, // impossible
    { ...at('2026-10-11T09:00:00Z'), lat: 0, lng: 0 }, // position « nulle »
    { ...at('2026-10-11T09:00:00Z'), accuracy: 9000 }, // trop imprécise
    at('2026-10-11T10:30:00Z'), // dans le futur
    at('2026-10-11T06:00:00Z'), // avant l'activation du partage
    at('pas une date'),
  ], since, now);
  assert.deepEqual(kept.map((k) => k.recordedAt), ['2026-10-11T08:00:00Z', '2026-10-11T09:58:00Z'], 'gardées et remises dans l\'ordre');
});

test("positions : une position envoyée après une coupure de réseau garde son heure, jusqu'à 7 jours", () => {
  const longAgo = new Date('2026-10-01T00:00:00Z');
  assert.equal(acceptablePositions([at('2026-10-05T12:00:00Z')], longAgo, now).length, 1);
  assert.equal(acceptablePositions([at('2026-10-03T12:00:00Z')], longAgo, now).length, 0);
});

test("journée locale : minuit à Paris en heure d'été, d'hiver, et le jour du changement d'heure", () => {
  assert.equal(localDayStart('2026-07-14', 'Europe/Paris').toISOString(), '2026-07-13T22:00:00.000Z');
  assert.equal(localDayStart('2026-12-25', 'Europe/Paris').toISOString(), '2026-12-24T23:00:00.000Z');
  assert.equal(localDayStart('2026-10-25', 'Europe/Paris').toISOString(), '2026-10-24T22:00:00.000Z');
  assert.equal(localDayStart('2026-03-29', 'Europe/Paris').toISOString(), '2026-03-28T23:00:00.000Z');
  assert.equal(localDayStart('2026-10-11', 'Europe/London').toISOString(), '2026-10-10T23:00:00.000Z');
});
