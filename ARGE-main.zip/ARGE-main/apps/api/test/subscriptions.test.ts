import { test } from 'node:test';
import assert from 'node:assert/strict';
import { duePeriods, MAX_PERIODS_PER_RUN } from '../src/services/subscriptions.js';

const base = { status: 'ACTIVE', startDate: '2026-01-01', endDate: null, billingMonths: 1, billedUntil: null, annualPriceCents: 360_00 };

test('abonnement mensuel : une période par mois à terme à échoir, rien deux fois', () => {
  const first = duePeriods(base, '2026-03-01');
  assert.deepEqual(first, [
    { start: '2026-01-01', end: '2026-01-31', amountCents: 30_00 },
    { start: '2026-02-01', end: '2026-02-28', amountCents: 30_00 },
    { start: '2026-03-01', end: '2026-03-31', amountCents: 30_00 },
  ]);
  // Une fois facturé jusqu'au 31 mars, plus rien n'est dû avant le 1er avril
  assert.deepEqual(duePeriods({ ...base, billedUntil: '2026-03-31' }, '2026-03-31'), []);
  assert.equal(duePeriods({ ...base, billedUntil: '2026-03-31' }, '2026-04-01')[0].start, '2026-04-01');
});

test('trimestriel et annuel : le prix annuel est réparti sur la période', () => {
  assert.deepEqual(duePeriods({ ...base, billingMonths: 3 }, '2026-01-15'), [{ start: '2026-01-01', end: '2026-03-31', amountCents: 90_00 }]);
  assert.deepEqual(duePeriods({ ...base, billingMonths: 12 }, '2026-01-01'), [{ start: '2026-01-01', end: '2026-12-31', amountCents: 360_00 }]);
});

test('fin de contrat en cours de période : dernière période au prorata des jours', () => {
  const p = duePeriods({ ...base, billingMonths: 3, endDate: '2026-02-14', billedUntil: null }, '2026-12-31');
  assert.equal(p.length, 1);
  assert.equal(p[0].end, '2026-02-14');
  assert.equal(p[0].amountCents, Math.round((90_00 * 45) / 90));
});

test('rien à facturer : contrat suspendu, sans prix, sans facturation, ou pas encore commencé', () => {
  assert.deepEqual(duePeriods({ ...base, status: 'SUSPENDED' }, '2026-06-01'), []);
  assert.deepEqual(duePeriods({ ...base, annualPriceCents: null }, '2026-06-01'), []);
  assert.deepEqual(duePeriods({ ...base, billingMonths: null }, '2026-06-01'), []);
  assert.deepEqual(duePeriods({ ...base, startDate: '2026-07-01' }, '2026-06-30'), []);
});

test('rattrapage limité en une fois', () => {
  assert.equal(duePeriods({ ...base, startDate: '2020-01-01' }, '2026-12-31').length, MAX_PERIODS_PER_RUN);
});
