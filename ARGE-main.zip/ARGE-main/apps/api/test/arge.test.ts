import { test } from 'node:test';
import assert from 'node:assert/strict';
import { argeTemplates } from '../src/db/arge/templates.js';
import { ARGE_CATALOGUE } from '../src/db/arge/catalogue.js';
import { templateSchema } from '../src/services/template-schema.js';
import { footerMargin } from '../src/services/pdf-text.js';

test('version ARGE : chaque document respecte les règles des modèles de fiches', () => {
  for (const tpl of argeTemplates()) {
    const r = templateSchema.safeParse(tpl.schema);
    assert.ok(r.success, `${tpl.name} : ${r.success ? '' : JSON.stringify(r.error.issues)}`);
  }
});

test('version ARGE : la fiche d’intervention est celle de la société pour chaque type, les autres documents se choisissent', () => {
  const list = argeTemplates();
  assert.deepEqual(list.filter((t) => t.company).map((t) => t.kind).sort(), ['INSTALLATION', 'MAINTENANCE', 'OTHER', 'SAV']);
  assert.equal(list.filter((t) => !t.company).length, 3);
});

test('version ARGE : catalogue sans référence en double', () => {
  const refs = ARGE_CATALOGUE.map((a) => a.reference);
  assert.equal(new Set(refs).size, refs.length);
  assert.equal(refs.length, 131, "toutes les lignes des deux bons de sortie");
});

test('pied de page : la marge du bas grandit avec des mentions légales longues', () => {
  assert.equal(footerMargin(null), 40);
  assert.equal(footerMargin('SAS au capital de 1 000 €'), 40);
  assert.ok(footerMargin('x'.repeat(480)) > 60);
});
