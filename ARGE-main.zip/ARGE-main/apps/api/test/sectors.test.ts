import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  applySectorWords, deadlineState, EDITION_THEMES, featureEnabled, INTERVENTION_KINDS, moduleEnabled, productName, SECTOR_KINDS, SECTOR_VOCABULARY, SECTORS,
} from '@itineo/shared';
import { buildSectorTemplates, TEMPLATE_SECTORS } from '../src/services/sector-templates.js';
import { templateSchema } from '../src/services/template-schema.js';

test('chaque édition a un nom, des couleurs, et des modèles pour chaque type en français et en anglais', () => {
  assert.equal(productName('TECH'), 'Itinéos');
  assert.equal(productName('SECURITY'), 'Itinéos Vigie');
  for (const s of SECTORS) assert.match(EDITION_THEMES[s].accent, /^#[0-9A-F]{6}$/i, s);
  assert.deepEqual([...TEMPLATE_SECTORS].sort(), SECTORS.filter((s) => s !== 'TECH').sort());
  for (const sector of TEMPLATE_SECTORS) {
    for (const lang of ['fr', 'en'] as const) {
      const tpls = buildSectorTemplates(sector, lang);
      assert.deepEqual(tpls.map((t) => t.kind).sort(), [...INTERVENTION_KINDS].sort(), `${sector}/${lang}`);
      for (const t of tpls) {
        assert.equal(t.schema.lang, lang);
        const res = templateSchema.safeParse(t.schema);
        assert.ok(res.success, `${sector}/${t.kind}/${lang} : ${res.success ? '' : res.error.issues.map((i) => i.message).join(', ')}`);
      }
    }
    // Les deux langues ont les mêmes champs : une fiche se lit pareil quelle que soit la langue
    const ids = (lang: 'fr' | 'en') => buildSectorTemplates(sector, lang).map((t) => t.schema.sections.flatMap((s) => s.fields.map((f) => f.id)).join());
    assert.deepEqual(ids('fr'), ids('en'), sector);
  }
});

test('chaque métier a ses types d’intervention et ses modules', () => {
  for (const s of SECTORS) {
    if (s === 'TECH') continue;
    for (const lang of ['fr', 'en'] as const) for (const k of INTERVENTION_KINDS) assert.ok(SECTOR_KINDS[s]?.[lang][k], `${s}/${lang}/${k}`);
  }
  assert.equal(moduleEnabled('TECH', 'stock'), true);
  assert.equal(moduleEnabled('BAILIFF', 'stock'), false);
  assert.equal(moduleEnabled('BAILIFF', 'invoices'), true);
});

test('fonctions des métiers et dates limites', () => {
  assert.equal(featureEnabled('SECURITY', 'checkpoints'), true);
  assert.equal(featureEnabled('SECURITY', 'treatmentRegister'), false);
  assert.equal(featureEnabled('TECH', 'sos'), false);
  assert.equal(featureEnabled('SERVICES', 'treatmentRegister'), true);
  assert.equal(deadlineState('2026-10-10', '2026-10-12'), 'OVERDUE');
  assert.equal(deadlineState('2026-10-15', '2026-10-12'), 'SOON');
  assert.equal(deadlineState('2026-11-30', '2026-10-12'), 'OK');
  assert.equal(deadlineState('2026-10-10', '2026-10-12', true), 'NONE', 'rapport rendu');
  assert.equal(deadlineState(null, '2026-10-12'), 'NONE');
});

test('vocabulaire du métier : accords, élision et majuscules', () => {
  const sec = SECTOR_VOCABULARY.SECURITY!;
  const fr = (s: string) => applySectorWords(s, sec.fr, 'fr');
  assert.equal(fr('Nouvelle intervention'), 'Nouvelle mission');
  assert.equal(fr('Interventions'), 'Missions');
  assert.equal(fr('Nom du technicien'), 'Nom de l’agent');
  assert.equal(fr('Le technicien est en route'), 'L’agent est en route');
  assert.equal(fr('Ce technicien a déjà un véhicule'), 'Cet agent a déjà un véhicule');
  assert.equal(fr('Aucun technicien dans cette société.'), 'Aucun agent dans cette société.');
  assert.equal(fr('Activité par technicien'), 'Activité par agent');
  assert.equal(fr('Type d’intervention'), 'Type de mission');
  assert.equal(fr('Voir les {n} techniciens'), 'Voir les {n} agents');
  // Un mot qui commence par une voyelle remplacé par un mot qui commence par une consonne
  const rental = SECTOR_VOCABULARY.RENTAL!;
  assert.equal(applySectorWords('Cette intervention est clôturée', rental.fr, 'fr'), 'Cette visite est clôturée');
  assert.equal(applySectorWords('Détail de l’intervention', rental.fr, 'fr'), 'Détail de la visite');
  assert.equal(applySectorWords('Lieu d’intervention', rental.fr, 'fr'), 'Lieu de visite');
  // Anglais : a / an
  const en = (s: string) => applySectorWords(s, sec.en, 'en');
  assert.equal(en('New job'), 'New assignment');
  assert.equal(en('Assign a technician'), 'Assign an officer');
  assert.equal(en('Technicians'), 'Officers');
  assert.equal(applySectorWords('Book a job', SECTOR_VOCABULARY.RENTAL!.en, 'en'), 'Book a visit');
  // Les mots voisins ne sont pas touchés
  assert.equal(fr('Intervenant extérieur'), 'Intervenant extérieur');
  assert.equal(fr('Fiche technique / schéma'), 'Fiche technique / schéma');
});
