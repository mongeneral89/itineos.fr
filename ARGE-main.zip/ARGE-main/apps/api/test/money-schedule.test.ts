import { test } from 'node:test';
import assert from 'node:assert/strict';
import { addMonths, documentTotals, formatMoney, isQuoteExpired, lineNetCents, visitDueDates } from '@itineo/shared';
import { documentCode } from '../src/services/numbering.js';
import { todayIn } from '../src/services/contracts.js';
import { pdfSafe } from '../src/services/document-pdf.js';

test('totaux : TVA calculée par taux sur la somme des lignes, au centime près', () => {
  const t = documentTotals([
    { quantity: 1, unitPriceCents: 125_000, vatRateBp: 2000 }, // 1 250,00 € HT à 20 %
    { quantity: 2.5, unitPriceCents: 6_500, vatRateBp: 2000 }, // 2,5 h × 65 € = 162,50 €
    { quantity: 3, unitPriceCents: 333, vatRateBp: 1000 }, // 9,99 € à 10 %
  ]);
  assert.equal(t.netCents, 125_000 + 16_250 + 999);
  assert.deepEqual(t.byRate, [
    { vatRateBp: 2000, baseCents: 141_250, vatCents: 28_250 },
    { vatRateBp: 1000, baseCents: 999, vatCents: 100 }, // 99,9 c arrondi à 100
  ]);
  assert.equal(t.vatCents, 28_350);
  assert.equal(t.grossCents, t.netCents + t.vatCents);
});

test('pas d’erreur d’arrondi flottant', () => {
  assert.equal(lineNetCents({ quantity: 0.1 * 3, unitPriceCents: 1000, vatRateBp: 0 }), 300);
  assert.equal(documentTotals([]).grossCents, 0);
  assert.equal(formatMoney(123456, 'EUR', 'fr-FR').replace(/\s/g, ' '), '1 234,56 €');
});

test('ajout de mois : fin de mois et années bissextiles', () => {
  assert.equal(addMonths('2026-01-31', 1), '2026-02-28');
  assert.equal(addMonths('2028-01-31', 1), '2028-02-29');
  assert.equal(addMonths('2026-11-15', 3), '2027-02-15');
  assert.equal(addMonths('2026-03-31', -1), '2026-02-28');
});

test('échéances de visites : sans dérive, dans la période, jamais après la fin du contrat', () => {
  const c = { startDate: '2026-01-31', endDate: null, frequencyMonths: 1 };
  assert.deepEqual(visitDueDates(c, '2026-02-01', '2026-04-30'), ['2026-02-28', '2026-03-31', '2026-04-30']);
  const annual = { startDate: '2024-06-15', endDate: '2027-01-01', frequencyMonths: 12 };
  assert.deepEqual(visitDueDates(annual, '2026-01-01', '2030-12-31'), ['2026-06-15']);
  assert.deepEqual(visitDueDates({ startDate: '2026-12-01', endDate: null, frequencyMonths: 6 }, '2026-10-10', '2026-12-09'), ['2026-12-01']);
});

test('devis expiré : envoyé et date de validité passée', () => {
  assert.equal(isQuoteExpired({ status: 'SENT', validUntil: '2026-10-09' }, '2026-10-10'), true);
  assert.equal(isQuoteExpired({ status: 'SENT', validUntil: '2026-10-10' }, '2026-10-10'), false);
  assert.equal(isQuoteExpired({ status: 'ACCEPTED', validUntil: '2026-01-01' }, '2026-10-10'), false);
});

test('numéros de documents selon la langue de la société', () => {
  assert.equal(documentCode('quote', 'fr-BE'), 'DEV');
  assert.equal(documentCode('quote', 'en-GB'), 'QUO');
  assert.equal(documentCode('contract', 'fr-FR'), 'CTR');
  assert.equal(documentCode('intervention', 'fr-FR'), null);
});

test('montants lisibles dans un PDF (pas d’espace fine, que la police ne connaît pas)', () => {
  const s = pdfSafe(formatMoney(129_000, 'EUR', 'fr-FR'));
  assert.equal(/ /.test(s), false);
  assert.equal(s.replace(/ /g, ' '), '1 290,00 €');
});

test('date du jour dans le fuseau de la société', () => {
  const lateEvening = new Date('2026-10-10T22:30:00Z'); // 00:30 à Paris le 11
  assert.equal(todayIn('Europe/Paris', lateEvening), '2026-10-11');
  assert.equal(todayIn('Europe/London', lateEvening), '2026-10-10');
});
