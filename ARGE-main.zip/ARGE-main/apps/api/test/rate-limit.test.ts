import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AttemptLimiter, tooManyMessage } from '../src/services/rate-limit.js';

const MIN = 60_000;

test('bloqué après le nombre maximum d’échecs, débloqué quand ils sortent de la fenêtre', () => {
  const l = new AttemptLimiter(3, 15 * MIN);
  const t0 = 1_000_000;
  for (let i = 0; i < 3; i++) {
    assert.equal(l.check('a', t0 + i).blocked, false);
    l.hit('a', t0 + i);
  }
  const blocked = l.check('a', t0 + 5 * MIN);
  assert.equal(blocked.blocked, true);
  assert.ok(blocked.retryAfterMs > 9 * MIN && blocked.retryAfterMs <= 10 * MIN);
  assert.equal(l.check('a', t0 + 15 * MIN + 10).blocked, false, 'fenêtre passée');
});

test('chaque clé a son propre compteur ; une réussite remet à zéro', () => {
  const l = new AttemptLimiter(2, MIN);
  l.hit('a', 0);
  l.hit('a', 1);
  assert.equal(l.check('a', 2).blocked, true);
  assert.equal(l.check('b', 2).blocked, false);
  l.reset('a');
  assert.equal(l.check('a', 3).blocked, false);
});

test('la mémoire est libérée pour les clés anciennes', () => {
  const l = new AttemptLimiter(2, MIN);
  for (let i = 0; i < 100; i++) l.hit(`k${i}`, 0);
  l.sweep(2 * MIN);
  assert.equal((l as unknown as { hits: Map<string, number[]> }).hits.size, 0);
});

test('message lisible', () => {
  assert.equal(tooManyMessage(14 * MIN + 1), 'Trop de tentatives. Réessayez dans 15 minutes.');
  assert.equal(tooManyMessage(10_000), 'Trop de tentatives. Réessayez dans 1 minute.');
});

test('connexion : une adresse qui se trompe est bloquée, pas le titulaire du compte', async () => {
  const { loginAttempts } = await import('../src/services/rate-limit.js');
  const account = 'victime@exemple.fr';
  for (let i = 0; i < 5; i++) loginAttempts.fail(account, '203.0.113.9');
  assert.equal(loginAttempts.check(account, '203.0.113.9').some((c) => c.blocked), true, 'adresse du pirate bloquée');
  assert.equal(loginAttempts.check(account, '198.51.100.7').some((c) => c.blocked), false, 'le titulaire peut se connecter');
});
