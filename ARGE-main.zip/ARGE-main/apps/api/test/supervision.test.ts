import { test } from 'node:test';
import assert from 'node:assert/strict';

test('mise à jour « la nuit » : entre 3 h et 5 h, sinon la nuit suivante', async () => {
  const { nextWindow } = await import('../src/services/supervision.js');
  const at = (h: number, m = 0) => new Date(2026, 9, 15, h, m);
  assert.deepEqual(nextWindow('night', at(1)), new Date(2026, 9, 15, 3, 0));
  assert.deepEqual(nextWindow('night', at(3, 30)), at(3, 30));
  assert.deepEqual(nextWindow('night', at(14)), new Date(2026, 9, 16, 3, 0));
  assert.deepEqual(nextWindow('now', at(14)), at(14));
});

test('clés de confiance de l’agent : remplacées seulement sur recommandation d’une clé connue', async () => {
  const { generateKeyPairSync, sign } = await import('node:crypto');
  const { nextTrustedKeys } = await import('../src/services/supervision.js');
  const pem = (k: import('node:crypto').KeyObject) => k.export({ type: 'spki', format: 'pem' }).toString();
  const main = generateKeyPairSync('ed25519');
  const backup = generateKeyPairSync('ed25519');
  const endorse = (priv: import('node:crypto').KeyObject, pub: string) => sign(null, Buffer.from(`cle-secours|${pub.trim()}`), priv).toString('base64');
  const trusted = [pem(main.publicKey)];
  const next = nextTrustedKeys(trusted, { signing: pem(main.publicKey), backup: { publicKeyPem: pem(backup.publicKey), endorsement: endorse(main.privateKey, pem(backup.publicKey)) } });
  assert.deepEqual(next, [pem(main.publicKey), pem(backup.publicKey)]);
  // Une console inconnue ne peut pas imposer ses clés
  const intruder = generateKeyPairSync('ed25519');
  assert.deepEqual(nextTrustedKeys(trusted, { signing: pem(intruder.publicKey), backup: { publicKeyPem: pem(intruder.publicKey), endorsement: endorse(intruder.privateKey, pem(intruder.publicKey)) } }), trusted);
  // Après restauration de la clé de secours : l'ancienne clé principale est oubliée
  const newBackup = generateKeyPairSync('ed25519');
  const afterRestore = nextTrustedKeys(next, { signing: pem(backup.publicKey), backup: { publicKeyPem: pem(newBackup.publicKey), endorsement: endorse(backup.privateKey, pem(newBackup.publicKey)) } });
  assert.deepEqual(afterRestore, [pem(backup.publicKey), pem(newBackup.publicKey)]);
});
