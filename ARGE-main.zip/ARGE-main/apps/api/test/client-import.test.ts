import { test } from 'node:test';
import assert from 'node:assert/strict';
import { deflateRawSync } from 'node:zlib';
import { readCsv, readTable, decodeText } from '../src/services/import-table.js';
import { guessMapping, normalize, parseDate } from '../src/services/client-import.js';
import { createZip } from '../src/services/zip.js';

test('CSV d’Excel : point-virgule, guillemets, retour à la ligne dans une cellule', () => {
  const rows = readCsv('Nom;Adresse;Notes\r\n"Dupont; fils";"12 rue ""Haute""";"ligne 1\nligne 2"\r\nMartin;;\r\n');
  assert.deepEqual(rows, [
    ['Nom', 'Adresse', 'Notes'],
    ['Dupont; fils', '12 rue "Haute"', 'ligne 1\nligne 2'],
    ['Martin', '', ''],
  ]);
});

test('CSV : virgule ou tabulation reconnues, lignes vides retirées', () => {
  assert.deepEqual(readTable(Buffer.from('a,b\n1,2\n\n')), [['a', 'b'], ['1', '2']]);
  assert.deepEqual(readTable(Buffer.from('a\tb\n1\t2')), [['a', 'b'], ['1', '2']]);
});

test('encodage : UTF-8 avec BOM, UTF-8, ou Windows-1252 (CSV enregistré par Excel)', () => {
  assert.equal(decodeText(Buffer.from('﻿N° série', 'utf8')), 'N° série');
  assert.equal(decodeText(Buffer.from('Abonné', 'utf8')), 'Abonné');
  assert.equal(decodeText(Buffer.from([0x41, 0x62, 0x6f, 0x6e, 0x6e, 0xe9])), 'Abonné');
});

test('Excel .xlsx : textes partagés, nombres, cellules vides, texte en ligne', () => {
  const files: Record<string, string> = {
    'xl/workbook.xml': '<workbook><sheets><sheet name="Clients" sheetId="1" r:id="rId1"/></sheets></workbook>',
    'xl/_rels/workbook.xml.rels': '<Relationships><Relationship Id="rId1" Type="worksheet" Target="worksheets/sheet1.xml"/></Relationships>',
    'xl/sharedStrings.xml': '<sst><si><t>Nom du client</t></si><si><t>N° de série</t></si><si><r><t>Pharmacie </t></r><r><t>&amp; Cie</t></r></si></sst>',
    'xl/worksheets/sheet1.xml': '<worksheet><sheetData>'
      + '<row r="1"><c r="A1" t="s"><v>0</v></c><c r="C1" t="s"><v>1</v></c></row>'
      + '<row r="2"><c r="A2" t="s"><v>2</v></c><c r="C2"><v>44270</v></c></row>'
      + '<row r="3"><c r="A3" t="inlineStr"><is><t>M. Durand</t></is></c></row>'
      + '</sheetData></worksheet>',
  };
  const zip = createZip(Object.entries(files).map(([name, xml]) => ({ name, data: Buffer.from(xml) })));
  assert.deepEqual(readTable(zip), [['Nom du client', '', 'N° de série'], ['Pharmacie & Cie', '', '44270'], ['M. Durand']]);
});

test('Excel .xlsx compressé (deflate), comme les fichiers enregistrés par Excel', () => {
  // Archive écrite à la main : un seul fichier compressé suffit à vérifier la décompression
  const entries = {
    'xl/workbook.xml': '<workbook><sheets><sheet r:id="rId1"/></sheets></workbook>',
    'xl/_rels/workbook.xml.rels': '<Relationships><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>',
    'xl/worksheets/sheet1.xml': '<worksheet><sheetData><row><c r="A1" t="inlineStr"><is><t>Client</t></is></c></row><row><c r="A2" t="inlineStr"><is><t>Durand</t></is></c></row></sheetData></worksheet>',
  };
  const locals: Buffer[] = [];
  const centrals: Buffer[] = [];
  let offset = 0;
  for (const [name, xml] of Object.entries(entries)) {
    const raw = Buffer.from(xml);
    const data = deflateRawSync(raw);
    const nameBuf = Buffer.from(name);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(8, 8);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(raw.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(8, 10);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(raw.length, 24);
    central.writeUInt16LE(nameBuf.length, 28);
    central.writeUInt32LE(offset, 42);
    locals.push(local, nameBuf, data);
    centrals.push(central, nameBuf);
    offset += 30 + nameBuf.length + data.length;
  }
  const dir = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(3, 8);
  end.writeUInt16LE(3, 10);
  end.writeUInt32LE(dir.length, 12);
  end.writeUInt32LE(offset, 16);
  assert.deepEqual(readTable(Buffer.concat([...locals, dir, end])), [['Client'], ['Durand']]);
});

test('titres de colonnes : reconnus sans tenir compte des accents ni de « N° »', () => {
  assert.equal(normalize('N° de série'), 'n de serie');
  assert.equal(normalize('N°abonné'), 'n abonne');
  const mapping = guessMapping(['Raison sociale', 'Code client', 'N° abonné', 'CP', 'Ville', 'Site', 'Matériel', 'Marque', 'N° de série', 'Colonne inconnue', 'Ville']);
  assert.deepEqual(mapping, ['clientName', 'clientRef', 'subscriberNumber', 'postalCode', 'city', 'siteName', 'category', 'brand', 'serialNumber', null, null]);
});

test('dates : jj/mm/aaaa, jj/mm/aa, aaaa-mm-jj et n° de jour Excel ; date impossible refusée', () => {
  assert.equal(parseDate('15/03/2021'), '2021-03-15');
  assert.equal(parseDate('5.3.21'), '2021-03-05');
  assert.equal(parseDate('2021-03-15'), '2021-03-15');
  assert.equal(parseDate('44270'), '2021-03-15');
  assert.equal(parseDate('31/02/2021'), null);
  assert.equal(parseDate('bientôt'), null);
});
