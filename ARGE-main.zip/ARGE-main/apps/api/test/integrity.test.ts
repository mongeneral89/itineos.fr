import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { computeFingerprint, integrityRoots } from '../src/services/integrity.js';

test('empreinte : identique pour les mêmes fichiers, différente si un fichier change ou s’ajoute', async () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'itineo-empreinte-'));
  try {
    const api = path.join(dir, 'api');
    const web = path.join(dir, 'web');
    mkdirSync(path.join(api, 'dist'), { recursive: true });
    mkdirSync(path.join(api, 'migrations'), { recursive: true });
    mkdirSync(path.join(web, 'assets'), { recursive: true });
    writeFileSync(path.join(api, 'dist', 'index.mjs'), 'console.log(1)');
    writeFileSync(path.join(api, 'migrations', '0001.sql'), 'SELECT 1;');
    writeFileSync(path.join(web, 'assets', 'app.js'), 'x');
    const roots = integrityRoots(api, web);
    const a = await computeFingerprint(roots);
    const b = await computeFingerprint(roots);
    assert.equal(a.fingerprint, b.fingerprint);
    assert.equal(a.files, 3);
    writeFileSync(path.join(api, 'dist', 'index.mjs'), 'console.log(2)');
    assert.notEqual((await computeFingerprint(roots)).fingerprint, a.fingerprint);
    writeFileSync(path.join(api, 'dist', 'index.mjs'), 'console.log(1)');
    assert.equal((await computeFingerprint(roots)).fingerprint, a.fingerprint);
    writeFileSync(path.join(web, 'ajout.js'), 'y');
    assert.notEqual((await computeFingerprint(roots)).fingerprint, a.fingerprint);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
