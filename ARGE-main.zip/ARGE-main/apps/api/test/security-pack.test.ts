import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { PREFILL_SOURCES, type ReportData, type TemplateSchema } from '@itineo/shared';
import { securityPackTemplates } from '../src/services/security-pack.js';
import { generateReportPdf } from '../src/services/pdf.js';
import { templateSchema } from '../src/services/template-schema.js';

test('pack installateur : une fiche prise d’office par type d’intervention, puis 4 documents à choisir', () => {
  const pack = securityPackTemplates('fr');
  const auto = pack.filter((t) => t.autoPick);
  assert.deepEqual(auto.map((t) => t.kind).sort(), ['INSTALLATION', 'MAINTENANCE', 'OTHER', 'SAV']);
  assert.deepEqual(pack.filter((t) => !t.autoPick).map((t) => t.name), [
    'Consignes de télésurveillance – complètes',
    'Dossier technique – alarme et télésurveillance',
    'Dossier technique – vidéoprotection',
    'Procès-verbal de réception des travaux',
  ]);
});

test('pack installateur : modèles valides pour l’éditeur, en français et en anglais, sans champ en double', () => {
  const sources = new Set(PREFILL_SOURCES.map((s) => s.path));
  for (const lang of ['fr', 'en'] as const) {
    for (const tpl of securityPackTemplates(lang)) {
      const res = templateSchema.safeParse(tpl.schema);
      assert.ok(res.success, `${tpl.name}/${lang} : ${res.success ? '' : res.error.issues.map((i) => i.message).join(', ')}`);
      assert.equal(tpl.schema.lang, lang);
      const fields = tpl.schema.sections.flatMap((s) => s.fields);
      const ids = fields.map((f) => f.id);
      assert.equal(new Set(ids).size, ids.length, `doublon dans ${tpl.name}`);
      for (const f of fields) {
        if (f.prefill) assert.ok(sources.has(f.prefill), `${tpl.name} : préremplissage inconnu ${f.prefill}`);
        if (f.type === 'select' || f.type === 'checklist') assert.ok(f.options?.length, f.id);
      }
    }
  }
});

/** Une fiche entièrement remplie : toutes les cases cochées, tous les textes saisis */
function filled(schema: TemplateSchema): ReportData {
  const data: ReportData = {};
  for (const f of schema.sections.flatMap((s) => s.fields)) {
    data[f.id] = f.type === 'checklist' ? f.options! : f.type === 'select' ? f.options![0] : f.type === 'checkbox' ? true
      : f.type === 'number' ? 12 : f.type === 'date' ? '2026-11-03' : f.type === 'time' ? '08:30' : `${f.label} : valeur saisie sur place`;
  }
  return data;
}

test('pack installateur : chaque fiche remplie donne un PDF', async () => {
  for (const tpl of securityPackTemplates('fr')) {
    const pdf = await generateReportPdf({
      locale: 'fr-FR', timezone: 'Europe/Paris', title: tpl.name,
      company: { name: 'Installateur Exemple', legalMentions: 'SAS · SIRET 000 000 000 00000 · Autorisation CNAPS AUT-000-0000' },
      agency: { name: 'Agence Est' },
      intervention: { number: 'FR-2026-00042', kind: tpl.kind, reason: 'Maintenance annuelle' },
      client: { name: 'Pharmacie des Tilleuls', address: '12 rue des Tilleuls, 21000 Dijon' },
      site: { name: 'Pharmacie', address: '12 rue des Tilleuls, 21000 Dijon' },
      technicianName: 'Julien Martin',
      report: {
        schema: tpl.schema, data: filled(tpl.schema), arrivedAt: new Date('2026-11-03T07:30:00Z'), leftAt: new Date('2026-11-03T09:00:00Z'),
        laborMinutes: 90, travelMinutes: 20, outcome: 'DONE', technicianSignature: null, clientSignature: null,
        clientSignerName: 'Mme Martin', clientAbsent: false, clientAbsentReason: null, signedAt: new Date('2026-11-03T09:00:00Z'),
      },
      parts: [{ label: 'Batterie 12 V 7 Ah', reference: 'BAT-12-7', quantity: 1 }],
      photos: [],
    });
    assert.equal(pdf.subarray(0, 5).toString(), '%PDF-', tpl.name);
    assert.ok(pdf.length > 3000, tpl.name);
    if (process.env.PACK_PDF_DIR && tpl.kind === 'MAINTENANCE') writeFileSync(`${process.env.PACK_PDF_DIR}/maintenance.pdf`, pdf);
  }
});

test('pack installateur : générique (aucun nom de société, de télésurveilleur ni de financeur)', () => {
  const all = JSON.stringify([securityPackTemplates('fr'), securityPackTemplates('en')]);
  for (const word of ['ARGE', 'A.R.G.E', 'Teles', 'Grenke', 'NBB', 'Locam', 'DocuSign', 'PROM']) assert.ok(!all.includes(word), word);
});
