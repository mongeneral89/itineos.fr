import { test } from 'node:test';
import assert from 'node:assert/strict';
import { nextReminder, type DunningState } from '../src/services/dunning.js';
import { docTexts, DOC_LANGS } from '../src/services/doc-i18n.js';

const days = [7, 15, 30];
const s = (o: Partial<DunningState>): DunningState => ({ dueDate: '2026-10-01', level: 0, lastOn: null, paused: false, inCollection: false, ...o });

test('relances : rappel, relance puis mise en demeure, aux jours réglés après l’échéance', () => {
  assert.deepEqual(nextReminder(s({}), days), { level: 1, on: '2026-10-08' });
  assert.deepEqual(nextReminder(s({ level: 1, lastOn: '2026-10-08' }), days), { level: 2, on: '2026-10-16' });
  assert.deepEqual(nextReminder(s({ level: 2, lastOn: '2026-10-16' }), days), { level: 3, on: '2026-10-31' });
  assert.equal(nextReminder(s({ level: 3, lastOn: '2026-10-31' }), days), null, 'plus rien après la mise en demeure');
});

test('relances : un niveau à la fois, au moins 7 jours entre deux', () => {
  // Très en retard quand l'envoi est activé : le rappel d'abord, la relance 7 jours plus tard
  assert.deepEqual(nextReminder(s({ dueDate: '2026-06-01' }), days), { level: 1, on: '2026-06-08' });
  assert.deepEqual(nextReminder(s({ dueDate: '2026-06-01', level: 1, lastOn: '2026-10-20' }), days), { level: 2, on: '2026-10-27' });
});

test('relances : jamais pendant un prélèvement en cours, ni suspendues, ni sans échéance', () => {
  assert.equal(nextReminder(s({ inCollection: true }), days), null);
  assert.equal(nextReminder(s({ paused: true }), days), null);
  assert.equal(nextReminder(s({ dueDate: null }), days), null);
});

test('relances : e-mail dans chaque langue, avec le n° de facture, l’échéance et le montant', () => {
  for (const lang of DOC_LANGS) {
    for (const level of [1, 2, 3] as const) {
      const m = docTexts(lang).reminderMail({ company: 'Société', number: 'FR-FAC-2026-00012', due: '1er octobre', remaining: '108,00 €', level });
      assert.ok(m.subject.includes('FR-FAC-2026-00012'), `${lang} ${level}`);
      for (const x of ['FR-FAC-2026-00012', '1er octobre', '108,00 €', 'Société']) assert.ok(m.text.includes(x), `${lang} ${level} : ${x}`);
    }
  }
  const fr = docTexts('fr');
  assert.match(fr.reminderMail({ company: 'S', number: 'N', due: 'D', remaining: 'R', level: 3 }).subject, /Mise en demeure/);
});
