import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cleanFileName, contentDisposition, parseFileDataUrl } from '../src/services/files.js';
import { dayIn, defaultDay, haversineKm, scoreCandidate } from '../src/services/assign.js';

const dataUrl = (mime: string, bytes: number[] | Buffer) => `data:${mime};base64,${Buffer.from(bytes).toString('base64')}`;

test('fichiers joints : le contenu doit correspondre au type annoncé', () => {
  const pdf = parseFileDataUrl(dataUrl('application/pdf', Buffer.from('%PDF-1.4 essai')), 'C:\\Users\\x\\Notice "centrale".pdf');
  assert.equal(pdf?.ext, 'pdf');
  assert.equal(pdf?.name, 'Notice centrale.pdf', 'sans dossier ni guillemets');
  const docx = parseFileDataUrl(dataUrl('application/vnd.openxmlformats-officedocument.wordprocessingml.document', [0x50, 0x4b, 0x03, 0x04, 1, 2]), 'procédure.docx');
  assert.equal(docx?.ext, 'docx');
  assert.equal(parseFileDataUrl(dataUrl('text/plain', Buffer.from('Bonjour, ça va ?')), 'note.txt')?.ext, 'txt');
  // Refusés : un faux PDF, du HTML (pourrait s'exécuter), un SVG, un texte binaire
  assert.equal(parseFileDataUrl(dataUrl('application/pdf', Buffer.from('<html>')), 'x.pdf'), null);
  assert.equal(parseFileDataUrl(dataUrl('text/html', Buffer.from('<script>')), 'x.html'), null);
  assert.equal(parseFileDataUrl(dataUrl('image/svg+xml', Buffer.from('<svg/>')), 'x.svg'), null);
  assert.equal(parseFileDataUrl(dataUrl('text/plain', [0x41, 0, 0x42]), 'x.txt'), null);
  assert.equal(parseFileDataUrl(dataUrl('application/pdf', Buffer.alloc(10 * 1024 * 1024 + 1, 0x25)), 'gros.pdf'), null, '10 Mo au plus');
  assert.equal(cleanFileName('   ', 'pdf'), 'fichier.pdf');
});

test('fichiers joints : photos et PDF s’affichent, le reste se télécharge (nom accentué conservé)', () => {
  assert.match(contentDisposition('application/pdf', 'Notice.pdf'), /^inline;/);
  assert.match(contentDisposition('image/jpeg', 'photo.jpg'), /^inline;/);
  const d = contentDisposition('application/vnd.ms-excel', 'Tarifs été.xls');
  assert.match(d, /^attachment;/);
  assert.match(d, /filename="Tarifs _t_\.xls"/);
  assert.match(d, /filename\*=UTF-8''Tarifs%20%C3%A9t%C3%A9\.xls/);
});

test('suggestion : distance, jours et note selon la priorité', () => {
  const nancy = { lat: 48.6921, lng: 6.1844 };
  const metz = { lat: 49.1193, lng: 6.1757 };
  const km = haversineKm(nancy, metz);
  assert.ok(km > 45 && km < 50, `Nancy–Metz ≈ 47 km (${km})`);
  assert.equal(dayIn(new Date('2026-10-11T22:30:00Z'), 'Europe/Paris'), '2026-10-12', 'minuit passé à Paris');
  // Vendredi soir : une intervention normale est proposée pour le lundi, une urgence pour aujourd'hui
  const friday = new Date('2026-10-09T16:00:00Z');
  assert.equal(defaultDay('NORMAL', friday, 'Europe/Paris'), '2026-10-12');
  assert.equal(defaultDay('URGENT', friday, 'Europe/Paris'), '2026-10-09');

  const ctx = { anyDistance: true, anyParts: false };
  const near = { distanceKm: 2, loadMinutes: 360, conflicts: 0, stockCoverage: null, missingCerts: 0 };
  const free = { distanceKm: 45, loadMinutes: 0, conflicts: 0, stockCoverage: null, missingCerts: 0 };
  // Urgence : le plus proche passe devant, même chargé ; intervention ordinaire : le moins chargé
  assert.ok(scoreCandidate(near, 'URGENT', ctx) > scoreCandidate(free, 'URGENT', ctx));
  assert.ok(scoreCandidate(free, 'LOW', ctx) > scoreCandidate(near, 'LOW', ctx));
  // Matériel : celui qui a tout dans son véhicule passe devant à situation égale
  const withParts = { anyDistance: true, anyParts: true };
  assert.ok(scoreCandidate({ ...near, stockCoverage: 1 }, 'NORMAL', withParts) > scoreCandidate({ ...near, stockCoverage: 0 }, 'NORMAL', withParts));
  // Non habilité ou déjà pris sur le créneau : derrière les autres
  assert.ok(scoreCandidate({ ...near, missingCerts: 1 }, 'URGENT', ctx) < scoreCandidate(free, 'URGENT', ctx));
  assert.ok(scoreCandidate({ ...near, conflicts: 1 }, 'URGENT', ctx) < scoreCandidate(near, 'URGENT', ctx));
  // Notes toujours entre 0 et 100
  for (const p of ['LOW', 'NORMAL', 'HIGH', 'URGENT'] as const) {
    const s = scoreCandidate({ distanceKm: 500, loadMinutes: 900, conflicts: 2, stockCoverage: 0, missingCerts: 3 }, p, withParts);
    assert.ok(s >= 0 && s <= 100);
  }
});
