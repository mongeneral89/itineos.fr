import { test } from 'node:test';
import assert from 'node:assert/strict';
import { planningNotices } from '../src/routes/interventions.js';

const at = (h: number) => new Date(`2026-10-19T${String(h).padStart(2, '0')}:00:00Z`);
const row = (technicianId: string | null, start: Date | null, status = 'PLANNED') => ({ technicianId, scheduledStart: start, status } as Parameters<typeof planningNotices>[0]);
const kinds = (r: ReturnType<typeof planningNotices>) => r.map((n) => `${n.userId}:${n.kind}`).sort();

test('replanifier : confiée à un autre, l’ancien et le nouveau technicien sont prévenus', () => {
  assert.deepEqual(kinds(planningNotices(row('julien', at(12)), row('lucas', at(9)), 'sophie')), ['julien:new', 'lucas:removed']);
});

test('déplacée à une autre heure : le technicien est prévenu une fois', () => {
  assert.deepEqual(kinds(planningNotices(row('julien', at(14)), row('julien', at(9)), 'sophie')), ['julien:moved']);
});

test('remise à planifier : le technicien qui l’avait est prévenu', () => {
  assert.deepEqual(kinds(planningNotices(row(null, null, 'TO_PLAN'), row('julien', at(9)), 'sophie')), ['julien:removed']);
});

test('annulée : celui qui devait la faire est prévenu, avec l’heure prévue', () => {
  const r = planningNotices(row('julien', at(9), 'CANCELLED'), row('julien', at(9)), 'sophie');
  assert.deepEqual(kinds(r), ['julien:cancelled']);
  assert.equal(r[0].start?.toISOString(), at(9).toISOString());
});

test('jamais celui qui fait le changement, et rien si rien ne change', () => {
  assert.deepEqual(planningNotices(row('julien', at(12)), row('lucas', at(9)), 'julien').map((n) => n.kind), ['removed']);
  assert.deepEqual(planningNotices(row('julien', at(9)), row('julien', at(9)), 'sophie'), []);
  assert.deepEqual(planningNotices(row('julien', at(9), 'CANCELLED'), row('julien', at(9), 'CANCELLED'), 'sophie'), []);
});
