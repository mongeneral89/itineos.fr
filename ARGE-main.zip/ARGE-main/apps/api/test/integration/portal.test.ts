import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let durandId: string;
let moreauId: string;
before(async () => {
  t = await startTestApp();
  [{ id: durandId }] = await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Cabinet Durand'");
  [{ id: moreauId }] = await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Boulangerie Moreau'");
});
after(async () => {
  await t.close();
});

const wait = () => new Promise((r) => setTimeout(r, 200)); // les e-mails partent sans bloquer la réponse

async function portalLogin(email = 'contact.durand@client.test', password = 'demo1234') {
  const res = await t.call<{ token: string }>('POST', '/portal/auth/login', { body: { email, password } });
  assert.equal(res.status, 200, `connexion portail ${email}`);
  return res.body.token;
}

test("invitation : le bureau invite, le client choisit son mot de passe depuis le lien et arrive dans son espace", async () => {
  const chef = await t.login('chef.est@exemple.test');
  t.mails.length = 0;
  const inv = await t.call('POST', `/clients/${durandId}/portal-users`, { token: chef, body: { email: 'Paul.Gerant@client.test', name: 'Paul Gérant' } });
  assert.equal(inv.status, 201);
  assert.equal(inv.body.activated, false);
  assert.equal(t.mails.length, 1);
  assert.deepEqual(t.mails[0].to, ['paul.gerant@client.test']);
  const link = /https:\/\/itineo\.test\/portail\/activer\?token=([\w%-]+)/.exec(t.mails[0].text);
  assert.ok(link, "l'invitation contient le lien vers le portail");
  const token = decodeURIComponent(link[1]);

  const info = await t.call('GET', `/portal/auth/link?token=${encodeURIComponent(token)}`);
  assert.equal(info.status, 200);
  assert.equal(info.body.clientName, 'Cabinet Durand');
  assert.equal(info.body.purpose, 'invite');

  assert.equal((await t.call('POST', '/portal/auth/activate', { body: { token, password: 'court' } })).status, 400);
  const act = await t.call<{ token: string }>('POST', '/portal/auth/activate', { body: { token, password: 'Mon-espace-2026' } });
  assert.equal(act.status, 200);
  assert.equal((await t.call('POST', '/portal/auth/activate', { body: { token, password: 'Encore-un-autre' } })).status, 400, 'lien déjà utilisé');

  const me = await t.call('GET', '/portal/me', { token: act.body.token });
  assert.equal(me.status, 200);
  assert.equal(me.body.client.name, 'Cabinet Durand');
  assert.ok(me.body.sites.length >= 1);
  await portalLogin('paul.gerant@client.test', 'Mon-espace-2026');

  // La liste vue par le bureau
  const list = await t.call('GET', `/clients/${durandId}/portal-users`, { token: chef });
  assert.ok(list.body.some((u: { email: string; activated: boolean }) => u.email === 'paul.gerant@client.test' && u.activated));
});

test("une même adresse ne peut pas avoir d'accès pour deux clients ; un chef d'agence n'invite que chez ses clients", async () => {
  const admin = await t.login('admin@exemple.test');
  const dup = await t.call('POST', `/clients/${moreauId}/portal-users`, { token: admin, body: { email: 'contact.durand@client.test', name: 'X' } });
  assert.equal(dup.status, 409);
  const [{ id: lille }] = await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Pharmacie du Beffroi'");
  const chef = await t.login('chef.est@exemple.test');
  assert.equal((await t.call('POST', `/clients/${lille}/portal-users`, { token: chef, body: { email: 'pharma@client.test', name: 'Y' } })).status, 403);
});

test('sessions étanches : un jeton client est refusé au bureau, un jeton du bureau est refusé au portail', async () => {
  const client = await portalLogin();
  const staff = await t.login('chef.est@exemple.test');
  assert.equal((await t.call('GET', '/me', { token: client })).status, 401);
  assert.equal((await t.call('GET', '/interventions?companyId=00000000-0000-0000-0000-000000000000', { token: client })).status, 401);
  assert.equal((await t.call('GET', '/portal/me', { token: staff })).status, 401);
  assert.equal((await t.call('GET', '/portal/me')).status, 401);
  assert.equal((await t.call('POST', '/portal/auth/login', { body: { email: 'contact.durand@client.test', password: 'faux' } })).status, 401);
});

test("le client ne voit que ses propres interventions, devis et documents", async () => {
  const client = await portalLogin();
  const ivs = await t.call<{ id: string; number: string }[]>('GET', '/portal/interventions', { token: client });
  assert.equal(ivs.status, 200);
  assert.ok(ivs.body.length >= 2);
  const own = await t.sql<{ id: string }>('SELECT id FROM interventions WHERE client_id = $1', [durandId]);
  for (const iv of ivs.body) assert.ok(own.some((o) => o.id === iv.id), `intervention ${iv.number} du client`);

  const [other] = await t.sql<{ id: string }>('SELECT id FROM interventions WHERE client_id = $1 LIMIT 1', [moreauId]);
  assert.equal((await t.call('GET', `/portal/interventions/${other.id}/report.pdf`, { token: client })).status, 404);

  // Le devis de la boulangerie n'est ni listé ni accessible
  const quotes = await t.call<unknown[]>('GET', '/portal/quotes', { token: client });
  assert.deepEqual(quotes.body, []);
  const [moreauQuote] = await t.sql<{ id: string }>('SELECT id FROM quotes WHERE client_id = $1', [moreauId]);
  assert.equal((await t.call('GET', `/portal/quotes/${moreauQuote.id}/pdf`, { token: client })).status, 404);
  assert.equal((await t.call('POST', `/portal/quotes/${moreauQuote.id}/decision`, { token: client, body: { decision: 'ACCEPTED', name: 'Pirate' } })).status, 404);
});

test("devis : le client l'accepte en ligne une seule fois, et le bureau est prévenu", async () => {
  // Accès de la boulangerie, activé directement (le parcours d'invitation est testé plus haut)
  await t.sql(`INSERT INTO portal_users (group_id, client_id, email, name, password_hash, locale)
    SELECT group_id, id, 'gerant.moreau@client.test', 'Jean Moreau', (SELECT password_hash FROM users LIMIT 1), 'fr-FR' FROM clients WHERE id = $1`, [moreauId]);
  const client = await portalLogin('gerant.moreau@client.test');
  const quotes = await t.call<{ id: string; status: string; expired: boolean }[]>('GET', '/portal/quotes', { token: client });
  assert.equal(quotes.body.length, 1);
  assert.equal(quotes.body[0].status, 'SENT');
  assert.equal(quotes.body[0].expired, false);

  t.mails.length = 0;
  const id = quotes.body[0].id;
  assert.equal((await t.call('POST', `/portal/quotes/${id}/decision`, { token: client, body: { decision: 'ACCEPTED', name: '' } })).status, 400);
  const ok = await t.call('POST', `/portal/quotes/${id}/decision`, { token: client, body: { decision: 'ACCEPTED', name: 'Jean Moreau', note: 'Le plus tôt possible' } });
  assert.equal(ok.status, 200);
  const [row] = await t.sql<{ status: string; decision_name: string; decided_at: Date | null }>('SELECT status, decision_name, decided_at FROM quotes WHERE id = $1', [id]);
  assert.equal(row.status, 'ACCEPTED');
  assert.equal(row.decision_name, 'Jean Moreau');
  assert.ok(row.decided_at);
  assert.equal((await t.call('POST', `/portal/quotes/${id}/decision`, { token: client, body: { decision: 'REFUSED', name: 'Jean Moreau' } })).status, 409);
  await wait();
  const notice = t.mails.find((m) => m.subject.includes('accepté'));
  assert.ok(notice, 'e-mail au bureau');
  assert.ok(notice.to.includes('est@exemple-services.test'));
  assert.ok(notice.text.includes('Le plus tôt possible'));
});

test("demande d'intervention : elle arrive « à planifier » au bureau, avec accusé de réception au client", async () => {
  const client = await portalLogin();
  const me = await t.call('GET', '/portal/me', { token: client });
  const site = me.body.sites[0];
  t.mails.length = 0;
  const res = await t.call<{ id: string; number: string }>('POST', '/portal/requests', {
    token: client,
    body: { siteId: site.id, equipmentId: site.equipments[0]?.id ?? null, reason: 'Le climatiseur goutte dans le bureau', clientNotes: 'Disponible le matin', urgent: true },
  });
  assert.equal(res.status, 201);
  const [iv] = await t.sql<{ status: string; source: string; priority: string; client_notes: string; agency_id: string; client_id: string }>(
    'SELECT status, source, priority, client_notes, agency_id, client_id FROM interventions WHERE id = $1', [res.body.id]);
  assert.equal(iv.status, 'TO_PLAN');
  assert.equal(iv.source, 'Portail client');
  assert.equal(iv.priority, 'URGENT');
  assert.equal(iv.client_notes, 'Disponible le matin');
  assert.equal(iv.client_id, durandId);
  await wait();
  assert.ok(t.mails.some((m) => m.to.includes('contact.durand@client.test') && m.subject.includes(res.body.number)), 'accusé de réception');
  assert.ok(t.mails.some((m) => m.to.includes('est@exemple-services.test') && m.text.includes('Disponible le matin')), 'bureau prévenu');

  // Visible dans son espace, et au bureau dans la liste à planifier
  const list = await t.call<{ id: string }[]>('GET', '/portal/interventions', { token: client });
  assert.ok(list.body.some((x) => x.id === res.body.id));

  // Un site d'un autre client est refusé
  const [otherSite] = await t.sql<{ id: string }>('SELECT id FROM sites WHERE client_id = $1', [moreauId]);
  assert.equal((await t.call('POST', '/portal/requests', { token: client, body: { siteId: otherSite.id, reason: 'Test intrusion' } })).status, 400);
});

test("accès coupé par le bureau : la session en cours et les nouvelles connexions sont refusées", async () => {
  const client = await portalLogin();
  const chef = await t.login('chef.est@exemple.test');
  const users = await t.call<{ id: string; email: string }[]>('GET', `/clients/${durandId}/portal-users`, { token: chef });
  const access = users.body.find((u) => u.email === 'contact.durand@client.test')!;
  assert.equal((await t.call('PATCH', `/portal-users/${access.id}`, { token: chef, body: { active: false } })).status, 200);
  assert.equal((await t.call('GET', '/portal/me', { token: client })).status, 401);
  assert.equal((await t.call('POST', '/portal/auth/login', { body: { email: 'contact.durand@client.test', password: 'demo1234' } })).status, 401);
  assert.equal((await t.call('PATCH', `/portal-users/${access.id}`, { token: chef, body: { active: true } })).status, 200);
  await portalLogin();
});

test('mot de passe oublié sur le portail : lien par e-mail, ancienne session fermée', async () => {
  const old = await portalLogin();
  t.mails.length = 0;
  assert.equal((await t.call('POST', '/portal/auth/forgot', { body: { email: 'contact.durand@client.test' } })).status, 204);
  assert.equal((await t.call('POST', '/portal/auth/forgot', { body: { email: 'inconnu@client.test' } })).status, 204);
  await wait();
  assert.equal(t.mails.length, 1);
  const token = decodeURIComponent(/activer\?token=([\w%-]+)/.exec(t.mails[0].text)![1]);
  await new Promise((r) => setTimeout(r, 5)); // la nouvelle version du mot de passe doit être postérieure
  assert.equal((await t.call('POST', '/portal/auth/activate', { body: { token, password: 'Nouveau-mdp-2026' } })).status, 200);
  assert.equal((await t.call('GET', '/portal/me', { token: old })).status, 401, 'ancienne session fermée');
  await portalLogin('contact.durand@client.test', 'Nouveau-mdp-2026');
});
