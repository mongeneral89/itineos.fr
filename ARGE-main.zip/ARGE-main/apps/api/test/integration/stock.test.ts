import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, TINY_PNG, type TestContext } from './setup.js';

let t: TestContext;
let planner: string; // planificateur de l'agence Est (gère le stock)
let tech: string; // Julien Simon, technicien Est, a un véhicule
let ids: { fr: string; est: string; depot: string; van: string; cd35: string; filtre: string; res: string };

const qty = async (locationId: string, articleId: string) =>
  Number((await t.sql<{ quantity: number }>('SELECT quantity FROM stock_levels WHERE location_id = $1 AND article_id = $2', [locationId, articleId]))[0]?.quantity ?? 0);

before(async () => {
  t = await startTestApp();
  planner = await t.login('planning.est@exemple.test');
  tech = await t.login('tech1.est@exemple.test');
  const [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  const [est] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'EST'");
  const [depot] = await t.sql<{ id: string }>("SELECT id FROM stock_locations WHERE name = 'Dépôt Nancy'");
  const [van] = await t.sql<{ id: string }>("SELECT id FROM stock_locations WHERE name = 'Véhicule de Julien Simon'");
  const art = async (ref: string) => (await t.sql<{ id: string }>('SELECT id FROM articles WHERE reference = $1', [ref]))[0].id;
  ids = { fr: fr.id, est: est.id, depot: depot.id, van: van.id, cd35: await art('CD-35'), filtre: await art('FIL-G4'), res: await art('RES-6K') };
});
after(async () => {
  await t.close();
});

test('données de départ : dépôt et véhicule approvisionnés, alertes de stock bas', async () => {
  assert.equal(await qty(ids.depot, ids.cd35), 16);
  assert.equal(await qty(ids.van, ids.cd35), 4);
  const low = await t.call<{ reference: string }[]>('GET', `/stock/levels?companyId=${ids.fr}&low=true`, { token: planner });
  assert.deepEqual(low.body.map((l) => l.reference), ['RES-6K'], '2 résistances pour un seuil de 2');
});

test('catalogue : référence unique par société, droits', async () => {
  const dup = await t.call('POST', '/articles', { token: planner, body: { companyId: ids.fr, reference: 'cd-35', name: 'Doublon' } });
  assert.equal(dup.status, 409);
  const ok = await t.call('POST', '/articles', { token: planner, body: { companyId: ids.fr, reference: 'VAN-3V', name: 'Vanne 3 voies', salePriceCents: 14_900, unit: 'u' } });
  assert.equal(ok.status, 201);
  assert.equal((await t.call('POST', '/articles', { token: tech, body: { companyId: ids.fr, reference: 'X', name: 'X' } })).status, 403);
  const sales = await t.call<{ reference: string }[]>('GET', `/articles?companyId=${ids.fr}&q=vanne`, { token: await t.login('direction.fr@exemple.test') });
  assert.equal(sales.body[0].reference, 'VAN-3V');
});

test('réception et inventaire mettent à jour le stock et laissent une trace', async () => {
  await t.call('POST', '/stock/receipts', { token: planner, body: { locationId: ids.depot, lines: [{ articleId: ids.res, quantity: 3 }], note: 'BL fournisseur 778' } });
  assert.equal(await qty(ids.depot, ids.res), 5);
  const adj = await t.call('POST', '/stock/adjustments', { token: planner, body: { locationId: ids.depot, articleId: ids.res, countedQuantity: 4 } });
  assert.equal(adj.body.delta, -1);
  assert.equal(await qty(ids.depot, ids.res), 4);
  const moves = await t.call<{ kind: string }[]>('GET', `/stock/movements?articleId=${ids.res}`, { token: planner });
  assert.deepEqual(moves.body.slice(0, 2).map((m) => m.kind), ['ADJUSTMENT', 'RECEIPT']);
});

test('bon de sortie : numéroté à la validation, refusé si le dépôt n’a pas assez, rien ne bouge en cas de refus', async () => {
  const draft = await t.call('POST', '/stock/slips', {
    token: planner,
    body: { fromLocationId: ids.depot, toLocationId: ids.van, lines: [{ articleId: ids.filtre, quantity: 5 }, { articleId: ids.res, quantity: 50 }] },
  });
  assert.equal(draft.status, 201);
  assert.equal(draft.body.number, null);
  const refused = await t.call('POST', `/stock/slips/${draft.body.id}/validate`, { token: planner });
  assert.equal(refused.status, 400);
  assert.match(refused.body.error, /Stock insuffisant pour RES-6K/);
  assert.equal(await qty(ids.depot, ids.filtre), 32, 'le filtre ne bouge pas : tout ou rien');
  const [{ n }] = await t.sql<{ n: string }>("SELECT count(*) AS n FROM counters WHERE kind = 'slip'");
  assert.equal(Number(n), 0, 'aucun numéro consommé');

  const fixed = await t.call('PUT', `/stock/slips/${draft.body.id}`, {
    token: planner,
    body: { fromLocationId: ids.depot, toLocationId: ids.van, lines: [{ articleId: ids.filtre, quantity: 5 }, { articleId: ids.res, quantity: 1 }] },
  });
  assert.equal(fixed.status, 200);
  const ok = await t.call('POST', `/stock/slips/${draft.body.id}/validate`, { token: planner });
  assert.equal(ok.status, 200);
  assert.match(ok.body.number, /^FR-BS-\d{4}-00001$/);
  assert.equal(await qty(ids.depot, ids.filtre), 27);
  assert.equal(await qty(ids.van, ids.filtre), 11);
  assert.equal((await t.call('POST', `/stock/slips/${draft.body.id}/validate`, { token: planner })).status, 409);
  assert.equal((await t.call('PUT', `/stock/slips/${draft.body.id}`, { token: planner, body: { fromLocationId: ids.depot, toLocationId: ids.van, lines: [] } })).status, 409);

  const pdf = await t.app.inject({ method: 'GET', url: `/api/stock/slips/${draft.body.id}/pdf`, headers: { authorization: `Bearer ${planner}` } });
  assert.equal(pdf.headers['content-type'], 'application/pdf');
});

test('bon de sortie vers une intervention (sortie chantier)', async () => {
  const [iv] = await t.sql<{ id: string }>("SELECT id FROM interventions WHERE reason = 'Pose et mise en service d’une pompe à chaleur'");
  const s = await t.call('POST', '/stock/slips', { token: planner, body: { fromLocationId: ids.depot, interventionId: iv.id, lines: [{ articleId: ids.cd35, quantity: 2 }] } });
  const v = await t.call('POST', `/stock/slips/${s.body.id}/validate`, { token: planner });
  assert.equal(v.status, 200);
  assert.equal(v.body.intervention.id, iv.id);
  const [m] = await t.sql<{ kind: string; to_location_id: string | null }>('SELECT kind, to_location_id FROM stock_movements WHERE slip_id = $1', [s.body.id]);
  assert.deepEqual(m, { kind: 'ISSUE', to_location_id: null });
  // Une seule destination à la fois
  assert.equal((await t.call('POST', '/stock/slips', { token: planner, body: { fromLocationId: ids.depot, toLocationId: ids.van, interventionId: iv.id, lines: [] } })).status, 400);
});

test('le technicien voit son véhicule, pas le dépôt', async () => {
  const mine = await t.call<{ vehicle: { id: string }; levels: { reference: string; quantity: number }[] }>('GET', '/stock/my-vehicle', { token: tech });
  assert.equal(mine.body.vehicle.id, ids.van);
  assert.ok(mine.body.levels.some((l) => l.reference === 'CD-35' && l.quantity === 4));
  assert.equal((await t.call('GET', `/stock/levels?locationId=${ids.van}`, { token: tech })).status, 200);
  assert.equal((await t.call('GET', `/stock/levels?locationId=${ids.depot}`, { token: tech })).status, 403);
  assert.equal((await t.call('POST', '/stock/receipts', { token: tech, body: { locationId: ids.van, lines: [{ articleId: ids.cd35, quantity: 1 }] } })).status, 403);
});

test('pièce posée sur la fiche : déduite du véhicule à la signature, et facturée au prix du catalogue', async () => {
  const [iv] = await t.sql<{ id: string }>("SELECT id FROM interventions WHERE reason = 'La climatisation ne démarre plus'");
  const { body: b } = await t.call('GET', `/interventions/${iv.id}/report`, { token: tech });
  await t.call('PUT', `/interventions/${iv.id}/report`, {
    token: tech,
    body: {
      data: { ...b.report.data, callType: 'Facturable', cause: 'Condensateur HS', work: 'Remplacé' }, outcome: 'DONE', laborMinutes: 60,
      parts: [{ label: 'Condensateur de démarrage 35 µF', reference: 'CD-35', quantity: 1, articleId: ids.cd35 }, { label: 'Collier', quantity: 2 }],
    },
  });
  const before = await qty(ids.van, ids.cd35);
  await t.call('POST', `/interventions/${iv.id}/report/sign`, { token: tech, body: { technicianSignature: TINY_PNG, clientSignature: TINY_PNG, clientSignerName: 'Dr Durand' } });
  assert.equal(await qty(ids.van, ids.cd35), before - 1);
  const [m] = await t.sql<{ kind: string; intervention_id: string }>("SELECT kind, intervention_id FROM stock_movements WHERE kind = 'CONSUMPTION'");
  assert.deepEqual(m, { kind: 'CONSUMPTION', intervention_id: iv.id });

  const chef = await t.login('chef.est@exemple.test');
  const inv = await t.call('POST', `/invoices/from-intervention/${iv.id}`, { token: chef });
  const { body: invoice } = await t.call('GET', `/invoices/${inv.body.id}`, { token: chef });
  const part = invoice.lines.find((l: { description: string }) => l.description.startsWith('Condensateur'));
  assert.equal(part.unitPriceCents, 2_850, 'prix de vente du catalogue');
  const free = invoice.lines.find((l: { description: string }) => l.description.startsWith('Collier'));
  assert.equal(free.unitPriceCents, 0, 'pièce libre : prix à compléter');
});

test('véhicule : un seul par technicien, rattaché à son agence ; lieu non vide non désactivable', async () => {
  const [tech2] = await t.sql<{ id: string }>("SELECT id FROM users WHERE email = 'tech1.est@exemple.test'");
  assert.equal((await t.call('POST', '/stock/locations', { token: planner, body: { companyId: ids.fr, agencyId: ids.est, kind: 'VEHICLE', name: 'Second', technicianId: tech2.id } })).status, 409);
  assert.equal((await t.call('PATCH', `/stock/locations/${ids.van}`, { token: planner, body: { active: false } })).status, 409);
});
