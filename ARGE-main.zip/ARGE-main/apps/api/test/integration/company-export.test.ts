import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { startTestApp, type TestContext } from './setup.js';
import { readCsv } from '../../src/services/import-table.js';
import { unzip } from '../../src/services/import-table.js';

let t: TestContext;
let fr: { id: string };
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

before(async () => {
  t = await startTestApp();
  [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
});
after(async () => {
  await t.close();
});

async function download(token: string, companyId = fr.id) {
  const res = await t.app.inject({ method: 'GET', url: `/api/org/companies/${companyId}/export`, headers: { authorization: `Bearer ${token}` } });
  return res;
}

test('export complet : archive lisible, données de la société, documents, rien de secret', async () => {
  // Une fiche signée avec son PDF, sa signature et une photo
  const dir = await mkdtemp(path.join(os.tmpdir(), 'itineo-export-'));
  const pdf = path.join(dir, 'fiche.pdf');
  const photo = path.join(dir, 'photo.jpg');
  await writeFile(pdf, '%PDF-1.4 fiche de test');
  await writeFile(photo, Buffer.from([0xff, 0xd8, 0xff, 0xd9]));
  const [i] = await t.sql<{ id: string; number: string }>('SELECT id, number FROM interventions WHERE company_id = $1 ORDER BY number LIMIT 1', [fr.id]);
  const [tpl] = await t.sql<{ id: string; schema: unknown }>('SELECT id, schema FROM form_templates LIMIT 1');
  const [report] = await t.sql<{ id: string }>(
    `INSERT INTO reports (intervention_id, template_id, template_schema, data, status, client_signature, client_signer_name, pdf_path, signed_at)
     VALUES ($1, $2, $3, '{"constat":"RAS ; batterie changée"}', 'SIGNED', $4, 'Mme Martin', $5, now()) RETURNING id`,
    [i.id, tpl.id, JSON.stringify(tpl.schema), PNG, pdf],
  );
  await t.sql(`INSERT INTO report_photos (report_id, client_id, kind, mime_type, size_bytes, file_path) VALUES ($1, gen_random_uuid(), 'AFTER', 'image/jpeg', 4, $2)`, [report.id, photo]);
  await t.sql(`INSERT INTO report_photos (report_id, client_id, kind, mime_type, size_bytes, file_path) VALUES ($1, gen_random_uuid(), 'AFTER', 'image/jpeg', 4, '/introuvable.jpg')`, [report.id]);
  await t.sql("UPDATE companies SET einvoice_api_token = 'SECRET-PLATEFORME' WHERE id = $1", [fr.id]);

  const admin = await t.login('admin@exemple.test');
  const res = await download(admin);
  assert.equal(res.statusCode, 200);
  assert.equal(res.headers['content-type'], 'application/zip');
  assert.match(String(res.headers['content-disposition']), /attachment; filename="itineos-export-fr-\d{4}-\d{2}-\d{2}\.zip"/);

  const files = unzip(res.rawPayload);
  const text = (name: string) => {
    const f = files.get(name);
    assert.ok(f, `${name} présent`);
    return f().toString('utf8');
  };
  const table = (name: string) => readCsv(text(`donnees/${name}.csv`).replace(/^﻿/, '')).filter((r) => r.some((c) => c));

  // Les tableaux attendus, avec leurs lignes
  for (const name of ['societe', 'agences', 'utilisateurs', 'clients', 'sites', 'materiels', 'interventions', 'fiches', 'photos', 'factures', 'articles', 'vehicules']) {
    assert.ok(files.has(`donnees/${name}.csv`), name);
  }
  const clients = table('clients');
  const [{ n: clientCount }] = await t.sql<{ n: string }>('SELECT count(*) AS n FROM clients WHERE company_id = $1', [fr.id]);
  assert.equal(clients.length - 1, Number(clientCount), 'tous les clients de la société, et seulement eux');
  const companyName = (await t.sql<{ name: string }>("SELECT name FROM companies WHERE country_code = 'GB'"))[0].name;
  assert.ok(!text('donnees/clients.csv').includes(companyName), 'rien d’une autre société');

  // Rien de secret
  const all = [...files.keys()].filter((k) => k.endsWith('.csv')).map((k) => text(k)).join('\n');
  assert.ok(!all.includes('SECRET-PLATEFORME'));
  assert.ok(!/password_hash|token_hash|\$2[aby]\$/.test(all), 'ni mot de passe ni empreinte');
  assert.ok(!all.includes(dir), 'aucun chemin du serveur');
  assert.ok(!all.includes('data:image/png'), 'les signatures sont des fichiers à part');

  // La fiche : ses réponses, son PDF, sa signature, ses photos (une introuvable : colonne vide, signalée)
  const fiches = table('fiches');
  const header = fiches[0];
  const row = fiches.find((r) => r[header.indexOf('id')] === report.id)!;
  assert.match(row[header.indexOf('data')], /batterie changée/);
  assert.equal(row[header.indexOf('fichier')], `fiches/${i.number}.pdf`);
  assert.equal(files.get(`fiches/${i.number}.pdf`)!().toString(), '%PDF-1.4 fiche de test');
  assert.ok(files.has(`fiches/${i.number}-signature-client.png`));
  const photos = table('photos');
  assert.deepEqual(photos.slice(1).map((r) => r[photos[0].indexOf('fichier')]).sort(), ['', `photos/${i.number}/after.jpg`]);
  assert.ok(files.has(`photos/${i.number}/after.jpg`));
  assert.match(text('LISEZ-MOI.txt'), /1 document\(s\) référencé\(s\) introuvable\(s\)/);
  assert.match(text('LISEZ-MOI.txt'), new RegExp(`donnees/clients\\.csv : ${clientCount} ligne`));
});

test('export complet : réservé à l’administrateur du groupe et au directeur de la société', async () => {
  const director = await t.login('direction.fr@exemple.test');
  assert.equal((await download(director)).statusCode, 200);
  for (const email of ['chef.est@exemple.test', 'compta.fr@exemple.test', 'tech1.est@exemple.test']) {
    assert.equal((await download(await t.login(email))).statusCode, 403, email);
  }
  // Le directeur d'une société n'exporte pas une autre société
  const [gb] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'GB'");
  assert.equal((await download(director, gb.id)).statusCode, 403);
  // L'export est noté dans le journal
  const logs = await t.sql<{ n: string }>("SELECT count(*) AS n FROM audit_logs WHERE action = 'export' AND entity = 'company'");
  assert.ok(Number(logs[0].n) >= 2);
});
