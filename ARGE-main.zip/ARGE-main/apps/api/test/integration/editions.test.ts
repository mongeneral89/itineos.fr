import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
});
after(async () => {
  await t.close();
});

test("une société d'une autre édition utilise les modèles de son métier", async () => {
  // Édition des techniciens par défaut : les modèles neutres
  const [be] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'BE'");
  const tech = await t.call<{ name: string; inUse: boolean; scope: string }[]>('GET', `/templates?companyId=${be.id}`, { token: admin });
  assert.ok(tech.body.some((x) => x.inUse && x.name === 'Fiche SAV / Dépannage'));
  assert.ok(!tech.body.some((x) => x.name === 'Rapport de ronde'), 'pas de modèles des autres métiers');

  // Itinéos Vigie : rondes, levées de doute… et le document commun « Consignes de télésurveillance »
  await t.sql("UPDATE companies SET sector = 'SECURITY' WHERE id = $1", [be.id]);
  const vigie = await t.call<{ name: string; kind: string; inUse: boolean; scope: string; schema: { lang: string } }[]>('GET', `/templates?companyId=${be.id}`, { token: admin });
  const used = vigie.body.filter((x) => x.inUse);
  assert.equal(used.length, 4);
  assert.deepEqual(used.map((x) => x.name).sort(), [
    'Mise en place de site / audit de sécurité', 'Rapport d’incident / main courante', 'Rapport de levée de doute', 'Rapport de ronde',
  ].sort());
  assert.ok(used.every((x) => x.schema.lang === 'fr'));
  assert.ok(vigie.body.some((x) => x.name === 'Consignes de télésurveillance'));
  assert.ok(!vigie.body.some((x) => x.name === 'Fiche SAV / Dépannage'), 'pas de modèles des techniciens');
  assert.ok(!vigie.body.some((x) => x.name === 'État des lieux d’entrée'), 'pas de modèles des autres métiers');

  // Royaume-Uni en Itinéos Clés : les modèles en anglais
  const [uk] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'GB'");
  await t.sql("UPDATE companies SET sector = 'RENTAL' WHERE id = $1", [uk.id]);
  const keys = await t.call<{ name: string; inUse: boolean }[]>('GET', `/templates?companyId=${uk.id}`, { token: admin });
  assert.ok(keys.body.some((x) => x.inUse && x.name === 'Check-in inventory'));
});

test('une nouvelle fiche suit le modèle du métier, pré-rempli', async () => {
  await t.sql("UPDATE companies SET sector = 'SECURITY' WHERE country_code = 'FR'");
  const tech = await t.login('tech1.est@exemple.test');
  const [iv] = await t.sql<{ id: string }>(`SELECT i.id FROM interventions i
     WHERE i.kind = 'SAV' AND i.status <> 'DONE' AND i.template_id IS NULL
       AND i.technician_id = (SELECT id FROM users WHERE email = 'tech1.est@exemple.test')
       AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.intervention_id = i.id)
     LIMIT 1`);
  const res = await t.call('GET', `/interventions/${iv.id}/report`, { token: tech });
  assert.equal(res.status, 200);
  const ids = res.body.report.templateSchema.sections.flatMap((s: any) => s.fields.map((f: any) => f.id));
  assert.ok(ids.includes('alarmType') && ids.includes('result'), 'fiche de levée de doute');
});

test("une société créée prend le secteur de l'édition installée", async () => {
  const res = await t.call('POST', '/org/companies', {
    token: admin,
    body: { name: 'Nouvelle', countryCode: 'FR', currency: 'EUR', documentPrefix: 'NV', sector: 'BAILIFF' },
  });
  assert.equal(res.status, 201);
  assert.equal(res.body.sector, 'TECH', 'le secteur ne se choisit pas : c’est celui de l’installation');
});
