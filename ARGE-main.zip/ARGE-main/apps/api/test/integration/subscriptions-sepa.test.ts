import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { earliestCollectionDate } from '../../src/services/sepa.js';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
let fr: { id: string };

// IBAN et ICS d'exemple publiés (documentation des banques et de la Banque de France)
const IBAN = 'FR76 3000 6000 0112 3456 7890 189';
const ICS = 'FR72 ZZZ 123456';

before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
  [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
});
after(async () => {
  await t.close();
});

test('abonnement facturé en lot, prélevé par fichier SEPA, puis encaissé', async () => {
  // Réglages SEPA de la société : un IBAN faux est refusé
  assert.equal((await t.call('PATCH', `/org/companies/${fr.id}/billing`, { token: admin, body: { sepaIban: 'FR76 3000 6000 0112 3456 7890 188' } })).status, 400);
  assert.equal((await t.call('PATCH', `/org/companies/${fr.id}/billing`, { token: admin, body: { sepaCreditorId: ICS, sepaIban: IBAN, sepaBic: 'BNPAFRPP' } })).status, 200);

  // Télésurveillance : sans visite, facturée chaque mois, 360 € HT par an
  const [ct] = (await t.call('GET', `/contracts?companyId=${fr.id}`, { token: admin })).body;
  const patched = await t.call('PATCH', `/contracts/${ct.id}`, {
    token: admin, body: { frequencyMonths: 0, billingMonths: 1, annualPriceCents: 36000, startDate: '2026-09-01', billedUntil: null, endDate: null },
  });
  assert.equal(patched.status, 200);

  const plan = (await t.call('GET', `/billing/subscriptions?companyId=${fr.id}&until=2026-11-30`, { token: admin })).body;
  const mine = plan.clients.find((c: any) => c.clientId === ct.clientId);
  assert.deepEqual(mine.lines.filter((l: any) => l.contractId === ct.id).map((l: any) => [l.start, l.end, l.amountCents]), [
    ['2026-09-01', '2026-09-30', 3000], ['2026-10-01', '2026-10-31', 3000], ['2026-11-01', '2026-11-30', 3000],
  ]);

  // Facturation avec émission directe ; relancée aussitôt, plus rien à facturer
  const run = await t.call('POST', '/billing/subscriptions', { token: admin, body: { companyId: fr.id, until: '2026-11-30', issue: true } });
  assert.equal(run.status, 200);
  assert.equal(run.body.issued, run.body.invoiceIds.length);
  assert.equal((await t.call('GET', `/billing/subscriptions?companyId=${fr.id}&until=2026-11-30`, { token: admin })).body.clients.length, 0, 'rien deux fois');
  const [{ invoiceId }] = await t.sql<{ invoiceId: string }>(
    `SELECT id AS "invoiceId" FROM invoices WHERE client_id = $1 AND status <> 'DRAFT' ORDER BY created_at DESC LIMIT 1`, [ct.clientId]);
  const inv = (await t.call('GET', `/invoices/${invoiceId}`, { token: admin })).body;
  assert.ok(inv.number, 'numérotée');
  assert.ok(inv.pdfPath, 'PDF archivé');
  assert.match(inv.title, /^Abonnement /, 'sans visite : un abonnement, pas un contrat d’entretien');
  const [{ billed }] = await t.sql<{ billed: string }>(`SELECT to_char(billed_until, 'YYYY-MM-DD') AS billed FROM contracts WHERE id = $1`, [ct.id]);
  assert.equal(billed, '2026-11-30');

  // Mandat du client : IBAN faux refusé, puis mandat avec sa référence unique
  assert.equal((await t.call('POST', `/clients/${ct.clientId}/mandates`, { token: admin, body: { holderName: 'X', iban: 'FR00 1234', signedOn: '2026-08-20' } })).status, 400);
  const mandate = await t.call('POST', `/clients/${ct.clientId}/mandates`, { token: admin, body: { holderName: ct.clientName, iban: 'DE89 3704 0044 0532 0130 00', signedOn: '2026-08-20' } });
  assert.equal(mandate.status, 201);
  assert.match(mandate.body.reference, /RUM/);
  assert.ok(!JSON.stringify(mandate.body).includes('DE89370400440532013000'), 'IBAN masqué');

  // Fichier de prélèvement : un week-end est refusé
  const pre = (await t.call('GET', `/billing/direct-debits/preview?companyId=${fr.id}`, { token: admin })).body;
  assert.ok(pre.ready);
  const due = pre.invoices.filter((i: any) => i.clientId === ct.clientId || i.id === invoiceId);
  assert.ok(due.some((i: any) => i.id === invoiceId && i.sequence === 'FRST'));
  const ids = due.map((i: any) => i.id);
  const sunday = (() => {
    const d = new Date(`${earliestCollectionDate(new Date().toISOString().slice(0, 10))}T00:00:00Z`);
    while (d.getUTCDay() !== 0) d.setUTCDate(d.getUTCDate() + 1);
    return d.toISOString().slice(0, 10);
  })();
  assert.equal((await t.call('POST', '/billing/direct-debits', { token: admin, body: { companyId: fr.id, collectionDate: sunday, invoiceIds: ids } })).status, 400);
  const batch = await t.call('POST', '/billing/direct-debits', { token: admin, body: { companyId: fr.id, collectionDate: pre.earliestDate, invoiceIds: ids } });
  assert.equal(batch.status, 201);
  const file = await t.app.inject({ method: 'GET', url: `/api/billing/direct-debits/${batch.body.id}/file`, headers: { authorization: `Bearer ${admin}` } });
  assert.equal(file.statusCode, 200);
  assert.match(file.body, /pain\.008\.001\.02/);
  assert.match(file.body, /<SeqTp>FRST<\/SeqTp>/);
  assert.match(file.body, /<IBAN>DE89370400440532013000<\/IBAN>/);
  assert.match(file.body, /<Id>FR72ZZZ123456<\/Id>/);
  assert.ok(!(await t.call('GET', `/billing/direct-debits/preview?companyId=${fr.id}`, { token: admin })).body.invoices.some((i: any) => ids.includes(i.id)), 'déjà dans un lot');

  // Encaissement : la facture est payée par prélèvement, le mandat passe en récurrent
  assert.equal((await t.call('POST', `/billing/direct-debits/${batch.body.id}/collected`, { token: admin, body: { rejectedInvoiceIds: [] } })).status, 200);
  const paid = (await t.call('GET', `/invoices/${invoiceId}`, { token: admin })).body;
  assert.equal(paid.remainingCents, 0);
  assert.equal(paid.payments[0].method, 'DIRECT_DEBIT');
  assert.ok((await t.call('GET', `/clients/${ct.clientId}/mandates`, { token: admin })).body[0].firstCollectedAt);
});
