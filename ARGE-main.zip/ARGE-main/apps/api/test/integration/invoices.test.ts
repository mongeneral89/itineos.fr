import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { addDays } from '@itineo/shared';
import { startTestApp, TINY_PNG, type TestContext } from './setup.js';

let t: TestContext;
let dir: string; // direction France : facture pour toute la société
let chef: string; // chef d'agence Est
let ids: { fr: string; durand: string; durandSite: string; climId: string };
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Paris' }).format(new Date());
const seq = (n: string) => Number(n.slice(-5));

before(async () => {
  t = await startTestApp();
  dir = await t.login('direction.fr@exemple.test');
  chef = await t.login('chef.est@exemple.test');
  const [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  const [durand] = await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Cabinet Durand'");
  const [site] = await t.sql<{ id: string }>('SELECT id FROM sites WHERE client_id = $1', [durand.id]);
  const [clim] = await t.sql<{ id: string }>("SELECT id FROM interventions WHERE reason = 'La climatisation ne démarre plus'");
  ids = { fr: fr.id, durand: durand.id, durandSite: site.id, climId: clim.id };
});
after(async () => {
  await t.close();
});

const line = (unitPriceCents: number, description = 'Prestation') => ({ description, quantity: 1, unitPriceCents, vatRateBp: 2000 });

test('réglages de facturation : réservés à qui facture pour toute la société', async () => {
  const body = { hourlyRateCents: 6_500, travelFeeCents: 3_500, paymentTermsDays: 30, bankDetails: 'FR76 0000 0000 0000 0000 0000 000' };
  assert.equal((await t.call('PATCH', `/org/companies/${ids.fr}/billing`, { token: chef, body })).status, 403);
  const ok = await t.call('PATCH', `/org/companies/${ids.fr}/billing`, { token: dir, body });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.hourlyRateCents, 6_500);
});

test("facture depuis une fiche signée : main-d'œuvre, déplacement et pièces repris ; émission avec numéro et échéance", async () => {
  const tech = await t.login('tech1.est@exemple.test');
  // Pas de facture tant que la fiche n'est pas signée
  assert.equal((await t.call('POST', `/invoices/from-intervention/${ids.climId}`, { token: chef })).status, 409);

  const { body: bundle } = await t.call('GET', `/interventions/${ids.climId}/report`, { token: tech });
  await t.call('PUT', `/interventions/${ids.climId}/report`, {
    token: tech,
    body: { data: { ...bundle.report.data, callType: 'Facturable', cause: 'x', work: 'y' }, outcome: 'DONE', laborMinutes: 90, travelMinutes: 20, parts: [{ label: 'Condensateur', reference: 'CD-35', quantity: 2 }] },
  });
  await t.call('POST', `/interventions/${ids.climId}/report/sign`, { token: tech, body: { technicianSignature: TINY_PNG, clientSignature: TINY_PNG, clientSignerName: 'Dr Durand' } });

  const created = await t.call('POST', `/invoices/from-intervention/${ids.climId}`, { token: chef });
  assert.equal(created.status, 201);
  const again = await t.call('POST', `/invoices/from-intervention/${ids.climId}`, { token: chef });
  assert.equal(again.body.id, created.body.id, 'une seule facture par intervention');

  const { body: draft } = await t.call('GET', `/invoices/${created.body.id}`, { token: chef });
  assert.equal(draft.status, 'DRAFT');
  assert.equal(draft.number, null, 'pas de numéro avant émission');
  assert.deepEqual(draft.lines.map((l: { description: string; quantity: number; unitPriceCents: number }) => [l.description, l.quantity, l.unitPriceCents]), [
    ["Main-d'œuvre", 1.5, 6_500],
    ['Déplacement', 1, 3_500],
    ['Condensateur – CD-35', 2, 0],
  ]);

  // Une ligne sans prix bloque l'émission
  const blocked = await t.call('POST', `/invoices/${draft.id}/issue`, { token: chef });
  assert.equal(blocked.status, 400);
  assert.match(blocked.body.error, /Condensateur/);

  const lines = draft.lines.map((l: Record<string, unknown>) => ({ description: l.description, quantity: l.quantity, unit: l.unit, unitPriceCents: l.unitPriceCents || 2_500, vatRateBp: l.vatRateBp }));
  const put = await t.call('PUT', `/invoices/${draft.id}`, { token: chef, body: { clientId: ids.durand, siteId: ids.durandSite, title: draft.title, lines } });
  assert.equal(put.body.netCents, 9_750 + 3_500 + 5_000);

  const issued = await t.call('POST', `/invoices/${draft.id}/issue`, { token: chef });
  assert.equal(issued.status, 200);
  assert.match(issued.body.number, /^FR-FAC-\d{4}-00001$/);
  assert.equal(issued.body.issueDate, today());
  assert.equal(issued.body.dueDate, addDays(today(), 30));
  assert.equal(issued.body.state, 'UNPAID');

  // Figée
  assert.equal((await t.call('PUT', `/invoices/${draft.id}`, { token: chef, body: { clientId: ids.durand, title: 'x', lines } })).status, 409);
  assert.equal((await t.call('DELETE', `/invoices/${draft.id}`, { token: chef })).status, 409);
  assert.equal((await t.call('POST', `/invoices/${draft.id}/issue`, { token: chef })).status, 409);

  const pdf = await t.app.inject({ method: 'GET', url: `/api/invoices/${draft.id}/pdf`, headers: { authorization: `Bearer ${chef}` } });
  assert.equal(pdf.headers['content-type'], 'application/pdf');

  t.mails.length = 0;
  const sent = await t.call('POST', `/invoices/${draft.id}/send`, { token: chef, body: {} });
  assert.equal(sent.status, 200);
  assert.match(t.mails[0].subject, /Facture FR-FAC-/);
  assert.equal(t.mails[0].attachments?.[0].content.subarray(0, 5).toString(), '%PDF-');
});

test('numérotation continue : les brouillons ne consomment pas de numéro, aucun trou', async () => {
  const a = await t.call('POST', '/invoices', { token: chef, body: { clientId: ids.durand, title: 'A', lines: [line(10_000)] } });
  const b = await t.call('POST', '/invoices', { token: chef, body: { clientId: ids.durand, title: 'B', lines: [line(20_000)] } });
  const c = await t.call('POST', '/invoices', { token: chef, body: { clientId: ids.durand, title: 'C', lines: [line(30_000)] } });
  assert.equal((await t.call('DELETE', `/invoices/${c.body.id}`, { token: chef })).status, 204, 'un brouillon se supprime');
  const nb = (await t.call('POST', `/invoices/${b.body.id}/issue`, { token: chef })).body.number;
  const na = (await t.call('POST', `/invoices/${a.body.id}/issue`, { token: chef })).body.number;
  assert.equal(seq(na), seq(nb) + 1);
  const all = await t.sql<{ number: string }>("SELECT number FROM invoices WHERE kind = 'INVOICE' AND number IS NOT NULL ORDER BY number");
  assert.deepEqual(all.map((r) => seq(r.number)), all.map((_, i) => i + 1), 'suite 1, 2, 3… sans trou');
});

test('paiements : partiel, trop-perçu refusé, soldé, annulation ; retard', async () => {
  const { body: d } = await t.call('POST', '/invoices', { token: chef, body: { clientId: ids.durand, title: 'Paiements', lines: [line(100_000)] } });
  assert.equal((await t.call('POST', `/invoices/${d.id}/payments`, { token: chef, body: { paidOn: today(), amountCents: 1, method: 'TRANSFER' } })).status, 409, 'pas sur un brouillon');
  await t.call('POST', `/invoices/${d.id}/issue`, { token: chef });

  const p1 = await t.call('POST', `/invoices/${d.id}/payments`, { token: chef, body: { paidOn: today(), amountCents: 50_000, method: 'CHECK', reference: 'Chèque 123' } });
  assert.equal(p1.status, 201);
  assert.equal((await t.call('GET', `/invoices/${d.id}`, { token: chef })).body.state, 'PARTIAL');
  assert.equal((await t.call('POST', `/invoices/${d.id}/payments`, { token: chef, body: { paidOn: today(), amountCents: 70_001, method: 'TRANSFER' } })).status, 400);

  // Échéance dépassée et pas soldée : en retard
  await t.sql("UPDATE invoices SET due_date = current_date - 3 WHERE id = $1", [d.id]);
  assert.equal((await t.call('GET', `/invoices/${d.id}`, { token: chef })).body.state, 'OVERDUE');
  const late = await t.call<{ id: string }[]>('GET', `/invoices?companyId=${ids.fr}&state=OVERDUE`, { token: chef });
  assert.ok(late.body.some((x) => x.id === d.id));

  await t.call('POST', `/invoices/${d.id}/payments`, { token: chef, body: { paidOn: today(), amountCents: 70_000, method: 'TRANSFER' } });
  const paid = await t.call('GET', `/invoices/${d.id}`, { token: chef });
  assert.equal(paid.body.state, 'PAID');
  assert.equal(paid.body.remainingCents, 0);

  assert.equal((await t.call('DELETE', `/invoices/${d.id}/payments/${p1.body.id}`, { token: chef })).status, 204);
  assert.equal((await t.call('GET', `/invoices/${d.id}`, { token: chef })).body.state, 'OVERDUE');
});

test('avoir : numérotation propre, solde la facture, jamais plus que la facture', async () => {
  const { body: d } = await t.call('POST', '/invoices', { token: chef, body: { clientId: ids.durand, title: 'À annuler', lines: [line(40_000)] } });
  await t.call('POST', `/invoices/${d.id}/issue`, { token: chef });
  assert.equal((await t.call('POST', `/invoices/${d.id}/credit-note`, { token: chef })).status, 201);
  const { body: cn } = await t.call('GET', `/invoices/${(await t.sql<{ id: string }>('SELECT id FROM invoices WHERE credited_invoice_id = $1', [d.id]))[0].id}`, { token: chef });
  assert.equal(cn.kind, 'CREDIT_NOTE');
  assert.equal(cn.grossCents, 48_000);
  const issued = await t.call('POST', `/invoices/${cn.id}/issue`, { token: chef });
  assert.match(issued.body.number, /^FR-AVO-\d{4}-00001$/);
  assert.equal(issued.body.dueDate, null);

  const original = await t.call('GET', `/invoices/${d.id}`, { token: chef });
  assert.equal(original.body.state, 'PAID', "l'avoir solde la facture");
  assert.equal(original.body.creditNotes.length, 1);

  // Un second avoir total dépasserait la facture
  const second = await t.call('POST', `/invoices/${d.id}/credit-note`, { token: chef });
  assert.equal((await t.call('POST', `/invoices/${second.body.id}/issue`, { token: chef })).status, 400);
  assert.equal((await t.call('POST', `/invoices/${cn.id}/credit-note`, { token: chef })).status, 409, "pas d'avoir sur un avoir");
});

test('facture depuis un devis accepté et depuis un contrat', async () => {
  const { body: q } = await t.call('POST', '/quotes', { token: chef, body: { clientId: ids.durand, siteId: ids.durandSite, title: 'Travaux', lines: [line(80_000, 'Pose')] } });
  assert.equal((await t.call('POST', `/invoices/from-quote/${q.id}`, { token: chef })).status, 409, 'devis pas encore accepté');
  await t.call('POST', `/quotes/${q.id}/send`, { token: chef, body: {} });
  await t.call('POST', `/quotes/${q.id}/status`, { token: chef, body: { status: 'ACCEPTED' } });
  const fromQuote = await t.call('POST', `/invoices/from-quote/${q.id}`, { token: chef });
  assert.equal(fromQuote.status, 201);
  assert.equal((await t.call('GET', `/invoices/${fromQuote.body.id}`, { token: chef })).body.netCents, 80_000);

  const [{ id: contractId }] = await t.sql<{ id: string }>('SELECT id FROM contracts LIMIT 1');
  const fromContract = await t.call('POST', `/invoices/from-contract/${contractId}`, { token: chef, body: { periodStart: '2026-01-01', months: 6 } });
  assert.equal(fromContract.status, 201);
  const { body: ci } = await t.call('GET', `/invoices/${fromContract.body.id}`, { token: chef });
  assert.match(ci.lines[0].description, /du 01\/01\/2026 au 30\/06\/2026/);
  assert.equal(ci.lines[0].unitPriceCents, 48_000, 'moitié du prix annuel (960 €)');
});

test('export comptable : journal équilibré, réservé à la société entière', async () => {
  const from = addDays(today(), -1);
  const to = addDays(today(), 1);
  assert.equal((await t.call('GET', `/invoices/export?companyId=${ids.fr}&from=${from}&to=${to}`, { token: chef })).status, 403);
  const res = await t.app.inject({ method: 'GET', url: `/api/invoices/export?companyId=${ids.fr}&from=${from}&to=${to}&format=journal`, headers: { authorization: `Bearer ${dir}` } });
  assert.equal(res.statusCode, 200);
  assert.match(String(res.headers['content-disposition']), /journal-ventes-FR/);
  const rows = res.body.replace(/^﻿/, '').trim().split('\r\n').slice(1).map((r) => r.split(';'));
  const sum = (i: number) => rows.reduce((s, r) => s + Number(r[i].replace(',', '.')), 0);
  assert.ok(rows.length >= 6);
  assert.equal(Math.round(sum(6) * 100), Math.round(sum(7) * 100), 'total débit = total crédit');
  assert.ok(rows.some((r) => r[2].includes('-AVO-')), "l'avoir est dans le journal");
  assert.ok(!rows.some((r) => r[2] === ''), 'pas de brouillon dans le journal');
});

test('droits : technicien et planificateur ne facturent pas', async () => {
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call<unknown[]>('GET', '/invoices', { token: tech })).body.length, 0);
  const planner = await t.login('planning.est@exemple.test');
  assert.equal((await t.call('POST', '/invoices', { token: planner, body: { clientId: ids.durand, title: 'x', lines: [] } })).status, 403);
  const compta = await t.login('compta.fr@exemple.test');
  assert.equal((await t.call('POST', '/invoices', { token: compta, body: { clientId: ids.durand, title: 'Compta', lines: [line(1_000)] } })).status, 201);
});
