/** Pièces jointes de la messagerie, notices et procédures, cartes SIM, statistiques, suggestion d'attribution */
import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, TINY_JPEG, type TestContext } from './setup.js';

let t: TestContext;
const ids: Record<string, string> = {};
let fr = '';
before(async () => {
  t = await startTestApp();
  for (const r of await t.sql<{ id: string; email: string }>('SELECT id, email FROM users')) ids[r.email] = r.id;
  fr = (await t.sql<{ id: string }>("SELECT id FROM companies WHERE document_prefix = 'FR'"))[0].id;
});
after(async () => {
  await t.close();
});

const PDF = `data:application/pdf;base64,${Buffer.from('%PDF-1.4 notice de test').toString('base64')}`;

test('messagerie : photo et fichier joints, lisibles seulement par les membres, effacés avec le message', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const tech = await t.login('tech1.est@exemple.test');
  const outsider = await t.login('tech2.est@exemple.test');
  const conv = await t.call('POST', '/conversations', { token: chef, body: { userIds: [ids['tech1.est@exemple.test']] } });

  const photo = await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: tech, body: { file: { dataUrl: TINY_JPEG, name: 'compteur.jpg' } } });
  assert.equal(photo.status, 201, 'une photo seule, sans texte');
  assert.deepEqual(photo.body.attachment, { name: 'compteur.jpg', mime: 'image/jpeg', size: photo.body.attachment.size });
  assert.equal(photo.body.attachmentPath, undefined, 'le chemin sur le serveur ne sort jamais');
  const pdf = await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: chef, body: { body: 'Le schéma', file: { dataUrl: PDF, name: 'schéma.pdf' } } });
  assert.equal(pdf.status, 201);

  const file = await t.app.inject({ method: 'GET', url: `/api/messages/${pdf.body.id}/attachment`, headers: { authorization: `Bearer ${tech}` } });
  assert.equal(file.statusCode, 200);
  assert.equal(file.headers['content-type'], 'application/pdf');
  assert.match(String(file.headers['content-disposition']), /^inline;/);
  assert.equal(file.headers['x-content-type-options'], 'nosniff');
  assert.equal((await t.call('GET', `/messages/${pdf.body.id}/attachment`, { token: outsider })).status, 403);

  const list = await t.call('GET', '/conversations', { token: tech });
  assert.equal(list.body.find((c: { id: string }) => c.id === conv.body.id).lastMessage.attachmentName, 'schéma.pdf');

  const html = `data:text/html;base64,${Buffer.from('<script>alert(1)</script>').toString('base64')}`;
  assert.equal((await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: chef, body: { file: { dataUrl: html, name: 'x.html' } } })).status, 400);
  const fake = `data:application/pdf;base64,${Buffer.from('pas un pdf').toString('base64')}`;
  assert.equal((await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: chef, body: { file: { dataUrl: fake, name: 'x.pdf' } } })).status, 400);

  assert.equal((await t.call('DELETE', `/messages/${pdf.body.id}`, { token: chef })).status, 204);
  assert.equal((await t.call('GET', `/messages/${pdf.body.id}/attachment`, { token: tech })).status, 404);
  const [row] = await t.sql<{ attachment_path: string | null }>('SELECT attachment_path FROM messages WHERE id = $1', [pdf.body.id]);
  assert.equal(row.attachment_path, null);
});

test('notices : le bureau publie, le technicien propose, le bureau valide ou refuse', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const tech1 = await t.login('tech1.est@exemple.test');
  const tech2 = await t.login('tech2.est@exemple.test');
  const bxl = await t.login('tech.bxl@exemple.test');

  const admin = await t.login('admin@exemple.test');
  const pub = await t.call('POST', '/procedures', { token: admin, body: { title: 'Notice Ajax Hub 2', category: 'MANUAL', keywords: 'Ajax hub', file: { dataUrl: PDF, name: 'hub2.pdf' } } });
  assert.equal(pub.status, 201);
  assert.equal(pub.body.status, 'APPROVED', 'publié directement, pour tout le groupe');
  const local = await t.call('POST', '/procedures', { token: chef, body: { title: 'Procédure agence Est', category: 'PROCEDURE', url: 'https://exemple.test/est' } });
  assert.equal(local.body.status, 'APPROVED', 'le chef d’agence publie directement, sur son agence');
  assert.ok(local.body.agencyId);
  assert.ok((await t.call('GET', '/procedures', { token: bxl })).body.some((p: { id: string }) => p.id === pub.body.id), 'visible partout dans le groupe');

  const prop = await t.call('POST', '/procedures', { token: tech1, body: { title: 'Astuce reset transmetteur', category: 'PROCEDURE', url: 'exemple.test/astuce', companyId: null } });
  assert.equal(prop.status, 201);
  assert.equal(prop.body.status, 'PENDING');
  assert.equal(prop.body.url, 'https://exemple.test/astuce');
  assert.equal(prop.body.agencyId !== null, true, 'rattachée à son agence');
  assert.ok(!(await t.call('GET', '/procedures', { token: tech2 })).body.some((p: { id: string }) => p.id === prop.body.id), 'pas visible des collègues avant validation');
  assert.equal((await t.call('GET', '/procedures/pending-count', { token: chef })).body.pending, 1);
  assert.equal((await t.call('POST', `/procedures/${prop.body.id}/review`, { token: tech2, body: { decision: 'APPROVED' } })).status, 403);
  assert.equal((await t.call('POST', `/procedures/${prop.body.id}/review`, { token: chef, body: { decision: 'REJECTED' } })).status, 400, 'motif obligatoire');

  const rejected = await t.call('POST', `/procedures/${prop.body.id}/review`, { token: chef, body: { decision: 'REJECTED', note: 'Ajoutez les étapes' } });
  assert.equal(rejected.body.status, 'REJECTED');
  const mine = (await t.call('GET', '/procedures', { token: tech1 })).body.find((p: { id: string }) => p.id === prop.body.id);
  assert.equal(mine.reviewNote, 'Ajoutez les étapes');
  const fixed = await t.call('PATCH', `/procedures/${prop.body.id}`, { token: tech1, body: { title: 'Astuce reset transmetteur (étapes)', category: 'PROCEDURE', url: 'https://exemple.test/astuce' } });
  assert.equal(fixed.body.status, 'PENDING', 'corrigée : repart en attente');

  await t.call('POST', `/procedures/${prop.body.id}/review`, { token: chef, body: { decision: 'APPROVED' } });
  assert.ok((await t.call('GET', '/procedures', { token: tech2 })).body.some((p: { id: string }) => p.id === prop.body.id), 'visible de l’agence une fois validée');
  assert.ok(!(await t.call('GET', '/procedures', { token: bxl })).body.some((p: { id: string }) => p.id === prop.body.id), 'pas des autres sociétés');
  assert.equal((await t.call('DELETE', `/procedures/${prop.body.id}`, { token: tech1 })).status, 403, 'validée : seul le bureau la supprime');

  const file = await t.app.inject({ method: 'GET', url: `/api/procedures/${pub.body.id}/file`, headers: { authorization: `Bearer ${tech2}` } });
  assert.equal(file.statusCode, 200);
  assert.equal(file.headers['content-type'], 'application/pdf');
});

test('cartes SIM : bureau seulement, ajout en lot sans doublons, suivi de l’activation', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const tech = await t.login('tech1.est@exemple.test');
  const compta = await t.login('compta.fr@exemple.test');
  assert.equal((await t.call('GET', `/sims?companyId=${fr}`, { token: tech })).status, 403);

  const imp = await t.call('POST', '/sims/import', { token: chef, body: {
    companyId: fr, agencyId: null, operator: 'Orange', lines: '8933 1501 1900 0000 001\n8933150119000000002 ; 06 39 98 00 01\n8933150119000000001\n123\n',
  } });
  assert.equal(imp.status, 200);
  assert.deepEqual({ created: imp.body.created, duplicates: imp.body.duplicates, invalid: imp.body.invalid }, { created: 2, duplicates: 0, invalid: ['123'] });
  const again = await t.call('POST', '/sims/import', { token: chef, body: { companyId: fr, lines: '8933150119000000001' } });
  assert.equal(again.body.duplicates, 1);
  assert.equal((await t.call('POST', '/sims', { token: chef, body: { companyId: fr, iccid: '8933150119000000002' } })).status, 409);

  const settings = await t.call('PATCH', '/sims/settings', { token: chef, body: { companyId: fr, provider: 'Prestataire SIM', portalUrl: 'portail.exemple.test' } });
  assert.equal(settings.status, 403, 'réglage de toute la société : pas pour un chef d’agence');
  const direction = await t.login('direction.fr@exemple.test');
  assert.equal((await t.call('PATCH', '/sims/settings', { token: direction, body: { companyId: fr, provider: 'Prestataire SIM', portalUrl: 'portail.exemple.test' } })).body.portalUrl, 'https://portail.exemple.test');

  const list = await t.call('GET', `/sims?companyId=${fr}`, { token: chef });
  assert.equal(list.body.cards.length, 2);
  assert.equal(list.body.portalUrl, 'https://portail.exemple.test');
  const card = list.body.cards.find((c: { phoneNumber: string | null }) => c.phoneNumber);
  const client = (await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Cabinet Durand'"))[0].id;
  const edited = await t.call('PATCH', `/sims/${card.id}`, { token: chef, body: { iccid: card.iccid, clientId: client, device: 'Transmetteur' } });
  assert.equal(edited.body.clientId, client);
  const req = await t.call('POST', `/sims/${card.id}/status`, { token: chef, body: { status: 'REQUESTED' } });
  assert.ok(req.body.requestedAt);
  const active = await t.call('POST', `/sims/${card.id}/status`, { token: chef, body: { status: 'ACTIVE' } });
  assert.ok(active.body.activatedAt);
  const read = await t.call('GET', `/sims?companyId=${fr}`, { token: compta });
  assert.equal(read.body.cards.find((c: { id: string }) => c.id === card.id).clientName, 'Cabinet Durand');
});

test('statistiques : indicateurs regroupés, droits de chaque source, garde-fous', async () => {
  const admin = await t.login('admin@exemple.test');
  const planner = await t.login('planning.est@exemple.test');
  const tech = await t.login('tech1.est@exemple.test');
  const year = new Date().getFullYear();
  const period = `from=${year - 1}-01-01&to=${year + 1}-12-31`;

  const all = await t.call('GET', `/stats?measures=count&by=all&${period}`, { token: admin });
  const [{ n }] = await t.sql<{ n: number }>('SELECT count(*)::int AS n FROM interventions');
  assert.equal(all.body.totals.count, n);
  const byTech = await t.call('GET', `/stats?measures=count,done,laborHours&by=technician&${period}`, { token: admin });
  assert.equal(byTech.status, 200);
  assert.equal(byTech.body.rows.reduce((s: number, r: { values: { count: number } }) => s + r.values.count, 0), n, 'la somme des lignes fait le total');
  assert.ok(byTech.body.rows.some((r: { label: string }) => r.label === 'Julien Simon'));

  const est = await t.call('GET', `/stats?measures=count&by=agency&${period}`, { token: planner });
  assert.deepEqual(est.body.rows.map((r: { label: string }) => r.label), ['Agence Est'], 'le planificateur ne voit que son agence');
  assert.equal((await t.call('GET', `/stats?measures=revenue&by=month&${period}`, { token: planner })).status, 403, 'pas de chiffre d’affaires sans accès aux factures');
  assert.equal((await t.call('GET', `/stats?measures=count&by=agency&${period}`, { token: tech })).status, 403);

  const pivot = await t.call('GET', `/stats?measures=count&by=technician&by2=kind&${period}`, { token: admin });
  assert.ok(pivot.body.rows.every((r: { key2?: string }) => r.key2 !== undefined));
  assert.equal((await t.call('GET', `/stats?measures=count,done&by=technician&by2=kind&${period}`, { token: admin })).status, 400);
  assert.equal((await t.call('GET', `/stats?measures=revenue&by=priority&${period}`, { token: admin })).status, 400, 'regroupement impossible pour les factures');
  assert.equal((await t.call('GET', `/stats?measures=count&by=all&from=2020-01-01&to=2026-01-01`, { token: admin })).status, 400, '3 ans au plus');
});

test('suggestion d’attribution : désactivée par défaut, puis distance, stock du véhicule et habilitations', async () => {
  const direction = await t.login('direction.fr@exemple.test');
  const planner = await t.login('planning.est@exemple.test');
  const [est] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'EST'");
  const [site] = await t.sql<{ id: string; client_id: string }>("SELECT s.id, s.client_id FROM sites s JOIN clients c ON c.id = s.client_id WHERE c.name = 'Cabinet Durand' LIMIT 1");
  const created = await t.call('POST', '/interventions', { token: planner, body: {
    companyId: fr, agencyId: est.id, clientId: site.client_id, siteId: site.id, kind: 'SAV', priority: 'URGENT', reason: 'Alarme en défaut',
  } });
  assert.equal(created.status, 201);
  const id = created.body.id;

  assert.equal((await t.call('GET', `/interventions/${id}/suggestions`, { token: planner })).status, 409, 'fonction désactivée par défaut');
  assert.equal((await t.call('PATCH', `/org/companies/${fr}/planning`, { token: planner, body: { assignSuggestions: true } })).status, 403);
  assert.equal((await t.call('PATCH', `/org/companies/${fr}/planning`, { token: direction, body: { assignSuggestions: true } })).body.assignSuggestions, true);

  // Le site est à Nancy ; Martin est à Nancy (position en direct), Julien à Metz
  await t.sql('UPDATE sites SET latitude = 48.6930, longitude = 6.1830 WHERE id = $1', [site.id]);
  await t.sql("UPDATE vehicles SET last_lat = 49.1193, last_lng = 6.1757, last_position_at = now() - interval '5 minutes' WHERE driver_id = $1", [ids['tech1.est@exemple.test']]);
  await t.sql("UPDATE vehicles SET last_lat = 48.6921, last_lng = 6.1844, last_position_at = now() - interval '5 minutes' WHERE driver_id = $1", [ids['tech2.est@exemple.test']]);
  let s = (await t.call('GET', `/interventions/${id}/suggestions`, { token: planner })).body;
  assert.equal(s.siteLocated, true);
  const names = s.candidates.map((c: { name: string }) => c.name);
  assert.ok(names.includes('Julien Simon') && names.includes('Martin Bernard'));
  assert.ok(!names.includes('Sarah Laurent'), 'seulement les techniciens de l’agence');
  assert.equal(s.candidates[0].name, 'Martin Bernard', 'urgence : le plus proche d’abord');
  assert.ok(s.candidates[0].distanceKm < 1);

  // Matériel à prévoir : 2 condensateurs, seul Julien en a dans son véhicule
  const [cd35] = await t.sql<{ id: string }>("SELECT id FROM articles WHERE reference = 'CD-35'");
  assert.equal((await t.call('PUT', `/interventions/${id}/needed-parts`, { token: planner, body: { parts: [{ articleId: cd35.id, quantity: 2 }] } })).status, 200);
  s = (await t.call('GET', `/interventions/${id}/suggestions`, { token: planner })).body;
  const julien = s.candidates.find((c: { name: string }) => c.name === 'Julien Simon');
  const martin = s.candidates.find((c: { name: string }) => c.name === 'Martin Bernard');
  assert.deepEqual([julien.stock.covered, julien.stock.missing.length], [2, 0]);
  assert.deepEqual([martin.stock.covered, martin.stock.missing.length], [0, 1]);

  // Habilitation exigée (fluides frigorigènes) : Martin ne l'a pas, il passe derrière
  const [fluides] = await t.sql<{ id: string }>("SELECT id FROM certification_types WHERE code = 'FLUIDES'");
  await t.call('PATCH', `/interventions/${id}`, { token: planner, body: { requiredCertificationIds: [fluides.id] } });
  s = (await t.call('GET', `/interventions/${id}/suggestions`, { token: planner })).body;
  assert.equal(s.candidates[0].name, 'Julien Simon');
  assert.ok(s.candidates.find((c: { name: string }) => c.name === 'Martin Bernard').missingCerts.length > 0);

  // Le technicien ne voit pas les suggestions
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('GET', `/interventions/${id}/suggestions`, { token: tech })).status, 403);
});

test('« Je suis sur place » avec une position précise : le site sans coordonnées les reçoit', async () => {
  const tech = await t.login('tech1.est@exemple.test');
  const [job] = await t.sql<{ id: string; site_id: string }>(
    'SELECT id, site_id FROM interventions WHERE technician_id = $1 ORDER BY scheduled_start LIMIT 1', [ids['tech1.est@exemple.test']]);
  await t.sql('UPDATE sites SET latitude = NULL, longitude = NULL, geo_source = NULL WHERE id = $1', [job.site_id]);
  const res = await t.call('POST', '/fleet/positions', { token: tech, body: { positions: [
    { lat: 48.6800, lng: 6.1700, accuracy: 20, recordedAt: new Date().toISOString(), event: 'ON_SITE', interventionId: job.id },
  ] } });
  assert.equal(res.body.stored, 1);
  const [site] = await t.sql<{ latitude: number; geo_source: string }>('SELECT latitude, geo_source FROM sites WHERE id = $1', [job.site_id]);
  assert.equal(site.latitude, 48.68);
  assert.equal(site.geo_source, 'ON_SITE');
});
