import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
const ids: Record<string, string> = {};
before(async () => {
  t = await startTestApp();
  for (const r of await t.sql<{ id: string; email: string }>('SELECT id, email FROM users')) ids[r.email] = r.id;
});
after(async () => {
  await t.close();
});

test('messagerie : une seule conversation à deux par paire, messages non lus, lecture', async () => {
  // (Paul et Julien ont déjà une conversation dans les données de démo : on prend la planificatrice)
  const chef = await t.login('planning.est@exemple.test');
  const tech = await t.login('tech1.est@exemple.test');

  const people = await t.call('GET', '/messages/people', { token: chef });
  assert.ok(people.body.some((p: { id: string }) => p.id === ids['tech1.est@exemple.test']));
  assert.ok(!people.body.some((p: { id: string }) => p.id === ids['planning.est@exemple.test']), 'on ne s’écrit pas à soi-même');

  const first = await t.call('POST', '/conversations', { token: chef, body: { userIds: [ids['tech1.est@exemple.test']] } });
  assert.equal(first.status, 201);
  assert.equal(first.body.kind, 'DIRECT');
  const again = await t.call('POST', '/conversations', { token: tech, body: { userIds: [ids['planning.est@exemple.test']] } });
  assert.equal(again.body.id, first.body.id, 'la même conversation est rouverte, dans un sens comme dans l’autre');

  await t.call('POST', `/conversations/${first.body.id}/read`, { token: tech });
  await t.call('POST', `/conversations/${first.body.id}/read`, { token: chef });
  const before = (await t.call('GET', '/messages/unread', { token: tech })).body.unread;
  const chefBefore = (await t.call('GET', '/messages/unread', { token: chef })).body.unread;
  const sent = await t.call('POST', `/conversations/${first.body.id}/messages`, { token: chef, body: { body: 'Peux-tu passer chez Durand ?' } });
  assert.equal(sent.status, 201);
  assert.equal((await t.call('GET', '/messages/unread', { token: tech })).body.unread, before + 1);
  assert.equal((await t.call('GET', '/messages/unread', { token: chef })).body.unread, chefBefore, 'ses propres messages ne sont pas « non lus »');

  const list = await t.call('GET', '/conversations', { token: tech });
  const conv = list.body.find((c: { id: string }) => c.id === first.body.id);
  assert.equal(conv.unread, 1);
  assert.equal(conv.lastMessage.body, 'Peux-tu passer chez Durand ?');
  await t.call('POST', `/conversations/${first.body.id}/read`, { token: tech });
  assert.equal((await t.call('GET', '/messages/unread', { token: tech })).body.unread, before);

  const empty = await t.call('POST', `/conversations/${first.body.id}/messages`, { token: tech, body: { body: '   ' } });
  assert.equal(empty.status, 400);
});

test("messagerie : une personne hors de la conversation ne la lit pas et n'y écrit pas", async () => {
  const chef = await t.login('chef.est@exemple.test');
  const outsider = await t.login('tech2.est@exemple.test');
  const conv = await t.call('POST', '/conversations', { token: chef, body: { userIds: [ids['tech1.est@exemple.test']] } });
  assert.equal((await t.call('GET', `/conversations/${conv.body.id}/messages`, { token: outsider })).status, 403);
  assert.equal((await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: outsider, body: { body: 'Coucou' } })).status, 403);
  assert.ok(!(await t.call('GET', '/conversations', { token: outsider })).body.some((c: { id: string }) => c.id === conv.body.id));
});

test('messagerie : groupe, ajout, renommage, départ (avec messages du système), modification et retrait de son message', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const tech1 = await t.login('tech1.est@exemple.test');
  const tech2 = await t.login('tech2.est@exemple.test');

  const group = await t.call('POST', '/conversations', { token: chef, body: { userIds: [ids['tech1.est@exemple.test']], title: 'Équipe Est' } });
  assert.equal(group.body.kind, 'GROUP');
  assert.equal(group.body.members.length, 2);
  await t.call('POST', `/conversations/${group.body.id}/messages`, { token: chef, body: { body: 'Avant son arrivée' } });
  const unreadBefore = (await t.call('GET', '/messages/unread', { token: tech2 })).body.unread;
  const added = await t.call('POST', `/conversations/${group.body.id}/members`, { token: tech1, body: { userIds: [ids['tech2.est@exemple.test']] } });
  assert.equal(added.body.members.length, 3);
  // Le nouvel arrivant voit seulement l'avis « X a ajouté… », pas ce qui précède son arrivée
  assert.equal((await t.call('GET', '/messages/unread', { token: tech2 })).body.unread, unreadBefore + 1);

  await t.call('PATCH', `/conversations/${group.body.id}`, { token: tech2, body: { title: 'Dépannage Est' } });
  const msg = await t.call('POST', `/conversations/${group.body.id}/messages`, { token: tech2, body: { body: 'En retard de 20 min' } });
  assert.equal((await t.call('PATCH', `/messages/${msg.body.id}`, { token: tech1, body: { body: 'piraté' } })).status, 403, 'on ne modifie que ses propres messages');
  await t.call('PATCH', `/messages/${msg.body.id}`, { token: tech2, body: { body: 'En retard de 30 min' } });
  await t.call('DELETE', `/conversations/${group.body.id}/members/me`, { token: tech2 });

  const thread = await t.call('GET', `/conversations/${group.body.id}/messages`, { token: chef });
  const events = thread.body.filter((m: { senderId: string | null }) => !m.senderId).map((m: { body: string }) => JSON.parse(m.body).e);
  assert.deepEqual(events, ['created', 'added', 'renamed', 'left']);
  const edited = thread.body.find((m: { id: string }) => m.id === msg.body.id);
  assert.equal(edited.body, 'En retard de 30 min');
  assert.ok(edited.editedAt);

  await t.call('DELETE', `/messages/${msg.body.id}`, { token: chef }).then((r) => assert.equal(r.status, 403));
  const list = await t.call('GET', '/conversations', { token: chef });
  assert.equal(list.body.find((c: { id: string }) => c.id === group.body.id).title, 'Dépannage Est');
  assert.equal((await t.call('GET', `/conversations/${group.body.id}/messages`, { token: tech2 })).status, 403, 'après son départ, plus d’accès');

  const direct = await t.call('POST', '/conversations', { token: chef, body: { userIds: [ids['tech1.est@exemple.test']] } });
  assert.equal((await t.call('DELETE', `/conversations/${direct.body.id}/members/me`, { token: chef })).status, 400);
});

test('annuaire : équipe et standards pour tous, contacts gérés selon le périmètre', async () => {
  const tech = await t.login('tech1.est@exemple.test');
  const chef = await t.login('chef.est@exemple.test');
  const admin = await t.login('admin@exemple.test');
  const [{ id: frId }] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  const [{ id: estId }] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'EST'");
  const [{ id: nordId }] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'NORD'");

  // Chacun renseigne son numéro
  await t.call('PATCH', '/me', { token: tech, body: { phone: '06 00 00 00 01' } });
  const dir = await t.call('GET', '/directory', { token: tech });
  assert.equal(dir.status, 200);
  assert.equal(dir.body.staff.find((s: { id: string }) => s.id === ids['tech1.est@exemple.test']).phone, '06 00 00 00 01');
  assert.ok(dir.body.agencies.length >= 2);

  // Un technicien consulte mais n'ajoute pas
  const denied = await t.call('POST', '/directory/contacts', { token: tech, body: { companyId: frId, agencyId: estId, name: 'Grossiste' } });
  assert.equal(denied.status, 403);
  // Le chef d'agence ajoute dans son agence, pas dans une autre ni pour tout le groupe
  const ok = await t.call('POST', '/directory/contacts', {
    token: chef, body: { companyId: frId, agencyId: estId, category: 'SUPPLIER', name: 'Comptoir', organization: 'Grossiste Est', phone: '03 00 00 00 00' },
  });
  assert.equal(ok.status, 201);
  assert.equal((await t.call('POST', '/directory/contacts', { token: chef, body: { companyId: frId, agencyId: nordId, name: 'X' } })).status, 403);
  assert.equal((await t.call('POST', '/directory/contacts', { token: chef, body: { name: 'Pompiers' } })).status, 403);
  const all = await t.call('POST', '/directory/contacts', { token: admin, body: { category: 'EMERGENCY', name: 'Pompiers', phone: '18' } });
  assert.equal(all.status, 201);

  const seen = await t.call('GET', '/directory', { token: tech });
  const comptoir = seen.body.contacts.find((c: { id: string }) => c.id === ok.body.id);
  assert.equal(comptoir.canEdit, false);
  assert.equal((await t.call('GET', '/directory', { token: chef })).body.contacts.find((c: { id: string }) => c.id === ok.body.id).canEdit, true);

  const upd = await t.call('PATCH', `/directory/contacts/${ok.body.id}`, { token: chef, body: { companyId: frId, agencyId: estId, category: 'SUPPLIER', name: 'Comptoir', phone: '03 11 11 11 11' } });
  assert.equal(upd.body.phone, '03 11 11 11 11');
  assert.equal((await t.call('DELETE', `/directory/contacts/${all.body.id}`, { token: chef })).status, 403);
  assert.equal((await t.call('DELETE', `/directory/contacts/${ok.body.id}`, { token: chef })).status, 204);
});

test('langue des documents : choisie sur la fiche du client, parmi les langues proposées', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const [client] = await t.sql<{ id: string }>("SELECT c.id FROM clients c JOIN companies co ON co.id = c.company_id WHERE co.country_code = 'FR' LIMIT 1");
  const res = await t.call('PATCH', `/clients/${client.id}`, { token: chef, body: { locale: 'es-ES' } });
  assert.equal(res.status, 200);
  assert.equal(res.body.locale, 'es-ES');
  assert.equal((await t.call('PATCH', `/clients/${client.id}`, { token: chef, body: { locale: 'xx-XX' } })).status, 400);
  assert.equal((await t.call('PATCH', `/clients/${client.id}`, { token: chef, body: { locale: null } })).body.locale, null);
});
