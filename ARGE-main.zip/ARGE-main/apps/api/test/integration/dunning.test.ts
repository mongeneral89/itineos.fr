import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
let fr: { id: string };
// Chargé après startTestApp : la connexion à la base se règle à ce moment-là (sinon base de développement)
let runDunning: typeof import('../../src/services/dunning.js').runDunning;

before(async () => {
  t = await startTestApp();
  ({ runDunning } = await import('../../src/services/dunning.js'));
  admin = await t.login('admin@exemple.test');
  [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
});
after(async () => {
  await t.close();
});

/** Facture émise, échue depuis `late` jours, pour un client qui a une adresse e-mail */
async function overdue(late: number) {
  const [client] = await t.sql<{ id: string }>(
    `SELECT id FROM clients WHERE company_id = $1 AND email IS NOT NULL ORDER BY name LIMIT 1`, [fr.id]);
  const [agency] = await t.sql<{ id: string }>(`SELECT id FROM agencies WHERE company_id = $1 ORDER BY code LIMIT 1`, [fr.id]);
  const draft = await t.call('POST', '/invoices', {
    token: admin, body: { agencyId: agency.id, clientId: client.id, title: 'Dépannage', lines: [{ description: 'Main-d’œuvre', quantity: 1, unitPriceCents: 9000, vatRateBp: 2000 }] },
  });
  assert.equal(draft.status, 201);
  assert.equal((await t.call('POST', `/invoices/${draft.body.id}/issue`, { token: admin })).status, 200);
  await t.sql(`UPDATE invoices SET due_date = current_date - $2::int WHERE id = $1`, [draft.body.id, late]);
  return draft.body.id as string;
}

test('relances : liste des impayés, envoi automatique un niveau à la fois, suspension, puis réglée', async () => {
  const id = await overdue(40);

  // Désactivé par défaut : rien ne part, mais la facture est listée avec sa prochaine relance
  assert.equal(await runDunning(new Date(), { anyHour: true }), 0);
  const list = (await t.call('GET', `/billing/reminders?companyId=${fr.id}`, { token: admin })).body;
  assert.equal(list.enabled, false);
  const row = list.invoices.find((r: any) => r.id === id);
  assert.equal(row.daysLate, 40);
  assert.equal(row.remainingCents, 10800);
  assert.equal(row.next.level, 1);

  // Délais incohérents refusés ; activation
  assert.equal((await t.call('PATCH', `/org/companies/${fr.id}/billing`, { token: admin, body: { dunningDays: [15, 7, 30] } })).status, 400);
  assert.equal((await t.call('PATCH', `/org/companies/${fr.id}/billing`, { token: admin, body: { dunningEnabled: true, dunningDays: [7, 15, 30] } })).status, 200);

  // 40 jours de retard : le rappel d'abord, pas la mise en demeure ; relancé aussitôt, rien de plus
  const before = t.mails.length;
  assert.ok(await runDunning(new Date(), { anyHour: true }) >= 1);
  const [{ number }] = await t.sql<{ number: string }>('SELECT number FROM invoices WHERE id = $1', [id]);
  const mine = () => t.mails.slice(before).filter((m) => m.subject.includes(number));
  assert.equal(mine().length, 1);
  assert.match(mine()[0].subject, /Rappel/);
  assert.match(mine()[0].text, /108,00/);
  assert.equal(mine()[0].attachments?.[0].filename, `${number}.pdf`);
  await runDunning(new Date(), { anyHour: true });
  assert.equal(mine().length, 1, 'au moins 7 jours entre deux relances');

  // Relance à la main : le niveau suivant, tout de suite
  const manual = await t.call('POST', `/invoices/${id}/reminders`, { token: admin, body: {} });
  assert.equal(manual.status, 200);
  assert.equal(manual.body.level, 2);
  assert.match(mine()[1].subject, /Relance/);

  // Suspendue : plus de relance automatique
  await t.sql(`UPDATE invoices SET dunning_last_on = current_date - 10 WHERE id = $1`, [id]);
  assert.equal((await t.call('PATCH', `/invoices/${id}/dunning`, { token: admin, body: { paused: true } })).status, 200);
  await runDunning(new Date(), { anyHour: true });
  assert.equal(mine().length, 2);
  const history = (await t.call('GET', `/invoices/${id}/reminders`, { token: admin })).body;
  assert.deepEqual(history.reminders.map((r: any) => r.level), [1, 2]);
  assert.equal(history.reminders[0].sentBy, null, 'le premier est parti tout seul');

  // Réglée : elle sort de la liste et ne peut plus être relancée
  assert.equal((await t.call('POST', `/invoices/${id}/payments`, { token: admin, body: { amountCents: 10800, method: 'TRANSFER', paidOn: new Date().toISOString().slice(0, 10) } })).status, 201);
  assert.ok(!(await t.call('GET', `/billing/reminders?companyId=${fr.id}`, { token: admin })).body.invoices.some((r: any) => r.id === id));
  assert.equal((await t.call('POST', `/invoices/${id}/reminders`, { token: admin, body: {} })).status, 409);
});
