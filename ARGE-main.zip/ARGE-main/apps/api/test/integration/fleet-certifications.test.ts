import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { addDays } from '@itineo/shared';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let chef: string;
let ids: { fr: string; est: string; julien: string; martin: string; kangoo: string; partner: string; fluides: string; pac: string };
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Paris' }).format(new Date());
const PDF = 'data:application/pdf;base64,' + Buffer.from('%PDF-1.4\n%test\n').toString('base64');

before(async () => {
  t = await startTestApp();
  chef = await t.login('chef.est@exemple.test');
  const one = async (q: string, p: unknown[] = []) => (await t.sql<{ id: string }>(q, p))[0].id;
  ids = {
    fr: await one("SELECT id FROM companies WHERE country_code = 'FR'"),
    est: await one("SELECT id FROM agencies WHERE code = 'EST'"),
    julien: await one("SELECT id FROM users WHERE email = 'tech1.est@exemple.test'"),
    martin: await one("SELECT id FROM users WHERE email = 'tech2.est@exemple.test'"),
    kangoo: await one("SELECT id FROM vehicles WHERE plate = 'AB-123-CD'"),
    partner: await one("SELECT id FROM vehicles WHERE plate = 'EF-456-GH'"),
    fluides: await one("SELECT id FROM certification_types WHERE code = 'FLUIDES'"),
    pac: await one("SELECT id FROM interventions WHERE reason = 'Pose et mise en service d’une pompe à chaleur'"),
  };
});
after(async () => {
  await t.close();
});

test("tableau des habilitations de l'agence : états calculés", async () => {
  const res = await t.call('GET', `/certifications?companyId=${ids.fr}&agencyId=${ids.est}`, { token: chef });
  assert.equal(res.status, 200);
  const julien = res.body.technicians.find((x: { id: string }) => x.id === ids.julien);
  const states = Object.fromEntries(julien.certifications.map((c: { typeId: string; state: string }) => [c.typeId, c.state]));
  assert.equal(states[ids.fluides], 'SOON');
  assert.ok(Object.values(states).includes('OVERDUE'), 'SST expirée');
});

test('habilitation avec justificatif PDF ; un faux PDF est refusé ; le technicien voit les siennes', async () => {
  const bad = await t.call('POST', '/certifications', { token: chef, body: { userId: ids.martin, typeId: ids.fluides, document: 'data:application/pdf;base64,' + Buffer.from('<html>').toString('base64') } });
  assert.equal(bad.status, 400);
  const ok = await t.call('POST', '/certifications', { token: chef, body: { userId: ids.martin, typeId: ids.fluides, obtainedOn: today(), expiresOn: addDays(today(), 1800), document: PDF } });
  assert.equal(ok.status, 201);
  const doc = await t.app.inject({ method: 'GET', url: `/api/certifications/${ok.body.id}/document`, headers: { authorization: `Bearer ${chef}` } });
  assert.equal(doc.headers['content-type'], 'application/pdf');

  const martin = await t.login('tech2.est@exemple.test');
  const mine = await t.call<{ code: string }[]>('GET', `/certifications/user/${ids.martin}`, { token: martin });
  assert.ok(mine.body.some((c) => c.code === 'FLUIDES'));
  assert.equal((await t.call('GET', `/certifications/user/${ids.julien}`, { token: martin })).status, 403, "pas celles d'un collègue");
  assert.equal((await t.call('POST', '/certifications', { token: martin, body: { userId: ids.martin, typeId: ids.fluides } })).status, 403);
});

test("planning : avertissement si le technicien n'a pas (ou plus) l'habilitation exigée", async () => {
  const planner = await t.login('planning.est@exemple.test');
  // Julien : attestation fluides valable encore 25 jours → OK aujourd'hui, manquante dans 2 mois
  const soon = new Date(`${today()}T09:00:00`);
  const r1 = await t.call('PATCH', `/interventions/${ids.pac}`, { token: planner, body: { technicianId: ids.julien, scheduledStart: soon.toISOString(), scheduledEnd: new Date(soon.getTime() + 3_600_000).toISOString() } });
  assert.equal(r1.status, 200);
  assert.deepEqual(r1.body.missingCertifications, []);
  const later = new Date(`${addDays(today(), 60)}T09:00:00`);
  const r2 = await t.call('PATCH', `/interventions/${ids.pac}`, { token: planner, body: { scheduledStart: later.toISOString(), scheduledEnd: new Date(later.getTime() + 3_600_000).toISOString() } });
  assert.equal(r2.status, 200, 'avertir sans bloquer');
  assert.equal(r2.body.missingCertifications[0].code, 'FLUIDES');
  const check = await t.call('GET', `/certifications/check?interventionId=${ids.pac}&technicianId=${ids.julien}`, { token: planner });
  assert.equal(check.body.missing[0].code, 'FLUIDES');
});

test('parc : liste avec la pire échéance de chaque véhicule ; à programmer', async () => {
  const list = await t.call<{ plate: string; worstState: string }[]>('GET', `/fleet/vehicles?companyId=${ids.fr}`, { token: chef });
  const state = Object.fromEntries(list.body.map((v) => [v.plate, v.worstState]));
  assert.deepEqual(state, { 'AB-123-CD': 'SOON', 'EF-456-GH': 'OVERDUE' });
  const todo = await t.call('GET', `/deadlines?companyId=${ids.fr}&agencyId=${ids.est}`, { token: chef });
  const kinds = todo.body.vehicles.map((x: { plate: string; kind: string }) => `${x.plate}:${x.kind}`);
  assert.equal(kinds[0], 'EF-456-GH:SERVICE', 'le dépassé en premier');
  assert.ok(kinds.includes('AB-123-CD:SERVICE'), 'entretien Kangoo : à 800 km');
  assert.ok(kinds.includes('AB-123-CD:TECH_INSPECTION'));
  assert.ok(!kinds.includes('EF-456-GH:INSURANCE'), 'assurance dans 70 jours : pas encore');
  assert.ok(todo.body.certifications.length >= 2);
});

test("entretien noté : échéance suivante recalculée, kilométrage mis à jour, rendez-vous effacé", async () => {
  const { body: before } = await t.call('GET', `/fleet/vehicles/${ids.partner}`, { token: chef });
  const service = before.deadlines.find((d: { kind: string }) => d.kind === 'SERVICE');
  await t.call('PATCH', `/fleet/deadlines/${service.id}`, { token: chef, body: { appointmentOn: today(), appointmentWith: 'Garage du Centre' } });
  const done = await t.call('POST', `/fleet/vehicles/${ids.partner}/events`, {
    token: chef, body: { kind: 'SERVICE', occurredOn: today(), mileage: 41_300, costCents: 21_000, provider: 'Garage du Centre', deadlineId: service.id },
  });
  assert.equal(done.status, 201);
  const { body: after } = await t.call('GET', `/fleet/vehicles/${ids.partner}`, { token: chef });
  const next = after.deadlines.find((d: { id: string }) => d.id === service.id);
  assert.equal(after.mileage, 41_300);
  assert.equal(next.dueMileage, 56_300);
  assert.equal(next.dueDate.slice(0, 4), String(Number(today().slice(0, 4)) + 1));
  assert.equal(next.appointmentOn, null);
  assert.equal(next.state, 'OK');
  assert.equal(after.costThisYear >= 21_000, true);
});

test('kilométrage : le conducteur le relève, le compteur ne recule pas, un autre technicien ne peut pas', async () => {
  const julien = await t.login('tech1.est@exemple.test');
  const mine = await t.call('GET', '/fleet/my-vehicle', { token: julien });
  assert.equal(mine.body.vehicle.plate, 'AB-123-CD');
  assert.equal((await t.call('POST', `/fleet/vehicles/${ids.kangoo}/mileage`, { token: julien, body: { mileage: 85_100 } })).status, 201);
  assert.equal((await t.call('POST', `/fleet/vehicles/${ids.kangoo}/mileage`, { token: julien, body: { mileage: 80_000 } })).status, 400);
  const martin = await t.login('tech2.est@exemple.test');
  assert.equal((await t.call('POST', `/fleet/vehicles/${ids.kangoo}/mileage`, { token: martin, body: { mileage: 90_000 } })).status, 403);
  // 85 100 km > 85 000 : l'entretien du Kangoo est maintenant dépassé
  const { body } = await t.call('GET', `/fleet/vehicles/${ids.kangoo}`, { token: chef });
  assert.equal(body.deadlines.find((d: { kind: string }) => d.kind === 'SERVICE').state, 'OVERDUE');
});

test('véhicule : immatriculation unique, droits', async () => {
  const dup = await t.call('POST', '/fleet/vehicles', { token: chef, body: { companyId: ids.fr, agencyId: ids.est, plate: 'ab 123 cd' } });
  assert.equal(dup.status, 409);
  const ok = await t.call('POST', '/fleet/vehicles', { token: chef, body: { companyId: ids.fr, agencyId: ids.est, plate: 'gh-789-ij', make: 'Citroën', model: 'Berlingo', mileage: 12_000 } });
  assert.equal(ok.status, 201);
  assert.equal(ok.body.plate, 'GH-789-IJ');
  const compta = await t.login('compta.fr@exemple.test');
  assert.equal((await t.call('GET', `/fleet/vehicles?companyId=${ids.fr}`, { token: compta })).body.length, 0, 'la comptabilité ne voit pas le parc');
});

test("récapitulatif du matin : une fois par jour, au bon destinataire", async () => {
  const { sendDailyDigests } = await import('../../src/services/digest.js');
  t.mails.length = 0;
  const morning = new Date(`${today()}T10:00:00+02:00`);
  const n = await sendDailyDigests(morning);
  assert.ok(n >= 1);
  const toDirector = t.mails.find((m) => m.to.includes('direction.fr@exemple.test'));
  assert.ok(toDirector, 'la direction France reçoit le récapitulatif');
  assert.match(toDirector.text, /EF-456-GH|AB-123-CD/);
  assert.match(toDirector.text, /HABILITATIONS/);
  assert.equal(await sendDailyDigests(morning), 0, 'pas deux fois le même jour');
});
