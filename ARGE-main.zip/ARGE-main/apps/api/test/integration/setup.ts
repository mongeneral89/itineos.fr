/**
 * Tests d'intégration : le vrai serveur, sur une vraie base PostgreSQL de test.
 *
 * La base « itineo_test » (même serveur que la base de développement, via docker compose) est
 * entièrement recréée à chaque fichier de test, puis remplie avec les données d'exemple.
 * La base de développement « itineo » n'est jamais touchée.
 *
 *   npm run test:integration
 *
 * Autre serveur : TEST_DATABASE_URL=postgres://… npm run test:integration
 */
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import pg from 'pg';
import type { FastifyInstance } from 'fastify';

const TEST_URL = process.env.TEST_DATABASE_URL ?? 'postgres://itineo:itineo@localhost:5432/itineo_test';

export interface TestContext {
  app: FastifyInstance;
  /** Requêtes SQL directes, pour préparer ou vérifier */
  sql: <T extends pg.QueryResultRow = Record<string, unknown>>(text: string, params?: unknown[]) => Promise<T[]>;
  /** E-mails « envoyés » (aucun SMTP en test) */
  mails: { to: string[]; subject: string; text: string; attachments?: { filename: string; content: Buffer }[] }[];
  login: (email: string, password?: string) => Promise<string>;
  call: <T = any>(method: string, url: string, opts?: { token?: string; body?: unknown }) => Promise<{ status: number; body: T }>;
  close: () => Promise<void>;
}

async function recreateDatabase() {
  const name = new URL(TEST_URL).pathname.slice(1);
  if (!/^[a-z0-9_]+$/.test(name) || !name.includes('test')) {
    throw new Error(`Par sécurité, la base de test doit contenir « test » dans son nom (reçu : ${name})`);
  }
  const admin = new pg.Client({ connectionString: TEST_URL.replace(/\/[^/]+$/, '/postgres') });
  await admin.connect();
  try {
    const { rowCount } = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [name]);
    if (!rowCount) await admin.query(`CREATE DATABASE ${name}`);
  } finally {
    await admin.end();
  }
  const db = new pg.Client({ connectionString: TEST_URL });
  await db.connect();
  try {
    // Certains serveurs (PGlite) ignorent le nom de la base demandée : on vérifie qu'on est bien
    // dans la base de test avant de tout effacer, sinon on viderait la base de démonstration
    const [{ current }] = (await db.query<{ current: string }>('SELECT current_database() AS current')).rows;
    if (current !== name) {
      throw new Error(`Par sécurité, arrêt : le serveur a ouvert la base « ${current} » au lieu de « ${name} » (PGlite ?). Utilisez un vrai PostgreSQL.`);
    }
    await db.query('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  } finally {
    await db.end();
  }
}

export async function startTestApp(): Promise<TestContext> {
  await recreateDatabase();
  const storage = await mkdtemp(path.join(os.tmpdir(), 'itineo-test-'));

  // Avant tout import du code : la configuration est lue au chargement des modules
  process.env.DATABASE_URL = TEST_URL;
  process.env.SMTP_URL = '';
  process.env.STORAGE_DIR = storage;
  process.env.JWT_SECRET = 'secret-de-test-tres-long-pour-les-tests';
  process.env.WEB_ORIGIN = 'https://itineo.test';

  const { migrate } = await import('../../src/db/migrate.js');
  await migrate(TEST_URL);
  const { seedDemo } = await import('../../src/db/seed.js');
  await seedDemo();
  const { buildApp } = await import('../../src/app.js');
  const { pool } = await import('../../src/db/client.js');
  const { unsentMails } = await import('../../src/services/mail.js');
  const app = await buildApp({ logger: false });
  await app.ready();

  const call: TestContext['call'] = async (method, url, opts = {}) => {
    const res = await app.inject({
      method: method as 'GET',
      url: `/api${url}`,
      headers: opts.token ? { authorization: `Bearer ${opts.token}` } : {},
      ...(opts.body !== undefined ? { payload: opts.body as object } : {}),
    });
    let body: any = res.body;
    try {
      body = res.json();
    } catch {
      /* réponse sans JSON (PDF, image, 204) */
    }
    return { status: res.statusCode, body };
  };

  return {
    app,
    sql: async (text, params) => (await pool.query(text, params as unknown[])).rows,
    mails: unsentMails,
    login: async (email, password = 'demo1234') => {
      const res = await call<{ token: string }>('POST', '/auth/login', { body: { email, password } });
      if (res.status !== 200) throw new Error(`Connexion impossible pour ${email} : ${res.status}`);
      return res.body.token;
    },
    call,
    close: async () => {
      await app.close();
      await pool.end();
      await rm(storage, { recursive: true, force: true });
    },
  };
}

/** Une petite image JPEG valide (1×1 pixel), pour les photos */
export const TINY_JPEG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=';
/** Une signature (PNG 1×1) */
export const TINY_PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
