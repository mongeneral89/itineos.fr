import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { addDays, addMonths } from '@itineo/shared';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let chef: string; // chef de l'agence Est
let ids: { fr: string; est: string; nord: string; durand: string; durandSite: string; durandEquipment: string; lille: string };
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Paris' }).format(new Date());

before(async () => {
  t = await startTestApp();
  chef = await t.login('chef.est@exemple.test');
  const [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  const [est] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'EST'");
  const [nord] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'NORD'");
  const [durand] = await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Cabinet Durand'");
  const [site] = await t.sql<{ id: string }>('SELECT id FROM sites WHERE client_id = $1', [durand.id]);
  const [eqp] = await t.sql<{ id: string }>('SELECT id FROM equipments WHERE site_id = $1', [site.id]);
  const [lille] = await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Pharmacie du Beffroi'");
  ids = { fr: fr.id, est: est.id, nord: nord.id, durand: durand.id, durandSite: site.id, durandEquipment: eqp.id, lille: lille.id };
});
after(async () => {
  await t.close();
});

const lines = [
  { description: 'Remplacement du compresseur', quantity: 1, unit: 'u', unitPriceCents: 89_000, vatRateBp: 2000 },
  { description: "Main-d'œuvre", quantity: 3.5, unit: 'h', unitPriceCents: 6_500, vatRateBp: 2000 },
];

test('devis : numérotation, totaux calculés par le serveur, modification en brouillon seulement', async () => {
  const a = await t.call('POST', '/quotes', { token: chef, body: { clientId: ids.durand, siteId: ids.durandSite, title: 'Remplacement compresseur', lines } });
  assert.equal(a.status, 201);
  assert.match(a.body.number, /^FR-DEV-\d{4}-\d{5}$/);
  assert.equal(a.body.netCents, 89_000 + 22_750);
  assert.equal(a.body.vatCents, Math.round((111_750 * 2000) / 10_000));
  assert.equal(a.body.currency, 'EUR');
  assert.equal(a.body.agencyId, ids.est, "l'agence du client est reprise");
  assert.equal(a.body.validUntil, addDays(today(), 30), 'valable 30 jours par défaut');

  const b = await t.call('POST', '/quotes', { token: chef, body: { clientId: ids.durand, title: 'Autre', lines: [] } });
  const seq = (n: string) => Number(n.slice(-5));
  assert.equal(seq(b.body.number), seq(a.body.number) + 1, 'numéros qui se suivent');
  // La numérotation des interventions n'est pas touchée
  const [{ n }] = await t.sql<{ n: string }>("SELECT count(*) AS n FROM interventions WHERE number LIKE 'FR-DEV%'");
  assert.equal(Number(n), 0);

  const upd = await t.call('PUT', `/quotes/${a.body.id}`, {
    token: chef,
    body: { clientId: ids.durand, siteId: ids.durandSite, title: 'Remplacement du compresseur', lines: [...lines, { description: 'Gaz', quantity: 2, unitPriceCents: 4_000, vatRateBp: 1000 }] },
  });
  assert.equal(upd.status, 200);
  assert.equal(upd.body.lines.length, 3);
  assert.equal(upd.body.netCents, 111_750 + 8_000);
});

test('devis : on ne peut pas viser un client hors de son périmètre', async () => {
  const res = await t.call('POST', '/quotes', { token: chef, body: { clientId: ids.lille, title: 'X', lines } });
  assert.equal(res.status, 403);
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('GET', '/quotes', { token: tech })).body.length, 0, 'un technicien ne voit pas les devis');
});

test('devis de travaux : envoi PDF, acceptation, intervention à planifier (une seule)', async () => {
  const { body: quote } = await t.call('POST', '/quotes', { token: chef, body: { clientId: ids.durand, siteId: ids.durandSite, title: 'Pose clim salle 2', lines } });
  t.mails.length = 0;
  const sent = await t.call('POST', `/quotes/${quote.id}/send`, { token: chef, body: {} });
  assert.equal(sent.status, 200);
  assert.equal(sent.body.status, 'SENT');
  assert.equal(t.mails.length, 1);
  assert.deepEqual(t.mails[0].to, ['cabinet.durand@client.test']);
  assert.match(t.mails[0].subject, /Devis FR-DEV-/);
  assert.equal(t.mails[0].attachments?.[0].content.subarray(0, 5).toString(), '%PDF-');

  // Plus modifiable une fois envoyé
  assert.equal((await t.call('PUT', `/quotes/${quote.id}`, { token: chef, body: { clientId: ids.durand, title: 'x', lines } })).status, 409);
  // Pas d'intervention avant acceptation
  assert.equal((await t.call('POST', `/quotes/${quote.id}/intervention`, { token: chef, body: {} })).status, 409);
  // Transition interdite
  assert.equal((await t.call('POST', `/quotes/${quote.id}/status`, { token: chef, body: { status: 'ACCEPTED' } })).status, 200);
  assert.equal((await t.call('POST', `/quotes/${quote.id}/status`, { token: chef, body: { status: 'DRAFT' } })).status, 409, 'un devis accepté reste accepté');

  const iv = await t.call('POST', `/quotes/${quote.id}/intervention`, { token: chef, body: { kind: 'INSTALLATION' } });
  assert.equal(iv.status, 201);
  const again = await t.call('POST', `/quotes/${quote.id}/intervention`, { token: chef, body: {} });
  assert.equal(again.body.id, iv.body.id, 'pas de doublon');
  const [row] = await t.sql<{ status: string; reason: string; quote_id: string }>('SELECT status, reason, quote_id FROM interventions WHERE id = $1', [iv.body.id]);
  assert.deepEqual(row, { status: 'TO_PLAN', reason: 'Pose clim salle 2', quote_id: quote.id });

  const pdf = await t.app.inject({ method: 'GET', url: `/api/quotes/${quote.id}/pdf`, headers: { authorization: `Bearer ${chef}` } });
  assert.equal(pdf.headers['content-type'], 'application/pdf');
});

test("contrat d'entretien : visites créées à l'avance, sans doublon, retirées si le contrat change", async () => {
  const start = addDays(today(), 10); // première visite dans 10 jours, puis tous les mois
  const res = await t.call('POST', '/contracts', {
    token: chef,
    body: { agencyId: ids.est, clientId: ids.durand, siteId: ids.durandSite, equipmentIds: [ids.durandEquipment], title: 'Entretien climatisation', frequencyMonths: 1, startDate: start, annualPriceCents: 48_000 },
  });
  assert.equal(res.status, 201);
  assert.match(res.body.number, /^FR-CTR-\d{4}-\d{5}$/);
  const expected = [start, addMonths(start, 1)].filter((d) => d <= addDays(today(), 60));
  assert.equal(res.body.visitsCreated, expected.length);

  const visits = await t.sql<{ due_date: string; status: string; kind: string; equipment_id: string; source: string }>(
    "SELECT to_char(due_date, 'YYYY-MM-DD') AS due_date, status, kind, equipment_id, source FROM interventions WHERE contract_id = $1 ORDER BY due_date", [res.body.id]);
  assert.deepEqual(visits.map((v) => v.due_date), expected);
  assert.ok(visits.every((v) => v.status === 'TO_PLAN' && v.kind === 'MAINTENANCE' && v.equipment_id === ids.durandEquipment && v.source === 'Contrat'));

  // Relancer la génération ne crée rien de plus
  assert.equal((await t.call('POST', `/contracts/${res.body.id}/generate`, { token: chef })).body.visitsCreated, 0);

  // Les visites apparaissent dans « à planifier », triées par échéance
  const toPlan = await t.call<{ contractId: string | null; dueDate: string | null }[]>('GET', `/interventions?agencyId=${ids.est}&status=TO_PLAN`, { token: chef });
  const fromContract = toPlan.body.filter((x) => x.contractId === res.body.id);
  assert.deepEqual(fromContract.map((x) => x.dueDate), expected);

  // Une visite planifiée ne bouge plus ; les autres sont retirées à la suspension
  const [first] = await t.sql<{ id: string }>('SELECT id FROM interventions WHERE contract_id = $1 ORDER BY due_date LIMIT 1', [res.body.id]);
  await t.sql("UPDATE interventions SET status = 'PLANNED' WHERE id = $1", [first.id]);
  const suspended = await t.call('PATCH', `/contracts/${res.body.id}`, { token: chef, body: { status: 'SUSPENDED' } });
  assert.equal(suspended.body.visitsRemoved, expected.length - 1);
  const left = await t.sql('SELECT id FROM interventions WHERE contract_id = $1', [res.body.id]);
  assert.deepEqual(left.map((r) => r.id), [first.id]);

  // Réactivation : les échéances manquantes reviennent
  const back = await t.call('PATCH', `/contracts/${res.body.id}`, { token: chef, body: { status: 'ACTIVE' } });
  assert.equal(back.body.visitsCreated, expected.length - 1);

  const detail = await t.call('GET', `/contracts/${res.body.id}`, { token: chef });
  assert.equal(detail.body.visits.length, expected.length);
  assert.equal(detail.body.equipments[0].serialNumber, 'SN-0001-A');
});

test('contrat : contrôles (site du client, matériel du site, dates, droits)', async () => {
  const base = { agencyId: ids.est, clientId: ids.durand, siteId: ids.durandSite, title: 'X', frequencyMonths: 12, startDate: today() };
  const [otherSite] = await t.sql<{ id: string }>("SELECT s.id FROM sites s JOIN clients c ON c.id = s.client_id WHERE c.name = 'Boulangerie Moreau'");
  assert.equal((await t.call('POST', '/contracts', { token: chef, body: { ...base, siteId: otherSite.id } })).status, 400);
  const [foreignEq] = await t.sql<{ id: string }>("SELECT id FROM equipments WHERE serial_number = 'SN-0003-C'");
  assert.equal((await t.call('POST', '/contracts', { token: chef, body: { ...base, equipmentIds: [foreignEq.id] } })).status, 400);
  assert.equal((await t.call('POST', '/contracts', { token: chef, body: { ...base, endDate: addDays(today(), -1) } })).status, 400);
  assert.equal((await t.call('POST', '/contracts', { token: chef, body: { ...base, agencyId: ids.nord } })).status, 403);
  const planner = await t.login('planning.est@exemple.test');
  assert.equal((await t.call('POST', '/contracts', { token: planner, body: base })).status, 403, 'le planificateur consulte seulement');
  assert.equal((await t.call('GET', '/contracts', { token: planner })).status, 200);
});

test('devis de contrat accepté → contrat avec le prix et la fréquence du devis', async () => {
  const { body: quote } = await t.call('POST', '/quotes', {
    token: chef,
    body: { clientId: ids.durand, siteId: ids.durandSite, kind: 'CONTRACT', contractFrequencyMonths: 6, title: 'Contrat entretien semestriel', lines: [{ description: '2 visites par an', quantity: 1, unitPriceCents: 36_000, vatRateBp: 2000 }] },
  });
  await t.call('POST', `/quotes/${quote.id}/send`, { token: chef, body: {} });
  await t.call('POST', `/quotes/${quote.id}/status`, { token: chef, body: { status: 'ACCEPTED' } });
  const start = addDays(today(), 5);
  const res = await t.call('POST', `/quotes/${quote.id}/contract`, { token: chef, body: { startDate: start } });
  assert.equal(res.status, 201);
  const detail = await t.call('GET', `/contracts/${res.body.id}`, { token: chef });
  assert.equal(detail.body.frequencyMonths, 6);
  assert.equal(detail.body.annualPriceCents, 36_000);
  assert.equal(detail.body.quote.number, quote.number);
  assert.equal(detail.body.visits.length, 1);
});
