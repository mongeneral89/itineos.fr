import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, TINY_JPEG, TINY_PNG, type TestContext } from './setup.js';

let t: TestContext;
let tech: string;
let id: string; // Cabinet Durand, climatisation (SAV, agence Est)
before(async () => {
  t = await startTestApp();
  tech = await t.login('tech1.est@exemple.test');
  [{ id }] = await t.sql<{ id: string }>("SELECT id FROM interventions WHERE reason = 'La climatisation ne démarre plus'");
});
after(async () => {
  await t.close();
});

test("« je suis sur place » envoyé plus tard garde l'heure réelle", async () => {
  const at = new Date(Date.now() - 45 * 60_000); // il y a 45 min, hors connexion
  assert.equal((await t.call('GET', `/interventions/${id}/report`, { token: tech })).status, 200);
  const res = await t.call('POST', `/interventions/${id}/status`, { token: tech, body: { status: 'ON_SITE', at: at.toISOString() } });
  assert.equal(res.status, 200);
  const [r] = await t.sql<{ arrived_at: Date }>('SELECT r.arrived_at FROM reports r WHERE r.intervention_id = $1', [id]);
  assert.equal(r.arrived_at.toISOString(), at.toISOString());
});

test('la fiche est pré-remplie avec le motif et le matériel', async () => {
  const { body } = await t.call('GET', `/interventions/${id}/report`, { token: tech });
  assert.equal(body.report.status, 'DRAFT');
  assert.equal(body.report.data.symptom, 'La climatisation ne démarre plus');
  assert.equal(body.report.data.equipmentSerial, 'SN-0001-A');
  assert.equal(body.canEdit, true);
});

test('photos : ajout, renvoi sans doublon, image refusée si ce n’en est pas une, légende, suppression', async () => {
  const clientId = '6f1d4c6e-1d3a-4b4f-9a43-2f0a3c1b7e01';
  const first = await t.call('POST', `/interventions/${id}/report/photos`, { token: tech, body: { clientId, kind: 'BEFORE', image: TINY_JPEG } });
  assert.equal(first.status, 201);
  const replay = await t.call('POST', `/interventions/${id}/report/photos`, { token: tech, body: { clientId, kind: 'BEFORE', image: TINY_JPEG } });
  assert.equal(replay.status, 200);
  assert.equal(replay.body.id, first.body.id);

  const svg = 'data:image/jpeg;base64,' + Buffer.from('<svg onload="alert(1)"/>').toString('base64');
  const fake = await t.call('POST', `/interventions/${id}/report/photos`, { token: tech, body: { clientId: '6f1d4c6e-1d3a-4b4f-9a43-2f0a3c1b7e02', kind: 'OTHER', image: svg } });
  assert.equal(fake.status, 400);

  const cap = await t.call('PATCH', `/interventions/${id}/report/photos/${first.body.id}`, { token: tech, body: { caption: 'Unité intérieure' } });
  assert.equal(cap.body.caption, 'Unité intérieure');

  const img = await t.app.inject({ method: 'GET', url: `/api/interventions/${id}/report/photos/${first.body.id}`, headers: { authorization: `Bearer ${tech}` } });
  assert.equal(img.statusCode, 200);
  assert.equal(img.headers['content-type'], 'image/jpeg');

  const extra = await t.call('POST', `/interventions/${id}/report/photos`, { token: tech, body: { clientId: '6f1d4c6e-1d3a-4b4f-9a43-2f0a3c1b7e03', kind: 'AFTER', image: TINY_JPEG } });
  assert.equal((await t.call('DELETE', `/interventions/${id}/report/photos/${extra.body.id}`, { token: tech })).status, 204);
  assert.equal((await t.call('DELETE', `/interventions/${id}/report/photos/${extra.body.id}`, { token: tech })).status, 204, 'suppression rejouée');

  const { body } = await t.call('GET', `/interventions/${id}/report`, { token: tech });
  assert.equal(body.photos.length, 1);

  // Quelqu'un d'une autre société ne voit pas l'image
  const uk = await t.login('tech.uk@exemple.test');
  const denied = await t.app.inject({ method: 'GET', url: `/api/interventions/${id}/report/photos/${first.body.id}`, headers: { authorization: `Bearer ${uk}` } });
  assert.notEqual(denied.statusCode, 200);
});

test('signature refusée tant que les champs obligatoires manquent, puis acceptée avec l’heure de l’appareil', async () => {
  const early = await t.call('POST', `/interventions/${id}/report/sign`, { token: tech, body: { technicianSignature: TINY_PNG, clientSignature: TINY_PNG, clientSignerName: 'Dr Durand' } });
  assert.equal(early.status, 400);
  assert.ok(early.body.details.missing.includes('Travaux réalisés'));

  const { body } = await t.call('GET', `/interventions/${id}/report`, { token: tech });
  const save = await t.call('PUT', `/interventions/${id}/report`, {
    token: tech,
    body: {
      data: { ...body.report.data, callType: 'Sous contrat', cause: 'Condensateur HS', work: 'Condensateur remplacé', champInconnu: 'ignoré' },
      outcome: 'DONE', laborMinutes: 50, parts: [{ label: 'Condensateur 35 µF', reference: 'CD-35', quantity: 1 }],
    },
  });
  assert.equal(save.status, 200);
  assert.equal('champInconnu' in save.body.report.data, false, 'seuls les champs du modèle sont gardés');

  const signedAt = new Date(Date.now() - 10 * 60_000);
  const sign = await t.call('POST', `/interventions/${id}/report/sign`, {
    token: tech,
    body: { technicianSignature: TINY_PNG, clientSignature: TINY_PNG, clientSignerName: 'Dr Durand', signedAt: signedAt.toISOString() },
  });
  assert.equal(sign.status, 200);
  assert.equal(new Date(sign.body.signedAt).toISOString(), signedAt.toISOString());

  // Fiche figée
  assert.equal((await t.call('PUT', `/interventions/${id}/report`, { token: tech, body: { data: {} } })).status, 409);
  const late = await t.call('POST', `/interventions/${id}/report/photos`, { token: tech, body: { clientId: '6f1d4c6e-1d3a-4b4f-9a43-2f0a3c1b7e04', kind: 'AFTER', image: TINY_JPEG } });
  assert.equal(late.status, 409);
  assert.equal((await t.call('POST', `/interventions/${id}/report/sign`, { token: tech, body: { technicianSignature: TINY_PNG, clientAbsent: true, clientAbsentReason: 'x' } })).status, 409);
});

test('envoi : PDF par e-mail, archivé, intervention terminée ; un envoi rejoué ne renvoie pas l’e-mail', async () => {
  t.mails.length = 0;
  const send = await t.call('POST', `/interventions/${id}/report/send`, { token: tech, body: { sendEmail: true } });
  assert.equal(send.status, 200);
  assert.deepEqual(send.body.sentTo, ['cabinet.durand@client.test']);
  assert.equal(t.mails.length, 1);
  const pdf = t.mails[0].attachments?.[0];
  assert.ok(pdf && pdf.filename.endsWith('.pdf'));
  assert.equal(pdf.content.subarray(0, 5).toString(), '%PDF-');

  const replay = await t.call('POST', `/interventions/${id}/report/send`, { token: tech, body: { sendEmail: true } });
  assert.equal(replay.status, 200);
  assert.equal(t.mails.length, 1, 'pas de second e-mail');

  const [iv] = await t.sql<{ status: string }>('SELECT status FROM interventions WHERE id = $1', [id]);
  assert.equal(iv.status, 'DONE');

  const dl = await t.app.inject({ method: 'GET', url: `/api/interventions/${id}/report/pdf`, headers: { authorization: `Bearer ${tech}` } });
  assert.equal(dl.statusCode, 200);
  assert.equal(dl.headers['content-type'], 'application/pdf');

  // Plus de « je pars » sur une intervention terminée : refus sans bloquer l'appli (409)
  assert.equal((await t.call('POST', `/interventions/${id}/status`, { token: tech, body: { status: 'EN_ROUTE' } })).status, 409);
});
