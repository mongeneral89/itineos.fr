import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
// Une APK est une archive ZIP : la signature suffit au contrôle du serveur
const APK = Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.alloc(2048, 7)]);
const MIME = 'application/vnd.android.package-archive';

before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
});
after(async () => {
  await t.close();
});

const publish = (token: string, query: string, payload: Buffer = APK) =>
  t.app.inject({ method: 'PUT', url: `/api/app/android?${query}`, headers: { authorization: `Bearer ${token}`, 'content-type': MIME }, payload });

test('l’appli Android se publie, se compare et se télécharge sans connexion', async () => {
  // Rien de publié : version 0, pas d'APK
  assert.deepEqual((await t.call('GET', '/app/android')).body, { versionCode: 0 });
  assert.equal((await t.app.inject({ method: 'GET', url: '/api/app/android.apk' })).statusCode, 404);

  // Seul un administrateur du groupe publie, et seulement une vraie APK
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await publish(tech, 'versionCode=10&versionName=v10')).statusCode, 403);
  assert.equal((await publish(admin, 'versionCode=10&versionName=v10', Buffer.from('pas une apk'))).statusCode, 400);

  const ok = await publish(admin, 'versionCode=10&versionName=2026.10.16-1200&notes=Onglets');
  assert.equal(ok.statusCode, 200);
  const info = (await t.call('GET', '/app/android')).body;
  assert.equal(info.versionCode, 10);
  assert.equal(info.notes, 'Onglets');
  assert.equal(info.size, APK.length);
  assert.equal(info.sha256, createHash('sha256').update(APK).digest('hex'));

  const dl = await t.app.inject({ method: 'GET', url: '/api/app/android.apk' });
  assert.equal(dl.statusCode, 200);
  assert.equal(dl.headers['content-type'], MIME);
  assert.ok(dl.rawPayload.equals(APK));

  // Pas de retour en arrière : le numéro doit augmenter
  assert.equal((await publish(admin, 'versionCode=10&versionName=bis')).statusCode, 400);
  assert.equal((await publish(admin, 'versionCode=11&versionName=v11')).statusCode, 200);
});
