import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
before(async () => {
  t = await startTestApp();
});
after(async () => {
  await t.close();
});

test('gestion des comptes : modifier, changer les droits, bloquer et débloquer', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const admin = await t.login('admin@exemple.test');
  const [tech] = await t.sql<{ id: string }>("SELECT id FROM users WHERE email = 'tech2.est@exemple.test'");
  const [est] = await t.sql<{ id: string; company_id: string }>("SELECT id, company_id FROM agencies WHERE code = 'EST'");
  const [me] = await t.sql<{ id: string }>("SELECT id FROM users WHERE email = 'chef.est@exemple.test'");
  const [adm] = await t.sql<{ id: string }>("SELECT id FROM users WHERE email = 'admin@exemple.test'");

  // La fiche donne tous les rôles et dit si on peut la modifier
  const card = await t.call('GET', `/users/${tech.id}`, { token: chef });
  assert.equal(card.status, 200);
  assert.equal(card.body.canEdit, true);
  assert.ok(card.body.roles.length >= 1);

  // Identité et téléphone
  assert.equal((await t.call('PATCH', `/users/${tech.id}`, { token: chef, body: { firstName: 'Jean-Marc', phone: '06 11 22 33 44', skills: ['Alarme'] } })).status, 200);
  const [row] = await t.sql<{ first_name: string; phone: string }>(`SELECT first_name, phone FROM users WHERE id = '${tech.id}'`);
  assert.equal(row.first_name, 'Jean-Marc');
  assert.equal(row.phone, '06 11 22 33 44');

  // Un technicien ne modifie pas les comptes
  const techToken = await t.login('tech2.est@exemple.test');
  assert.equal((await t.call('PATCH', `/users/${me.id}`, { token: techToken, body: { firstName: 'X' } })).status, 403);

  // Bloqué : sa session ouverte est refusée, et il ne peut plus se connecter
  assert.equal((await t.call('PATCH', `/users/${tech.id}`, { token: chef, body: { active: false } })).status, 200);
  assert.equal((await t.call('GET', '/me', { token: techToken })).status, 401);
  assert.equal((await t.call('POST', '/auth/login', { body: { email: 'tech2.est@exemple.test', password: 'demo1234' } })).status, 401);
  // Débloqué : il se reconnecte
  assert.equal((await t.call('PATCH', `/users/${tech.id}`, { token: chef, body: { active: true } })).status, 200);
  assert.ok(await t.login('tech2.est@exemple.test'));

  // Droits : le technicien devient aussi planificateur de l'agence
  const roles = [{ role: 'TECHNICIAN', companyId: est.company_id, agencyId: est.id }, { role: 'PLANNER', companyId: est.company_id, agencyId: est.id }];
  assert.equal((await t.call('PATCH', `/users/${tech.id}`, { token: chef, body: { assignments: roles } })).status, 200);
  const [{ n }] = await t.sql<{ n: string }>(`SELECT count(*) AS n FROM role_assignments WHERE user_id = '${tech.id}'`);
  assert.equal(Number(n), 2);
  // Un chef d'agence ne peut pas donner un rôle sur tout le groupe
  assert.equal((await t.call('PATCH', `/users/${tech.id}`, { token: chef, body: { assignments: [{ role: 'GROUP_ADMIN', companyId: null, agencyId: null }] } })).status, 403);

  // Pas soi-même : ni se bloquer, ni changer ses propres rôles
  assert.equal((await t.call('PATCH', `/users/${me.id}`, { token: chef, body: { active: false } })).status, 400);
  assert.equal((await t.call('PATCH', `/users/${me.id}`, { token: chef, body: { assignments: roles } })).status, 400);
  // Le dernier administrateur du groupe ne peut pas disparaître
  const [{ admins }] = await t.sql<{ admins: string }>("SELECT count(DISTINCT user_id) AS admins FROM role_assignments WHERE role = 'GROUP_ADMIN'");
  if (Number(admins) === 1) {
    const other = await t.call('PATCH', `/users/${adm.id}`, { token: admin, body: { firstName: 'Admin' } });
    assert.equal(other.status, 200);
  }
});
