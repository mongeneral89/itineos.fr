import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
before(async () => {
  t = await startTestApp();
});
after(async () => {
  await t.close();
});

test('connexion : bon mot de passe accepté, mauvais refusé avec le même message que pour un compte inconnu', async () => {
  const ok = await t.call('POST', '/auth/login', { body: { email: 'Chef.Est@exemple.test', password: 'demo1234' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.me.user.email, 'chef.est@exemple.test');

  const bad = await t.call('POST', '/auth/login', { body: { email: 'chef.est@exemple.test', password: 'faux' } });
  const unknown = await t.call('POST', '/auth/login', { body: { email: 'personne@exemple.test', password: 'faux' } });
  assert.equal(bad.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(bad.body.error, unknown.body.error);
});

test('les routes protégées exigent une session', async () => {
  assert.equal((await t.call('GET', '/me')).status, 401);
  assert.equal((await t.call('GET', '/me', { token: 'n-importe-quoi' })).status, 401);
  const token = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('GET', '/me', { token })).status, 200);
});

test("langue de l'interface : chacun choisit la sienne, parmi les langues proposées", async () => {
  const token = await t.login('tech1.est@exemple.test');
  const res = await t.call('PATCH', '/me', { token, body: { locale: 'en-GB' } });
  assert.equal(res.status, 200);
  assert.equal(res.body.user.locale, 'en-GB');
  assert.equal((await t.call('GET', '/me', { token })).body.user.locale, 'en-GB');
  assert.equal((await t.call('PATCH', '/me', { token, body: { locale: 'xx-YY' } })).status, 400);
  // Remis en français pour les autres tests
  assert.equal((await t.call('PATCH', '/me', { token, body: { locale: 'fr-FR' } })).status, 200);
});

test('mot de passe oublié : lien par e-mail, valable une fois, ferme les anciennes sessions', async () => {
  const oldSession = await t.login('compta.fr@exemple.test');
  t.mails.length = 0;

  // Compte inconnu : même réponse, aucun e-mail
  assert.equal((await t.call('POST', '/auth/forgot', { body: { email: 'inconnu@exemple.test' } })).status, 204);
  assert.equal((await t.call('POST', '/auth/forgot', { body: { email: 'compta.fr@exemple.test' } })).status, 204);
  // Deuxième demande rapprochée : pas de second e-mail
  assert.equal((await t.call('POST', '/auth/forgot', { body: { email: 'compta.fr@exemple.test' } })).status, 204);
  await new Promise((r) => setTimeout(r, 200)); // l'e-mail part sans bloquer la réponse
  assert.equal(t.mails.length, 1);
  assert.deepEqual(t.mails[0].to, ['compta.fr@exemple.test']);

  const link = /https:\/\/itineo\.test\/reset-password\?token=([\w-]+)/.exec(t.mails[0].text);
  assert.ok(link, "l'e-mail contient le lien vers l'appli");
  const token = decodeURIComponent(link[1]);

  // Le jeton n'est pas stocké en clair
  const stored = await t.sql<{ token_hash: string }>('SELECT token_hash FROM password_resets');
  assert.equal(stored.length, 1);
  assert.notEqual(stored[0].token_hash, token);

  assert.equal((await t.call('POST', '/auth/reset', { body: { token, password: 'court' } })).status, 400);
  assert.equal((await t.call('POST', '/auth/reset', { body: { token, password: 'Nouveau-mdp-2026' } })).status, 204);
  assert.equal((await t.call('POST', '/auth/reset', { body: { token, password: 'Encore-un-autre' } })).status, 400, 'lien déjà utilisé');

  // Ouverte moins d'une seconde avant : quand même fermée
  assert.equal((await t.call('GET', '/me', { token: oldSession })).status, 401, 'ancienne session fermée');
  assert.equal((await t.call('POST', '/auth/login', { body: { email: 'compta.fr@exemple.test', password: 'demo1234' } })).status, 401);
  await t.login('compta.fr@exemple.test', 'Nouveau-mdp-2026');
});

test('après 5 mauvais mots de passe, l’adresse est bloquée 15 min pour ce compte, même avec le bon mot de passe', async () => {
  const email = 'tech2.est@exemple.test';
  for (let i = 0; i < 5; i++) {
    assert.equal((await t.call('POST', '/auth/login', { body: { email, password: `faux-${i}` } })).status, 401);
  }
  const blocked = await t.app.inject({ method: 'POST', url: '/api/auth/login', payload: { email, password: 'demo1234' } });
  assert.equal(blocked.statusCode, 429);
  assert.match(blocked.json().error, /Réessayez dans 15 minutes/);
  assert.ok(Number(blocked.headers['retry-after']) > 800);

  // Le titulaire, depuis une autre adresse, n'est pas bloqué : connaître son e-mail ne suffit pas à l'empêcher d'entrer
  const owner = await t.app.inject({ method: 'POST', url: '/api/auth/login', remoteAddress: '198.51.100.7', payload: { email, password: 'demo1234' } });
  assert.equal(owner.statusCode, 200);

  // Les autres comptes ne sont pas touchés
  await t.login('tech.nord@exemple.test');
  const audit = await t.sql("SELECT 1 FROM audit_logs WHERE action = 'login.blocked'");
  assert.equal(audit.length, 1, 'le blocage est tracé');
});

test('mot de passe oublié : 5 demandes maximum par adresse en 15 min', async () => {
  // Ce fichier en a déjà fait 3 depuis la même adresse
  const statuses = [];
  for (let i = 0; i < 4; i++) statuses.push((await t.call('POST', '/auth/forgot', { body: { email: `x${i}@exemple.test` } })).status);
  assert.deepEqual(statuses, [204, 204, 429, 429]);
});

test('changement de mot de passe : ancien vérifié, autres sessions fermées, nouvelle session renvoyée', async () => {
  const other = await t.login('planning.est@exemple.test');
  const current = await t.login('planning.est@exemple.test');
  const wrong = await t.call('POST', '/auth/change-password', { token: current, body: { currentPassword: 'faux', newPassword: 'Planning-2026' } });
  assert.equal(wrong.status, 400);

  const ok = await t.call('POST', '/auth/change-password', { token: current, body: { currentPassword: 'demo1234', newPassword: 'Planning-2026' } });
  assert.equal(ok.status, 200);
  assert.equal((await t.call('GET', '/me', { token: other })).status, 401);
  assert.equal((await t.call('GET', '/me', { token: ok.body.token })).status, 200);

  const audit = await t.sql("SELECT action FROM audit_logs WHERE action LIKE 'password.%'");
  assert.ok(audit.some((a) => a.action === 'password.change'));
});
