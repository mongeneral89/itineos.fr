import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
let fr: { id: string };
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
  [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
});
after(async () => {
  await t.close();
});

test('le logo se dépose, s’affiche sans connexion, figure dans les PDF et se retire', async () => {
  assert.equal((await t.app.inject({ method: 'GET', url: `/api/logos/${fr.id}` })).statusCode, 404, 'pas encore de logo');

  // Un faux fichier est refusé ; un technicien ne peut pas changer le logo
  assert.equal((await t.call('PUT', `/org/companies/${fr.id}/logo`, { token: admin, body: { image: 'data:image/png;base64,AAAA' } })).status, 400);
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('PUT', `/org/companies/${fr.id}/logo`, { token: tech, body: { image: PNG } })).status, 403);

  const put = await t.call('PUT', `/org/companies/${fr.id}/logo`, { token: admin, body: { image: PNG } });
  assert.equal(put.status, 200);
  assert.ok(put.body.logoUpdatedAt);

  const img = await t.app.inject({ method: 'GET', url: `/api/logos/${fr.id}` });
  assert.equal(img.statusCode, 200);
  assert.equal(img.headers['content-type'], 'image/png');

  // La société envoyée au navigateur annonce le logo, sans dévoiler où il est rangé sur le serveur
  const org = await t.call('GET', '/org', { token: admin });
  const company = org.body.find((c: any) => c.id === fr.id);
  assert.ok(company.logoUpdatedAt);
  assert.equal('logoPath' in company, false);

  // Un devis avec logo se fabrique toujours
  const [quote] = await t.sql<{ id: string }>('SELECT id FROM quotes WHERE company_id = $1 LIMIT 1', [fr.id]);
  const pdf = await t.app.inject({ method: 'GET', url: `/api/quotes/${quote.id}/pdf`, headers: { authorization: `Bearer ${admin}` } });
  assert.equal(pdf.statusCode, 200);
  assert.equal(pdf.rawPayload.subarray(0, 4).toString(), '%PDF');

  // L'e-mail au client part aussi en version mise en forme, avec le logo en tête
  const before = t.mails.length;
  const sent = await t.call('POST', `/quotes/${quote.id}/send`, { token: admin, body: { to: ['client@exemple.test'] } });
  assert.equal(sent.status, 200, JSON.stringify(sent.body));
  const mail = t.mails.slice(before).find((m) => m.to.includes('client@exemple.test')) as any;
  assert.ok(mail?.html?.includes('cid:logo@itineo'), 'logo en tête de l’e-mail');
  assert.ok(mail.html.includes('Exemple Services France'));

  assert.equal((await t.call('DELETE', `/org/companies/${fr.id}/logo`, { token: admin })).status, 204);
  assert.equal((await t.app.inject({ method: 'GET', url: `/api/logos/${fr.id}` })).statusCode, 404);
});
