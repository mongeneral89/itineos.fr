import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
before(async () => {
  t = await startTestApp();
});
after(async () => {
  await t.close();
});

test('invitation d’un technicien : lien unique, mot de passe choisi, appli ouverte connectée', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const [est] = await t.sql<{ id: string; company_id: string }>("SELECT id, company_id FROM agencies WHERE code = 'EST'");

  // Compte créé sans mot de passe : personne ne peut s'y connecter avant l'invitation
  const created = await t.call('POST', '/users', {
    token: chef,
    body: { email: 'nouveau.tech@exemple.test', firstName: 'Léo', lastName: 'Nouveau', phone: '06 12 34 56 78', assignments: [{ role: 'TECHNICIAN', companyId: est.company_id, agencyId: est.id }] },
  });
  assert.equal(created.status, 201);
  const id = created.body.id as string;

  // Un technicien ne peut pas inviter
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('POST', `/users/${id}/invitation`, { token: tech })).status, 403);

  const first = await t.call('POST', `/users/${id}/invitation`, { token: chef });
  assert.equal(first.status, 200);
  assert.match(first.body.url, /\/invitation#[\w-]{20,}$/);
  // Un nouveau lien annule le précédent
  const inv = await t.call('POST', `/users/${id}/invitation`, { token: chef });
  const oldToken = first.body.url.split('#')[1];
  const token = inv.body.url.split('#')[1];
  assert.equal((await t.call('GET', `/invitations/${oldToken}`)).status, 400);

  const info = await t.call('GET', `/invitations/${token}`);
  assert.equal(info.status, 200);
  assert.equal(info.body.firstName, 'Léo');
  assert.equal(info.body.email, 'nouveau.tech@exemple.test');

  assert.equal((await t.call('POST', `/invitations/${token}/accept`, { body: { password: 'court' } })).status, 400);
  const accepted = await t.call('POST', `/invitations/${token}/accept`, { body: { password: 'MonMotDePasse1' } });
  assert.equal(accepted.status, 200);
  assert.ok(accepted.body.token);
  assert.equal(accepted.body.me.user.email, 'nouveau.tech@exemple.test');
  // Lien à usage unique
  assert.equal((await t.call('POST', `/invitations/${token}/accept`, { body: { password: 'AutreMotDePasse2' } })).status, 400);

  // L'appli s'ouvre connectée avec le code, une seule fois
  const app = await t.call('POST', '/invitations/app-login', { body: { code: accepted.body.appCode } });
  assert.equal(app.status, 200);
  assert.equal(app.body.me.user.email, 'nouveau.tech@exemple.test');
  assert.equal((await t.call('POST', '/invitations/app-login', { body: { code: accepted.body.appCode } })).status, 400);

  // Et le mot de passe choisi marche
  assert.ok(await t.login('nouveau.tech@exemple.test', 'MonMotDePasse1'));
});
