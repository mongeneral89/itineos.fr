import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
let fr: { id: string };
before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
  [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
});
after(async () => {
  await t.close();
});

const reportOf = async (reason: string, token: string) => {
  const [{ id }] = await t.sql<{ id: string }>('SELECT id FROM interventions WHERE reason = $1', [reason]);
  return (await t.call('GET', `/interventions/${id}/report`, { token })).body;
};

test('chaque société utilise le modèle neutre dans sa langue', async () => {
  const [uk] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'GB'");
  const list = await t.call<{ kind: string; inUse: boolean; schema: { lang: string } }[]>('GET', `/templates?companyId=${uk.id}`, { token: admin });
  assert.equal(list.status, 200);
  const used = list.body.filter((x) => x.inUse);
  assert.equal(used.length, 4, 'un modèle utilisé par type');
  assert.ok(used.every((x) => x.schema.lang === 'en'));
});

test("personnaliser un modèle : la société l'utilise pour les nouvelles fiches, pas pour celles déjà commencées", async () => {
  const tech = await t.login('tech1.est@exemple.test');
  // Une fiche SAV commencée AVANT la personnalisation
  const before = await reportOf('Four en défaut, code erreur E4', tech);
  const neutral = await t.call<{ id: string; kind: string; inUse: boolean; schema: any }[]>('GET', `/templates?companyId=${fr.id}`, { token: admin });
  const sav = neutral.body.find((x) => x.kind === 'SAV' && x.inUse)!;

  const schema = structuredClone(sav.schema);
  schema.sections[0].fields.push({ id: 'pression_bar', label: 'Pression relevée (bar)', type: 'number', required: true });
  const created = await t.call('POST', '/templates', { token: admin, body: { companyId: fr.id, name: 'SAV France', kind: 'SAV', schema } });
  assert.equal(created.status, 201);

  const after = await t.call<{ id: string; inUse: boolean; scope: string }[]>('GET', `/templates?companyId=${fr.id}`, { token: admin });
  assert.equal(after.body.find((x) => x.id === created.body.id)?.inUse, true);
  assert.equal(after.body.find((x) => x.id === created.body.id)?.scope, 'company');

  // Nouvelle fiche : nouveau modèle, avec le champ ajouté et le pré-remplissage conservé
  const fresh = await reportOf('La climatisation ne démarre plus', tech);
  const ids = fresh.report.templateSchema.sections.flatMap((s: any) => s.fields.map((f: any) => f.id));
  assert.ok(ids.includes('pression_bar'));
  assert.equal(fresh.report.data.symptom, 'La climatisation ne démarre plus');

  // Fiche déjà commencée : inchangée
  const again = await reportOf('Four en défaut, code erreur E4', tech);
  assert.deepEqual(again.report.templateSchema, before.report.templateSchema);

  // Le nouveau champ obligatoire est exigé à la signature
  const [{ id }] = await t.sql<{ id: string }>("SELECT id FROM interventions WHERE reason = 'La climatisation ne démarre plus'");
  const sign = await t.call('POST', `/interventions/${id}/report/sign`, { token: tech, body: { technicianSignature: 'data:image/png;base64,iVBORw0KGgo=', clientAbsent: true, clientAbsentReason: 'absent' } });
  assert.equal(sign.status, 400);
  assert.ok(sign.body.details.missing.includes('Pression relevée (bar)'));
});

test('modifier crée une nouvelle version ; retirer rend la main au modèle neutre', async () => {
  const list = await t.call<{ id: string; scope: string; version: number; schema: any }[]>('GET', `/templates?companyId=${fr.id}`, { token: admin });
  const mine = list.body.find((x) => x.scope === 'company')!;
  const v2 = await t.call('PUT', `/templates/${mine.id}`, { token: admin, body: { name: 'SAV France v2', schema: mine.schema } });
  assert.equal(v2.status, 200);
  assert.equal(v2.body.version, mine.version + 1);
  const [old] = await t.sql<{ active: boolean }>('SELECT active FROM form_templates WHERE id = $1', [mine.id]);
  assert.equal(old.active, false);

  assert.equal((await t.call('POST', `/templates/${v2.body.id}/archive`, { token: admin })).status, 200);
  const after = await t.call<{ kind: string; inUse: boolean; scope: string }[]>('GET', `/templates?companyId=${fr.id}`, { token: admin });
  assert.equal(after.body.find((x) => x.kind === 'SAV' && x.inUse)?.scope, 'system');
});

test('modèles invalides et droits', async () => {
  const bad = await t.call('POST', '/templates', {
    token: admin,
    body: { companyId: fr.id, name: 'X', kind: 'SAV', schema: { sections: [{ id: 's', title: 'S', fields: [{ id: 'a', label: 'A', type: 'select' }] }] } },
  });
  assert.equal(bad.status, 400);

  const dir = await t.login('direction.fr@exemple.test');
  const valid = { sections: [{ id: 's', title: 'S', fields: [{ id: 'a', label: 'A', type: 'text' }] }] };
  assert.equal((await t.call('POST', '/templates', { token: dir, body: { companyId: fr.id, name: 'X', kind: 'SAV', schema: valid } })).status, 403);
  assert.equal((await t.call('GET', `/templates?companyId=${fr.id}`, { token: dir })).status, 200, 'la direction peut consulter');

  const [uk] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'GB'");
  assert.equal((await t.call('GET', `/templates?companyId=${uk.id}`, { token: dir })).status, 403);
});
