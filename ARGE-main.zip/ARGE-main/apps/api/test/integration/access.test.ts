import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let ids: Record<string, string>;
before(async () => {
  t = await startTestApp();
  const rows = await t.sql<{ id: string; reason: string }>('SELECT id, reason FROM interventions');
  ids = Object.fromEntries(rows.map((r) => [r.reason, r.id]));
});
after(async () => {
  await t.close();
});

const durand = () => ids['La climatisation ne démarre plus']; // agence Est, technicien Julien Simon
const lille = () => ids['Détecteur en défaut']; // agence Nord
const london = () => ids['Server room unit not cooling']; // Royaume-Uni

test('un technicien ne voit que ses interventions', async () => {
  const julien = await t.login('tech1.est@exemple.test');
  const martin = await t.login('tech2.est@exemple.test');
  assert.equal((await t.call('GET', `/interventions/${durand()}`, { token: julien })).status, 200);
  assert.notEqual((await t.call('GET', `/interventions/${durand()}`, { token: martin })).status, 200);
  assert.notEqual((await t.call('GET', `/interventions/${durand()}/report`, { token: martin })).status, 200);

  const mine = await t.call<{ id: string }[]>('GET', '/interventions?mine=true', { token: julien });
  assert.equal(mine.status, 200);
  assert.ok(mine.body.length >= 4);
  assert.ok(!mine.body.some((i) => i.id === lille() || i.id === london()));
});

test("le chef d'agence Est ne voit ni l'agence Nord ni le Royaume-Uni", async () => {
  const chef = await t.login('chef.est@exemple.test');
  assert.equal((await t.call('GET', `/interventions/${durand()}`, { token: chef })).status, 200);
  assert.notEqual((await t.call('GET', `/interventions/${lille()}`, { token: chef })).status, 200);
  assert.notEqual((await t.call('GET', `/interventions/${london()}`, { token: chef })).status, 200);
});

test('la direction France voit toute la France mais pas le Royaume-Uni', async () => {
  const dir = await t.login('direction.fr@exemple.test');
  assert.equal((await t.call('GET', `/interventions/${lille()}`, { token: dir })).status, 200);
  assert.notEqual((await t.call('GET', `/interventions/${london()}`, { token: dir })).status, 200);
});

test("l'administrateur du groupe voit tout", async () => {
  const admin = await t.login('admin@exemple.test');
  for (const id of [durand(), lille(), london()]) {
    assert.equal((await t.call('GET', `/interventions/${id}`, { token: admin })).status, 200);
  }
});

test("la comptabilité peut lire mais pas remplir une fiche", async () => {
  const compta = await t.login('compta.fr@exemple.test');
  assert.equal((await t.call('GET', `/interventions/${durand()}`, { token: compta })).status, 200);
  const put = await t.call('PUT', `/interventions/${durand()}/report`, { token: compta, body: { data: {} } });
  assert.notEqual(put.status, 200);
});

test("on ne peut pas donner plus de droits qu'on en a", async () => {
  const chef = await t.login('chef.est@exemple.test');
  const [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  const res = await t.call('POST', '/users', {
    token: chef,
    body: { email: 'pirate@exemple.test', password: 'motdepasse', firstName: 'P', lastName: 'Irate', assignments: [{ role: 'GROUP_ADMIN', companyId: null, agencyId: null }] },
  });
  assert.equal(res.status, 403);
  assert.equal((await t.sql("SELECT 1 FROM users WHERE email = 'pirate@exemple.test'")).length, 0);
  assert.ok(fr);
});
