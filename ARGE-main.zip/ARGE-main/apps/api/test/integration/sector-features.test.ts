import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
let tech: string;
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
  tech = await t.login('tech1.est@exemple.test');
});
after(async () => {
  await t.close();
});

const sector = (s: string) => t.sql("UPDATE companies SET sector = $1 WHERE country_code = 'FR'", [s]);
const ivByReason = async (reason: string) => (await t.sql<{ id: string; site_id: string }>('SELECT id, site_id FROM interventions WHERE reason = $1', [reason]))[0];

test('Vigie : points de passage réservés au métier, pointés pendant la ronde, sans doublon ni point étranger', async () => {
  const iv = await ivByReason('Visite annuelle de la chaudière collective'); // ronde (MAINTENANCE), technicien tech1
  // Édition des techniciens : pas de points de passage
  assert.equal((await t.call('GET', `/sites/${iv.site_id}/checkpoints`, { token: admin })).status, 403);

  await sector('SECURITY');
  const a = await t.call('POST', `/sites/${iv.site_id}/checkpoints`, { token: admin, body: { name: 'Hall d’entrée' } });
  const b = await t.call('POST', `/sites/${iv.site_id}/checkpoints`, { token: admin, body: { name: 'Parking' } });
  assert.equal(a.status, 201);
  assert.match(a.body.code, /^ITN-CP-/);
  assert.equal((await t.call('POST', `/sites/${iv.site_id}/checkpoints`, { token: tech, body: { name: 'X' } })).status, 403, 'l’agent ne crée pas de point');

  const opened = await t.call('GET', `/interventions/${iv.id}/report`, { token: tech });
  assert.deepEqual(opened.body.checkpoints.map((c: any) => c.name), ['Hall d’entrée', 'Parking']);

  const at = new Date(Date.now() - 60_000).toISOString();
  const saved = await t.call('PUT', `/interventions/${iv.id}/report`, {
    token: tech,
    body: { checkpointScans: [
      { checkpointId: a.body.id, name: 'nom envoyé par l’appareil', at },
      { checkpointId: a.body.id, name: 'doublon', at: new Date().toISOString() },
      { checkpointId: '00000000-0000-0000-0000-000000000000', name: 'étranger', at },
    ] },
  });
  assert.equal(saved.status, 200);
  assert.deepEqual(saved.body.report.checkpointScans, [{ checkpointId: a.body.id, name: 'Hall d’entrée', at }]);

  // Point retiré : il n'est plus proposé
  await t.call('PATCH', `/checkpoints/${b.body.id}`, { token: admin, body: { active: false } });
  const again = await t.call('GET', `/interventions/${iv.id}/report`, { token: tech });
  assert.equal(again.body.checkpoints.length, 1);
  await sector('TECH');
});

test('Vigie : l’alerte SOS prévient les responsables de l’agent, par e-mail, avec sa position', async () => {
  assert.equal((await t.call('POST', '/alerts/sos', { token: tech, body: {} })).status, 403, 'pas de SOS chez les techniciens');
  await sector('SECURITY');
  const iv = await ivByReason('Four en défaut, code erreur E4');
  const before = t.mails.length;
  const res = await t.call('POST', '/alerts/sos', { token: tech, body: { lat: 48.6921, lng: 6.1844, accuracyM: 12, interventionId: iv.id } });
  assert.equal(res.status, 200);
  assert.ok(res.body.notified >= 2, 'chef d’agence, planificatrice, direction, administrateur');
  const sent = t.mails.slice(before).filter((m) => m.subject.includes('SOS'));
  assert.ok(sent.length >= 2);
  assert.match(sent[0].text, /48\.692100,6\.184400/);
  assert.match(sent[0].text, /Boulangerie Moreau/);
  const [log] = await t.sql<{ n: number }>("SELECT count(*)::int AS n FROM audit_logs WHERE action = 'sos'");
  assert.equal(log.n, 1);
  await sector('TECH');
});

test('Constat : chaque photo garde son heure de prise de vue et son empreinte SHA-256', async () => {
  await sector('BAILIFF');
  const iv = await ivByReason('La climatisation ne démarre plus');
  await t.call('GET', `/interventions/${iv.id}/report`, { token: tech });
  const takenAt = new Date(Date.now() - 3600_000).toISOString();
  const res = await t.call('POST', `/interventions/${iv.id}/report/photos`, {
    token: tech, body: { clientId: crypto.randomUUID(), kind: 'BEFORE', image: PNG, takenAt },
  });
  assert.equal(res.status, 201);
  const [row] = await t.sql<{ sha256: string; taken_at: Date }>('SELECT sha256, taken_at FROM report_photos WHERE id = $1', [res.body.id]);
  const expected = createHash('sha256').update(Buffer.from(PNG.split(',')[1], 'base64')).digest('hex');
  assert.equal(row.sha256, expected);
  assert.equal(row.taken_at.toISOString(), takenAt);
  await sector('TECH');
});

test('Clés : la sortie reprend l’état des lieux d’entrée du même logement, et le PDF se fabrique', async () => {
  await sector('RENTAL');
  // Entrée : une fiche signée sur le site de la Boulangerie Moreau (modèle d'entrée du métier)
  const exit = await ivByReason('Four en défaut, code erreur E4'); // SAV = sortie
  const [tpl] = await t.sql<{ id: string; schema: unknown }>("SELECT id, schema FROM form_templates WHERE sector = 'RENTAL' AND kind = 'INSTALLATION' AND schema->>'lang' = 'fr'");
  const [entry] = await t.sql<{ id: string }>(`INSERT INTO interventions (group_id, company_id, agency_id, number, client_id, site_id, kind, reason, status)
    SELECT group_id, company_id, agency_id, 'FR-TEST-ENTREE', client_id, site_id, 'INSTALLATION', 'Entrée', 'DONE' FROM interventions WHERE id = $1 RETURNING id`, [exit.id]);
  await t.sql(`INSERT INTO reports (intervention_id, template_id, template_schema, data, status, signed_at, outcome, technician_signature)
    VALUES ($1, $2, $3, $4, 'SENT', now() - interval '400 days', 'DONE', $5)`,
  [entry.id, tpl.id, tpl.schema, { roomKitchen: 'Bon état', meterElec: '1000', keys: '2 clés' }, PNG]);

  const opened = await t.call('GET', `/interventions/${exit.id}/report`, { token: tech });
  assert.equal(opened.status, 200);
  assert.equal(opened.body.checkin.number, 'FR-TEST-ENTREE');
  assert.equal(opened.body.checkin.data.roomKitchen, 'Bon état');
  const ids = opened.body.report.templateSchema.sections.flatMap((s: any) => s.fields.map((f: any) => f.id));
  assert.ok(ids.includes('damage'), 'modèle de sortie du métier');

  // Remplir, signer, envoyer : le PDF compare entrée et sortie
  await t.call('PUT', `/interventions/${exit.id}/report`, {
    token: tech,
    body: { outcome: 'DONE', data: { landlord: 'Bailleur', tenants: 'Locataire', keys: '1 clé', damage: 'Plaque de cuisson rayée', roomKitchen: 'Plaque rayée', meterElec: '1800' } },
  });
  const signed = await t.call('POST', `/interventions/${exit.id}/report/sign`, { token: tech, body: { technicianSignature: PNG, clientAbsent: true, clientAbsentReason: 'absent' } });
  assert.equal(signed.status, 200, JSON.stringify(signed.body));
  const sent = await t.call('POST', `/interventions/${exit.id}/report/send`, { token: tech, body: { sendEmail: false } });
  assert.equal(sent.status, 200);
  const pdf = await t.app.inject({ method: 'GET', url: `/api/interventions/${exit.id}/report/pdf`, headers: { authorization: `Bearer ${tech}` } });
  assert.equal(pdf.statusCode, 200);
  assert.equal(pdf.rawPayload.subarray(0, 4).toString(), '%PDF');
  await sector('TECH');
});

test('Services : le registre des traitements reprend les fiches anti-nuisibles signées', async () => {
  const [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  assert.equal((await t.call('GET', `/registers/treatments?companyId=${fr.id}`, { token: admin })).status, 403);
  await sector('SERVICES');
  const iv = await ivByReason('Entretien semestriel du four');
  await t.sql("UPDATE interventions SET kind = 'OTHER', technician_id = (SELECT id FROM users WHERE email = 'tech1.est@exemple.test') WHERE id = $1", [iv.id]);
  const opened = await t.call('GET', `/interventions/${iv.id}/report`, { token: tech });
  assert.ok(opened.body.report.templateSchema.sections.some((s: any) => s.fields.some((f: any) => f.id === 'biocides')));
  await t.call('PUT', `/interventions/${iv.id}/report`, {
    token: tech,
    body: { outcome: 'DONE', data: { pest: 'Rats / souris', zones: 'Réserve', biocides: 'Raticide, AMM FR-0001, 3 sachets', baitStations: 4 } },
  });
  assert.equal((await t.call('POST', `/interventions/${iv.id}/report/sign`, { token: tech, body: { technicianSignature: PNG, clientAbsent: true, clientAbsentReason: 'absent' } })).status, 200);

  const reg = await t.call('GET', `/registers/treatments?companyId=${fr.id}`, { token: admin });
  assert.equal(reg.status, 200);
  const line = reg.body.find((r: any) => r.interventionId === iv.id);
  assert.ok(line);
  assert.equal(line.biocides, 'Raticide, AMM FR-0001, 3 sachets');
  assert.equal(line.baitStations, 4);
  assert.equal((await t.call('GET', `/registers/treatments?companyId=${fr.id}`, { token: tech })).status, 403, 'pas pour le technicien');
  await sector('TECH');
});

test('Expertise : la date limite se saisit à la création et apparaît au tableau de bord', async () => {
  await sector('EXPERTISE');
  const [ctx] = await t.sql<{ company_id: string; agency_id: string; client_id: string; site_id: string }>(
    "SELECT company_id, agency_id, client_id, site_id FROM interventions WHERE reason = 'La climatisation ne démarre plus'");
  const created = await t.call('POST', '/interventions', {
    token: admin,
    body: { companyId: ctx.company_id, agencyId: ctx.agency_id, clientId: ctx.client_id, siteId: ctx.site_id, kind: 'SAV', reason: 'Sinistre test', dueDate: '2026-01-15' },
  });
  assert.equal(created.status, 201);
  assert.equal(created.body.dueDate, '2026-01-15');
  const dash = await t.call('GET', `/dashboard?companyId=${ctx.company_id}`, { token: admin });
  assert.ok(dash.body.deadlines.some((d: any) => d.id === created.body.id));
  await sector('TECH');
  const tech2 = await t.call('GET', `/dashboard?companyId=${ctx.company_id}`, { token: admin });
  assert.ok(!tech2.body.deadlines.some((d: any) => d.id === created.body.id), 'seulement pour l’édition Expertise');
});
