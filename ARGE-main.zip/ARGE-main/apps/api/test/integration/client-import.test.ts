import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let admin: string;
let fr: { id: string };
let est: { id: string };

const csv = (rows: string[][]) => 'data:text/csv;base64,' + Buffer.from(rows.map((r) => r.join(';')).join('\r\n')).toString('base64');

// Fichier type d'un installateur : une ligne par matériel, même client sur plusieurs lignes
const FILE = csv([
  ['Raison sociale', 'Code client', 'N° abonné', 'Adresse', 'CP', 'Ville', 'Contact', 'Site', 'Matériel', 'Marque', 'N° de série', 'Date de pose', 'Sous contrat'],
  ['Pharmacie des Tilleuls', 'C0042', 'TS-04512', '12 rue des Tilleuls', '21000', 'Dijon', 'Mme Martin', 'Pharmacie', 'Centrale intrusion', 'Marque A', '1A2B', '15/03/2021', 'oui'],
  ['Pharmacie des Tilleuls', 'C0042', 'TS-04512', '', '', '', 'Mme Martin', 'Pharmacie', 'Détecteur', 'Marque A', '5E6F', '15/03/2021', 'oui'],
  ['Pharmacie des Tilleuls', 'C0042', 'TS-09999', '', '', '', '', 'Entrepôt', 'Caméra', 'Marque B', 'CAM1', 'bientôt', 'non'],
  ['M. Durand', '', 'TS-07730', '4 impasse des Lilas', '21800', 'Quetigny', '', '', 'Caméra', 'Marque B', 'CAM2', '2023-09-02', ''],
  ['', '', '', '', '', '', '', '', 'Sirène', '', '', '', ''],
]);

before(async () => {
  t = await startTestApp();
  admin = await t.login('admin@exemple.test');
  [fr] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  [est] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'EST'");
});
after(async () => {
  await t.close();
});

test('import : aperçu sans rien enregistrer, puis import, puis réimport sans doublons', async () => {
  const body = { companyId: fr.id, agencyId: est.id, file: FILE };
  const before = (await t.sql<{ n: string }>('SELECT count(*) AS n FROM clients'))[0].n;

  const preview = await t.call('POST', '/clients/import/preview', { token: admin, body });
  assert.equal(preview.status, 200);
  const p = preview.body;
  assert.deepEqual(p.columns.map((c: any) => c.field), [
    'clientName', 'clientRef', 'subscriberNumber', 'address', 'postalCode', 'city', 'contactName', 'siteName',
    'category', 'brand', 'serialNumber', 'installedAt', 'underContract',
  ]);
  assert.equal(p.clientsNew, 2);
  assert.equal(p.sitesNew, 3, 'Pharmacie, Entrepôt, et le site principal de M. Durand');
  assert.equal(p.equipmentsNew, 4);
  assert.equal(p.contactsNew, 1);
  assert.equal(p.rowsSkipped, 1);
  assert.deepEqual(p.issues.map((i: any) => `${i.line}:${i.code}`).sort(), ['4:badDate', '4:otherSubscriber', '6:missingName']);
  assert.equal((await t.sql<{ n: string }>('SELECT count(*) AS n FROM clients'))[0].n, before, 'l’aperçu n’enregistre rien');

  const imported = await t.call('POST', '/clients/import', { token: admin, body });
  assert.equal(imported.status, 200);
  assert.deepEqual(imported.body, { clientsNew: 2, clientsUpdated: 0, sitesNew: 3, equipmentsNew: 4, contactsNew: 1 });

  const [pharma] = await t.sql<any>("SELECT * FROM clients WHERE external_ref = 'C0042'");
  assert.equal(pharma.subscriber_number, 'TS-04512');
  assert.equal(pharma.agency_id, est.id);
  const sites = await t.sql<any>('SELECT name, access_notes FROM sites WHERE client_id = $1 ORDER BY name', [pharma.id]);
  assert.deepEqual(sites.map((s: any) => s.name), ['Entrepôt', 'Pharmacie']);
  assert.match(sites[0].access_notes, /TS-09999/, 'le 2ᵉ n° d’abonné est noté sur son site');
  const [central] = await t.sql<any>("SELECT to_char(installed_at, 'YYYY-MM-DD') AS installed, under_contract FROM equipments WHERE serial_number = '1A2B'");
  assert.equal(central.under_contract, true);
  assert.equal(central.installed, '2021-03-15');

  // Réimport du même fichier : rien de nouveau
  const again = await t.call('POST', '/clients/import/preview', { token: admin, body });
  assert.equal(again.body.clientsNew, 0);
  assert.equal(again.body.clientsExisting, 2);
  assert.equal(again.body.sitesNew, 0);
  assert.equal(again.body.equipmentsNew, 0);
  assert.equal(again.body.equipmentsExisting, 4);
  assert.equal(again.body.contactsNew, 0);
  const second = await t.call('POST', '/clients/import', { token: admin, body });
  assert.deepEqual(second.body, { clientsNew: 0, clientsUpdated: 0, sitesNew: 0, equipmentsNew: 0, contactsNew: 0 });

  // Un matériel ajouté plus tard dans le fichier : seul lui est créé, sur le bon site
  const more = csv([
    ['Nom du client', 'N° abonné', 'Nom du site', 'Type de matériel', 'N° de série', 'E-mail'],
    ['pharmacie des tilleuls', 'TS-04512', 'Pharmacie', 'Clavier', 'KB1', 'pharma@exemple.test'],
  ]);
  const added = await t.call('POST', '/clients/import', { token: admin, body: { ...body, file: more } });
  assert.deepEqual(added.body, { clientsNew: 0, clientsUpdated: 1, sitesNew: 0, equipmentsNew: 1, contactsNew: 0 });
  const [updated] = await t.sql<any>('SELECT email FROM clients WHERE id = $1', [pharma.id]);
  assert.equal(updated.email, 'pharma@exemple.test', 'un champ vide est complété');
});

test('import : colonnes choisies à la main, droits, fichiers refusés', async () => {
  const file = csv([['A', 'B'], ['Garage Petit', 'X-1']]);
  // Titres inconnus : il faut choisir la colonne du nom
  assert.equal((await t.call('POST', '/clients/import/preview', { token: admin, body: { companyId: fr.id, file } })).status, 400);
  const ok = await t.call('POST', '/clients/import/preview', { token: admin, body: { companyId: fr.id, file, mapping: ['clientName', 'serialNumber'] } });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.clientsNew, 1);
  assert.equal(ok.body.equipmentsNew, 1);

  // Un technicien ne peut pas importer ; un fichier illisible est refusé
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('POST', '/clients/import/preview', { token: tech, body: { companyId: fr.id, agencyId: est.id, file } })).status, 403);
  assert.equal((await t.call('POST', '/clients/import/preview', { token: admin, body: { companyId: fr.id, file: 'pas un fichier' } })).status, 400);
  assert.equal((await t.call('POST', '/clients/import/preview', { token: admin, body: { companyId: fr.id, file: csv([['Nom']]) } })).status, 400);

  // Le modèle à remplir
  const tpl = await t.app.inject({ method: 'GET', url: '/api/clients/import/template', headers: { authorization: `Bearer ${admin}` } });
  assert.equal(tpl.statusCode, 200);
  assert.match(tpl.headers['content-type'] as string, /text\/csv/);
  assert.match(tpl.body, /Nom du client;Type;Code client;N° abonné/);
});
