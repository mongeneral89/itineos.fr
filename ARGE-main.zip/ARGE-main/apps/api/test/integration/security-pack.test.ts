import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let fr: string;
let est: { id: string };

before(async () => {
  t = await startTestApp();
  [{ id: fr }] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  [est] = await t.sql<{ id: string }>("SELECT id FROM agencies WHERE code = 'EST'");
});
after(async () => {
  await t.close();
});

test('pack installateur : ajouté une fois, fiches prises d’office, documents seulement sur choix', async () => {
  const admin = await t.login('admin@exemple.test');
  const added = await t.call('POST', '/templates/packs/security', { token: admin, body: { companyId: fr } });
  assert.equal(added.status, 200);
  assert.equal(added.body.added, 8);
  // Deuxième fois : rien n'est ajouté en double
  assert.equal((await t.call('POST', '/templates/packs/security', { token: admin, body: { companyId: fr } })).body.added, 0);

  const list = await t.call('GET', `/templates?companyId=${fr}`, { token: admin });
  const inUse = list.body.filter((x: any) => x.inUse).map((x: any) => `${x.kind}:${x.name}`).sort();
  assert.deepEqual(inUse, [
    'INSTALLATION:Fiche d’installation – alarme et vidéo',
    'MAINTENANCE:Fiche de maintenance – alarme et vidéo',
    'OTHER:Fiche de dépannage – alarme et vidéo',
    'SAV:Fiche de dépannage – alarme et vidéo',
  ]);
  const pv = list.body.find((x: any) => x.name === 'Procès-verbal de réception des travaux');
  assert.equal(pv.autoPick, false);
  assert.equal(pv.inUse, false);

  // Une nouvelle installation prend la fiche d'installation ; le PV se choisit sur l'intervention
  const [site] = await t.sql<{ id: string; client_id: string }>(
    'SELECT s.id, s.client_id FROM sites s JOIN clients c ON c.id = s.client_id WHERE c.company_id = $1 AND c.agency_id = $2 LIMIT 1', [fr, est.id]);
  const create = (templateId: string | null) => t.call('POST', '/interventions', { token: admin, body: {
    companyId: fr, agencyId: est.id, clientId: site.client_id, siteId: site.id, kind: 'INSTALLATION', reason: 'Pose d’une alarme', templateId,
  } });
  const plain = await create(null);
  assert.equal(plain.status, 201);
  const report = await t.call('GET', `/interventions/${plain.body.id}/report`, { token: admin });
  assert.equal(report.status, 200);
  assert.equal(report.body.report.templateSchema.sections[0].title, 'Installation');
  assert.equal(report.body.report.data.description, 'Pose d’une alarme', 'motif prérempli');

  const chosen = await create(pv.id);
  const pvReport = await t.call('GET', `/interventions/${chosen.body.id}/report`, { token: admin });
  assert.equal(pvReport.body.report.templateId, pv.id);

  // Une copie personnalisée du PV reste un document à choisir
  const copy = await t.call('PUT', `/templates/${pv.id}`, { token: admin, body: { schema: pv.schema, name: 'PV de réception – notre société' } });
  assert.equal(copy.status, 200);
  assert.equal(copy.body.autoPick, false);
});

test('pack installateur : droits et édition', async () => {
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('POST', '/templates/packs/security', { token: tech, body: { companyId: fr } })).status, 403);
  // Une société d'un autre métier (édition sécurité privée…) ne reçoit pas ce pack
  await t.sql("UPDATE companies SET sector = 'SECURITY' WHERE id = $1", [fr]);
  const admin = await t.login('admin@exemple.test');
  assert.equal((await t.call('POST', '/templates/packs/security', { token: admin, body: { companyId: fr } })).status, 400);
  await t.sql("UPDATE companies SET sector = 'TECH' WHERE id = $1", [fr]);
});
