/** Fonctions reprises de l'« App technicien admin » */
import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, TINY_PNG, type TestContext } from './setup.js';

let t: TestContext;
const ids: Record<string, string> = {};
let fr = '';
let sent: { userId: string; event: string; channel: string; notice: { title: string; body: string; url: string } }[] = [];
const wait = () => new Promise((r) => setTimeout(r, 150));

before(async () => {
  t = await startTestApp();
  for (const r of await t.sql<{ id: string; email: string }>('SELECT id, email FROM users')) ids[r.email] = r.id;
  fr = (await t.sql<{ id: string }>("SELECT id FROM companies WHERE document_prefix = 'FR'"))[0].id;
  // Après le démarrage : même module que le serveur de test
  sent = (await import('../../src/services/notify.js')).sentNotifications;
});
after(async () => {
  await t.close();
});

const payload = (token: string) => JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString());

test('rester connecté : session d’un an, prolongée ; « déconnecter tous mes appareils »', async () => {
  const short = await t.call('POST', '/auth/login', { body: { email: 'tech2.est@exemple.test', password: 'demo1234' } });
  const p1 = payload(short.body.token);
  assert.ok(p1.exp - p1.iat <= 12 * 3600, 'sans « Rester connecté » : 12 h');
  const long = await t.call('POST', '/auth/login', { body: { email: 'tech2.est@exemple.test', password: 'demo1234', remember: true } });
  const p2 = payload(long.body.token);
  assert.ok(p2.exp - p2.iat >= 364 * 86400, 'avec : un an');
  const renewed = await t.call('POST', '/auth/refresh', { token: long.body.token });
  assert.ok(renewed.body.token);
  assert.equal((await t.call('POST', '/auth/refresh', { token: short.body.token })).body.token, null, 'une session courte ne se prolonge pas');

  await new Promise((r) => setTimeout(r, 5));
  const out = await t.call('POST', '/auth/logout-all', { token: long.body.token });
  assert.equal(out.status, 200);
  assert.equal((await t.call('GET', '/me', { token: short.body.token })).status, 401, 'les autres appareils sont déconnectés');
  assert.equal((await t.call('GET', '/me', { token: renewed.body.token })).status, 401);
  assert.equal((await t.call('GET', '/me', { token: out.body.token })).status, 200, 'cet appareil reste connecté');
  assert.ok(payload(out.body.token).rem, 'et garde « Rester connecté »');
});

test('recherche client : sans accents, téléphone écrit autrement, n° de série, département, n° d’abonné', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const names = async (q: string) => (await t.call('GET', `/clients?${q}`, { token: chef })).body.map((c: { name: string }) => c.name);
  assert.ok((await names('q=LEFEVRE')).includes('M. et Mme Lefèvre'));
  assert.ok((await names(`q=${encodeURIComponent('+33 3 83 00')}&field=phone`)).includes('Cabinet Durand'));
  assert.ok((await names('q=03.83.00.00.01&field=phone')).includes('Cabinet Durand'));
  assert.ok((await names('dept=54')).every((n: string) => n !== 'Pharmacie du Beffroi'));
  const durand = (await t.sql<{ id: string }>("SELECT id FROM clients WHERE name = 'Cabinet Durand'"))[0].id;
  await t.call('PATCH', `/clients/${durand}`, { token: chef, body: { subscriberNumber: 'AB-5531' } });
  assert.deepEqual(await names('q=ab-5531&field=subscriber'), ['Cabinet Durand']);
  const [eqp] = await t.sql<{ serial_number: string }>("SELECT e.serial_number FROM equipments e JOIN sites s ON s.id = e.site_id WHERE s.client_id = $1 AND e.serial_number IS NOT NULL LIMIT 1", [durand]);
  if (eqp) assert.ok((await names(`q=${encodeURIComponent(eqp.serial_number.toLowerCase())}&field=serial`)).includes('Cabinet Durand'));
  assert.equal((await names('q=zzzzzz')).length, 0);
});

test('matériel difficile à repérer, « Y aller » et document « Consignes » choisi pour une intervention', async () => {
  const planner = await t.login('planning.est@exemple.test');
  const tech = await t.login('tech1.est@exemple.test');
  const [job] = await t.sql<{ id: string; site_id: string }>(
    "SELECT id, site_id FROM interventions WHERE technician_id = $1 AND status = 'PLANNED' ORDER BY scheduled_start LIMIT 1", [ids['tech1.est@exemple.test']]);
  const [eqp] = await t.sql<{ id: string }>('INSERT INTO equipments (site_id, category) VALUES ($1, $2) RETURNING id', [job.site_id, 'Détecteur de fumée']);
  const chef = await t.login('chef.est@exemple.test');
  assert.equal((await t.call('PATCH', `/equipments/${eqp.id}`, { token: chef, body: { category: 'Détecteur de fumée', locateHint: 'Dans le faux plafond du couloir' } })).status, 200);

  const day = await t.call('GET', `/interventions?technicianId=${ids['tech1.est@exemple.test']}`, { token: tech });
  const row = day.body.find((r: { id: string }) => r.id === job.id);
  assert.ok('siteAddress' in row && 'siteLat' in row, 'adresse du site pour « Y aller »');

  // Document : les consignes de télésurveillance, choisies avant que la fiche commence
  const templates = await t.call('GET', `/templates?companyId=${fr}`, { token: planner });
  const list = Array.isArray(templates.body) ? templates.body : templates.body.templates;
  const consignes = list.find((x: { name: string }) => x.name === 'Consignes de télésurveillance');
  assert.ok(consignes, 'modèle fourni avec Itinéos');
  assert.equal((await t.call('PATCH', `/interventions/${job.id}`, { token: planner, body: { templateId: consignes.id } })).status, 200);
  const report = await t.call('GET', `/interventions/${job.id}/report`, { token: tech });
  assert.equal(report.body.report.templateId, consignes.id);
  assert.ok(report.body.report.templateSchema.sections.some((s: { id: string }) => s.id === 'responsibles'));
  assert.ok(report.body.context.siteHints.some((h: { locateHint: string }) => h.locateHint === 'Dans le faux plafond du couloir'));
  assert.equal((await t.call('PATCH', `/interventions/${job.id}`, { token: planner, body: { templateId: null } })).status, 400, 'fiche commencée : document figé');

  // Le modèle par défaut ne devient jamais « Consignes » tout seul
  const [other] = await t.sql<{ id: string }>(
    "SELECT id FROM interventions WHERE technician_id = $1 AND kind = 'INSTALLATION' AND id <> $2 LIMIT 1", [ids['tech1.est@exemple.test'], job.id]);
  if (other) {
    const r2 = await t.call('GET', `/interventions/${other.id}/report`, { token: tech });
    assert.notEqual(r2.body.report.templateId, consignes.id);
  }
});

test('envoi de la fiche : copie au technicien et au bureau, le client répond au technicien', async () => {
  const tech = await t.login('tech1.est@exemple.test');
  const [job] = await t.sql<{ id: string }>(
    "SELECT id FROM interventions WHERE technician_id = $1 AND status = 'PLANNED' AND id NOT IN (SELECT intervention_id FROM reports) ORDER BY scheduled_start LIMIT 1", [ids['tech1.est@exemple.test']]);
  const opened = await t.call('GET', `/interventions/${job.id}/report`, { token: tech });
  const data: Record<string, unknown> = { ...opened.body.report.data };
  for (const s of opened.body.report.templateSchema.sections) for (const f of s.fields) {
    if (f.required) data[f.id] = f.type === 'select' ? f.options[0] : f.type === 'checklist' ? [f.options[0]] : 'Test';
  }
  await t.call('PUT', `/interventions/${job.id}/report`, { token: tech, body: { data, parts: [], outcome: 'DONE', laborMinutes: 30 } });
  const signed = await t.call('POST', `/interventions/${job.id}/report/sign`, { token: tech, body: { technicianSignature: TINY_PNG, clientSignature: TINY_PNG, clientSignerName: 'M. Client', clientAbsent: false } });
  assert.equal(signed.status, 200, JSON.stringify(signed.body));
  const before = t.mails.length;
  const res = await t.call('POST', `/interventions/${job.id}/report/send`, { token: tech, body: { to: ['client@exemple.test'], copyOffice: true } });
  assert.equal(res.status, 200, JSON.stringify(res.body));
  const mail = t.mails[t.mails.length - 1] as unknown as { to: string[]; bcc?: string[]; replyTo?: { address: string } };
  assert.equal(t.mails.length, before + 1);
  assert.deepEqual(mail.to, ['client@exemple.test']);
  assert.ok(mail.bcc?.includes('tech1.est@exemple.test'), 'copie au technicien');
  assert.ok(mail.bcc?.includes('est@exemple-services.test'), 'copie au bureau (adresse de l’agence)');
  assert.equal(mail.replyTo?.address, 'tech1.est@exemple.test');
});

test('planning de l’équipe : le bureau choisit ce que voit chaque technicien', async () => {
  const tech1 = await t.login('tech1.est@exemple.test');
  const tech2 = await t.login('tech2.est@exemple.test');
  const planner = await t.login('planning.est@exemple.test');
  const from = new Date(Date.now() - 7 * 86400_000).toISOString();
  const to = new Date(Date.now() + 14 * 86400_000).toISOString();
  const seen = async (token: string) => (await t.call('GET', `/team-planning?from=${from}&to=${to}`, { token })).body;

  let v = await seen(tech1);
  assert.equal(v.mode, 'OWN');
  assert.deepEqual(v.technicians.map((x: { id: string }) => x.id), [ids['tech1.est@exemple.test']], 'par défaut : seulement lui');
  assert.ok(v.jobs.every((j: { technicianId: string }) => j.technicianId === ids['tech1.est@exemple.test']));

  const list = await t.call('GET', `/planning-visibility?companyId=${fr}`, { token: planner });
  assert.ok(list.body.some((x: { id: string }) => x.id === ids['tech1.est@exemple.test']));
  assert.ok(!list.body.some((x: { id: string }) => x.id === ids['tech.nord@exemple.test']), 'seulement les techniciens qu’on planifie');

  assert.equal((await t.call('PUT', `/planning-visibility/${ids['tech1.est@exemple.test']}`, { token: tech2, body: { mode: 'AGENCY' } })).status, 403);
  await t.call('PUT', `/planning-visibility/${ids['tech1.est@exemple.test']}`, { token: planner, body: { mode: 'AGENCY' } });
  v = await seen(tech1);
  assert.ok(v.technicians.some((x: { id: string }) => x.id === ids['tech2.est@exemple.test']), 'toute son agence');
  assert.ok(!v.technicians.some((x: { id: string }) => x.id === ids['tech.nord@exemple.test']));
  assert.ok(v.technicians.find((x: { me: boolean }) => x.me).id === ids['tech1.est@exemple.test']);

  await t.call('PUT', `/planning-visibility/${ids['tech2.est@exemple.test']}`, { token: planner, body: { mode: 'CUSTOM', targetIds: [ids['tech1.est@exemple.test']] } });
  v = await seen(tech2);
  assert.deepEqual(v.technicians.map((x: { id: string }) => x.id).sort(), [ids['tech1.est@exemple.test'], ids['tech2.est@exemple.test']].sort());
  const job = v.jobs[0];
  if (job) assert.deepEqual(Object.keys(job).sort(), ['city', 'clientName', 'end', 'id', 'kind', 'number', 'priority', 'start', 'status', 'technicianId']);
});

test('notifications : abonnement, message, intervention attribuée, préférences et e-mail', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const tech = await t.login('tech2.est@exemple.test');
  const cfg = await t.call('GET', '/notifications/config', { token: tech });
  assert.ok(cfg.body.publicKey.length > 40);
  assert.equal(cfg.body.prefs.push_message, true);
  assert.equal(cfg.body.prefs.email_message, false);
  assert.equal((await t.call('POST', '/notifications/subscribe', { token: tech, body: { endpoint: 'http://pas-https.test/x', keys: { p256dh: 'x'.repeat(20), auth: 'y'.repeat(10) } } })).status, 400);
  assert.equal((await t.call('POST', '/notifications/subscribe', { token: tech, body: { endpoint: 'https://push.exemple.test/abc', keys: { p256dh: 'x'.repeat(20), auth: 'y'.repeat(10) } } })).status, 201);

  const conv = await t.call('POST', '/conversations', { token: chef, body: { userIds: [ids['tech2.est@exemple.test']] } });
  sent.length = 0;
  await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: chef, body: { body: 'Rappelle-moi' } });
  await wait();
  const push = sent.find((s) => s.userId === ids['tech2.est@exemple.test'] && s.channel === 'push');
  assert.ok(push, 'le destinataire est prévenu');
  assert.equal(push!.notice.body, 'Rappelle-moi');
  assert.equal(push!.notice.url, `/messages?c=${conv.body.id}`);
  assert.ok(!sent.some((s) => s.userId === ids['chef.est@exemple.test']), 'pas l’auteur');

  // Intervention attribuée par le bureau
  const [todo] = await t.sql<{ id: string }>("SELECT i.id FROM interventions i JOIN agencies a ON a.id = i.agency_id WHERE a.code = 'EST' AND i.status = 'TO_PLAN' LIMIT 1");
  sent.length = 0;
  await t.call('PATCH', `/interventions/${todo.id}`, { token: chef, body: { technicianId: ids['tech2.est@exemple.test'], scheduledStart: new Date(Date.now() + 86400_000).toISOString(), scheduledEnd: new Date(Date.now() + 90000_000).toISOString() } });
  await wait();
  const assigned = sent.find((s) => s.event === 'assignment');
  assert.equal(assigned?.notice.title, 'Nouvelle intervention');
  assert.equal(assigned?.notice.url, `/tech/${todo.id}`);

  // Préférences : plus de notification de message sur l'appareil, mais par e-mail
  await t.call('PATCH', '/notifications/prefs', { token: tech, body: { push_message: false, email_message: true } });
  sent.length = 0;
  const mails = t.mails.length;
  await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: chef, body: { body: 'Toujours là ?' } });
  await wait();
  assert.ok(!sent.some((s) => s.channel === 'push'));
  assert.ok(sent.some((s) => s.channel === 'email'));
  assert.equal(t.mails.length, mails + 1);
  assert.deepEqual(t.mails[t.mails.length - 1].to, ['tech2.est@exemple.test']);
});
