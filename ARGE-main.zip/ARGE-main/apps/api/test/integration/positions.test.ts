import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
let frId: string;
let ukId: string;
let kangooId: string;
before(async () => {
  t = await startTestApp();
  [{ id: frId }] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'FR'");
  [{ id: ukId }] = await t.sql<{ id: string }>("SELECT id FROM companies WHERE country_code = 'GB'");
  [{ id: kangooId }] = await t.sql<{ id: string }>("SELECT id FROM vehicles WHERE plate = 'AB-123-CD'");
});
after(async () => {
  await t.close();
});

const minutesAgo = (m: number) => new Date(Date.now() - m * 60_000).toISOString();

test("partage de position : rien n'est accepté tant que le technicien ne l'a pas activé lui-même", async () => {
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('PUT', '/me/location-sharing', { token: tech, body: { enabled: false } })).status, 200);
  const refused = await t.call('POST', '/fleet/positions', { token: tech, body: { positions: [{ lat: 48.69, lng: 6.18, recordedAt: minutesAgo(1) }] } });
  assert.equal(refused.status, 409);

  const on = await t.call('PUT', '/me/location-sharing', { token: tech, body: { enabled: true } });
  assert.equal(on.body.enabled, true);
  const state = await t.call('GET', '/me/location-sharing', { token: tech });
  assert.equal(state.body.enabled, true);
  assert.equal(state.body.vehicle.plate, 'AB-123-CD');
  assert.equal(state.body.retentionDays, 30);
  const logged = await t.sql("SELECT 1 FROM audit_logs WHERE action = 'location.enable'");
  assert.ok(logged.length >= 1, "l'activation est tracée");
});

test('positions envoyées : historique, dernière position du véhicule, intervention rattachée seulement si c’est la sienne', async () => {
  const tech = await t.login('tech1.est@exemple.test');
  const [mine] = await t.sql<{ id: string }>("SELECT i.id FROM interventions i JOIN users u ON u.id = i.technician_id WHERE u.email = 'tech1.est@exemple.test' LIMIT 1");
  const [other] = await t.sql<{ id: string }>("SELECT i.id FROM interventions i JOIN users u ON u.id = i.technician_id WHERE u.email = 'tech2.est@exemple.test' LIMIT 1");
  // On part d'un véhicule sans position (les données de démo en ont déjà une), partage activé depuis 2 h
  // (une position antérieure à l'activation est refusée : c'est vérifié dans les tests unitaires)
  await t.sql('UPDATE vehicles SET last_position_at = NULL, last_lat = NULL, last_lng = NULL WHERE id = $1', [kangooId]);
  await t.sql("UPDATE users SET location_sharing_since = now() - interval '2 hours' WHERE email = 'tech1.est@exemple.test'");
  const res = await t.call('POST', '/fleet/positions', {
    token: tech,
    body: {
      positions: [
        { lat: 48.6600, lng: 6.1700, accuracy: 10, recordedAt: minutesAgo(2), event: 'ON_SITE', interventionId: mine.id },
        { lat: 48.6500, lng: 6.1600, accuracy: 10, recordedAt: minutesAgo(10), event: 'EN_ROUTE', interventionId: other.id },
        { lat: 91, lng: 6.17, recordedAt: minutesAgo(5) },
      ],
    },
  });
  assert.equal(res.status, 200);
  assert.equal(res.body.stored, 2, 'la position impossible est écartée');
  assert.equal(res.body.vehicleId, kangooId);
  const [veh] = await t.sql<{ last_lat: number; last_lng: number }>('SELECT last_lat, last_lng FROM vehicles WHERE id = $1', [kangooId]);
  assert.deepEqual([veh.last_lat, veh.last_lng], [48.66, 6.17], 'la plus récente devient la dernière position');
  const rows = await t.sql<{ event: string; intervention_id: string | null }>(
    "SELECT event, intervention_id FROM vehicle_positions WHERE vehicle_id = $1 AND recorded_at > now() - interval '15 minutes' ORDER BY recorded_at", [kangooId]);
  assert.equal(rows.find((r) => r.event === 'ON_SITE')?.intervention_id, mine.id);
  assert.equal(rows.find((r) => r.event === 'EN_ROUTE')?.intervention_id, null, "l'intervention d'un autre technicien n'est pas rattachée");

  // Un lot ancien arrivé en retard ne fait pas reculer la dernière position
  await t.call('POST', '/fleet/positions', { token: tech, body: { positions: [{ lat: 48.70, lng: 6.20, recordedAt: minutesAgo(60) }] } });
  const [still] = await t.sql<{ last_lat: number }>('SELECT last_lat FROM vehicles WHERE id = $1', [kangooId]);
  assert.equal(still.last_lat, 48.66);
});

test("technicien sans véhicule : ses positions sont simplement ignorées", async () => {
  const tech = await t.login('tech.nord@exemple.test');
  await t.call('PUT', '/me/location-sharing', { token: tech, body: { enabled: true } });
  const res = await t.call('POST', '/fleet/positions', { token: tech, body: { positions: [{ lat: 50.63, lng: 3.06, recordedAt: minutesAgo(1) }] } });
  assert.equal(res.status, 200);
  assert.equal(res.body.stored, 0);
  assert.equal(res.body.vehicleId, null);
});

test('carte du parc : visible du bureau, avec le conducteur et ce qu’il fait ; pas pour les autres périmètres', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const map = await t.call('GET', `/fleet/map?companyId=${frId}`, { token: chef });
  assert.equal(map.status, 200);
  const kangoo = map.body.vehicles.find((x: { plate: string }) => x.plate === 'AB-123-CD');
  assert.ok(kangoo.lat && kangoo.lng && kangoo.positionAt);
  assert.equal(kangoo.driverFirstName, 'Julien');
  assert.equal(kangoo.sharing, true);
  assert.ok(kangoo.job, 'intervention du jour du conducteur');

  assert.equal((await t.call('GET', `/fleet/map?companyId=${ukId}`, { token: chef })).status, 403, "un chef d'agence ne voit pas le Royaume-Uni");
  const tech = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('GET', `/fleet/map?companyId=${frId}`, { token: tech })).status, 403, 'un technicien ne voit pas la carte');
});

test('trajet du jour : le bureau et le conducteur le voient, pas un autre technicien', async () => {
  const chef = await t.login('chef.est@exemple.test');
  const track = await t.call('GET', `/fleet/vehicles/${kangooId}/track`, { token: chef });
  assert.equal(track.status, 200);
  assert.ok(track.body.points.length >= 2);
  const times = track.body.points.map((p: { recordedAt: string }) => p.recordedAt);
  assert.deepEqual(times, [...times].sort(), 'dans l’ordre chronologique');
  assert.ok(track.body.days.includes(track.body.date));

  const driver = await t.login('tech1.est@exemple.test');
  assert.equal((await t.call('GET', `/fleet/vehicles/${kangooId}/track`, { token: driver })).status, 200);
  const otherTech = await t.login('tech2.est@exemple.test');
  assert.equal((await t.call('GET', `/fleet/vehicles/${kangooId}/track`, { token: otherTech })).status, 403);
});

test("effacement automatique : les positions de plus de 30 jours disparaissent", async () => {
  await t.sql("INSERT INTO vehicle_positions (vehicle_id, lat, lng, recorded_at) VALUES ($1, 48.6, 6.1, now() - interval '31 days')", [kangooId]);
  const { purgeOldPositions } = await import('../../src/services/positions.js');
  assert.ok((await purgeOldPositions()) >= 1);
  const old = await t.sql("SELECT 1 FROM vehicle_positions WHERE recorded_at < now() - interval '30 days'");
  assert.equal(old.length, 0);
});
