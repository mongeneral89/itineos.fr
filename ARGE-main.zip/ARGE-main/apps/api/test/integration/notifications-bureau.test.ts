import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { startTestApp, type TestContext } from './setup.js';

let t: TestContext;
// Chargés après le démarrage : la base de test est choisie par startTestApp
let notify: typeof import('../../src/services/notify.js');
let office: typeof import('../../src/services/office-notify.js');
let ids: Record<string, string>;

before(async () => {
  t = await startTestApp();
  notify = await import('../../src/services/notify.js');
  office = await import('../../src/services/office-notify.js');
  const rows = await t.sql<{ id: string; email: string }>("SELECT id, email FROM users WHERE email LIKE '%.est@exemple.test'");
  ids = Object.fromEntries(rows.map((r) => [r.email, r.id]));
});
after(async () => {
  await t.close();
});

const wait = () => new Promise((r) => setTimeout(r, 300));
// La cloche reçoit tout (le Web Push seulement les appareils abonnés) : on lit ce qu'elle a reçu depuis « since »
let since = new Date();
const mark = () => { since = new Date(); };
const sentTo = async (email: string, kind: string) => (await t.sql<{ title: string }>(
  `SELECT title FROM notifications WHERE user_id = '${ids[email]}' AND kind = '${kind}' AND created_at >= '${since.toISOString()}' ORDER BY created_at`,
)).map((r) => ({ notice: r }));

test('bureau et technicien : attribution, retard, retrait, annulation, fin d’intervention et cloche', async () => {
  const planner = await t.login('planning.est@exemple.test');
  const [todo] = await t.sql<{ id: string }>("SELECT i.id FROM interventions i JOIN agencies a ON a.id = i.agency_id WHERE a.code = 'EST' AND i.status = 'TO_PLAN' LIMIT 1");

  // Planifiée il y a 30 minutes pour tech2 : il est prévenu
  mark();
  const start = new Date(Date.now() - 30 * 60_000);
  const plan = await t.call('PATCH', `/interventions/${todo.id}`, { token: planner, body: { technicianId: ids['tech2.est@exemple.test'], scheduledStart: start.toISOString(), scheduledEnd: new Date(start.getTime() + 3600_000).toISOString() } });
  assert.equal(plan.status, 200);
  await wait();
  assert.equal((await sentTo('tech2.est@exemple.test', 'assignment'))[0]?.notice.title, 'Nouvelle intervention');

  // Pas parti 15 minutes après : la planification et le chef d'agence sont prévenus, une seule fois
  mark();
  // (les données d'essai ont d'autres interventions du jour déjà passées : elles sont signalées aussi)
  assert.ok(await office.notifyLateInterventions() >= 1);
  const [{ late }] = await t.sql<{ late: string | null }>(`SELECT late_notified_at AS late FROM interventions WHERE id = '${todo.id}'`);
  assert.ok(late, 'retard noté');
  assert.ok((await sentTo('planning.est@exemple.test', 'late')).length >= 1, 'qui a planifié');
  assert.ok((await sentTo('chef.est@exemple.test', 'late')).length >= 1, 'le chef de l’agence');
  assert.equal(await office.notifyLateInterventions(), 0, 'une seule fois');

  // Donnée à tech1 : tech2 apprend qu'elle lui est retirée, tech1 qu'elle est à lui
  mark();
  await t.call('PATCH', `/interventions/${todo.id}`, { token: planner, body: { technicianId: ids['tech1.est@exemple.test'] } });
  await wait();
  assert.equal((await sentTo('tech2.est@exemple.test', 'assignment'))[0]?.notice.title, 'Intervention retirée');
  assert.equal((await sentTo('tech1.est@exemple.test', 'assignment'))[0]?.notice.title, 'Nouvelle intervention');

  // Annulée : tech1 est prévenu
  mark();
  await t.call('PATCH', `/interventions/${todo.id}`, { token: planner, body: { status: 'CANCELLED' } });
  await wait();
  assert.equal((await sentTo('tech1.est@exemple.test', 'assignment'))[0]?.notice.title, 'Intervention annulée');

  // Fin d'intervention : qui l'a planifiée et le chef, pas le technicien qui l'a terminée
  const [iv] = await t.sql<Record<string, unknown>>(`SELECT id, number, agency_id AS "agencyId", company_id AS "companyId", client_id AS "clientId",
    technician_id AS "technicianId", planned_by_id AS "plannedById", created_by_id AS "createdById" FROM interventions WHERE id = '${todo.id}'`);
  assert.equal(iv.plannedById, ids['planning.est@exemple.test'], 'la planification est notée');
  mark();
  office.notifyCompleted(iv as never, false, ids['tech1.est@exemple.test']);
  await wait();
  assert.equal((await sentTo('planning.est@exemple.test', 'completed'))[0]?.notice.title, 'Intervention terminée');
  assert.equal((await sentTo('chef.est@exemple.test', 'completed')).length, 1);
  assert.equal((await sentTo('tech1.est@exemple.test', 'completed')).length, 0);

  // La cloche garde tout, et se vide quand on a lu
  const inbox = await t.call('GET', '/notifications/inbox', { token: planner });
  assert.ok(inbox.body.unread >= 2);
  assert.ok(inbox.body.items.some((n: { kind: string }) => n.kind === 'late'));
  assert.equal((await t.call('POST', '/notifications/read', { token: planner, body: { ids: [inbox.body.items[0].id] } })).status, 200);
  assert.equal((await t.call('GET', '/notifications/unread', { token: planner })).body.count, inbox.body.unread - 1);
  await t.call('POST', '/notifications/read', { token: planner, body: {} });
  assert.equal((await t.call('GET', '/notifications/unread', { token: planner })).body.count, 0);
});
