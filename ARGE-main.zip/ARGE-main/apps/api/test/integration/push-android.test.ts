import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { startTestApp, type TestContext } from './setup.js';

// Compte de service factice : pendant les tests, rien ne part vers Firebase (envois notés dans sentNotifications)
const dir = mkdtempSync(path.join(tmpdir(), 'fcm-'));
const file = path.join(dir, 'compte.json');
writeFileSync(file, JSON.stringify({ project_id: 'essai', client_email: 'essai@essai.iam.gserviceaccount.com', private_key: 'factice' }));
process.env.FCM_SERVICE_ACCOUNT_FILE = file;

let t: TestContext;
// Chargé après le démarrage : la base de test est choisie par startTestApp
let sent: (typeof import('../../src/services/notify.js'))['sentNotifications'];
before(async () => {
  t = await startTestApp();
  sent = (await import('../../src/services/notify.js')).sentNotifications;
});
after(async () => {
  await t.close();
});

const wait = () => new Promise((r) => setTimeout(r, 300));
const TOKEN = 'dAbC123:APA91b' + 'x'.repeat(140);

test('l’appli Android s’enregistre pour les notifications Firebase et les reçoit', async () => {
  const tech = await t.login('tech2.est@exemple.test');
  const chef = await t.login('chef.est@exemple.test');
  assert.equal((await t.call('GET', '/notifications/config', { token: tech })).body.appPush, true);

  assert.equal((await t.call('POST', '/notifications/device', { token: tech, body: { token: 'court' } })).status, 400);
  assert.equal((await t.call('POST', '/notifications/device', { token: tech, body: { token: 'pas un jeton <script>'.repeat(3) } })).status, 400);
  assert.equal((await t.call('POST', '/notifications/device', { token: tech, body: { token: TOKEN } })).status, 201);
  // Deux fois le même téléphone : un seul enregistrement
  assert.equal((await t.call('POST', '/notifications/device', { token: tech, body: { token: TOKEN } })).status, 201);
  const rows = await t.sql<{ n: string }>(`SELECT count(*) AS n FROM push_subscriptions WHERE endpoint = 'fcm:${TOKEN}'`);
  assert.equal(Number(rows[0].n), 1);

  const [{ id: techId }] = await t.sql<{ id: string }>("SELECT id FROM users WHERE email = 'tech2.est@exemple.test'");
  const conv = await t.call('POST', '/conversations', { token: chef, body: { userIds: [techId] } });
  sent.length = 0;
  await t.call('POST', `/conversations/${conv.body.id}/messages`, { token: chef, body: { body: 'Tu passes ?' } });
  await wait();
  assert.ok(sent.some((s) => s.userId === techId && s.channel === 'push' && s.notice.body === 'Tu passes ?'));

  // Déconnexion de l'appli : le téléphone ne reçoit plus rien
  assert.equal((await t.call('POST', '/notifications/device/remove', { token: tech, body: { token: TOKEN } })).status, 200);
  const left = await t.sql<{ n: string }>(`SELECT count(*) AS n FROM push_subscriptions WHERE endpoint = 'fcm:${TOKEN}'`);
  assert.equal(Number(left[0].n), 0);
});
