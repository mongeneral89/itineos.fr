import { test } from 'node:test';
import assert from 'node:assert/strict';
import { departmentWhere, normalize, phoneDigits } from '../src/services/client-search.js';
import { wants } from '../src/services/notify.js';
import { sessionStillValid, sessionVersion } from '../src/services/password.js';

test('recherche : accents, numéros de téléphone, départements', () => {
  assert.equal(normalize('  Lefèvre Œuvre ÇA '), 'lefevre oeuvre ca');
  assert.equal(phoneDigits('06 12 34 56 78'), '0612345678');
  assert.equal(phoneDigits('+33 6 12 34 56 78'), '0612345678');
  assert.equal(phoneDigits('0033 6.12.34'), '061234', 'indicatif écrit : même un début de numéro');
  assert.equal(phoneDigits('33612345678'), '0612345678');
  assert.ok(departmentWhere('54'));
  assert.ok(departmentWhere('2a'));
  assert.ok(departmentWhere('974'));
  assert.equal(departmentWhere('Nancy'), null);
});

test('notifications : sur l’appareil par défaut, par e-mail seulement si demandé', () => {
  assert.equal(wants({}, 'message', 'push'), true);
  assert.equal(wants({}, 'message', 'email'), false);
  assert.equal(wants({ push_message: false, email_assignment: true }, 'message', 'push'), false);
  assert.equal(wants({ push_message: false, email_assignment: true }, 'assignment', 'email'), true);
});

test('sessions : « déconnecter tous mes appareils » refuse les jetons plus anciens', () => {
  const pwd = new Date('2026-01-01T10:00:00Z');
  const revoked = new Date('2026-06-01T10:00:00Z');
  const before = sessionVersion(pwd, null);
  assert.equal(sessionStillValid(before, pwd, null), true);
  assert.equal(sessionStillValid(before, pwd, revoked), false);
  assert.equal(sessionStillValid(sessionVersion(pwd, revoked), pwd, revoked), true);
});
