import { test } from 'node:test';
import assert from 'node:assert/strict';
import { bicValid, creditorIdValid, directDebitXml, earliestCollectionDate, ibanValid, isWeekend, maskIban, sepaId, sepaText } from '../src/services/sepa.js';

// IBAN et ICS d'exemple publiés (documentation des banques et de la Banque de France)
const IBAN = 'FR76 3000 6000 0112 3456 7890 189';
const ICS = 'FR72ZZZ123456';

test('IBAN : clé de contrôle, longueur française, espaces et minuscules acceptés', () => {
  assert.ok(ibanValid(IBAN));
  assert.ok(ibanValid(IBAN.toLowerCase()));
  assert.ok(ibanValid('DE89 3704 0044 0532 0130 00'));
  assert.ok(!ibanValid('FR76 3000 6000 0112 3456 7890 188'), 'mauvaise clé');
  assert.ok(!ibanValid('FR76 3000 6000 0112 3456 7890'), 'trop court');
  assert.ok(!ibanValid('pas un iban'));
  assert.equal(maskIban(IBAN), 'FR76 •••• •••• 0189');
});

test('BIC et identifiant créancier SEPA', () => {
  assert.ok(bicValid('BNPAFRPP'));
  assert.ok(bicValid('bnpafrppxxx'));
  assert.ok(!bicValid('BNP'));
  assert.ok(creditorIdValid(ICS));
  assert.ok(!creditorIdValid('FR73ZZZ123456'), 'mauvaise clé');
});

test('textes du fichier : sans accent ni caractère refusé par les banques, longueur limitée', () => {
  assert.equal(sepaText('Société Électro & Fils — n° 12 « Lyon »', 70), 'Societe Electro Fils n 12 "Lyon"'.replace(/"/g, ' ').replace(/\s+/g, ' ').trim());
  assert.equal(sepaText('x'.repeat(200), 140).length, 140);
  assert.equal(sepaId('/FR-2026//00001/'), 'FR-2026/00001');
});

test('fichier pain.008 : en-tête, un bloc par type de prélèvement, totaux justes', () => {
  const out = directDebitXml({
    messageId: 'PRLV-20261105-1', createdAt: new Date('2026-11-01T10:00:00Z'), collectionDate: '2026-11-05',
    creditor: { name: 'Installateur Sécurité', iban: IBAN, bic: 'BNPAFRPP', creditorId: ICS },
    transactions: [
      { endToEndId: 'FR-2026-00010', amountCents: 3000, mandateRef: 'RUM-0001', mandateSignedOn: '2026-01-10', sequence: 'FRST', debtorName: 'Pharmacie des Tilleuls', debtorIban: 'DE89370400440532013000', debtorBic: null, remittance: 'Facture FR-2026-00010' },
      { endToEndId: 'FR-2026-00011', amountCents: 4550, mandateRef: 'RUM-0002', mandateSignedOn: '2025-03-01', sequence: 'RCUR', debtorName: 'M. Durand', debtorIban: IBAN, debtorBic: 'BNPAFRPP', remittance: 'Facture FR-2026-00011' },
      { endToEndId: 'FR-2026-00012', amountCents: 1000, mandateRef: 'RUM-0003', mandateSignedOn: '2025-03-01', sequence: 'RCUR', debtorName: 'Garage', debtorIban: IBAN, debtorBic: 'BNPAFRPP', remittance: 'Facture FR-2026-00012' },
    ],
  });
  assert.match(out, /^<\?xml version="1.0" encoding="UTF-8"\?>/);
  assert.match(out, /xmlns="urn:iso:std:iso:20022:tech:xsd:pain.008.001.02"/);
  assert.match(out, /<GrpHdr>[\s\S]*<NbOfTxs>3<\/NbOfTxs>\s*<CtrlSum>85.50<\/CtrlSum>/);
  assert.equal((out.match(/<PmtInf>/g) ?? []).length, 2);
  assert.match(out, /<SeqTp>FRST<\/SeqTp>[\s\S]*<CtrlSum>|<NbOfTxs>1<\/NbOfTxs>\s*<CtrlSum>30.00<\/CtrlSum>/);
  assert.match(out, /<NbOfTxs>2<\/NbOfTxs>\s*<CtrlSum>55.50<\/CtrlSum>/);
  assert.match(out, /<ReqdColltnDt>2026-11-05<\/ReqdColltnDt>/);
  assert.match(out, /<Id>FR72ZZZ123456<\/Id><SchmeNm><Prtry>SEPA<\/Prtry>/);
  assert.match(out, /<Nm>Installateur Securite<\/Nm>/, 'accents retirés');
  assert.match(out, /<IBAN>FR7630006000011234567890189<\/IBAN>/);
  assert.match(out, /<Othr><Id>NOTPROVIDED<\/Id><\/Othr>/, 'BIC du débiteur inconnu');
  assert.match(out, /<MndtId>RUM-0001<\/MndtId><DtOfSgntr>2026-01-10<\/DtOfSgntr>/);
});

test('date de prélèvement : deux jours après, jamais un samedi ni un dimanche', () => {
  assert.equal(earliestCollectionDate('2026-10-23'), '2026-10-26', 'vendredi → lundi');
  assert.equal(earliestCollectionDate('2026-10-26'), '2026-10-28', 'lundi → mercredi');
  assert.equal(earliestCollectionDate('2026-10-29'), '2026-11-02', 'jeudi → lundi');
  assert.ok(isWeekend('2026-10-25'));
  assert.ok(!isWeekend('2026-10-26'));
});
