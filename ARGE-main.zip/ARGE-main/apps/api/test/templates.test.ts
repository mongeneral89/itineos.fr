import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fieldIdFromLabel, INTERVENTION_KINDS, missingRequiredFields } from '@itineo/shared';
import { buildDefaultTemplate } from '../src/services/default-templates.js';
import { templateSchema } from '../src/services/template-schema.js';
import { buildPrefill, formatNumber, getPath, langOf, oneLineAddress } from '../src/services/prefill.js';

test('chaque type d’intervention a un modèle neutre en français et en anglais, sans champ en double', () => {
  for (const lang of ['fr', 'en'] as const) {
    for (const kind of INTERVENTION_KINDS) {
      const { name, schema } = buildDefaultTemplate(kind, lang);
      assert.ok(name.length > 0);
      assert.equal(schema.lang, lang);
      const ids = schema.sections.flatMap((s) => s.fields.map((f) => f.id));
      assert.equal(new Set(ids).size, ids.length, `doublon dans ${kind}/${lang}`);
      for (const f of schema.sections.flatMap((s) => s.fields)) {
        if (f.type === 'select' || f.type === 'checklist') assert.ok(f.options?.length, f.id);
      }
    }
  }
});

test("les modèles neutres respectent les règles de l'éditeur (on peut les copier tels quels)", () => {
  for (const lang of ['fr', 'en'] as const) {
    for (const kind of INTERVENTION_KINDS) {
      const res = templateSchema.safeParse(buildDefaultTemplate(kind, lang).schema);
      assert.ok(res.success, `${kind}/${lang} : ${res.success ? '' : res.error.issues.map((i) => i.message).join(', ')}`);
    }
  }
});

test("l'éditeur refuse un modèle incohérent", () => {
  const base = { sections: [{ id: 's', title: 'Section', fields: [{ id: 'a', label: 'A', type: 'text' as const }] }] };
  assert.equal(templateSchema.safeParse(base).success, true);
  const bad = (s: unknown) => templateSchema.safeParse(s).success;
  assert.equal(bad({ sections: [] }), false, 'aucune section');
  assert.equal(bad({ sections: [{ ...base.sections[0], fields: [] }] }), false, 'section vide');
  assert.equal(bad({ sections: [{ ...base.sections[0], fields: [{ id: 'c', label: 'C', type: 'select' }] }] }), false, 'choix manquants');
  assert.equal(bad({ sections: [{ ...base.sections[0], fields: [{ id: 'c', label: 'C', type: 'select', options: ['x', 'x'] }] }] }), false, 'choix en double');
  assert.equal(bad({ sections: [base.sections[0], { ...base.sections[0], id: 's2' }] }), false, 'champ en double');
  assert.equal(bad({ sections: [{ ...base.sections[0], fields: [{ id: 'a', label: 'A', type: 'text', prefill: 'client.passwordHash' }] }] }), false, 'pré-remplissage inconnu');
});

test("l'identifiant d'un champ est tiré de son libellé, sans doublon", () => {
  assert.equal(fieldIdFromLabel('N° de série', []), 'n_de_serie');
  assert.equal(fieldIdFromLabel('Pression (bar)', ['pression_bar']), 'pression_bar_2');
  assert.equal(fieldIdFromLabel('2e contrôle', []), 'f_2e_controle');
  assert.equal(fieldIdFromLabel('!!!', []), 'champ');
});

test('le pré-remplissage reprend le motif et le matériel', () => {
  const { schema } = buildDefaultTemplate('SAV', 'fr');
  const data = buildPrefill(schema, {
    intervention: { reason: 'Clim en panne' },
    equipment: { brand: 'Marque A', serialNumber: 'SN-1', model: null },
  });
  assert.equal(data.symptom, 'Clim en panne');
  assert.equal(data.equipmentBrand, 'Marque A');
  assert.equal(data.equipmentSerial, 'SN-1');
  assert.equal('equipmentModel' in data, false, 'une valeur vide ne doit pas être pré-remplie');
});

test('les champs obligatoires manquants sont détectés', () => {
  const { schema } = buildDefaultTemplate('SAV', 'fr');
  const missing = missingRequiredFields(schema, { symptom: 'x', callType: 'Facturable', cause: '' });
  assert.deepEqual(missing, ['Diagnostic et cause identifiée', 'Travaux réalisés']);
  assert.deepEqual(
    missingRequiredFields(schema, { symptom: 'x', callType: 'Facturable', cause: 'y', work: 'z' }),
    [],
  );
});

test('utilitaires', () => {
  assert.equal(getPath({ a: { b: 'c' } }, 'a.b'), 'c');
  assert.equal(getPath({ a: null }, 'a.b'), undefined);
  assert.equal(langOf('en-GB'), 'en');
  assert.equal(langOf(undefined), 'fr');
  assert.equal(oneLineAddress('1 rue', null, '', 'Nancy'), '1 rue, Nancy');
  assert.equal(formatNumber('FR', 2026, 42), 'FR-2026-00042');
});
