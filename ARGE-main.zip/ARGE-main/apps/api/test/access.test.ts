import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  can, canGrant, canReadIntervention, canWriteReport, isEmptyScope, scopeFor, type Principal,
} from '../src/auth/access.js';

const FR = 'company-fr';
const UK = 'company-uk';
const EST = 'agency-est';
const NORD = 'agency-nord';

const admin: Principal = { userId: 'u-admin', groupId: 'g', assignments: [{ role: 'GROUP_ADMIN', companyId: null, agencyId: null }] };
const directorFr: Principal = { userId: 'u-dir', groupId: 'g', assignments: [{ role: 'DIRECTOR', companyId: FR, agencyId: null }] };
const managerEst: Principal = { userId: 'u-chef', groupId: 'g', assignments: [{ role: 'AGENCY_MANAGER', companyId: FR, agencyId: EST }] };
const techEst: Principal = { userId: 'u-tech', groupId: 'g', assignments: [{ role: 'TECHNICIAN', companyId: FR, agencyId: EST }] };

test("l'administrateur du groupe voit toutes les sociétés", () => {
  assert.equal(can(admin, 'intervention.read', { companyId: UK, agencyId: 'x' }), true);
  assert.equal(scopeFor(admin, 'client.read').all, true);
});

test('la direction France voit toute la France, pas le Royaume-Uni', () => {
  assert.equal(can(directorFr, 'intervention.read', { companyId: FR, agencyId: NORD }), true);
  assert.equal(can(directorFr, 'intervention.read', { companyId: UK, agencyId: 'x' }), false);
});

test("le chef d'agence Est ne voit pas l'agence Nord", () => {
  assert.equal(can(managerEst, 'intervention.read', { companyId: FR, agencyId: EST }), true);
  assert.equal(can(managerEst, 'intervention.read', { companyId: FR, agencyId: NORD }), false);
});

test("les clients partagés de la société sont visibles par l'agence, mais pas modifiables", () => {
  const shared = { companyId: FR, agencyId: null };
  assert.equal(can(managerEst, 'client.read', shared, { sharedVisible: true }), true);
  assert.equal(can(managerEst, 'client.write', shared), false);
});

test('un technicien ne voit que ses propres interventions', () => {
  const mine = { companyId: FR, agencyId: EST, technicianId: 'u-tech' };
  const other = { companyId: FR, agencyId: EST, technicianId: 'u-autre' };
  assert.equal(canReadIntervention(techEst, mine), true);
  assert.equal(canReadIntervention(techEst, other), false);
  assert.equal(canWriteReport(techEst, mine), true);
  assert.equal(canWriteReport(techEst, other), false);
});

test("un technicien affecté ailleurs ne voit rien hors de son agence, même s'il est désigné", () => {
  const elsewhere = { companyId: FR, agencyId: NORD, technicianId: 'u-tech' };
  assert.equal(canReadIntervention(techEst, elsewhere), false);
});

test('les périmètres de liste sont corrects', () => {
  const f = scopeFor(managerEst, 'intervention.read');
  assert.deepEqual(f, { all: false, companyIds: [], agencyIds: [EST], agencyCompanyIds: [FR] });
  assert.equal(isEmptyScope(scopeFor(techEst, 'dashboard.read')), true);
});

test("on ne peut pas donner plus de droits qu'on en a", () => {
  assert.equal(canGrant(managerEst, { role: 'TECHNICIAN', companyId: FR, agencyId: EST }), true);
  assert.equal(canGrant(managerEst, { role: 'TECHNICIAN', companyId: FR, agencyId: NORD }), false);
  assert.equal(canGrant(managerEst, { role: 'GROUP_ADMIN', companyId: null, agencyId: null }), false);
  assert.equal(canGrant(managerEst, { role: 'DIRECTOR', companyId: FR, agencyId: null }), false);
  assert.equal(canGrant(admin, { role: 'DIRECTOR', companyId: UK, agencyId: null }), true);
});
