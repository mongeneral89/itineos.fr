import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { inflateRawSync } from 'node:zlib';
import { facturxWarnings, facturxXml, ibanOf, sirenOf, type FacturxInput } from '../src/services/facturx.js';
import { generateInvoicePdf } from '../src/services/document-pdf.js';
import { createZip, crc32 } from '../src/services/zip.js';
import { depositInvoice, flowStatus, readStatus, statusLabel, testPlatform } from '../src/services/einvoice.js';

const base: FacturxInput = {
  kind: 'INVOICE', number: 'FR-F-2026-0001', issueDate: '2026-10-22', serviceDate: '2026-10-20', dueDate: '2026-11-21',
  currency: 'EUR', title: 'Dépannage climatisation', operationType: 'SERVICES', vatOnDebits: false,
  seller: { name: 'Exemple Services', siren: '123 456 789', vatNumber: 'FR12123456789', address: '1 rue A', postalCode: '54000', city: 'Nancy', countryCode: 'FR', bankDetails: 'IBAN FR76 3000 6000 0112 3456 7890 189 – BIC AGRIFRPP' },
  buyer: { name: 'Cabinet Durand', siren: '98765432100012', vatNumber: 'FR99987654321', address: '12 rue des Lilas', postalCode: '54500', city: 'Vandœuvre', countryCode: 'FR' },
  delivery: null,
  lines: [
    { description: 'Main-d’œuvre', quantity: 1.5, unit: 'h', unitPriceCents: 6000, vatRateBp: 2000 },
    { description: 'Condensateur 35 µF', quantity: 1, unit: 'u', unitPriceCents: 1850, vatRateBp: 2000 },
    { description: 'Déplacement', quantity: 1, unit: 'forfait', unitPriceCents: 3500, vatRateBp: 1000 },
  ],
};

const tag = (xml: string, name: string) => [...xml.matchAll(new RegExp(`<ram:${name}[^>]*>([^<]*)</ram:${name}>`, 'g'))].map((m) => m[1]);

test('Factur-X : en-tête, totaux, TVA par taux et mentions françaises', () => {
  const xml = facturxXml(base);
  assert.match(xml, /<ram:ID>urn:cen\.eu:en16931:2017<\/ram:ID>/);
  assert.match(xml, /<ram:ID>S1<\/ram:ID>/, 'cadre de facturation : services');
  assert.equal(tag(xml, 'TypeCode')[0], '380');
  assert.deepEqual(tag(xml, 'LineTotalAmount').slice(0, 3), ['90.00', '18.50', '35.00']);
  // 108,50 € à 20 % (21,70) + 35 € à 10 % (3,50)
  assert.deepEqual(tag(xml, 'BasisAmount'), ['108.50', '35.00']);
  assert.deepEqual(tag(xml, 'CalculatedAmount'), ['21.70', '3.50']);
  assert.equal(tag(xml, 'GrandTotalAmount')[0], '168.70');
  assert.equal(tag(xml, 'DuePayableAmount')[0], '168.70');
  assert.match(xml, /<ram:ID schemeID="0002">123456789<\/ram:ID>/, 'SIREN du vendeur');
  assert.match(xml, /<ram:ID schemeID="0002">987654321<\/ram:ID>/, 'SIREN tiré du SIRET du client');
  assert.match(xml, /<ram:IBANID>FR7630006000011234567890189<\/ram:IBANID>/);
  assert.match(xml, /<ram:BilledQuantity unitCode="HUR">1\.5<\/ram:BilledQuantity>/);
  for (const code of ['PMT', 'PMD', 'AAB']) assert.match(xml, new RegExp(`<ram:SubjectCode>${code}</ram:SubjectCode>`));
  assert.match(xml, /<ram:DueDateTypeCode>72<\/ram:DueDateTypeCode>/, 'TVA à l’encaissement pour des services');
  assert.doesNotMatch(xml, /Vandœuvre.*&(?!amp;|lt;|gt;|quot;)/);
});

test('Factur-X : avoir, remise, déjà payé, TVA sur les débits, lieu d’intervention', () => {
  const xml = facturxXml({
    ...base, kind: 'CREDIT_NOTE', creditedNumber: 'FR-F-2026-0001', vatOnDebits: true, operationType: 'MIXED',
    delivery: { name: 'Agence Toul', address: '3 place B', postalCode: '54200', city: 'Toul' },
    lines: [...base.lines, { description: 'Remise fidélité', quantity: 1, unit: null, unitPriceCents: -1000, vatRateBp: 2000 }],
  });
  assert.equal(tag(xml, 'TypeCode')[0], '381');
  assert.match(xml, /<ram:ID>M1<\/ram:ID>/);
  assert.match(xml, /<ram:InvoiceReferencedDocument><ram:IssuerAssignedID>FR-F-2026-0001<\/ram:IssuerAssignedID>/);
  // Remise : prix positif, quantité négative (règle BR-27)
  assert.match(xml, /<ram:ChargeAmount>10\.00<\/ram:ChargeAmount><\/ram:NetPriceProductTradePrice><\/ram:SpecifiedLineTradeAgreement><ram:SpecifiedLineTradeDelivery><ram:BilledQuantity unitCode="C62">-1<\/ram:BilledQuantity>/);
  assert.match(xml, /<ram:DueDateTypeCode>5<\/ram:DueDateTypeCode>/);
  assert.match(xml, /<ram:SubjectCode>TXD<\/ram:SubjectCode>/);
  assert.match(xml, /<ram:ShipToTradeParty><ram:Name>Agence Toul<\/ram:Name>/);
  assert.doesNotMatch(xml, /<ram:DueDateDateTime>/, 'pas d’échéance sur un avoir');

  const paid = facturxXml({ ...base, paidCents: 5000 });
  assert.equal(tag(paid, 'TotalPrepaidAmount')[0], '50.00');
  assert.equal(tag(paid, 'DuePayableAmount')[0], '118.70');
});

test('Factur-X : TVA à 0 % = exonération motivée ; SIREN et IBAN lus dans le texte saisi', () => {
  const xml = facturxXml({ ...base, lines: [{ description: 'Entretien', quantity: 1, unit: null, unitPriceCents: 9000, vatRateBp: 0 }] });
  assert.match(xml, /<ram:CategoryCode>E<\/ram:CategoryCode>/);
  assert.match(xml, /<ram:ExemptionReason>TVA non applicable, art\. 293 B du CGI<\/ram:ExemptionReason>/);
  assert.equal(sirenOf('123 456 789 00012'), '123456789');
  assert.equal(sirenOf('12345'), null);
  assert.equal(ibanOf('Banque X\nIBAN : FR76 1234 5678 9012 3456 7890 123'), 'FR7612345678901234567890123');
  assert.equal(ibanOf('Chèque à l’ordre de…'), null);
});

test('Factur-X : ce qui manque est signalé', () => {
  const w = facturxWarnings({ seller: { name: 'X', siren: null, vatNumber: null }, buyer: { name: 'Y', siren: null, countryCode: 'FR' }, buyerIsCompany: true });
  assert.equal(w.length, 4);
  assert.deepEqual(facturxWarnings({ seller: base.seller, buyer: base.buyer, buyerIsCompany: true }), []);
  // Particulier : pas de SIREN demandé
  assert.equal(facturxWarnings({ seller: base.seller, buyer: { ...base.buyer, siren: null }, buyerIsCompany: false }).length, 0);
});

test('PDF de facture : PDF/A-3 avec le XML Factur-X joint', async () => {
  const xml = facturxXml(base);
  const pdf = await generateInvoicePdf({
    locale: 'fr-FR', currency: 'EUR',
    company: { name: 'Exemple Services', countryCode: 'FR', legalMentions: 'SAS au capital de 1 000 €' },
    client: { name: 'Cabinet Durand', address: '12 rue des Lilas 54500 Vandœuvre' }, site: null,
    invoice: { kind: 'INVOICE', number: base.number, title: base.title, notes: null, issueDate: base.issueDate, serviceDate: null, dueDate: base.dueDate, creditedNumber: null, paidCents: 0 },
    lines: base.lines, facturxXml: xml,
  });
  const raw = pdf.toString('latin1');
  assert.match(raw, /%PDF-1\.7/);
  assert.match(raw, /factur-x\.xml/);
  assert.match(raw, /\/AFRelationship \/Data/);
  assert.match(raw, /<pdfaid:part>3<\/pdfaid:part>/);
  assert.match(raw, /<fx:ConformanceLevel>EN 16931<\/fx:ConformanceLevel>/);
  assert.match(raw, /\/OutputIntents/);
});

test('archive .zip : fichiers retrouvés à l’identique', () => {
  const files = [{ name: 'F-1.pdf', data: Buffer.from('premier') }, { name: 'é-2.pdf', data: Buffer.from('deuxième fichier') }];
  const zip = createZip(files);
  // Relecture du répertoire central
  const end = zip.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  assert.equal(zip.readUInt16LE(end + 10), 2);
  let p = zip.readUInt32LE(end + 16);
  for (const f of files) {
    const nameLen = zip.readUInt16LE(p + 28);
    assert.equal(zip.toString('utf8', p + 46, p + 46 + nameLen), f.name);
    assert.equal(zip.readUInt32LE(p + 16), crc32(f.data));
    const local = zip.readUInt32LE(p + 42);
    const start = local + 30 + zip.readUInt16LE(local + 26);
    assert.deepEqual(zip.subarray(start, start + f.data.length), f.data);
    p += 46 + nameLen;
  }
  assert.equal(crc32(Buffer.from('123456789')), 0xcbf43926);
  assert.ok(inflateRawSync); // (stockés sans compression)
});

test('plateforme agréée : dépôt, suivi du statut, jeton refusé', async () => {
  const seen: { method: string; url: string; auth?: string; body: string }[] = [];
  const server = createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      seen.push({ method: req.method!, url: req.url!, auth: req.headers.authorization, body });
      res.setHeader('Content-Type', 'application/json');
      if (req.headers.authorization !== 'Bearer bon-jeton') return res.writeHead(401).end('{"message":"invalid token"}');
      if (req.method === 'POST' && req.url === '/api/v1/flows') return res.writeHead(201).end('{"flowId":"FLOW-42","status":"200"}');
      if (req.url === '/api/v1/flows/FLOW-42') return res.writeHead(200).end('{"flowId":"FLOW-42","lifecycleStatus":{"code":"205"}}');
      if (req.url?.startsWith('/api/v1/flows?')) return res.writeHead(200).end('[]');
      return res.writeHead(404).end('{}');
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  const port = (server.address() as { port: number }).port;
  const cfg = { url: `http://127.0.0.1:${port}/api/`, token: 'bon-jeton' };
  try {
    await testPlatform(cfg);
    const r = await depositInvoice(cfg, Buffer.from('%PDF-1.7 factur-x.xml'), { invoiceId: 'abc', number: 'F-1' });
    assert.deepEqual(r, { flowId: 'FLOW-42', status: '200' });
    const dep = seen.find((s) => s.method === 'POST')!;
    assert.match(dep.body, /"flowSyntax":"Factur-X"/);
    assert.match(dep.body, /filename="F-1\.pdf"/);
    assert.equal(await flowStatus(cfg, 'FLOW-42'), '205');
    assert.equal(statusLabel('205'), 'Approuvée');
    await assert.rejects(testPlatform({ ...cfg, token: 'mauvais' }), /refuse le jeton/);
  } finally {
    server.close();
  }
  assert.equal(readStatus({ status: 'ACCEPTED' }), 'ACCEPTED');
  assert.equal(readStatus(null), null);
});
