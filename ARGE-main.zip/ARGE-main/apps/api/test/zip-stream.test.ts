import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ZipStream } from '../src/services/zip.js';
import { unzip } from '../src/services/import-table.js';

async function build(files: [string, string, boolean][]) {
  const chunks: Buffer[] = [];
  const zip = new ZipStream(async (c) => {
    chunks.push(c);
  });
  for (const [name, text, compress] of files) await zip.add(name, Buffer.from(text), compress);
  const size = await zip.finish();
  const out = Buffer.concat(chunks);
  assert.equal(size, out.length);
  return out;
}

test('archive écrite au fur et à mesure : fichiers stockés et compressés, noms accentués', async () => {
  const zip = await build([
    ['donnees/clients.csv', 'Nom;Ville\r\nPharmacie;Dijon\r\n'.repeat(50), true],
    ['fiches/FR-2026-00001.pdf', '%PDF-1.4', false],
    ['LISEZ-MOI.txt', 'Données exportées', true],
  ]);
  const files = unzip(zip);
  assert.deepEqual([...files.keys()], ['donnees/clients.csv', 'fiches/FR-2026-00001.pdf', 'LISEZ-MOI.txt']);
  assert.equal(files.get('fiches/FR-2026-00001.pdf')!().toString(), '%PDF-1.4');
  assert.equal(files.get('LISEZ-MOI.txt')!().toString(), 'Données exportées');
  assert.match(files.get('donnees/clients.csv')!().toString(), /^Nom;Ville/);
});

test('plus de 65 535 fichiers : répertoire ZIP64 ajouté', async () => {
  const chunks: Buffer[] = [];
  const zip = new ZipStream(async (c) => {
    chunks.push(c);
  });
  const n = 65_540;
  for (let i = 0; i < n; i++) await zip.add(`p/${i}.jpg`, Buffer.from([i & 0xff]));
  await zip.finish();
  const out = Buffer.concat(chunks);
  const end = out.length - 22;
  assert.equal(out.readUInt32LE(end), 0x06054b50);
  assert.equal(out.readUInt16LE(end + 10), 0xffff, 'le nombre est dans le répertoire ZIP64');
  const locator = end - 20;
  assert.equal(out.readUInt32LE(locator), 0x07064b50);
  const rec = Number(out.readBigUInt64LE(locator + 8));
  assert.equal(out.readUInt32LE(rec), 0x06064b50);
  assert.equal(Number(out.readBigUInt64LE(rec + 32)), n);
});
