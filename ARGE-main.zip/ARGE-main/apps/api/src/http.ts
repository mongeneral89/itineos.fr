/** Erreur HTTP : Fastify renvoie automatiquement le bon code de statut. */
export class HttpError extends Error {
  constructor(public statusCode: number, message: string, public details?: unknown) {
    super(message);
  }
}

export const notFound = (what = 'Élément') => new HttpError(404, `${what} introuvable`);
export const forbidden = (msg = "Vous n'avez pas les droits pour cette action") => new HttpError(403, msg);
export const badRequest = (msg: string, details?: unknown) => new HttpError(400, msg, details);
export const conflict = (msg: string) => new HttpError(409, msg);

/** Adresse pour le journal : les jetons d'activation ou de réinitialisation (?token=…) n'y sont jamais écrits */
export function redactUrl(url: string): string {
  return url.replace(/([?&]token=)[^&#]*/gi, '$1[masqué]');
}
