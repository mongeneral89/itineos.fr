/**
 * Les documents papier d'A.R.G.E., repris en modèles de fiches (dossier « docs viere arge ») :
 *  - FICHE D'INTERVENTION TECHNIQUE (2025)       → fiche par défaut de toutes les interventions
 *  - CONSIGNES DE TELESURVEILLANCE (Teles, 2025) → document à choisir sur l'intervention
 *  - DOSSIER TECHNIQUE – BON DE SORTIE (télésurveillance et vidéo) → partie administrative du dossier ;
 *    le matériel sorti est saisi dans les pièces de la fiche (catalogue : voir catalogue.ts)
 *
 * Les heures d'arrivée et de départ, le technicien, le client, le matériel posé et les deux signatures sont déjà
 * gérés par toutes les fiches : ils ne sont pas répétés ici.
 */
import type { InterventionKind, TemplateField, TemplateSchema } from '@itineo/shared';

const yesNo = ['Oui', 'Non'];
const AGENCIES_STOCK = ['21 – Dijon', '54 – Nancy', '59 – Lille', '77 – Fontainebleau'];

/** FICHE D'INTERVENTION TECHNIQUE */
export const interventionSheet: TemplateSchema = {
  lang: 'fr',
  sections: [
    {
      id: 'call',
      title: 'Appel et intervenants',
      fields: [
        { id: 'callDate', label: 'Date de l’appel du client', type: 'date' },
        { id: 'subject', label: 'Objet de l’intervention', type: 'textarea', prefill: 'intervention.reason', dictation: true, required: true },
        { id: 'tech2', label: 'Technicien n° 2', type: 'text', help: 'Si deux techniciens interviennent' },
        { id: 'tech2Arrival', label: 'Technicien n° 2 : heure d’arrivée', type: 'time' },
        { id: 'tech2Departure', label: 'Technicien n° 2 : heure de départ', type: 'time' },
        { id: 'secondArrival', label: 'Deuxième passage : heure d’arrivée', type: 'time' },
        { id: 'secondDeparture', label: 'Deuxième passage : heure de départ', type: 'time' },
      ],
    },
    {
      id: 'subscriber',
      title: 'Abonné',
      fields: [
        { id: 'oldSubscriber', label: 'Ancien n° d’abonné', type: 'text', prefill: 'client.subscriberNumber' },
        { id: 'newSubscriber', label: 'Nouveau n° d’abonné', type: 'text' },
        { id: 'managerEmail', label: 'Adresse e-mail du responsable', type: 'text', prefill: 'client.email' },
      ],
    },
    {
      id: 'equipment',
      title: 'Matériel',
      fields: [
        { id: 'onSite', label: 'Matériel sur place', type: 'text', prefill: 'equipment.category' },
        { id: 'installedOn', label: 'Installé le', type: 'date' },
        { id: 'stockFrom', label: 'Sortie de stock', type: 'select', options: AGENCIES_STOCK, help: 'Le détail du matériel (réf., quantité) se saisit dans les pièces de la fiche' },
        { id: 'newOrUsed', label: 'Matériel posé', type: 'select', options: ['Neuf', 'Occasion', 'Neuf et occasion'] },
        { id: 'serial', label: 'N° de série', type: 'text', prefill: 'equipment.serialNumber' },
        { id: 'remote', label: 'Option connexion à distance activée', type: 'checkbox' },
        { id: 'transmission', label: 'Transmission', type: 'select', options: ['Analogique', 'WIP', 'GSM'] },
        { id: 'p2p', label: 'P2P vidéo', type: 'text' },
        { id: 'stickers', label: 'Nombre d’autocollants posés', type: 'number' },
      ],
    },
    {
      id: 'observation',
      title: 'Observation',
      fields: [
        { id: 'followUp', label: 'Suites à donner', type: 'checklist', options: ['Matériel à commander', 'Devis à faire', 'Action commerciale', 'Prochain SAV à prévoir', 'Divers'] },
        { id: 'orderRef', label: 'Matériel à commander : références', type: 'text' },
        { id: 'nextVisit', label: 'Prochain SAV : temps prévu et nombre de techniciens', type: 'text' },
        { id: 'misc', label: 'Divers', type: 'text' },
      ],
    },
    {
      id: 'remarks',
      title: 'Remarque(s) sur la visite de l’installation',
      fields: [
        { id: 'remarks', label: 'Remarques', type: 'textarea', dictation: true },
      ],
    },
  ],
};

/** CONSIGNES DE TELESURVEILLANCE (à transmettre à Teles, le centre de télésurveillance) */
export function monitoringInstructions(): TemplateSchema {
  const contacts: TemplateField[] = [];
  for (let i = 1; i <= 6; i++) {
    contacts.push(
      { id: `resp${i}Name`, label: `Responsable ${i} : nom, prénom, fonction`, type: 'text' },
      { id: `resp${i}Password`, label: `Responsable ${i} : mot de passe`, type: 'text' },
      { id: `resp${i}Phone`, label: `Responsable ${i} : téléphone`, type: 'text' },
      { id: `resp${i}When`, label: `Responsable ${i} : clé, jour, nuit, week-end`, type: 'checklist', options: ['Clé', 'Jour', 'Nuit', 'Week-end'] },
    );
  }
  const days = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche', 'jours fériés'];
  return {
    lang: 'fr',
    sections: [
      {
        id: 'site',
        title: 'Site',
        fields: [
          { id: 'prom', label: 'N° de PROM', type: 'text', prefill: 'client.subscriberNumber', required: true },
          { id: 'siteName', label: 'Nom du site', type: 'text', prefill: 'site.name' },
          { id: 'siteManager', label: 'Responsable', type: 'text' },
          { id: 'siteAddress', label: 'Adresse, code postal, ville', type: 'text', prefill: 'site.fullAddress' },
          { id: 'sitePhone', label: 'Téléphone', type: 'text', prefill: 'client.phone' },
          { id: 'siteEmail', label: 'E-mail', type: 'text', prefill: 'client.email' },
          { id: 'sitePassword', label: 'Mot de passe', type: 'text' },
          { id: 'siteType', label: 'Type de site', type: 'select', required: true, options: ['Résidence principale', 'Résidence secondaire', 'Professionnel'] },
        ],
      },
      {
        id: 'transmitter',
        title: 'Transmetteur',
        fields: [
          { id: 'model', label: 'Modèle du transmetteur', type: 'text', prefill: 'equipment.model' },
          { id: 'backup', label: 'Secours de transmission', type: 'text' },
          { id: 'protocol', label: 'Protocole de transmission', type: 'text' },
        ],
      },
      {
        id: 'onSiteCalls',
        title: 'A – Appel(s) sur place',
        fields: [
          { id: 'onSiteCall1', label: 'N° 1', type: 'text' },
          { id: 'onSiteCall2', label: 'N° 2', type: 'text' },
        ],
      },
      { id: 'contacts', title: 'B – Responsables (dans l’ordre inscrit)', fields: contacts },
      {
        id: 'companies',
        title: 'C, D – Intervenants',
        fields: [
          { id: 'responder', label: 'C – Nom de la société d’intervention', type: 'text' },
          { id: 'installer', label: 'D – Nom de l’installateur', type: 'text', prefill: 'company.name' },
        ],
      },
      {
        id: 'alarms',
        title: 'Informations reçues à gérer',
        fields: [
          {
            id: 'handled', label: 'À gérer (ordre d’appel : A sur place, B responsable, C intervenant, D installateur)', type: 'checklist',
            options: [
              'Alarme intrusion', 'Alarme autoprotection', 'Absence de test cyclique', 'Défaut secteur 220 V',
              'Défaut tension batterie', 'Défaut technique', 'Alarme agression', 'Alarme incendie', 'Alarme assistance',
              'Absence de mise en service', 'Mise hors service non autorisée',
            ],
          },
          { id: 'mainsHours', label: 'Défaut secteur 220 V : appel', type: 'select', options: ['De 8 h à 21 h', '24 h / 24'] },
          { id: 'batteryHours', label: 'Défaut tension batterie : appel', type: 'select', options: ['De 8 h à 21 h', '24 h / 24'] },
          { id: 'orderChanges', label: 'Modification de l’ordre d’appel', type: 'textarea' },
        ],
      },
      {
        id: 'options',
        title: 'Options',
        fields: [
          { id: 'delegation', label: 'Le client donne délégation au PC de télésurveillance pour prendre des mesures conservatoires', type: 'select', options: yesNo },
          { id: 'guarding', label: 'Gardiennage du site si sinistre ou effraction constatée (selon disponibilités)', type: 'select', options: yesNo },
          { id: 'patrol', label: 'Ronde de sécurité', type: 'select', options: yesNo },
          { id: 'patrolCount', label: 'Nombre de rondes', type: 'number' },
          ...days.flatMap((d, i): TemplateField[] => [
            { id: `armOn${i}`, label: `Mise en service : ${d}`, type: 'text' },
            { id: `armOff${i}`, label: `Mise hors service : ${d}`, type: 'text' },
          ]),
          { id: 'breaker', label: 'Sur défaut 220 V, disjoncteur réenclenché par', type: 'select', options: ['B1', 'B2', 'B3', 'B4', 'B5', 'Autres'] },
          { id: 'armReports', label: 'Transmission des mises en et hors service', type: 'select', options: yesNo },
        ],
      },
      {
        id: 'comments',
        title: 'Commentaires',
        fields: [
          { id: 'comments', label: 'Toutes les informations utiles à la bonne gestion des alarmes', type: 'textarea', dictation: true },
          { id: 'salesName', label: 'Nom commercial', type: 'text' },
          { id: 'place', label: 'Fait à', type: 'text' },
        ],
      },
    ],
  };
}

/** DOSSIER TECHNIQUE – BON DE SORTIE : la partie administrative (télésurveillance ou vidéo) */
export function technicalFile(kind: 'TELES' | 'VIDEO'): TemplateSchema {
  const video = kind === 'VIDEO';
  return {
    lang: 'fr',
    sections: [
      {
        id: 'file',
        title: 'Dossier',
        fields: [
          { id: 'prom', label: 'PROM', type: 'text', prefill: 'client.subscriberNumber' },
          { id: 'client', label: 'Client', type: 'text', prefill: 'client.name' },
          { id: 'pvDate', label: 'Date précise à noter sur le PV et le dossier de financement', type: 'date', required: true },
          {
            id: 'todo', label: 'À faire', type: 'checklist',
            options: video ? ['Plan', 'Photos', 'Bon de sortie', 'DocuSign technique'] : ['Fiche PC à faire signer', 'Bon de sortie', 'DocuSign technique'],
          },
          {
            id: 'noDocusign', label: 'Si absence de DocuSign technique', type: 'checklist',
            options: [
              'Procès-verbal de réception des marchandises', 'Contrôle technique qualité', 'Attestation de formation', 'Mandat SEPA',
              ...(video ? ['Dossier préfecture (Cerfa, annexe 1, rapport de présentation)'] : []),
            ],
          },
        ],
      },
      {
        id: 'financing',
        title: 'Contrat partenaire financier',
        fields: [
          { id: 'partner', label: 'Partenaire financier', type: 'select', options: ['Grenke', 'NBB Lease', 'Locam', 'Pas de contrat à régulariser'] },
          { id: 'sentBy', label: 'Contrat envoyé', type: 'select', options: ['Par DocuSign', 'Papier'] },
          { id: 'signatory', label: 'Nom de la personne habilitée à signer les contrats', type: 'text' },
          { id: 'flags', label: 'À préciser', type: 'checklist', options: ['Adresse d’installation', 'Supervision vidéo'] },
          { id: 'misc', label: 'Divers', type: 'textarea' },
        ],
      },
      {
        id: 'admin',
        title: 'Partie réservée au service administratif',
        fields: [
          { id: 'validated', label: 'Fiche validation', type: 'checkbox' },
          { id: 'plan', label: 'Plan', type: 'select', options: ['À faire', 'Fait'] },
          video
            ? { id: 'public', label: 'Pas de public', type: 'checkbox' }
            : { id: 'discharge', label: 'Décharge', type: 'checkbox' },
          ...(video ? [{ id: 'disk', label: 'Disque dur de l’enregistreur', type: 'select' as const, options: ['2 To', '4 To', '6 To'] }] : []),
          { id: 'serials', label: 'N° de série (obligatoire)', type: 'textarea', required: true, prefill: 'equipment.serialNumber' },
        ],
      },
    ],
  };
}

export const FICHE_NAME = 'Fiche d’intervention technique';

/** Les modèles de la société A.R.G.E. : la fiche pour chaque type d'intervention, puis les documents à choisir */
export function argeTemplates(): { name: string; kind: InterventionKind; schema: TemplateSchema; company: boolean }[] {
  const kinds: InterventionKind[] = ['SAV', 'INSTALLATION', 'MAINTENANCE', 'OTHER'];
  return [
    // Modèles de la société : choisis d'office pour chaque nouvelle fiche
    ...kinds.map((kind) => ({ name: FICHE_NAME, kind, schema: interventionSheet, company: true })),
    // Modèles du groupe : jamais choisis d'office (la société a déjà les siens), on les choisit sur l'intervention
    { name: 'Consignes de télésurveillance (Teles)', kind: 'INSTALLATION', schema: monitoringInstructions(), company: false },
    { name: 'Dossier technique – bon de sortie télésurveillance', kind: 'INSTALLATION', schema: technicalFile('TELES'), company: false },
    { name: 'Dossier technique – bon de sortie vidéoprotection', kind: 'INSTALLATION', schema: technicalFile('VIDEO'), company: false },
  ];
}
