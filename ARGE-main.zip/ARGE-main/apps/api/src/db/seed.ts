/**
 * Données d'exemple : un groupe international avec trois sociétés (France, Belgique, Royaume-Uni),
 * des agences, des utilisateurs de chaque rôle, des clients et des interventions du jour.
 *
 *   npm run db:seed            (ne fait rien si des données existent déjà)
 *   npm run db:seed -- --reset (efface TOUT et recommence)
 *
 * Tous les comptes ont le mot de passe : demo1234
 */
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import { sql } from 'drizzle-orm';
import { addDays, documentTotals, type Role } from '@itineo/shared';
import { db, pool, schema } from './client.js';
import { migrate } from './migrate.js';
import { alignCompaniesToEdition, ensureSystemTemplates } from '../services/templates.js';
import { env } from '../env.js';
import { applySectorDemo } from './seed-sectors.js';
import { nextInterventionNumber, nextNumber } from '../services/numbering.js';
import { generateContractVisits, todayIn } from '../services/contracts.js';
import { recordMovement } from '../services/stock.js';

const reset = process.argv.includes('--reset');

async function main() {
  await migrate();

  const existing = await db.select({ id: schema.groups.id }).from(schema.groups).limit(1);
  if (existing.length && !reset) {
    console.log('La base contient déjà des données. Relancez avec --reset pour tout effacer et recommencer.');
    return;
  }
  if (reset) await wipeData();
  await seedDemo();

  console.log(`
Données d'exemple créées. Mot de passe de tous les comptes : demo1234

  admin@exemple.test          Administrateur du groupe (tout voir)
  direction.fr@exemple.test   Direction de la société France
  chef.est@exemple.test       Chef de l'agence Est
  planning.est@exemple.test   Planificateur de l'agence Est
  compta.fr@exemple.test      Comptabilité France
  tech1.est@exemple.test      Technicien agence Est (4 interventions aujourd'hui)
  tech.bxl@exemple.test       Technicienne Belgique
  tech.uk@exemple.test        Technician UK (fiches en anglais)

Portail client (http://localhost:5173/portail) :
  contact.durand@client.test  Claire Durand, client « Cabinet Durand »
`);
}

/** Efface toutes les données (pas la structure) : base de démonstration remise à zéro */
export async function wipeData() {
  await db.execute(sql`TRUNCATE messages, conversation_members, conversations, directory_contacts, vehicle_positions, portal_tokens, portal_users, audit_logs, counters, job_runs, vehicle_events, vehicle_deadlines, vehicles,
      user_certifications, certification_types, stock_movements, stock_slip_lines, stock_slips, stock_levels, stock_locations, articles,
      payments, invoice_lines, invoices, report_photos, report_parts, reports, interventions,
      contracts, quote_lines, quotes, form_templates,
      equipments, sites, contacts, clients, password_resets, role_assignments, users, teams, agencies, companies, groups CASCADE`);
}

/** Crée les données d'exemple dans une base vide (aussi utilisé par les tests d'intégration) */
export async function seedDemo() {
  await ensureSystemTemplates();

  // ─── Organisation ───
  const [group] = await db.insert(schema.groups).values({ name: 'Groupe Exemple' }).returning();

  const [fr, be, uk] = await db.insert(schema.companies).values([
    {
      groupId: group.id, name: 'Exemple Services France', legalName: 'Exemple Services France SAS',
      countryCode: 'FR', currency: 'EUR', locale: 'fr-FR', timezone: 'Europe/Paris',
      vatNumber: 'FR00000000000', address: '1 rue de l’Exemple', postalCode: '75000', city: 'Paris',
      email: 'contact@exemple-services.test', phone: '01 00 00 00 00', documentPrefix: 'FR',
      legalMentions: 'Exemple Services France SAS · SIRET 000 000 000 00000',
    },
    {
      groupId: group.id, name: 'Exemple Services Belgique', legalName: 'Exemple Services Belgique SRL',
      countryCode: 'BE', currency: 'EUR', locale: 'fr-BE', timezone: 'Europe/Brussels',
      vatNumber: 'BE0000000000', address: '1 avenue de l’Exemple', postalCode: '1000', city: 'Bruxelles',
      email: 'contact@exemple-services-be.test', documentPrefix: 'BE',
      legalMentions: 'Exemple Services Belgique SRL · BCE 0000.000.000',
    },
    {
      groupId: group.id, name: 'Example Services UK', legalName: 'Example Services UK Ltd',
      countryCode: 'GB', currency: 'GBP', locale: 'en-GB', timezone: 'Europe/London',
      vatNumber: 'GB000000000', address: '1 Example Street', postalCode: 'EC1A 1AA', city: 'London',
      email: 'contact@example-services-uk.test', documentPrefix: 'UK',
      legalMentions: 'Example Services UK Ltd · Company No. 00000000',
    },
  ]).returning();
  // Sociétés de l'édition installée (Itinéos Vigie, Itinéos Constat…)
  await alignCompaniesToEdition(env.EDITION);

  const agencyRows = await db.insert(schema.agencies).values([
    { companyId: fr.id, name: 'Agence Nord', code: 'NORD', city: 'Lille' },
    { companyId: fr.id, name: 'Agence Est', code: 'EST', city: 'Nancy', email: 'est@exemple-services.test' },
    { companyId: fr.id, name: 'Agence Sud', code: 'SUD', city: 'Lyon' },
    { companyId: fr.id, name: 'Agence Ouest', code: 'OUEST', city: 'Nantes' },
    { companyId: be.id, name: 'Agence Bruxelles', code: 'BXL', city: 'Bruxelles' },
    { companyId: uk.id, name: 'London Branch', code: 'LON', city: 'London' },
  ]).returning();
  const agency = Object.fromEntries(agencyRows.map((a) => [a.code, a]));

  const [teamEst] = await db.insert(schema.teams).values([
    { agencyId: agency.EST.id, name: 'Dépannage' },
    { agencyId: agency.EST.id, name: 'Installation' },
  ]).returning();

  // ─── Utilisateurs ───
  const passwordHash = await bcrypt.hash('demo1234', 10);
  type Grant = { role: Role; companyId?: string; agencyId?: string };
  const people: { email: string; firstName: string; lastName: string; skills?: string[]; locale?: string; teamId?: string; grants: Grant[] }[] = [
    { email: 'admin@exemple.test', firstName: 'Alex', lastName: 'Admin', grants: [{ role: 'GROUP_ADMIN' }] },
    { email: 'direction.fr@exemple.test', firstName: 'Claire', lastName: 'Directrice', grants: [{ role: 'DIRECTOR', companyId: fr.id }] },
    { email: 'chef.est@exemple.test', firstName: 'Paul', lastName: 'Chef', grants: [{ role: 'AGENCY_MANAGER', companyId: fr.id, agencyId: agency.EST.id }] },
    { email: 'planning.est@exemple.test', firstName: 'Sophie', lastName: 'Planning', grants: [{ role: 'PLANNER', companyId: fr.id, agencyId: agency.EST.id }] },
    { email: 'compta.fr@exemple.test', firstName: 'Marc', lastName: 'Compta', grants: [{ role: 'ACCOUNTANT', companyId: fr.id }] },
    { email: 'tech1.est@exemple.test', firstName: 'Julien', lastName: 'Simon', skills: ['Clim', 'Chauffage'], teamId: teamEst.id, grants: [{ role: 'TECHNICIAN', companyId: fr.id, agencyId: agency.EST.id }] },
    { email: 'tech2.est@exemple.test', firstName: 'Martin', lastName: 'Bernard', skills: ['Électricité'], teamId: teamEst.id, grants: [{ role: 'TECHNICIAN', companyId: fr.id, agencyId: agency.EST.id }] },
    { email: 'tech.nord@exemple.test', firstName: 'Sarah', lastName: 'Laurent', skills: ['Alarme', 'Réseau'], grants: [{ role: 'TECHNICIAN', companyId: fr.id, agencyId: agency.NORD.id }] },
    { email: 'chef.bxl@exemple.test', firstName: 'Lucas', lastName: 'Peeters', locale: 'fr-BE', grants: [{ role: 'AGENCY_MANAGER', companyId: be.id, agencyId: agency.BXL.id }] },
    { email: 'tech.bxl@exemple.test', firstName: 'Emma', lastName: 'Janssens', locale: 'fr-BE', skills: ['Chauffage'], grants: [{ role: 'TECHNICIAN', companyId: be.id, agencyId: agency.BXL.id }] },
    { email: 'manager.uk@exemple.test', firstName: 'Oliver', lastName: 'Smith', locale: 'en-GB', grants: [{ role: 'AGENCY_MANAGER', companyId: uk.id, agencyId: agency.LON.id }] },
    { email: 'tech.uk@exemple.test', firstName: 'Harry', lastName: 'Jones', locale: 'en-GB', skills: ['HVAC'], grants: [{ role: 'TECHNICIAN', companyId: uk.id, agencyId: agency.LON.id }] },
  ];
  const userId: Record<string, string> = {};
  for (const person of people) {
    const [u] = await db.insert(schema.users).values({
      groupId: group.id, email: person.email, passwordHash, firstName: person.firstName, lastName: person.lastName,
      skills: person.skills ?? [], locale: person.locale ?? 'fr-FR', teamId: person.teamId,
    }).returning({ id: schema.users.id });
    userId[person.email] = u.id;
    await db.insert(schema.roleAssignments).values(person.grants.map((g) => ({
      userId: u.id, groupId: group.id, role: g.role, companyId: g.companyId ?? null, agencyId: g.agencyId ?? null,
    })));
  }

  // ─── Clients, sites et équipements ───
  async function addClient(input: {
    companyId: string; agencyId?: string; name: string; email?: string; phone?: string;
    address: string; postalCode: string; city: string; countryCode: string;
    equipment?: { category: string; brand?: string; model?: string; serialNumber?: string; location?: string; installedAt?: string; underContract?: boolean };
  }) {
    const [client] = await db.insert(schema.clients).values({
      groupId: group.id, companyId: input.companyId, agencyId: input.agencyId ?? null, name: input.name,
      email: input.email, phone: input.phone, address: input.address, postalCode: input.postalCode,
      city: input.city, countryCode: input.countryCode,
    }).returning();
    const [site] = await db.insert(schema.sites).values({
      clientId: client.id, name: input.name, address: input.address, postalCode: input.postalCode,
      city: input.city, countryCode: input.countryCode,
    }).returning();
    const [equipment] = input.equipment
      ? await db.insert(schema.equipments).values({ ...input.equipment, siteId: site.id }).returning()
      : [null];
    return { client, site, equipment };
  }

  const durand = await addClient({
    companyId: fr.id, agencyId: agency.EST.id, name: 'Cabinet Durand', email: 'cabinet.durand@client.test',
    phone: '03 83 00 00 01', address: '12 rue des Lilas', postalCode: '54500', city: 'Vandœuvre-lès-Nancy', countryCode: 'FR',
    equipment: { category: 'Climatiseur mural', brand: 'Marque A', model: 'Modèle 35', serialNumber: 'SN-0001-A', location: "Salle d'attente", installedAt: '2019-05-14', underContract: true },
  });
  const tilleuls = await addClient({
    companyId: fr.id, agencyId: agency.EST.id, name: 'Résidence Les Tilleuls', email: 'syndic.tilleuls@client.test',
    address: '4 place des Tilleuls', postalCode: '54000', city: 'Nancy', countryCode: 'FR',
    equipment: { category: 'Chaudière collective', brand: 'Marque B', model: 'Modèle 120', serialNumber: 'SN-0002-B', location: 'Chaufferie', installedAt: '2015-09-01', underContract: true },
  });
  const moreau = await addClient({
    companyId: fr.id, name: 'Boulangerie Moreau', email: 'boulangerie.moreau@client.test',
    address: '8 rue Principale', postalCode: '54520', city: 'Laxou', countryCode: 'FR',
    equipment: { category: 'Four professionnel', brand: 'Marque C', model: 'Modèle F4', serialNumber: 'SN-0003-C', location: 'Fournil' },
  });
  const lefevre = await addClient({
    companyId: fr.id, agencyId: agency.EST.id, name: 'M. et Mme Lefèvre', email: 'lefevre@client.test',
    address: '21 chemin des Vignes', postalCode: '54200', city: 'Toul', countryCode: 'FR',
  });
  const lille = await addClient({
    companyId: fr.id, agencyId: agency.NORD.id, name: 'Pharmacie du Beffroi', email: 'pharmacie.beffroi@client.test',
    address: '3 Grand Place', postalCode: '59000', city: 'Lille', countryCode: 'FR',
    equipment: { category: 'Alarme intrusion', brand: 'Marque D', serialNumber: 'SN-0004-D', location: 'Officine' },
  });
  const bxl = await addClient({
    companyId: be.id, agencyId: agency.BXL.id, name: 'Brasserie du Sablon', email: 'brasserie.sablon@client.test',
    address: '10 rue du Sablon', postalCode: '1000', city: 'Bruxelles', countryCode: 'BE',
    equipment: { category: 'Chaudière', brand: 'Marque B', model: 'Modèle 45', serialNumber: 'SN-0005-B', location: 'Cave' },
  });
  const london = await addClient({
    companyId: uk.id, agencyId: agency.LON.id, name: 'Riverside Offices', email: 'facilities.riverside@client.test',
    address: '5 River Walk', postalCode: 'SE1 9AA', city: 'London', countryCode: 'GB',
    equipment: { category: 'Air conditioning unit', brand: 'Brand E', model: 'Model 50', serialNumber: 'SN-0006-E', location: 'Server room' },
  });

  // ─── Interventions ───
  const at = (hour: number, minute = 0, dayOffset = 0) => {
    const d = new Date();
    d.setDate(d.getDate() + dayOffset);
    d.setHours(hour, minute, 0, 0);
    return d;
  };
  const companies = { [fr.id]: fr, [be.id]: be, [uk.id]: uk };
  async function addIntervention(v: {
    companyId: string; agencyId: string; c: Awaited<ReturnType<typeof addClient>>; kind: 'SAV' | 'INSTALLATION' | 'MAINTENANCE';
    reason: string; technician?: string; start?: Date; hours?: number; priority?: 'NORMAL' | 'URGENT' | 'HIGH'; source?: string;
  }) {
    const company = companies[v.companyId];
    const number = await nextInterventionNumber(db, company);
    const [row] = await db.insert(schema.interventions).values({
      groupId: group.id, companyId: v.companyId, agencyId: v.agencyId, number,
      clientId: v.c.client.id, siteId: v.c.site.id, equipmentId: v.c.equipment?.id ?? null,
      technicianId: v.technician ? userId[v.technician] : null, kind: v.kind, reason: v.reason,
      priority: v.priority ?? 'NORMAL', source: v.source ?? 'Appel client',
      status: v.technician && v.start ? 'PLANNED' : 'TO_PLAN',
      scheduledStart: v.start ?? null,
      scheduledEnd: v.start ? new Date(v.start.getTime() + (v.hours ?? 1) * 3600_000) : null,
      createdById: userId['planning.est@exemple.test'],
    }).returning();
    return row;
  }

  const est = { companyId: fr.id, agencyId: agency.EST.id };
  await addIntervention({ ...est, c: tilleuls, kind: 'MAINTENANCE', reason: 'Visite annuelle de la chaudière collective', technician: 'tech1.est@exemple.test', start: at(8), hours: 1, source: 'Contrat' });
  await addIntervention({ ...est, c: moreau, kind: 'SAV', reason: 'Four en défaut, code erreur E4', technician: 'tech1.est@exemple.test', start: at(9, 30), hours: 0.75 });
  await addIntervention({ ...est, c: durand, kind: 'SAV', reason: 'La climatisation ne démarre plus', technician: 'tech1.est@exemple.test', start: at(11), hours: 2, priority: 'HIGH' });
  await addIntervention({ ...est, c: lefevre, kind: 'INSTALLATION', reason: 'Pose et mise en service d’une pompe à chaleur', technician: 'tech1.est@exemple.test', start: at(14), hours: 3, source: 'Devis signé' });
  await addIntervention({ ...est, c: durand, kind: 'SAV', reason: 'Contrôle de l’éclairage de secours', technician: 'tech2.est@exemple.test', start: at(10), hours: 1 });
  await addIntervention({ ...est, c: tilleuls, kind: 'SAV', reason: 'Fuite signalée sous la chaudière', priority: 'URGENT' });
  await addIntervention({ ...est, c: moreau, kind: 'MAINTENANCE', reason: 'Entretien semestriel du four', source: 'Contrat' });
  await addIntervention({ companyId: fr.id, agencyId: agency.NORD.id, c: lille, kind: 'SAV', reason: 'Détecteur en défaut', technician: 'tech.nord@exemple.test', start: at(9), hours: 1 });
  await addIntervention({ companyId: be.id, agencyId: agency.BXL.id, c: bxl, kind: 'MAINTENANCE', reason: 'Entretien annuel de la chaudière', technician: 'tech.bxl@exemple.test', start: at(10), hours: 1.5, source: 'Contrat' });
  await addIntervention({ companyId: uk.id, agencyId: agency.LON.id, c: london, kind: 'SAV', reason: 'Server room unit not cooling', technician: 'tech.uk@exemple.test', start: at(9), hours: 2, priority: 'URGENT', source: 'Phone call' });

  // ─── Portail client : un accès déjà activé chez le Cabinet Durand ───
  await db.insert(schema.portalUsers).values({
    groupId: group.id, clientId: durand.client.id, email: 'contact.durand@client.test', name: 'Claire Durand',
    passwordHash, locale: fr.locale, invitedAt: new Date(), passwordChangedAt: null,
  });

  // ─── Devis et contrat d'entretien ───
  const today = todayIn(fr.timezone);
  const quoteLines = [
    { description: 'Résistance de sole 6 kW', quantity: 1, unit: 'u', unitPriceCents: 38_500, vatRateBp: 2000 },
    { description: "Main-d'œuvre", quantity: 2, unit: 'h', unitPriceCents: 6_500, vatRateBp: 2000 },
  ];
  const totals = documentTotals(quoteLines);
  const [quote] = await db.insert(schema.quotes).values({
    groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, number: await nextNumber(db, fr, 'quote'),
    clientId: moreau.client.id, siteId: moreau.site.id, kind: 'WORK', status: 'SENT',
    title: 'Remplacement de la résistance du four', validUntil: addDays(today, 30), currency: 'EUR',
    netCents: totals.netCents, vatCents: totals.vatCents, grossCents: totals.grossCents,
    sentAt: new Date(), sentTo: moreau.client.email, createdById: userId['chef.est@exemple.test'],
  }).returning();
  await db.insert(schema.quoteLines).values(quoteLines.map((l, i) => ({ ...l, quoteId: quote.id, position: i })));

  await db.insert(schema.contracts).values({
    groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, number: await nextNumber(db, fr, 'contract'),
    clientId: tilleuls.client.id, siteId: tilleuls.site.id, equipmentIds: tilleuls.equipment ? [tilleuls.equipment.id] : [],
    title: 'Entretien chaudière collective', frequencyMonths: 3, startDate: addDays(today, 20), annualPriceCents: 96_000,
    createdById: userId['chef.est@exemple.test'],
  });
  await generateContractVisits();

  // ─── Stock : catalogue, dépôt de l'agence Est, véhicules des techniciens ───
  const catalog = await db.insert(schema.articles).values([
    { reference: 'CD-35', name: 'Condensateur de démarrage 35 µF', category: 'Climatisation', purchasePriceCents: 1_200, salePriceCents: 2_850 },
    { reference: 'FIL-G4', name: 'Filtre G4 595×595', category: 'Climatisation', purchasePriceCents: 900, salePriceCents: 2_200 },
    { reference: 'JT-CIRC', name: 'Joint de circulateur', category: 'Chauffage', purchasePriceCents: 350, salePriceCents: 1_150 },
    { reference: 'RES-6K', name: 'Résistance de sole 6 kW', category: 'Fours', purchasePriceCents: 19_000, salePriceCents: 38_500 },
    { reference: 'GAZ-R32', name: 'Fluide frigorigène R32', category: 'Climatisation', unit: 'kg', purchasePriceCents: 4_500, salePriceCents: 9_500 },
  ].map((x) => ({ ...x, groupId: group.id, companyId: fr.id, vatRateBp: 2000 }))).returning();
  const art = Object.fromEntries(catalog.map((x) => [x.reference, x]));
  const [depot, van1, van2] = await db.insert(schema.stockLocations).values([
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, kind: 'DEPOT', name: 'Dépôt Nancy' },
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, kind: 'VEHICLE', name: 'Véhicule de Julien Simon', technicianId: userId['tech1.est@exemple.test'] },
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, kind: 'VEHICLE', name: 'Véhicule de Martin Bernard', technicianId: userId['tech2.est@exemple.test'] },
  ] as const).returning();
  const base = { groupId: group.id, companyId: fr.id, userId: userId['planning.est@exemple.test'] };
  await db.transaction(async (tx) => {
    for (const [ref, q] of [['CD-35', 20], ['FIL-G4', 40], ['JT-CIRC', 15], ['RES-6K', 2], ['GAZ-R32', 12]] as const) {
      await recordMovement(tx, { ...base, articleId: art[ref].id, kind: 'RECEIPT', toLocationId: depot.id, quantity: q, note: 'Stock initial' });
    }
    for (const [ref, q] of [['CD-35', 4], ['FIL-G4', 6], ['JT-CIRC', 3], ['GAZ-R32', 2]] as const) {
      await recordMovement(tx, { ...base, articleId: art[ref].id, kind: 'TRANSFER', fromLocationId: depot.id, toLocationId: van1.id, quantity: q, note: 'Dotation du véhicule' });
    }
    await recordMovement(tx, { ...base, articleId: art['FIL-G4'].id, kind: 'TRANSFER', fromLocationId: depot.id, toLocationId: van2.id, quantity: 2, note: 'Dotation du véhicule' });
  });
  await db.insert(schema.stockLevels).values([
    { locationId: depot.id, articleId: art['RES-6K'].id, minQuantity: 2 },
    { locationId: depot.id, articleId: art['CD-35'].id, minQuantity: 5 },
  ]).onConflictDoUpdate({ target: [schema.stockLevels.locationId, schema.stockLevels.articleId], set: { minQuantity: sql`excluded.min_quantity` } });

  // ─── Habilitations ───
  const types = await db.insert(schema.certificationTypes).values([
    { code: 'B1V', name: 'Habilitation électrique B1V', validityMonths: 36, description: 'Exécutant électricien, travaux au voisinage' },
    { code: 'BR', name: 'Habilitation électrique BR', validityMonths: 36, description: 'Interventions BT générales (dépannage, raccordement)' },
    { code: 'FLUIDES', name: 'Attestation d’aptitude fluides frigorigènes (cat. I)', validityMonths: 60, description: 'Obligatoire pour intervenir sur les circuits frigorifiques' },
    { code: 'CACES-R486', name: 'CACES R486 (nacelles)', validityMonths: 60 },
    { code: 'HAUTEUR', name: 'Travail en hauteur', validityMonths: 36 },
    { code: 'SST', name: 'Sauveteur secouriste du travail', validityMonths: 24 },
  ].map((x) => ({ ...x, groupId: group.id }))).returning();
  const type = Object.fromEntries(types.map((x) => [x.code, x]));
  const julien = userId['tech1.est@exemple.test'];
  const martin = userId['tech2.est@exemple.test'];
  await db.insert(schema.userCertifications).values([
    { userId: julien, typeId: type.BR.id, obtainedOn: addDays(today, -400), expiresOn: addDays(today, 700), reference: 'Titre n° 2025-114' },
    { userId: julien, typeId: type.FLUIDES.id, obtainedOn: addDays(today, -1800), expiresOn: addDays(today, 25), reference: 'Attestation 54-0331' },
    { userId: julien, typeId: type.SST.id, obtainedOn: addDays(today, -760), expiresOn: addDays(today, -30) },
    { userId: martin, typeId: type.B1V.id, obtainedOn: addDays(today, -200), expiresOn: addDays(today, 900) },
    { userId: martin, typeId: type.BR.id, obtainedOn: addDays(today, -200), expiresOn: addDays(today, 900) },
  ]);
  // La pose de pompe à chaleur exige l'attestation fluides frigorigènes
  await db.update(schema.interventions).set({ requiredCertificationIds: [type.FLUIDES.id] })
    .where(sql`${schema.interventions.reason} = 'Pose et mise en service d’une pompe à chaleur'`);

  // ─── Parc véhicules ───
  const [kangoo, partner] = await db.insert(schema.vehicles).values([
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, plate: 'AB-123-CD', type: 'VAN', make: 'Renault', model: 'Kangoo Van', fuel: 'Diesel',
      firstRegistration: '2022-03-15', ownership: 'LEASED', lessor: 'Loueur Exemple', mileage: 84_200, mileageUpdatedOn: addDays(today, -3),
      driverId: julien, stockLocationId: van1.id },
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, plate: 'EF-456-GH', type: 'VAN', make: 'Peugeot', model: 'Partner', fuel: 'Diesel',
      firstRegistration: '2020-09-01', ownership: 'OWNED', mileage: 41_050, mileageUpdatedOn: addDays(today, -10), driverId: martin, stockLocationId: van2.id },
  ]).returning();
  await db.insert(schema.vehicleDeadlines).values([
    { vehicleId: kangoo.id, kind: 'SERVICE', dueDate: addDays(today, 120), dueMileage: 85_000, intervalMonths: 12, intervalKm: 20_000 },
    { vehicleId: kangoo.id, kind: 'TECH_INSPECTION', dueDate: addDays(today, 20), intervalMonths: 24 },
    { vehicleId: kangoo.id, kind: 'LEASE_END', dueDate: addDays(today, 500) },
    { vehicleId: partner.id, kind: 'SERVICE', dueDate: addDays(today, -5), dueMileage: 45_000, intervalMonths: 12, intervalKm: 15_000 },
    { vehicleId: partner.id, kind: 'INSURANCE', dueDate: addDays(today, 70), intervalMonths: 12 },
    { vehicleId: partner.id, kind: 'TIRES', label: 'Pneus hiver', dueDate: addDays(today, 15), intervalMonths: 12, appointmentOn: addDays(today, 12), appointmentWith: 'Garage du Centre' },
  ]);
  // ─── Géolocalisation : Julien et Martin ont activé le partage ; un trajet autour de Nancy ───
  const ago = (min: number) => new Date(Date.now() - min * 60_000);
  await db.update(schema.users).set({ locationSharingSince: ago(24 * 60) }).where(sql`${schema.users.id} IN (${julien}, ${martin})`);
  const julienTrack: [number, number, number][] = [
    [120, 48.6921, 6.1844], [110, 48.6895, 6.1790], [100, 48.6868, 6.1702], [90, 48.6852, 6.1601], [80, 48.6847, 6.1497],
    [60, 48.6847, 6.1497], [45, 48.6790, 6.1560], [35, 48.6702, 6.1641], [25, 48.6620, 6.1690], [12, 48.6603, 6.1716], [3, 48.6604, 6.1718],
  ];
  const martinTrack: [number, number, number][] = [[95, 48.6921, 6.1844], [80, 48.6750, 6.1760], [60, 48.6566, 6.1722], [45, 48.6568, 6.1725]];
  for (const [veh, user, track] of [[kangoo, julien, julienTrack], [partner, martin, martinTrack]] as const) {
    await db.insert(schema.vehiclePositions).values(track.map(([min, lat, lng], i) => ({
      vehicleId: veh.id, userId: user, lat, lng, accuracyM: 12 + (i % 3) * 6, recordedAt: ago(min),
      event: (i === 0 ? 'EN_ROUTE' : 'TRACK') as 'EN_ROUTE' | 'TRACK',
    })));
    const [lastMin, lat, lng] = track[track.length - 1];
    await db.update(schema.vehicles).set({ lastLat: lat, lastLng: lng, lastAccuracyM: 12, lastPositionAt: ago(lastMin), lastPositionBy: user })
      .where(sql`${schema.vehicles.id} = ${veh.id}`);
  }

  await db.insert(schema.vehicleEvents).values([
    { vehicleId: kangoo.id, kind: 'SERVICE', occurredOn: addDays(today, -245), mileage: 65_000, costCents: 32_000, provider: 'Garage du Centre', description: 'Vidange, filtres, plaquettes AV' },
    { vehicleId: partner.id, kind: 'REPAIR', occurredOn: addDays(today, -60), mileage: 39_800, costCents: 48_500, provider: 'Garage du Centre', description: 'Remplacement embrayage' },
  ]);

  // ─── Annuaire : numéros fictifs (plages réservées à la fiction en France : 01 99 00…, 06 39 98…) ───
  const phones: Record<string, string> = {
    'chef.est@exemple.test': '06 39 98 00 01', 'planning.est@exemple.test': '06 39 98 00 02',
    'tech1.est@exemple.test': '06 39 98 00 03', 'tech2.est@exemple.test': '06 39 98 00 04', 'tech.nord@exemple.test': '06 39 98 00 05',
  };
  for (const [email, phone] of Object.entries(phones)) await db.update(schema.users).set({ phone }).where(sql`${schema.users.email} = ${email}`);
  await db.update(schema.agencies).set({ phone: '01 99 00 10 00' }).where(sql`${schema.agencies.id} = ${agency.EST.id}`);
  await db.insert(schema.directoryContacts).values([
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, category: 'SUPPLIER', name: 'Comptoir', organization: 'Grossiste Clim & Chauffage (exemple)',
      phone: '01 99 00 20 00', email: 'comptoir@grossiste.exemple', notes: 'Ouvert 7 h 30 – 17 h. N° client : 54-1180.' },
    { groupId: group.id, companyId: fr.id, agencyId: null, category: 'MANUFACTURER', name: 'Assistance technique', organization: 'Fabricant de pompes à chaleur (exemple)',
      phone: '01 99 00 30 00', notes: 'Hotline installateurs, du lundi au vendredi 8 h – 18 h. Préparer le n° de série.' },
    { groupId: group.id, companyId: fr.id, agencyId: agency.EST.id, category: 'SUBCONTRACTOR', name: 'Marc Électricité (exemple)', organization: 'Sous-traitant électricité',
      mobile: '06 39 98 10 00', email: 'contact@marc-elec.exemple' },
    { groupId: group.id, companyId: null, agencyId: null, category: 'EMERGENCY', name: 'Numéro d’urgence européen', phone: '112' },
  ]);

  // ─── Messagerie : une conversation à deux et un groupe d'agence ───
  const [paul] = await db.select({ id: schema.users.id }).from(schema.users).where(sql`${schema.users.email} = 'chef.est@exemple.test'`);
  const minutes = (m: number) => new Date(Date.now() - m * 60_000);
  const [direct] = await db.insert(schema.conversations).values({
    groupId: group.id, kind: 'DIRECT', directKey: [paul.id, julien].sort().join(':'), createdBy: paul.id, createdAt: minutes(90), lastMessageAt: minutes(40),
  }).returning();
  const [team] = await db.insert(schema.conversations).values({
    groupId: group.id, kind: 'GROUP', title: 'Agence Est', createdBy: paul.id, createdAt: minutes(300), lastMessageAt: minutes(20),
  }).returning();
  await db.insert(schema.conversationMembers).values([
    { conversationId: direct.id, userId: paul.id, joinedAt: minutes(90), lastReadAt: new Date() },
    { conversationId: direct.id, userId: julien, joinedAt: minutes(90), lastReadAt: minutes(60) },
    { conversationId: team.id, userId: paul.id, joinedAt: minutes(300), lastReadAt: new Date() },
    { conversationId: team.id, userId: julien, joinedAt: minutes(300), lastReadAt: new Date() },
    { conversationId: team.id, userId: martin, joinedAt: minutes(300), lastReadAt: minutes(200) },
  ]);
  await db.insert(schema.messages).values([
    { conversationId: team.id, senderId: null, body: JSON.stringify({ e: 'created', by: 'Paul Chef' }), createdAt: minutes(300) },
    { conversationId: team.id, senderId: paul.id, body: 'Bonjour à tous : réunion d’équipe vendredi 8 h à l’agence.', createdAt: minutes(240) },
    { conversationId: team.id, senderId: martin, body: 'Bien noté.', createdAt: minutes(200) },
    { conversationId: team.id, senderId: julien, body: 'Je passe au comptoir chercher des raccords, quelqu’un a besoin de quelque chose ?', createdAt: minutes(20) },
    { conversationId: direct.id, senderId: paul.id, body: 'Julien, le client de la Boulangerie Moreau demande si tu peux passer avant 11 h.', createdAt: minutes(55) },
    { conversationId: direct.id, senderId: julien, body: 'Oui, j’y serai vers 10 h 30.', createdAt: minutes(40) },
  ]);

  // ─── Habillage pour le métier de l'édition (Itinéos Vigie, Constat…) ───
  await applySectorDemo(env.EDITION);
}

// Exécution directe : npm run db:seed
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main()
    .catch((err) => {
      console.error(err);
      process.exitCode = 1;
    })
    .finally(() => pool.end());
}
