/**
 * Données d'exemple propres à chaque édition : les données des techniciens (seed.ts) sont reprises puis
 * habillées pour le métier (clients, motifs, devis, habilitations…), avec ce qu'il faut pour essayer
 * les fonctions du métier : points de passage (Vigie), délais de l'assureur (Expertise), état des lieux
 * d'entrée déjà signé (Clés), traitements déjà faits pour le registre (Services).
 */
import { and, eq, isNull, sql } from 'drizzle-orm';
import { addDays, documentTotals, type InterventionKind, type Sector } from '@itineo/shared';
import { db, schema } from './client.js';
import { nextInterventionNumber } from '../services/numbering.js';
import { newCheckpointCode } from '../services/sector-features.js';
import { todayIn } from '../services/contracts.js';

type Job = { kind: InterventionKind; reason: string; due?: number };
interface SectorDemo {
  /** Nom des clients des techniciens → nom dans le métier */
  clients: Record<string, string>;
  /** Motif des interventions des techniciens → type et motif dans le métier (due : date limite, en jours) */
  jobs: Record<string, Job>;
  quote: { title: string; lines: { description: string; quantity: number; unit: string; unitPriceCents: number }[] };
  contract: string;
  /** Les 6 types d'habilitation, dans l'ordre (B1V, BR, FLUIDES, CACES-R486, HAUTEUR, SST) */
  certifications?: { code: string; name: string; validityMonths: number }[];
  skills: Record<string, string[]>;
  /** Fournisseur et fabricant de l'annuaire */
  directory: { supplier: string; manufacturer: string };
  /** Message d'équipe des techniciens → message du métier */
  teamMessage: string;
}

// Motifs des interventions créées par seed.ts (édition des techniciens)
const R = {
  visitBoiler: 'Visite annuelle de la chaudière collective',
  oven: 'Four en défaut, code erreur E4',
  aircon: 'La climatisation ne démarre plus',
  heatPump: 'Pose et mise en service d’une pompe à chaleur',
  lighting: 'Contrôle de l’éclairage de secours',
  leak: 'Fuite signalée sous la chaudière',
  ovenService: 'Entretien semestriel du four',
  detector: 'Détecteur en défaut',
  bxlBoiler: 'Entretien annuel de la chaudière',
  london: 'Server room unit not cooling',
};
const C = {
  durand: 'Cabinet Durand', tilleuls: 'Résidence Les Tilleuls', moreau: 'Boulangerie Moreau', lefevre: 'M. et Mme Lefèvre',
  lille: 'Pharmacie du Beffroi', bxl: 'Brasserie du Sablon', london: 'Riverside Offices',
};

const DEMOS: Record<Exclude<Sector, 'TECH'>, SectorDemo> = {
  SECURITY: {
    clients: { [C.moreau]: 'Entrepôt Moreau Logistique', [C.lefevre]: 'Chantier Lefèvre Construction', [C.london]: 'Riverside Business Park' },
    jobs: {
      [R.visitBoiler]: { kind: 'MAINTENANCE', reason: 'Ronde de nuit : parties communes et parkings' },
      [R.oven]: { kind: 'SAV', reason: 'Alarme intrusion zone quai 3 – levée de doute' },
      [R.aircon]: { kind: 'MAINTENANCE', reason: 'Ronde d’ouverture des locaux' },
      [R.heatPump]: { kind: 'INSTALLATION', reason: 'Mise en place du gardiennage du chantier' },
      [R.lighting]: { kind: 'OTHER', reason: 'Main courante : contrôle des accès visiteurs' },
      [R.leak]: { kind: 'SAV', reason: 'Alarme incendie déclenchée – levée de doute' },
      [R.ovenService]: { kind: 'MAINTENANCE', reason: 'Ronde de fermeture du week-end' },
      [R.detector]: { kind: 'SAV', reason: 'Alarme intrusion officine – levée de doute' },
      [R.bxlBoiler]: { kind: 'MAINTENANCE', reason: 'Ronde de contrôle hebdomadaire' },
      [R.london]: { kind: 'SAV', reason: 'Intruder alarm, loading bay – alarm response' },
    },
    quote: { title: 'Gardiennage du chantier (2 semaines)', lines: [
      { description: 'Agent de sécurité – vacation de nuit de 12 h', quantity: 14, unit: 'u', unitPriceCents: 32_000 },
      { description: 'Ronde mobile avec contrôle des accès', quantity: 10, unit: 'u', unitPriceCents: 4_500 },
    ] },
    contract: 'Rondes et interventions sur alarme',
    certifications: [
      { code: 'CNAPS', name: 'Carte professionnelle (CNAPS)', validityMonths: 60 },
      { code: 'SSIAP1', name: 'SSIAP 1 – agent de sécurité incendie', validityMonths: 36 },
      { code: 'H0B0', name: 'Habilitation électrique H0B0', validityMonths: 36 },
      { code: 'PALPATION', name: 'Palpation de sécurité', validityMonths: 60 },
      { code: 'CYNO', name: 'Agent cynophile', validityMonths: 60 },
      { code: 'SST', name: 'Sauveteur secouriste du travail', validityMonths: 24 },
    ],
    skills: { 'tech1.est@exemple.test': ['Rondes', 'SSIAP'], 'tech2.est@exemple.test': ['Levée de doute'], 'tech.nord@exemple.test': ['Rondes', 'Cynophile'], 'tech.bxl@exemple.test': ['Rondes'], 'tech.uk@exemple.test': ['Patrols'] },
    directory: { supplier: 'Centre de télésurveillance (exemple)', manufacturer: 'Fabricant de systèmes d’alarme (exemple)' },
    teamMessage: 'Je repasse au poste de sécurité en fin de ronde, quelqu’un a besoin de quelque chose ?',
  },
  BAILIFF: {
    clients: { [C.durand]: 'Cabinet Durand, avocats', [C.tilleuls]: 'Syndic de la Résidence Les Tilleuls' },
    jobs: {
      [R.visitBoiler]: { kind: 'MAINTENANCE', reason: 'Constat d’affichage du permis de construire – 2e passage' },
      [R.oven]: { kind: 'SAV', reason: 'Constat de dégâts des eaux dans le fournil' },
      [R.aircon]: { kind: 'OTHER', reason: 'Constat de l’état des locaux avant restitution du bail commercial' },
      [R.heatPump]: { kind: 'INSTALLATION', reason: 'Constat d’avancement des travaux d’extension' },
      [R.lighting]: { kind: 'OTHER', reason: 'Constat de nuisances sonores' },
      [R.leak]: { kind: 'SAV', reason: 'Constat d’infiltrations dans les parties communes' },
      [R.ovenService]: { kind: 'MAINTENANCE', reason: 'Constat d’affichage – 3e passage' },
      [R.detector]: { kind: 'SAV', reason: 'Constat de dégradations de la vitrine' },
      [R.bxlBoiler]: { kind: 'OTHER', reason: 'Constat d’état des lieux contradictoire' },
      [R.london]: { kind: 'SAV', reason: 'Damage report: flooding in the basement' },
    },
    quote: { title: 'Constat de dégâts des eaux', lines: [
      { description: 'Procès-verbal de constat avec photographies', quantity: 1, unit: 'u', unitPriceCents: 25_000 },
      { description: 'Frais de déplacement', quantity: 1, unit: 'u', unitPriceCents: 750 },
    ] },
    contract: 'Constats d’affichage périodiques',
    skills: { 'tech1.est@exemple.test': ['Constats immobiliers'], 'tech2.est@exemple.test': ['Constats internet'], 'tech.nord@exemple.test': ['Constats'], 'tech.bxl@exemple.test': ['Constats'], 'tech.uk@exemple.test': ['Inspections'] },
    directory: { supplier: 'Serrurier de garde (exemple)', manufacturer: 'Chambre régionale des commissaires de justice (exemple)' },
    teamMessage: 'Je repasse à l’étude en fin de matinée pour déposer les procès-verbaux signés.',
  },
  EXPERTISE: {
    clients: { [C.durand]: 'Mutuelle Durand Assurances' },
    jobs: {
      [R.visitBoiler]: { kind: 'MAINTENANCE', reason: 'Visite de contrôle de la toiture après tempête', due: 12 },
      [R.oven]: { kind: 'SAV', reason: 'Expertise dégât des eaux – sinistre n° 2026-4471', due: -1 },
      [R.aircon]: { kind: 'SAV', reason: 'Expertise incendie cuisine – sinistre n° 2026-4502', due: 3 },
      [R.heatPump]: { kind: 'INSTALLATION', reason: 'Diagnostics avant vente : DPE, électricité, gaz', due: 6 },
      [R.lighting]: { kind: 'OTHER', reason: 'Contre-expertise du chiffrage des réparations', due: 20 },
      [R.leak]: { kind: 'SAV', reason: 'Expertise infiltration parties communes – sinistre n° 2026-4519', due: 5 },
      [R.ovenService]: { kind: 'INSTALLATION', reason: 'Diagnostic amiante avant travaux', due: 15 },
      [R.detector]: { kind: 'SAV', reason: 'Expertise bris de vitrine – sinistre n° 2026-4530', due: 2 },
      [R.bxlBoiler]: { kind: 'INSTALLATION', reason: 'Diagnostic de performance énergétique', due: 9 },
      [R.london]: { kind: 'SAV', reason: 'Claim inspection: water damage, claim 2026-881', due: 4 },
    },
    quote: { title: 'Diagnostics avant vente', lines: [
      { description: 'Diagnostic de performance énergétique (DPE)', quantity: 1, unit: 'u', unitPriceCents: 12_000 },
      { description: 'Diagnostic électricité', quantity: 1, unit: 'u', unitPriceCents: 9_000 },
      { description: 'Diagnostic gaz', quantity: 1, unit: 'u', unitPriceCents: 9_000 },
    ] },
    contract: 'Visites de contrôle annuelles du patrimoine',
    certifications: [
      { code: 'AMIANTE', name: 'Certification diagnostiqueur amiante', validityMonths: 84 },
      { code: 'DPE', name: 'Certification DPE', validityMonths: 84 },
      { code: 'PLOMB', name: 'Certification plomb (CREP)', validityMonths: 84 },
      { code: 'GAZ', name: 'Certification gaz', validityMonths: 84 },
      { code: 'ELEC', name: 'Certification électricité', validityMonths: 84 },
      { code: 'TERMITES', name: 'Certification termites', validityMonths: 84 },
    ],
    skills: { 'tech1.est@exemple.test': ['Dégâts des eaux', 'Incendie'], 'tech2.est@exemple.test': ['DPE', 'Amiante'], 'tech.nord@exemple.test': ['Bris de glace'], 'tech.bxl@exemple.test': ['Dégâts des eaux'], 'tech.uk@exemple.test': ['Water damage'] },
    directory: { supplier: 'Entreprise de recherche de fuite (exemple)', manufacturer: 'Plateforme sinistres de l’assureur (exemple)' },
    teamMessage: 'Rappel : le rapport du sinistre 2026-4471 est attendu par l’assureur, il est en retard.',
  },
  RENTAL: {
    clients: {
      [C.durand]: 'Agence Durand Immobilier', [C.tilleuls]: 'SCI Les Tilleuls', [C.moreau]: 'M. Moreau (propriétaire)',
      [C.lille]: 'Cabinet Beffroi Gestion', [C.bxl]: 'Gestion du Sablon', [C.london]: 'Riverside Lettings',
    },
    jobs: {
      [R.visitBoiler]: { kind: 'INSTALLATION', reason: 'État des lieux d’entrée – appartement 3 pièces, 2e étage' },
      [R.oven]: { kind: 'SAV', reason: 'État des lieux de sortie – studio' },
      [R.aircon]: { kind: 'MAINTENANCE', reason: 'Pré-état des lieux avant départ du locataire' },
      [R.heatPump]: { kind: 'INSTALLATION', reason: 'État des lieux d’entrée – maison avec jardin' },
      [R.lighting]: { kind: 'OTHER', reason: 'Inventaire du mobilier – location meublée' },
      [R.leak]: { kind: 'SAV', reason: 'État des lieux de sortie – appartement 2 pièces' },
      [R.ovenService]: { kind: 'INSTALLATION', reason: 'État des lieux d’entrée – nouveau locataire du studio' },
      [R.detector]: { kind: 'SAV', reason: 'État des lieux de sortie – local commercial' },
      [R.bxlBoiler]: { kind: 'INSTALLATION', reason: 'État des lieux d’entrée – appartement meublé' },
      [R.london]: { kind: 'SAV', reason: 'Check-out inventory – 2-bedroom flat' },
    },
    quote: { title: 'États des lieux – mandat de gestion', lines: [
      { description: 'État des lieux d’entrée – 3 pièces', quantity: 1, unit: 'u', unitPriceCents: 15_000 },
      { description: 'État des lieux de sortie – 3 pièces', quantity: 1, unit: 'u', unitPriceCents: 15_000 },
    ] },
    contract: 'Mandat : états des lieux du parc géré',
    skills: { 'tech1.est@exemple.test': ['Logements vides'], 'tech2.est@exemple.test': ['Meublés'], 'tech.nord@exemple.test': ['Locaux commerciaux'], 'tech.bxl@exemple.test': ['Logements'], 'tech.uk@exemple.test': ['Inventories'] },
    directory: { supplier: 'Serrurier (changement de serrures, exemple)', manufacturer: 'Fédération des agents immobiliers (exemple)' },
    teamMessage: 'Je récupère les clés du studio à l’agence avant l’état des lieux de sortie.',
  },
  SERVICES: {
    clients: {},
    jobs: {
      [R.visitBoiler]: { kind: 'MAINTENANCE', reason: 'Nettoyage hebdomadaire des parties communes' },
      [R.oven]: { kind: 'OTHER', reason: 'Dératisation du fournil et de la réserve' },
      [R.aircon]: { kind: 'SAV', reason: 'Nettoyage après travaux du cabinet' },
      [R.heatPump]: { kind: 'INSTALLATION', reason: 'Démarrage du contrat d’entretien des espaces verts' },
      [R.lighting]: { kind: 'MAINTENANCE', reason: 'Entretien des vitres' },
      [R.leak]: { kind: 'OTHER', reason: 'Nid de frelons signalé sur la façade' },
      [R.ovenService]: { kind: 'OTHER', reason: 'Contrôle trimestriel des postes d’appâtage' },
      [R.detector]: { kind: 'OTHER', reason: 'Désinsectisation : blattes dans la réserve' },
      [R.bxlBoiler]: { kind: 'MAINTENANCE', reason: 'Entretien mensuel des espaces verts' },
      [R.london]: { kind: 'SAV', reason: 'Deep clean after flood' },
    },
    quote: { title: 'Dératisation complète du local', lines: [
      { description: 'Traitement rongeurs – 3 passages', quantity: 3, unit: 'u', unitPriceCents: 9_000 },
      { description: 'Poste d’appâtage sécurisé', quantity: 6, unit: 'u', unitPriceCents: 1_800 },
    ] },
    contract: 'Contrôle des nuisibles (trimestriel)',
    certifications: [
      { code: 'CERTIBIOCIDE', name: 'Certibiocide (nuisibles)', validityMonths: 60 },
      { code: 'CERTIPHYTO', name: 'Certiphyto (espaces verts)', validityMonths: 60 },
      { code: 'B0', name: 'Habilitation électrique B0', validityMonths: 36 },
      { code: 'CACES-R486', name: 'CACES R486 (nacelles)', validityMonths: 60 },
      { code: 'HAUTEUR', name: 'Travail en hauteur', validityMonths: 36 },
      { code: 'SST', name: 'Sauveteur secouriste du travail', validityMonths: 24 },
    ],
    skills: { 'tech1.est@exemple.test': ['Nuisibles', 'Nettoyage'], 'tech2.est@exemple.test': ['Vitrerie'], 'tech.nord@exemple.test': ['Espaces verts'], 'tech.bxl@exemple.test': ['Nettoyage'], 'tech.uk@exemple.test': ['Cleaning'] },
    directory: { supplier: 'Grossiste produits d’hygiène et biocides (exemple)', manufacturer: 'Fabricant de pièges et postes d’appâtage (exemple)' },
    teamMessage: 'Je passe au dépôt prendre des sachets de raticide, quelqu’un a besoin de produits ?',
  },
};

/** Articles du stock pour Itinéos Services (le stock est masqué dans les autres métiers) */
const SERVICES_ARTICLES: Record<string, { reference: string; name: string; category: string; unit?: string }> = {
  'CD-35': { reference: 'RAT-PATE', name: 'Raticide en pâte (sachets de 10 g)', category: 'Nuisibles', unit: 'kg' },
  'FIL-G4': { reference: 'SAC-100', name: 'Sacs poubelle 100 L (rouleau)', category: 'Nettoyage' },
  'JT-CIRC': { reference: 'GEL-BLAT', name: 'Gel insecticide anti-blattes', category: 'Nuisibles' },
  'RES-6K': { reference: 'POSTE-APP', name: 'Poste d’appâtage sécurisé', category: 'Nuisibles' },
  'GAZ-R32': { reference: 'NETT-MULTI', name: 'Nettoyant multi-surfaces 5 L', category: 'Nettoyage', unit: 'L' },
};

const SIGNATURE = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

/** Habille les données d'exemple pour le métier de l'édition installée */
export async function applySectorDemo(sector: Sector): Promise<void> {
  if (sector === 'TECH') return;
  const demo = DEMOS[sector];

  // Clients et sites (les sites portent le nom du client)
  for (const [from, to] of Object.entries(demo.clients)) {
    await db.update(schema.clients).set({ name: to }).where(eq(schema.clients.name, from));
    await db.update(schema.sites).set({ name: to }).where(eq(schema.sites.name, from));
  }

  // Le matériel des techniciens n'a pas de sens dans les autres métiers
  await db.update(schema.interventions).set({ equipmentId: null, requiredCertificationIds: [] });
  await db.update(schema.contracts).set({ equipmentIds: [], title: demo.contract });
  await db.delete(schema.equipments);

  const [fr] = await db.select().from(schema.companies).where(eq(schema.companies.countryCode, 'FR'));
  const today = todayIn(fr.timezone);
  for (const [from, job] of Object.entries(demo.jobs)) {
    await db.update(schema.interventions)
      .set({ kind: job.kind, reason: job.reason, ...(job.due !== undefined ? { dueDate: addDays(today, job.due) } : {}) })
      .where(eq(schema.interventions.reason, from));
  }
  // Visites du contrat (créées par seed.ts) : leur motif suit le titre du contrat
  await db.update(schema.interventions).set({ reason: demo.contract, kind: 'MAINTENANCE' })
    .where(sql`${schema.interventions.contractId} IS NOT NULL`);

  // Devis
  const [quote] = await db.select().from(schema.quotes).limit(1);
  if (quote) {
    const lines = demo.quote.lines.map((l) => ({ ...l, vatRateBp: 2000 }));
    const totals = documentTotals(lines);
    await db.delete(schema.quoteLines).where(eq(schema.quoteLines.quoteId, quote.id));
    await db.insert(schema.quoteLines).values(lines.map((l, i) => ({ ...l, quoteId: quote.id, position: i })));
    await db.update(schema.quotes).set({ title: demo.quote.title, netCents: totals.netCents, vatCents: totals.vatCents, grossCents: totals.grossCents })
      .where(eq(schema.quotes.id, quote.id));
  }

  // Habilitations, compétences, annuaire, messagerie
  if (demo.certifications) {
    const types = await db.select().from(schema.certificationTypes).orderBy(schema.certificationTypes.createdAt, schema.certificationTypes.code);
    const order = ['B1V', 'BR', 'FLUIDES', 'CACES-R486', 'HAUTEUR', 'SST'];
    for (const [k, code] of order.entries()) {
      const row = types.find((x) => x.code === code);
      const next = demo.certifications[k];
      if (row && next) await db.update(schema.certificationTypes).set({ ...next, description: null }).where(eq(schema.certificationTypes.id, row.id));
    }
  }
  for (const [email, skills] of Object.entries(demo.skills)) {
    await db.update(schema.users).set({ skills }).where(eq(schema.users.email, email));
  }
  await db.update(schema.directoryContacts).set({ organization: demo.directory.supplier, notes: null }).where(eq(schema.directoryContacts.category, 'SUPPLIER'));
  await db.update(schema.directoryContacts).set({ organization: demo.directory.manufacturer, notes: null }).where(eq(schema.directoryContacts.category, 'MANUFACTURER'));
  await db.update(schema.messages).set({ body: demo.teamMessage })
    .where(sql`${schema.messages.body} LIKE 'Je passe au comptoir%'`);
  await db.update(schema.messages).set({ body: sql`replace(${schema.messages.body}, ${C.moreau}, ${demo.clients[C.moreau] ?? C.moreau})` })
    .where(sql`${schema.messages.body} LIKE ${`%${C.moreau}%`}`);

  // ─── Ce qu'il faut pour essayer les fonctions du métier ───
  const site = async (clientName: string) => {
    const [s] = await db.select().from(schema.sites).where(eq(schema.sites.name, demo.clients[clientName] ?? clientName));
    return s;
  };
  const julien = (await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, 'tech1.est@exemple.test')))[0].id;
  const [est] = await db.select().from(schema.agencies).where(eq(schema.agencies.code, 'EST'));

  /** Intervention passée, avec sa fiche signée et envoyée */
  const pastReport = async (s: typeof schema.sites.$inferSelect, kind: InterventionKind, reason: string, daysAgo: number, data: Record<string, unknown>) => {
    const [tpl] = await db.select().from(schema.formTemplates).where(and(
      eq(schema.formTemplates.sector, sector), eq(schema.formTemplates.kind, kind),
      isNull(schema.formTemplates.groupId), sql`${schema.formTemplates.schema}->>'lang' = 'fr'`,
    ));
    const when = new Date(Date.now() - daysAgo * 86_400_000);
    const [iv] = await db.insert(schema.interventions).values({
      groupId: fr.groupId, companyId: fr.id, agencyId: est.id, number: await nextInterventionNumber(db, fr),
      clientId: s.clientId, siteId: s.id, technicianId: julien, kind, reason, status: 'DONE', source: 'Appel client',
      scheduledStart: when, scheduledEnd: new Date(when.getTime() + 3600_000),
    }).returning();
    await db.insert(schema.reports).values({
      interventionId: iv.id, templateId: tpl.id, templateSchema: tpl.schema, data: data as never,
      arrivedAt: when, leftAt: new Date(when.getTime() + 3600_000), laborMinutes: 60, outcome: 'DONE',
      technicianSignature: SIGNATURE, clientSignature: SIGNATURE, clientSignerName: 'Le client',
      status: 'SENT', signedAt: new Date(when.getTime() + 3600_000), sentAt: new Date(when.getTime() + 3700_000),
    });
  };

  if (sector === 'SECURITY') {
    const points: [string, string[]][] = [
      [C.tilleuls, ['Hall d’entrée', 'Parking souterrain – niveau -1', 'Local poubelles', 'Porte de la chaufferie', 'Accès à la toiture-terrasse']],
      [C.moreau, ['Quai de chargement 3', 'Bureau d’accueil', 'Clôture nord', 'Local des chariots']],
    ];
    for (const [client, names] of points) {
      const s = await site(client);
      if (s) await db.insert(schema.checkpoints).values(names.map((name, k) => ({ siteId: s.id, name, code: newCheckpointCode(), position: k + 1 })));
    }
  }

  if (sector === 'RENTAL') {
    // L'état des lieux d'entrée du studio, signé il y a un peu plus d'un an : la sortie de ce jour s'y compare
    const s = await site(C.moreau);
    if (s) {
      await pastReport(s, 'INSTALLATION', 'État des lieux d’entrée – studio', 400, {
        landlord: 'M. Moreau (propriétaire)', tenants: 'Mme Léa Martin', premises: '8 rue Principale, 54520 Laxou', propertyType: 'Studio', furnished: 'Non',
        meterElec: '18 452', meterGas: '—', meterColdWater: '312', meterHotWater: '128',
        roomEntrance: 'Bon état. Sol carrelage propre, murs peints en blanc sans trace.',
        roomLiving: 'Bon état. Parquet sans rayure, peinture refaite à neuf, deux prises fonctionnelles.',
        roomKitchen: 'Bon état. Plaques et hotte propres, plan de travail sans brûlure.',
        roomBedrooms: 'Sans objet (studio).',
        roomBathroom: 'Bon état. Joints de la douche propres, lavabo sans éclat.',
        roomOther: 'Cave n° 4 : propre et vide.',
        keys: '2 clés de la porte, 1 badge de l’immeuble, 1 clé de la boîte aux lettres',
        fittings: ['Détecteur de fumée présent', 'Radiateurs fonctionnent', 'Volets et fenêtres fonctionnent', 'Robinetterie sans fuite'],
      });
    }
  }

  if (sector === 'SERVICES') {
    // Traitements déjà faits : le registre des produits biocides n'est pas vide
    const moreau = await site(C.moreau);
    const lille = await site(C.lille);
    if (moreau) await pastReport(moreau, 'OTHER', 'Dératisation de la réserve', 40, {
      pest: 'Rats / souris', zones: 'Réserve et fournil (périmètre des murs)', baitStations: 6, reentry: 'Immédiat (postes sécurisés)', safetyNotice: true,
      biocides: 'Raticide en pâte à la bromadiolone, autorisation n° FR-2019-0042, 6 sachets de 10 g',
    });
    if (lille) await pastReport(lille, 'OTHER', 'Désinsectisation : blattes en réserve', 15, {
      pest: 'Cafards / blattes', zones: 'Réserve et local technique', baitStations: 0, reentry: '2 heures', safetyNotice: true,
      biocides: 'Gel insecticide à l’indoxacarbe, autorisation n° FR-2020-0117, 12 points de gel',
    });
    for (const [from, to] of Object.entries(SERVICES_ARTICLES)) {
      await db.update(schema.articles).set(to).where(eq(schema.articles.reference, from));
    }
  }
}
