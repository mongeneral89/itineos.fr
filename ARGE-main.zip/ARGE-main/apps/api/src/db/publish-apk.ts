/**
 * Publie une APK sur ce serveur (même dossier STORAGE_DIR que lui), sans passer par le bureau :
 *   npx tsx src/db/publish-apk.ts <fichier.apk> <versionCode> <versionName> ["notes"]
 * Utilisé par lanceurs\construire-apk.ps1 juste après la construction.
 */
import { readFile } from 'node:fs/promises';
import { currentRelease, looksLikeApk, publishRelease, releaseInput } from '../services/app-update.js';

const [file, versionCode, versionName, notes] = process.argv.slice(2);
if (!file || !versionCode || !versionName) {
  console.error('Usage : publish-apk.ts <fichier.apk> <versionCode> <versionName> ["notes"]');
  process.exit(1);
}
const apk = await readFile(file);
if (!looksLikeApk(apk)) {
  console.error(`${file} n'est pas une APK`);
  process.exit(1);
}
const input = releaseInput.parse({ versionCode, versionName, notes });
const current = await currentRelease();
if (current && input.versionCode <= current.versionCode) {
  console.error(`Version ${input.versionCode} déjà dépassée (publiée : ${current.versionCode})`);
  process.exit(1);
}
const r = await publishRelease(apk, input);
console.log(`APK publiée : version ${r.versionName} (${r.versionCode}), ${Math.round(r.size / 1024)} Ko`);
