/**
 * Version A.R.G.E. : la société, ses quatre agences, son logo, ses documents (fiche d'intervention technique,
 * consignes de télésurveillance, dossiers techniques) et son catalogue de matériel, repris de ses documents papier
 * (dossier « docs viere arge »). Voir db/arge/.
 *
 *   npm run db:seed-arge            (ne fait rien si des données existent déjà)
 *   npm run db:seed-arge -- --reset (efface TOUT et recommence)
 *
 * Les informations de la société (adresses, SIRET, agréments CNAPS) sont celles de ses documents. Les personnes,
 * les clients et les interventions sont FICTIFS, pour essayer le logiciel : mot de passe demo1234, adresses en
 * @arge.test et @client.test, numéros de téléphone réservés à la fiction (01 99 00…, 06 39 98…).
 */
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import bcrypt from 'bcryptjs';
import { eq } from 'drizzle-orm';
import { addDays, type Role } from '@itineo/shared';
import { db, pool, schema } from './client.js';
import { migrate } from './migrate.js';
import { wipeData } from './seed.js';
import { alignCompaniesToEdition, ensureSystemTemplates } from '../services/templates.js';
import { storeLogo } from '../services/logo.js';
import { nextInterventionNumber, nextNumber } from '../services/numbering.js';
import { generateContractVisits, todayIn } from '../services/contracts.js';
import { recordMovement } from '../services/stock.js';
import { env } from '../env.js';
import { argeTemplates } from './arge/templates.js';
import { ARGE_CATALOGUE } from './arge/catalogue.js';

const LOGO = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'assets', 'arge', 'logo.png');

/** Mentions du pied des documents ARGE (obligatoires pour une entreprise autorisée par le CNAPS) */
export const ARGE_LEGAL_MENTIONS = 'A.R.G.E. SAS au capital de 40 000 € · SIRET 442 934 857 00032 · 16 rue du Golf, 21800 Quetigny · '
  + 'Tél. 03 80 46 82 50 · contact@arge.fr · www.arge.fr · Agréments CNAPS : Quetigny AUT-021-2119-11-10-20200468323, '
  + 'Vandœuvre-lès-Nancy AUT-054-2119-12-04-20200573838, Fontainebleau AUT077-2113-02-02-20230727194, '
  + 'Villeneuve-d’Ascq AUT-059-2119-10-09-20200469204 · Article L 612-14 du CSI : l’autorisation d’exercice ne confère '
  + 'aucune prérogative de puissance publique à l’entreprise et aux personnes qui en bénéficient';

const reset = process.argv.includes('--reset');

async function main() {
  await migrate();
  const existing = await db.select({ id: schema.groups.id }).from(schema.groups).limit(1);
  if (existing.length && !reset) {
    console.log('La base contient déjà des données. Relancez avec --reset pour tout effacer et recommencer.');
    return;
  }
  if (reset) await wipeData();
  await seedArge();
  console.log(`
Version A.R.G.E. créée. Mot de passe de tous les comptes d'essai : demo1234

  admin@arge.test             Administrateur (tout voir)
  direction@arge.test         Direction
  chef.dijon@arge.test        Chef de l'agence de Dijon (siège, Quetigny)
  planning.dijon@arge.test    Planification, agence de Dijon
  admin.ventes@arge.test      Service administratif (comptabilité, dossiers)
  tech.dijon@arge.test        Technicien Dijon (3 interventions aujourd'hui)
  tech.nancy@arge.test        Technicien Nancy
  tech.lille@arge.test        Technicien Lille
  tech.fontainebleau@arge.test  Technicien Fontainebleau

Espace client : contact@pharmacie-du-lac.client.test
`);
}

/** Crée la version ARGE dans une base vide */
export async function seedArge() {
  await ensureSystemTemplates();

  // ─── Société et agences (adresses de ses documents) ───
  const [group] = await db.insert(schema.groups).values({ name: 'Groupe A.R.G.E.' }).returning();
  const [arge] = await db.insert(schema.companies).values({
    groupId: group.id, name: 'A.R.G.E.', legalName: 'A.R.G.E. SAS', countryCode: 'FR', currency: 'EUR', locale: 'fr-FR',
    timezone: 'Europe/Paris', address: '16 rue du Golf', postalCode: '21800', city: 'Quetigny', email: 'contact@arge.fr',
    phone: '03 80 46 82 50', documentPrefix: 'ARGE', legalMentions: ARGE_LEGAL_MENTIONS, paymentTermsDays: 30,
    // A.R.G.E. signe ses contrats avec DocuSign : lien dans le menu (onglet à part, DocuSign refuse d'être affiché dans Itinéos)
    menuLinks: [{ label: 'DocuSign', url: 'https://app.docusign.com' }],
  }).returning();
  await alignCompaniesToEdition(env.EDITION);
  const logoPath = await storeLogo(arge.id, 'png', await readFile(LOGO));
  await db.update(schema.companies).set({ logoPath, logoUpdatedAt: new Date() }).where(eq(schema.companies.id, arge.id));

  const agencyRows = await db.insert(schema.agencies).values([
    { companyId: arge.id, name: 'Dijon – Quetigny (siège)', code: '21', address: '16 rue du Golf', postalCode: '21800', city: 'Quetigny', phone: '03 80 46 82 50', email: 'contact@arge.fr' },
    { companyId: arge.id, name: 'Nancy', code: '54', address: '23 boulevard de l’Europe', postalCode: '54500', city: 'Vandœuvre-lès-Nancy' },
    { companyId: arge.id, name: 'Lille', code: '59', address: '10 rue Jacques Prévert', postalCode: '59650', city: 'Villeneuve-d’Ascq' },
    { companyId: arge.id, name: 'Fontainebleau', code: '77', address: 'Les Écuries du Roy, 28 rue d’Avon, entrée B', postalCode: '77300', city: 'Fontainebleau' },
  ]).returning();
  const agency = Object.fromEntries(agencyRows.map((a) => [a.code, a])) as Record<'21' | '54' | '59' | '77', (typeof agencyRows)[number]>;

  // ─── Documents ARGE ───
  const templateId: Record<string, string> = {};
  for (const tpl of argeTemplates()) {
    const [row] = await db.insert(schema.formTemplates).values({
      groupId: group.id, companyId: tpl.company ? arge.id : null, name: tpl.name, kind: tpl.kind, schema: tpl.schema,
      // Les documents du groupe se choisissent sur l'intervention
      autoPick: tpl.company,
    }).returning({ id: schema.formTemplates.id });
    templateId[tpl.name] ??= row.id;
  }

  // ─── Comptes d'essai (personnes fictives) ───
  const passwordHash = await bcrypt.hash('demo1234', 10);
  type Grant = { role: Role; agency?: keyof typeof agency };
  const people: { email: string; firstName: string; lastName: string; phone?: string; skills?: string[]; grants: Grant[] }[] = [
    { email: 'admin@arge.test', firstName: 'Admin', lastName: 'ARGE', grants: [{ role: 'GROUP_ADMIN' }] },
    { email: 'direction@arge.test', firstName: 'Claire', lastName: 'Direction', grants: [{ role: 'DIRECTOR' }] },
    { email: 'chef.dijon@arge.test', firstName: 'Paul', lastName: 'Chef', phone: '06 39 98 00 11', grants: [{ role: 'AGENCY_MANAGER', agency: '21' }] },
    { email: 'planning.dijon@arge.test', firstName: 'Sophie', lastName: 'Planning', phone: '06 39 98 00 12', grants: [{ role: 'PLANNER', agency: '21' }] },
    { email: 'admin.ventes@arge.test', firstName: 'Marc', lastName: 'Administratif', grants: [{ role: 'ACCOUNTANT' }] },
    { email: 'tech.dijon@arge.test', firstName: 'Julien', lastName: 'Martin', phone: '06 39 98 00 13', skills: ['Alarme', 'Vidéo', 'Contrôle d’accès'], grants: [{ role: 'TECHNICIAN', agency: '21' }] },
    { email: 'tech2.dijon@arge.test', firstName: 'Lucas', lastName: 'Bernard', phone: '06 39 98 00 14', skills: ['Alarme', 'Générateur de brouillard'], grants: [{ role: 'TECHNICIAN', agency: '21' }] },
    { email: 'tech.nancy@arge.test', firstName: 'Thomas', lastName: 'Petit', phone: '06 39 98 00 15', skills: ['Alarme', 'Vidéo'], grants: [{ role: 'TECHNICIAN', agency: '54' }] },
    { email: 'tech.lille@arge.test', firstName: 'Sarah', lastName: 'Roux', phone: '06 39 98 00 16', skills: ['Vidéo', 'Réseau'], grants: [{ role: 'TECHNICIAN', agency: '59' }] },
    { email: 'tech.fontainebleau@arge.test', firstName: 'Nicolas', lastName: 'Fournier', phone: '06 39 98 00 17', skills: ['Alarme', 'Défibrillateur'], grants: [{ role: 'TECHNICIAN', agency: '77' }] },
  ];
  const userId: Record<string, string> = {};
  for (const person of people) {
    const [u] = await db.insert(schema.users).values({
      groupId: group.id, email: person.email, passwordHash, firstName: person.firstName, lastName: person.lastName,
      phone: person.phone, skills: person.skills ?? [], locale: 'fr-FR',
    }).returning({ id: schema.users.id });
    userId[person.email] = u.id;
    await db.insert(schema.roleAssignments).values(person.grants.map((g) => ({
      userId: u.id, groupId: group.id, role: g.role,
      companyId: g.role === 'GROUP_ADMIN' ? null : arge.id,
      agencyId: g.agency ? agency[g.agency].id : null,
    })));
  }

  // ─── Clients fictifs ───
  async function addClient(input: {
    agency: keyof typeof agency; name: string; email: string; phone: string; address: string; postalCode: string; city: string;
    prom: string; equipment: { category: string; brand?: string; model?: string; serialNumber?: string; location?: string; installedAt?: string; underContract?: boolean };
  }) {
    const [client] = await db.insert(schema.clients).values({
      groupId: group.id, companyId: arge.id, agencyId: agency[input.agency].id, name: input.name, email: input.email,
      phone: input.phone, address: input.address, postalCode: input.postalCode, city: input.city, countryCode: 'FR',
      subscriberNumber: input.prom,
    }).returning();
    const [site] = await db.insert(schema.sites).values({
      clientId: client.id, name: input.name, address: input.address, postalCode: input.postalCode, city: input.city, countryCode: 'FR',
    }).returning();
    const [equipment] = await db.insert(schema.equipments).values({ ...input.equipment, siteId: site.id }).returning();
    return { client, site, equipment };
  }
  const pharmacie = await addClient({
    agency: '21', name: 'Pharmacie du Lac', email: 'contact@pharmacie-du-lac.client.test', phone: '01 99 00 21 01',
    address: '5 place du Marché', postalCode: '21800', city: 'Quetigny', prom: '210451',
    equipment: { category: 'Alarme intrusion', brand: 'Zeus / Hestia', model: 'ARC3800H-FW2', serialNumber: 'ZH-2024-00871', location: 'Réserve', installedAt: '2024-03-12', underContract: true },
  });
  const garage = await addClient({
    agency: '21', name: 'Garage des Saules', email: 'garage.saules@client.test', phone: '01 99 00 21 02',
    address: '18 route de Gray', postalCode: '21000', city: 'Dijon', prom: '210978',
    equipment: { category: 'Vidéoprotection', brand: 'Enregistreur IP', model: '8VIPS5', serialNumber: 'VIP8-55120', location: 'Bureau d’accueil', installedAt: '2023-10-02', underContract: true },
  });
  const famille = await addClient({
    agency: '21', name: 'M. et Mme Garnier', email: 'garnier@client.test', phone: '06 39 98 21 03',
    address: '7 allée des Tilleuls', postalCode: '21121', city: 'Fontaine-lès-Dijon', prom: '211302',
    equipment: { category: 'Alarme intrusion', brand: 'RSI', model: 'WIP 230', location: 'Entrée' },
  });
  const nancy = await addClient({
    agency: '54', name: 'Bijouterie Stanislas', email: 'bijouterie.stanislas@client.test', phone: '01 99 00 54 01',
    address: '3 rue des Dames', postalCode: '54000', city: 'Nancy', prom: '540233',
    equipment: { category: 'Alarme intrusion + générateur de brouillard', brand: 'SPC', model: 'KTSPC4320', serialNumber: 'SPC-43-7781', location: 'Arrière-boutique', installedAt: '2022-06-20', underContract: true },
  });
  const lille = await addClient({
    agency: '59', name: 'Entrepôt Nord Logistique', email: 'securite@nord-logistique.client.test', phone: '01 99 00 59 01',
    address: '40 rue de l’Innovation', postalCode: '59650', city: 'Villeneuve-d’Ascq', prom: '590118',
    equipment: { category: 'Vidéoprotection', brand: 'Enregistreur IP', model: '32VIP', serialNumber: 'VIP32-90311', location: 'Local technique', installedAt: '2021-11-08', underContract: true },
  });
  const fontainebleau = await addClient({
    agency: '77', name: 'Mairie annexe de Bois-le-Roi (exemple)', email: 'services.techniques@client.test', phone: '01 99 00 77 01',
    address: '1 place de la Mairie', postalCode: '77590', city: 'Bois-le-Roi', prom: '770064',
    equipment: { category: 'Défibrillateur', brand: 'Pack défibrillateur', model: 'PACK350P/360P', serialNumber: 'DAE-350-2231', location: 'Hall d’accueil', installedAt: '2024-01-15', underContract: true },
  });

  // ─── Interventions (aujourd'hui et à planifier) ───
  const at = (hour: number, minute = 0) => {
    const d = new Date();
    d.setHours(hour, minute, 0, 0);
    return d;
  };
  async function addIntervention(v: {
    agency: keyof typeof agency; c: Awaited<ReturnType<typeof addClient>>; kind: 'SAV' | 'INSTALLATION' | 'MAINTENANCE';
    reason: string; technician?: string; start?: Date; hours?: number; priority?: 'NORMAL' | 'URGENT' | 'HIGH'; source?: string; document?: string;
  }) {
    await db.insert(schema.interventions).values({
      groupId: group.id, companyId: arge.id, agencyId: agency[v.agency].id, number: await nextInterventionNumber(db, arge),
      clientId: v.c.client.id, siteId: v.c.site.id, equipmentId: v.c.equipment.id,
      technicianId: v.technician ? userId[v.technician] : null, kind: v.kind, reason: v.reason,
      priority: v.priority ?? 'NORMAL', source: v.source ?? 'Appel client',
      status: v.technician && v.start ? 'PLANNED' : 'TO_PLAN',
      scheduledStart: v.start ?? null,
      scheduledEnd: v.start ? new Date(v.start.getTime() + (v.hours ?? 1) * 3600_000) : null,
      templateId: v.document ? templateId[v.document] : null,
      createdById: userId['planning.dijon@arge.test'],
    });
  }
  await addIntervention({ agency: '21', c: pharmacie, kind: 'MAINTENANCE', reason: 'Visite de maintenance annuelle de l’alarme', technician: 'tech.dijon@arge.test', start: at(8, 30), hours: 1, source: 'Contrat' });
  await addIntervention({ agency: '21', c: garage, kind: 'SAV', reason: 'Caméra du portail sans image sur l’enregistreur', technician: 'tech.dijon@arge.test', start: at(10, 30), hours: 1.5, priority: 'HIGH' });
  await addIntervention({ agency: '21', c: famille, kind: 'INSTALLATION', reason: 'Installation d’une alarme RSI WIP 230 et raccordement à la télésurveillance', technician: 'tech.dijon@arge.test', start: at(14), hours: 3, source: 'Devis signé', document: 'Consignes de télésurveillance (Teles)' });
  await addIntervention({ agency: '21', c: pharmacie, kind: 'SAV', reason: 'Défaut tension batterie signalé par Teles', technician: 'tech2.dijon@arge.test', start: at(9), hours: 1, source: 'Télésurveillance' });
  await addIntervention({ agency: '54', c: nancy, kind: 'SAV', reason: 'Absence de test cyclique depuis hier', technician: 'tech.nancy@arge.test', start: at(9, 30), hours: 1, priority: 'URGENT', source: 'Télésurveillance' });
  await addIntervention({ agency: '59', c: lille, kind: 'MAINTENANCE', reason: 'Maintenance annuelle de la vidéoprotection (32 voies)', technician: 'tech.lille@arge.test', start: at(13, 30), hours: 2, source: 'Contrat' });
  await addIntervention({ agency: '77', c: fontainebleau, kind: 'MAINTENANCE', reason: 'Contrôle annuel du défibrillateur (électrodes, batterie)', source: 'Contrat' });
  await addIntervention({ agency: '21', c: garage, kind: 'INSTALLATION', reason: 'Ajout de deux caméras extérieures sur le parking', source: 'Devis signé', document: 'Dossier technique – bon de sortie vidéoprotection' });

  // ─── Contrats de maintenance ───
  const today = todayIn(arge.timezone);
  const contract = (agencyCode: keyof typeof agency, c: Awaited<ReturnType<typeof addClient>>, title: string, annualPriceCents: number, start: number) =>
    ({ agencyCode, c, title, annualPriceCents, start });
  for (const k of [
    contract('21', pharmacie, 'Maintenance et télésurveillance de l’alarme', 54_000, 40),
    contract('21', garage, 'Maintenance de la vidéoprotection', 42_000, 25),
    contract('54', nancy, 'Maintenance alarme et générateur de brouillard', 66_000, 60),
    contract('59', lille, 'Maintenance de la vidéoprotection', 96_000, 90),
    contract('77', fontainebleau, 'Maintenance du défibrillateur', 18_000, 15),
  ]) {
    await db.insert(schema.contracts).values({
      groupId: group.id, companyId: arge.id, agencyId: agency[k.agencyCode].id, number: await nextNumber(db, arge, 'contract'),
      clientId: k.c.client.id, siteId: k.c.site.id, equipmentIds: [k.c.equipment.id], title: k.title,
      frequencyMonths: 12, startDate: addDays(today, k.start), annualPriceCents: k.annualPriceCents,
      createdById: userId['chef.dijon@arge.test'],
    });
  }
  await generateContractVisits();

  // ─── Portail client : un accès déjà activé à la Pharmacie du Lac ───
  await db.insert(schema.portalUsers).values({
    groupId: group.id, clientId: pharmacie.client.id, email: 'contact@pharmacie-du-lac.client.test', name: 'Hélène Moreau (exemple)',
    passwordHash, locale: 'fr-FR', invitedAt: new Date(), passwordChangedAt: null,
  });

  // ─── Stock : le catalogue des bons de sortie, un dépôt par agence (21, 54, 59, 77), les véhicules ───
  const catalog = await db.insert(schema.articles).values(
    ARGE_CATALOGUE.map((a) => ({ ...a, groupId: group.id, companyId: arge.id, vatRateBp: 2000 })),
  ).returning();
  const art = Object.fromEntries(catalog.map((x) => [x.reference, x]));
  const depots = await db.insert(schema.stockLocations).values(agencyRows.map((a) => ({
    groupId: group.id, companyId: arge.id, agencyId: a.id, kind: 'DEPOT' as const, name: `Dépôt ${a.code} – ${a.name}`,
  }))).returning();
  const techs = people.filter((p) => p.grants.some((g) => g.role === 'TECHNICIAN'));
  const vans = await db.insert(schema.stockLocations).values(techs.map((t) => ({
    groupId: group.id, companyId: arge.id, agencyId: agency[t.grants[0].agency!].id, kind: 'VEHICLE' as const,
    name: `Véhicule de ${t.firstName} ${t.lastName}`, technicianId: userId[t.email],
  }))).returning();
  // Stock d'exemple : quelques articles courants dans chaque dépôt (à remplacer par l'inventaire réel)
  const base = { groupId: group.id, companyId: arge.id, userId: userId['planning.dijon@arge.test'] };
  const starter: [string, number][] = [
    ['ARC3800H-FW2', 4], ['POST', 10], ['ARK30T-W2', 6], ['ARD1233-W2', 12], ['ARD323-W2', 20], ['HY-SA21A-W2', 8],
    ['ARA24-W2', 10], ['ARA13-W2', 4], ['FX1207', 10], ['LR06 1,5V', 40], ['CAMIPTIOCINT', 6], ['CAMIPEXT', 6],
    ['8VIPS5', 2], ['4TO', 3], ['RJ45/CAT6', 10], ['PFA135', 6],
  ];
  await db.transaction(async (tx) => {
    for (const depot of depots) {
      for (const [ref, q] of starter) {
        await recordMovement(tx, { ...base, articleId: art[ref].id, kind: 'RECEIPT', toLocationId: depot.id, quantity: q, note: 'Stock d’exemple' });
      }
    }
    for (const van of vans) {
      const depot = depots.find((d) => d.agencyId === van.agencyId)!;
      for (const [ref, q] of [['ARD323-W2', 4], ['ARD1233-W2', 2], ['LR06 1,5V', 8], ['FX1207', 2], ['RJ45/CAT6', 2]] as const) {
        await recordMovement(tx, { ...base, articleId: art[ref].id, kind: 'TRANSFER', fromLocationId: depot.id, toLocationId: van.id, quantity: q, note: 'Dotation du véhicule' });
      }
    }
  });

  // ─── Véhicules (fictifs) ───
  for (const [i, t] of techs.entries()) {
    const van = vans.find((v) => v.technicianId === userId[t.email])!;
    await db.insert(schema.vehicles).values({
      groupId: group.id, companyId: arge.id, agencyId: van.agencyId, plate: `AR-${String(101 + i)}-GE`, type: 'VAN',
      make: i % 2 ? 'Peugeot' : 'Renault', model: i % 2 ? 'Partner' : 'Kangoo Van', fuel: 'Diesel', ownership: 'LEASED',
      mileage: 30_000 + i * 11_500, mileageUpdatedOn: addDays(today, -3), driverId: userId[t.email], stockLocationId: van.id,
    });
  }

  // ─── Habilitations des installateurs ───
  const types = await db.insert(schema.certificationTypes).values([
    { code: 'BR', name: 'Habilitation électrique BR', validityMonths: 36, description: 'Interventions BT générales (raccordement des centrales, alimentations)' },
    { code: 'B1V', name: 'Habilitation électrique B1V', validityMonths: 36 },
    { code: 'HAUTEUR', name: 'Travail en hauteur', validityMonths: 36, description: 'Pose de sirènes extérieures, caméras, détecteurs en hauteur' },
    { code: 'CACES-R486', name: 'CACES R486 (nacelles)', validityMonths: 60 },
    { code: 'SST', name: 'Sauveteur secouriste du travail', validityMonths: 24 },
  ].map((x) => ({ ...x, groupId: group.id }))).returning();
  const type = Object.fromEntries(types.map((x) => [x.code, x]));
  await db.insert(schema.userCertifications).values([
    { userId: userId['tech.dijon@arge.test'], typeId: type.BR.id, obtainedOn: addDays(today, -400), expiresOn: addDays(today, 690) },
    { userId: userId['tech.dijon@arge.test'], typeId: type.HAUTEUR.id, obtainedOn: addDays(today, -1060), expiresOn: addDays(today, 35) },
    { userId: userId['tech2.dijon@arge.test'], typeId: type.BR.id, obtainedOn: addDays(today, -1100), expiresOn: addDays(today, -5) },
    { userId: userId['tech.nancy@arge.test'], typeId: type.BR.id, obtainedOn: addDays(today, -200), expiresOn: addDays(today, 890) },
    { userId: userId['tech.lille@arge.test'], typeId: type['CACES-R486'].id, obtainedOn: addDays(today, -300), expiresOn: addDays(today, 1500) },
  ]);

  // ─── Annuaire ───
  await db.insert(schema.directoryContacts).values([
    { groupId: group.id, companyId: arge.id, agencyId: null, category: 'SUPPLIER', name: 'Teles', organization: 'Centre de télésurveillance',
      notes: 'Destinataire des consignes de télésurveillance. Numéro à compléter.' },
    { groupId: group.id, companyId: arge.id, agencyId: null, category: 'ADMINISTRATION', name: 'Partenaires financiers', organization: 'Grenke, NBB Lease, Locam',
      notes: 'Contrats de location : envoyés par DocuSign ou sur papier (voir le dossier technique).' },
    { groupId: group.id, companyId: null, agencyId: null, category: 'EMERGENCY', name: 'Numéro d’urgence européen', phone: '112' },
  ]);
}

// Exécution directe : npm run db:seed-arge
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  main()
    .catch((err) => {
      console.error(err);
      process.exitCode = 1;
    })
    .finally(() => pool.end());
}
