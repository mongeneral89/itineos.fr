/**
 * Crée le premier compte administrateur sur une installation neuve (sans données d'exemple).
 *
 *   npm run admin:create -w @itineo/api -- --email vous@societe.fr --first Prénom --last Nom --group "Nom du groupe"
 *
 * Un mot de passe provisoire est affiché une seule fois : changez-le à la première connexion
 * (menu « Mon compte »). Les sociétés et agences se créent ensuite depuis l'écran Organisation.
 */
import { randomBytes } from 'node:crypto';
import { parseArgs } from 'node:util';
import bcrypt from 'bcryptjs';
import { eq, sql } from 'drizzle-orm';
import { db, pool, schema } from './client.js';
import { migrate } from './migrate.js';
import { ensureSystemTemplates } from '../services/templates.js';

async function main() {
  const { values } = parseArgs({
    options: {
      email: { type: 'string' },
      first: { type: 'string' },
      last: { type: 'string' },
      group: { type: 'string', default: 'Mon groupe' },
    },
  });
  if (!values.email || !values.first || !values.last) {
    console.error('Usage : npm run admin:create -w @itineo/api -- --email vous@societe.fr --first Prénom --last Nom [--group "Nom du groupe"]');
    process.exitCode = 1;
    return;
  }
  const email = values.email.trim().toLowerCase();

  await migrate();
  await ensureSystemTemplates();

  const [taken] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(sql`lower(${schema.users.email})`, email));
  if (taken) {
    console.error(`Un compte existe déjà avec l'e-mail ${email}.`);
    process.exitCode = 1;
    return;
  }

  const groups = await db.select().from(schema.groups);
  if (groups.length > 1) {
    console.error('Plusieurs groupes existent déjà : créez les comptes depuis l’écran Organisation.');
    process.exitCode = 1;
    return;
  }
  const group = groups[0] ?? (await db.insert(schema.groups).values({ name: values.group! }).returning())[0];

  const password = randomBytes(12).toString('base64url');
  const [user] = await db.insert(schema.users).values({
    groupId: group.id,
    email,
    passwordHash: await bcrypt.hash(password, 10),
    firstName: values.first,
    lastName: values.last,
  }).returning({ id: schema.users.id });
  await db.insert(schema.roleAssignments).values({ userId: user.id, groupId: group.id, role: 'GROUP_ADMIN', companyId: null, agencyId: null });

  console.log(`
Compte administrateur créé pour le groupe « ${group.name} ».

  E-mail                 : ${email}
  Mot de passe provisoire : ${password}

Connectez-vous, puis changez ce mot de passe dans « Mon compte ».
Créez ensuite vos sociétés et agences depuis l'écran « Organisation ».
`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
