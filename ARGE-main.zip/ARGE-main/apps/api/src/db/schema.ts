/**
 * Modèle de données.
 *
 * Organisation : Groupe → Sociétés (une par pays ou par entité juridique) → Agences → Équipes → Utilisateurs.
 * Toutes les données métier portent groupId + companyId (et agencyId quand c'est pertinent),
 * ce qui permet de cloisonner l'accès par périmètre.
 */
import {
  pgTable, pgEnum, uuid, text, varchar, timestamp, boolean, integer, jsonb, date,
  doublePrecision, uniqueIndex, index, primaryKey, bigint, unique,
} from 'drizzle-orm/pg-core';
import {
  ROLES, INTERVENTION_KINDS, INTERVENTION_STATUSES, PRIORITIES, REPORT_STATUSES, PHOTO_KINDS,
  QUOTE_KINDS, QUOTE_STATUSES, CONTRACT_STATUSES, INVOICE_KINDS, INVOICE_STATUSES, PAYMENT_METHODS,
  STOCK_LOCATION_KINDS, STOCK_MOVEMENT_KINDS, SLIP_STATUSES,
  VEHICLE_TYPES, VEHICLE_STATUSES, OWNERSHIPS, VEHICLE_DEADLINE_KINDS, VEHICLE_EVENT_KINDS, DIRECTORY_CATEGORIES,
  PROCEDURE_CATEGORIES, PROCEDURE_STATUSES, SIM_STATUSES,
  type TemplateSchema, type ReportData, type Sector, type CheckpointScan,
} from '@itineo/shared';

export const roleEnum = pgEnum('role', ROLES);
export const kindEnum = pgEnum('intervention_kind', INTERVENTION_KINDS);
export const statusEnum = pgEnum('intervention_status', INTERVENTION_STATUSES);
export const priorityEnum = pgEnum('priority', PRIORITIES);
export const reportStatusEnum = pgEnum('report_status', REPORT_STATUSES);
export const clientTypeEnum = pgEnum('client_type', ['COMPANY', 'INDIVIDUAL']);

const id = () => uuid('id').primaryKey().defaultRandom();
const createdAt = () => timestamp('created_at', { withTimezone: true }).notNull().defaultNow();

// ─── Organisation ────────────────────────────────────────────────────────

export const groups = pgTable('groups', {
  id: id(),
  name: text('name').notNull(),
  createdAt: createdAt(),
});

export const companies = pgTable('companies', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  name: text('name').notNull(),
  legalName: text('legal_name'),
  countryCode: varchar('country_code', { length: 2 }).notNull(), // ISO 3166 : FR, BE, GB…
  currency: varchar('currency', { length: 3 }).notNull(), // ISO 4217 : EUR, GBP…
  locale: text('locale').notNull().default('fr-FR'), // langue des documents
  timezone: text('timezone').notNull().default('Europe/Paris'),
  vatNumber: text('vat_number'),
  /** SIREN (ou SIRET) : obligatoire sur les factures électroniques */
  siren: text('siren'),
  /** Option pour le paiement de la TVA d'après les débits */
  vatOnDebits: boolean('vat_on_debits').notNull().default(false),
  /** Plateforme agréée de facture électronique : API, jeton (jamais renvoyé au navigateur), envoi automatique */
  einvoiceApiUrl: text('einvoice_api_url'),
  einvoiceApiToken: text('einvoice_api_token'),
  einvoiceAutoSend: boolean('einvoice_auto_send').notNull().default(false),
  address: text('address'),
  postalCode: text('postal_code'),
  city: text('city'),
  email: text('email'),
  phone: text('phone'),
  documentPrefix: varchar('document_prefix', { length: 8 }).notNull(), // préfixe des numéros de fiche
  legalMentions: text('legal_mentions'), // pied de page des documents
  // Facturation
  paymentTermsDays: integer('payment_terms_days').notNull().default(30),
  hourlyRateCents: bigint('hourly_rate_cents', { mode: 'number' }),
  travelFeeCents: bigint('travel_fee_cents', { mode: 'number' }),
  bankDetails: text('bank_details'),
  /** Prélèvement SEPA : identifiant créancier (ICS) et compte qui reçoit les prélèvements */
  sepaCreditorId: text('sepa_creditor_id'),
  sepaIban: text('sepa_iban'),
  sepaBic: text('sepa_bic'),
  /** Relances des impayés : envoi automatique, et jours après l'échéance pour le rappel, la relance, la mise en demeure */
  dunningEnabled: boolean('dunning_enabled').notNull().default(false),
  dunningDays: integer('dunning_days').array().notNull().default([7, 15, 30]),
  /** Cartes SIM : prestataire et site web où se fait l'activation */
  simProvider: text('sim_provider'),
  simPortalUrl: text('sim_portal_url'),
  /** Suggestion d'attribution des interventions (désactivée par défaut) */
  assignSuggestions: boolean('assign_suggestions').notNull().default(false),
  /** Localiser les adresses des sites pour calculer les distances */
  geocodeSites: boolean('geocode_sites').notNull().default(false),
  /** Liens dans le menu vers les outils en ligne de la société (DocuSign, banque…), ouverts dans un onglet à part */
  menuLinks: jsonb('menu_links').$type<{ label: string; url: string }[]>().notNull().default([]),
  /** Secteur d'activité : vocabulaire, modules visibles et modèles de fiches fournis */
  sector: text('sector').$type<Sector>().notNull().default('TECH'),
  /** Logo (PNG ou JPEG, dans STORAGE_DIR/logos) : écrans, espace client, en-tête des PDF */
  logoPath: text('logo_path'),
  logoUpdatedAt: timestamp('logo_updated_at', { withTimezone: true }),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
}, (t) => [index('companies_group_idx').on(t.groupId)]);

export const agencies = pgTable('agencies', {
  id: id(),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  name: text('name').notNull(),
  code: varchar('code', { length: 16 }).notNull(),
  address: text('address'),
  postalCode: text('postal_code'),
  city: text('city'),
  email: text('email'),
  phone: text('phone'),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('agencies_company_code_uq').on(t.companyId, t.code)]);

export const teams = pgTable('teams', {
  id: id(),
  agencyId: uuid('agency_id').notNull().references(() => agencies.id),
  name: text('name').notNull(),
});

// ─── Utilisateurs et droits ──────────────────────────────────────────────

export const users = pgTable('users', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  email: text('email').notNull(),
  passwordHash: text('password_hash').notNull(),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  phone: text('phone'),
  locale: text('locale').notNull().default('fr-FR'),
  teamId: uuid('team_id').references(() => teams.id),
  skills: text('skills').array().notNull().default([]), // compétences : clim, électricité…
  active: boolean('active').notNull().default(true),
  // Les sessions ouvertes avant cette date sont refusées
  passwordChangedAt: timestamp('password_changed_at', { withTimezone: true }),
  /** Partage de position activé par le technicien lui-même (vide = pas de partage) */
  locationSharingSince: timestamp('location_sharing_since', { withTimezone: true }),
  /** « Déconnecter tous mes appareils » : les sessions ouvertes avant cette date sont refusées */
  sessionsRevokedAt: timestamp('sessions_revoked_at', { withTimezone: true }),
  /** Planning de l'équipe vu par le technicien : le sien, son agence, ou les collègues choisis (planning_shares) */
  planningView: text('planning_view', { enum: ['OWN', 'AGENCY', 'CUSTOM'] }).notNull().default('OWN'),
  /** Préférences de notification (voir services/notify.ts) */
  notifyPrefs: jsonb('notify_prefs').$type<Partial<Record<string, boolean>>>().notNull().default({}),
  /** Le bureau a demandé une synchronisation : l'appli terrain recharge la journée et les fiches */
  syncRequestedAt: timestamp('sync_requested_at', { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('users_email_uq').on(t.email)]);

/** Collègues dont un technicien voit le planning (quand planningView = CUSTOM) */
export const planningShares = pgTable('planning_shares', {
  viewerId: uuid('viewer_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  targetId: uuid('target_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
}, (t) => [primaryKey({ columns: [t.viewerId, t.targetId] })]);

/** Téléphones et navigateurs abonnés aux notifications (Web Push) */
export const pushSubscriptions = pgTable('push_subscriptions', {
  id: id(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  endpoint: text('endpoint').notNull().unique(),
  p256dh: text('p256dh').notNull(),
  auth: text('auth').notNull(),
  userAgent: text('user_agent'),
  createdAt: createdAt(),
  lastUsedAt: timestamp('last_used_at', { withTimezone: true }),
}, (t) => [index('push_subscriptions_user_idx').on(t.userId)]);

/** Centre de notifications : la cloche du logiciel garde chaque notification, même si l'appareil l'a ratée */
export const notifications = pgTable('notifications', {
  id: id(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  kind: text('kind').notNull(),
  title: text('title').notNull(),
  body: text('body').notNull(),
  url: text('url').notNull(),
  createdAt: createdAt(),
  readAt: timestamp('read_at', { withTimezone: true }),
}, (t) => [index('notifications_user_idx').on(t.userId, t.createdAt)]);

/** Invitations : lien personnel à usage unique (empreinte seulement), puis code court pour ouvrir l'appli connectée */
export const invitations = pgTable('invitations', {
  id: id(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  usedAt: timestamp('used_at', { withTimezone: true }),
  appCodeHash: text('app_code_hash'),
  appCodeExpiresAt: timestamp('app_code_expires_at', { withTimezone: true }),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('invitations_token_uq').on(t.tokenHash), index('invitations_user_idx').on(t.userId)]);

/** Liens « mot de passe oublié » : seule l'empreinte du jeton est stockée */
export const passwordResets = pgTable('password_resets', {
  id: id(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  usedAt: timestamp('used_at', { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [
  uniqueIndex('password_resets_token_uq').on(t.tokenHash),
  index('password_resets_user_idx').on(t.userId),
]);

/**
 * Un utilisateur peut avoir plusieurs rôles, chacun sur un périmètre :
 *  - companyId et agencyId vides → tout le groupe
 *  - companyId seul → toute la société
 *  - companyId + agencyId → une agence
 */
export const roleAssignments = pgTable('role_assignments', {
  id: id(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  role: roleEnum('role').notNull(),
  companyId: uuid('company_id').references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
}, (t) => [index('role_assignments_user_idx').on(t.userId)]);

// ─── Clients, sites, équipements ─────────────────────────────────────────

export const clients = pgTable('clients', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  /** Vide = client partagé par toutes les agences de la société */
  agencyId: uuid('agency_id').references(() => agencies.id),
  type: clientTypeEnum('type').notNull().default('COMPANY'),
  name: text('name').notNull(),
  email: text('email'),
  phone: text('phone'),
  address: text('address'),
  postalCode: text('postal_code'),
  city: text('city'),
  countryCode: varchar('country_code', { length: 2 }),
  externalRef: text('external_ref'), // référence dans un autre logiciel (comptabilité, ERP)
  /** Entreprise cliente : SIREN et n° de TVA, obligatoires sur les factures électroniques */
  siren: text('siren'),
  vatNumber: text('vat_number'),
  /** N° d'abonné (télésurveillance, contrat…) */
  subscriberNumber: text('subscriber_number'),
  notes: text('notes'),
  /** Langue des documents envoyés au client ; vide = langue de la société */
  locale: text('locale'),
  createdAt: createdAt(),
}, (t) => [index('clients_company_idx').on(t.companyId)]);

export const contacts = pgTable('contacts', {
  id: id(),
  clientId: uuid('client_id').notNull().references(() => clients.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  email: text('email'),
  phone: text('phone'),
  role: text('role'),
});

export const sites = pgTable('sites', {
  id: id(),
  clientId: uuid('client_id').notNull().references(() => clients.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  address: text('address'),
  postalCode: text('postal_code'),
  city: text('city'),
  countryCode: varchar('country_code', { length: 2 }),
  accessNotes: text('access_notes'),
  latitude: doublePrecision('latitude'),
  longitude: doublePrecision('longitude'),
  /** MANUAL, GEOCODED (adresse localisée) ou ON_SITE (position du technicien sur place) */
  geoSource: text('geo_source'),
});

export const equipments = pgTable('equipments', {
  id: id(),
  siteId: uuid('site_id').notNull().references(() => sites.id, { onDelete: 'cascade' }),
  category: text('category').notNull(),
  brand: text('brand'),
  model: text('model'),
  serialNumber: text('serial_number'),
  location: text('location'),
  installedAt: date('installed_at'),
  warrantyUntil: date('warranty_until'),
  underContract: boolean('under_contract').notNull().default(false),
  notes: text('notes'),
  /** Pour le retrouver sur place (« derrière la trappe du placard de l'entrée ») */
  locateHint: text('locate_hint'),
});

// ─── Modèles de fiches ───────────────────────────────────────────────────

export const formTemplates = pgTable('form_templates', {
  id: id(),
  /** groupId et companyId vides = modèle neutre fourni par Itinéos */
  groupId: uuid('group_id').references(() => groups.id),
  companyId: uuid('company_id').references(() => companies.id),
  name: text('name').notNull(),
  kind: kindEnum('kind').notNull(),
  version: integer('version').notNull().default(1),
  schema: jsonb('schema').$type<TemplateSchema>().notNull(),
  /** Modèle fourni pour un secteur (vide = neutre : techniciens, ou document commun à tous) */
  sector: text('sector').$type<Sector>(),
  /** Faux = « document à choisir » sur l'intervention, jamais pris d'office pour une nouvelle fiche */
  autoPick: boolean('auto_pick').notNull().default(true),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
});

// ─── Interventions et fiches ─────────────────────────────────────────────

export const interventions = pgTable('interventions', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').notNull().references(() => agencies.id),
  number: text('number').notNull(),
  clientId: uuid('client_id').notNull().references(() => clients.id),
  siteId: uuid('site_id').notNull().references(() => sites.id),
  equipmentId: uuid('equipment_id').references(() => equipments.id),
  technicianId: uuid('technician_id').references(() => users.id),
  kind: kindEnum('kind').notNull(),
  status: statusEnum('status').notNull().default('TO_PLAN'),
  priority: priorityEnum('priority').notNull().default('NORMAL'),
  source: text('source'), // appel, e-mail, portail, contrat, devis
  reason: text('reason').notNull(),
  scheduledStart: timestamp('scheduled_start', { withTimezone: true }),
  scheduledEnd: timestamp('scheduled_end', { withTimezone: true }),
  /** Visite d'un contrat d'entretien / travaux d'un devis accepté */
  contractId: uuid('contract_id'),
  quoteId: uuid('quote_id'),
  /** Date à laquelle l'intervention est attendue (échéance d'une visite de contrat) */
  dueDate: date('due_date', { mode: 'string' }),
  /** Habilitations exigées du technicien (types d'habilitation) */
  requiredCertificationIds: uuid('required_certification_ids').array().notNull().default([]),
  /** Matériel à prévoir (sert à la suggestion d'attribution : stock des véhicules) */
  /** Document à remplir choisi pour cette intervention (sinon : modèle par défaut de son type) */
  templateId: uuid('template_id'),
  neededParts: jsonb('needed_parts').$type<{ articleId: string; quantity: number }[]>().notNull().default([]),
  /** Demande faite par le client sur le portail : qui, et ses disponibilités / précisions */
  requestedByPortalUserId: uuid('requested_by_portal_user_id'),
  clientNotes: text('client_notes'),
  /** Annulation : motif, date et auteur (le technicien concerné est prévenu) */
  cancelReason: text('cancel_reason'),
  cancelledAt: timestamp('cancelled_at', { withTimezone: true }),
  cancelledById: uuid('cancelled_by_id').references(() => users.id),
  createdById: uuid('created_by_id').references(() => users.id),
  /** Dernière personne du bureau qui l'a attribuée ou placée dans le planning (prévenue quand elle est terminée) */
  plannedById: uuid('planned_by_id').references(() => users.id),
  /** Retard signalé au bureau (une seule fois) */
  lateNotifiedAt: timestamp('late_notified_at', { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex('interventions_company_number_uq').on(t.companyId, t.number),
  index('interventions_agency_start_idx').on(t.agencyId, t.scheduledStart),
  index('interventions_technician_idx').on(t.technicianId),
]);

export const reports = pgTable('reports', {
  id: id(),
  interventionId: uuid('intervention_id').notNull().references(() => interventions.id, { onDelete: 'cascade' }),
  templateId: uuid('template_id').notNull().references(() => formTemplates.id),
  /** Copie du modèle au moment de la fiche : une fiche signée ne change jamais */
  templateSchema: jsonb('template_schema').$type<TemplateSchema>().notNull(),
  data: jsonb('data').$type<ReportData>().notNull().default({}),
  arrivedAt: timestamp('arrived_at', { withTimezone: true }),
  leftAt: timestamp('left_at', { withTimezone: true }),
  laborMinutes: integer('labor_minutes'),
  travelMinutes: integer('travel_minutes'),
  outcome: text('outcome'),
  technicianSignature: text('technician_signature'), // image PNG en data URL
  clientSignature: text('client_signature'),
  clientSignerName: text('client_signer_name'),
  clientAbsent: boolean('client_absent').notNull().default(false),
  clientAbsentReason: text('client_absent_reason'),
  status: reportStatusEnum('status').notNull().default('DRAFT'),
  signedAt: timestamp('signed_at', { withTimezone: true }),
  pdfPath: text('pdf_path'),
  sentAt: timestamp('sent_at', { withTimezone: true }),
  sentTo: text('sent_to'),
  /** Itinéos Vigie : points de passage pointés pendant la ronde */
  checkpointScans: jsonb('checkpoint_scans').$type<CheckpointScan[]>().notNull().default([]),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('reports_intervention_uq').on(t.interventionId)]);

export const reportParts = pgTable('report_parts', {
  id: id(),
  reportId: uuid('report_id').notNull().references(() => reports.id, { onDelete: 'cascade' }),
  label: text('label').notNull(),
  reference: text('reference'),
  quantity: doublePrecision('quantity').notNull().default(1),
  /** Article du catalogue (déduit du véhicule du technicien à la signature) */
  articleId: uuid('article_id'),
});

/** Photos de la fiche : le fichier est sur disque (STORAGE_DIR), la base garde la description */
export const reportPhotos = pgTable('report_photos', {
  id: id(),
  reportId: uuid('report_id').notNull().references(() => reports.id, { onDelete: 'cascade' }),
  // Identifiant créé par l'appareil : un renvoi après coupure réseau ne crée pas de doublon
  clientId: uuid('client_id').notNull(),
  kind: text('kind', { enum: PHOTO_KINDS }).notNull(),
  caption: text('caption'),
  mimeType: text('mime_type').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  filePath: text('file_path').notNull(),
  /** Heure de prise de vue sur l'appareil (photo envoyée plus tard sans réseau) */
  takenAt: timestamp('taken_at', { withTimezone: true }),
  /** Empreinte SHA-256 du fichier reçu : prouve que la photo n'a pas été modifiée depuis */
  sha256: text('sha256'),
  createdBy: uuid('created_by').references(() => users.id),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('report_photos_client_uq').on(t.reportId, t.clientId)]);

/** Itinéos Vigie : points de passage d'un site (QR code collé sur place, pointé pendant la ronde) */
export const checkpoints = pgTable('checkpoints', {
  id: id(),
  siteId: uuid('site_id').notNull().references(() => sites.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  code: text('code').notNull().unique(),
  position: integer('position').notNull().default(0),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
}, (t) => [index('checkpoints_site_idx').on(t.siteId)]);

// ─── Technique ───────────────────────────────────────────────────────────

/** Compteurs de numérotation des fiches, par société et par année */
export const counters = pgTable('counters', {
  companyId: uuid('company_id').notNull().references(() => companies.id),
  /** intervention, quote, contract, invoice : une suite de numéros par type de document */
  kind: text('kind').notNull().default('intervention'),
  year: integer('year').notNull(),
  value: integer('value').notNull().default(0),
}, (t) => [primaryKey({ columns: [t.companyId, t.kind, t.year] })]);

// ─── Devis et contrats ───────────────────────────────────────────────────

export const quotes = pgTable('quotes', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  number: text('number').notNull(),
  clientId: uuid('client_id').notNull().references(() => clients.id),
  siteId: uuid('site_id').references(() => sites.id),
  kind: text('kind', { enum: QUOTE_KINDS }).notNull().default('WORK'),
  status: text('status', { enum: QUOTE_STATUSES }).notNull().default('DRAFT'),
  title: text('title').notNull(),
  intro: text('intro'),
  notes: text('notes'),
  validUntil: date('valid_until', { mode: 'string' }),
  contractFrequencyMonths: integer('contract_frequency_months'),
  currency: varchar('currency', { length: 3 }).notNull(),
  netCents: bigint('net_cents', { mode: 'number' }).notNull().default(0),
  vatCents: bigint('vat_cents', { mode: 'number' }).notNull().default(0),
  grossCents: bigint('gross_cents', { mode: 'number' }).notNull().default(0),
  sourceInterventionId: uuid('source_intervention_id').references(() => interventions.id),
  createdById: uuid('created_by_id').references(() => users.id),
  sentAt: timestamp('sent_at', { withTimezone: true }),
  sentTo: text('sent_to'),
  decidedAt: timestamp('decided_at', { withTimezone: true }),
  /** Réponse donnée par le client sur le portail */
  decidedByPortalUserId: uuid('decided_by_portal_user_id'),
  decisionName: text('decision_name'),
  decisionNote: text('decision_note'),
  pdfPath: text('pdf_path'),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('quotes_company_number_uq').on(t.companyId, t.number), index('quotes_client_idx').on(t.clientId)]);

export const quoteLines = pgTable('quote_lines', {
  id: id(),
  quoteId: uuid('quote_id').notNull().references(() => quotes.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(),
  description: text('description').notNull(),
  quantity: doublePrecision('quantity').notNull().default(1),
  unit: text('unit'),
  unitPriceCents: bigint('unit_price_cents', { mode: 'number' }).notNull().default(0),
  vatRateBp: integer('vat_rate_bp').notNull().default(2000),
}, (t) => [index('quote_lines_quote_idx').on(t.quoteId)]);

export const contracts = pgTable('contracts', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').notNull().references(() => agencies.id),
  number: text('number').notNull(),
  clientId: uuid('client_id').notNull().references(() => clients.id),
  siteId: uuid('site_id').notNull().references(() => sites.id),
  equipmentIds: uuid('equipment_ids').array().notNull().default([]),
  title: text('title').notNull(),
  status: text('status', { enum: CONTRACT_STATUSES }).notNull().default('ACTIVE'),
  frequencyMonths: integer('frequency_months').notNull(),
  startDate: date('start_date', { mode: 'string' }).notNull(),
  endDate: date('end_date', { mode: 'string' }),
  visitHours: doublePrecision('visit_hours').notNull().default(1),
  annualPriceCents: bigint('annual_price_cents', { mode: 'number' }),
  /** Facturation de l'abonnement : période en mois (vide = pas de facturation en lot), à terme à échoir */
  billingMonths: integer('billing_months'),
  /** Contrat déjà facturé jusqu'à cette date (incluse) */
  billedUntil: date('billed_until', { mode: 'string' }),
  notes: text('notes'),
  quoteId: uuid('quote_id').references(() => quotes.id),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('contracts_company_number_uq').on(t.companyId, t.number), index('contracts_client_idx').on(t.clientId)]);

// ─── Facturation ─────────────────────────────────────────────────────────

export const invoices = pgTable('invoices', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  kind: text('kind', { enum: INVOICE_KINDS }).notNull().default('INVOICE'),
  status: text('status', { enum: INVOICE_STATUSES }).notNull().default('DRAFT'),
  /** Attribué à l'émission seulement */
  number: text('number'),
  clientId: uuid('client_id').notNull().references(() => clients.id),
  siteId: uuid('site_id').references(() => sites.id),
  title: text('title').notNull(),
  notes: text('notes'),
  issueDate: date('issue_date', { mode: 'string' }),
  serviceDate: date('service_date', { mode: 'string' }),
  dueDate: date('due_date', { mode: 'string' }),
  paymentTermsDays: integer('payment_terms_days').notNull().default(30),
  currency: varchar('currency', { length: 3 }).notNull(),
  netCents: bigint('net_cents', { mode: 'number' }).notNull().default(0),
  vatCents: bigint('vat_cents', { mode: 'number' }).notNull().default(0),
  grossCents: bigint('gross_cents', { mode: 'number' }).notNull().default(0),
  sourceInterventionId: uuid('source_intervention_id').references(() => interventions.id),
  sourceQuoteId: uuid('source_quote_id').references(() => quotes.id),
  contractId: uuid('contract_id').references(() => contracts.id),
  creditedInvoiceId: uuid('credited_invoice_id'),
  /** Nature de l'opération : services, biens ou les deux (mention obligatoire) */
  operationType: text('operation_type', { enum: ['SERVICES', 'GOODS', 'MIXED'] }).notNull().default('SERVICES'),
  /** Facture électronique déposée sur la plateforme agréée : identifiant du dépôt, statut, dernière erreur */
  einvoiceFlowId: text('einvoice_flow_id'),
  einvoiceStatus: text('einvoice_status'),
  einvoiceStatusAt: timestamp('einvoice_status_at', { withTimezone: true }),
  einvoiceError: text('einvoice_error'),
  pdfPath: text('pdf_path'),
  sentAt: timestamp('sent_at', { withTimezone: true }),
  sentTo: text('sent_to'),
  /** Prélèvement SEPA : lot (fichier remis à la banque), mandat utilisé, premier (FRST) ou récurrent (RCUR) */
  sepaBatchId: uuid('sepa_batch_id'),
  sepaMandateId: uuid('sepa_mandate_id'),
  sepaSequence: text('sepa_sequence', { enum: ['FRST', 'RCUR'] }),
  /** Relances : dernier niveau envoyé (0 aucun, 1 rappel, 2 relance, 3 mise en demeure), quand, et suspendues */
  dunningLevel: integer('dunning_level').notNull().default(0),
  dunningLastOn: date('dunning_last_on', { mode: 'string' }),
  dunningPaused: boolean('dunning_paused').notNull().default(false),
  createdById: uuid('created_by_id').references(() => users.id),
  issuedById: uuid('issued_by_id').references(() => users.id),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('invoices_client_idx').on(t.clientId), index('invoices_company_issue_idx').on(t.companyId, t.issueDate)]);

export const invoiceLines = pgTable('invoice_lines', {
  id: id(),
  invoiceId: uuid('invoice_id').notNull().references(() => invoices.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(),
  description: text('description').notNull(),
  quantity: doublePrecision('quantity').notNull().default(1),
  unit: text('unit'),
  unitPriceCents: bigint('unit_price_cents', { mode: 'number' }).notNull().default(0),
  vatRateBp: integer('vat_rate_bp').notNull().default(2000),
}, (t) => [index('invoice_lines_invoice_idx').on(t.invoiceId)]);

// ─── Stock ───────────────────────────────────────────────────────────────

export const articles = pgTable('articles', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  reference: text('reference').notNull(),
  name: text('name').notNull(),
  category: text('category'),
  unit: text('unit').notNull().default('u'),
  purchasePriceCents: bigint('purchase_price_cents', { mode: 'number' }),
  salePriceCents: bigint('sale_price_cents', { mode: 'number' }),
  vatRateBp: integer('vat_rate_bp').notNull().default(2000),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
});

export const stockLocations = pgTable('stock_locations', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  kind: text('kind', { enum: STOCK_LOCATION_KINDS }).notNull(),
  name: text('name').notNull(),
  technicianId: uuid('technician_id').references(() => users.id),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
});

export const stockLevels = pgTable('stock_levels', {
  locationId: uuid('location_id').notNull().references(() => stockLocations.id),
  articleId: uuid('article_id').notNull().references(() => articles.id),
  quantity: doublePrecision('quantity').notNull().default(0),
  minQuantity: doublePrecision('min_quantity').notNull().default(0),
}, (t) => [primaryKey({ columns: [t.locationId, t.articleId] })]);

export const stockSlips = pgTable('stock_slips', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  number: text('number'),
  status: text('status', { enum: SLIP_STATUSES }).notNull().default('DRAFT'),
  fromLocationId: uuid('from_location_id').notNull().references(() => stockLocations.id),
  toLocationId: uuid('to_location_id').references(() => stockLocations.id),
  interventionId: uuid('intervention_id').references(() => interventions.id),
  notes: text('notes'),
  createdById: uuid('created_by_id').references(() => users.id),
  validatedById: uuid('validated_by_id').references(() => users.id),
  validatedAt: timestamp('validated_at', { withTimezone: true }),
  createdAt: createdAt(),
});

export const stockSlipLines = pgTable('stock_slip_lines', {
  id: id(),
  slipId: uuid('slip_id').notNull().references(() => stockSlips.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(),
  articleId: uuid('article_id').notNull().references(() => articles.id),
  quantity: doublePrecision('quantity').notNull(),
});

export const stockMovements = pgTable('stock_movements', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  articleId: uuid('article_id').notNull().references(() => articles.id),
  kind: text('kind', { enum: STOCK_MOVEMENT_KINDS }).notNull(),
  fromLocationId: uuid('from_location_id').references(() => stockLocations.id),
  toLocationId: uuid('to_location_id').references(() => stockLocations.id),
  quantity: doublePrecision('quantity').notNull(),
  slipId: uuid('slip_id').references(() => stockSlips.id),
  interventionId: uuid('intervention_id').references(() => interventions.id),
  note: text('note'),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
});

// ─── Habilitations ───────────────────────────────────────────────────────

export const certificationTypes = pgTable('certification_types', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  validityMonths: integer('validity_months'),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
});

export const userCertifications = pgTable('user_certifications', {
  id: id(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  typeId: uuid('type_id').notNull().references(() => certificationTypes.id),
  obtainedOn: date('obtained_on', { mode: 'string' }),
  expiresOn: date('expires_on', { mode: 'string' }),
  reference: text('reference'),
  notes: text('notes'),
  documentPath: text('document_path'),
  documentMime: text('document_mime'),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
});

// ─── Parc véhicules ──────────────────────────────────────────────────────

export const vehicles = pgTable('vehicles', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  plate: text('plate').notNull(),
  type: text('type', { enum: VEHICLE_TYPES }).notNull().default('VAN'),
  make: text('make'),
  model: text('model'),
  vin: text('vin'),
  fuel: text('fuel'),
  firstRegistration: date('first_registration', { mode: 'string' }),
  ownership: text('ownership', { enum: OWNERSHIPS }).notNull().default('OWNED'),
  lessor: text('lessor'),
  status: text('status', { enum: VEHICLE_STATUSES }).notNull().default('ACTIVE'),
  mileage: integer('mileage'),
  mileageUpdatedOn: date('mileage_updated_on', { mode: 'string' }),
  driverId: uuid('driver_id').references(() => users.id),
  stockLocationId: uuid('stock_location_id').references(() => stockLocations.id),
  notes: text('notes'),
  /** Dernière position connue (envoyée par le téléphone du conducteur) */
  lastLat: doublePrecision('last_lat'),
  lastLng: doublePrecision('last_lng'),
  lastAccuracyM: integer('last_accuracy_m'),
  lastPositionAt: timestamp('last_position_at', { withTimezone: true }),
  lastPositionBy: uuid('last_position_by').references(() => users.id),
  createdAt: createdAt(),
});

/** Historique des positions d'un véhicule, effacé après 30 jours */
export const vehiclePositions = pgTable('vehicle_positions', {
  id: id(),
  vehicleId: uuid('vehicle_id').notNull().references(() => vehicles.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').references(() => users.id),
  lat: doublePrecision('lat').notNull(),
  lng: doublePrecision('lng').notNull(),
  accuracyM: integer('accuracy_m'),
  recordedAt: timestamp('recorded_at', { withTimezone: true }).notNull(),
  receivedAt: timestamp('received_at', { withTimezone: true }).notNull().defaultNow(),
  event: text('event', { enum: ['TRACK', 'EN_ROUTE', 'ON_SITE'] }).notNull().default('TRACK'),
  interventionId: uuid('intervention_id').references(() => interventions.id),
}, (t) => [index('vehicle_positions_vehicle_time_idx').on(t.vehicleId, t.recordedAt)]);

export const vehicleDeadlines = pgTable('vehicle_deadlines', {
  id: id(),
  vehicleId: uuid('vehicle_id').notNull().references(() => vehicles.id, { onDelete: 'cascade' }),
  kind: text('kind', { enum: VEHICLE_DEADLINE_KINDS }).notNull(),
  label: text('label'),
  dueDate: date('due_date', { mode: 'string' }),
  dueMileage: integer('due_mileage'),
  intervalMonths: integer('interval_months'),
  intervalKm: integer('interval_km'),
  appointmentOn: date('appointment_on', { mode: 'string' }),
  appointmentWith: text('appointment_with'),
  active: boolean('active').notNull().default(true),
  createdAt: createdAt(),
});

export const vehicleEvents = pgTable('vehicle_events', {
  id: id(),
  vehicleId: uuid('vehicle_id').notNull().references(() => vehicles.id, { onDelete: 'cascade' }),
  kind: text('kind', { enum: VEHICLE_EVENT_KINDS }).notNull(),
  occurredOn: date('occurred_on', { mode: 'string' }).notNull(),
  mileage: integer('mileage'),
  costCents: bigint('cost_cents', { mode: 'number' }),
  provider: text('provider'),
  description: text('description'),
  deadlineId: uuid('deadline_id').references(() => vehicleDeadlines.id, { onDelete: 'set null' }),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
});

export const jobRuns = pgTable('job_runs', {
  job: text('job').notNull(),
  runOn: date('run_on', { mode: 'string' }).notNull(),
}, (t) => [primaryKey({ columns: [t.job, t.runOn] })]);

/** Mandats de prélèvement SEPA signés par les clients (un seul actif par client) */
export const sepaMandates = pgTable('sepa_mandates', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  clientId: uuid('client_id').notNull().references(() => clients.id, { onDelete: 'cascade' }),
  /** Référence unique du mandat (RUM) */
  reference: text('reference').notNull(),
  holderName: text('holder_name').notNull(),
  iban: text('iban').notNull(),
  bic: text('bic'),
  signedOn: date('signed_on', { mode: 'string' }).notNull(),
  status: text('status', { enum: ['ACTIVE', 'REVOKED'] }).notNull().default('ACTIVE'),
  /** Premier prélèvement fait : les suivants sont récurrents */
  firstCollectedAt: timestamp('first_collected_at', { withTimezone: true }),
  revokedAt: timestamp('revoked_at', { withTimezone: true }),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
}, (t) => [index('sepa_mandates_client_idx').on(t.clientId), uniqueIndex('sepa_mandates_reference_uq').on(t.groupId, t.reference)]);

/** Lots de prélèvement : un fichier SEPA remis à la banque */
/** Relances envoyées pour une facture impayée (sentById vide : envoi automatique) */
export const invoiceReminders = pgTable('invoice_reminders', {
  id: id(),
  invoiceId: uuid('invoice_id').notNull().references(() => invoices.id, { onDelete: 'cascade' }),
  level: integer('level').notNull(),
  sentTo: text('sent_to').notNull(),
  sentById: uuid('sent_by_id').references(() => users.id),
  sentAt: timestamp('sent_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('invoice_reminders_invoice_idx').on(t.invoiceId)]);

export const sepaBatches = pgTable('sepa_batches', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  messageId: text('message_id').notNull(),
  collectionDate: date('collection_date', { mode: 'string' }).notNull(),
  /** SENT : fichier produit ; COLLECTED : paiements enregistrés */
  status: text('status', { enum: ['SENT', 'COLLECTED'] }).notNull().default('SENT'),
  count: integer('count').notNull(),
  totalCents: bigint('total_cents', { mode: 'number' }).notNull(),
  xml: text('xml').notNull(),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
  collectedAt: timestamp('collected_at', { withTimezone: true }),
}, (t) => [index('sepa_batches_company_idx').on(t.companyId, t.createdAt)]);

export const payments = pgTable('payments', {
  id: id(),
  invoiceId: uuid('invoice_id').notNull().references(() => invoices.id),
  paidOn: date('paid_on', { mode: 'string' }).notNull(),
  amountCents: bigint('amount_cents', { mode: 'number' }).notNull(),
  method: text('method', { enum: PAYMENT_METHODS }).notNull(),
  reference: text('reference'),
  createdById: uuid('created_by_id').references(() => users.id),
  createdAt: createdAt(),
}, (t) => [index('payments_invoice_idx').on(t.invoiceId)]);

/** Journal des actions : qui a fait quoi, et quand */
export const auditLogs = pgTable('audit_logs', {
  id: id(),
  groupId: uuid('group_id').notNull(),
  userId: uuid('user_id'),
  action: text('action').notNull(),
  entity: text('entity').notNull(),
  entityId: uuid('entity_id'),
  details: jsonb('details'),
  at: timestamp('at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('audit_group_at_idx').on(t.groupId, t.at)]);

// ─── Portail client ──────────────────────────────────────────────────────

/** Accès au portail : une personne chez le client ; le mot de passe est choisi depuis le lien d'invitation */
export const portalUsers = pgTable('portal_users', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  clientId: uuid('client_id').notNull().references(() => clients.id, { onDelete: 'cascade' }),
  email: text('email').notNull(),
  name: text('name').notNull(),
  passwordHash: text('password_hash'),
  locale: text('locale').notNull().default('fr-FR'),
  active: boolean('active').notNull().default(true),
  passwordChangedAt: timestamp('password_changed_at', { withTimezone: true }),
  lastLoginAt: timestamp('last_login_at', { withTimezone: true }),
  invitedAt: timestamp('invited_at', { withTimezone: true }),
  invitedById: uuid('invited_by_id').references(() => users.id),
  createdAt: createdAt(),
}, (t) => [index('portal_users_client_idx').on(t.clientId)]);

/** Liens d'invitation et de mot de passe oublié du portail (empreinte du jeton seulement) */
export const portalTokens = pgTable('portal_tokens', {
  id: id(),
  portalUserId: uuid('portal_user_id').notNull().references(() => portalUsers.id, { onDelete: 'cascade' }),
  purpose: text('purpose', { enum: ['invite', 'reset'] }).notNull(),
  tokenHash: text('token_hash').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  usedAt: timestamp('used_at', { withTimezone: true }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex('portal_tokens_hash_uq').on(t.tokenHash), index('portal_tokens_user_idx').on(t.portalUserId)]);
// ─── Messagerie interne ───────────────────────────────────────────────────

export const conversations = pgTable('conversations', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  kind: text('kind', { enum: ['DIRECT', 'GROUP'] }).notNull(),
  title: text('title'),
  /** Conversation à deux : les deux identifiants triés (une seule conversation par paire) */
  directKey: text('direct_key').unique(),
  createdBy: uuid('created_by').references(() => users.id),
  createdAt: createdAt(),
  lastMessageAt: timestamp('last_message_at', { withTimezone: true }).notNull().defaultNow(),
});

export const conversationMembers = pgTable('conversation_members', {
  conversationId: uuid('conversation_id').notNull().references(() => conversations.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  joinedAt: timestamp('joined_at', { withTimezone: true }).notNull().defaultNow(),
  lastReadAt: timestamp('last_read_at', { withTimezone: true }),
}, (t) => [primaryKey({ columns: [t.conversationId, t.userId] })]);

export const messages = pgTable('messages', {
  id: id(),
  conversationId: uuid('conversation_id').notNull().references(() => conversations.id, { onDelete: 'cascade' }),
  /** Vide : message du système (« X a ajouté Y ») */
  senderId: uuid('sender_id').references(() => users.id),
  body: text('body').notNull(),
  /** Photo ou fichier joint (chemin sur le disque du serveur, jamais renvoyé) */
  attachmentPath: text('attachment_path'),
  attachmentName: text('attachment_name'),
  attachmentMime: text('attachment_mime'),
  attachmentSize: integer('attachment_size'),
  createdAt: createdAt(),
  editedAt: timestamp('edited_at', { withTimezone: true }),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
}, (t) => [index('messages_conversation_time_idx').on(t.conversationId, t.createdAt)]);

// ─── Annuaire ─────────────────────────────────────────────────────────────

export const directoryContacts = pgTable('directory_contacts', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  /** Vide = tout le groupe ; agence vide = toute la société */
  companyId: uuid('company_id').references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  category: text('category', { enum: DIRECTORY_CATEGORIES }).notNull().default('OTHER'),
  name: text('name').notNull(),
  organization: text('organization'),
  phone: text('phone'),
  mobile: text('mobile'),
  email: text('email'),
  address: text('address'),
  website: text('website'),
  notes: text('notes'),
  createdBy: uuid('created_by').references(() => users.id),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('directory_contacts_group_idx').on(t.groupId, t.category)]);

// ─── Notices et procédures ────────────────────────────────────────────────

export const procedures = pgTable('procedures', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  /** Vide = tout le groupe ; agence vide = toute la société */
  companyId: uuid('company_id').references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  category: text('category', { enum: PROCEDURE_CATEGORIES }).notNull().default('OTHER'),
  title: text('title').notNull(),
  description: text('description'),
  keywords: text('keywords'),
  filePath: text('file_path'),
  fileName: text('file_name'),
  fileMime: text('file_mime'),
  fileSize: integer('file_size'),
  url: text('url'),
  status: text('status', { enum: PROCEDURE_STATUSES }).notNull().default('APPROVED'),
  submittedBy: uuid('submitted_by').references(() => users.id),
  reviewedBy: uuid('reviewed_by').references(() => users.id),
  reviewedAt: timestamp('reviewed_at', { withTimezone: true }),
  reviewNote: text('review_note'),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('procedures_group_idx').on(t.groupId, t.status, t.category)]);

// ─── Cartes SIM ───────────────────────────────────────────────────────────

export const simCards = pgTable('sim_cards', {
  id: id(),
  groupId: uuid('group_id').notNull().references(() => groups.id),
  companyId: uuid('company_id').notNull().references(() => companies.id),
  agencyId: uuid('agency_id').references(() => agencies.id),
  iccid: text('iccid').notNull(),
  phoneNumber: text('phone_number'),
  operator: text('operator'),
  plan: text('plan'),
  status: text('status', { enum: SIM_STATUSES }).notNull().default('STOCK'),
  clientId: uuid('client_id').references(() => clients.id, { onDelete: 'set null' }),
  siteId: uuid('site_id').references(() => sites.id, { onDelete: 'set null' }),
  device: text('device'),
  requestedAt: timestamp('requested_at', { withTimezone: true }),
  activatedAt: timestamp('activated_at', { withTimezone: true }),
  terminatedAt: timestamp('terminated_at', { withTimezone: true }),
  notes: text('notes'),
  createdBy: uuid('created_by').references(() => users.id),
  createdAt: createdAt(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [unique('sim_cards_group_id_iccid_key').on(t.groupId, t.iccid), index('sim_cards_company_idx').on(t.companyId, t.status)]);
// ─── Accès « support » demandé par la console de supervision ─────────────

export const SUPPORT_ACCESS_STATUSES = ['PENDING', 'APPROVED', 'REFUSED', 'EXPIRED', 'CLOSED'] as const;

export const supportAccess = pgTable('support_access', {
  id: id(),
  commandId: uuid('command_id').notNull().unique(),
  reason: text('reason').notNull(),
  hours: integer('hours').notNull(),
  status: text('status', { enum: SUPPORT_ACCESS_STATUSES }).notNull().default('PENDING'),
  decidedBy: uuid('decided_by').references(() => users.id),
  decidedAt: timestamp('decided_at', { withTimezone: true }),
  expiresAt: timestamp('expires_at', { withTimezone: true }),
  userId: uuid('user_id').references(() => users.id),
  reported: boolean('reported').notNull().default(false),
  createdAt: createdAt(),
});
