// npm run db:migrate : applique les migrations en attente (à part du serveur, qui le fait aussi au démarrage)
import { migrate } from './migrate.js';

migrate()
  .then((applied) => {
    console.log(applied.length ? `Migrations appliquées : ${applied.join(', ')}` : 'Base déjà à jour.');
  })
  .catch((err) => {
    console.error(err.message);
    process.exit(1);
  });
