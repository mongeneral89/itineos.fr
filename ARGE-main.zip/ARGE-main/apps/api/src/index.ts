import { buildApp } from './app.js';
import { env, PRODUCT_NAME } from './env.js';
import { migrate } from './db/migrate.js';
import { alignCompaniesToEdition, ensureSystemTemplates } from './services/templates.js';
import { scheduleContractVisits } from './services/contracts.js';
import { scheduleDailyDigests } from './services/digest.js';
import { schedulePositionPurge } from './services/positions.js';
import { startSupervision } from './services/supervision.js';
import { scheduleLateChecks } from './services/office-notify.js';
import { scheduleDunning } from './services/dunning.js';

// Au démarrage : base à jour, modèles neutres présents, puis l'API écoute.
const applied = await migrate();
if (applied.length) console.log(`Migrations appliquées : ${applied.join(', ')}`);
const created = await ensureSystemTemplates();
if (created) console.log(`${created} modèles de fiches fournis créés`);
// Toutes les sociétés de cette installation sont du secteur de l'édition (ex. données de démonstration)
const aligned = await alignCompaniesToEdition(env.EDITION);
if (aligned) console.log(`${aligned} société(s) passée(s) à l'édition ${PRODUCT_NAME}`);
console.log(`Édition : ${PRODUCT_NAME}`);

const app = await buildApp();
await app.listen({ port: env.PORT, host: env.HOST });

// Visites des contrats d'entretien : créées à l'avance dans « À planifier »
scheduleContractVisits((msg) => app.log.info(msg));
// Récapitulatif des échéances (véhicules, habilitations), chaque matin aux responsables
scheduleDailyDigests((msg) => app.log.info(msg));
// Positions des véhicules : effacées après 30 jours
schedulePositionPurge((msg) => app.log.info(msg));
// Console de supervision de l'éditeur : état, bugs, mises à jour (seulement si SUPERVISION_URL est réglé)
void startSupervision((msg) => app.log.info(msg));
// Technicien pas encore parti 15 minutes après l'heure prévue : le bureau est prévenu
scheduleLateChecks((msg) => app.log.info(msg));
// Factures impayées : rappel, relance puis mise en demeure par e-mail (sociétés qui l'ont activé)
scheduleDunning((msg) => app.log.info(msg));
