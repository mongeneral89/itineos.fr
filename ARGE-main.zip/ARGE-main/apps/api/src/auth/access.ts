/**
 * Contrôle d'accès : QUI peut faire QUOI, et SUR QUEL PÉRIMÈTRE.
 *
 * Un utilisateur a une ou plusieurs affectations (rôle + périmètre) :
 *  - périmètre groupe   : companyId = null, agencyId = null → tout le groupe
 *  - périmètre société  : companyId = X,    agencyId = null → toute la société X
 *  - périmètre agence   : companyId = X,    agencyId = Y    → l'agence Y seulement
 *
 * Ce fichier ne dépend d'aucune base de données : il est entièrement testable.
 */
import { ROLE_PERMISSIONS, type Permission, type Role } from '@itineo/shared';

export interface Assignment {
  role: Role;
  companyId: string | null;
  agencyId: string | null;
}

export interface Principal {
  userId: string;
  groupId: string;
  assignments: Assignment[];
}

/** La ressource visée : à quelle société et quelle agence elle appartient */
export interface Target {
  companyId: string;
  agencyId?: string | null;
}

export interface CoverOptions {
  /**
   * Une ressource rattachée à la société mais à aucune agence (ex. un client partagé)
   * est-elle visible pour un utilisateur limité à une agence ? Vrai pour la lecture des clients.
   */
  sharedVisible?: boolean;
}

export function roleHas(role: Role, perm: Permission): boolean {
  return ROLE_PERMISSIONS[role].includes(perm);
}

export function covers(a: Assignment, t: Target, opts: CoverOptions = {}): boolean {
  if (!a.companyId) return true; // périmètre groupe
  if (a.companyId !== t.companyId) return false;
  if (!a.agencyId) return true; // périmètre société
  if (t.agencyId == null) return !!opts.sharedVisible;
  return a.agencyId === t.agencyId;
}

export function can(p: Principal, perm: Permission, t: Target, opts: CoverOptions = {}): boolean {
  return p.assignments.some((a) => roleHas(a.role, perm) && covers(a, t, opts));
}

/** A-t-il cette permission sur tout le groupe ? (créer une société, par exemple) */
export function canGroupWide(p: Principal, perm: Permission): boolean {
  return p.assignments.some((a) => roleHas(a.role, perm) && !a.companyId);
}

/** A-t-il cette permission quelque part, quel que soit le périmètre ? */
export function canSomewhere(p: Principal, perm: Permission): boolean {
  return p.assignments.some((a) => roleHas(a.role, perm));
}

export interface InterventionTarget extends Target {
  technicianId?: string | null;
}

/** Lecture d'une intervention : dans son périmètre, ou parce qu'on en est le technicien */
export function canReadIntervention(p: Principal, t: InterventionTarget): boolean {
  if (can(p, 'intervention.read', t)) return true;
  return !!t.technicianId && t.technicianId === p.userId && can(p, 'intervention.read.own', t);
}

/** Remplir la fiche : le technicien affecté, ou quelqu'un qui gère les interventions du périmètre */
export function canWriteReport(p: Principal, t: InterventionTarget): boolean {
  if (can(p, 'intervention.write', t)) return true;
  return !!t.technicianId && t.technicianId === p.userId && can(p, 'report.write.own', t);
}

/**
 * Pour les listes : l'ensemble des sociétés et agences où l'utilisateur a la permission.
 * Sert à construire le filtre SQL.
 */
export interface ScopeFilter {
  all: boolean;
  companyIds: string[];
  agencyIds: string[];
  /** Sociétés des agences ci-dessus (pour les ressources partagées au niveau société) */
  agencyCompanyIds: string[];
}

export function scopeFor(p: Principal, perm: Permission): ScopeFilter {
  const f: ScopeFilter = { all: false, companyIds: [], agencyIds: [], agencyCompanyIds: [] };
  for (const a of p.assignments) {
    if (!roleHas(a.role, perm)) continue;
    if (!a.companyId) f.all = true;
    else if (!a.agencyId) f.companyIds.push(a.companyId);
    else {
      f.agencyIds.push(a.agencyId);
      f.agencyCompanyIds.push(a.companyId);
    }
  }
  f.companyIds = [...new Set(f.companyIds)];
  f.agencyIds = [...new Set(f.agencyIds)];
  f.agencyCompanyIds = [...new Set(f.agencyCompanyIds)];
  return f;
}

export function isEmptyScope(f: ScopeFilter): boolean {
  return !f.all && f.companyIds.length === 0 && f.agencyIds.length === 0;
}

/** Peut-il accorder ce rôle sur ce périmètre ? On ne donne jamais plus que ce qu'on a. */
export function canGrant(p: Principal, grant: Assignment): boolean {
  if (grant.role === 'GROUP_ADMIN' || !grant.companyId) return canGroupWide(p, 'org.write');
  if (grant.role === 'DIRECTOR' && !grant.agencyId) {
    return can(p, 'org.write', { companyId: grant.companyId });
  }
  return can(p, 'user.write', { companyId: grant.companyId, agencyId: grant.agencyId });
}
