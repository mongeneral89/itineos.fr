import { and, inArray, isNull, or, sql, type SQL } from 'drizzle-orm';
import type { PgColumn } from 'drizzle-orm/pg-core';
import type { ScopeFilter } from './access.js';

/**
 * Traduit un périmètre en condition SQL sur des colonnes company_id / agency_id.
 * Renvoie une condition toujours fausse si le périmètre est vide.
 */
export function scopeWhere(
  f: ScopeFilter,
  cols: { companyId: PgColumn; agencyId: PgColumn },
  opts: { sharedVisible?: boolean } = {},
): SQL {
  if (f.all) return sql`true`;
  const parts: SQL[] = [];
  if (f.companyIds.length) parts.push(inArray(cols.companyId, f.companyIds));
  if (f.agencyIds.length) parts.push(inArray(cols.agencyId, f.agencyIds));
  if (opts.sharedVisible && f.agencyCompanyIds.length) {
    parts.push(and(isNull(cols.agencyId), inArray(cols.companyId, f.agencyCompanyIds))!);
  }
  if (!parts.length) return sql`false`;
  return or(...parts)!;
}
