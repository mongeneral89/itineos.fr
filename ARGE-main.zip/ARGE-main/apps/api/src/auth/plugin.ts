import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { and, eq } from 'drizzle-orm';
import { db, schema } from '../db/client.js';
import { HttpError } from '../http.js';
import { SESSION_TTL, sessionStillValid, sessionVersion } from '../services/password.js';
import type { Principal } from './access.js';

declare module '@fastify/jwt' {
  interface FastifyJWT {
    /** pwv : version du mot de passe au moment de la connexion (voir services/password.ts) */
    /** kind : « portal » pour un client connecté au portail (jamais accepté sur les routes du bureau) */
    /** rem : « Rester connecté » (session d'un an, prolongée à chaque ouverture) */
    payload: { sub: string; gid: string; pwv: number; kind?: 'portal'; rem?: boolean };
    user: { sub: string; gid: string; pwv?: number; kind?: 'portal'; rem?: boolean };
  }
}

declare module 'fastify' {
  interface FastifyRequest {
    principal: Principal;
  }
  interface FastifyInstance {
    authenticate: (req: FastifyRequest, reply: FastifyReply) => Promise<void>;
  }
}

/**
 * Charge l'utilisateur et ses affectations à chaque requête : un droit retiré s'applique immédiatement.
 * Avec `session`, refuse aussi une session ouverte avant le dernier changement de mot de passe.
 */
export async function loadPrincipal(
  userId: string,
  groupId: string,
  session?: { passwordVersion: number | undefined },
): Promise<Principal | null> {
  const [user] = await db
    .select({
      id: schema.users.id,
      groupId: schema.users.groupId,
      active: schema.users.active,
      passwordChangedAt: schema.users.passwordChangedAt,
      sessionsRevokedAt: schema.users.sessionsRevokedAt,
    })
    .from(schema.users)
    .where(and(eq(schema.users.id, userId), eq(schema.users.groupId, groupId)));
  if (!user || !user.active) return null;
  if (session && !sessionStillValid(session.passwordVersion, user.passwordChangedAt, user.sessionsRevokedAt)) return null;
  const assignments = await db
    .select({
      role: schema.roleAssignments.role,
      companyId: schema.roleAssignments.companyId,
      agencyId: schema.roleAssignments.agencyId,
    })
    .from(schema.roleAssignments)
    .where(eq(schema.roleAssignments.userId, userId));
  return { userId: user.id, groupId: user.groupId, assignments };
}

export function registerAuth(app: FastifyInstance) {
  app.decorateRequest('principal', null as unknown as Principal);
  app.decorate('authenticate', async (req: FastifyRequest) => {
    try {
      await req.jwtVerify();
    } catch {
      throw new HttpError(401, 'Session expirée, reconnectez-vous');
    }
    if (req.user.kind === 'portal') throw new HttpError(401, 'Session expirée, reconnectez-vous');
    const principal = await loadPrincipal(req.user.sub, req.user.gid, { passwordVersion: req.user.pwv });
    if (!principal) throw new HttpError(401, 'Session expirée, reconnectez-vous');
    req.principal = principal;
  });
}

/** Ouvre une session (12 h, ou un an avec « Rester connecté ») liée à la version actuelle des sessions */
export function signSession(
  app: FastifyInstance,
  user: { id: string; groupId: string; passwordChangedAt: Date | null; sessionsRevokedAt?: Date | null },
  remember = false,
) {
  return app.jwt.sign(
    { sub: user.id, gid: user.groupId, pwv: sessionVersion(user.passwordChangedAt, user.sessionsRevokedAt), ...(remember ? { rem: true } : {}) },
    { expiresIn: remember ? SESSION_TTL.remember : SESSION_TTL.normal },
  );
}
