import { randomBytes } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { and, asc, eq, inArray, isNull, or } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { ROLES } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canGrant, canGroupWide } from '../auth/access.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';

const assignmentBody = z.object({
  role: z.enum(ROLES),
  companyId: z.string().uuid().nullable().default(null),
  agencyId: z.string().uuid().nullable().default(null),
});

const userBody = z.object({
  email: z.string().email().transform((s) => s.toLowerCase()),
  // Sans mot de passe : la personne le choisira avec son lien d'invitation (routes/invitations.ts)
  password: z.string().min(8, 'Le mot de passe doit faire au moins 8 caractères').optional(),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  phone: z.string().optional(),
  locale: z.string().default('fr-FR'),
  skills: z.array(z.string()).default([]),
  teamId: z.string().uuid().optional(),
  assignments: z.array(assignmentBody).min(1, 'Au moins un rôle est nécessaire'),
});

export async function userRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /**
   * Utilisateurs d'une société ou d'une agence, éventuellement filtrés par rôle.
   * Exemple : les techniciens d'une agence pour le planning.
   */
  app.get('/users', async (req) => {
    const p = req.principal;
    const q = z.object({
      companyId: z.string().uuid(),
      agencyId: z.string().uuid().optional(),
      role: z.enum(ROLES).optional(),
    }).parse(req.query);
    const target = { companyId: q.companyId, agencyId: q.agencyId ?? null };
    if (!can(p, 'user.read', target) && !can(p, 'intervention.assign', target)) throw forbidden();

    const ra = schema.roleAssignments;
    const rows = await db
      .select({
        id: schema.users.id,
        email: schema.users.email,
        firstName: schema.users.firstName,
        lastName: schema.users.lastName,
        phone: schema.users.phone,
        skills: schema.users.skills,
        locale: schema.users.locale,
        active: schema.users.active,
        role: ra.role,
        companyId: ra.companyId,
        agencyId: ra.agencyId,
      })
      .from(ra)
      .innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(
        eq(ra.groupId, p.groupId),
        eq(ra.companyId, q.companyId),
        q.agencyId ? or(eq(ra.agencyId, q.agencyId), isNull(ra.agencyId)) : undefined,
        q.role ? eq(ra.role, q.role) : undefined,
      ))
      .orderBy(asc(schema.users.lastName), asc(schema.users.firstName));

    const byUser = new Map<string, Omit<(typeof rows)[number], 'role' | 'companyId' | 'agencyId'> & { roles: { role: string; companyId: string | null; agencyId: string | null }[] }>();
    for (const { role, companyId, agencyId, ...u } of rows) {
      const entry = byUser.get(u.id) ?? { ...u, roles: [] };
      entry.roles.push({ role, companyId, agencyId });
      byUser.set(u.id, entry);
    }
    return [...byUser.values()];
  });

  /** Création d'un compte avec ses rôles */
  app.post('/users', async (req, reply) => {
    const p = req.principal;
    const body = userBody.parse(req.body);

    for (const a of body.assignments) {
      if (a.agencyId && !a.companyId) throw badRequest('Une agence doit être accompagnée de sa société');
      if (a.companyId && !(await getCompany(p.groupId, a.companyId))) throw badRequest('Société inconnue');
      if (a.companyId && a.agencyId && !(await getAgency(a.companyId, a.agencyId))) throw badRequest('Agence inconnue');
      if (!canGrant(p, a)) throw forbidden(`Vous ne pouvez pas attribuer le rôle ${a.role} sur ce périmètre`);
    }

    const existing = await db
      .select({ id: schema.users.id })
      .from(schema.users)
      .where(inArray(schema.users.email, [body.email]));
    if (existing.length) throw conflict('Un compte existe déjà avec cet e-mail');

    // Mot de passe inconnu de tous en attendant l'invitation
    const passwordHash = await bcrypt.hash(body.password ?? randomBytes(32).toString('base64url'), 10);
    const user = await db.transaction(async (tx) => {
      const [u] = await tx.insert(schema.users).values({
        groupId: p.groupId,
        email: body.email,
        passwordHash,
        firstName: body.firstName,
        lastName: body.lastName,
        phone: body.phone,
        locale: body.locale,
        skills: body.skills,
        teamId: body.teamId,
      }).returning({ id: schema.users.id, email: schema.users.email });
      await tx.insert(schema.roleAssignments).values(
        body.assignments.map((a) => ({ ...a, userId: u.id, groupId: p.groupId })),
      );
      return u;
    });
    await audit(p, 'create', 'user', user.id, { email: user.email, assignments: body.assignments });
    return reply.code(201).send(user);
  });

  /** Un compte avec tous ses rôles (fiche de modification : rien ne doit se perdre d'une autre société) */
  app.get('/users/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [user] = await db.select({
      id: schema.users.id, email: schema.users.email, firstName: schema.users.firstName, lastName: schema.users.lastName,
      phone: schema.users.phone, skills: schema.users.skills, locale: schema.users.locale, active: schema.users.active,
    }).from(schema.users).where(and(eq(schema.users.id, id), eq(schema.users.groupId, p.groupId)));
    if (!user) throw notFound('Compte');
    const roles = await db.select({ role: schema.roleAssignments.role, companyId: schema.roleAssignments.companyId, agencyId: schema.roleAssignments.agencyId })
      .from(schema.roleAssignments).where(eq(schema.roleAssignments.userId, id));
    // Visible pour qui peut lire les comptes d'au moins une de ses sociétés
    if (!roles.some((r) => (r.companyId ? can(p, 'user.read', { companyId: r.companyId, agencyId: r.agencyId }) : canGroupWide(p, 'user.read')) || canGrant(p, r))) throw forbidden();
    return { ...user, roles, canEdit: roles.every((r) => canGrant(p, r)), self: id === p.userId };
  });

  /**
   * Modification d'un compte par un responsable : identité, téléphone, compétences, langue, rôles et périmètres,
   * blocage. Il faut pouvoir gérer chacun de ses rôles actuels et attribuer chacun des nouveaux. On ne peut ni se
   * bloquer soi-même ni changer ses propres rôles, ni laisser le groupe sans administrateur.
   * Bloqué : plus de connexion, et ses sessions ouvertes sont refusées dès la requête suivante.
   */
  app.patch('/users/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const body = z.object({
      firstName: z.string().trim().min(1).optional(),
      lastName: z.string().trim().min(1).optional(),
      email: z.string().email().transform((s) => s.toLowerCase()).optional(),
      phone: z.string().trim().max(40).nullable().optional(),
      skills: z.array(z.string().trim().min(1).max(60)).max(30).optional(),
      locale: z.string().max(10).optional(),
      active: z.boolean().optional(),
      assignments: z.array(assignmentBody).min(1, 'Au moins un rôle est nécessaire').max(20).optional(),
    }).parse(req.body);

    const [user] = await db.select().from(schema.users).where(and(eq(schema.users.id, id), eq(schema.users.groupId, p.groupId)));
    if (!user) throw notFound('Compte');
    const current = await db.select().from(schema.roleAssignments).where(eq(schema.roleAssignments.userId, id));
    if (!current.length || !current.every((a) => canGrant(p, a))) throw forbidden();

    const self = id === p.userId;
    if (self && body.active === false) throw badRequest('Vous ne pouvez pas bloquer votre propre compte');
    if (self && body.assignments) throw badRequest('Vous ne pouvez pas changer vos propres rôles : demandez à un autre responsable');

    if (body.assignments) {
      for (const a of body.assignments) {
        if (a.agencyId && !a.companyId) throw badRequest('Une agence doit être accompagnée de sa société');
        if (a.companyId && !(await getCompany(p.groupId, a.companyId))) throw badRequest('Société inconnue');
        if (a.companyId && a.agencyId && !(await getAgency(a.companyId, a.agencyId))) throw badRequest('Agence inconnue');
        if (!canGrant(p, a)) throw forbidden(`Vous ne pouvez pas attribuer le rôle ${a.role} sur ce périmètre`);
      }
    }
    // Toujours au moins un administrateur actif dans le groupe
    const losesAdmin = current.some((a) => a.role === 'GROUP_ADMIN')
      && (body.active === false || (body.assignments && !body.assignments.some((a) => a.role === 'GROUP_ADMIN')));
    if (losesAdmin) {
      const others = await db.select({ id: schema.users.id }).from(schema.roleAssignments)
        .innerJoin(schema.users, eq(schema.users.id, schema.roleAssignments.userId))
        .where(and(eq(schema.roleAssignments.groupId, p.groupId), eq(schema.roleAssignments.role, 'GROUP_ADMIN'), eq(schema.users.active, true)));
      if (!others.some((o) => o.id !== id)) throw badRequest('Il faut garder au moins un administrateur du groupe');
    }
    if (body.email && body.email !== user.email.toLowerCase()) {
      const [taken] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, body.email));
      if (taken && taken.id !== id) throw conflict('Un compte existe déjà avec cet e-mail');
    }

    const { assignments, active, ...fields } = body;
    const now = new Date();
    await db.transaction(async (tx) => {
      await tx.update(schema.users).set({
        ...fields,
        ...(active !== undefined ? { active } : {}),
        // Bloqué, ou nouveaux droits : les sessions ouvertes repartent de zéro
        ...(active === false || assignments ? { sessionsRevokedAt: now } : {}),
      }).where(eq(schema.users.id, id));
      if (assignments) {
        await tx.delete(schema.roleAssignments).where(eq(schema.roleAssignments.userId, id));
        await tx.insert(schema.roleAssignments).values(assignments.map((a) => ({ ...a, userId: id, groupId: p.groupId })));
      }
    });
    await audit(p, active === false ? 'block' : active === true && !user.active ? 'unblock' : 'update', 'user', id, body);
    return { ok: true };
  });
}
