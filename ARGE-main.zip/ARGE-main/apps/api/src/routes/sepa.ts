/**
 * Prélèvement SEPA des factures : mandats des clients, lots de prélèvement (fichier pain.008 à déposer à la banque),
 * puis encaissement (paiements notés sur les factures, rejets remis à prélever).
 *
 * Un client a au plus un mandat actif ; un nouveau mandat remplace l'ancien. Une facture émise et non payée d'un
 * client qui a un mandat peut être prélevée ; elle n'entre que dans un seul lot à la fois.
 */
import type { FastifyInstance } from 'fastify';
import { and, desc, eq, inArray, isNull } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { can, type Principal } from '../auth/access.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { nextNumber } from '../services/numbering.js';
import { todayIn } from '../services/contracts.js';
import { bicValid, compactIban, directDebitXml, earliestCollectionDate, ibanValid, isWeekend, maskIban } from '../services/sepa.js';
import { loadClient } from './clients.js';
import { billsIn, settlements } from './invoices.js';

const m = schema.sepaMandates;
const inv = schema.invoices;

const publicMandate = (x: typeof m.$inferSelect) => ({
  id: x.id, clientId: x.clientId, reference: x.reference, holderName: x.holderName, iban: maskIban(x.iban), bic: x.bic,
  signedOn: x.signedOn, status: x.status, firstCollectedAt: x.firstCollectedAt, revokedAt: x.revokedAt, createdAt: x.createdAt,
});

/** Facture prélevable : émise, non payée, d'un client qui a un mandat actif, dans aucun lot */
async function eligible(p: Principal, companyId: string, ids?: string[]) {
  const rows = await db.select({ invoice: inv, client: schema.clients, mandate: m })
    .from(inv)
    .innerJoin(schema.clients, eq(schema.clients.id, inv.clientId))
    .innerJoin(m, and(eq(m.clientId, inv.clientId), eq(m.status, 'ACTIVE')))
    .where(and(
      eq(inv.groupId, p.groupId), eq(inv.companyId, companyId), eq(inv.kind, 'INVOICE'), eq(inv.status, 'ISSUED'),
      isNull(inv.sepaBatchId), ids ? inArray(inv.id, ids) : undefined,
    ))
    .orderBy(inv.issueDate, inv.number);
  const visible = rows.filter((r) => can(p, 'invoice.write', { companyId, agencyId: r.invoice.agencyId }));
  const { paid, credited } = await settlements(visible.map((r) => r.invoice.id));
  return visible
    .map((r) => ({ ...r, remainingCents: r.invoice.grossCents - (paid.get(r.invoice.id) ?? 0) - (credited.get(r.invoice.id) ?? 0) }))
    .filter((r) => r.remainingCents > 0);
}

export async function sepaRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  // ─── Mandats ────────────────────────────────────────────────────────────

  app.get('/clients/:id/mandates', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadClient(req.principal, id, 'client.read');
    const rows = await db.select().from(m).where(eq(m.clientId, id)).orderBy(desc(m.createdAt));
    return rows.map(publicMandate);
  });

  /** Nouveau mandat signé par le client : il remplace le mandat actif précédent */
  app.post('/clients/:id/mandates', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const client = await loadClient(p, id, 'client.read');
    if (!can(p, 'invoice.write', { companyId: client.companyId, agencyId: client.agencyId })) throw forbidden();
    const body = z.object({
      holderName: z.string().trim().min(1, 'Indiquez le titulaire du compte').max(70),
      iban: z.string().trim().max(50).transform(compactIban).refine(ibanValid, 'IBAN invalide'),
      bic: z.string().trim().max(15).nullable().optional().transform((s) => (s ? s.replace(/\s+/g, '').toUpperCase() : null))
        .refine((s) => !s || bicValid(s), 'BIC invalide'),
      /** Référence unique du mandat (RUM) : celle du mandat papier, sinon créée */
      reference: z.string().trim().max(35).nullable().optional(),
      signedOn: z.string().date(),
    }).parse(req.body);
    const company = (await getCompany(p.groupId, client.companyId))!;
    if (body.signedOn > todayIn(company.timezone)) throw badRequest('La date de signature ne peut pas être dans le futur');
    const created = await db.transaction(async (tx) => {
      const reference = body.reference || (await nextNumber(tx, company, 'mandate'));
      const [taken] = await tx.select({ id: m.id }).from(m).where(and(eq(m.groupId, p.groupId), eq(m.reference, reference)));
      if (taken) throw conflict(`La référence de mandat « ${reference} » existe déjà`);
      await tx.update(m).set({ status: 'REVOKED', revokedAt: new Date() }).where(and(eq(m.clientId, id), eq(m.status, 'ACTIVE')));
      const [row] = await tx.insert(m).values({
        groupId: p.groupId, clientId: id, reference, holderName: body.holderName, iban: body.iban, bic: body.bic,
        signedOn: body.signedOn, createdById: p.userId,
      }).returning();
      return row;
    });
    await audit(p, 'create', 'sepa-mandate', created.id, { clientId: id, reference: created.reference });
    return reply.code(201).send(publicMandate(created));
  });

  app.post('/mandates/:id/revoke', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [row] = await db.select().from(m).where(and(eq(m.id, id), eq(m.groupId, p.groupId)));
    if (!row) throw notFound('Mandat');
    const client = await loadClient(p, row.clientId, 'client.read');
    if (!can(p, 'invoice.write', { companyId: client.companyId, agencyId: client.agencyId })) throw forbidden();
    const [updated] = await db.update(m).set({ status: 'REVOKED', revokedAt: new Date() }).where(eq(m.id, id)).returning();
    await audit(p, 'revoke', 'sepa-mandate', id, { reference: row.reference });
    return publicMandate(updated);
  });

  // ─── Lots de prélèvement ────────────────────────────────────────────────

  /** Factures que l'on peut prélever maintenant, et ce qui manque à la société pour produire le fichier */
  app.get('/billing/direct-debits/preview', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.query);
    if (!billsIn(p, companyId)) throw forbidden();
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    const rows = await eligible(p, companyId);
    return {
      ready: !!(company.sepaCreditorId && company.sepaIban),
      earliestDate: earliestCollectionDate(todayIn(company.timezone)),
      invoices: rows.map((r) => ({
        id: r.invoice.id, number: r.invoice.number, issueDate: r.invoice.issueDate, dueDate: r.invoice.dueDate,
        clientName: r.client.name, remainingCents: r.remainingCents,
        mandate: r.mandate.reference, sequence: r.mandate.firstCollectedAt ? 'RCUR' : 'FRST',
      })),
    };
  });

  app.get('/billing/direct-debits', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.query);
    if (!billsIn(p, companyId)) throw forbidden();
    const b = schema.sepaBatches;
    return db.select({
      id: b.id, messageId: b.messageId, collectionDate: b.collectionDate, status: b.status, count: b.count,
      totalCents: b.totalCents, createdAt: b.createdAt, collectedAt: b.collectedAt,
    }).from(b).where(and(eq(b.groupId, p.groupId), eq(b.companyId, companyId))).orderBy(desc(b.createdAt)).limit(100);
  });

  /** Produit le lot : fichier pain.008 et factures marquées « présentées au prélèvement » */
  app.post('/billing/direct-debits', async (req, reply) => {
    const p = req.principal;
    const body = z.object({
      companyId: z.string().uuid(),
      collectionDate: z.string().date(),
      invoiceIds: z.array(z.string().uuid()).min(1, 'Choisissez au moins une facture').max(2000),
    }).parse(req.body);
    if (!billsIn(p, body.companyId)) throw forbidden();
    const company = await getCompany(p.groupId, body.companyId);
    if (!company) throw notFound('Société');
    if (!company.sepaCreditorId || !company.sepaIban) {
      throw badRequest('Indiquez d’abord l’identifiant créancier SEPA (ICS) et l’IBAN de la société (Organisation → Facturation)');
    }
    if (company.currency !== 'EUR') throw badRequest('Le prélèvement SEPA se fait en euros');
    const earliest = earliestCollectionDate(todayIn(company.timezone));
    if (body.collectionDate < earliest) throw badRequest(`Date de prélèvement trop proche : au plus tôt le ${earliest}`);
    if (isWeekend(body.collectionDate)) throw badRequest('Choisissez un jour de semaine : les banques ne prélèvent pas le samedi ni le dimanche');
    const rows = await eligible(p, company.id, body.invoiceIds);
    if (rows.length !== new Set(body.invoiceIds).size) throw conflict('Certaines factures ne peuvent plus être prélevées : rechargez la liste');

    const batch = await db.transaction(async (tx) => {
      const messageId = await nextNumber(tx, company, 'sepa_batch');
      const txs = rows.map((r) => ({
        invoiceId: r.invoice.id, mandateId: r.mandate.id,
        sequence: (r.mandate.firstCollectedAt ? 'RCUR' : 'FRST') as 'FRST' | 'RCUR',
        endToEndId: r.invoice.number!, amountCents: r.remainingCents,
        mandateRef: r.mandate.reference, mandateSignedOn: r.mandate.signedOn,
        debtorName: r.mandate.holderName, debtorIban: r.mandate.iban, debtorBic: r.mandate.bic,
        remittance: `${company.name} ${r.invoice.number}`,
      }));
      const xmlText = directDebitXml({
        messageId, createdAt: new Date(), collectionDate: body.collectionDate,
        creditor: { name: company.legalName || company.name, iban: company.sepaIban!, bic: company.sepaBic, creditorId: company.sepaCreditorId! },
        transactions: txs,
      });
      const [row] = await tx.insert(schema.sepaBatches).values({
        groupId: p.groupId, companyId: company.id, messageId, collectionDate: body.collectionDate,
        count: txs.length, totalCents: txs.reduce((s, t) => s + t.amountCents, 0), xml: xmlText, createdById: p.userId,
      }).returning();
      for (const t of txs) {
        const [done] = await tx.update(inv).set({ sepaBatchId: row.id, sepaMandateId: t.mandateId, sepaSequence: t.sequence, updatedAt: new Date() })
          .where(and(eq(inv.id, t.invoiceId), isNull(inv.sepaBatchId))).returning({ id: inv.id });
        if (!done) throw conflict('Une facture vient d’être mise dans un autre lot : recommencez');
      }
      // Premier prélèvement du mandat : les suivants seront récurrents
      const firsts = [...new Set(txs.filter((t) => t.sequence === 'FRST').map((t) => t.mandateId))];
      if (firsts.length) await tx.update(m).set({ firstCollectedAt: new Date() }).where(inArray(m.id, firsts));
      return row;
    });
    await audit(p, 'create', 'sepa-batch', batch.id, { messageId: batch.messageId, count: batch.count, totalCents: batch.totalCents });
    return reply.code(201).send({ id: batch.id, messageId: batch.messageId, count: batch.count, totalCents: batch.totalCents });
  });

  async function loadBatch(p: Principal, id: string) {
    const [row] = await db.select().from(schema.sepaBatches).where(and(eq(schema.sepaBatches.id, id), eq(schema.sepaBatches.groupId, p.groupId)));
    if (!row) throw notFound('Lot de prélèvement');
    if (!billsIn(p, row.companyId)) throw forbidden();
    return row;
  }

  /** Le fichier à déposer sur le site de la banque */
  app.get('/billing/direct-debits/:id/file', async (req, reply) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const batch = await loadBatch(req.principal, id);
    return reply.type('application/xml; charset=utf-8')
      .header('Content-Disposition', `attachment; filename="${batch.messageId}.xml"`)
      .send(batch.xml);
  });

  app.get('/billing/direct-debits/:id', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const batch = await loadBatch(req.principal, id);
    const invoices = await db.select({
      id: inv.id, number: inv.number, grossCents: inv.grossCents, sequence: inv.sepaSequence, clientName: schema.clients.name,
    }).from(inv).innerJoin(schema.clients, eq(schema.clients.id, inv.clientId)).where(eq(inv.sepaBatchId, id)).orderBy(inv.number);
    const { xml: _file, ...rest } = batch;
    return { ...rest, invoices };
  });

  /**
   * La banque a prélevé : un paiement est noté sur chaque facture du lot, à la date de prélèvement.
   * Les factures rejetées sortent du lot et pourront être présentées à nouveau.
   */
  app.post('/billing/direct-debits/:id/collected', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const body = z.object({ rejectedInvoiceIds: z.array(z.string().uuid()).default([]) }).parse(req.body ?? {});
    const batch = await loadBatch(p, id);
    if (batch.status === 'COLLECTED') throw conflict('Ce lot est déjà encaissé');
    const rows = await db.select({ id: inv.id, grossCents: inv.grossCents }).from(inv).where(eq(inv.sepaBatchId, id));
    const rejected = new Set(body.rejectedInvoiceIds);
    const { paid, credited } = await settlements(rows.map((r) => r.id));
    let payments = 0;
    await db.transaction(async (tx) => {
      for (const r of rows) {
        if (rejected.has(r.id)) {
          await tx.update(inv).set({ sepaBatchId: null, sepaMandateId: null, sepaSequence: null, updatedAt: new Date() }).where(eq(inv.id, r.id));
          continue;
        }
        const remaining = r.grossCents - (paid.get(r.id) ?? 0) - (credited.get(r.id) ?? 0);
        if (remaining <= 0) continue;
        await tx.insert(schema.payments).values({
          invoiceId: r.id, paidOn: batch.collectionDate, amountCents: remaining, method: 'DIRECT_DEBIT',
          reference: batch.messageId, createdById: p.userId,
        });
        payments++;
      }
      await tx.update(schema.sepaBatches).set({ status: 'COLLECTED', collectedAt: new Date() }).where(eq(schema.sepaBatches.id, id));
    });
    await audit(p, 'collect', 'sepa-batch', id, { payments, rejected: rejected.size });
    return { payments, rejected: rejected.size };
  });
}
