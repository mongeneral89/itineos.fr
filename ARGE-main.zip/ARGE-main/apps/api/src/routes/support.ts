/**
 * Lien avec la console de supervision de l'éditeur (voir services/supervision.ts) :
 *  - « Signaler un problème » : envoyé à la console avec la page et le nom de la personne ;
 *  - accès « support » : demandé par la console, accepté ou refusé ici par un administrateur du groupe.
 *    Accepté, un compte « Support » (administrateur) est ouvert pour la durée demandée, puis fermé seul.
 */
import type { FastifyInstance } from 'fastify';
import { randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { and, desc, eq, inArray } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { canGroupWide } from '../auth/access.js';
import { conflict, forbidden, notFound } from '../http.js';
import { audit } from '../services/audit.js';
import { reportUserProblem, SUPPORT_EMAIL, supervisionEnabled } from '../services/supervision.js';

const sa = schema.supportAccess;

export async function supportRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/support/status', async (req) => ({
    enabled: supervisionEnabled(),
    canDecide: canGroupWide(req.principal, 'org.write'),
  }));

  app.post('/support/report', async (req) => {
    const body = z.object({
      message: z.string().trim().min(5, 'Décrivez le problème en quelques mots').max(4000),
      page: z.string().max(300).optional(),
    }).parse(req.body);
    const [u] = await db.select({ firstName: schema.users.firstName, lastName: schema.users.lastName, email: schema.users.email })
      .from(schema.users).where(eq(schema.users.id, req.principal.userId));
    reportUserProblem({ message: body.message, page: body.page, userName: `${u.firstName} ${u.lastName}`, userEmail: u.email, userAgent: req.headers['user-agent'] });
    await audit(req.principal, 'support.report', 'user', req.principal.userId, { page: body.page ?? null });
    return { sent: supervisionEnabled() };
  });

  /** Demandes en attente et accès en cours (administrateurs du groupe) */
  app.get('/support/access', async (req) => {
    if (!canGroupWide(req.principal, 'org.write')) return [];
    return db.select({ id: sa.id, reason: sa.reason, hours: sa.hours, status: sa.status, expiresAt: sa.expiresAt, createdAt: sa.createdAt })
      .from(sa).where(inArray(sa.status, ['PENDING', 'APPROVED'])).orderBy(desc(sa.createdAt));
  });

  app.post('/support/access/:id/decide', async (req) => {
    const p = req.principal;
    if (!canGroupWide(p, 'org.write')) throw forbidden('Seul un administrateur peut ouvrir l’accès au support');
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { approve } = z.object({ approve: z.boolean() }).parse(req.body);
    const [row] = await db.select().from(sa).where(eq(sa.id, id));
    if (!row) throw notFound('Demande');
    if (row.status !== 'PENDING') throw conflict('Cette demande a déjà reçu une réponse');
    const now = new Date();
    if (!approve) {
      await db.update(sa).set({ status: 'REFUSED', decidedBy: p.userId, decidedAt: now }).where(eq(sa.id, id));
      await audit(p, 'support.refuse', 'support_access', id);
      return { status: 'REFUSED' };
    }
    const expiresAt = new Date(now.getTime() + row.hours * 3_600_000);
    // Compte « Support » : créé la première fois, rouvert ensuite. Son mot de passe est tiré par l'agent et
    // transmis à la console seulement ; d'ici là, personne ne peut s'y connecter.
    const userId = await db.transaction(async (tx) => {
      let [user] = await tx.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, SUPPORT_EMAIL));
      const unknownPassword = await bcrypt.hash(randomBytes(24).toString('hex'), 10);
      if (!user) {
        [user] = await tx.insert(schema.users).values({
          groupId: p.groupId, email: SUPPORT_EMAIL, passwordHash: unknownPassword, firstName: 'Support', lastName: 'Itinéos', active: true,
        }).returning({ id: schema.users.id });
      } else {
        await tx.update(schema.users).set({ passwordHash: unknownPassword, passwordChangedAt: now, active: true }).where(eq(schema.users.id, user.id));
      }
      const roles = await tx.select().from(schema.roleAssignments)
        .where(and(eq(schema.roleAssignments.userId, user.id), eq(schema.roleAssignments.role, 'GROUP_ADMIN')));
      if (!roles.length) {
        await tx.insert(schema.roleAssignments).values({ userId: user.id, groupId: p.groupId, role: 'GROUP_ADMIN', companyId: null, agencyId: null });
      }
      await tx.update(sa).set({ status: 'APPROVED', decidedBy: p.userId, decidedAt: now, expiresAt, userId: user.id }).where(eq(sa.id, id));
      return user.id;
    });
    await audit(p, 'support.approve', 'support_access', id, { hours: row.hours, until: expiresAt.toISOString(), userId });
    return { status: 'APPROVED', expiresAt };
  });

  /** Fermer l'accès avant la fin prévue */
  app.post('/support/access/:id/close', async (req) => {
    const p = req.principal;
    if (!canGroupWide(p, 'org.write')) throw forbidden();
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [row] = await db.update(sa).set({ expiresAt: new Date(Date.now() - 1000) })
      .where(and(eq(sa.id, id), eq(sa.status, 'APPROVED'))).returning({ userId: sa.userId });
    if (!row) throw conflict('Aucun accès en cours');
    if (row.userId) await db.update(schema.users).set({ active: false, sessionsRevokedAt: new Date() }).where(eq(schema.users.id, row.userId));
    await audit(p, 'support.close', 'support_access', id);
    return { ok: true };
  });
}
