/**
 * Synchronisation de l'appli terrain.
 *
 *  - GET /sync/stamp : une empreinte de ce qui concerne le technicien connecté (ses interventions des jours
 *    proches, leurs fiches, et la dernière demande du bureau). L'appli la relit régulièrement : si elle a
 *    changé, elle recharge sa journée et ses fiches sans que le technicien ait à le faire.
 *  - POST /sync/request : le bouton « Synchroniser les téléphones » du bureau. Les techniciens visés sont
 *    prévenus sur leur téléphone, et leur appli recharge tout dès qu'elle est ouverte.
 */
import { createHash } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { and, eq, gte, inArray, isNull, lt, or } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { can } from '../auth/access.js';
import { forbidden } from '../http.js';
import { notifyUsers } from '../services/notify.js';

const DAY = 24 * 3600 * 1000;

/** Empreinte de ce que l'appli terrain d'un technicien affiche (journée, fiches, demande du bureau) */
export async function syncStamp(userId: string, now = new Date()): Promise<string> {
  const i = schema.interventions;
  const r = schema.reports;
  const rows = await db
    .select({ id: i.id, at: i.updatedAt, report: r.updatedAt })
    .from(i)
    .leftJoin(r, eq(r.interventionId, i.id))
    .where(and(
      eq(i.technicianId, userId),
      or(isNull(i.scheduledStart), and(gte(i.scheduledStart, new Date(now.getTime() - 2 * DAY)), lt(i.scheduledStart, new Date(now.getTime() + 15 * DAY)))),
    ));
  const [u] = await db.select({ at: schema.users.syncRequestedAt }).from(schema.users).where(eq(schema.users.id, userId));
  const lines = rows.map((x) => `${x.id} ${x.at?.toISOString() ?? ''} ${x.report?.toISOString() ?? ''}`).sort();
  lines.push(`request ${u?.at?.toISOString() ?? ''}`);
  return createHash('sha256').update(lines.join('\n')).digest('hex').slice(0, 24);
}

export async function syncRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/sync/stamp', async (req) => ({ stamp: await syncStamp(req.principal.userId) }));

  app.post('/sync/request', async (req) => {
    const p = req.principal;
    const b = z.object({
      companyId: z.string().uuid(),
      agencyId: z.string().uuid().nullish(),
      technicianIds: z.array(z.string().uuid()).max(500).optional(),
    }).parse(req.body);
    if (!can(p, 'intervention.assign', { companyId: b.companyId, agencyId: b.agencyId ?? null })) throw forbidden();

    const ra = schema.roleAssignments;
    const techs = await db
      .selectDistinct({ id: schema.users.id })
      .from(ra)
      .innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(
        eq(ra.groupId, p.groupId),
        eq(ra.companyId, b.companyId),
        eq(ra.role, 'TECHNICIAN'),
        b.agencyId ? or(eq(ra.agencyId, b.agencyId), isNull(ra.agencyId)) : undefined,
        eq(schema.users.active, true),
        b.technicianIds?.length ? inArray(schema.users.id, b.technicianIds) : undefined,
      ));
    const ids = techs.map((t) => t.id);
    if (!ids.length) return { count: 0 };

    await db.update(schema.users).set({ syncRequestedAt: new Date() }).where(inArray(schema.users.id, ids));
    void notifyUsers(ids, 'assignment', (locale) => locale.startsWith('fr')
      ? { title: 'Planning mis à jour', body: 'Le bureau vous a envoyé les dernières modifications. Ouvrez l’appli pour les recevoir.', url: '/tech', tag: 'sync', sync: true }
      : { title: 'Schedule updated', body: 'The office sent you the latest changes. Open the app to receive them.', url: '/tech', tag: 'sync', sync: true },
    ).catch(() => undefined);
    return { count: ids.length };
  });
}
