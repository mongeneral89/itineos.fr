import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, gte, inArray, isNull, lt, or, sql } from 'drizzle-orm';
import { alias } from 'drizzle-orm/pg-core';
import { z } from 'zod';
import { INTERVENTION_KINDS, INTERVENTION_STATUSES, PRIORITIES } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canReadIntervention, canWriteReport, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { nextInterventionNumber } from '../services/numbering.js';
import { audit } from '../services/audit.js';
import { deviceTime } from '../services/device-time.js';
import { missingCertifications } from '../services/certifications.js';
import { notifyLater } from '../services/notify.js';

const i = schema.interventions;
const tech = alias(schema.users, 'tech');

/** Colonnes renvoyées dans les listes (avec le nom du client, la ville et le technicien) */
const listColumns = {
  id: i.id,
  number: i.number,
  companyId: i.companyId,
  agencyId: i.agencyId,
  kind: i.kind,
  status: i.status,
  priority: i.priority,
  source: i.source,
  reason: i.reason,
  scheduledStart: i.scheduledStart,
  scheduledEnd: i.scheduledEnd,
  technicianId: i.technicianId,
  clientId: i.clientId,
  siteId: i.siteId,
  equipmentId: i.equipmentId,
  contractId: i.contractId,
  quoteId: i.quoteId,
  dueDate: i.dueDate,
  requiredCertificationIds: i.requiredCertificationIds,
  createdAt: i.createdAt,
  clientName: schema.clients.name,
  siteName: schema.sites.name,
  siteCity: schema.sites.city,
  // Pour « Y aller » (itinéraire GPS)
  siteAddress: schema.sites.address,
  sitePostalCode: schema.sites.postalCode,
  siteLat: schema.sites.latitude,
  siteLng: schema.sites.longitude,
  templateId: i.templateId,
  technicianFirstName: tech.firstName,
  technicianLastName: tech.lastName,
};

/** Le technicien est-il rattaché à cette agence (ou à toute la société) ? */
export async function isTechnicianFor(userId: string, companyId: string, agencyId: string): Promise<boolean> {
  const ra = schema.roleAssignments;
  const rows = await db
    .select({ id: ra.id })
    .from(ra)
    .innerJoin(schema.users, eq(schema.users.id, ra.userId))
    .where(and(
      eq(ra.userId, userId),
      eq(ra.role, 'TECHNICIAN'),
      eq(ra.companyId, companyId),
      or(eq(ra.agencyId, agencyId), isNull(ra.agencyId)),
      eq(schema.users.active, true),
    ))
    .limit(1);
  return rows.length > 0;
}

export async function loadIntervention(p: Principal, id: string) {
  const [row] = await db
    .select()
    .from(i)
    .where(and(eq(i.id, id), eq(i.groupId, p.groupId)));
  if (!row) throw notFound('Intervention');
  if (!canReadIntervention(p, row)) throw forbidden();
  return row;
}

const createBody = z.object({
  companyId: z.string().uuid(),
  agencyId: z.string().uuid(),
  clientId: z.string().uuid(),
  siteId: z.string().uuid(),
  equipmentId: z.string().uuid().nullable().optional(),
  technicianId: z.string().uuid().nullable().optional(),
  kind: z.enum(INTERVENTION_KINDS),
  priority: z.enum(PRIORITIES).default('NORMAL'),
  source: z.string().optional(),
  reason: z.string().min(1, 'Le motif est obligatoire'),
  scheduledStart: z.coerce.date().nullable().optional(),
  scheduledEnd: z.coerce.date().nullable().optional(),
  requiredCertificationIds: z.array(z.string().uuid()).max(20).default([]),
  /** Document à remplir (sinon le modèle par défaut du type) */
  templateId: z.string().uuid().nullable().optional(),
  /** Date attendue : échéance d'une visite de contrat, date limite de remise du rapport (Itinéos Expertise) */
  dueDate: z.string().date().nullable().optional(),
});

const patchBody = z.object({
  dueDate: z.string().date().nullable().optional(),
  requiredCertificationIds: z.array(z.string().uuid()).max(20).optional(),
  technicianId: z.string().uuid().nullable().optional(),
  scheduledStart: z.coerce.date().nullable().optional(),
  scheduledEnd: z.coerce.date().nullable().optional(),
  priority: z.enum(PRIORITIES).optional(),
  reason: z.string().min(1).optional(),
  status: z.enum(INTERVENTION_STATUSES).optional(),
  templateId: z.string().uuid().nullable().optional(),
});

type Row = typeof i.$inferSelect;

/** « contient » pour ILIKE : % et _ tapés par l'utilisateur sont cherchés tels quels */
const likePattern = (text: string) => `%${text.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;

type NoticeKind = 'new' | 'moved' | 'removed' | 'cancelled';
type PlanFields = Pick<Row, 'technicianId' | 'scheduledStart' | 'status'>;

/**
 * Qui prévenir d'un changement au planning, et de quoi (jamais celui qui fait le changement) :
 * attribuée ou déplacée → le technicien prévu ; confiée à un autre ou remise à planifier → l'ancien ;
 * annulée → celui qui devait la faire.
 */
export function planningNotices(row: PlanFields, before: PlanFields | null, actorId: string): { userId: string; kind: NoticeKind; start: Date | null }[] {
  const out: { userId: string; kind: NoticeKind; start: Date | null }[] = [];
  const add = (userId: string | null, kind: NoticeKind, start: Date | null) => {
    if (userId && userId !== actorId) out.push({ userId, kind, start });
  };
  if (row.status === 'CANCELLED') {
    if (before && before.status !== 'CANCELLED') add(before.technicianId ?? row.technicianId, 'cancelled', before.scheduledStart);
    return out;
  }
  if (before?.technicianId && before.technicianId !== row.technicianId) add(before.technicianId, 'removed', before.scheduledStart);
  if (!row.technicianId) return out;
  if (!before || before.technicianId !== row.technicianId) add(row.technicianId, 'new', row.scheduledStart);
  else if (before.scheduledStart?.getTime() !== row.scheduledStart?.getTime()) add(row.technicianId, 'moved', row.scheduledStart);
  return out;
}

const NOTICE_TITLES: Record<NoticeKind, { fr: string; en: string }> = {
  new: { fr: 'Nouvelle intervention', en: 'New job' },
  moved: { fr: 'Intervention déplacée', en: 'Job rescheduled' },
  removed: { fr: 'Intervention retirée', en: 'Job removed' },
  cancelled: { fr: 'Intervention annulée', en: 'Job cancelled' },
};

/** Envoie les notifications décidées par planningNotices (sur le téléphone et/ou par e-mail, selon les préférences) */
function notifyAssignment(row: Row, before: Row | null, actorId: string) {
  const notices = planningNotices(row, before, actorId);
  if (!notices.length) return;
  void (async () => {
    const [info] = await db.select({ client: schema.clients.name, city: schema.sites.city, tz: schema.companies.timezone })
      .from(schema.clients).innerJoin(schema.sites, eq(schema.sites.id, row.siteId)).innerJoin(schema.companies, eq(schema.companies.id, row.companyId))
      .where(eq(schema.clients.id, row.clientId));
    for (const n of notices) {
      notifyLater([n.userId], 'assignment', (locale) => {
        const fr = locale.startsWith('fr');
        const when = n.start
          ? new Intl.DateTimeFormat(locale, { timeZone: info?.tz ?? 'Europe/Paris', weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(n.start)
          : fr ? 'à planifier' : 'to be scheduled';
        const reason = n.kind === 'cancelled' && row.cancelReason ? ` · ${row.cancelReason}` : '';
        return {
          title: fr ? NOTICE_TITLES[n.kind].fr : NOTICE_TITLES[n.kind].en,
          body: `${when} · ${info?.client ?? ''}${info?.city ? ` · ${info.city}` : ''}${row.priority === 'URGENT' ? ' · URGENT' : ''}${reason}`,
          // Une intervention retirée ou annulée n'est plus visible : sa journée à la place
          url: n.kind === 'removed' || n.kind === 'cancelled' ? '/tech' : `/tech/${row.id}`, tag: `iv-${row.id}`,
        };
      });
    }
  })().catch(() => undefined);
}

/** Le document choisi doit être un modèle actif de la société, du groupe ou fourni par Itinéos */
async function checkTemplate(groupId: string, companyId: string, templateId: string) {
  const t = schema.formTemplates;
  const [row] = await db.select({ id: t.id }).from(t).where(and(
    eq(t.id, templateId), eq(t.active, true),
    or(eq(t.companyId, companyId), and(eq(t.groupId, groupId), isNull(t.companyId)), isNull(t.groupId)),
  ));
  if (!row) throw badRequest('Document inconnu');
}

export async function interventionRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Liste : planning, interventions à planifier, journée d'un technicien… */
  app.get('/interventions', async (req) => {
    const p = req.principal;
    const q = z.object({
      companyId: z.string().uuid().optional(),
      agencyId: z.string().uuid().optional(),
      technicianId: z.string().uuid().optional(),
      status: z.string().optional(), // liste séparée par des virgules
      from: z.coerce.date().optional(),
      to: z.coerce.date().optional(),
      mine: z.coerce.boolean().optional(),
      /** Recherche : numéro, client, site ou ville (recherche du logiciel, en haut du menu) */
      q: z.string().trim().max(100).optional(),
      limit: z.coerce.number().int().min(1).max(3000).default(200), // un mois de planning entier peut dépasser 500
    }).parse(req.query);

    const cols = { companyId: i.companyId, agencyId: i.agencyId };
    const visible = or(
      scopeWhere(scopeFor(p, 'intervention.read'), cols),
      and(eq(i.technicianId, p.userId), scopeWhere(scopeFor(p, 'intervention.read.own'), cols)),
    );
    const statuses = q.status?.split(',').filter((s) => (INTERVENTION_STATUSES as readonly string[]).includes(s)) as
      | (typeof INTERVENTION_STATUSES)[number][]
      | undefined;

    return db
      .select(listColumns)
      .from(i)
      .innerJoin(schema.clients, eq(schema.clients.id, i.clientId))
      .innerJoin(schema.sites, eq(schema.sites.id, i.siteId))
      .leftJoin(tech, eq(tech.id, i.technicianId))
      .where(and(
        eq(i.groupId, p.groupId),
        visible,
        q.companyId ? eq(i.companyId, q.companyId) : undefined,
        q.agencyId ? eq(i.agencyId, q.agencyId) : undefined,
        q.technicianId ? eq(i.technicianId, q.technicianId) : undefined,
        q.mine ? eq(i.technicianId, p.userId) : undefined,
        statuses?.length ? inArray(i.status, statuses) : undefined,
        q.from ? gte(i.scheduledStart, q.from) : undefined,
        q.to ? lt(i.scheduledStart, q.to) : undefined,
        q.q ? or(...[i.number, schema.clients.name, schema.sites.name, schema.sites.city]
          .map((col) => sql`${col} ilike ${likePattern(q.q!)}`)) : undefined,
      ))
      // Planifiées par heure ; à planifier par échéance (visites de contrat), puis les plus récentes
      .orderBy(sql`${i.scheduledStart} asc nulls last`, sql`${i.dueDate} asc nulls last`, desc(i.createdAt))
      .limit(q.limit);
  });

  /** Détail d'une intervention */
  app.get('/interventions/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadIntervention(p, id);
    const [row] = await db
      .select({ ...listColumns, technicianEmail: tech.email, clientNotes: i.clientNotes, requestedByPortalUserId: i.requestedByPortalUserId, neededParts: i.neededParts, templateId: i.templateId, cancelReason: i.cancelReason, cancelledAt: i.cancelledAt })
      .from(i)
      .innerJoin(schema.clients, eq(schema.clients.id, i.clientId))
      .innerJoin(schema.sites, eq(schema.sites.id, i.siteId))
      .leftJoin(tech, eq(tech.id, i.technicianId))
      .where(eq(i.id, id));
    const [report] = await db
      .select({ id: schema.reports.id, status: schema.reports.status, sentAt: schema.reports.sentAt, outcome: schema.reports.outcome })
      .from(schema.reports)
      .where(eq(schema.reports.interventionId, id));
    const photos = report
      ? await db
          .select({
            id: schema.reportPhotos.id,
            clientId: schema.reportPhotos.clientId,
            kind: schema.reportPhotos.kind,
            caption: schema.reportPhotos.caption,
            createdAt: schema.reportPhotos.createdAt,
          })
          .from(schema.reportPhotos)
          .where(eq(schema.reportPhotos.reportId, report.id))
          .orderBy(asc(schema.reportPhotos.createdAt))
      : [];
    return { ...row, report: report ? { ...report, photos } : null };
  });

  /** Nouvelle intervention (appel client, devis signé, visite de contrat…) */
  app.post('/interventions', async (req, reply) => {
    const p = req.principal;
    const body = createBody.parse(req.body);
    const company = await getCompany(p.groupId, body.companyId);
    if (!company) throw badRequest('Société inconnue');
    if (!(await getAgency(company.id, body.agencyId))) throw badRequest('Agence inconnue');
    if (body.templateId) await checkTemplate(p.groupId, company.id, body.templateId);
    if (!can(p, 'intervention.write', { companyId: company.id, agencyId: body.agencyId })) throw forbidden();

    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, body.clientId));
    if (!client || client.companyId !== company.id) throw badRequest("Ce client n'appartient pas à cette société");
    const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, body.siteId));
    if (!site || site.clientId !== client.id) throw badRequest("Ce site n'appartient pas à ce client");
    if (body.equipmentId) {
      const [eqp] = await db.select().from(schema.equipments).where(eq(schema.equipments.id, body.equipmentId));
      if (!eqp || eqp.siteId !== site.id) throw badRequest("Cet équipement n'est pas sur ce site");
    }
    if (body.technicianId) {
      if (!can(p, 'intervention.assign', { companyId: company.id, agencyId: body.agencyId })) throw forbidden();
      if (!(await isTechnicianFor(body.technicianId, company.id, body.agencyId))) {
        throw badRequest("Ce technicien n'est pas rattaché à cette agence");
      }
    }
    if (body.scheduledStart && body.scheduledEnd && body.scheduledEnd <= body.scheduledStart) {
      throw badRequest("La fin doit être après le début");
    }

    const created = await db.transaction(async (tx) => {
      const number = await nextInterventionNumber(tx, company);
      const [row] = await tx.insert(i).values({
        ...body,
        groupId: p.groupId,
        number,
        status: body.technicianId && body.scheduledStart ? 'PLANNED' : 'TO_PLAN',
        createdById: p.userId,
        plannedById: body.technicianId || body.scheduledStart ? p.userId : null,
      }).returning();
      return row;
    });
    await audit(p, 'create', 'intervention', created.id, { number: created.number });
    notifyAssignment(created, null, p.userId);
    return reply.code(201).send(created);
  });

  /** Planification et mise à jour par le bureau */
  app.patch('/interventions/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadIntervention(p, id);
    const body = patchBody.parse(req.body);
    const target = { companyId: current.companyId, agencyId: current.agencyId };

    const touchesPlanning = body.technicianId !== undefined || body.scheduledStart !== undefined || body.scheduledEnd !== undefined;
    if (touchesPlanning && !can(p, 'intervention.assign', target)) throw forbidden();
    if (!touchesPlanning && !can(p, 'intervention.write', target)) throw forbidden();
    if (body.technicianId && !(await isTechnicianFor(body.technicianId, current.companyId, current.agencyId))) {
      throw badRequest("Ce technicien n'est pas rattaché à cette agence");
    }

    if (body.templateId !== undefined) {
      // Le document ne change plus une fois la fiche commencée
      const [started] = await db.select({ id: schema.reports.id }).from(schema.reports).where(eq(schema.reports.interventionId, id));
      if (started) throw badRequest('La fiche est déjà commencée : le document ne peut plus changer');
      if (body.templateId) await checkTemplate(p.groupId, current.companyId, body.templateId);
    }
    const next = { ...current, ...body };
    if (next.scheduledStart && next.scheduledEnd && next.scheduledEnd <= next.scheduledStart) {
      throw badRequest('La fin doit être après le début');
    }
    // Statut automatique selon la planification, sauf si un statut est imposé
    let status = body.status ?? current.status;
    if (!body.status && touchesPlanning) {
      if (next.technicianId && next.scheduledStart && current.status === 'TO_PLAN') status = 'PLANNED';
      if ((!next.technicianId || !next.scheduledStart) && current.status === 'PLANNED') status = 'TO_PLAN';
    }

    // Annulée par le choix du statut (sans motif) ou rouverte : la trace d'annulation suit
    const cancelTrace = status === 'CANCELLED' && current.status !== 'CANCELLED'
      ? { cancelledAt: new Date(), cancelledById: p.userId }
      : status !== 'CANCELLED' && current.status === 'CANCELLED'
        ? { cancelledAt: null, cancelledById: null, cancelReason: null }
        : {};

    // Qui planifie est prévenu quand l'intervention est terminée ; une nouvelle heure peut de nouveau être en retard
    const planning = touchesPlanning ? { plannedById: p.userId, lateNotifiedAt: null } : {};
    const [updated] = await db
      .update(i)
      .set({ ...body, ...cancelTrace, ...planning, status, updatedAt: new Date() })
      .where(eq(i.id, id))
      .returning();
    await audit(p, 'update', 'intervention', id, body);
    notifyAssignment(updated, current, p.userId);
    // Avertissement (sans bloquer) : habilitations exigées que le technicien n'a pas ou plus à la date prévue
    const warnings = updated.technicianId && updated.requiredCertificationIds.length
      ? await missingCertifications(updated.technicianId, updated.requiredCertificationIds,
        (updated.scheduledStart ?? new Date()).toISOString().slice(0, 10))
      : [];
    return { ...updated, missingCertifications: warnings };
  });

  /**
   * Annuler une intervention, avec son motif (gardé sur la fiche et dans le journal).
   * Une intervention terminée, ou dont la fiche est signée, ne s'annule plus : elle a eu lieu.
   */
  app.post('/interventions/:id/cancel', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { reason } = z.object({ reason: z.string().trim().min(3, 'Indiquez le motif de l’annulation').max(500) }).parse(req.body);
    const current = await loadIntervention(p, id);
    if (!can(p, 'intervention.write', { companyId: current.companyId, agencyId: current.agencyId })) throw forbidden();
    if (current.status === 'CANCELLED') throw conflict('Cette intervention est déjà annulée');
    if (current.status === 'DONE' || current.status === 'TO_RESUME') throw conflict('Cette intervention a eu lieu : elle ne peut plus être annulée');
    const [report] = await db.select({ status: schema.reports.status }).from(schema.reports).where(eq(schema.reports.interventionId, id));
    if (report && report.status !== 'DRAFT') throw conflict('La fiche est signée : l’intervention ne peut plus être annulée');
    const [updated] = await db
      .update(i)
      .set({ status: 'CANCELLED', cancelReason: reason, cancelledAt: new Date(), cancelledById: p.userId, updatedAt: new Date() })
      .where(eq(i.id, id))
      .returning();
    await audit(p, 'cancel', 'intervention', id, { reason });
    notifyAssignment(updated, current, p.userId);
    return updated;
  });

  /** Le technicien signale qu'il part ou qu'il est arrivé */
  app.post('/interventions/:id/status', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const body = z.object({
      status: z.enum(['PLANNED', 'EN_ROUTE', 'ON_SITE']),
      // Heure sur l'appareil, si l'action a été faite hors connexion
      at: z.coerce.date().optional(),
    }).parse(req.body);
    const { status } = body;
    const at = deviceTime(body.at);
    const current = await loadIntervention(p, id);
    if (!canWriteReport(p, current)) throw forbidden();
    if (['DONE', 'TO_RESUME', 'CANCELLED'].includes(current.status)) throw conflict('Cette intervention est clôturée');
    const [updated] = await db.update(i).set({ status, updatedAt: new Date() }).where(eq(i.id, id)).returning();
    if (status === 'ON_SITE') {
      await db
        .update(schema.reports)
        .set({ arrivedAt: at })
        .where(and(eq(schema.reports.interventionId, id), isNull(schema.reports.arrivedAt)));
    }
    await audit(p, 'status', 'intervention', id, { status });
    return updated;
  });
}
