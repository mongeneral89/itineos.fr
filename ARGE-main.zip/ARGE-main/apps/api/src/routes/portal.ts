/**
 * Portail client.
 *
 * Deux parties :
 *  - côté bureau (session du personnel) : inviter une personne du client, renvoyer l'invitation, couper l'accès ;
 *  - côté client (session « portail ») : ses interventions et fiches signées, ses devis (accepter / refuser),
 *    ses factures, ses contrats, et ses demandes d'intervention.
 *
 * Un client ne voit QUE ses propres données : chaque requête est filtrée sur le client de la personne connectée.
 * Les sessions du portail et du bureau sont étanches (claim `kind`).
 */
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { and, asc, desc, eq, inArray, isNotNull, ne, sql } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { readFile } from 'node:fs/promises';
import { z } from 'zod';
import {
  addDays, isQuoteExpired, paymentState, UI_LOCALES, visitDueDates,
} from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { badRequest, conflict, HttpError, notFound } from '../http.js';
import { audit } from '../services/audit.js';
import { sendMail } from '../services/mail.js';
import { getCompany } from '../services/org.js';
import { logoUrl } from '../services/logo.js';
import { nextInterventionNumber } from '../services/numbering.js';
import { todayIn } from '../services/contracts.js';
import { createResetToken, hashResetToken, newPassword, passwordMatches, passwordVersion, sessionStillValid } from '../services/password.js';
import { forgotByIp, loginAttempts, passwordChangeByUser, tooManyMessage } from '../services/rate-limit.js';
import {
  INVITE_TTL_MS, inviteMail, officeNoticeMail, PORTAL_RESET_TTL_MS, portalLink, portalResetMail, requestReceivedMail,
} from '../services/portal.js';
import { loadClient } from './clients.js';
import { settlements } from './invoices.js';
import { notifyClientRequest, notifyQuoteDecision } from '../services/office-notify.js';

const pu = schema.portalUsers;
const pt = schema.portalTokens;

type PortalUser = typeof pu.$inferSelect;
interface PortalContext {
  user: PortalUser;
  client: typeof schema.clients.$inferSelect;
  company: NonNullable<Awaited<ReturnType<typeof getCompany>>>;
}

declare module 'fastify' {
  interface FastifyRequest {
    portal: PortalContext;
  }
}

/** Pour le journal : l'action est tracée au nom de la personne du portail */
const asPrincipal = (u: PortalUser) => ({ userId: u.id, groupId: u.groupId, assignments: [] });

function signPortalSession(app: FastifyInstance, u: PortalUser) {
  return app.jwt.sign({ sub: u.id, gid: u.groupId, pwv: passwordVersion(u.passwordChangedAt), kind: 'portal' }, { expiresIn: '12h' });
}

async function portalContext(userId: string, groupId: string): Promise<PortalContext | null> {
  const [user] = await db.select().from(pu).where(and(eq(pu.id, userId), eq(pu.groupId, groupId)));
  if (!user || !user.active || !user.passwordHash) return null;
  const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, user.clientId));
  if (!client) return null;
  const company = await getCompany(client.groupId, client.companyId);
  if (!company) return null;
  return { user, client, company };
}

function throwIfBlocked(reply: FastifyReply, ...checks: { blocked: boolean; retryAfterMs: number }[]) {
  if (!checks.some((c) => c.blocked)) return;
  const wait = Math.max(0, ...checks.filter((c) => c.blocked).map((c) => c.retryAfterMs));
  reply.header('Retry-After', String(Math.ceil(wait / 1000)));
  throw new HttpError(429, tooManyMessage(wait));
}

/** Où prévenir le bureau : l'e-mail de l'agence, sinon celui de la société */
async function officeEmail(companyEmail: string | null, agencyId: string | null): Promise<string | null> {
  if (agencyId) {
    const [a] = await db.select({ email: schema.agencies.email }).from(schema.agencies).where(eq(schema.agencies.id, agencyId));
    if (a?.email) return a.email;
  }
  return companyEmail;
}

/** Envoie un lien (invitation ou mot de passe oublié) ; un seul lien valable à la fois par usage */
async function sendLink(u: PortalUser, purpose: 'invite' | 'reset', clientName: string, company: { name: string; locale: string; logoPath?: string | null }) {
  const { token, tokenHash } = createResetToken();
  await db.delete(pt).where(and(eq(pt.portalUserId, u.id), eq(pt.purpose, purpose)));
  await db.insert(pt).values({
    portalUserId: u.id, purpose, tokenHash,
    expiresAt: new Date(Date.now() + (purpose === 'invite' ? INVITE_TTL_MS : PORTAL_RESET_TTL_MS)),
  });
  const link = portalLink(`/activer?token=${encodeURIComponent(token)}`);
  const mail = purpose === 'invite'
    ? inviteMail(u.locale, { name: u.name, clientName, companyName: company.name, link })
    : portalResetMail(u.locale, { name: u.name, companyName: company.name, link });
  await sendMail({ to: [u.email], ...mail, brand: { name: company.name, logoPath: company.logoPath } });
}

export async function portalRoutes(app: FastifyInstance) {
  app.decorateRequest('portal', null as unknown as PortalContext);

  // ════════════════════════════════════════════ Côté bureau : gérer les accès d'un client

  const clientAccess = (row: PortalUser) => ({
    id: row.id, email: row.email, name: row.name, active: row.active, activated: !!row.passwordHash,
    invitedAt: row.invitedAt, lastLoginAt: row.lastLoginAt,
  });

  app.get('/clients/:id/portal-users', { preHandler: app.authenticate }, async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const client = await loadClient(req.principal, id, 'client.read');
    const rows = await db.select().from(pu).where(eq(pu.clientId, client.id)).orderBy(asc(pu.name));
    return rows.map(clientAccess);
  });

  /** Invite une personne du client (ou renvoie l'invitation si elle existe déjà pour ce client) */
  app.post('/clients/:id/portal-users', { preHandler: app.authenticate }, async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const body = z.object({
      email: z.string().trim().toLowerCase().email('Adresse e-mail invalide'),
      name: z.string().trim().min(1, 'Indiquez le nom de la personne').max(200),
    }).parse(req.body);
    const client = await loadClient(p, id, 'client.write');
    const company = (await getCompany(p.groupId, client.companyId))!;
    const [existing] = await db.select().from(pu).where(sql`lower(${pu.email}) = ${body.email}`);
    if (existing && existing.clientId !== client.id) throw conflict('Cette adresse a déjà un accès pour un autre client');
    const now = new Date();
    const [row] = existing
      ? await db.update(pu).set({ name: body.name, active: true, invitedAt: now, invitedById: p.userId }).where(eq(pu.id, existing.id)).returning()
      : await db.insert(pu).values({
        groupId: p.groupId, clientId: client.id, email: body.email, name: body.name, locale: client.locale || company.locale,
        invitedAt: now, invitedById: p.userId,
      }).returning();
    await sendLink(row, 'invite', client.name, company);
    await audit(p, 'portal.invite', 'client', client.id, { email: body.email });
    return reply.code(existing ? 200 : 201).send(clientAccess(row));
  });

  /** Coupe ou rouvre l'accès d'une personne (les sessions ouvertes sont refusées dès la requête suivante) */
  app.patch('/portal-users/:id', { preHandler: app.authenticate }, async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { active } = z.object({ active: z.boolean() }).parse(req.body);
    const [row] = await db.select().from(pu).where(and(eq(pu.id, id), eq(pu.groupId, p.groupId)));
    if (!row) throw notFound('Accès');
    await loadClient(p, row.clientId, 'client.write');
    const [updated] = await db.update(pu).set({ active }).where(eq(pu.id, id)).returning();
    await audit(p, active ? 'portal.enable' : 'portal.disable', 'client', row.clientId, { email: row.email });
    return clientAccess(updated);
  });

  // ════════════════════════════════════════════ Côté client : connexion

  app.post('/portal/auth/login', async (req, reply) => {
    const body = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1) }).parse(req.body);
    const key = `portal:${body.email}`;
    throwIfBlocked(reply, ...loginAttempts.check(key, req.ip));
    const [user] = await db.select().from(pu).where(sql`lower(${pu.email}) = ${body.email}`);
    // Même temps de réponse que le compte existe ou non
    const matches = await passwordMatches(body.password, user?.passwordHash);
    if (!matches || !user.active) {
      loginAttempts.fail(key, req.ip);
      throw new HttpError(401, 'E-mail ou mot de passe incorrect');
    }
    loginAttempts.succeed(key, req.ip);
    await db.update(pu).set({ lastLoginAt: new Date() }).where(eq(pu.id, user.id));
    return { token: signPortalSession(app, user) };
  });

  /** Ce qu'affiche la page d'activation avant de choisir le mot de passe */
  app.get('/portal/auth/link', async (req) => {
    const { token } = z.object({ token: z.string().min(1) }).parse(req.query);
    const [row] = await db.select().from(pt).where(eq(pt.tokenHash, hashResetToken(token)));
    if (!row || row.usedAt || row.expiresAt < new Date()) throw badRequest('Ce lien est invalide ou a expiré. Demandez-en un nouveau.');
    const [user] = await db.select().from(pu).where(eq(pu.id, row.portalUserId));
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, user.clientId));
    const company = (await getCompany(client.groupId, client.companyId))!;
    return { purpose: row.purpose, name: user.name, email: user.email, clientName: client.name, companyName: company.name, locale: company.locale, logoUrl: logoUrl(company) };
  });

  /** Choix du mot de passe depuis une invitation ou un lien « mot de passe oublié » : ouvre la session */
  app.post('/portal/auth/activate', async (req) => {
    const body = z.object({ token: z.string().min(1), password: newPassword }).parse(req.body);
    const [row] = await db.select().from(pt).where(eq(pt.tokenHash, hashResetToken(body.token)));
    const [user] = row ? await db.select().from(pu).where(eq(pu.id, row.portalUserId)) : [];
    if (!row || row.usedAt || row.expiresAt < new Date() || !user || !user.active) {
      throw badRequest('Ce lien est invalide ou a expiré. Demandez-en un nouveau.');
    }
    const changedAt = new Date();
    const [updated] = await db.transaction(async (tx) => {
      await tx.delete(pt).where(eq(pt.portalUserId, user.id));
      return tx.update(pu).set({ passwordHash: await bcrypt.hash(body.password, 10), passwordChangedAt: changedAt, lastLoginAt: changedAt })
        .where(eq(pu.id, user.id)).returning();
    });
    await audit(asPrincipal(user), row.purpose === 'invite' ? 'portal.activate' : 'portal.reset', 'client', user.clientId);
    return { token: signPortalSession(app, updated) };
  });

  /** Mot de passe oublié : même réponse que le compte existe ou non */
  app.post('/portal/auth/forgot', async (req, reply) => {
    const { email } = z.object({ email: z.string().trim().toLowerCase().email() }).parse(req.body);
    throwIfBlocked(reply, forgotByIp.check(req.ip));
    forgotByIp.hit(req.ip);
    const [user] = await db.select().from(pu).where(sql`lower(${pu.email}) = ${email}`);
    if (user && user.active) {
      const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, user.clientId));
      const company = (await getCompany(client.groupId, client.companyId))!;
      // Jamais activé : on renvoie l'invitation (plus longue) plutôt qu'un lien d'une heure
      void sendLink(user, user.passwordHash ? 'reset' : 'invite', client.name, company).catch((err) => req.log.error(err, 'lien du portail'));
    }
    return reply.code(204).send();
  });

  // ════════════════════════════════════════════ Côté client : espace connecté

  await app.register(async (portal) => {
    portal.addHook('preHandler', async (req: FastifyRequest) => {
      try {
        await req.jwtVerify();
      } catch {
        throw new HttpError(401, 'Session expirée, reconnectez-vous');
      }
      if (req.user.kind !== 'portal') throw new HttpError(401, 'Session expirée, reconnectez-vous');
      const ctx = await portalContext(req.user.sub, req.user.gid);
      if (!ctx || !sessionStillValid(req.user.pwv, ctx.user.passwordChangedAt)) throw new HttpError(401, 'Session expirée, reconnectez-vous');
      req.portal = ctx;
    });

    portal.get('/portal/me', async (req) => {
      const { user, client, company } = req.portal;
      const sites = await db.select().from(schema.sites).where(eq(schema.sites.clientId, client.id)).orderBy(asc(schema.sites.name));
      const equipments = sites.length
        ? await db.select().from(schema.equipments).where(inArray(schema.equipments.siteId, sites.map((s) => s.id)))
        : [];
      return {
        user: { id: user.id, name: user.name, email: user.email, locale: user.locale },
        client: { id: client.id, name: client.name, email: client.email, phone: client.phone, address: client.address, postalCode: client.postalCode, city: client.city },
        company: { name: company.name, email: company.email, phone: company.phone, locale: company.locale, currency: company.currency, timezone: company.timezone, logoUrl: logoUrl(company) },
        sites: sites.map((s) => ({
          id: s.id, name: s.name, address: s.address, postalCode: s.postalCode, city: s.city,
          equipments: equipments.filter((e) => e.siteId === s.id).map((e) => ({
            id: e.id, category: e.category, brand: e.brand, model: e.model, serialNumber: e.serialNumber, location: e.location, underContract: e.underContract,
          })),
        })),
      };
    });

    portal.patch('/portal/me', async (req) => {
      const { locale } = z.object({ locale: z.enum(UI_LOCALES) }).parse(req.body);
      await db.update(pu).set({ locale }).where(eq(pu.id, req.portal.user.id));
      return { locale };
    });

    portal.post('/portal/auth/change-password', async (req, reply) => {
      const { user } = req.portal;
      const body = z.object({ currentPassword: z.string().min(1), newPassword }).parse(req.body);
      // Essais comptés : une session volée ne permet pas d'essayer des mots de passe à l'infini
      const key = `portal:${user.id}`;
      throwIfBlocked(reply, passwordChangeByUser.check(key));
      if (!(await bcrypt.compare(body.currentPassword, user.passwordHash!))) {
        passwordChangeByUser.hit(key);
        throw badRequest('Mot de passe actuel incorrect');
      }
      passwordChangeByUser.reset(key);
      if (body.currentPassword === body.newPassword) throw badRequest("Le nouveau mot de passe doit être différent de l'ancien");
      const [updated] = await db.update(pu).set({ passwordHash: await bcrypt.hash(body.newPassword, 10), passwordChangedAt: new Date() })
        .where(eq(pu.id, user.id)).returning();
      return { token: signPortalSession(app, updated) };
    });

    // ─── Interventions et fiches signées ───
    portal.get('/portal/interventions', async (req) => {
      const { client } = req.portal;
      const iv = schema.interventions;
      const rows = await db.select({
        id: iv.id, number: iv.number, kind: iv.kind, status: iv.status, reason: iv.reason, source: iv.source,
        scheduledStart: iv.scheduledStart, scheduledEnd: iv.scheduledEnd, createdAt: iv.createdAt,
        siteName: schema.sites.name, siteCity: schema.sites.city,
        technicianFirstName: schema.users.firstName,
        reportStatus: schema.reports.status, signedAt: schema.reports.signedAt, sentAt: schema.reports.sentAt, pdfPath: schema.reports.pdfPath,
        outcome: schema.reports.outcome,
      })
        .from(iv)
        .innerJoin(schema.sites, eq(schema.sites.id, iv.siteId))
        .leftJoin(schema.users, eq(schema.users.id, iv.technicianId))
        .leftJoin(schema.reports, eq(schema.reports.interventionId, iv.id))
        .where(and(eq(iv.clientId, client.id), ne(iv.status, 'CANCELLED')))
        .orderBy(desc(sql`coalesce(${iv.scheduledStart}, ${iv.createdAt})`));
      return rows.map(({ pdfPath, ...r }) => ({
        ...r,
        // Le prénom suffit au client ; une fiche n'est téléchargeable qu'une fois signée et archivée
        hasReport: !!pdfPath && (r.reportStatus === 'SIGNED' || r.reportStatus === 'SENT'),
      }));
    });

    portal.get('/portal/interventions/:id/report.pdf', async (req, reply) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const [row] = await db.select({ number: schema.interventions.number, clientId: schema.interventions.clientId, status: schema.reports.status, pdfPath: schema.reports.pdfPath })
        .from(schema.interventions).innerJoin(schema.reports, eq(schema.reports.interventionId, schema.interventions.id))
        .where(eq(schema.interventions.id, id));
      if (!row || row.clientId !== req.portal.client.id || row.status === 'DRAFT' || !row.pdfPath) throw notFound('PDF');
      const pdf = await readFile(row.pdfPath).catch(() => null);
      if (!pdf) throw notFound('PDF');
      return reply.type('application/pdf').header('Content-Disposition', `inline; filename="${row.number}.pdf"`).send(pdf);
    });

    // ─── Devis ───
    const q = schema.quotes;
    portal.get('/portal/quotes', async (req) => {
      const { client, company } = req.portal;
      const today = todayIn(company.timezone);
      const rows = await db.select({
        id: q.id, number: q.number, kind: q.kind, status: q.status, title: q.title, validUntil: q.validUntil,
        netCents: q.netCents, grossCents: q.grossCents, currency: q.currency, sentAt: q.sentAt, decidedAt: q.decidedAt,
        decisionName: q.decisionName, siteName: schema.sites.name,
      })
        .from(q).leftJoin(schema.sites, eq(schema.sites.id, q.siteId))
        // Les brouillons restent au bureau ; un devis annulé n'intéresse plus le client
        .where(and(eq(q.clientId, client.id), inArray(q.status, ['SENT', 'ACCEPTED', 'REFUSED']), isNotNull(q.sentAt)))
        .orderBy(desc(q.sentAt));
      return rows.map((r) => ({ ...r, expired: isQuoteExpired(r, today) }));
    });

    portal.get('/portal/quotes/:id/pdf', async (req, reply) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const [row] = await db.select().from(q).where(eq(q.id, id));
      if (!row || row.clientId !== req.portal.client.id || row.status === 'DRAFT' || !row.pdfPath) throw notFound('PDF');
      const pdf = await readFile(row.pdfPath).catch(() => null);
      if (!pdf) throw notFound('PDF');
      return reply.type('application/pdf').header('Content-Disposition', `inline; filename="${row.number}.pdf"`).send(pdf);
    });

    /** Le client accepte ou refuse un devis envoyé (et encore valable) ; le bureau est prévenu par e-mail */
    portal.post('/portal/quotes/:id/decision', async (req) => {
      const { user, client, company } = req.portal;
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const body = z.object({
        decision: z.enum(['ACCEPTED', 'REFUSED']),
        name: z.string().trim().min(1, 'Indiquez votre nom').max(200),
        note: z.string().trim().max(2000).optional(),
      }).parse(req.body);
      const [row] = await db.select().from(q).where(eq(q.id, id));
      if (!row || row.clientId !== client.id || row.status === 'DRAFT') throw notFound('Devis');
      if (row.status !== 'SENT') throw conflict('Ce devis a déjà reçu une réponse');
      if (isQuoteExpired(row, todayIn(company.timezone))) throw conflict("Ce devis n'est plus valable : demandez-en un nouveau");
      const now = new Date();
      // Condition sur le statut : deux réponses simultanées ne peuvent pas passer toutes les deux
      const updated = await db.update(q).set({
        status: body.decision, decidedAt: now, decidedByPortalUserId: user.id, decisionName: body.name,
        decisionNote: body.note || null, updatedAt: now,
      }).where(and(eq(q.id, id), eq(q.status, 'SENT'))).returning({ id: q.id });
      if (!updated.length) throw conflict('Ce devis a déjà reçu une réponse');
      await audit(asPrincipal(user), body.decision === 'ACCEPTED' ? 'portal.quote.accept' : 'portal.quote.refuse', 'quote', id, { name: body.name });
      notifyQuoteDecision({ id, number: row.number, title: row.title, agencyId: row.agencyId, companyId: row.companyId, createdById: row.createdById, client: client.name, accepted: body.decision === 'ACCEPTED' });

      const en = company.locale.startsWith('en');
      const to = new Set<string>();
      const office = await officeEmail(company.email, row.agencyId);
      if (office) to.add(office);
      if (row.createdById) {
        const [author] = await db.select({ email: schema.users.email }).from(schema.users).where(eq(schema.users.id, row.createdById));
        if (author) to.add(author.email);
      }
      if (to.size) {
        const verdict = body.decision === 'ACCEPTED' ? (en ? 'accepted' : 'accepté') : (en ? 'declined' : 'refusé');
        const mail = officeNoticeMail(company.locale, {
          clientName: client.name,
          subject: en ? `quote ${row.number} ${verdict}` : `devis ${row.number} ${verdict}`,
          lines: [
            en ? `${client.name} has ${verdict} quote ${row.number} (${row.title}) online.` : `${client.name} a ${verdict} en ligne le devis ${row.number} (${row.title}).`,
            `${en ? 'By' : 'Par'} : ${body.name} (${user.email})`,
            ...(body.note ? [`${en ? 'Comment' : 'Commentaire'} : ${body.note}`] : []),
          ],
        });
        void sendMail({ to: [...to], ...mail, brand: { name: company.name, logoPath: company.logoPath } }).catch((err) => req.log.error(err, 'e-mail réponse devis'));
      }
      return { id, status: body.decision };
    });

    // ─── Factures ───
    portal.get('/portal/invoices', async (req) => {
      const { client, company } = req.portal;
      const inv = schema.invoices;
      const rows = await db.select({
        id: inv.id, kind: inv.kind, status: inv.status, number: inv.number, title: inv.title, issueDate: inv.issueDate,
        dueDate: inv.dueDate, grossCents: inv.grossCents, currency: inv.currency,
      }).from(inv)
        .where(and(eq(inv.clientId, client.id), eq(inv.status, 'ISSUED')))
        .orderBy(desc(inv.issueDate), desc(inv.number));
      const { paid, credited } = await settlements(rows.map((r) => r.id));
      const today = todayIn(company.timezone);
      return rows.map((r) => {
        const settled = (paid.get(r.id) ?? 0) + (credited.get(r.id) ?? 0);
        return {
          ...r,
          paidCents: settled,
          remainingCents: r.kind === 'INVOICE' ? Math.max(0, r.grossCents - settled) : 0,
          state: paymentState({ ...r, paidCents: settled }, today),
        };
      });
    });

    portal.get('/portal/invoices/:id/pdf', async (req, reply) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const [row] = await db.select().from(schema.invoices).where(eq(schema.invoices.id, id));
      if (!row || row.clientId !== req.portal.client.id || row.status !== 'ISSUED' || !row.pdfPath) throw notFound('PDF');
      const pdf = await readFile(row.pdfPath).catch(() => null);
      if (!pdf) throw notFound('PDF');
      return reply.type('application/pdf').header('Content-Disposition', `inline; filename="${row.number}.pdf"`).send(pdf);
    });

    // ─── Contrats d'entretien ───
    portal.get('/portal/contracts', async (req) => {
      const { client, company } = req.portal;
      const c = schema.contracts;
      const rows = await db.select({
        id: c.id, number: c.number, title: c.title, status: c.status, frequencyMonths: c.frequencyMonths,
        startDate: c.startDate, endDate: c.endDate, siteName: schema.sites.name, siteCity: schema.sites.city,
      }).from(c).innerJoin(schema.sites, eq(schema.sites.id, c.siteId))
        .where(and(eq(c.clientId, client.id), ne(c.status, 'ENDED')))
        .orderBy(asc(c.number));
      const today = todayIn(company.timezone);
      return rows.map((r) => ({
        ...r,
        nextVisit: r.status === 'ACTIVE' ? visitDueDates(r, today, addDays(today, 366 * 6))[0] ?? null : null,
      }));
    });

    // ─── Demande d'intervention ───
    portal.post('/portal/requests', async (req, reply) => {
      const { user, client, company } = req.portal;
      const body = z.object({
        siteId: z.string().uuid(),
        equipmentId: z.string().uuid().nullable().optional(),
        reason: z.string().trim().min(3, 'Décrivez le problème en quelques mots').max(2000),
        clientNotes: z.string().trim().max(2000).optional(),
        urgent: z.boolean().default(false),
      }).parse(req.body);
      const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, body.siteId));
      if (!site || site.clientId !== client.id) throw badRequest("Ce site n'appartient pas au client");
      if (body.equipmentId) {
        const [eq_] = await db.select().from(schema.equipments).where(eq(schema.equipments.id, body.equipmentId));
        if (!eq_ || eq_.siteId !== site.id) throw badRequest("Cet équipement n'est pas sur ce site");
      }
      // Agence : celle du client, sinon celle de sa dernière intervention, sinon la première de la société
      let agencyId = client.agencyId;
      if (!agencyId) {
        const [last] = await db.select({ agencyId: schema.interventions.agencyId }).from(schema.interventions)
          .where(eq(schema.interventions.clientId, client.id)).orderBy(desc(schema.interventions.createdAt)).limit(1);
        agencyId = last?.agencyId ?? null;
      }
      if (!agencyId) {
        const [first] = await db.select({ id: schema.agencies.id }).from(schema.agencies)
          .where(and(eq(schema.agencies.companyId, company.id), eq(schema.agencies.active, true))).orderBy(asc(schema.agencies.name)).limit(1);
        agencyId = first?.id ?? null;
      }
      if (!agencyId) throw conflict("Aucune agence ne peut recevoir cette demande : contactez l'entreprise");
      const en = company.locale.startsWith('en');
      const created = await db.transaction(async (tx) => {
        const number = await nextInterventionNumber(tx, company);
        const [row] = await tx.insert(schema.interventions).values({
          groupId: client.groupId, companyId: company.id, agencyId: agencyId!, number,
          clientId: client.id, siteId: site.id, equipmentId: body.equipmentId ?? null,
          kind: 'SAV', status: 'TO_PLAN', priority: body.urgent ? 'URGENT' : 'NORMAL',
          source: en ? 'Customer area' : 'Portail client', reason: body.reason,
          requestedByPortalUserId: user.id, clientNotes: body.clientNotes || null,
        }).returning({ id: schema.interventions.id, number: schema.interventions.number });
        return row;
      });
      await audit(asPrincipal(user), 'portal.request', 'intervention', created.id, { number: created.number });
      notifyClientRequest({ id: created.id, number: created.number, agencyId: agencyId!, companyId: company.id, client: client.name, reason: body.reason, urgent: body.urgent });

      const ack = requestReceivedMail(user.locale, { name: user.name, companyName: company.name, number: created.number, reason: body.reason });
      void sendMail({ to: [user.email], ...ack, brand: { name: company.name, logoPath: company.logoPath } }).catch((err) => req.log.error(err, 'accusé de réception'));
      const office = await officeEmail(company.email, agencyId);
      if (office) {
        const notice = officeNoticeMail(company.locale, {
          clientName: client.name,
          subject: en ? `new request ${created.number}${body.urgent ? ' (URGENT)' : ''}` : `nouvelle demande ${created.number}${body.urgent ? ' (URGENTE)' : ''}`,
          lines: [
            en ? `${client.name} has requested a visit from the customer area.` : `${client.name} demande une intervention depuis l'espace client.`,
            `${en ? 'Site' : 'Site'} : ${[site.name, site.city].filter(Boolean).join(', ')}`,
            `${en ? 'Problem' : 'Problème'} : ${body.reason}`,
            ...(body.clientNotes ? [`${en ? 'Availability / details' : 'Disponibilités / précisions'} : ${body.clientNotes}`] : []),
            `${en ? 'Requested by' : 'Demandé par'} : ${user.name} (${user.email})`,
            en ? 'The job is waiting in the "to schedule" list.' : 'L’intervention attend dans la liste « à planifier ».',
          ],
        });
        void sendMail({ to: [office], ...notice, brand: { name: company.name, logoPath: company.logoPath } }).catch((err) => req.log.error(err, 'e-mail au bureau'));
      }
      return reply.code(201).send(created);
    });
  });
}

