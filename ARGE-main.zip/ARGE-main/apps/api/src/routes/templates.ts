import type { FastifyInstance } from 'fastify';
import { and, asc, eq, isNull, or } from 'drizzle-orm';
import { z } from 'zod';
import { INTERVENTION_KINDS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canGroupWide } from '../auth/access.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { pickTemplate, systemTemplateVisible } from '../services/templates.js';
import { templateSchema } from '../services/template-schema.js';
import { installSecurityPack } from '../services/security-pack.js';

/** D'où vient un modèle : neutre (Itinéos), commun au groupe, ou propre à une société */
function scopeOf(t: { groupId: string | null; companyId: string | null }) {
  return t.companyId ? 'company' : t.groupId ? 'group' : 'system';
}

export async function templateRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Modèles utilisables par une société : les siens, ceux du groupe et les modèles neutres */
  app.get('/templates', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.query);
    if (!can(p, 'template.read', { companyId }, { sharedVisible: true })) throw forbidden();
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    const t = schema.formTemplates;
    const rows = await db
      .select()
      .from(t)
      .where(and(
        eq(t.active, true),
        or(
          eq(t.companyId, companyId),
          and(eq(t.groupId, p.groupId), isNull(t.companyId)),
          and(isNull(t.groupId), isNull(t.companyId)),
        ),
      ))
      .orderBy(asc(t.kind), asc(t.name));
    // Le modèle réellement utilisé pour les nouvelles fiches de cette société, par type d'intervention
    const inUse = new Set<string>();
    for (const kind of INTERVENTION_KINDS) {
      const picked = await pickTemplate(company, kind);
      if (picked) inUse.add(picked.id);
    }
    // Modèles fournis : seulement ceux du secteur de la société
    return rows
      .filter((r) => scopeOf(r) !== 'system' || systemTemplateVisible(r, company.sector))
      .map((r) => ({ ...r, scope: scopeOf(r), inUse: inUse.has(r.id) }));
  });

  /** Ajoute à une société le pack « installateur d'alarme et de vidéosurveillance » (fiches et documents du métier) */
  app.post('/templates/packs/security', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.body);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'template.write', { companyId })) throw forbidden();
    if (company.sector !== 'TECH') throw badRequest('Ce pack est prévu pour les installateurs (édition Itinéos)');
    const added = await installSecurityPack(company);
    await audit(p, 'install', 'template-pack', companyId, { pack: 'security', added });
    return { added };
  });

  /** Retire un modèle de société ou de groupe : le modèle plus général reprend la main */
  app.post('/templates/:id/archive', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(schema.formTemplates).where(eq(schema.formTemplates.id, id));
    if (!current || current.groupId !== p.groupId) throw notFound('Modèle');
    const allowed = current.companyId
      ? can(p, 'template.write', { companyId: current.companyId })
      : canGroupWide(p, 'template.write');
    if (!allowed) throw forbidden();
    await db.update(schema.formTemplates).set({ active: false }).where(eq(schema.formTemplates.id, id));
    await audit(p, 'archive', 'template', id, { name: current.name });
    return { archived: true };
  });

  /** Nouveau modèle pour une société (ou pour tout le groupe si companyId est vide) */
  app.post('/templates', async (req, reply) => {
    const p = req.principal;
    const body = z.object({
      companyId: z.string().uuid().nullable().default(null),
      name: z.string().min(1),
      kind: z.enum(INTERVENTION_KINDS),
      schema: templateSchema,
      /** Faux = document à choisir sur l'intervention (une copie garde le réglage du modèle copié) */
      autoPick: z.boolean().default(true),
    }).parse(req.body);
    if (body.companyId) {
      if (!(await getCompany(p.groupId, body.companyId))) throw badRequest('Société inconnue');
      if (!can(p, 'template.write', { companyId: body.companyId })) throw forbidden();
    } else if (!canGroupWide(p, 'template.write')) throw forbidden();

    const [created] = await db
      .insert(schema.formTemplates)
      .values({ ...body, groupId: p.groupId })
      .returning();
    await audit(p, 'create', 'template', created.id, { name: created.name });
    return reply.code(201).send(created);
  });

  /**
   * Modifier un modèle crée une NOUVELLE VERSION : les fiches déjà remplies
   * gardent la version avec laquelle elles ont été faites.
   */
  app.put('/templates/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(schema.formTemplates).where(eq(schema.formTemplates.id, id));
    if (!current || current.groupId !== p.groupId) throw notFound('Modèle');
    const allowed = current.companyId
      ? can(p, 'template.write', { companyId: current.companyId })
      : canGroupWide(p, 'template.write');
    if (!allowed) throw forbidden();
    const body = z.object({ name: z.string().min(1).optional(), schema: templateSchema }).parse(req.body);

    const created = await db.transaction(async (tx) => {
      await tx.update(schema.formTemplates).set({ active: false }).where(eq(schema.formTemplates.id, id));
      const [row] = await tx.insert(schema.formTemplates).values({
        groupId: current.groupId,
        companyId: current.companyId,
        kind: current.kind,
        name: body.name ?? current.name,
        schema: body.schema,
        autoPick: current.autoPick,
        version: current.version + 1,
      }).returning();
      return row;
    });
    await audit(p, 'update', 'template', created.id, { previous: id, version: created.version });
    return created;
  });
}
