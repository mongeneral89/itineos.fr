/**
 * Habilitations des techniciens : types (communs au groupe), habilitations de chacun avec justificatif,
 * tableau par agence, et contrôle des habilitations exigées par une intervention.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, eq, inArray, isNull, or, sql } from 'drizzle-orm';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { certificationState } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canGroupWide, canSomewhere, type Principal } from '../auth/access.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { todayIn } from '../services/contracts.js';
import { parseDocumentDataUrl, readDocument, removeDocument, storeDocument } from '../services/documents.js';
import { missingCertifications } from '../services/certifications.js';
import { loadIntervention } from './interventions.js';

const ct = schema.certificationTypes;
const uc = schema.userCertifications;
const ra = schema.roleAssignments;

type Perm = 'certification.read' | 'certification.write';

/** Peut-on lire / gérer les habilitations de cet utilisateur ? (dans le périmètre d'une de ses affectations, ou soi-même en lecture) */
async function checkUser(p: Principal, userId: string, perm: Perm) {
  const [user] = await db.select({ id: schema.users.id, groupId: schema.users.groupId }).from(schema.users).where(eq(schema.users.id, userId));
  if (!user || user.groupId !== p.groupId) throw notFound('Utilisateur');
  if (perm === 'certification.read' && userId === p.userId && canSomewhere(p, 'certification.read.own')) return;
  const scopes = await db.select({ companyId: ra.companyId, agencyId: ra.agencyId }).from(ra).where(eq(ra.userId, userId));
  // Une personne rattachée à tout le groupe ne se gère que depuis le niveau groupe
  const ok = scopes.some((s) => (s.companyId ? can(p, perm, { companyId: s.companyId, agencyId: s.agencyId }) : canGroupWide(p, perm)));
  if (!ok) throw forbidden();
}

async function loadCert(p: Principal, id: string, perm: Perm) {
  const [row] = await db.select().from(uc).where(eq(uc.id, id));
  if (!row) throw notFound('Habilitation');
  await checkUser(p, row.userId, perm);
  return row;
}

const certBody = z.object({
  typeId: z.string().uuid(),
  obtainedOn: z.string().date().nullable().optional(),
  expiresOn: z.string().date().nullable().optional(),
  reference: z.string().trim().max(120).nullable().optional(),
  notes: z.string().max(1000).nullable().optional(),
  /** Justificatif : PDF, JPEG ou PNG en data URL (5 Mo maximum) */
  document: z.string().max(7_500_000).nullable().optional(),
}).refine((b) => !b.obtainedOn || !b.expiresOn || b.expiresOn >= b.obtainedOn, { message: "La date d'expiration doit suivre la date d'obtention", path: ['expiresOn'] });

async function saveDocument(certId: string, dataUrl: string) {
  const doc = parseDocumentDataUrl(dataUrl);
  if (!doc) throw badRequest('Justificatif illisible : PDF, JPEG ou PNG de 5 Mo maximum');
  return { documentPath: await storeDocument('certifications', certId, doc.ext, doc.buffer), documentMime: doc.mime };
}

export async function certificationRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  // ─── Types ───

  app.get('/certification-types', async (req) => {
    const p = req.principal;
    return db.select().from(ct).where(eq(ct.groupId, p.groupId)).orderBy(asc(ct.name));
  });

  const typeBody = z.object({
    code: z.string().trim().min(1, 'Le code est obligatoire').max(30),
    name: z.string().trim().min(1, 'Le nom est obligatoire').max(200),
    description: z.string().max(1000).nullable().optional(),
    validityMonths: z.number().int().min(1).max(240).nullable().optional(),
    active: z.boolean().optional(),
  });

  app.post('/certification-types', async (req, reply) => {
    const p = req.principal;
    if (!canSomewhere(p, 'certification.write')) throw forbidden();
    const body = typeBody.parse(req.body);
    const [dup] = await db.select({ id: ct.id }).from(ct).where(and(eq(ct.groupId, p.groupId), sql`lower(${ct.code}) = lower(${body.code})`));
    if (dup) throw conflict(`Le code « ${body.code} » existe déjà`);
    const [row] = await db.insert(ct).values({ ...body, groupId: p.groupId }).returning();
    await audit(p, 'create', 'certification_type', row.id, { code: row.code });
    return reply.code(201).send(row);
  });

  app.patch('/certification-types/:id', async (req) => {
    const p = req.principal;
    if (!canSomewhere(p, 'certification.write')) throw forbidden();
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const body = typeBody.partial().parse(req.body);
    const [row] = await db.update(ct).set(body).where(and(eq(ct.id, id), eq(ct.groupId, p.groupId))).returning();
    if (!row) throw notFound("Type d'habilitation");
    return row;
  });

  // ─── Tableau par société / agence : techniciens × habilitations ───

  app.get('/certifications', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid().optional() }).parse(req.query);
    if (!can(p, 'certification.read', { companyId: f.companyId, agencyId: f.agencyId ?? null }, { sharedVisible: true })) throw forbidden();
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    const today = todayIn(company.timezone);
    const techs = await db
      .selectDistinct({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName, agencyId: ra.agencyId })
      .from(ra).innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(
        eq(ra.role, 'TECHNICIAN'), eq(ra.companyId, f.companyId), eq(schema.users.active, true),
        f.agencyId ? or(eq(ra.agencyId, f.agencyId), isNull(ra.agencyId)) : undefined,
      ))
      .orderBy(asc(schema.users.lastName), asc(schema.users.firstName));
    // Un chef limité à une agence ne voit que ses techniciens
    const visible = techs.filter((t) => can(p, 'certification.read', { companyId: f.companyId, agencyId: t.agencyId }, { sharedVisible: true }));
    const ids = [...new Set(visible.map((t) => t.id))];
    const certs = ids.length
      ? await db.select({ id: uc.id, userId: uc.userId, typeId: uc.typeId, obtainedOn: uc.obtainedOn, expiresOn: uc.expiresOn, reference: uc.reference, hasDocument: sql<boolean>`${uc.documentPath} is not null` })
        .from(uc).where(inArray(uc.userId, ids))
      : [];
    const seen = new Set<string>();
    return {
      today,
      technicians: visible.filter((t) => !seen.has(t.id) && seen.add(t.id)).map((t) => ({
        ...t,
        certifications: certs.filter((c) => c.userId === t.id).map((c) => ({ ...c, state: certificationState(c.expiresOn, today) })),
      })),
    };
  });

  /** Habilitations d'une personne (le technicien voit les siennes) */
  app.get('/certifications/user/:userId', async (req) => {
    const p = req.principal;
    const { userId } = z.object({ userId: z.string().uuid() }).parse(req.params);
    await checkUser(p, userId, 'certification.read');
    // Date du jour dans le fuseau de la société de la personne (Paris par défaut)
    const [first] = await db.select({ tz: schema.companies.timezone }).from(ra)
      .innerJoin(schema.companies, eq(schema.companies.id, ra.companyId)).where(eq(ra.userId, userId)).limit(1);
    const today = todayIn(first?.tz ?? 'Europe/Paris');
    const rows = await db.select({ id: uc.id, typeId: uc.typeId, obtainedOn: uc.obtainedOn, expiresOn: uc.expiresOn, reference: uc.reference, notes: uc.notes,
      hasDocument: sql<boolean>`${uc.documentPath} is not null`, code: ct.code, name: ct.name })
      .from(uc).innerJoin(ct, eq(ct.id, uc.typeId)).where(eq(uc.userId, userId)).orderBy(asc(ct.name));
    return rows.map((r) => ({ ...r, state: certificationState(r.expiresOn, today) }));
  });

  app.post('/certifications', async (req, reply) => {
    const p = req.principal;
    const body = z.object({ userId: z.string().uuid() }).and(certBody).parse(req.body);
    await checkUser(p, body.userId, 'certification.write');
    const [type] = await db.select().from(ct).where(and(eq(ct.id, body.typeId), eq(ct.groupId, p.groupId)));
    if (!type) throw badRequest("Type d'habilitation inconnu");
    const id = randomUUID();
    const doc = body.document ? await saveDocument(id, body.document) : {};
    const [row] = await db.insert(uc).values({
      id, userId: body.userId, typeId: body.typeId, obtainedOn: body.obtainedOn ?? null, expiresOn: body.expiresOn ?? null,
      reference: body.reference ?? null, notes: body.notes ?? null, createdById: p.userId, ...doc,
    }).returning();
    await audit(p, 'create', 'certification', row.id, { userId: body.userId, type: type.code, expiresOn: row.expiresOn });
    return reply.code(201).send(row);
  });

  app.patch('/certifications/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadCert(p, id, 'certification.write');
    const body = z.object({
      obtainedOn: z.string().date().nullable().optional(),
      expiresOn: z.string().date().nullable().optional(),
      reference: z.string().trim().max(120).nullable().optional(),
      notes: z.string().max(1000).nullable().optional(),
      document: z.string().max(7_500_000).nullable().optional(),
    }).parse(req.body);
    const { document, ...fields } = body;
    const doc = document ? await saveDocument(id, document) : {};
    if (document && current.documentPath && current.documentPath !== (doc as { documentPath?: string }).documentPath) await removeDocument(current.documentPath);
    const [row] = await db.update(uc).set({ ...fields, ...doc, updatedAt: new Date() }).where(eq(uc.id, id)).returning();
    await audit(p, 'update', 'certification', id, fields);
    return row;
  });

  app.delete('/certifications/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadCert(p, id, 'certification.write');
    await db.delete(uc).where(eq(uc.id, id));
    if (current.documentPath) await removeDocument(current.documentPath);
    await audit(p, 'delete', 'certification', id, { userId: current.userId, typeId: current.typeId });
    return reply.code(204).send();
  });

  app.get('/certifications/:id/document', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const cert = await loadCert(p, id, 'certification.read');
    const file = cert.documentPath ? await readDocument(cert.documentPath) : null;
    if (!file) throw notFound('Justificatif');
    return reply.type(cert.documentMime ?? 'application/octet-stream').header('Content-Disposition', 'inline').send(file);
  });

  /** Ce qui manque au technicien pour cette intervention (à la date prévue, sinon aujourd'hui) */
  app.get('/certifications/check', async (req) => {
    const p = req.principal;
    const f = z.object({ interventionId: z.string().uuid(), technicianId: z.string().uuid(), on: z.string().date().optional() }).parse(req.query);
    const iv = await loadIntervention(p, f.interventionId);
    const company = (await getCompany(p.groupId, iv.companyId))!;
    const on = f.on ?? (iv.scheduledStart ? todayIn(company.timezone, iv.scheduledStart) : todayIn(company.timezone));
    return { missing: await missingCertifications(f.technicianId, iv.requiredCertificationIds, on) };
  });
}
