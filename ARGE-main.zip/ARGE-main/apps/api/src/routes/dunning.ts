/**
 * Relances des factures impayées : la liste des factures échues avec leur prochaine relance, l'envoi d'une relance
 * tout de suite, la suspension (litige, promesse de paiement) et l'historique d'une facture.
 * L'envoi automatique se règle dans les réglages de facturation de la société (services/dunning.ts).
 */
import type { FastifyInstance } from 'fastify';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { can, type Principal } from '../auth/access.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { todayIn } from '../services/contracts.js';
import { nextReminder, overdueInvoices, remindersOf, sendReminder } from '../services/dunning.js';
import { billsIn, settlements } from './invoices.js';

async function loadForWrite(p: Principal, id: string) {
  const [row] = await db.select().from(schema.invoices).where(eq(schema.invoices.id, id));
  if (!row || row.groupId !== p.groupId) throw notFound('Facture');
  if (!can(p, 'invoice.write', { companyId: row.companyId, agencyId: row.agencyId })) throw forbidden();
  return row;
}

export async function dunningRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Factures échues et pas entièrement réglées, avec leur prochaine relance */
  app.get('/billing/reminders', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.query);
    if (!billsIn(p, companyId)) throw forbidden();
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    const today = todayIn(company.timezone);
    const rows = (await overdueInvoices(companyId, today))
      .filter((r) => can(p, 'invoice.read', { companyId, agencyId: r.agencyId }));
    const history = await remindersOf(rows.map((r) => r.id));
    return {
      enabled: company.dunningEnabled, days: company.dunningDays, today,
      invoices: rows.map(({ clientEmail, ...r }) => ({
        ...r, hasEmail: !!clientEmail, next: nextReminder(r, company.dunningDays),
        reminders: history.filter((h) => h.invoiceId === r.id).map(({ invoiceId: _i, ...h }) => h),
      })),
      totalCents: rows.reduce((s, r) => s + r.remainingCents, 0),
    };
  });

  /** Relance tout de suite : le niveau suivant (ou celui demandé) */
  app.post('/invoices/:id/reminders', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const body = z.object({ level: z.union([z.literal(1), z.literal(2), z.literal(3)]).optional() }).parse(req.body ?? {});
    const row = await loadForWrite(p, id);
    if (row.kind !== 'INVOICE' || row.status !== 'ISSUED' || !row.dueDate) throw conflict('Seule une facture émise avec une échéance peut être relancée');
    const { paid, credited } = await settlements([id]);
    if (row.grossCents - (paid.get(id) ?? 0) - (credited.get(id) ?? 0) <= 0) throw conflict('Cette facture est réglée');
    const level = body.level ?? (Math.min(3, row.dunningLevel + 1) as 1 | 2 | 3);
    const to = await sendReminder(id, level, p.userId);
    if (!to) throw badRequest("Le client n'a pas d'adresse e-mail : ajoutez-la sur sa fiche");
    await audit(p, 'remind', 'invoice', id, { level, to });
    return { level, to };
  });

  /** Suspend ou reprend les relances d'une facture */
  app.patch('/invoices/:id/dunning', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { paused } = z.object({ paused: z.boolean() }).parse(req.body);
    await loadForWrite(p, id);
    await db.update(schema.invoices).set({ dunningPaused: paused, updatedAt: new Date() }).where(eq(schema.invoices.id, id));
    await audit(p, 'update', 'invoice.dunning', id, { paused });
    return { paused };
  });

  /** Relances envoyées pour une facture */
  app.get('/invoices/:id/reminders', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [row] = await db.select().from(schema.invoices).where(eq(schema.invoices.id, id));
    if (!row || row.groupId !== p.groupId) throw notFound('Facture');
    if (!can(p, 'invoice.read', { companyId: row.companyId, agencyId: row.agencyId })) throw forbidden();
    return { level: row.dunningLevel, paused: row.dunningPaused, reminders: await remindersOf([id]) };
  });
}
