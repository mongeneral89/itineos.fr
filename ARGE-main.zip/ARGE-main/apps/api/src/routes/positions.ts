/**
 * Géolocalisation des véhicules : partage activé par le technicien, envoi des positions depuis son téléphone,
 * carte du parc et trajet du jour pour le bureau. Voir services/positions.ts.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, gte, inArray, isNull, lt, or, sql } from 'drizzle-orm';
import { z } from 'zod';
import { addDays } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, scopeFor } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { conflict, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { todayIn } from '../services/contracts.js';
import { acceptablePositions, localDayStart as dayStart, POSITION_RETENTION_DAYS } from '../services/positions.js';

const v = schema.vehicles;
const vp = schema.vehiclePositions;
const iv = schema.interventions;

export async function positionRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Le partage de position du technicien connecté, et son véhicule */
  app.get('/me/location-sharing', async (req) => {
    const p = req.principal;
    const [user] = await db.select({ since: schema.users.locationSharingSince }).from(schema.users).where(eq(schema.users.id, p.userId));
    const [vehicle] = await db.select({ id: v.id, plate: v.plate }).from(v)
      .where(and(eq(v.driverId, p.userId), eq(v.groupId, p.groupId), eq(v.status, 'ACTIVE')));
    return { enabled: !!user?.since, since: user?.since ?? null, vehicle: vehicle ?? null, retentionDays: POSITION_RETENTION_DAYS };
  });

  /** Le technicien active ou arrête lui-même le partage de sa position */
  app.put('/me/location-sharing', async (req) => {
    const p = req.principal;
    const { enabled } = z.object({ enabled: z.boolean() }).parse(req.body);
    const since = enabled ? new Date() : null;
    const [current] = await db.select({ since: schema.users.locationSharingSince }).from(schema.users).where(eq(schema.users.id, p.userId));
    // Déjà activé : on garde la date d'origine
    const value = enabled ? current?.since ?? since : null;
    await db.update(schema.users).set({ locationSharingSince: value }).where(eq(schema.users.id, p.userId));
    if (!!current?.since !== enabled) await audit(p, enabled ? 'location.enable' : 'location.disable', 'user', p.userId);
    return { enabled, since: value };
  });

  /** Positions envoyées par le téléphone du conducteur (par lots : elles peuvent attendre le réseau) */
  app.post('/fleet/positions', async (req) => {
    const p = req.principal;
    const body = z.object({
      positions: z.array(z.object({
        lat: z.number(),
        lng: z.number(),
        accuracy: z.number().min(0).nullable().optional(),
        recordedAt: z.string().min(10),
        event: z.enum(['TRACK', 'EN_ROUTE', 'ON_SITE']).default('TRACK'),
        interventionId: z.string().uuid().nullable().optional(),
      })).min(1).max(200),
    }).parse(req.body);

    const [user] = await db.select({ since: schema.users.locationSharingSince }).from(schema.users).where(eq(schema.users.id, p.userId));
    if (!user?.since) throw conflict("Le partage de position n'est pas activé");
    const [vehicle] = await db.select().from(v)
      .where(and(eq(v.driverId, p.userId), eq(v.groupId, p.groupId), eq(v.status, 'ACTIVE')));
    // Pas de véhicule attribué : rien à suivre, ce n'est pas une erreur pour le téléphone
    if (!vehicle) return { stored: 0, vehicleId: null };

    const kept = acceptablePositions(body.positions, user.since);
    if (!kept.length) return { stored: 0, vehicleId: vehicle.id };
    // Une intervention n'est rattachée que si c'est bien celle du technicien
    const ivIds = [...new Set(kept.map((k) => k.interventionId).filter((x): x is string => !!x))];
    const own = ivIds.length
      ? new Set((await db.select({ id: iv.id }).from(iv).where(and(inArray(iv.id, ivIds), eq(iv.technicianId, p.userId)))).map((r) => r.id))
      : new Set<string>();

    await db.transaction(async (tx) => {
      await tx.insert(vp).values(kept.map((k) => ({
        vehicleId: vehicle.id, userId: p.userId, lat: k.lat, lng: k.lng,
        accuracyM: k.accuracy != null ? Math.round(k.accuracy) : null, recordedAt: k.at, event: k.event ?? 'TRACK',
        interventionId: k.interventionId && own.has(k.interventionId) ? k.interventionId : null,
      })));
      const last = kept[kept.length - 1];
      // La dernière position ne recule jamais (un lot ancien arrivé en retard ne l'écrase pas)
      await tx.update(v).set({
        lastLat: last.lat, lastLng: last.lng, lastAccuracyM: last.accuracy != null ? Math.round(last.accuracy) : null,
        lastPositionAt: last.at, lastPositionBy: p.userId,
      }).where(and(eq(v.id, vehicle.id), or(isNull(v.lastPositionAt), lt(v.lastPositionAt, last.at))));
      // « Je suis sur place » avec une position précise : le site sans coordonnées prend celles-ci
      // (sert à calculer les distances pour la suggestion d'attribution)
      for (const k of kept) {
        if (k.event !== 'ON_SITE' || !k.interventionId || !own.has(k.interventionId) || (k.accuracy ?? 9999) > 150) continue;
        const [job] = await tx.select({ siteId: iv.siteId }).from(iv).where(eq(iv.id, k.interventionId));
        if (job) {
          await tx.update(schema.sites).set({ latitude: k.lat, longitude: k.lng, geoSource: 'ON_SITE' })
            .where(and(eq(schema.sites.id, job.siteId), isNull(schema.sites.latitude)));
        }
      }
    });
    return { stored: kept.length, vehicleId: vehicle.id };
  });

  /** Carte du parc : dernière position de chaque véhicule, son conducteur et ce qu'il fait */
  app.get('/fleet/map', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid().optional() }).parse(req.query);
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'fleet.read', { companyId: f.companyId, agencyId: f.agencyId ?? null }, { sharedVisible: true })) throw forbidden();
    const rows = await db.select({
      id: v.id, plate: v.plate, make: v.make, model: v.model, status: v.status, agencyId: v.agencyId, driverId: v.driverId,
      lat: v.lastLat, lng: v.lastLng, accuracyM: v.lastAccuracyM, positionAt: v.lastPositionAt,
      driverFirstName: schema.users.firstName, driverLastName: schema.users.lastName, sharingSince: schema.users.locationSharingSince,
    })
      .from(v).leftJoin(schema.users, eq(schema.users.id, v.driverId))
      .where(and(
        eq(v.companyId, f.companyId),
        scopeWhere(scopeFor(p, 'fleet.read'), { companyId: v.companyId, agencyId: v.agencyId }, { sharedVisible: true }),
        f.agencyId ? or(eq(v.agencyId, f.agencyId), isNull(v.agencyId)) : undefined,
        inArray(v.status, ['ACTIVE', 'IMMOBILIZED']),
      ))
      .orderBy(asc(v.plate));

    // Ce que fait chaque conducteur aujourd'hui : intervention en route / sur place, sinon la prochaine prévue
    const today = todayIn(company.timezone);
    const from = dayStart(today, company.timezone);
    const to = dayStart(addDays(today, 1), company.timezone);
    const drivers = rows.map((r) => r.driverId).filter((x): x is string => !!x);
    const jobs = drivers.length
      ? await db.select({
        technicianId: iv.technicianId, id: iv.id, number: iv.number, status: iv.status, reason: iv.reason, scheduledStart: iv.scheduledStart,
        clientName: schema.clients.name, siteCity: schema.sites.city,
      }).from(iv)
        .innerJoin(schema.clients, eq(schema.clients.id, iv.clientId))
        .innerJoin(schema.sites, eq(schema.sites.id, iv.siteId))
        .where(and(inArray(iv.technicianId, drivers), gte(iv.scheduledStart, from), lt(iv.scheduledStart, to)))
        .orderBy(asc(iv.scheduledStart))
      : [];
    return {
      today,
      vehicles: rows.map(({ sharingSince, ...r }) => {
        const mine = jobs.filter((j) => j.technicianId === r.driverId);
        const current = mine.find((j) => j.status === 'EN_ROUTE' || j.status === 'ON_SITE')
          ?? mine.find((j) => j.status === 'PLANNED') ?? null;
        return { ...r, sharing: !!sharingSince, job: current };
      }),
    };
  });

  /** Trajet d'un véhicule sur une journée (positions dans l'ordre) */
  app.get('/fleet/vehicles/:id/track', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const q = z.object({ date: z.string().date().optional() }).parse(req.query);
    const [vehicle] = await db.select().from(v).where(and(eq(v.id, id), eq(v.groupId, p.groupId)));
    if (!vehicle) throw notFound('Véhicule');
    const target = { companyId: vehicle.companyId, agencyId: vehicle.agencyId };
    const isDriver = vehicle.driverId === p.userId && can(p, 'fleet.read.own', target, { sharedVisible: true });
    if (!isDriver && !can(p, 'fleet.read', target, { sharedVisible: true })) throw forbidden();
    const company = (await getCompany(p.groupId, vehicle.companyId))!;
    const day = q.date ?? todayIn(company.timezone);
    const from = dayStart(day, company.timezone);
    const to = dayStart(addDays(day, 1), company.timezone);
    const points = await db.select({
      lat: vp.lat, lng: vp.lng, accuracyM: vp.accuracyM, recordedAt: vp.recordedAt, event: vp.event,
      interventionNumber: iv.number,
    }).from(vp).leftJoin(iv, eq(iv.id, vp.interventionId))
      .where(and(eq(vp.vehicleId, id), gte(vp.recordedAt, from), lt(vp.recordedAt, to)))
      .orderBy(asc(vp.recordedAt));
    // Jours pour lesquels un trajet existe (30 derniers jours)
    const days = await db.selectDistinct({
      day: sql<string>`to_char(${vp.recordedAt} AT TIME ZONE ${company.timezone}, 'YYYY-MM-DD')`,
    }).from(vp).where(eq(vp.vehicleId, id)).orderBy(desc(sql`1`)).limit(31);
    return { date: day, points, days: days.map((d) => d.day) };
  });
}
