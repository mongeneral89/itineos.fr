/**
 * Parc véhicules : véhicules, échéances (entretien, contrôle technique, assurance…), rendez-vous,
 * carnet d'entretien, kilométrage. Et la liste « À programmer ».
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, inArray, isNull, or, sql } from 'drizzle-orm';
import { z } from 'zod';
import {
  nextVehicleDeadline, OWNERSHIPS, VEHICLE_DEADLINE_KINDS, VEHICLE_EVENT_KINDS, VEHICLE_STATUSES, VEHICLE_TYPES,
  vehicleDeadlineState, type DueState,
} from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { todayIn } from '../services/contracts.js';
import { certificationsDue, vehiclesDue } from '../services/deadlines.js';
import { isTechnicianFor } from './interventions.js';

const v = schema.vehicles;
const dl = schema.vehicleDeadlines;
const ev = schema.vehicleEvents;

type Perm = 'fleet.read' | 'fleet.write';

/** Un véhicule ; son conducteur peut le consulter et y noter son kilométrage */
async function loadVehicle(p: Principal, id: string, perm: Perm, opts: { driverMayWrite?: boolean } = {}) {
  const [row] = await db.select().from(v).where(and(eq(v.id, id), eq(v.groupId, p.groupId)));
  if (!row) throw notFound('Véhicule');
  const target = { companyId: row.companyId, agencyId: row.agencyId };
  const isDriver = row.driverId === p.userId && can(p, 'fleet.read.own', target, { sharedVisible: true });
  if (isDriver && (perm === 'fleet.read' || opts.driverMayWrite)) return row;
  if (!can(p, perm, target, { sharedVisible: true })) throw forbidden();
  return row;
}

/** « ab 123 cd », « AB-123-CD » et « AB123CD » sont la même immatriculation */
const normalizePlate = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, '');
const samePlate = (plate: string) => sql`upper(regexp_replace(${v.plate}, '[^A-Za-z0-9]', '', 'g')) = ${normalizePlate(plate)}`;

const vehicleBody = z.object({
  agencyId: z.string().uuid().nullable().optional(),
  plate: z.string().trim().min(2, "L'immatriculation est obligatoire").max(20),
  type: z.enum(VEHICLE_TYPES).default('VAN'),
  make: z.string().trim().max(60).nullable().optional(),
  model: z.string().trim().max(60).nullable().optional(),
  vin: z.string().trim().max(30).nullable().optional(),
  fuel: z.string().trim().max(30).nullable().optional(),
  firstRegistration: z.string().date().nullable().optional(),
  ownership: z.enum(OWNERSHIPS).default('OWNED'),
  lessor: z.string().trim().max(100).nullable().optional(),
  status: z.enum(VEHICLE_STATUSES).default('ACTIVE'),
  mileage: z.number().int().min(0).max(5_000_000).nullable().optional(),
  driverId: z.string().uuid().nullable().optional(),
  stockLocationId: z.string().uuid().nullable().optional(),
  notes: z.string().max(2000).nullable().optional(),
});

const deadlineBody = z.object({
  kind: z.enum(VEHICLE_DEADLINE_KINDS),
  label: z.string().trim().max(120).nullable().optional(),
  dueDate: z.string().date().nullable().optional(),
  dueMileage: z.number().int().min(0).max(5_000_000).nullable().optional(),
  intervalMonths: z.number().int().min(1).max(120).nullable().optional(),
  intervalKm: z.number().int().min(100).max(1_000_000).nullable().optional(),
  appointmentOn: z.string().date().nullable().optional(),
  appointmentWith: z.string().trim().max(120).nullable().optional(),
});

async function checkVehicleRefs(companyId: string, b: { agencyId?: string | null; driverId?: string | null; stockLocationId?: string | null }) {
  if (b.agencyId && !(await getAgency(companyId, b.agencyId))) throw badRequest('Agence inconnue');
  if (b.driverId) {
    const [u] = await db.select({ id: schema.roleAssignments.id }).from(schema.roleAssignments)
      .where(and(eq(schema.roleAssignments.userId, b.driverId), eq(schema.roleAssignments.companyId, companyId))).limit(1);
    if (!u) throw badRequest("Ce conducteur ne fait pas partie de la société");
  }
  if (b.stockLocationId) {
    const [l] = await db.select().from(schema.stockLocations).where(eq(schema.stockLocations.id, b.stockLocationId));
    if (!l || l.companyId !== companyId) throw badRequest('Lieu de stock inconnu');
  }
}

/** La pire échéance d'un véhicule, et la prochaine date */
function summarize(deadlines: (typeof dl.$inferSelect)[], today: string, mileage: number | null) {
  const states = deadlines.filter((d) => d.active).map((d) => ({ d, s: vehicleDeadlineState(d, today, mileage) }));
  const worst: DueState = states.some((x) => x.s === 'OVERDUE') ? 'OVERDUE' : states.some((x) => x.s === 'SOON') ? 'SOON' : states.length ? 'OK' : 'NONE';
  const next = states.filter((x) => x.d.dueDate).sort((a, b) => a.d.dueDate!.localeCompare(b.d.dueDate!))[0]?.d ?? null;
  return { worstState: worst, nextDue: next ? { kind: next.kind, label: next.label, dueDate: next.dueDate } : null };
}

export async function fleetRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/fleet/vehicles', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid().optional(), all: z.coerce.boolean().optional() }).parse(req.query);
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    const rows = await db.select({
      vehicle: v, driverFirstName: schema.users.firstName, driverLastName: schema.users.lastName,
    })
      .from(v).leftJoin(schema.users, eq(schema.users.id, v.driverId))
      .where(and(
        eq(v.companyId, f.companyId),
        scopeWhere(scopeFor(p, 'fleet.read'), { companyId: v.companyId, agencyId: v.agencyId }, { sharedVisible: true }),
        f.agencyId ? or(eq(v.agencyId, f.agencyId), isNull(v.agencyId)) : undefined,
        f.all ? undefined : inArray(v.status, ['ACTIVE', 'IMMOBILIZED']),
      ))
      .orderBy(asc(v.plate));
    const ids = rows.map((r) => r.vehicle.id);
    const deadlines = ids.length ? await db.select().from(dl).where(inArray(dl.vehicleId, ids)) : [];
    const today = todayIn(company.timezone);
    return rows.map((r) => ({
      ...r.vehicle, driverFirstName: r.driverFirstName, driverLastName: r.driverLastName,
      ...summarize(deadlines.filter((d) => d.vehicleId === r.vehicle.id), today, r.vehicle.mileage),
    }));
  });

  app.get('/fleet/vehicles/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const vehicle = await loadVehicle(p, id, 'fleet.read');
    const company = (await getCompany(p.groupId, vehicle.companyId))!;
    const today = todayIn(company.timezone);
    const deadlines = await db.select().from(dl).where(eq(dl.vehicleId, id)).orderBy(asc(dl.dueDate));
    const events = await db.select().from(ev).where(eq(ev.vehicleId, id)).orderBy(desc(ev.occurredOn), desc(ev.createdAt)).limit(200);
    const [driver] = vehicle.driverId
      ? await db.select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, vehicle.driverId))
      : [null];
    const [stock] = vehicle.stockLocationId
      ? await db.select({ id: schema.stockLocations.id, name: schema.stockLocations.name }).from(schema.stockLocations).where(eq(schema.stockLocations.id, vehicle.stockLocationId))
      : [null];
    const year = today.slice(0, 4);
    const costThisYear = events.filter((e) => e.occurredOn.startsWith(year)).reduce((s, e) => s + (e.costCents ?? 0), 0);
    return {
      ...vehicle, driver: driver ?? null, stockLocation: stock ?? null, today, costThisYear,
      deadlines: deadlines.map((d) => ({ ...d, state: vehicleDeadlineState(d, today, vehicle.mileage) })),
      events,
    };
  });

  app.post('/fleet/vehicles', async (req, reply) => {
    const p = req.principal;
    const body = vehicleBody.extend({ companyId: z.string().uuid() }).parse(req.body);
    const company = await getCompany(p.groupId, body.companyId);
    if (!company) throw badRequest('Société inconnue');
    if (!can(p, 'fleet.write', { companyId: company.id, agencyId: body.agencyId ?? null })) throw forbidden();
    await checkVehicleRefs(company.id, body);
    const [dup] = await db.select({ id: v.id }).from(v).where(and(eq(v.companyId, company.id), samePlate(body.plate)));
    if (dup) throw conflict(`Le véhicule ${body.plate} existe déjà`);
    const [row] = await db.insert(v).values({
      ...body, plate: body.plate.toUpperCase(), groupId: p.groupId,
      mileageUpdatedOn: body.mileage != null ? todayIn(company.timezone) : null,
    }).returning();
    await audit(p, 'create', 'vehicle', row.id, { plate: row.plate });
    return reply.code(201).send(row);
  });

  app.patch('/fleet/vehicles/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadVehicle(p, id, 'fleet.write');
    const body = vehicleBody.partial().parse(req.body);
    await checkVehicleRefs(current.companyId, body);
    if (body.agencyId !== undefined && !can(p, 'fleet.write', { companyId: current.companyId, agencyId: body.agencyId })) throw forbidden();
    if (body.plate && normalizePlate(body.plate) !== normalizePlate(current.plate)) {
      const [dup] = await db.select({ id: v.id }).from(v).where(and(eq(v.companyId, current.companyId), samePlate(body.plate)));
      if (dup) throw conflict(`Le véhicule ${body.plate} existe déjà`);
    }
    const [row] = await db.update(v).set({ ...body, ...(body.plate ? { plate: body.plate.toUpperCase() } : {}) }).where(eq(v.id, id)).returning();
    await audit(p, 'update', 'vehicle', id, body);
    return row;
  });

  // ─── Échéances ───

  app.post('/fleet/vehicles/:id/deadlines', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadVehicle(p, id, 'fleet.write');
    const body = deadlineBody.parse(req.body);
    if (!body.dueDate && body.dueMileage == null) throw badRequest('Indiquez une date et/ou un kilométrage d’échéance');
    const [row] = await db.insert(dl).values({ ...body, vehicleId: id }).returning();
    await audit(p, 'create', 'vehicle_deadline', row.id, { vehicleId: id, kind: row.kind });
    return reply.code(201).send(row);
  });

  app.patch('/fleet/deadlines/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(dl).where(eq(dl.id, id));
    if (!current) throw notFound('Échéance');
    await loadVehicle(p, current.vehicleId, 'fleet.write');
    const body = deadlineBody.partial().extend({ active: z.boolean().optional() }).parse(req.body);
    const next = { ...current, ...body };
    if (!next.dueDate && next.dueMileage == null) throw badRequest('Indiquez une date et/ou un kilométrage d’échéance');
    const [row] = await db.update(dl).set(body).where(eq(dl.id, id)).returning();
    await audit(p, 'update', 'vehicle_deadline', id, body);
    return row;
  });

  app.delete('/fleet/deadlines/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(dl).where(eq(dl.id, id));
    if (!current) throw notFound('Échéance');
    await loadVehicle(p, current.vehicleId, 'fleet.write');
    await db.delete(dl).where(eq(dl.id, id));
    return reply.code(204).send();
  });

  // ─── Carnet d'entretien ───

  /**
   * Un événement (entretien, réparation, contrôle…). S'il solde une échéance, la suivante est recalculée
   * (date + intervalle, kilométrage + intervalle) et le rendez-vous est effacé.
   */
  app.post('/fleet/vehicles/:id/events', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const vehicle = await loadVehicle(p, id, 'fleet.write');
    const body = z.object({
      kind: z.enum(VEHICLE_EVENT_KINDS),
      occurredOn: z.string().date(),
      mileage: z.number().int().min(0).max(5_000_000).nullable().optional(),
      costCents: z.number().int().min(0).max(100_000_000).nullable().optional(),
      provider: z.string().trim().max(120).nullable().optional(),
      description: z.string().max(2000).nullable().optional(),
      deadlineId: z.string().uuid().nullable().optional(),
    }).parse(req.body);
    const [deadline] = body.deadlineId ? await db.select().from(dl).where(and(eq(dl.id, body.deadlineId), eq(dl.vehicleId, id))) : [null];
    if (body.deadlineId && !deadline) throw badRequest("Cette échéance n'appartient pas au véhicule");
    const row = await db.transaction(async (tx) => {
      const [event] = await tx.insert(ev).values({ ...body, vehicleId: id, createdById: p.userId }).returning();
      if (body.mileage != null && (vehicle.mileage == null || body.mileage > vehicle.mileage)) {
        await tx.update(v).set({ mileage: body.mileage, mileageUpdatedOn: body.occurredOn }).where(eq(v.id, id));
      }
      if (deadline) {
        const next = nextVehicleDeadline(deadline, body.occurredOn, body.mileage ?? vehicle.mileage);
        const recurring = next.dueDate || next.dueMileage != null;
        await tx.update(dl).set(recurring
          ? { dueDate: next.dueDate, dueMileage: next.dueMileage, appointmentOn: null, appointmentWith: null }
          : { active: false, appointmentOn: null, appointmentWith: null }).where(eq(dl.id, deadline.id));
      }
      return event;
    });
    await audit(p, 'create', 'vehicle_event', row.id, { vehicleId: id, kind: row.kind, deadlineId: body.deadlineId });
    return reply.code(201).send(row);
  });

  app.delete('/fleet/events/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(ev).where(eq(ev.id, id));
    if (!current) throw notFound('Événement');
    await loadVehicle(p, current.vehicleId, 'fleet.write');
    await db.delete(ev).where(eq(ev.id, id));
    await audit(p, 'delete', 'vehicle_event', id, { vehicleId: current.vehicleId, kind: current.kind });
    return reply.code(204).send();
  });

  /** Relevé kilométrique (le conducteur peut le faire pour son véhicule) */
  app.post('/fleet/vehicles/:id/mileage', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const vehicle = await loadVehicle(p, id, 'fleet.write', { driverMayWrite: true });
    const body = z.object({ mileage: z.number().int().min(0).max(5_000_000) }).parse(req.body);
    if (vehicle.mileage != null && body.mileage < vehicle.mileage) {
      throw badRequest(`Le compteur ne peut pas reculer : dernier relevé ${vehicle.mileage} km`);
    }
    const company = (await getCompany(p.groupId, vehicle.companyId))!;
    const today = todayIn(company.timezone);
    await db.transaction(async (tx) => {
      await tx.update(v).set({ mileage: body.mileage, mileageUpdatedOn: today }).where(eq(v.id, id));
      await tx.insert(ev).values({ vehicleId: id, kind: 'MILEAGE', occurredOn: today, mileage: body.mileage, createdById: p.userId });
    });
    return reply.code(201).send({ mileage: body.mileage });
  });

  /** Le véhicule dont on est le conducteur */
  app.get('/fleet/my-vehicle', async (req) => {
    const p = req.principal;
    const [row] = await db.select().from(v).where(and(eq(v.driverId, p.userId), eq(v.groupId, p.groupId), eq(v.status, 'ACTIVE')));
    return { vehicle: row ?? null };
  });

  // ─── À programmer / échéances ───

  /** Véhicules : échéances proches ou dépassées. Habilitations : qui expirent bientôt ou ont expiré. */
  app.get('/deadlines', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid().optional() }).parse(req.query);
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    const today = todayIn(company.timezone);
    const inAgency = (agencyId: string | null) => !f.agencyId || agencyId === f.agencyId || agencyId === null;
    const vehicles = can(p, 'fleet.read', { companyId: f.companyId, agencyId: f.agencyId ?? null }, { sharedVisible: true })
      ? (await vehiclesDue(f.companyId, today)).filter((x) => inAgency(x.agencyId) && can(p, 'fleet.read', { companyId: f.companyId, agencyId: x.agencyId }, { sharedVisible: true }))
      : [];
    const certifications = can(p, 'certification.read', { companyId: f.companyId, agencyId: f.agencyId ?? null }, { sharedVisible: true })
      ? (await certificationsDue(f.companyId, today)).filter((x) => inAgency(x.agencyId) && can(p, 'certification.read', { companyId: f.companyId, agencyId: x.agencyId }, { sharedVisible: true }))
      : [];
    return { today, vehicles, certifications };
  });

  /** Le technicien peut-il conduire / est-il rattaché ? (utilisé pour proposer les conducteurs) */
  app.get('/fleet/drivers', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid() }).parse(req.query);
    if (!can(p, 'fleet.read', { companyId: f.companyId, agencyId: f.agencyId })) throw forbidden();
    const ra = schema.roleAssignments;
    const users = await db.selectDistinct({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName })
      .from(ra).innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(eq(ra.companyId, f.companyId), or(eq(ra.agencyId, f.agencyId), isNull(ra.agencyId)), eq(schema.users.active, true)))
      .orderBy(asc(schema.users.lastName));
    const techs = await Promise.all(users.map(async (u) => ({ ...u, technician: await isTechnicianFor(u.id, f.companyId, f.agencyId) })));
    return techs;
  });
}
