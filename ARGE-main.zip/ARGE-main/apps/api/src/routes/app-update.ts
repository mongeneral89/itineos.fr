/**
 * Appli Android : version publiée et téléchargement (sans connexion, pour pouvoir mettre à jour une appli dont
 * la connexion ne marche plus), et publication d'une nouvelle version par un administrateur du groupe.
 * L'APK ne contient aucune donnée : l'adresse du serveur et le compte se saisissent dans l'appli.
 */
import type { FastifyInstance } from 'fastify';
import { createReadStream } from 'node:fs';
import { canGroupWide } from '../auth/access.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { audit } from '../services/audit.js';
import { apkPath, currentRelease, looksLikeApk, MAX_APK_BYTES, publishRelease, releaseInput } from '../services/app-update.js';

const APK_MIME = 'application/vnd.android.package-archive';

export async function appUpdateRoutes(app: FastifyInstance) {
  app.get('/app/android', async () => {
    const r = await currentRelease();
    return r ? { versionCode: r.versionCode, versionName: r.versionName, notes: r.notes, size: r.size, sha256: r.sha256, publishedAt: r.publishedAt } : { versionCode: 0 };
  });

  app.get('/app/android.apk', async (_req, reply) => {
    const r = await currentRelease();
    if (!r) throw notFound('Appli');
    return reply.type(APK_MIME)
      .header('Content-Length', r.size)
      .header('Content-Disposition', `attachment; filename="appli-${r.versionCode}.apk"`)
      .header('Cache-Control', 'no-store')
      .send(createReadStream(apkPath()));
  });

  // Publication : l'APK arrive telle quelle dans le corps de la requête, la version dans l'adresse
  await app.register(async (admin) => {
    admin.addContentTypeParser(APK_MIME, { parseAs: 'buffer', bodyLimit: MAX_APK_BYTES }, (_req, body, done) => done(null, body));
    // Compte et droits vérifiés avant de lire le corps : 150 Mo ne sont reçus que d'un administrateur
    admin.addHook('onRequest', admin.authenticate);
    admin.addHook('onRequest', async (req) => {
      if (!canGroupWide(req.principal, 'org.write')) throw forbidden();
    });
    admin.put('/app/android', { bodyLimit: MAX_APK_BYTES }, async (req) => {
      const p = req.principal;
      const input = releaseInput.parse(req.query);
      const apk = req.body;
      if (!Buffer.isBuffer(apk) || !looksLikeApk(apk)) throw badRequest('Fichier refusé : ce n’est pas une APK Android');
      const current = await currentRelease();
      if (current && input.versionCode <= current.versionCode) {
        throw badRequest('Le numéro de version doit être plus grand que celui déjà publié');
      }
      const release = await publishRelease(apk, input);
      await audit(p, 'publish', 'android_app', null, { versionCode: release.versionCode, versionName: release.versionName });
      return release;
    });
  });
}
