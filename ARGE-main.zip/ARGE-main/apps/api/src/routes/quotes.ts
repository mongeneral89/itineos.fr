/**
 * Devis : création, envoi en PDF, acceptation, puis intervention ou contrat d'entretien.
 *
 * Cycle : DRAFT (modifiable) → SENT → ACCEPTED / REFUSED. Un devis envoyé peut repasser en brouillon pour être corrigé.
 */
import { clientLocale, docTexts } from '../services/doc-i18n.js';
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, ilike, inArray, isNull, or } from 'drizzle-orm';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import {
  addDays, documentTotals, INTERVENTION_KINDS, QUOTE_KINDS, QUOTE_STATUSES, type QuoteStatus,
} from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { companyLogo } from '../services/logo.js';
import { env } from '../env.js';
import { can, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { nextInterventionNumber, nextNumber } from '../services/numbering.js';
import { oneLineAddress } from '../services/prefill.js';
import { generateQuotePdf } from '../services/document-pdf.js';
import { sendMail } from '../services/mail.js';
import { generateContractVisits, todayIn } from '../services/contracts.js';

const q = schema.quotes;

const lineBody = z.object({
  description: z.string().trim().min(1, 'Chaque ligne doit avoir une désignation').max(2000),
  quantity: z.number().positive('La quantité doit être positive').max(1_000_000),
  unit: z.string().trim().max(20).nullable().optional(),
  unitPriceCents: z.number().int().min(-100_000_000).max(1_000_000_000),
  vatRateBp: z.number().int().min(0).max(10_000),
});

const quoteBody = z.object({
  agencyId: z.string().uuid().nullable().optional(),
  clientId: z.string().uuid(),
  siteId: z.string().uuid().nullable().optional(),
  kind: z.enum(QUOTE_KINDS).default('WORK'),
  title: z.string().trim().min(1, "L'objet du devis est obligatoire").max(300),
  intro: z.string().max(5000).nullable().optional(),
  notes: z.string().max(5000).nullable().optional(),
  validUntil: z.string().date().nullable().optional(),
  contractFrequencyMonths: z.number().int().min(1).max(60).nullable().optional(),
  lines: z.array(lineBody).max(200).default([]),
});

/** Transitions de statut autorisées à la main */
const TRANSITIONS: Record<QuoteStatus, QuoteStatus[]> = {
  DRAFT: ['CANCELLED'],
  SENT: ['ACCEPTED', 'REFUSED', 'CANCELLED', 'DRAFT'],
  ACCEPTED: [],
  REFUSED: ['DRAFT'],
  CANCELLED: ['DRAFT'],
};

async function loadQuote(p: Principal, id: string, perm: 'quote.read' | 'quote.write') {
  const [row] = await db.select().from(q).where(and(eq(q.id, id), eq(q.groupId, p.groupId)));
  if (!row) throw notFound('Devis');
  if (!can(p, perm, { companyId: row.companyId, agencyId: row.agencyId }, { sharedVisible: perm === 'quote.read' })) throw forbidden();
  return row;
}

/** Vérifie le client, le site et l'agence d'un devis, et que l'utilisateur peut écrire à cet endroit */
async function checkTargets(p: Principal, body: { clientId: string; siteId?: string | null; agencyId?: string | null }) {
  const [client] = await db.select().from(schema.clients)
    .where(and(eq(schema.clients.id, body.clientId), eq(schema.clients.groupId, p.groupId)));
  if (!client) throw badRequest('Client inconnu');
  const company = await getCompany(p.groupId, client.companyId);
  if (!company) throw badRequest('Société inconnue');
  const agencyId = body.agencyId ?? client.agencyId ?? null;
  if (agencyId && !(await getAgency(company.id, agencyId))) throw badRequest('Agence inconnue');
  if (body.siteId) {
    const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, body.siteId));
    if (!site || site.clientId !== client.id) throw badRequest("Ce site n'appartient pas au client");
  }
  if (!can(p, 'quote.write', { companyId: company.id, agencyId })) throw forbidden();
  return { client, company, agencyId };
}

/** Les équipements d'un contrat doivent se trouver sur son site */
export async function checkEquipments(siteId: string, equipmentIds: string[]) {
  if (!equipmentIds.length) return;
  const found = await db.select({ id: schema.equipments.id }).from(schema.equipments)
    .where(and(inArray(schema.equipments.id, equipmentIds), eq(schema.equipments.siteId, siteId)));
  if (found.length !== new Set(equipmentIds).size) throw badRequest("Un des équipements n'est pas sur ce site");
}

function totalsOf(lines: z.infer<typeof lineBody>[]) {
  const t = documentTotals(lines);
  return { netCents: t.netCents, vatCents: t.vatCents, grossCents: t.grossCents };
}

async function loadFull(id: string) {
  const [quote] = await db.select().from(q).where(eq(q.id, id));
  const lines = await db.select().from(schema.quoteLines).where(eq(schema.quoteLines.quoteId, id)).orderBy(asc(schema.quoteLines.position));
  const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, quote.clientId));
  const [site] = quote.siteId ? await db.select().from(schema.sites).where(eq(schema.sites.id, quote.siteId)) : [null];
  const interventions = await db
    .select({ id: schema.interventions.id, number: schema.interventions.number, status: schema.interventions.status })
    .from(schema.interventions).where(eq(schema.interventions.quoteId, id));
  const contracts = await db
    .select({ id: schema.contracts.id, number: schema.contracts.number, status: schema.contracts.status })
    .from(schema.contracts).where(eq(schema.contracts.quoteId, id));
  return { ...quote, lines, client, site: site ?? null, interventions, contracts };
}

async function buildPdf(quote: typeof q.$inferSelect) {
  const full = await loadFull(quote.id);
  const company = (await getCompany(quote.groupId, quote.companyId))!;
  const agency = quote.agencyId ? await getAgency(company.id, quote.agencyId) : null;
  return generateQuotePdf({
    locale: clientLocale(full.client, company),
    currency: quote.currency,
    company: { ...company, logo: await companyLogo(company) },
    agencyName: agency?.name ?? null,
    quote: {
      number: quote.number, title: quote.title, intro: quote.intro, notes: quote.notes, kind: quote.kind,
      contractFrequencyMonths: quote.contractFrequencyMonths,
      date: todayIn(company.timezone, quote.sentAt ?? quote.createdAt),
      validUntil: quote.validUntil,
    },
    client: {
      name: full.client.name,
      address: oneLineAddress(full.client.address, full.client.postalCode, full.client.city),
      email: full.client.email,
    },
    site: full.site ? { name: full.site.name, address: oneLineAddress(full.site.address, full.site.postalCode, full.site.city) } : null,
    lines: full.lines,
  });
}

export async function quoteRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/quotes', async (req) => {
    const p = req.principal;
    const f = z.object({
      companyId: z.string().uuid().optional(),
      agencyId: z.string().uuid().optional(),
      clientId: z.string().uuid().optional(),
      status: z.enum(QUOTE_STATUSES).optional(),
      q: z.string().optional(),
      limit: z.coerce.number().int().min(1).max(500).default(200),
    }).parse(req.query);
    const term = f.q?.trim();
    return db
      .select({
        id: q.id, number: q.number, companyId: q.companyId, agencyId: q.agencyId, clientId: q.clientId,
        kind: q.kind, status: q.status, title: q.title, validUntil: q.validUntil, currency: q.currency,
        netCents: q.netCents, grossCents: q.grossCents, sentAt: q.sentAt, createdAt: q.createdAt,
        clientName: schema.clients.name,
      })
      .from(q)
      .innerJoin(schema.clients, eq(schema.clients.id, q.clientId))
      .where(and(
        eq(q.groupId, p.groupId),
        scopeWhere(scopeFor(p, 'quote.read'), { companyId: q.companyId, agencyId: q.agencyId }, { sharedVisible: true }),
        f.companyId ? eq(q.companyId, f.companyId) : undefined,
        // Une agence voit ses devis et ceux faits au niveau de la société
        f.agencyId ? or(eq(q.agencyId, f.agencyId), isNull(q.agencyId)) : undefined,
        f.clientId ? eq(q.clientId, f.clientId) : undefined,
        f.status ? eq(q.status, f.status) : undefined,
        term ? or(ilike(q.title, `%${term}%`), ilike(q.number, `%${term}%`), ilike(schema.clients.name, `%${term}%`)) : undefined,
      ))
      .orderBy(desc(q.createdAt))
      .limit(f.limit);
  });

  app.get('/quotes/:id', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadQuote(req.principal, id, 'quote.read');
    return loadFull(id);
  });

  app.post('/quotes', async (req, reply) => {
    const p = req.principal;
    const body = quoteBody.extend({ sourceInterventionId: z.string().uuid().nullable().optional() }).parse(req.body);
    const { company, agencyId } = await checkTargets(p, body);
    const created = await db.transaction(async (tx) => {
      const number = await nextNumber(tx, company, 'quote');
      const [row] = await tx.insert(q).values({
        groupId: p.groupId,
        companyId: company.id,
        agencyId,
        number,
        clientId: body.clientId,
        siteId: body.siteId ?? null,
        kind: body.kind,
        title: body.title,
        intro: body.intro ?? null,
        notes: body.notes ?? null,
        validUntil: body.validUntil ?? addDays(todayIn(company.timezone), 30),
        contractFrequencyMonths: body.kind === 'CONTRACT' ? body.contractFrequencyMonths ?? 12 : null,
        currency: company.currency,
        sourceInterventionId: body.sourceInterventionId ?? null,
        createdById: p.userId,
        ...totalsOf(body.lines),
      }).returning();
      if (body.lines.length) {
        await tx.insert(schema.quoteLines).values(body.lines.map((l, i) => ({ ...l, unit: l.unit ?? null, quoteId: row.id, position: i })));
      }
      return row;
    });
    await audit(p, 'create', 'quote', created.id, { number: created.number });
    return reply.code(201).send(await loadFull(created.id));
  });

  app.put('/quotes/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadQuote(p, id, 'quote.write');
    if (current.status !== 'DRAFT') throw conflict('Seul un devis en brouillon peut être modifié');
    const body = quoteBody.parse(req.body);
    if (body.clientId !== current.clientId) throw badRequest('Le client d’un devis ne peut pas changer : créez un nouveau devis');
    const { agencyId } = await checkTargets(p, body);
    await db.transaction(async (tx) => {
      await tx.update(q).set({
        agencyId,
        siteId: body.siteId ?? null,
        kind: body.kind,
        title: body.title,
        intro: body.intro ?? null,
        notes: body.notes ?? null,
        validUntil: body.validUntil ?? current.validUntil,
        contractFrequencyMonths: body.kind === 'CONTRACT' ? body.contractFrequencyMonths ?? 12 : null,
        updatedAt: new Date(),
        ...totalsOf(body.lines),
      }).where(eq(q.id, id));
      await tx.delete(schema.quoteLines).where(eq(schema.quoteLines.quoteId, id));
      if (body.lines.length) {
        await tx.insert(schema.quoteLines).values(body.lines.map((l, i) => ({ ...l, unit: l.unit ?? null, quoteId: id, position: i })));
      }
    });
    await audit(p, 'update', 'quote', id);
    return loadFull(id);
  });

  /** Génère le PDF, l'archive et l'envoie au client */
  app.post('/quotes/:id/send', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const quote = await loadQuote(p, id, 'quote.write');
    if (quote.status !== 'DRAFT' && quote.status !== 'SENT') throw conflict('Ce devis ne peut plus être envoyé');
    const body = z.object({ to: z.array(z.string().email()).optional() }).parse(req.body ?? {});
    const lines = await db.select({ id: schema.quoteLines.id }).from(schema.quoteLines).where(eq(schema.quoteLines.quoteId, id));
    if (!lines.length) throw badRequest('Ajoutez au moins une ligne avant d’envoyer le devis');
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, quote.clientId));
    const to = body.to?.length ? body.to : client.email ? [client.email] : [];
    if (!to.length) throw badRequest("Le client n'a pas d'adresse e-mail : indiquez-en une");

    const now = new Date();
    const sent = { ...quote, sentAt: now };
    const pdf = await buildPdf(sent);
    const dir = path.resolve(env.STORAGE_DIR, 'quotes', quote.companyId);
    await mkdir(dir, { recursive: true });
    const pdfPath = path.join(dir, `${quote.number}.pdf`);
    await writeFile(pdfPath, pdf);

    const company = (await getCompany(p.groupId, quote.companyId))!;
    await sendMail({
      to,
      brand: { name: company.name, logoPath: company.logoPath },
      ...docTexts(clientLocale(client, company)).quoteMail({ company: company.name, number: quote.number, title: quote.title }),
      attachments: [{ filename: `${quote.number}.pdf`, content: pdf, contentType: 'application/pdf' }],
    });
    await db.update(q).set({ status: 'SENT', sentAt: now, sentTo: to.join(', '), pdfPath, updatedAt: now }).where(eq(q.id, id));
    await audit(p, 'send', 'quote', id, { to });
    return loadFull(id);
  });

  app.post('/quotes/:id/status', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const quote = await loadQuote(p, id, 'quote.write');
    const { status } = z.object({ status: z.enum(QUOTE_STATUSES) }).parse(req.body);
    if (!TRANSITIONS[quote.status].includes(status)) {
      throw conflict(`Un devis « ${quote.status} » ne peut pas passer à « ${status} »`);
    }
    const decided = status === 'ACCEPTED' || status === 'REFUSED';
    await db.update(q).set({ status, decidedAt: decided ? new Date() : null, updatedAt: new Date() }).where(eq(q.id, id));
    await audit(p, 'status', 'quote', id, { from: quote.status, to: status });
    return loadFull(id);
  });

  app.get('/quotes/:id/pdf', async (req, reply) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const quote = await loadQuote(req.principal, id, 'quote.read');
    let pdf: Buffer | null = null;
    // Devis envoyé : on renvoie exactement le document reçu par le client
    if (quote.status !== 'DRAFT' && quote.pdfPath) pdf = await readFile(quote.pdfPath).catch(() => null);
    pdf ??= await buildPdf(quote);
    return reply.type('application/pdf').header('Content-Disposition', `inline; filename="${quote.number}.pdf"`).send(pdf);
  });

  /** Devis de travaux accepté → intervention à planifier */
  app.post('/quotes/:id/intervention', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const quote = await loadQuote(p, id, 'quote.write');
    if (quote.status !== 'ACCEPTED') throw conflict("Le devis doit d'abord être accepté");
    const body = z.object({
      kind: z.enum(INTERVENTION_KINDS).default('INSTALLATION'),
      agencyId: z.string().uuid().optional(),
      siteId: z.string().uuid().optional(),
    }).parse(req.body ?? {});
    const [existing] = await db.select({ id: schema.interventions.id }).from(schema.interventions).where(eq(schema.interventions.quoteId, id));
    if (existing) return existing;

    const agencyId = body.agencyId ?? quote.agencyId;
    const siteId = body.siteId ?? quote.siteId;
    if (!agencyId) throw badRequest('Choisissez l’agence qui réalisera les travaux');
    if (!siteId) throw badRequest('Choisissez le lieu d’intervention');
    if (!can(p, 'intervention.write', { companyId: quote.companyId, agencyId })) throw forbidden();
    const company = (await getCompany(p.groupId, quote.companyId))!;
    if (!(await getAgency(company.id, agencyId))) throw badRequest('Agence inconnue');
    const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, siteId));
    if (!site || site.clientId !== quote.clientId) throw badRequest("Ce site n'appartient pas au client");

    const created = await db.transaction(async (tx) => {
      const number = await nextInterventionNumber(tx, company);
      const [row] = await tx.insert(schema.interventions).values({
        groupId: p.groupId, companyId: company.id, agencyId, number, clientId: quote.clientId, siteId,
        kind: body.kind, status: 'TO_PLAN', priority: 'NORMAL', source: `Devis ${quote.number}`,
        reason: quote.title, quoteId: id, createdById: p.userId,
      }).returning({ id: schema.interventions.id, number: schema.interventions.number });
      return row;
    });
    await audit(p, 'create', 'intervention', created.id, { fromQuote: quote.number });
    return reply.code(201).send(created);
  });

  /** Devis de contrat accepté → contrat d'entretien (et ses premières visites) */
  app.post('/quotes/:id/contract', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const quote = await loadQuote(p, id, 'quote.write');
    if (quote.status !== 'ACCEPTED') throw conflict("Le devis doit d'abord être accepté");
    if (quote.kind !== 'CONTRACT') throw badRequest("Ce devis ne porte pas sur un contrat d'entretien");
    const [existing] = await db.select({ id: schema.contracts.id }).from(schema.contracts).where(eq(schema.contracts.quoteId, id));
    if (existing) return existing;
    const body = z.object({
      startDate: z.string().date(),
      agencyId: z.string().uuid().optional(),
      equipmentIds: z.array(z.string().uuid()).default([]),
    }).parse(req.body);
    const agencyId = body.agencyId ?? quote.agencyId;
    if (!agencyId) throw badRequest('Choisissez l’agence qui assurera les visites');
    if (!quote.siteId) throw badRequest('Le devis doit indiquer le lieu d’intervention');
    if (!can(p, 'contract.write', { companyId: quote.companyId, agencyId })) throw forbidden();
    const company = (await getCompany(p.groupId, quote.companyId))!;
    if (!(await getAgency(company.id, agencyId))) throw badRequest('Agence inconnue');
    await checkEquipments(quote.siteId, body.equipmentIds);

    const created = await db.transaction(async (tx) => {
      const number = await nextNumber(tx, company, 'contract');
      const [row] = await tx.insert(schema.contracts).values({
        groupId: p.groupId, companyId: company.id, agencyId, number, clientId: quote.clientId, siteId: quote.siteId!,
        equipmentIds: body.equipmentIds, title: quote.title, frequencyMonths: quote.contractFrequencyMonths ?? 12,
        startDate: body.startDate, annualPriceCents: quote.netCents, quoteId: id, createdById: p.userId,
      }).returning({ id: schema.contracts.id, number: schema.contracts.number });
      return row;
    });
    await audit(p, 'create', 'contract', created.id, { fromQuote: quote.number });
    await generateContractVisits({ contractId: created.id });
    return reply.code(201).send(created);
  });
}
