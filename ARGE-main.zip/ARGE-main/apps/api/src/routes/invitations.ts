/**
 * Invitation d'un collègue (technicien surtout), sans mot de passe provisoire à inventer ni à transmettre :
 *  1. le bureau crée le lien (POST /users/:id/invitation) et l'envoie par WhatsApp, e-mail ou QR code ;
 *  2. la personne l'ouvre, choisit son mot de passe (POST /invitations/:token/accept) ;
 *  3. sur son téléphone, « Ouvrir l'appli » passe un code de 15 minutes à l'appli, qui s'ouvre connectée
 *     (POST /invitations/app-login) : ni adresse de serveur ni mot de passe à retaper.
 * Lien à usage unique, valable 7 jours, un seul à la fois par personne ; seules les empreintes sont gardées.
 */
import type { FastifyInstance, FastifyReply } from 'fastify';
import { and, eq, gt, isNull } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { env } from '../env.js';
import { badRequest, forbidden, HttpError, notFound } from '../http.js';
import { canGrant } from '../auth/access.js';
import { loadPrincipal, signSession } from '../auth/plugin.js';
import { audit } from '../services/audit.js';
import { createResetToken, hashResetToken, newPassword } from '../services/password.js';
import { invitationByIp, tooManyMessage } from '../services/rate-limit.js';
import { buildMe } from './auth.js';

const inv = schema.invitations;
export const INVITATION_TTL_MS = 7 * 86400_000;
export const APP_CODE_TTL_MS = 15 * 60_000;

/** Adresse publique du logiciel : la première en https de WEB_ORIGIN (celle du nom de domaine) */
export function publicOrigin(): string {
  const all = env.WEB_ORIGIN.split(',').map((s) => s.trim().replace(/\/$/, '')).filter(Boolean);
  return all.find((o) => o.startsWith('https://')) ?? all[0];
}

function limit(reply: FastifyReply, ip: string) {
  const c = invitationByIp.check(ip);
  if (c.blocked) {
    reply.header('Retry-After', String(Math.ceil(c.retryAfterMs / 1000)));
    throw new HttpError(429, tooManyMessage(c.retryAfterMs));
  }
  invitationByIp.hit(ip);
}

const INVALID = 'Ce lien d’invitation est invalide ou a expiré. Demandez-en un nouveau au bureau.';

async function findValid(token: string) {
  const [row] = await db.select().from(inv).where(and(eq(inv.tokenHash, hashResetToken(token)), isNull(inv.usedAt), gt(inv.expiresAt, new Date())));
  if (!row) return null;
  const [user] = await db.select().from(schema.users).where(eq(schema.users.id, row.userId));
  return user?.active ? { row, user } : null;
}

export async function invitationRoutes(app: FastifyInstance) {
  /** Le bureau crée (ou recrée) le lien d'invitation d'un collègue */
  app.post('/users/:id/invitation', { preHandler: app.authenticate }, async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [user] = await db.select().from(schema.users).where(and(eq(schema.users.id, id), eq(schema.users.groupId, p.groupId)));
    if (!user || !user.active) throw notFound('Compte');
    // Mêmes droits que pour créer ce compte : sur chacun de ses rôles
    const roles = await db.select().from(schema.roleAssignments).where(eq(schema.roleAssignments.userId, id));
    if (!roles.length || !roles.every((a) => canGrant(p, a))) throw forbidden();

    const { token, tokenHash } = createResetToken();
    const expiresAt = new Date(Date.now() + INVITATION_TTL_MS);
    await db.transaction(async (tx) => {
      // Un seul lien valable à la fois
      await tx.delete(inv).where(eq(inv.userId, id));
      await tx.insert(inv).values({ userId: id, tokenHash, expiresAt, createdById: p.userId });
    });
    await audit(p, 'invite', 'user', id);
    // Le jeton est après « # » : il n'est jamais envoyé dans les journaux du serveur ni aux autres sites
    return { url: `${publicOrigin()}/invitation#${token}`, expiresAt, firstName: user.firstName, phone: user.phone, email: user.email };
  });

  /** Page d'invitation : à qui elle s'adresse */
  app.get('/invitations/:token', async (req, reply) => {
    limit(reply, req.ip);
    const { token } = z.object({ token: z.string().min(20).max(200) }).parse(req.params);
    const found = await findValid(token);
    if (!found) throw badRequest(INVALID);
    const [role] = await db.select({ companyId: schema.roleAssignments.companyId }).from(schema.roleAssignments).where(eq(schema.roleAssignments.userId, found.user.id)).limit(1);
    const [company] = role?.companyId ? await db.select({ name: schema.companies.name }).from(schema.companies).where(eq(schema.companies.id, role.companyId)) : [];
    return { firstName: found.user.firstName, lastName: found.user.lastName, email: found.user.email, companyName: company?.name ?? null };
  });

  /** Mot de passe choisi : le compte est activé, la personne est connectée, et l'appli reçoit un code court */
  app.post('/invitations/:token/accept', async (req, reply) => {
    limit(reply, req.ip);
    const { token } = z.object({ token: z.string().min(20).max(200) }).parse(req.params);
    const body = z.object({ password: newPassword }).parse(req.body);
    const found = await findValid(token);
    if (!found) throw badRequest(INVALID);
    const { token: appCode, tokenHash: appCodeHash } = createResetToken();
    const now = new Date();
    const used = await db.transaction(async (tx) => {
      const done = await tx.update(inv).set({ usedAt: now, appCodeHash, appCodeExpiresAt: new Date(now.getTime() + APP_CODE_TTL_MS) })
        .where(and(eq(inv.id, found.row.id), isNull(inv.usedAt))).returning({ id: inv.id });
      if (!done.length) return false;
      await tx.update(schema.users).set({ passwordHash: await bcrypt.hash(body.password, 10), passwordChangedAt: now })
        .where(eq(schema.users.id, found.user.id));
      return true;
    });
    if (!used) throw badRequest(INVALID);
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, found.user.id));
    const p = await loadPrincipal(user.id, user.groupId);
    await audit(p!, 'invitation.accept', 'user', user.id);
    return { token: signSession(app, user, true), me: await buildMe(p!), appCode, server: publicOrigin() };
  });

  /** L'appli s'ouvre connectée avec le code reçu juste après l'invitation (une seule fois, 15 minutes) */
  app.post('/invitations/app-login', async (req, reply) => {
    limit(reply, req.ip);
    const { code } = z.object({ code: z.string().min(20).max(200) }).parse(req.body);
    const hash = hashResetToken(code);
    const [row] = await db.select().from(inv).where(and(eq(inv.appCodeHash, hash), gt(inv.appCodeExpiresAt, new Date())));
    if (!row) throw badRequest('Ce code a expiré : connectez-vous avec votre e-mail et votre mot de passe.');
    const cleared = await db.update(inv).set({ appCodeHash: null, appCodeExpiresAt: null })
      .where(and(eq(inv.id, row.id), eq(inv.appCodeHash, hash))).returning({ id: inv.id });
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, row.userId));
    if (!cleared.length || !user?.active) throw badRequest('Ce code a expiré : connectez-vous avec votre e-mail et votre mot de passe.');
    const p = await loadPrincipal(user.id, user.groupId);
    await audit(p!, 'login.app-code', 'user', user.id);
    return { token: signSession(app, user, true), me: await buildMe(p!) };
  });
}
