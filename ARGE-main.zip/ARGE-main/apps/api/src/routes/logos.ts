/**
 * Image du logo d'une société, sans connexion : c'est l'image publique de l'entreprise (page de connexion de
 * l'espace client, en-têtes). L'adresse porte la date de mise à jour (?v=…) : le navigateur la garde en cache.
 */
import type { FastifyInstance } from 'fastify';
import { readFile } from 'node:fs/promises';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { notFound } from '../http.js';
import { logoMime } from '../services/logo.js';

export async function logoRoutes(app: FastifyInstance) {
  app.get('/logos/:companyId', async (req, reply) => {
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const [c] = await db.select({ logoPath: schema.companies.logoPath }).from(schema.companies).where(eq(schema.companies.id, companyId));
    if (!c?.logoPath) throw notFound('Logo');
    let image: Buffer;
    try {
      image = await readFile(c.logoPath);
    } catch {
      throw notFound('Logo');
    }
    return reply.type(logoMime(c.logoPath)).header('Cache-Control', 'public, max-age=31536000, immutable').send(image);
  });
}
