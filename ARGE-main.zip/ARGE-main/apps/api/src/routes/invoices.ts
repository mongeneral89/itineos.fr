/**
 * Factures et avoirs.
 *
 * Brouillon (modifiable, sans numéro) → Émise (numéro définitif, PDF archivé, plus jamais modifiée).
 * Une facture émise se corrige par un avoir. Les paiements se notent sur la facture émise.
 */
import { clientLocale, docTexts, formatLocale, longDay } from '../services/doc-i18n.js';
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, gte, ilike, inArray, isNotNull, isNull, lte, or, sql } from 'drizzle-orm';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import {
  addDays, addMonths, documentTotals, PAYMENT_METHODS, paymentState, vatRatesFor, type PaymentState,
} from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { companyLogo } from '../services/logo.js';
import { env } from '../env.js';
import { can, roleHas, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { nextNumber } from '../services/numbering.js';
import { oneLineAddress } from '../services/prefill.js';
import { generateInvoicePdf } from '../services/document-pdf.js';
import { sendMail } from '../services/mail.js';
import { todayIn } from '../services/contracts.js';
import { invoiceListCsv, salesJournalCsv, type ExportDocument } from '../services/accounting.js';
import { loadIntervention } from './interventions.js';
import { facturxWarnings, facturxXml, OPERATION_TYPES, type FacturxInput } from '../services/facturx.js';
import { depositInvoice, FINAL_STATUSES, flowStatus, statusLabel, type PlatformConfig } from '../services/einvoice.js';
import { createZip } from '../services/zip.js';
import { duePeriods, type DuePeriod } from '../services/subscriptions.js';

const inv = schema.invoices;

const lineBody = z.object({
  description: z.string().trim().min(1, 'Chaque ligne doit avoir une désignation').max(2000),
  quantity: z.number().positive('La quantité doit être positive').max(1_000_000),
  unit: z.string().trim().max(20).nullable().optional(),
  unitPriceCents: z.number().int().min(-100_000_000).max(1_000_000_000),
  vatRateBp: z.number().int().min(0).max(10_000),
});
type Line = z.infer<typeof lineBody>;

const draftBody = z.object({
  agencyId: z.string().uuid().nullable().optional(),
  clientId: z.string().uuid(),
  siteId: z.string().uuid().nullable().optional(),
  title: z.string().trim().min(1, "L'objet de la facture est obligatoire").max(300),
  notes: z.string().max(5000).nullable().optional(),
  serviceDate: z.string().date().nullable().optional(),
  paymentTermsDays: z.number().int().min(0).max(120).optional(),
  /** Nature de l'opération : services, biens ou les deux (mention obligatoire) */
  operationType: z.enum(OPERATION_TYPES as [string, ...string[]]).optional(),
  lines: z.array(lineBody).max(300).default([]),
});

async function loadInvoice(p: Principal, id: string, perm: 'invoice.read' | 'invoice.write') {
  const [row] = await db.select().from(inv).where(and(eq(inv.id, id), eq(inv.groupId, p.groupId)));
  if (!row) throw notFound('Facture');
  if (!can(p, perm, { companyId: row.companyId, agencyId: row.agencyId }, { sharedVisible: perm === 'invoice.read' })) throw forbidden();
  return row;
}

async function checkTargets(p: Principal, b: { clientId: string; siteId?: string | null; agencyId?: string | null }) {
  const [client] = await db.select().from(schema.clients)
    .where(and(eq(schema.clients.id, b.clientId), eq(schema.clients.groupId, p.groupId)));
  if (!client) throw badRequest('Client inconnu');
  const company = (await getCompany(p.groupId, client.companyId))!;
  const agencyId = b.agencyId ?? client.agencyId ?? null;
  if (agencyId && !(await getAgency(company.id, agencyId))) throw badRequest('Agence inconnue');
  if (b.siteId) {
    const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, b.siteId));
    if (!site || site.clientId !== client.id) throw badRequest("Ce site n'appartient pas au client");
  }
  if (!can(p, 'invoice.write', { companyId: company.id, agencyId })) throw forbidden();
  return { client, company, agencyId };
}

const totalsOf = (lines: Line[]) => {
  const t = documentTotals(lines);
  return { netCents: t.netCents, vatCents: t.vatCents, grossCents: t.grossCents };
};

/** Montants déjà réglés : paiements + avoirs émis sur chaque facture */
export async function settlements(ids: string[]) {
  const paid = new Map<string, number>();
  const credited = new Map<string, number>();
  if (!ids.length) return { paid, credited };
  const pays = await db.select({ id: schema.payments.invoiceId, total: sql<string>`sum(${schema.payments.amountCents})` })
    .from(schema.payments).where(inArray(schema.payments.invoiceId, ids)).groupBy(schema.payments.invoiceId);
  for (const r of pays) paid.set(r.id, Number(r.total));
  const credits = await db.select({ id: inv.creditedInvoiceId, total: sql<string>`sum(${inv.grossCents})` })
    .from(inv).where(and(inArray(inv.creditedInvoiceId, ids), eq(inv.status, 'ISSUED'))).groupBy(inv.creditedInvoiceId);
  for (const r of credits) if (r.id) credited.set(r.id, Number(r.total));
  return { paid, credited };
}

type DraftInput = z.infer<typeof draftBody> & {
  kind?: 'INVOICE' | 'CREDIT_NOTE'; sourceInterventionId?: string | null; sourceQuoteId?: string | null;
  contractId?: string | null; creditedInvoiceId?: string | null;
};
type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

/** Écrit un brouillon dans une transaction déjà ouverte (cibles déjà vérifiées) */
async function insertDraft(tx: Tx, p: Principal, company: Company, agencyId: string | null, b: DraftInput) {
  const [row] = await tx.insert(inv).values({
    groupId: p.groupId, companyId: company.id, agencyId, kind: b.kind ?? 'INVOICE', status: 'DRAFT',
    clientId: b.clientId, siteId: b.siteId ?? null, title: b.title, notes: b.notes ?? null,
    serviceDate: b.serviceDate ?? null, paymentTermsDays: b.paymentTermsDays ?? company.paymentTermsDays,
    operationType: (b.operationType ?? 'SERVICES') as 'SERVICES' | 'GOODS' | 'MIXED',
    currency: company.currency, sourceInterventionId: b.sourceInterventionId ?? null, sourceQuoteId: b.sourceQuoteId ?? null,
    contractId: b.contractId ?? null, creditedInvoiceId: b.creditedInvoiceId ?? null, createdById: p.userId,
    ...totalsOf(b.lines),
  }).returning();
  if (b.lines.length) {
    await tx.insert(schema.invoiceLines).values(b.lines.map((l, i) => ({ ...l, unit: l.unit ?? null, invoiceId: row.id, position: i })));
  }
  return row;
}

/** Crée un brouillon (utilisé par toutes les façons de créer une facture) */
async function createDraft(p: Principal, b: DraftInput) {
  const { company, agencyId } = await checkTargets(p, b);
  return db.transaction((tx) => insertDraft(tx, p, company, agencyId, b));
}

async function loadFull(id: string) {
  const [row] = await db.select().from(inv).where(eq(inv.id, id));
  const lines = await db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, id)).orderBy(asc(schema.invoiceLines.position));
  const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, row.clientId));
  const [site] = row.siteId ? await db.select().from(schema.sites).where(eq(schema.sites.id, row.siteId)) : [null];
  const payments = await db.select().from(schema.payments).where(eq(schema.payments.invoiceId, id)).orderBy(asc(schema.payments.paidOn));
  const creditNotes = await db.select({ id: inv.id, number: inv.number, status: inv.status, grossCents: inv.grossCents })
    .from(inv).where(eq(inv.creditedInvoiceId, id));
  const [credited] = row.creditedInvoiceId
    ? await db.select({ id: inv.id, number: inv.number }).from(inv).where(eq(inv.id, row.creditedInvoiceId))
    : [null];
  const company = (await getCompany(row.groupId, row.companyId))!;
  const { paid, credited: creditedMap } = await settlements([id]);
  const paidCents = paid.get(id) ?? 0;
  const creditedCents = creditedMap.get(id) ?? 0;
  const fx = facturxInput({ ...row, lines, client, site: site ?? null, creditedInvoice: credited ?? null, paidCents, creditedCents }, company);
  return {
    ...row, lines, client, site: site ?? null, payments, creditNotes, creditedInvoice: credited ?? null,
    paidCents, creditedCents,
    // Facture électronique : ce qui manque, la plateforme est-elle réglée, où en est le dépôt
    einvoiceWarnings: facturxWarnings({ seller: fx.seller, buyer: fx.buyer, buyerIsCompany: client.type === 'COMPANY' }),
    einvoiceReady: !!platformOf(company),
    // Particulier : facture en PDF par e-mail, jamais déposée sur la plateforme (ventes déclarées par l'e-reporting)
    einvoiceB2B: client.type === 'COMPANY',
    einvoiceStatusLabel: statusLabel(row.einvoiceStatus),
    remainingCents: row.kind === 'INVOICE' && row.status === 'ISSUED' ? Math.max(0, row.grossCents - paidCents - creditedCents) : 0,
    state: paymentState({ ...row, paidCents: paidCents + creditedCents }, todayIn(company.timezone)),
  };
}

type Company = NonNullable<Awaited<ReturnType<typeof getCompany>>>;

/** Plateforme agréée réglée pour la société (adresse de l'API et jeton), sinon null */
export function platformOf(company: Pick<Company, 'einvoiceApiUrl' | 'einvoiceApiToken'>): PlatformConfig | null {
  return company.einvoiceApiUrl && company.einvoiceApiToken ? { url: company.einvoiceApiUrl, token: company.einvoiceApiToken } : null;
}

/** Les données de la facture électronique (Factur-X) */
function facturxInput(full: {
  kind: 'INVOICE' | 'CREDIT_NOTE'; number: string | null; issueDate: string | null; serviceDate: string | null; dueDate: string | null;
  currency: string; title: string; operationType: string; lines: FacturxInput['lines'];
  client: typeof schema.clients.$inferSelect; site: typeof schema.sites.$inferSelect | null;
  creditedInvoice: { number: string | null } | null; paidCents: number; creditedCents: number;
}, company: Company): FacturxInput {
  const c = full.client;
  const s = full.site;
  // Lieu d'intervention : seulement s'il diffère de l'adresse de facturation
  const where = (x: { address: string | null; postalCode: string | null; city: string | null }) => `${x.address ?? ''}|${x.postalCode ?? ''}|${x.city ?? ''}`;
  const elsewhere = s && where(s) !== where(c);
  return {
    kind: full.kind, number: full.number ?? 'BROUILLON', issueDate: full.issueDate ?? todayIn(company.timezone),
    serviceDate: full.serviceDate, dueDate: full.dueDate, currency: full.currency, title: full.title,
    operationType: full.operationType as FacturxInput['operationType'], vatOnDebits: company.vatOnDebits,
    seller: {
      name: company.legalName || company.name, siren: company.siren, vatNumber: company.vatNumber, address: company.address,
      postalCode: company.postalCode, city: company.city, countryCode: company.countryCode, email: company.email, bankDetails: company.bankDetails,
    },
    buyer: {
      name: c.name, siren: c.siren, vatNumber: c.vatNumber, address: c.address, postalCode: c.postalCode, city: c.city,
      countryCode: c.countryCode ?? company.countryCode, email: c.email,
    },
    delivery: elsewhere && s ? { name: s.name, address: s.address, postalCode: s.postalCode, city: s.city, countryCode: s.countryCode } : null,
    creditedNumber: full.creditedInvoice?.number ?? null,
    paidCents: full.kind === 'INVOICE' ? full.paidCents + full.creditedCents : 0,
    lines: full.lines,
  };
}

/** Facture émise : PDF/A-3 avec son XML Factur-X (le brouillon reste un PDF simple) */
export async function buildPdf(id: string) {
  const full = await loadFull(id);
  const company = (await getCompany(full.groupId, full.companyId))!;
  const agency = full.agencyId ? await getAgency(company.id, full.agencyId) : null;
  return generateInvoicePdf({
    locale: clientLocale(full.client, company),
    currency: full.currency,
    company: { ...company, logo: await companyLogo(company) },
    agencyName: agency?.name ?? null,
    invoice: {
      kind: full.kind,
      number: full.number ?? docTexts(clientLocale(full.client, company)).draft,
      title: full.title, notes: full.notes,
      issueDate: full.issueDate ?? todayIn(company.timezone),
      serviceDate: full.serviceDate, dueDate: full.dueDate,
      creditedNumber: full.creditedInvoice?.number ?? null,
      paidCents: full.paidCents + full.creditedCents,
    },
    client: {
      name: full.client.name,
      address: oneLineAddress(full.client.address, full.client.postalCode, full.client.city),
      email: full.client.email,
    },
    site: full.site ? { name: full.site.name, address: oneLineAddress(full.site.address, full.site.postalCode, full.site.city) } : null,
    lines: full.lines,
    facturxXml: full.status === 'ISSUED' && full.number ? facturxXml(facturxInput(full, company)) : null,
  });
}

/** PDF Factur-X d'une facture émise : celui archivé s'il l'est déjà, sinon refait (factures d'avant la réforme) */
async function facturxPdf(id: string, pdfPath: string | null): Promise<Buffer> {
  const archived = pdfPath ? await readFile(pdfPath).catch(() => null) : null;
  return archived && archived.includes('factur-x.xml') ? archived : buildPdf(id);
}

/**
 * Dépose la facture émise sur la plateforme agréée de la société et note le résultat.
 * Une erreur est gardée sur la facture (affichée) et renvoyée.
 */
async function sendToPlatform(id: string): Promise<void> {
  const full = await loadFull(id);
  const company = (await getCompany(full.groupId, full.companyId))!;
  const cfg = platformOf(company);
  if (!cfg) throw badRequest('Aucune plateforme de facture électronique n’est réglée (Organisation → Facture électronique)');
  const pdf = await facturxPdf(id, full.pdfPath);
  try {
    const r = await depositInvoice(cfg, pdf, { invoiceId: id, number: full.number! });
    await db.update(inv).set({ einvoiceFlowId: r.flowId, einvoiceStatus: r.status, einvoiceStatusAt: new Date(), einvoiceError: null }).where(eq(inv.id, id));
  } catch (e) {
    await db.update(inv).set({ einvoiceError: (e as Error).message, einvoiceStatusAt: new Date() }).where(eq(inv.id, id));
    throw badRequest((e as Error).message);
  }
}

/** Peut facturer dans cette société (toute la société ou une de ses agences) */
export function billsIn(p: Principal, companyId: string): boolean {
  return p.assignments.some((a) => roleHas(a.role, 'invoice.write') && (!a.companyId || a.companyId === companyId));
}

/** Facture déjà créée depuis cette intervention / ce devis : on la renvoie plutôt que d'en créer une seconde */
async function existingFor(where: ReturnType<typeof eq>) {
  const [row] = await db.select({ id: inv.id }).from(inv).where(and(where, eq(inv.kind, 'INVOICE')));
  return row ?? null;
}

export async function invoiceRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/invoices', async (req) => {
    const p = req.principal;
    const f = z.object({
      companyId: z.string().uuid().optional(),
      agencyId: z.string().uuid().optional(),
      clientId: z.string().uuid().optional(),
      state: z.enum(['DRAFT', 'UNPAID', 'PARTIAL', 'PAID', 'OVERDUE', 'OPEN']).optional(),
      from: z.string().date().optional(),
      to: z.string().date().optional(),
      q: z.string().optional(),
      limit: z.coerce.number().int().min(1).max(1000).default(300),
    }).parse(req.query);
    const term = f.q?.trim();
    const rows = await db
      .select({
        id: inv.id, kind: inv.kind, status: inv.status, number: inv.number, companyId: inv.companyId, agencyId: inv.agencyId,
        clientId: inv.clientId, title: inv.title, issueDate: inv.issueDate, dueDate: inv.dueDate, currency: inv.currency,
        netCents: inv.netCents, grossCents: inv.grossCents, sentAt: inv.sentAt, createdAt: inv.createdAt,
        clientName: schema.clients.name, timezone: schema.companies.timezone,
      })
      .from(inv)
      .innerJoin(schema.clients, eq(schema.clients.id, inv.clientId))
      .innerJoin(schema.companies, eq(schema.companies.id, inv.companyId))
      .where(and(
        eq(inv.groupId, p.groupId),
        scopeWhere(scopeFor(p, 'invoice.read'), { companyId: inv.companyId, agencyId: inv.agencyId }, { sharedVisible: true }),
        f.companyId ? eq(inv.companyId, f.companyId) : undefined,
        f.agencyId ? or(eq(inv.agencyId, f.agencyId), isNull(inv.agencyId)) : undefined,
        f.clientId ? eq(inv.clientId, f.clientId) : undefined,
        f.from ? gte(inv.issueDate, f.from) : undefined,
        f.to ? lte(inv.issueDate, f.to) : undefined,
        term ? or(ilike(inv.title, `%${term}%`), ilike(inv.number, `%${term}%`), ilike(schema.clients.name, `%${term}%`)) : undefined,
      ))
      .orderBy(sql`${inv.issueDate} desc nulls first`, desc(inv.createdAt))
      .limit(f.limit);
    const { paid, credited } = await settlements(rows.map((r) => r.id));
    const out = rows.map(({ timezone, ...r }) => {
      const settled = (paid.get(r.id) ?? 0) + (credited.get(r.id) ?? 0);
      const state = paymentState({ ...r, paidCents: settled }, todayIn(timezone));
      return { ...r, settledCents: settled, remainingCents: r.kind === 'INVOICE' && r.status === 'ISSUED' ? Math.max(0, r.grossCents - settled) : 0, state };
    });
    const open: PaymentState[] = ['UNPAID', 'PARTIAL', 'OVERDUE'];
    return f.state ? out.filter((r) => (f.state === 'OPEN' ? open.includes(r.state) : r.state === f.state)) : out;
  });

  /** Export comptable de la période (factures et avoirs émis) */
  app.get('/invoices/export', async (req, reply) => {
    const p = req.principal;
    const f = z.object({
      companyId: z.string().uuid(),
      from: z.string().date(),
      to: z.string().date(),
      format: z.enum(['journal', 'list']).default('journal'),
    }).parse(req.query);
    if (!can(p, 'invoice.read', { companyId: f.companyId, agencyId: null })) throw forbidden('Export réservé à qui voit toute la société');
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    const rows = await db
      .select({ id: inv.id, kind: inv.kind, number: inv.number, issueDate: inv.issueDate, dueDate: inv.dueDate, title: inv.title,
        clientName: schema.clients.name, externalRef: schema.clients.externalRef })
      .from(inv).innerJoin(schema.clients, eq(schema.clients.id, inv.clientId))
      .where(and(eq(inv.companyId, f.companyId), eq(inv.status, 'ISSUED'), gte(inv.issueDate, f.from), lte(inv.issueDate, f.to)))
      .orderBy(asc(inv.issueDate), asc(inv.number));
    const ids = rows.map((r) => r.id);
    const lines = ids.length ? await db.select().from(schema.invoiceLines).where(inArray(schema.invoiceLines.invoiceId, ids)) : [];
    const { paid, credited } = await settlements(ids);
    const docs: ExportDocument[] = rows.map((r) => ({
      kind: r.kind, number: r.number!, issueDate: r.issueDate!, dueDate: r.dueDate, clientName: r.clientName,
      clientAccount: r.externalRef ?? r.clientName, title: r.title,
      lines: lines.filter((l) => l.invoiceId === r.id),
      settledCents: (paid.get(r.id) ?? 0) + (credited.get(r.id) ?? 0),
    }));
    const csv = f.format === 'journal' ? salesJournalCsv(docs) : invoiceListCsv(docs);
    const name = `${f.format === 'journal' ? 'journal-ventes' : 'factures'}-${company.documentPrefix}-${f.from}-${f.to}.csv`;
    await audit(p, 'export', 'invoices', null, { companyId: f.companyId, from: f.from, to: f.to, format: f.format, count: docs.length });
    return reply.type('text/csv; charset=utf-8').header('Content-Disposition', `attachment; filename="${name}"`).send(csv);
  });

  /** Factures électroniques d'une période (PDF Factur-X), dans un .zip : pour le comptable ou un dépôt à la main */
  app.get('/invoices/export/facturx', async (req, reply) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), from: z.string().date(), to: z.string().date() }).parse(req.query);
    if (!can(p, 'invoice.read', { companyId: f.companyId, agencyId: null })) throw forbidden('Export réservé à qui voit toute la société');
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    const rows = await db.select({ id: inv.id, number: inv.number, pdfPath: inv.pdfPath }).from(inv)
      .where(and(eq(inv.companyId, f.companyId), eq(inv.status, 'ISSUED'), gte(inv.issueDate, f.from), lte(inv.issueDate, f.to)))
      .orderBy(asc(inv.issueDate), asc(inv.number));
    if (rows.length > 2000) throw badRequest('Trop de factures pour un seul export : choisissez une période plus courte');
    const files: { name: string; data: Buffer }[] = [];
    for (const r of rows) files.push({ name: `${r.number}.pdf`, data: await facturxPdf(r.id, r.pdfPath) });
    await audit(p, 'export', 'invoices.facturx', null, { companyId: f.companyId, from: f.from, to: f.to, count: files.length });
    return reply.type('application/zip')
      .header('Content-Disposition', `attachment; filename="factur-x-${company.documentPrefix}-${f.from}-${f.to}.zip"`)
      .send(createZip(files));
  });

  app.get('/invoices/:id', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadInvoice(req.principal, id, 'invoice.read');
    return loadFull(id);
  });

  app.post('/invoices', async (req, reply) => {
    const p = req.principal;
    const body = draftBody.parse(req.body);
    const row = await createDraft(p, body);
    await audit(p, 'create', 'invoice', row.id);
    return reply.code(201).send(await loadFull(row.id));
  });

  /** Facture à partir d'une fiche signée : main-d'œuvre, déplacement et pièces repris */
  app.post('/invoices/from-intervention/:interventionId', async (req, reply) => {
    const p = req.principal;
    const { interventionId } = z.object({ interventionId: z.string().uuid() }).parse(req.params);
    const iv = await loadIntervention(p, interventionId);
    const existing = await existingFor(eq(inv.sourceInterventionId, iv.id));
    if (existing) return existing;
    const [report] = await db.select().from(schema.reports).where(eq(schema.reports.interventionId, iv.id));
    if (!report || report.status === 'DRAFT') throw conflict("La fiche d'intervention doit d'abord être signée");
    const parts = await db.select().from(schema.reportParts).where(eq(schema.reportParts.reportId, report.id));
    const company = (await getCompany(p.groupId, iv.companyId))!;
    const vat = vatRatesFor(company.countryCode)[0];
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, iv.clientId));
    const t = docTexts(clientLocale(client, company));
    const lines: Line[] = [];
    if (report.laborMinutes) {
      lines.push({ description: t.laborLine, quantity: Math.round((report.laborMinutes / 60) * 100) / 100, unit: 'h', unitPriceCents: company.hourlyRateCents ?? 0, vatRateBp: vat });
    }
    if (report.travelMinutes || company.travelFeeCents) {
      lines.push({ description: t.travelLine, quantity: 1, unit: t.flat, unitPriceCents: company.travelFeeCents ?? 0, vatRateBp: vat });
    }
    // Pièces du catalogue : prix de vente, unité et TVA de l'article ; pièces libres : prix à compléter
    const articleIds = parts.map((pt) => pt.articleId).filter((x): x is string => !!x);
    const catalog = new Map((articleIds.length
      ? await db.select().from(schema.articles).where(and(inArray(schema.articles.id, articleIds), eq(schema.articles.companyId, iv.companyId)))
      : []).map((a) => [a.id, a]));
    for (const part of parts) {
      const art = part.articleId ? catalog.get(part.articleId) : undefined;
      lines.push({
        description: [part.label, part.reference].filter(Boolean).join(' – '),
        quantity: part.quantity,
        unit: art?.unit ?? 'u',
        unitPriceCents: art?.salePriceCents ?? 0,
        vatRateBp: art?.vatRateBp ?? vat,
      });
    }
    const row = await createDraft(p, {
      clientId: iv.clientId, siteId: iv.siteId, agencyId: iv.agencyId,
      title: t.jobTitle(iv.number, iv.reason),
      serviceDate: report.signedAt ? todayIn(company.timezone, report.signedAt) : null,
      lines, sourceInterventionId: iv.id,
    });
    await audit(p, 'create', 'invoice', row.id, { fromIntervention: iv.number });
    return reply.code(201).send({ id: row.id });
  });

  /** Facture d'un devis accepté : mêmes lignes */
  app.post('/invoices/from-quote/:quoteId', async (req, reply) => {
    const p = req.principal;
    const { quoteId } = z.object({ quoteId: z.string().uuid() }).parse(req.params);
    const [quote] = await db.select().from(schema.quotes).where(and(eq(schema.quotes.id, quoteId), eq(schema.quotes.groupId, p.groupId)));
    if (!quote) throw notFound('Devis');
    if (!can(p, 'quote.read', { companyId: quote.companyId, agencyId: quote.agencyId }, { sharedVisible: true })) throw forbidden();
    if (quote.status !== 'ACCEPTED') throw conflict("Le devis doit d'abord être accepté");
    const existing = await existingFor(eq(inv.sourceQuoteId, quote.id));
    if (existing) return existing;
    const lines = await db.select().from(schema.quoteLines).where(eq(schema.quoteLines.quoteId, quote.id)).orderBy(asc(schema.quoteLines.position));
    const row = await createDraft(p, {
      clientId: quote.clientId, siteId: quote.siteId, agencyId: quote.agencyId, title: quote.title,
      lines: lines.map(({ description, quantity, unit, unitPriceCents, vatRateBp }) => ({ description, quantity, unit, unitPriceCents, vatRateBp })),
      sourceQuoteId: quote.id,
    });
    await audit(p, 'create', 'invoice', row.id, { fromQuote: quote.number });
    return reply.code(201).send({ id: row.id });
  });

  /** Facture d'une période de contrat d'entretien (prix annuel, au prorata de la période) */
  app.post('/invoices/from-contract/:contractId', async (req, reply) => {
    const p = req.principal;
    const { contractId } = z.object({ contractId: z.string().uuid() }).parse(req.params);
    const body = z.object({ periodStart: z.string().date(), months: z.number().int().min(1).max(12).default(12) }).parse(req.body);
    const [contract] = await db.select().from(schema.contracts).where(and(eq(schema.contracts.id, contractId), eq(schema.contracts.groupId, p.groupId)));
    if (!contract) throw notFound('Contrat');
    if (!can(p, 'contract.read', { companyId: contract.companyId, agencyId: contract.agencyId })) throw forbidden();
    if (contract.annualPriceCents == null) throw badRequest("Indiquez d'abord le prix annuel du contrat");
    const company = (await getCompany(p.groupId, contract.companyId))!;
    const periodEnd = addDays(addMonths(body.periodStart, body.months), -1);
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, contract.clientId));
    const docLocale = clientLocale(client, company);
    const t = docTexts(docLocale);
    const fmt = (d: string) => new Intl.DateTimeFormat(formatLocale(docLocale), { timeZone: 'UTC', dateStyle: 'short' }).format(new Date(`${d}T00:00:00Z`));
    const row = await createDraft(p, {
      clientId: contract.clientId, siteId: contract.siteId, agencyId: contract.agencyId,
      title: t.contractTitle(contract.number, contract.title),
      lines: [{
        description: t.period(fmt(body.periodStart), fmt(periodEnd)),
        quantity: 1, unit: null, unitPriceCents: Math.round((contract.annualPriceCents * body.months) / 12),
        vatRateBp: vatRatesFor(company.countryCode)[0],
      }],
      serviceDate: body.periodStart, contractId: contract.id,
    });
    await audit(p, 'create', 'invoice', row.id, { fromContract: contract.number });
    return reply.code(201).send({ id: row.id });
  });

  app.put('/invoices/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(p, id, 'invoice.write');
    if (current.status !== 'DRAFT') throw conflict('Une facture émise ne peut plus être modifiée : faites un avoir');
    const body = draftBody.parse(req.body);
    if (body.clientId !== current.clientId) throw badRequest('Le client ne peut pas changer : créez une nouvelle facture');
    const { agencyId } = await checkTargets(p, body);
    await db.transaction(async (tx) => {
      await tx.update(inv).set({
        agencyId, siteId: body.siteId ?? null, title: body.title, notes: body.notes ?? null,
        serviceDate: body.serviceDate ?? null, paymentTermsDays: body.paymentTermsDays ?? current.paymentTermsDays,
        operationType: (body.operationType ?? current.operationType) as 'SERVICES' | 'GOODS' | 'MIXED',
        updatedAt: new Date(), ...totalsOf(body.lines),
      }).where(eq(inv.id, id));
      await tx.delete(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, id));
      if (body.lines.length) {
        await tx.insert(schema.invoiceLines).values(body.lines.map((l, i) => ({ ...l, unit: l.unit ?? null, invoiceId: id, position: i })));
      }
    });
    await audit(p, 'update', 'invoice', id);
    return loadFull(id);
  });

  app.delete('/invoices/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(p, id, 'invoice.write');
    if (current.status !== 'DRAFT') throw conflict('Une facture émise ne peut pas être supprimée : faites un avoir');
    await db.delete(inv).where(eq(inv.id, id));
    await audit(p, 'delete', 'invoice', id);
    return reply.code(204).send();
  });

  // ─── Facturation des abonnements en lot ─────────────────────────────────

  /**
   * Ce qui est dû jusqu'au jour `until` : les contrats facturés en lot (billingMonths), regroupés par client
   * et par agence (une facture par client, une ligne par contrat et par période).
   */
  async function subscriptionPlan(p: Principal, companyId: string, until: string) {
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    const k = schema.contracts;
    const contracts = (await db.select().from(k).where(and(
      eq(k.companyId, companyId), eq(k.status, 'ACTIVE'), isNotNull(k.billingMonths),
    )).orderBy(asc(k.number))).filter((c) => can(p, 'invoice.write', { companyId, agencyId: c.agencyId }));
    const clientIds = [...new Set(contracts.map((c) => c.clientId))];
    const clients = clientIds.length ? await db.select().from(schema.clients).where(inArray(schema.clients.id, clientIds)) : [];
    const mandates = clientIds.length
      ? await db.select({ clientId: schema.sepaMandates.clientId }).from(schema.sepaMandates)
        .where(and(inArray(schema.sepaMandates.clientId, clientIds), eq(schema.sepaMandates.status, 'ACTIVE')))
      : [];
    const withMandate = new Set(mandates.map((m) => m.clientId));
    const groups = new Map<string, { client: (typeof clients)[number]; agencyId: string; items: { contract: (typeof contracts)[number]; periods: DuePeriod[] }[] }>();
    const missingPrice: string[] = [];
    for (const contract of contracts) {
      if (contract.annualPriceCents == null) {
        missingPrice.push(contract.number);
        continue;
      }
      const periods = duePeriods(contract, until);
      if (!periods.length) continue;
      const key = `${contract.clientId}|${contract.agencyId}`;
      const group = groups.get(key) ?? { client: clients.find((c) => c.id === contract.clientId)!, agencyId: contract.agencyId, items: [] };
      group.items.push({ contract, periods });
      groups.set(key, group);
    }
    return { company, groups: [...groups.values()], withMandate, missingPrice };
  }

  const billingQuery = z.object({ companyId: z.string().uuid(), until: z.string().date() });

  /** Aperçu : abonnements à facturer, par client. Rien n'est créé. */
  app.get('/billing/subscriptions', async (req) => {
    const p = req.principal;
    const q = billingQuery.parse(req.query);
    if (!billsIn(p, q.companyId)) throw forbidden();
    const { groups, withMandate, missingPrice } = await subscriptionPlan(p, q.companyId, q.until);
    const clients = groups.map((g) => ({
      clientId: g.client.id, clientName: g.client.name, agencyId: g.agencyId, directDebit: withMandate.has(g.client.id),
      totalCents: g.items.reduce((s, it) => s + it.periods.reduce((t, x) => t + x.amountCents, 0), 0),
      lines: g.items.flatMap((it) => it.periods.map((x) => ({
        contractId: it.contract.id, number: it.contract.number, title: it.contract.title, start: x.start, end: x.end, amountCents: x.amountCents,
      }))),
    }));
    return { clients, totalCents: clients.reduce((s, c) => s + c.totalCents, 0), missingPrice };
  });

  /** Crée les factures (en brouillon, ou émises directement) et note la période facturée sur chaque contrat */
  app.post('/billing/subscriptions', async (req) => {
    const p = req.principal;
    const body = billingQuery.extend({ issue: z.boolean().default(false) }).parse(req.body);
    if (!billsIn(p, body.companyId)) throw forbidden();
    const { company, groups } = await subscriptionPlan(p, body.companyId, body.until);
    const vat = vatRatesFor(company.countryCode)[0];
    const created: string[] = [];
    let skipped = 0;
    for (const g of groups) {
      const docLocale = clientLocale(g.client, company);
      const t = docTexts(docLocale);
      const fmt = (d: string) => new Intl.DateTimeFormat(formatLocale(docLocale), { timeZone: 'UTC', dateStyle: 'short' }).format(new Date(`${d}T00:00:00Z`));
      const single = g.items.length === 1 ? g.items[0].contract : null;
      // Contrat sans visite : un abonnement (télésurveillance…), pas un contrat d'entretien
      const title = (c: (typeof g.items)[number]['contract']) => (c.frequencyMonths === 0 ? t.subscriptionTitle : t.contractTitle)(c.number, c.title);
      const lines: Line[] = g.items.flatMap((it) => it.periods.map((x) => ({
        description: single ? t.period(fmt(x.start), fmt(x.end)) : `${title(it.contract)} – ${t.period(fmt(x.start), fmt(x.end))}`,
        quantity: 1, unit: null, unitPriceCents: x.amountCents, vatRateBp: vat,
      })));
      try {
        const row = await db.transaction(async (tx) => {
          // La période est réservée sur le contrat en même temps que la facture est créée :
          // deux lancements simultanés ne peuvent pas facturer deux fois la même période
          for (const it of g.items) {
            const last = it.periods[it.periods.length - 1].end;
            const [done] = await tx.update(schema.contracts).set({ billedUntil: last, updatedAt: new Date() })
              .where(and(eq(schema.contracts.id, it.contract.id), it.contract.billedUntil
                ? eq(schema.contracts.billedUntil, it.contract.billedUntil) : isNull(schema.contracts.billedUntil)))
              .returning({ id: schema.contracts.id });
            if (!done) throw conflict('Contrat facturé entre-temps');
          }
          return insertDraft(tx, p, company, g.agencyId, {
            clientId: g.client.id, siteId: single?.siteId ?? null, agencyId: g.agencyId,
            title: single ? title(single) : t.contracts(g.items.length),
            lines, serviceDate: g.items.flatMap((it) => it.periods.map((x) => x.start)).sort()[0],
            contractId: single?.id ?? null,
          });
        });
        created.push(row.id);
      } catch {
        skipped++;
      }
    }
    let issued = 0;
    const errors: string[] = [];
    if (body.issue) {
      for (const id of created) {
        try {
          await issueInvoice(p, id);
          issued++;
        } catch (e) {
          errors.push((e as Error).message);
        }
      }
    }
    await audit(p, 'bill', 'subscriptions', null, { companyId: company.id, until: body.until, created: created.length, issued, skipped });
    return { created: created.length, issued, skipped, errors, invoiceIds: created };
  });

  /** Émission : numéro définitif, dates, PDF archivé. Ensuite, plus aucune modification. */
  app.post('/invoices/:id/issue', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    return issueInvoice(req.principal, id);
  });

  async function issueInvoice(p: Principal, id: string) {
    const current = await loadInvoice(p, id, 'invoice.write');
    if (current.status !== 'DRAFT') throw conflict('Cette facture est déjà émise');
    const lines = await db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, id));
    if (!lines.length) throw badRequest('Ajoutez au moins une ligne');
    if (current.grossCents <= 0) throw badRequest('Le total doit être positif');
    const zero = lines.filter((l) => l.unitPriceCents === 0);
    if (zero.length) throw badRequest(`Ligne sans prix : ${zero.map((l) => l.description).join(', ')}`);
    if (current.kind === 'CREDIT_NOTE') {
      const [orig] = await db.select().from(inv).where(eq(inv.id, current.creditedInvoiceId!));
      const { credited } = await settlements([orig.id]);
      if ((credited.get(orig.id) ?? 0) + current.grossCents > orig.grossCents) {
        throw badRequest('Le total des avoirs dépasserait le montant de la facture');
      }
    }
    const company = (await getCompany(p.groupId, current.companyId))!;
    const issueDate = todayIn(company.timezone);
    await db.transaction(async (tx) => {
      // Le compteur et la facture sont écrits ensemble : en cas d'échec, aucun numéro n'est consommé
      const number = await nextNumber(tx, company, current.kind === 'CREDIT_NOTE' ? 'credit_note' : 'invoice');
      const [done] = await tx.update(inv).set({
        status: 'ISSUED', number, issueDate,
        dueDate: current.kind === 'INVOICE' ? addDays(issueDate, current.paymentTermsDays) : null,
        serviceDate: current.serviceDate ?? issueDate, issuedById: p.userId, updatedAt: new Date(),
      }).where(and(eq(inv.id, id), eq(inv.status, 'DRAFT'))).returning({ id: inv.id });
      if (!done) throw conflict('Cette facture vient d’être émise par quelqu’un d’autre');
    });
    // PDF archivé : c'est ce document, et lui seul, qui fait foi
    const pdf = await buildPdf(id);
    const dir = path.resolve(env.STORAGE_DIR, 'invoices', current.companyId);
    await mkdir(dir, { recursive: true });
    const full = await loadFull(id);
    const pdfPath = path.join(dir, `${full.number}.pdf`);
    await writeFile(pdfPath, pdf);
    await db.update(inv).set({ pdfPath }).where(eq(inv.id, id));
    await audit(p, 'issue', 'invoice', id, { number: full.number });
    // Envoi automatique à la plateforme (entreprises clientes) : un échec n'empêche pas l'émission, il est affiché
    if (company.einvoiceAutoSend && platformOf(company) && full.client.type === 'COMPANY') {
      await sendToPlatform(id).catch(() => undefined);
      return loadFull(id);
    }
    return { ...full, pdfPath };
  }

  app.post('/invoices/:id/send', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(p, id, 'invoice.write');
    if (current.status !== 'ISSUED') throw conflict('Émettez la facture avant de l’envoyer');
    const body = z.object({ to: z.array(z.string().email()).optional() }).parse(req.body ?? {});
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, current.clientId));
    const to = body.to?.length ? body.to : client.email ? [client.email] : [];
    if (!to.length) throw badRequest("Le client n'a pas d'adresse e-mail : indiquez-en une");
    const pdf = (current.pdfPath && (await readFile(current.pdfPath).catch(() => null))) || (await buildPdf(id));
    const company = (await getCompany(p.groupId, current.companyId))!;
    const credit = current.kind === 'CREDIT_NOTE';
    const docLocale = clientLocale(client, company);
    await sendMail({
      to,
      brand: { name: company.name, logoPath: company.logoPath },
      ...docTexts(docLocale).invoiceMail({
        company: company.name, number: current.number!, credit,
        due: !credit && current.dueDate ? longDay(current.dueDate, docLocale) : null,
      }),
      attachments: [{ filename: `${current.number}.pdf`, content: pdf, contentType: 'application/pdf' }],
    });
    await db.update(inv).set({ sentAt: new Date(), sentTo: to.join(', ') }).where(eq(inv.id, id));
    await audit(p, 'send', 'invoice', id, { to });
    return loadFull(id);
  });

  app.get('/invoices/:id/pdf', async (req, reply) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(req.principal, id, 'invoice.read');
    const archived = current.status === 'ISSUED' && current.pdfPath ? await readFile(current.pdfPath).catch(() => null) : null;
    const pdf = archived ?? (await buildPdf(id));
    const name = current.number ?? 'brouillon';
    return reply.type('application/pdf').header('Content-Disposition', `inline; filename="${name}.pdf"`).send(pdf);
  });

  /** Données de la facture électronique (XML Factur-X), pour les vérifier ou les déposer à la main */
  app.get('/invoices/:id/facturx.xml', async (req, reply) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(req.principal, id, 'invoice.read');
    if (current.status !== 'ISSUED') throw conflict('Émettez la facture avant de télécharger sa version électronique');
    const full = await loadFull(id);
    const company = (await getCompany(full.groupId, full.companyId))!;
    return reply.type('application/xml; charset=utf-8')
      .header('Content-Disposition', `attachment; filename="${full.number}-factur-x.xml"`)
      .send(facturxXml(facturxInput(full, company)));
  });

  /** Dépôt sur la plateforme agréée de la société */
  app.post('/invoices/:id/einvoice', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(p, id, 'invoice.write');
    if (current.status !== 'ISSUED') throw conflict('Émettez la facture avant de l’envoyer à la plateforme');
    if (current.einvoiceFlowId && current.einvoiceStatus !== '213') throw conflict('Cette facture est déjà déposée sur la plateforme');
    const [client] = await db.select({ type: schema.clients.type }).from(schema.clients).where(eq(schema.clients.id, current.clientId));
    if (client?.type !== 'COMPANY') throw badRequest('Facture à un particulier : elle s’envoie au client par e-mail, elle ne passe pas par la plateforme');
    await sendToPlatform(id);
    await audit(p, 'einvoice', 'invoice', id);
    return loadFull(id);
  });

  /** Où en est la facture déposée (approuvée, refusée, encaissée…) */
  app.post('/invoices/:id/einvoice/refresh', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(p, id, 'invoice.read');
    if (!current.einvoiceFlowId) throw conflict('Cette facture n’a pas été déposée sur la plateforme');
    const company = (await getCompany(p.groupId, current.companyId))!;
    const cfg = platformOf(company);
    if (!cfg) throw badRequest('Aucune plateforme de facture électronique n’est réglée');
    if (!FINAL_STATUSES.has(current.einvoiceStatus ?? '')) {
      try {
        const status = await flowStatus(cfg, current.einvoiceFlowId);
        await db.update(inv).set({ einvoiceStatus: status ?? current.einvoiceStatus, einvoiceStatusAt: new Date(), einvoiceError: null }).where(eq(inv.id, id));
      } catch (e) {
        await db.update(inv).set({ einvoiceError: (e as Error).message }).where(eq(inv.id, id));
        throw badRequest((e as Error).message);
      }
    }
    return loadFull(id);
  });

  /** Encaissement (total ou partiel) */
  app.post('/invoices/:id/payments', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadInvoice(p, id, 'invoice.write');
    if (current.status !== 'ISSUED' || current.kind !== 'INVOICE') throw conflict('Un paiement se note sur une facture émise');
    const body = z.object({
      paidOn: z.string().date(),
      amountCents: z.number().int().positive('Le montant doit être positif'),
      method: z.enum(PAYMENT_METHODS),
      reference: z.string().trim().max(200).nullable().optional(),
    }).parse(req.body);
    const full = await loadFull(id);
    if (body.amountCents > full.remainingCents) throw badRequest('Le montant dépasse le reste à payer');
    const [pay] = await db.insert(schema.payments).values({ ...body, reference: body.reference ?? null, invoiceId: id, createdById: p.userId }).returning();
    await audit(p, 'payment', 'invoice', id, { amountCents: body.amountCents, method: body.method });
    return reply.code(201).send(pay);
  });

  app.delete('/invoices/:id/payments/:paymentId', async (req, reply) => {
    const p = req.principal;
    const { id, paymentId } = z.object({ id: z.string().uuid(), paymentId: z.string().uuid() }).parse(req.params);
    await loadInvoice(p, id, 'invoice.write');
    const [removed] = await db.delete(schema.payments)
      .where(and(eq(schema.payments.id, paymentId), eq(schema.payments.invoiceId, id))).returning();
    if (!removed) throw notFound('Paiement');
    await audit(p, 'payment.delete', 'invoice', id, { amountCents: removed.amountCents, paidOn: removed.paidOn });
    return reply.code(204).send();
  });

  /** Avoir sur une facture émise : brouillon reprenant ses lignes (à ajuster pour un avoir partiel) */
  app.post('/invoices/:id/credit-note', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const original = await loadInvoice(p, id, 'invoice.write');
    if (original.status !== 'ISSUED' || original.kind !== 'INVOICE') throw conflict('Un avoir se fait sur une facture émise');
    const lines = await db.select().from(schema.invoiceLines).where(eq(schema.invoiceLines.invoiceId, id)).orderBy(asc(schema.invoiceLines.position));
    const company = (await getCompany(p.groupId, original.companyId))!;
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, original.clientId));
    const docLocale = clientLocale(client, company);
    // « AVOIR » → « Avoir » (dans la langue du client)
    const label = docTexts(docLocale).creditNote;
    const creditLabel = label.charAt(0) + label.slice(1).toLocaleLowerCase(formatLocale(docLocale));
    const row = await createDraft(p, {
      kind: 'CREDIT_NOTE', clientId: original.clientId, siteId: original.siteId, agencyId: original.agencyId,
      title: `${creditLabel} – ${original.title}`,
      lines: lines.map(({ description, quantity, unit, unitPriceCents, vatRateBp }) => ({ description, quantity, unit, unitPriceCents, vatRateBp })),
      creditedInvoiceId: original.id,
    });
    await audit(p, 'create', 'invoice', row.id, { creditNoteFor: original.number });
    return reply.code(201).send({ id: row.id });
  });
}
