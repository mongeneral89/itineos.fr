import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, inArray, isNull, or } from 'drizzle-orm';
import { alias } from 'drizzle-orm/pg-core';
import { CLIENT_SEARCH_FIELDS, CLIENT_SORTS, clientOrder, clientSearchWhere, departmentWhere } from '../services/client-search.js';
import { z } from 'zod';
import { UI_LOCALES } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canSomewhere, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { CLIENT_IMPORT_FIELDS } from '@itineo/shared';
import { FILE_BODY_LIMIT, MAX_FILE_BYTES } from '../services/files.js';
import { readTable, TableError } from '../services/import-table.js';
import { applyImport, guessMapping, importTemplateCsv, planImport } from '../services/client-import.js';

const opt = z.string().trim().optional().transform((s) => (s ? s : undefined));

const siteBody = z.object({
  name: z.string().min(1),
  address: opt,
  postalCode: opt,
  city: opt,
  countryCode: z.string().length(2).optional(),
  accessNotes: opt,
  latitude: z.number().optional(),
  longitude: z.number().optional(),
});

const equipmentBody = z.object({
  category: z.string().min(1),
  brand: opt,
  model: opt,
  serialNumber: opt,
  location: opt,
  installedAt: z.string().date().optional(),
  warrantyUntil: z.string().date().optional(),
  underContract: z.boolean().default(false),
  notes: opt,
  // Vide = effacé (une modification peut retirer l'indication)
  locateHint: z.string().trim().max(300).optional().transform((s) => (s === undefined ? undefined : s || null)),
});

const clientBody = z.object({
  companyId: z.string().uuid(),
  agencyId: z.string().uuid().nullable().default(null),
  type: z.enum(['COMPANY', 'INDIVIDUAL']).default('COMPANY'),
  name: z.string().min(1),
  email: z.string().email().optional().or(z.literal('').transform(() => undefined)),
  phone: opt,
  address: opt,
  postalCode: opt,
  city: opt,
  countryCode: z.string().length(2).optional(),
  externalRef: opt,
  /** Entreprise cliente : SIREN (ou SIRET) et n° de TVA, obligatoires sur les factures électroniques */
  siren: z.string().trim().max(20).nullable().optional().transform((s) => (s === undefined ? undefined : s || null)).refine((s) => !s || /^\d{9}(\d{5})?$/.test(s.replace(/\s/g, '')), 'SIREN : 9 chiffres (ou SIRET : 14 chiffres)'),
  vatNumber: z.string().trim().max(20).nullable().optional().transform((s) => (s === undefined ? undefined : s || null)),
  /** N° d'abonné (télésurveillance, contrat…) */
  subscriberNumber: z.string().trim().max(60).nullable().optional().transform((s) => (s === undefined ? undefined : s || null)),
  notes: opt,
  /** Langue des documents envoyés au client ; vide = langue de la société */
  locale: z.enum(UI_LOCALES).nullable().optional(),
  sites: z.array(siteBody).default([]),
});

/** Charge un client et vérifie la permission demandée sur son périmètre */
export async function loadClient(p: Principal, id: string, perm: 'client.read' | 'client.write') {
  const [c] = await db
    .select()
    .from(schema.clients)
    .where(and(eq(schema.clients.id, id), eq(schema.clients.groupId, p.groupId)));
  if (!c) throw notFound('Client');
  if (!can(p, perm, { companyId: c.companyId, agencyId: c.agencyId }, { sharedVisible: perm === 'client.read' })) {
    throw forbidden();
  }
  return c;
}

export async function loadSite(p: Principal, siteId: string, perm: 'client.read' | 'client.write') {
  const [s] = await db.select().from(schema.sites).where(eq(schema.sites.id, siteId));
  if (!s) throw notFound('Site');
  const client = await loadClient(p, s.clientId, perm);
  return { site: s, client };
}

export async function clientRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Liste et recherche de clients */
  app.get('/clients', async (req) => {
    const p = req.principal;
    const q = z.object({
      companyId: z.string().uuid().optional(),
      agencyId: z.string().uuid().optional(),
      q: z.string().max(200).optional(),
      field: z.enum(CLIENT_SEARCH_FIELDS).default('all'),
      dept: z.string().max(5).optional(),
      sort: z.enum(CLIENT_SORTS).default('name'),
      limit: z.coerce.number().int().min(1).max(200).default(50),
    }).parse(req.query);
    // Alias « c » : la recherche (services/client-search.ts) écrit ses conditions sur c.*
    const c = alias(schema.clients, 'c');
    return db
      .select()
      .from(c)
      .where(and(
        eq(c.groupId, p.groupId),
        scopeWhere(scopeFor(p, 'client.read'), { companyId: c.companyId, agencyId: c.agencyId }, { sharedVisible: true }),
        q.companyId ? eq(c.companyId, q.companyId) : undefined,
        // Une agence voit ses clients et les clients partagés de la société
        q.agencyId ? or(eq(c.agencyId, q.agencyId), isNull(c.agencyId)) : undefined,
        q.q ? clientSearchWhere(q.q, q.field) ?? undefined : undefined,
        q.dept ? departmentWhere(q.dept) ?? undefined : undefined,
      ))
      .orderBy(clientOrder(q.sort))
      .limit(q.limit);
  });

  /** Fiche client complète : contacts, sites, équipements, dernières interventions */
  app.get('/clients/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const client = await loadClient(p, id, 'client.read');
    const contacts = await db.select().from(schema.contacts).where(eq(schema.contacts.clientId, id));
    const sites = await db.select().from(schema.sites).where(eq(schema.sites.clientId, id)).orderBy(asc(schema.sites.name));
    const equipments = sites.length
      ? await db.select().from(schema.equipments).where(inArray(schema.equipments.siteId, sites.map((s) => s.id)))
      : [];
    const i = schema.interventions;
    const history = await db
      .select({
        id: i.id, number: i.number, kind: i.kind, status: i.status, reason: i.reason,
        scheduledStart: i.scheduledStart, siteId: i.siteId, equipmentId: i.equipmentId, technicianId: i.technicianId,
      })
      .from(i)
      .where(eq(i.clientId, id))
      .orderBy(desc(i.createdAt))
      .limit(30);
    return {
      ...client,
      contacts,
      sites: sites.map((s) => ({ ...s, equipments: equipments.filter((e) => e.siteId === s.id) })),
      history,
    };
  });

  app.post('/clients', async (req, reply) => {
    const p = req.principal;
    const body = clientBody.parse(req.body);
    const company = await getCompany(p.groupId, body.companyId);
    if (!company) throw badRequest('Société inconnue');
    if (body.agencyId && !(await getAgency(company.id, body.agencyId))) throw badRequest('Agence inconnue');
    if (!can(p, 'client.write', { companyId: body.companyId, agencyId: body.agencyId })) throw forbidden();

    const { sites, ...data } = body;
    const created = await db.transaction(async (tx) => {
      const [client] = await tx.insert(schema.clients).values({
        ...data,
        groupId: p.groupId,
        countryCode: data.countryCode ?? company.countryCode,
      }).returning();
      // Un client a toujours au moins un site : par défaut, son adresse
      const siteRows: z.infer<typeof siteBody>[] = sites.length
        ? sites
        : [{ name: client.name, address: client.address ?? undefined, postalCode: client.postalCode ?? undefined, city: client.city ?? undefined }];
      await tx.insert(schema.sites).values(siteRows.map((s) => ({
        ...s, clientId: client.id, countryCode: s.countryCode ?? client.countryCode,
      })));
      return client;
    });
    await audit(p, 'create', 'client', created.id, { name: created.name });
    return reply.code(201).send(created);
  });

  app.patch('/clients/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadClient(p, id, 'client.write');
    const body = clientBody.omit({ companyId: true, sites: true, agencyId: true }).partial().parse(req.body);
    const [updated] = await db.update(schema.clients).set(body).where(eq(schema.clients.id, id)).returning();
    await audit(p, 'update', 'client', id, body);
    return updated;
  });

  app.post('/clients/:id/contacts', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadClient(p, id, 'client.write');
    const body = z.object({ name: z.string().min(1), email: z.string().email().optional(), phone: opt, role: opt }).parse(req.body);
    const [contact] = await db.insert(schema.contacts).values({ ...body, clientId: id }).returning();
    return reply.code(201).send(contact);
  });

  app.post('/clients/:id/sites', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const client = await loadClient(p, id, 'client.write');
    const body = siteBody.parse(req.body);
    const [site] = await db.insert(schema.sites).values({
      ...body, clientId: id, countryCode: body.countryCode ?? client.countryCode,
    }).returning();
    return reply.code(201).send(site);
  });

  app.post('/sites/:id/equipments', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadSite(p, id, 'client.write');
    const body = equipmentBody.parse(req.body);
    const [equipment] = await db.insert(schema.equipments).values({ ...body, siteId: id }).returning();
    return reply.code(201).send(equipment);
  });

  // ─── Import d'un fichier (CSV ou Excel) : aperçu, puis enregistrement ───

  const importBody = z.object({
    companyId: z.string().uuid(),
    agencyId: z.string().uuid().nullable().default(null),
    /** Fichier en data URL (le type annoncé par le navigateur varie : on lit le contenu) */
    file: z.string().max(FILE_BODY_LIMIT),
    /** Colonne Itinéos de chaque colonne du fichier ; absent = reconnue d'après les titres */
    mapping: z.array(z.enum(CLIENT_IMPORT_FIELDS).nullable()).optional(),
  });

  async function prepareImport(p: Principal, raw: unknown) {
    const body = importBody.parse(raw);
    const company = await getCompany(p.groupId, body.companyId);
    if (!company) throw badRequest('Société inconnue');
    if (body.agencyId && !(await getAgency(company.id, body.agencyId))) throw badRequest('Agence inconnue');
    if (!can(p, 'client.write', { companyId: body.companyId, agencyId: body.agencyId })) throw forbidden();
    const m = /^data:[^,]*;base64,([A-Za-z0-9+/=]+)$/.exec(body.file);
    const buffer = m ? Buffer.from(m[1], 'base64') : null;
    if (!buffer?.length || buffer.length > MAX_FILE_BYTES) throw badRequest('Fichier illisible ou trop volumineux (10 Mo au plus)');
    let table: string[][];
    try {
      table = readTable(buffer);
    } catch (err) {
      if (err instanceof TableError) throw badRequest(err.message);
      throw badRequest('Fichier illisible : enregistrez-le en CSV ou en Excel (.xlsx)');
    }
    if (table.length < 2) throw badRequest('Le fichier doit contenir une ligne de titres puis au moins une ligne');
    const headers = table[0];
    const mapping = body.mapping && body.mapping.length === headers.length ? body.mapping : guessMapping(headers);
    if (!mapping.includes('clientName')) throw badRequest('Choisissez la colonne du nom du client');
    const target = { groupId: p.groupId, companyId: company.id, agencyId: body.agencyId, countryCode: company.countryCode };
    return { target, plan: await planImport(table, mapping, target) };
  }

  /** Aperçu : colonnes reconnues, ce qui sera créé, lignes à corriger. Rien n'est enregistré. */
  app.post('/clients/import/preview', { bodyLimit: FILE_BODY_LIMIT }, async (req) => {
    const { plan } = await prepareImport(req.principal, req.body);
    return plan.preview;
  });

  app.post('/clients/import', { bodyLimit: FILE_BODY_LIMIT }, async (req) => {
    const p = req.principal;
    const { target, plan } = await prepareImport(p, req.body);
    if (plan.preview.issues.some((i) => i.code === 'tooManyRows')) throw badRequest('Fichier trop long : 5 000 lignes au plus');
    const result = await applyImport(plan, target);
    await audit(p, 'import', 'client', null, { ...result, rows: plan.preview.rows });
    return result;
  });

  /** Modèle à remplir, pour ceux qui partent d'un tableur */
  app.get('/clients/import/template', async (req, reply) => {
    if (!canSomewhere(req.principal, 'client.write')) throw forbidden();
    return reply
      .type('text/csv; charset=utf-8')
      .header('Content-Disposition', 'attachment; filename="modele-import-clients.csv"')
      .send(importTemplateCsv());
  });

  app.patch('/equipments/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [eqp] = await db.select().from(schema.equipments).where(eq(schema.equipments.id, id));
    if (!eqp) throw notFound('Équipement');
    await loadSite(p, eqp.siteId, 'client.write');
    const body = equipmentBody.partial().parse(req.body);
    const [updated] = await db.update(schema.equipments).set(body).where(eq(schema.equipments.id, id)).returning();
    return updated;
  });
}
