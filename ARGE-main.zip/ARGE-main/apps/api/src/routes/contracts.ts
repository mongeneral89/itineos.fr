/**
 * Contrats d'entretien : les visites sont créées automatiquement (services/contracts.ts).
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, gte, ilike, inArray, or } from 'drizzle-orm';
import { z } from 'zod';
import { CONTRACT_STATUSES, visitDueDates } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { nextNumber } from '../services/numbering.js';
import { generateContractVisits, todayIn } from '../services/contracts.js';
import { checkEquipments } from './quotes.js';

const c = schema.contracts;
const i = schema.interventions;

const contractBody = z.object({
  agencyId: z.string().uuid(),
  clientId: z.string().uuid(),
  siteId: z.string().uuid(),
  equipmentIds: z.array(z.string().uuid()).default([]),
  title: z.string().trim().min(1, "L'intitulé du contrat est obligatoire").max(300),
  /** 0 = aucune visite (abonnement seul, par exemple la télésurveillance) */
  frequencyMonths: z.number().int().min(0).max(60),
  startDate: z.string().date(),
  endDate: z.string().date().nullable().optional(),
  visitHours: z.number().positive().max(24).default(1),
  annualPriceCents: z.number().int().min(0).nullable().optional(),
  /** Facturation en lot : tous les N mois, à terme à échoir (vide = pas de facturation automatique) */
  billingMonths: z.number().int().min(1).max(12).nullable().optional(),
  /** Déjà facturé jusqu'à cette date (reprise d'un client facturé ailleurs) */
  billedUntil: z.string().date().nullable().optional(),
  notes: z.string().max(5000).nullable().optional(),
}).refine((b) => !b.endDate || b.endDate >= b.startDate, { message: 'La date de fin doit suivre la date de début', path: ['endDate'] });

async function loadContract(p: Principal, id: string, perm: 'contract.read' | 'contract.write') {
  const [row] = await db.select().from(c).where(and(eq(c.id, id), eq(c.groupId, p.groupId)));
  if (!row) throw notFound('Contrat');
  if (!can(p, perm, { companyId: row.companyId, agencyId: row.agencyId })) throw forbidden();
  return row;
}

async function checkTargets(p: Principal, b: { clientId: string; siteId: string; agencyId: string; equipmentIds: string[] }) {
  const [client] = await db.select().from(schema.clients)
    .where(and(eq(schema.clients.id, b.clientId), eq(schema.clients.groupId, p.groupId)));
  if (!client) throw badRequest('Client inconnu');
  const company = await getCompany(p.groupId, client.companyId);
  if (!company) throw badRequest('Société inconnue');
  if (!(await getAgency(company.id, b.agencyId))) throw badRequest('Agence inconnue');
  const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, b.siteId));
  if (!site || site.clientId !== client.id) throw badRequest("Ce site n'appartient pas au client");
  await checkEquipments(site.id, b.equipmentIds);
  if (!can(p, 'contract.write', { companyId: company.id, agencyId: b.agencyId })) throw forbidden();
  return { client, company };
}

/**
 * Après un changement (fréquence, dates, suspension…), les visites futures encore « à planifier »
 * qui ne correspondent plus au contrat sont retirées. Celles déjà planifiées ne bougent jamais.
 */
async function pruneUnplannedVisits(contract: typeof c.$inferSelect, timezone: string) {
  const today = todayIn(timezone);
  const pending = await db.select({ id: i.id, due: i.dueDate }).from(i)
    .where(and(eq(i.contractId, contract.id), eq(i.status, 'TO_PLAN'), gte(i.dueDate, today)));
  if (!pending.length) return 0;
  // Une visite est gardée si son échéance fait toujours partie du calendrier du contrat
  const stillDue = (due: string) => contract.status === 'ACTIVE' && visitDueDates(contract, due, due).length === 1;
  const remove = pending.filter((v) => !v.due || !stillDue(v.due)).map((v) => v.id);
  if (remove.length) await db.delete(i).where(inArray(i.id, remove));
  return remove.length;
}

export async function contractRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/contracts', async (req) => {
    const p = req.principal;
    const f = z.object({
      companyId: z.string().uuid().optional(),
      agencyId: z.string().uuid().optional(),
      clientId: z.string().uuid().optional(),
      status: z.enum(CONTRACT_STATUSES).optional(),
      q: z.string().optional(),
    }).parse(req.query);
    const term = f.q?.trim();
    return db
      .select({
        id: c.id, number: c.number, companyId: c.companyId, agencyId: c.agencyId, clientId: c.clientId, siteId: c.siteId,
        title: c.title, status: c.status, frequencyMonths: c.frequencyMonths, startDate: c.startDate, endDate: c.endDate,
        annualPriceCents: c.annualPriceCents, billingMonths: c.billingMonths, billedUntil: c.billedUntil,
        clientName: schema.clients.name, siteName: schema.sites.name, siteCity: schema.sites.city,
      })
      .from(c)
      .innerJoin(schema.clients, eq(schema.clients.id, c.clientId))
      .innerJoin(schema.sites, eq(schema.sites.id, c.siteId))
      .where(and(
        eq(c.groupId, p.groupId),
        scopeWhere(scopeFor(p, 'contract.read'), { companyId: c.companyId, agencyId: c.agencyId }),
        f.companyId ? eq(c.companyId, f.companyId) : undefined,
        f.agencyId ? eq(c.agencyId, f.agencyId) : undefined,
        f.clientId ? eq(c.clientId, f.clientId) : undefined,
        f.status ? eq(c.status, f.status) : undefined,
        term ? or(ilike(c.title, `%${term}%`), ilike(c.number, `%${term}%`), ilike(schema.clients.name, `%${term}%`)) : undefined,
      ))
      .orderBy(asc(schema.clients.name), desc(c.startDate));
  });

  app.get('/contracts/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const contract = await loadContract(p, id, 'contract.read');
    const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, contract.clientId));
    const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, contract.siteId));
    const equipments = contract.equipmentIds.length
      ? await db.select().from(schema.equipments).where(inArray(schema.equipments.id, contract.equipmentIds))
      : [];
    const visits = await db
      .select({ id: i.id, number: i.number, status: i.status, dueDate: i.dueDate, scheduledStart: i.scheduledStart, technicianId: i.technicianId })
      .from(i).where(eq(i.contractId, id)).orderBy(desc(i.dueDate)).limit(100);
    const [quote] = contract.quoteId
      ? await db.select({ id: schema.quotes.id, number: schema.quotes.number }).from(schema.quotes).where(eq(schema.quotes.id, contract.quoteId))
      : [null];
    return { ...contract, client, site, equipments, visits, quote: quote ?? null };
  });

  app.post('/contracts', async (req, reply) => {
    const p = req.principal;
    const body = contractBody.parse(req.body);
    const { company } = await checkTargets(p, body);
    const created = await db.transaction(async (tx) => {
      const number = await nextNumber(tx, company, 'contract');
      const [row] = await tx.insert(c).values({
        ...body, endDate: body.endDate ?? null, annualPriceCents: body.annualPriceCents ?? null, notes: body.notes ?? null,
        billingMonths: body.billingMonths ?? null, billedUntil: body.billedUntil ?? null,
        groupId: p.groupId, companyId: company.id, number, createdById: p.userId,
      }).returning();
      return row;
    });
    await audit(p, 'create', 'contract', created.id, { number: created.number });
    const visits = await generateContractVisits({ contractId: created.id });
    return reply.code(201).send({ ...created, visitsCreated: visits });
  });

  app.patch('/contracts/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadContract(p, id, 'contract.write');
    const body = z.object({
      agencyId: z.string().uuid().optional(),
      siteId: z.string().uuid().optional(),
      equipmentIds: z.array(z.string().uuid()).optional(),
      title: z.string().trim().min(1).max(300).optional(),
      status: z.enum(CONTRACT_STATUSES).optional(),
      frequencyMonths: z.number().int().min(0).max(60).optional(),
      startDate: z.string().date().optional(),
      endDate: z.string().date().nullable().optional(),
      visitHours: z.number().positive().max(24).optional(),
      annualPriceCents: z.number().int().min(0).nullable().optional(),
      billingMonths: z.number().int().min(1).max(12).nullable().optional(),
      billedUntil: z.string().date().nullable().optional(),
      notes: z.string().max(5000).nullable().optional(),
    }).parse(req.body);
    const next = { ...current, ...body };
    if (next.endDate && next.endDate < next.startDate) throw badRequest('La date de fin doit suivre la date de début');
    const { company } = await checkTargets(p, next);
    const [updated] = await db.update(c).set({ ...body, updatedAt: new Date() }).where(eq(c.id, id)).returning();
    const removed = await pruneUnplannedVisits(updated, company.timezone);
    const created = await generateContractVisits({ contractId: id });
    await audit(p, 'update', 'contract', id, { ...body, visitsRemoved: removed, visitsCreated: created });
    return { ...updated, visitsRemoved: removed, visitsCreated: created };
  });

  /** Relance la création des visites à venir pour ce contrat */
  app.post('/contracts/:id/generate', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadContract(req.principal, id, 'contract.write');
    return { visitsCreated: await generateContractVisits({ contractId: id }) };
  });
}
