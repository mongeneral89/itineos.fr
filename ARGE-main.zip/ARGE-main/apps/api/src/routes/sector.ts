/**
 * Fonctions propres aux métiers (voir FEATURES dans packages/shared) :
 *  - Itinéos Vigie : points de passage des sites (QR codes) et alerte SOS de l'agent isolé
 *  - Itinéos Services : registre des traitements (produits biocides utilisés)
 * Chaque fonction n'est ouverte qu'aux sociétés du métier concerné.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, gte, inArray, isNull, lt, or, sql } from 'drizzle-orm';
import { alias } from 'drizzle-orm/pg-core';
import { z } from 'zod';
import { featureEnabled, type Feature } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { isEmptyScope, scopeFor } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { notifyUsers } from '../services/notify.js';
import { newCheckpointCode, siteCheckpoints } from '../services/sector-features.js';
import { loadSite } from './clients.js';
import { loadIntervention } from './interventions.js';

async function requireFeature(companyId: string, feature: Feature) {
  const [c] = await db.select({ sector: schema.companies.sector }).from(schema.companies).where(eq(schema.companies.id, companyId));
  if (!c || !featureEnabled(c.sector, feature)) throw forbidden();
}

export async function sectorRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  // ─── Itinéos Vigie : points de passage ────────────────────────────────

  /** Points de passage d'un site, avec le contenu de leur QR code (pour les imprimer) */
  app.get('/sites/:id/checkpoints', async (req) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { client } = await loadSite(req.principal, id, 'client.read');
    await requireFeature(client.companyId, 'checkpoints');
    return siteCheckpoints(id);
  });

  /** Nouveau point de passage, placé en fin de ronde */
  app.post('/sites/:id/checkpoints', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { client } = await loadSite(p, id, 'client.write');
    await requireFeature(client.companyId, 'checkpoints');
    const { name } = z.object({ name: z.string().trim().min(1, 'Le nom du point est obligatoire').max(120) }).parse(req.body);
    const [last] = await db.select({ position: schema.checkpoints.position }).from(schema.checkpoints)
      .where(eq(schema.checkpoints.siteId, id)).orderBy(desc(schema.checkpoints.position)).limit(1);
    const [cp] = await db.insert(schema.checkpoints).values({
      siteId: id, name, code: newCheckpointCode(), position: (last?.position ?? 0) + 1,
    }).returning();
    await audit(p, 'create', 'checkpoint', cp.id, { name, siteId: id });
    return reply.code(201).send(cp);
  });

  /** Renommer ou retirer un point (retiré : il disparaît des rondes, les passages déjà faits restent) */
  app.patch('/checkpoints/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [cp] = await db.select().from(schema.checkpoints).where(eq(schema.checkpoints.id, id));
    if (!cp) throw notFound('Point de passage');
    await loadSite(p, cp.siteId, 'client.write');
    const body = z.object({
      name: z.string().trim().min(1).max(120).optional(),
      active: z.boolean().optional(),
      position: z.number().int().min(0).max(10_000).optional(),
    }).parse(req.body);
    const [updated] = await db.update(schema.checkpoints).set(body).where(eq(schema.checkpoints.id, id)).returning();
    await audit(p, 'update', 'checkpoint', id, body);
    return updated;
  });

  // ─── Itinéos Vigie : alerte SOS de l'agent isolé ──────────────────────

  /**
   * L'agent appuie sur SOS : ses responsables (chef d'agence, planificateurs, direction, administrateurs)
   * sont prévenus aussitôt sur leur téléphone et par e-mail, avec sa position si elle est connue.
   */
  app.post('/alerts/sos', async (req) => {
    const p = req.principal;
    const body = z.object({
      lat: z.number().min(-90).max(90).optional(),
      lng: z.number().min(-180).max(180).optional(),
      accuracyM: z.number().min(0).max(100_000).optional(),
      interventionId: z.string().uuid().optional(),
    }).parse(req.body ?? {});

    // Société et agence de l'agent : celles de son affectation
    const home = p.assignments.find((a) => a.companyId);
    if (!home?.companyId) throw badRequest('Aucune société rattachée à ce compte');
    await requireFeature(home.companyId, 'sos');

    const iv = body.interventionId ? await loadIntervention(p, body.interventionId) : null;
    const [me] = await db.select({ firstName: schema.users.firstName, lastName: schema.users.lastName, phone: schema.users.phone })
      .from(schema.users).where(eq(schema.users.id, p.userId));
    const site = iv
      ? (await db.select({ client: schema.clients.name, city: schema.sites.city }).from(schema.sites)
          .innerJoin(schema.clients, eq(schema.clients.id, schema.sites.clientId)).where(eq(schema.sites.id, iv.siteId)))[0]
      : null;

    const ra = schema.roleAssignments;
    const agencyId = iv?.agencyId ?? home.agencyId;
    const managers = await db.select({ userId: ra.userId }).from(ra)
      .innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(
        eq(ra.groupId, p.groupId),
        eq(schema.users.active, true),
        or(
          eq(ra.role, 'GROUP_ADMIN'),
          and(eq(ra.role, 'DIRECTOR'), eq(ra.companyId, home.companyId)),
          and(inArray(ra.role, ['AGENCY_MANAGER', 'PLANNER']), eq(ra.companyId, home.companyId),
            agencyId ? or(eq(ra.agencyId, agencyId), isNull(ra.agencyId)) : undefined),
        ),
      ));
    const recipients = [...new Set(managers.map((m) => m.userId))].filter((id) => id !== p.userId);

    const name = `${me?.firstName ?? ''} ${me?.lastName ?? ''}`.trim();
    const where = body.lat != null && body.lng != null
      ? `https://www.google.com/maps?q=${body.lat.toFixed(6)},${body.lng.toFixed(6)}`
      : null;
    await notifyUsers(recipients, 'alert', (locale) => {
      const fr = locale.startsWith('fr');
      const lines = [
        fr ? `${name} a déclenché une alerte SOS.` : `${name} has raised an SOS alert.`,
        me?.phone ? `${fr ? 'Téléphone' : 'Phone'} : ${me.phone}` : null,
        iv ? `${iv.number}${site ? ` · ${site.client}${site.city ? `, ${site.city}` : ''}` : ''}` : null,
        where ? `${fr ? 'Position' : 'Location'} : ${where}${body.accuracyM ? ` (± ${Math.round(body.accuracyM)} m)` : ''}`
          : fr ? 'Position inconnue.' : 'Location unknown.',
      ].filter(Boolean);
      return {
        title: fr ? `ALERTE SOS – ${name}` : `SOS ALERT – ${name}`,
        body: lines.join('\n'),
        url: iv ? `/interventions/${iv.id}` : '/directory',
        tag: `sos-${p.userId}`,
      };
    });
    await audit(p, 'sos', 'user', p.userId, { interventionId: iv?.id ?? null, lat: body.lat ?? null, lng: body.lng ?? null, notified: recipients.length });
    return { notified: recipients.length };
  });

  // ─── Itinéos Services : registre des traitements ──────────────────────

  /**
   * Produits biocides utilisés, fiche par fiche (fiches signées dont le modèle a un champ « biocides »).
   * Période par défaut : les 12 derniers mois.
   */
  app.get('/registers/treatments', async (req) => {
    const p = req.principal;
    const now = new Date();
    const q = z.object({
      companyId: z.string().uuid(),
      agencyId: z.string().uuid().optional(),
      from: z.coerce.date().default(new Date(now.getFullYear() - 1, now.getMonth(), now.getDate())),
      to: z.coerce.date().default(new Date(now.getTime() + 86_400_000)),
    }).parse(req.query);
    if (!(await getCompany(p.groupId, q.companyId))) throw notFound('Société');
    await requireFeature(q.companyId, 'treatmentRegister');
    // Chacun ne voit que les fiches de son périmètre (filtre plus bas)
    const scope = scopeFor(p, 'report.read');
    if (isEmptyScope(scope)) throw forbidden();

    const i = schema.interventions;
    const r = schema.reports;
    const tech = alias(schema.users, 'tech');
    const rows = await db
      .select({
        interventionId: i.id, number: i.number, signedAt: r.signedAt, data: r.data,
        clientName: schema.clients.name, siteName: schema.sites.name, siteCity: schema.sites.city,
        technicianFirstName: tech.firstName, technicianLastName: tech.lastName,
      })
      .from(r)
      .innerJoin(i, eq(i.id, r.interventionId))
      .innerJoin(schema.clients, eq(schema.clients.id, i.clientId))
      .innerJoin(schema.sites, eq(schema.sites.id, i.siteId))
      .leftJoin(tech, eq(tech.id, i.technicianId))
      .where(and(
        eq(i.groupId, p.groupId),
        eq(i.companyId, q.companyId),
        q.agencyId ? eq(i.agencyId, q.agencyId) : undefined,
        scopeWhere(scope, { companyId: i.companyId, agencyId: i.agencyId }),
        inArray(r.status, ['SIGNED', 'SENT']),
        sql`${r.data} ? 'biocides'`,
        gte(r.signedAt, q.from),
        lt(r.signedAt, q.to),
      ))
      .orderBy(desc(r.signedAt), asc(i.number))
      .limit(2000);
    const str = (v: unknown) => (v === null || v === undefined ? '' : Array.isArray(v) ? v.join(', ') : String(v));
    return rows.map(({ data, ...row }) => ({
      ...row,
      pest: str(data.pest),
      zones: str(data.zones),
      biocides: str(data.biocides),
      baitStations: typeof data.baitStations === 'number' ? data.baitStations : null,
      reentry: str(data.reentry),
    }));
  });
}
