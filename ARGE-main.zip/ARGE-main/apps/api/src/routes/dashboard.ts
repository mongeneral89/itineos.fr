import type { FastifyInstance } from 'fastify';
import { and, asc, eq, gte, inArray, isNotNull, lt, notInArray, sql } from 'drizzle-orm';
import { alias } from 'drizzle-orm/pg-core';
import { z } from 'zod';
import { featureEnabled, SECTORS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { isEmptyScope, scopeFor } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { forbidden } from '../http.js';

const tech = alias(schema.users, 'tech');

/** Indicateurs par agence, pour comparer les agences entre elles */
export async function dashboardRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/dashboard', async (req) => {
    const p = req.principal;
    const scope = scopeFor(p, 'dashboard.read');
    if (isEmptyScope(scope)) throw forbidden();

    const now = new Date();
    const q = z.object({
      companyId: z.string().uuid().optional(),
      from: z.coerce.date().default(new Date(now.getFullYear(), now.getMonth(), 1)),
      to: z.coerce.date().default(new Date(now.getFullYear(), now.getMonth() + 1, 1)),
    }).parse(req.query);

    const i = schema.interventions;
    const r = schema.reports;
    const when = sql`coalesce(${i.scheduledStart}, ${i.createdAt})`;
    const scopeCond = scopeWhere(scope, { companyId: i.companyId, agencyId: i.agencyId });
    const companyCond = q.companyId ? eq(i.companyId, q.companyId) : undefined;

    const activity = await db
      .select({
        agencyId: i.agencyId,
        total: sql<number>`count(*)::int`,
        done: sql<number>`count(*) filter (where ${i.status} = 'DONE')::int`,
        toPlan: sql<number>`count(*) filter (where ${i.status} = 'TO_PLAN')::int`,
        toResume: sql<number>`count(*) filter (where ${i.status} = 'TO_RESUME')::int`,
        urgentOpen: sql<number>`count(*) filter (where ${i.priority} = 'URGENT' and ${i.status} not in ('DONE','CANCELLED'))::int`,
      })
      .from(i)
      .where(and(eq(i.groupId, p.groupId), scopeCond, companyCond, gte(when, q.from), lt(when, q.to)))
      .groupBy(i.agencyId);

    const quality = await db
      .select({
        agencyId: i.agencyId,
        reports: sql<number>`count(*)::int`,
        firstTimeFix: sql<number>`count(*) filter (where ${r.outcome} = 'DONE')::int`,
        avgHoursToSend: sql<number | null>`round(avg(extract(epoch from (${r.sentAt} - ${r.leftAt})) / 3600)::numeric, 1)::float`,
      })
      .from(r)
      .innerJoin(i, eq(i.id, r.interventionId))
      .where(and(eq(i.groupId, p.groupId), scopeCond, companyCond, eq(r.status, 'SENT'), gte(r.signedAt, q.from), lt(r.signedAt, q.to)))
      .groupBy(i.agencyId);

    const agencies = await db
      .select({ id: schema.agencies.id, name: schema.agencies.name, companyId: schema.agencies.companyId, companyName: schema.companies.name })
      .from(schema.agencies)
      .innerJoin(schema.companies, eq(schema.companies.id, schema.agencies.companyId))
      .where(and(
        eq(schema.companies.groupId, p.groupId),
        scopeWhere(scope, { companyId: schema.agencies.companyId, agencyId: schema.agencies.id }),
        q.companyId ? eq(schema.agencies.companyId, q.companyId) : undefined,
      ));

    const rows = agencies.map((a) => {
      const act = activity.find((x) => x.agencyId === a.id);
      const qual = quality.find((x) => x.agencyId === a.id);
      return {
        ...a,
        total: act?.total ?? 0,
        done: act?.done ?? 0,
        toPlan: act?.toPlan ?? 0,
        toResume: act?.toResume ?? 0,
        urgentOpen: act?.urgentOpen ?? 0,
        reports: qual?.reports ?? 0,
        firstTimeFixRate: qual?.reports ? Math.round((qual.firstTimeFix / qual.reports) * 100) : null,
        avgHoursToSend: qual?.avgHoursToSend ?? null,
      };
    });
    // Itinéos Expertise : rapports à rendre, par date limite (les plus urgents d'abord)
    const deadlineSectors = SECTORS.filter((s) => featureEnabled(s, 'deadlines'));
    const deadlines = await db
      .select({
        id: i.id, number: i.number, reason: i.reason, status: i.status, dueDate: i.dueDate,
        clientName: schema.clients.name, technicianFirstName: tech.firstName, technicianLastName: tech.lastName,
      })
      .from(i)
      .innerJoin(schema.companies, eq(schema.companies.id, i.companyId))
      .innerJoin(schema.clients, eq(schema.clients.id, i.clientId))
      .leftJoin(tech, eq(tech.id, i.technicianId))
      .where(and(
        eq(i.groupId, p.groupId), scopeCond, companyCond,
        inArray(schema.companies.sector, deadlineSectors),
        isNotNull(i.dueDate),
        notInArray(i.status, ['DONE', 'CANCELLED']),
      ))
      .orderBy(asc(i.dueDate))
      .limit(30);

    return {
      from: q.from, to: q.to, deadlines,
      agencies: rows.sort((a, b) => a.companyName.localeCompare(b.companyName) || a.name.localeCompare(b.name)),
    };
  });
}
