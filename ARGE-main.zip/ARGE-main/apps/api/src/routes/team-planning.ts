/**
 * Planning de l'équipe vu depuis l'appli terrain (lecture seule).
 *
 * Le bureau choisit, technicien par technicien, ce qu'il voit : son planning seulement (par défaut), celui de
 * toute son agence, ou celui de collègues choisis. Seul le strict nécessaire est montré : heure, client, ville,
 * type et statut de chaque intervention.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, eq, gte, inArray, isNull, lt, ne, or } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { can, isEmptyScope, scopeFor, type Principal } from '../auth/access.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { audit } from '../services/audit.js';

const u = schema.users;
const ra = schema.roleAssignments;
const ps = schema.planningShares;
const iv = schema.interventions;

export const PLANNING_VIEWS = ['OWN', 'AGENCY', 'CUSTOM'] as const;

/** Techniciens actifs rattachés à une agence (ou à toute sa société) */
async function techniciansOf(companyId: string, agencyId: string | null) {
  return db.selectDistinct({ id: u.id, firstName: u.firstName, lastName: u.lastName })
    .from(ra).innerJoin(u, eq(u.id, ra.userId))
    .where(and(
      eq(ra.role, 'TECHNICIAN'), eq(u.active, true), eq(ra.companyId, companyId),
      agencyId ? or(eq(ra.agencyId, agencyId), isNull(ra.agencyId)) : undefined,
    ));
}

/** Qui ce technicien peut-il voir ? (toujours lui-même) */
export async function visibleTechnicians(p: Principal): Promise<{ mode: (typeof PLANNING_VIEWS)[number]; ids: string[] }> {
  const [me] = await db.select({ view: u.planningView }).from(u).where(eq(u.id, p.userId));
  const mode = me?.view ?? 'OWN';
  const ids = new Set([p.userId]);
  if (mode === 'AGENCY') {
    for (const a of p.assignments.filter((x) => x.role === 'TECHNICIAN' && x.companyId)) {
      for (const t of await techniciansOf(a.companyId!, a.agencyId)) ids.add(t.id);
    }
  } else if (mode === 'CUSTOM') {
    for (const r of await db.select({ id: ps.targetId }).from(ps).where(eq(ps.viewerId, p.userId))) ids.add(r.id);
  }
  return { mode, ids: [...ids] };
}

/** Le bureau peut-il régler ce technicien ? (droit d'attribuer sur une de ses agences) */
async function manageableTech(p: Principal, userId: string) {
  const [user] = await db.select().from(u).where(and(eq(u.id, userId), eq(u.groupId, p.groupId)));
  if (!user) throw notFound('Utilisateur');
  const grants = await db.select().from(ra).where(and(eq(ra.userId, userId), eq(ra.role, 'TECHNICIAN')));
  const grant = grants.find((g) => g.companyId && can(p, 'intervention.assign', { companyId: g.companyId, agencyId: g.agencyId }, { sharedVisible: true }));
  if (!grant) throw forbidden();
  return { user, companyId: grant.companyId! };
}

export async function teamPlanningRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Appli terrain : le planning des collègues visibles, sur une période (31 jours au plus) */
  app.get('/team-planning', async (req) => {
    const p = req.principal;
    const q = z.object({ from: z.coerce.date(), to: z.coerce.date() }).parse(req.query);
    if (q.to <= q.from || q.to.getTime() - q.from.getTime() > 31 * 86_400_000) throw badRequest('Période invalide');
    const { mode, ids } = await visibleTechnicians(p);
    const technicians = await db.select({ id: u.id, firstName: u.firstName, lastName: u.lastName }).from(u)
      .where(inArray(u.id, ids)).orderBy(asc(u.lastName), asc(u.firstName));
    const jobs = await db.select({
      id: iv.id, number: iv.number, technicianId: iv.technicianId, kind: iv.kind, status: iv.status, priority: iv.priority,
      start: iv.scheduledStart, end: iv.scheduledEnd, clientName: schema.clients.name, city: schema.sites.city,
    }).from(iv)
      .innerJoin(schema.clients, eq(schema.clients.id, iv.clientId))
      .innerJoin(schema.sites, eq(schema.sites.id, iv.siteId))
      .where(and(eq(iv.groupId, p.groupId), inArray(iv.technicianId, ids), gte(iv.scheduledStart, q.from), lt(iv.scheduledStart, q.to), ne(iv.status, 'CANCELLED')))
      .orderBy(asc(iv.scheduledStart));
    return { mode, technicians: technicians.map((t) => ({ ...t, me: t.id === p.userId })), jobs };
  });

  /** Bureau : ce que voit chaque technicien du périmètre */
  app.get('/planning-visibility', async (req) => {
    const p = req.principal;
    const q = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid().optional() }).parse(req.query);
    if (isEmptyScope(scopeFor(p, 'intervention.assign'))) throw forbidden();
    const all = await techniciansOf(q.companyId, q.agencyId ?? null);
    // Seulement les techniciens que cette personne planifie
    const techGrants = all.length ? await db.select().from(ra).where(and(inArray(ra.userId, all.map((t) => t.id)), eq(ra.role, 'TECHNICIAN'))) : [];
    const techs = all.filter((t) => techGrants.some((g) => g.userId === t.id && g.companyId
      && can(p, 'intervention.assign', { companyId: g.companyId, agencyId: g.agencyId }, { sharedVisible: true })));
    const ids = techs.map((t) => t.id);
    const views = ids.length ? await db.select({ id: u.id, view: u.planningView }).from(u).where(inArray(u.id, ids)) : [];
    const shares = ids.length ? await db.select().from(ps).where(inArray(ps.viewerId, ids)) : [];
    // Agence(s) de chacun, pour l'affichage
    const grants = ids.length ? await db.select({ userId: ra.userId, agencyName: schema.agencies.name })
      .from(ra).leftJoin(schema.agencies, eq(schema.agencies.id, ra.agencyId))
      .where(and(inArray(ra.userId, ids), eq(ra.role, 'TECHNICIAN'))) : [];
    return techs
      .sort((a, b) => a.lastName.localeCompare(b.lastName))
      .map((t) => ({
        ...t,
        mode: views.find((v) => v.id === t.id)?.view ?? 'OWN',
        targetIds: shares.filter((s) => s.viewerId === t.id).map((s) => s.targetId),
        agencies: [...new Set(grants.filter((g) => g.userId === t.id).map((g) => g.agencyName).filter((x): x is string => !!x))],
      }));
  });

  app.put('/planning-visibility/:userId', async (req) => {
    const p = req.principal;
    const { userId } = z.object({ userId: z.string().uuid() }).parse(req.params);
    const body = z.object({ mode: z.enum(PLANNING_VIEWS), targetIds: z.array(z.string().uuid()).max(200).default([]) }).parse(req.body);
    const { companyId } = await manageableTech(p, userId);
    let targets: string[] = [];
    if (body.mode === 'CUSTOM') {
      const allowed = new Set((await techniciansOf(companyId, null)).map((t) => t.id));
      targets = [...new Set(body.targetIds)].filter((x) => x !== userId);
      if (targets.some((x) => !allowed.has(x))) throw badRequest('Ce technicien ne fait pas partie de la société');
    }
    await db.transaction(async (tx) => {
      await tx.update(u).set({ planningView: body.mode }).where(eq(u.id, userId));
      await tx.delete(ps).where(eq(ps.viewerId, userId));
      if (targets.length) await tx.insert(ps).values(targets.map((targetId) => ({ viewerId: userId, targetId })));
    });
    await audit(p, 'update', 'planning_visibility', userId, { mode: body.mode, targets: targets.length });
    return { mode: body.mode, targetIds: targets };
  });
}
