import type { FastifyInstance } from 'fastify';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { env } from '../env.js';
import { db, schema } from '../db/client.js';
import { can, canGroupWide } from '../auth/access.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { parseLogoDataUrl, removeLogo, storeLogo } from '../services/logo.js';
import { getCompany, publicCompany, visibleOrg } from '../services/org.js';
import { audit } from '../services/audit.js';
import { testPlatform } from '../services/einvoice.js';
import { PassThrough } from 'node:stream';
import { writeCompanyExport } from '../services/company-export.js';
import { bicValid, compactIban, creditorIdValid, ibanValid } from '../services/sepa.js';
import type { Principal } from '../auth/access.js';

/** Export complet : administrateur du groupe, ou directeur de toute la société */
export function canExportCompany(p: Principal, companyId: string): boolean {
  return p.assignments.some((a) =>
    (a.role === 'GROUP_ADMIN' && (!a.companyId || a.companyId === companyId) && !a.agencyId)
    || (a.role === 'DIRECTOR' && a.companyId === companyId && !a.agencyId));
}

const companyBody = z.object({
  name: z.string().min(1),
  legalName: z.string().optional(),
  countryCode: z.string().length(2).transform((s) => s.toUpperCase()),
  currency: z.string().length(3).transform((s) => s.toUpperCase()),
  locale: z.string().default('fr-FR'),
  timezone: z.string().default('Europe/Paris'),
  vatNumber: z.string().optional(),
  /** SIREN (ou SIRET) : obligatoire sur les factures électroniques */
  siren: z.string().trim().max(20).optional().refine((s) => !s || /^\d{9}(\d{5})?$/.test(s.replace(/\s/g, '')), 'SIREN : 9 chiffres (ou SIRET : 14 chiffres)'),
  address: z.string().optional(),
  postalCode: z.string().optional(),
  city: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  documentPrefix: z.string().min(1).max(8).transform((s) => s.toUpperCase()),
  legalMentions: z.string().optional(),
});

const agencyBody = z.object({
  name: z.string().min(1),
  code: z.string().min(1).max(16),
  address: z.string().optional(),
  postalCode: z.string().optional(),
  city: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
});

export async function orgRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Arbre des sociétés, agences et équipes visibles */
  app.get('/org', async (req) => visibleOrg(req.principal));

  /**
   * Export complet des données de la société (archive .zip envoyée au fur et à mesure).
   * Réservé à l'administrateur du groupe et au directeur de la société entière.
   */
  app.get('/org/companies/:companyId/export', async (req, reply) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!canExportCompany(p, companyId)) throw forbidden();
    await audit(p, 'export', 'company', companyId, {});

    const stream = new PassThrough();
    const write = (chunk: Buffer) => new Promise<void>((resolve, reject) => {
      if (stream.destroyed) return reject(new Error('Export interrompu'));
      if (stream.write(chunk)) resolve();
      else stream.once('drain', resolve);
    });
    // L'archive s'écrit pendant que le navigateur la télécharge
    void writeCompanyExport(company.id, p.groupId, write)
      .then(() => stream.end())
      .catch((err) => {
        req.log.error({ err }, 'export interrompu');
        stream.destroy(err as Error);
      });
    const name = `itineos-export-${company.documentPrefix.toLowerCase()}-${new Date().toISOString().slice(0, 10)}.zip`;
    return reply
      .type('application/zip')
      .header('Content-Disposition', `attachment; filename="${name}"`)
      .header('Cache-Control', 'no-store')
      .send(stream);
  });

  /** Nouvelle société dans le groupe (nouveau pays, nouvelle entité) */
  app.post('/org/companies', async (req, reply) => {
    const p = req.principal;
    if (!canGroupWide(p, 'org.write')) throw forbidden();
    const body = companyBody.parse(req.body);
    // Vérifie que le fuseau horaire existe, sinon Intl lève une erreur
    new Intl.DateTimeFormat('en', { timeZone: body.timezone });
    // Le secteur est celui de l'édition installée (Itinéos Vigie : sécurité privée…)
    const [company] = await db.insert(schema.companies).values({ ...body, groupId: p.groupId, sector: env.EDITION }).returning();
    await audit(p, 'create', 'company', company.id, { name: company.name });
    return reply.code(201).send(publicCompany(company));
  });

  /** Coordonnées et mentions d'une société (le pays et la devise ne changent pas : les documents en dépendent) */
  app.patch('/org/companies/:companyId', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'org.write', { companyId })) throw forbidden();
    const body = companyBody.omit({ countryCode: true, currency: true }).partial().parse(req.body);
    if (body.timezone) new Intl.DateTimeFormat('en', { timeZone: body.timezone });
    const [updated] = await db.update(schema.companies).set(body).where(eq(schema.companies.id, companyId)).returning();
    await audit(p, 'update', 'company', companyId, body);
    return publicCompany(updated);
  });

  /**
   * Réglages de facturation : délai de paiement, taux horaire, forfait de déplacement, coordonnées bancaires.
   * Réservé à qui facture pour TOUTE la société (direction, comptabilité, administrateur).
   */
  app.patch('/org/companies/:companyId/billing', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'invoice.write', { companyId, agencyId: null })) throw forbidden();
    const body = z.object({
      paymentTermsDays: z.number().int().min(0).max(120).optional(),
      hourlyRateCents: z.number().int().min(0).max(10_000_000).nullable().optional(),
      travelFeeCents: z.number().int().min(0).max(10_000_000).nullable().optional(),
      bankDetails: z.string().max(500).nullable().optional(),
      legalMentions: z.string().max(1000).nullable().optional(),
      /** Facture électronique : TVA sur les débits, plateforme agréée (API + jeton), envoi automatique */
      vatOnDebits: z.boolean().optional(),
      einvoiceApiUrl: z.string().trim().url('Adresse de la plateforme invalide').refine((u) => u.startsWith('https://'), 'L’adresse de la plateforme commence par https://').nullable().optional()
        .or(z.literal('').transform(() => null)),
      /** Jeton : jamais renvoyé ; absent = inchangé, vide = effacé */
      einvoiceApiToken: z.string().trim().max(4000).nullable().optional().transform((s) => (s === undefined ? undefined : s || null)),
      einvoiceAutoSend: z.boolean().optional(),
      /** Prélèvement SEPA : identifiant créancier (ICS), IBAN et BIC du compte qui reçoit les prélèvements */
      sepaCreditorId: z.string().trim().max(35).nullable().optional().transform((s) => (s === undefined ? undefined : s ? s.replace(/\s+/g, '').toUpperCase() : null))
        .refine((s) => !s || creditorIdValid(s), 'Identifiant créancier SEPA (ICS) invalide'),
      sepaIban: z.string().trim().max(50).nullable().optional().transform((s) => (s === undefined ? undefined : s ? compactIban(s) : null))
        .refine((s) => !s || ibanValid(s), 'IBAN invalide'),
      sepaBic: z.string().trim().max(15).nullable().optional().transform((s) => (s === undefined ? undefined : s ? s.replace(/\s+/g, '').toUpperCase() : null))
        .refine((s) => !s || bicValid(s), 'BIC invalide'),
      /** Relances des impayés : envoi automatique, et jours après l'échéance du rappel, de la relance et de la mise en demeure */
      dunningEnabled: z.boolean().optional(),
      dunningDays: z.array(z.number().int().min(1).max(365)).length(3)
        .refine((d) => d[0] < d[1] && d[1] < d[2], 'Les délais des relances doivent aller en augmentant').optional(),
    }).parse(req.body);
    const [updated] = await db.update(schema.companies).set(body).where(eq(schema.companies.id, companyId)).returning();
    // Le jeton n'entre pas dans le journal
    const { einvoiceApiToken: token, ...logged } = body;
    await audit(p, 'update', 'company.billing', companyId, { ...logged, ...(token !== undefined ? { einvoiceApiToken: token ? 'changé' : 'effacé' } : {}) });
    return publicCompany(updated);
  });

  /** Facture électronique : vérifie l'adresse de la plateforme et le jeton enregistrés */
  app.post('/org/companies/:companyId/einvoice/test', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'invoice.write', { companyId, agencyId: null })) throw forbidden();
    if (!company.einvoiceApiUrl || !company.einvoiceApiToken) throw badRequest('Renseignez l’adresse de la plateforme et le jeton d’accès');
    try {
      await testPlatform({ url: company.einvoiceApiUrl, token: company.einvoiceApiToken });
    } catch (e) {
      throw badRequest((e as Error).message);
    }
    return { ok: true };
  });

  /**
   * Liens dans le menu vers les outils en ligne de la société (signature électronique, banque, comptabilité…).
   * Ouverts dans un onglet à part : ces sites refusent d'être affichés à l'intérieur d'Itinéos.
   */
  app.put('/org/companies/:companyId/menu-links', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'org.write', { companyId })) throw forbidden();
    const { links } = z.object({
      links: z.array(z.object({
        label: z.string().trim().min(1, 'Nom du lien obligatoire').max(40),
        // https seulement (http accepté pour un outil du réseau du bureau) : jamais javascript:, data:…
        url: z.string().trim().max(500).url('Adresse du lien invalide').refine((u) => /^https?:\/\//i.test(u), 'L’adresse commence par https://'),
      })).max(10),
    }).parse(req.body);
    const [updated] = await db.update(schema.companies).set({ menuLinks: links }).where(eq(schema.companies.id, companyId)).returning();
    await audit(p, 'update', 'company.menuLinks', companyId, { links });
    return publicCompany(updated);
  });

  /** Logo de la société (PNG ou JPEG, 1 Mo au maximum) : écrans, espace client, en-tête des PDF */
  app.put('/org/companies/:companyId/logo', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'org.write', { companyId })) throw forbidden();
    const { image } = z.object({ image: z.string().max(2_000_000) }).parse(req.body);
    const logo = parseLogoDataUrl(image);
    if (!logo) throw badRequest('Logo illisible : image PNG ou JPEG de 1 Mo au maximum');
    const logoPath = await storeLogo(companyId, logo.ext, logo.buffer);
    const [updated] = await db.update(schema.companies).set({ logoPath, logoUpdatedAt: new Date() })
      .where(eq(schema.companies.id, companyId)).returning({ logoUpdatedAt: schema.companies.logoUpdatedAt });
    await audit(p, 'update', 'company.logo', companyId, { bytes: logo.buffer.length });
    return updated;
  });

  app.delete('/org/companies/:companyId/logo', async (req, reply) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'org.write', { companyId })) throw forbidden();
    await removeLogo(company.logoPath);
    await db.update(schema.companies).set({ logoPath: null, logoUpdatedAt: null }).where(eq(schema.companies.id, companyId));
    await audit(p, 'delete', 'company.logo', companyId, {});
    return reply.code(204).send();
  });

  /** Nouvelle agence dans une société */
  app.post('/org/companies/:companyId/agencies', async (req, reply) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'org.write', { companyId })) throw forbidden();
    const body = agencyBody.parse(req.body);
    const [agency] = await db.insert(schema.agencies).values({ ...body, companyId }).returning();
    await audit(p, 'create', 'agency', agency.id, { name: agency.name });
    return reply.code(201).send(agency);
  });

  /** Nouvelle équipe dans une agence */
  app.post('/org/agencies/:agencyId/teams', async (req, reply) => {
    const p = req.principal;
    const { agencyId } = z.object({ agencyId: z.string().uuid() }).parse(req.params);
    const agency = await db.query.agencies.findFirst({ where: (a, { eq }) => eq(a.id, agencyId) });
    if (!agency) throw notFound('Agence');
    const company = await getCompany(p.groupId, agency.companyId);
    if (!company) throw notFound('Agence');
    if (!can(p, 'user.write', { companyId: company.id, agencyId })) throw forbidden();
    const { name } = z.object({ name: z.string().min(1) }).parse(req.body);
    const [team] = await db.insert(schema.teams).values({ agencyId, name }).returning();
    return reply.code(201).send(team);
  });
}
