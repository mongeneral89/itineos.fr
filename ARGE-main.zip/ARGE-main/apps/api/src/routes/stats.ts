/** Statistiques à la carte (droit « stats.read ») ; voir services/stats.ts */
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { canSomewhere } from '../auth/access.js';
import { badRequest, forbidden } from '../http.js';
import { computeStats, dimensionsFor, readableSources, sourceOf, STAT_DIMENSIONS, STAT_MEASURES } from '../services/stats.js';

const day = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const query = z.object({
  measures: z.string().transform((s) => s.split(',').filter(Boolean)).pipe(z.array(z.enum(STAT_MEASURES)).min(1, 'Choisissez au moins un indicateur').max(6)),
  by: z.enum(STAT_DIMENSIONS).default('technician'),
  by2: z.enum(STAT_DIMENSIONS).optional(),
  from: day,
  to: day,
  tz: z.string().max(64).regex(/^[A-Za-z_]+(\/[A-Za-z0-9_+-]+)*$/).default('Europe/Paris'),
  companyId: z.string().uuid().optional(),
  agencyId: z.string().uuid().optional(),
  technicianId: z.string().uuid().optional(),
  clientId: z.string().uuid().optional(),
  kind: z.string().max(30).optional(),
  priority: z.string().max(30).optional(),
});

export async function statsRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Ce que la personne peut choisir : sources lisibles et critères de chacune */
  app.get('/stats/options', async (req) => {
    const p = req.principal;
    if (!canSomewhere(p, 'stats.read')) throw forbidden();
    const sources = readableSources(p);
    return {
      sources,
      measures: STAT_MEASURES.filter((m) => sources.includes(sourceOf(m))),
      dimensions: Object.fromEntries(sources.map((s) => [s, dimensionsFor(s)])),
    };
  });

  app.get('/stats', async (req) => {
    const p = req.principal;
    if (!canSomewhere(p, 'stats.read')) throw forbidden();
    const q = query.parse(req.query);
    if (q.from > q.to) throw badRequest('La date de début est après la date de fin');
    if (q.by2 && (q.by2 === q.by || q.by2 === 'all')) throw badRequest('Choisissez deux critères différents');
    if (q.by2 && q.measures.length > 1) throw badRequest('Avec deux critères, choisissez un seul indicateur');
    const readable = readableSources(p);
    for (const m of q.measures) {
      const s = sourceOf(m);
      if (!readable.includes(s)) throw forbidden();
      if (!dimensionsFor(s).includes(q.by) || (q.by2 && !dimensionsFor(s).includes(q.by2))) {
        throw badRequest('Ce regroupement n’est pas possible pour cet indicateur');
      }
    }
    // Pas plus de 3 ans d'un coup : le calcul reste rapide
    const days = (Date.parse(q.to) - Date.parse(q.from)) / 86_400_000;
    if (days > 366 * 3) throw badRequest('Période trop longue : 3 ans au maximum');
    const { measures, by, by2, ...filters } = q;
    return computeStats(p, measures, by, by2 ?? null, filters);
  });
}
