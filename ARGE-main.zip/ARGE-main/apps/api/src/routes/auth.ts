import type { FastifyInstance, FastifyReply } from 'fastify';
import { and, eq, gt, sql } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { ROLE_LABELS, ROLE_PERMISSIONS, UI_LOCALES } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { badRequest, HttpError } from '../http.js';
import { visibleOrg } from '../services/org.js';
import { audit } from '../services/audit.js';
import { sendMail } from '../services/mail.js';
import {
  createResetToken, hashResetToken, newPassword, passwordMatches, resetLink, resetMail, RESET_COOLDOWN_MS, RESET_TTL_MS,
} from '../services/password.js';
import { forgotByIp, loginAttempts, passwordChangeByUser, tooManyMessage } from '../services/rate-limit.js';
import type { Principal } from '../auth/access.js';
import { loadPrincipal, signSession } from '../auth/plugin.js';

export async function buildMe(p: Principal) {
  const [user] = await db
    .select({
      id: schema.users.id,
      email: schema.users.email,
      firstName: schema.users.firstName,
      lastName: schema.users.lastName,
      locale: schema.users.locale,
      skills: schema.users.skills,
      phone: schema.users.phone,
    })
    .from(schema.users)
    .where(eq(schema.users.id, p.userId));
  const permissions = [...new Set(p.assignments.flatMap((a) => ROLE_PERMISSIONS[a.role]))];
  return {
    user,
    assignments: p.assignments.map((a) => ({ ...a, label: ROLE_LABELS[a.role] })),
    permissions,
    org: await visibleOrg(p),
  };
}

export async function authRoutes(app: FastifyInstance) {
  app.post('/auth/login', async (req, reply) => {
    const body = z.object({ email: z.string().email(), password: z.string().min(1), remember: z.boolean().default(false) }).parse(req.body);
    const account = body.email.toLowerCase();
    // Adresse bloquée (pour ce compte ou pour tous) : refus AVANT de vérifier le mot de passe (même s'il est bon)
    throwIfBlocked(reply, ...loginAttempts.check(account, req.ip));

    const [user] = await db
      .select()
      .from(schema.users)
      .where(eq(sql`lower(${schema.users.email})`, account));
    // Même message et même temps de réponse dans tous les cas : on ne révèle pas si le compte existe
    const matches = await passwordMatches(body.password, user?.passwordHash);
    if (!matches || !user.active) {
      if (loginAttempts.fail(account, req.ip) && user) {
        await audit(principalOf(user), 'login.blocked', 'user', user.id, { ip: req.ip });
      }
      throw new HttpError(401, 'E-mail ou mot de passe incorrect');
    }
    loginAttempts.succeed(account, req.ip);
    const token = signSession(app, user, body.remember);
    const p = await loadPrincipal(user.id, user.groupId);
    return { token, me: await buildMe(p!) };
  });

  app.get('/me', { preHandler: app.authenticate }, async (req) => buildMe(req.principal));

  /** « Rester connecté » : la session repart pour un an à chaque ouverture de l'appli */
  app.post('/auth/refresh', { preHandler: app.authenticate }, async (req) => {
    if (!req.user.rem) return { token: null };
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, req.principal.userId));
    return { token: signSession(app, user, true) };
  });

  /** Ferme les sessions de tous les autres appareils ; celui-ci reçoit une nouvelle session */
  app.post('/auth/logout-all', { preHandler: app.authenticate }, async (req) => {
    const p = req.principal;
    const now = new Date();
    const [user] = await db.update(schema.users).set({ sessionsRevokedAt: now }).where(eq(schema.users.id, p.userId)).returning();
    await audit(p, 'logout.all', 'user', p.userId);
    return { token: signSession(app, user, !!req.user.rem) };
  });

  /** Langue de l'interface choisie par l'utilisateur (bureau, appli terrain, e-mails qui lui sont adressés) */
  app.patch('/me', { preHandler: app.authenticate }, async (req) => {
    // Langue de l'interface et numéro de téléphone (affiché dans l'annuaire)
    const body = z.object({
      locale: z.enum(UI_LOCALES).optional(),
      phone: z.string().trim().max(40).nullable().optional().transform((s) => (s === undefined ? undefined : s || null)),
    }).parse(req.body);
    if (body.locale !== undefined || body.phone !== undefined) {
      await db.update(schema.users).set(body).where(eq(schema.users.id, req.principal.userId));
    }
    return buildMe(req.principal);
  });

  /**
   * Mot de passe oublié : envoie un lien par e-mail.
   * Répond toujours pareil, que le compte existe ou non, pour ne rien révéler.
   */
  app.post('/auth/forgot', async (req, reply) => {
    const body = z.object({ email: z.string().email() }).parse(req.body);
    throwIfBlocked(reply, forgotByIp.check(req.ip));
    forgotByIp.hit(req.ip);
    const [user] = await db
      .select()
      .from(schema.users)
      .where(eq(sql`lower(${schema.users.email})`, body.email.toLowerCase()));

    if (user && user.active) {
      const [recent] = await db
        .select({ id: schema.passwordResets.id })
        .from(schema.passwordResets)
        .where(and(
          eq(schema.passwordResets.userId, user.id),
          gt(schema.passwordResets.createdAt, new Date(Date.now() - RESET_COOLDOWN_MS)),
        ));
      if (!recent) {
        const { token, tokenHash } = createResetToken();
        // Un seul lien valable à la fois : les précédents sont annulés
        await db.delete(schema.passwordResets).where(eq(schema.passwordResets.userId, user.id));
        await db.insert(schema.passwordResets).values({
          userId: user.id,
          tokenHash,
          expiresAt: new Date(Date.now() + RESET_TTL_MS),
        });
        const mail = resetMail(user.locale, user.firstName, resetLink(token));
        // Envoi sans attendre : le temps de réponse ne trahit pas l'existence du compte
        void sendMail({ to: [user.email], ...mail }).catch((err) => req.log.error(err, 'envoi du lien de réinitialisation'));
        await audit(principalOf(user), 'password.reset.request', 'user', user.id);
      }
    }
    return reply.code(204).send();
  });

  /** Nouveau mot de passe à partir du lien reçu par e-mail */
  app.post('/auth/reset', async (req, reply) => {
    const body = z.object({ token: z.string().min(1), password: newPassword }).parse(req.body);
    const pr = schema.passwordResets;
    const [row] = await db
      .select({ id: pr.id, userId: pr.userId, expiresAt: pr.expiresAt, usedAt: pr.usedAt })
      .from(pr)
      .where(eq(pr.tokenHash, hashResetToken(body.token)));
    const [user] = row
      ? await db.select().from(schema.users).where(eq(schema.users.id, row.userId))
      : [];
    if (!row || row.usedAt || row.expiresAt < new Date() || !user || !user.active) {
      throw badRequest('Ce lien est invalide ou a expiré. Demandez-en un nouveau.');
    }

    await db.transaction(async (tx) => {
      await tx.update(schema.users)
        .set({ passwordHash: await bcrypt.hash(body.password, 10), passwordChangedAt: new Date() })
        .where(eq(schema.users.id, user.id));
      await tx.delete(pr).where(eq(pr.userId, user.id));
    });
    await audit(principalOf(user), 'password.reset', 'user', user.id);
    return reply.code(204).send();
  });

  /** Changement de mot de passe par l'utilisateur connecté : renvoie une nouvelle session */
  app.post('/auth/change-password', { preHandler: app.authenticate }, async (req, reply) => {
    const p = req.principal;
    const body = z.object({ currentPassword: z.string().min(1), newPassword }).parse(req.body);
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, p.userId));
    // Essais comptés : une session volée ne permet pas d'essayer des mots de passe à l'infini
    throwIfBlocked(reply, passwordChangeByUser.check(user.id));
    if (!(await bcrypt.compare(body.currentPassword, user.passwordHash))) {
      passwordChangeByUser.hit(user.id);
      throw badRequest('Mot de passe actuel incorrect');
    }
    passwordChangeByUser.reset(user.id);
    if (body.currentPassword === body.newPassword) {
      throw badRequest("Le nouveau mot de passe doit être différent de l'ancien");
    }

    const changedAt = new Date();
    await db.transaction(async (tx) => {
      await tx.update(schema.users)
        .set({ passwordHash: await bcrypt.hash(body.newPassword, 10), passwordChangedAt: changedAt })
        .where(eq(schema.users.id, user.id));
      await tx.delete(schema.passwordResets).where(eq(schema.passwordResets.userId, user.id));
    });
    await audit(p, 'password.change', 'user', user.id);
    // Les autres sessions (autres appareils) sont fermées ; celle-ci reçoit un nouveau jeton
    return { token: signSession(app, { ...user, passwordChangedAt: changedAt }, !!req.user.rem) };
  });
}

/** Trop de tentatives : 429, avec le délai d'attente (en-tête Retry-After et message) */
function throwIfBlocked(reply: FastifyReply, ...checks: { blocked: boolean; retryAfterMs: number }[]) {
  const wait = Math.max(0, ...checks.filter((c) => c.blocked).map((c) => c.retryAfterMs));
  if (!checks.some((c) => c.blocked)) return;
  reply.header('Retry-After', String(Math.ceil(wait / 1000)));
  throw new HttpError(429, tooManyMessage(wait));
}

/** Pour tracer une action faite sans être connecté (lien reçu par e-mail) */
function principalOf(user: { id: string; groupId: string }): Principal {
  return { userId: user.id, groupId: user.groupId, assignments: [] };
}
