/**
 * Cartes SIM (transmetteurs d'alarme, routeurs…) : inventaire et suivi de l'activation.
 *
 * L'activation elle-même se fait sur le site du prestataire : Itinéos garde la liste des cartes, leur client,
 * leur état (en stock → à activer → demandée → active…) et ouvre le site du prestataire, dont le lien est
 * réglé par société. Une liaison automatique avec le prestataire pourra s'ajouter plus tard.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, eq, inArray, isNull, or } from 'drizzle-orm';
import { z } from 'zod';
import { SIM_STATUSES, type SimStatus } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, isEmptyScope, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';

const sc = schema.simCards;

/** « 8933 1234… » et « 89331234… » sont le même numéro de carte */
export const normalizeIccid = (s: string) => s.replace(/[\s.-]/g, '');
const ICCID = /^\d{18,22}$/;

const opt = (max: number) => z.string().trim().max(max).optional().nullable().transform((s) => (s ? s : null));
const simBody = z.object({
  agencyId: z.string().uuid().nullable().optional(),
  iccid: z.string().transform(normalizeIccid).refine((s) => ICCID.test(s), 'Numéro de carte (ICCID) invalide : 18 à 22 chiffres'),
  phoneNumber: opt(30),
  operator: opt(60),
  plan: opt(120),
  clientId: z.string().uuid().nullable().optional(),
  siteId: z.string().uuid().nullable().optional(),
  device: opt(120),
  notes: opt(2000),
});

async function loadSim(p: Principal, id: string, perm: 'sim.read' | 'sim.write') {
  const [row] = await db.select().from(sc).where(and(eq(sc.id, id), eq(sc.groupId, p.groupId)));
  if (!row) throw notFound('Carte SIM');
  if (!can(p, perm, { companyId: row.companyId, agencyId: row.agencyId }, { sharedVisible: true })) throw forbidden();
  return row;
}

async function checkRefs(companyId: string, b: { agencyId?: string | null; clientId?: string | null; siteId?: string | null }) {
  if (b.agencyId && !(await getAgency(companyId, b.agencyId))) throw badRequest('Agence inconnue');
  if (b.clientId) {
    const [c] = await db.select({ companyId: schema.clients.companyId }).from(schema.clients).where(eq(schema.clients.id, b.clientId));
    if (!c || c.companyId !== companyId) throw badRequest('Client inconnu');
  }
  if (b.siteId) {
    const [s] = await db.select({ clientId: schema.sites.clientId }).from(schema.sites).where(eq(schema.sites.id, b.siteId));
    if (!s || (b.clientId && s.clientId !== b.clientId)) throw badRequest('Site inconnu');
  }
}

/** Dates tenues à jour quand l'état change */
function statusDates(status: SimStatus, now = new Date()) {
  if (status === 'REQUESTED') return { requestedAt: now };
  if (status === 'ACTIVE') return { activatedAt: now, terminatedAt: null };
  if (status === 'TERMINATED') return { terminatedAt: now };
  return {};
}

export async function simRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Les cartes d'une société (et le lien du prestataire) */
  app.get('/sims', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), agencyId: z.string().uuid().optional() }).parse(req.query);
    const company = await getCompany(p.groupId, f.companyId);
    if (!company) throw notFound('Société');
    if (isEmptyScope(scopeFor(p, 'sim.read'))) throw forbidden();
    const rows = await db.select({
      sim: sc, clientName: schema.clients.name, siteName: schema.sites.name, siteCity: schema.sites.city,
    }).from(sc)
      .leftJoin(schema.clients, eq(schema.clients.id, sc.clientId))
      .leftJoin(schema.sites, eq(schema.sites.id, sc.siteId))
      .where(and(
        eq(sc.companyId, company.id),
        scopeWhere(scopeFor(p, 'sim.read'), { companyId: sc.companyId, agencyId: sc.agencyId }, { sharedVisible: true }),
        f.agencyId ? or(eq(sc.agencyId, f.agencyId), isNull(sc.agencyId)) : undefined,
      ))
      .orderBy(asc(sc.status), asc(sc.iccid));
    return {
      provider: company.simProvider ?? null,
      portalUrl: company.simPortalUrl ?? null,
      canWrite: can(p, 'sim.write', { companyId: company.id }, { sharedVisible: true }),
      cards: rows.map((r) => ({ ...r.sim, clientName: r.clientName, siteName: r.siteName, siteCity: r.siteCity })),
    };
  });

  /** Prestataire et lien de son site (réglage de la société) */
  app.patch('/sims/settings', async (req) => {
    const p = req.principal;
    const b = z.object({
      companyId: z.string().uuid(),
      provider: opt(120),
      portalUrl: z.string().trim().max(500).optional().nullable()
        .transform((s) => (s ? (/^https?:\/\//i.test(s) ? s : `https://${s}`) : null))
        .refine((s) => !s || /^https?:\/\/[^\s]+$/i.test(s), 'Lien invalide'),
    }).parse(req.body);
    const company = await getCompany(p.groupId, b.companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'sim.write', { companyId: company.id })) throw forbidden();
    await db.update(schema.companies).set({ simProvider: b.provider, simPortalUrl: b.portalUrl }).where(eq(schema.companies.id, company.id));
    await audit(p, 'update', 'sim_settings', company.id, { provider: b.provider });
    return { provider: b.provider, portalUrl: b.portalUrl };
  });

  app.post('/sims', async (req, reply) => {
    const p = req.principal;
    const b = simBody.extend({ companyId: z.string().uuid(), status: z.enum(SIM_STATUSES).default('STOCK') }).parse(req.body);
    const company = await getCompany(p.groupId, b.companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'sim.write', { companyId: company.id, agencyId: b.agencyId ?? null }, { sharedVisible: true })) throw forbidden();
    await checkRefs(company.id, b);
    const [dup] = await db.select({ id: sc.id }).from(sc).where(and(eq(sc.groupId, p.groupId), eq(sc.iccid, b.iccid)));
    if (dup) throw conflict('Cette carte SIM est déjà enregistrée');
    const [row] = await db.insert(sc).values({
      ...b, groupId: p.groupId, companyId: company.id, agencyId: b.agencyId ?? null, createdBy: p.userId, ...statusDates(b.status),
    }).returning();
    await audit(p, 'create', 'sim_card', row.id, { iccid: row.iccid });
    return reply.code(201).send(row);
  });

  /** Ajout en lot : une carte par ligne (numéro seul, ou « numéro ; téléphone ») ; les doublons sont ignorés */
  app.post('/sims/import', async (req) => {
    const p = req.principal;
    const b = z.object({
      companyId: z.string().uuid(),
      agencyId: z.string().uuid().nullable().optional(),
      operator: opt(60),
      plan: opt(120),
      lines: z.string().max(200_000),
    }).parse(req.body);
    const company = await getCompany(p.groupId, b.companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'sim.write', { companyId: company.id, agencyId: b.agencyId ?? null }, { sharedVisible: true })) throw forbidden();
    await checkRefs(company.id, b);
    const invalid: string[] = [];
    const wanted = new Map<string, string | null>();
    for (const raw of b.lines.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;
      const [first, second] = line.split(/[;,\t]/).map((x) => x.trim());
      const iccid = normalizeIccid(first ?? '');
      if (!ICCID.test(iccid)) {
        invalid.push(line.slice(0, 40));
        continue;
      }
      wanted.set(iccid, second || null);
    }
    if (wanted.size > 2000) throw badRequest('2 000 cartes au plus par ajout');
    const existing = wanted.size
      ? new Set((await db.select({ iccid: sc.iccid }).from(sc).where(and(eq(sc.groupId, p.groupId), inArray(sc.iccid, [...wanted.keys()])))).map((r) => r.iccid))
      : new Set<string>();
    const fresh = [...wanted].filter(([iccid]) => !existing.has(iccid));
    if (fresh.length) {
      await db.insert(sc).values(fresh.map(([iccid, phoneNumber]) => ({
        groupId: p.groupId, companyId: company.id, agencyId: b.agencyId ?? null, iccid, phoneNumber,
        operator: b.operator, plan: b.plan, createdBy: p.userId,
      })));
      await audit(p, 'import', 'sim_card', null, { count: fresh.length });
    }
    return { created: fresh.length, duplicates: wanted.size - fresh.length, invalid };
  });

  app.patch('/sims/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadSim(p, id, 'sim.write');
    const b = simBody.parse(req.body);
    if (b.agencyId !== undefined && !can(p, 'sim.write', { companyId: current.companyId, agencyId: b.agencyId }, { sharedVisible: true })) throw forbidden();
    await checkRefs(current.companyId, b);
    if (b.iccid !== current.iccid) {
      const [dup] = await db.select({ id: sc.id }).from(sc).where(and(eq(sc.groupId, p.groupId), eq(sc.iccid, b.iccid)));
      if (dup) throw conflict('Cette carte SIM est déjà enregistrée');
    }
    const [row] = await db.update(sc).set({ ...b, updatedAt: new Date() }).where(eq(sc.id, id)).returning();
    await audit(p, 'update', 'sim_card', id, { iccid: row.iccid });
    return row;
  });

  /** Changer l'état (après l'avoir fait sur le site du prestataire) */
  app.post('/sims/:id/status', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { status } = z.object({ status: z.enum(SIM_STATUSES) }).parse(req.body);
    const current = await loadSim(p, id, 'sim.write');
    const [row] = await db.update(sc).set({ status, ...statusDates(status), updatedAt: new Date() }).where(eq(sc.id, id)).returning();
    await audit(p, 'status', 'sim_card', id, { iccid: current.iccid, from: current.status, to: status });
    return row;
  });

  app.delete('/sims/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadSim(p, id, 'sim.write');
    await db.delete(sc).where(eq(sc.id, id));
    await audit(p, 'delete', 'sim_card', id, { iccid: current.iccid });
    return reply.code(204).send();
  });
}
