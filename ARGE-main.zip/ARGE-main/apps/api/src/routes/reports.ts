/**
 * Fiches d'intervention : pré-remplissage, saisie, signatures, PDF et envoi au client.
 *
 * Cycle d'une fiche : DRAFT (en cours de saisie) → SIGNED (signée, figée) → SENT (PDF archivé et envoyé)
 */
import { clientLocale, docTexts } from '../services/doc-i18n.js';
import type { FastifyInstance } from 'fastify';
import { and, asc, count, desc, eq, inArray, ne } from 'drizzle-orm';
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import {
  featureEnabled, MAX_PHOTOS_PER_REPORT, missingRequiredFields, OUTCOMES, PHOTO_KINDS, type ReportData, type TemplateSchema,
} from '@itineo/shared';
import { createHash } from 'node:crypto';
import { findCheckinReport, siteCheckpoints } from '../services/sector-features.js';
import { companyLogo } from '../services/logo.js';
import { db, schema } from '../db/client.js';
import { env } from '../env.js';
import { canWriteReport, type Principal } from '../auth/access.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { loadIntervention } from './interventions.js';
import { EXTRA_NAMES, pickTemplate } from '../services/templates.js';
import { buildPrefill, oneLineAddress } from '../services/prefill.js';
import { generateReportPdf } from '../services/pdf.js';
import { sendMail } from '../services/mail.js';
import { audit } from '../services/audit.js';
import { notifyCompleted } from '../services/office-notify.js';
import { deviceTime } from '../services/device-time.js';
import { consumeReportParts } from '../services/stock.js';
import { parsePhotoDataUrl, readPhoto, removePhotoFile, storePhoto } from '../services/photos.js';

type Intervention = Awaited<ReturnType<typeof loadIntervention>>;

/** Tout ce qu'il faut savoir autour d'une intervention pour remplir et éditer sa fiche */
async function loadContext(iv: Intervention) {
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, iv.companyId));
  const [agency] = await db.select().from(schema.agencies).where(eq(schema.agencies.id, iv.agencyId));
  const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, iv.clientId));
  const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, iv.siteId));
  const [equipment] = iv.equipmentId
    ? await db.select().from(schema.equipments).where(eq(schema.equipments.id, iv.equipmentId))
    : [null];
  const [technician] = iv.technicianId
    ? await db
        .select({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName })
        .from(schema.users)
        .where(eq(schema.users.id, iv.technicianId))
    : [null];
  return { company, agency, client, site, equipment: equipment ?? null, technician: technician ?? null };
}

type Context = Awaited<ReturnType<typeof loadContext>>;

function prefillContext(iv: Intervention, ctx: Context) {
  return {
    intervention: { number: iv.number, reason: iv.reason, kind: iv.kind, priority: iv.priority },
    client: {
      ...ctx.client,
      fullAddress: oneLineAddress(ctx.client.address, ctx.client.postalCode, ctx.client.city),
    },
    site: { ...ctx.site, fullAddress: oneLineAddress(ctx.site.address, ctx.site.postalCode, ctx.site.city) },
    equipment: ctx.equipment,
    technician: ctx.technician
      ? { ...ctx.technician, fullName: `${ctx.technician.firstName} ${ctx.technician.lastName}` }
      : null,
    company: { name: ctx.company.name },
  };
}

/** Résumé des dernières fiches sur le même matériel (ou, à défaut, le même site) */
async function loadHistory(iv: Intervention) {
  const i = schema.interventions;
  const r = schema.reports;
  const rows = await db
    .select({
      number: i.number, kind: i.kind, reason: i.reason, outcome: r.outcome,
      date: r.signedAt, data: r.data,
    })
    .from(r)
    .innerJoin(i, eq(i.id, r.interventionId))
    .where(and(
      iv.equipmentId ? eq(i.equipmentId, iv.equipmentId) : eq(i.siteId, iv.siteId),
      ne(i.id, iv.id),
      inArray(r.status, ['SIGNED', 'SENT']),
    ))
    .orderBy(desc(r.signedAt))
    .limit(5);
  return rows.map(({ data, ...h }) => ({
    ...h,
    summary: String(data.work ?? data.cause ?? data.request ?? h.reason ?? '').slice(0, 280),
  }));
}

async function getReport(interventionId: string) {
  const [report] = await db.select().from(schema.reports).where(eq(schema.reports.interventionId, interventionId));
  if (!report) return null;
  const parts = await db.select().from(schema.reportParts).where(eq(schema.reportParts.reportId, report.id));
  return { report, parts };
}

const photoColumns = {
  id: schema.reportPhotos.id,
  clientId: schema.reportPhotos.clientId,
  kind: schema.reportPhotos.kind,
  caption: schema.reportPhotos.caption,
  createdAt: schema.reportPhotos.createdAt,
};

/** Photos d'une fiche, dans l'ordre de prise de vue */
function listPhotos(reportId: string) {
  return db.select(photoColumns).from(schema.reportPhotos)
    .where(eq(schema.reportPhotos.reportId, reportId))
    .orderBy(asc(schema.reportPhotos.createdAt));
}

/** Ne garde que les champs prévus par le modèle */
function sanitizeData(schemaDef: TemplateSchema, data: ReportData): ReportData {
  const allowed = new Set(schemaDef.sections.flatMap((s) => s.fields.map((f) => f.id)));
  return Object.fromEntries(Object.entries(data).filter(([k]) => allowed.has(k)));
}

const dataValue = z.union([z.string().max(20000), z.number(), z.boolean(), z.array(z.string()), z.null()]);
const signature = z
  .string()
  .regex(/^data:image\/(png|jpeg);base64,/, 'Signature invalide')
  .max(700_000, 'Signature trop lourde');

async function buildPdf(iv: Intervention, ctx: Context, report: typeof schema.reports.$inferSelect, parts: (typeof schema.reportParts.$inferSelect)[]) {
  const photoRows = await db.select().from(schema.reportPhotos)
    .where(eq(schema.reportPhotos.reportId, report.id))
    .orderBy(asc(schema.reportPhotos.createdAt));
  const photos = [];
  for (const ph of photoRows) {
    const image = await readPhoto(ph.filePath);
    if (image) photos.push({ kind: ph.kind, caption: ph.caption, image, takenAt: ph.takenAt ?? ph.createdAt, sha256: ph.sha256 });
  }
  const [tpl] = await db.select({ name: schema.formTemplates.name, sector: schema.formTemplates.sector }).from(schema.formTemplates).where(eq(schema.formTemplates.id, report.templateId));
  const sector = ctx.company.sector;
  const feature = (f: Parameters<typeof featureEnabled>[1]) => featureEnabled(sector, f);
  // Le document porte le nom du modèle : document particulier, modèle du métier (« Rapport de ronde »),
  // ou document choisi exprès sur l'intervention (« Consignes de télésurveillance (Teles) » d'une société)
  const named = tpl && (EXTRA_NAMES.has(tpl.name) || (sector !== 'TECH' && tpl.sector === sector) || iv.templateId === report.templateId);
  // Itinéos Vigie : chaque point du site, pointé ou non
  const checkpoints = feature('checkpoints') && iv.kind === 'MAINTENANCE'
    ? (await siteCheckpoints(iv.siteId)).map((cp) => {
      const scan = report.checkpointScans.find((s) => s.checkpointId === cp.id);
      return { name: cp.name, at: scan ? new Date(scan.at) : null };
    })
    : [];
  // Itinéos Clés : différences avec l'état des lieux d'entrée
  const checkin = feature('checkinComparison') && iv.kind === 'SAV' ? await findCheckinReport(iv) : null;
  const comparison = checkin ? {
    number: checkin.number,
    date: checkin.signedAt,
    fields: report.templateSchema.sections.flatMap((s) => s.fields)
      .filter((f) => f.type !== 'checklist' && checkin.schema.sections.some((s) => s.fields.some((x) => x.id === f.id)))
      .map((f) => ({ label: f.label, before: checkin.data[f.id] ?? null, after: report.data[f.id] ?? null })),
  } : null;
  return generateReportPdf({
    ...(named ? { title: tpl.name.toLocaleUpperCase(ctx.company.locale) } : {}),
    sector,
    place: ctx.site.city,
    checkpoints,
    comparison,
    photoProof: feature('photoProof'),
    photos,
    locale: clientLocale(ctx.client, ctx.company),
    timezone: ctx.company.timezone,
    company: { ...ctx.company, logo: await companyLogo(ctx.company) },
    agency: ctx.agency,
    intervention: { number: iv.number, kind: iv.kind, reason: iv.reason },
    client: {
      name: ctx.client.name,
      address: oneLineAddress(ctx.client.address, ctx.client.postalCode, ctx.client.city),
      phone: ctx.client.phone,
      email: ctx.client.email,
    },
    site: { name: ctx.site.name, address: oneLineAddress(ctx.site.address, ctx.site.postalCode, ctx.site.city) },
    technicianName: ctx.technician ? `${ctx.technician.firstName} ${ctx.technician.lastName}` : '—',
    report: {
      schema: report.templateSchema,
      data: report.data,
      arrivedAt: report.arrivedAt,
      leftAt: report.leftAt,
      laborMinutes: report.laborMinutes,
      travelMinutes: report.travelMinutes,
      outcome: report.outcome,
      technicianSignature: report.technicianSignature,
      clientSignature: report.clientSignature,
      clientSignerName: report.clientSignerName,
      clientAbsent: report.clientAbsent,
      clientAbsentReason: report.clientAbsentReason,
      signedAt: report.signedAt,
    },
    parts: parts.map((p) => ({ label: p.label, reference: p.reference, quantity: p.quantity })),
  });
}

async function writableReport(p: Principal, interventionId: string) {
  const iv = await loadIntervention(p, interventionId);
  if (!canWriteReport(p, iv)) throw forbidden();
  const found = await getReport(iv.id);
  if (!found) throw notFound('Fiche');
  return { iv, ...found };
}

export async function reportRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Ouvre la fiche : la crée pré-remplie si elle n'existe pas encore */
  app.get('/interventions/:id/report', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const iv = await loadIntervention(p, id);
    const ctx = await loadContext(iv);
    const canEdit = canWriteReport(p, iv);

    let found = await getReport(iv.id);
    if (!found && canEdit) {
      const template = await pickTemplate(ctx.company, iv.kind, iv.templateId);
      if (!template) throw badRequest('Aucun modèle de fiche disponible pour ce type d’intervention');
      await db
        .insert(schema.reports)
        .values({
          interventionId: iv.id,
          templateId: template.id,
          templateSchema: template.schema,
          data: buildPrefill(template.schema, prefillContext(iv, ctx)),
          arrivedAt: iv.status === 'ON_SITE' ? new Date() : null,
        })
        .onConflictDoNothing(); // deux ouvertures simultanées : une seule fiche
      found = await getReport(iv.id);
    }

    return {
      intervention: iv,
      report: found?.report ?? null,
      parts: found?.parts ?? [],
      canEdit: canEdit && (found?.report.status ?? 'DRAFT') === 'DRAFT',
      context: {
        company: { id: ctx.company.id, name: ctx.company.name, locale: ctx.company.locale, timezone: ctx.company.timezone, currency: ctx.company.currency },
        agency: { id: ctx.agency.id, name: ctx.agency.name, officeEmail: ctx.agency.email ?? ctx.company.email ?? null },
        client: ctx.client,
        site: ctx.site,
        equipment: ctx.equipment,
        technician: ctx.technician,
        // Matériel du site difficile à trouver : montré en évidence au technicien
        siteHints: (await db.select({ id: schema.equipments.id, category: schema.equipments.category, location: schema.equipments.location, locateHint: schema.equipments.locateHint })
          .from(schema.equipments).where(eq(schema.equipments.siteId, iv.siteId))).filter((e) => e.locateHint),
      },
      history: await loadHistory(iv),
      photos: found ? await listPhotos(found.report.id) : [],
      // Itinéos Vigie : points de passage à pointer pendant la ronde (gardés sur l'appareil pour pointer sans réseau)
      checkpoints: featureEnabled(ctx.company.sector, 'checkpoints') ? await siteCheckpoints(iv.siteId) : [],
      // Itinéos Clés : l'état des lieux d'entrée, montré à côté de chaque point pendant la sortie
      checkin: featureEnabled(ctx.company.sector, 'checkinComparison') && iv.kind === 'SAV' ? await findCheckinReport(iv) : null,
    };
  });

  /**
   * Ajoute une photo à la fiche (image déjà réduite par l'appareil).
   * Rejouer la même requête (même clientId) renvoie la photo déjà enregistrée.
   */
  app.post('/interventions/:id/report/photos', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { iv, report } = await writableReport(p, id);
    const body = z.object({
      clientId: z.string().uuid(),
      kind: z.enum(PHOTO_KINDS),
      caption: z.string().trim().max(200).optional(),
      image: z.string().max(5_000_000),
      // Heure de prise de vue sur l'appareil
      takenAt: z.coerce.date().optional(),
    }).parse(req.body);

    const [existing] = await db.select(photoColumns).from(schema.reportPhotos)
      .where(and(eq(schema.reportPhotos.reportId, report.id), eq(schema.reportPhotos.clientId, body.clientId)));
    if (existing) return existing;

    if (report.status !== 'DRAFT') throw conflict('La fiche est signée : on ne peut plus ajouter de photo');
    const [{ n }] = await db.select({ n: count() }).from(schema.reportPhotos).where(eq(schema.reportPhotos.reportId, report.id));
    if (n >= MAX_PHOTOS_PER_REPORT) throw badRequest(`${MAX_PHOTOS_PER_REPORT} photos au maximum par fiche`);
    const img = parsePhotoDataUrl(body.image);
    if (!img) throw badRequest('Photo illisible ou trop lourde (JPEG ou PNG, 3 Mo au maximum)');

    const photoId = randomUUID();
    const filePath = await storePhoto(iv.companyId, report.id, photoId, img.ext, img.buffer);
    const [photo] = await db.insert(schema.reportPhotos).values({
      id: photoId,
      reportId: report.id,
      clientId: body.clientId,
      kind: body.kind,
      caption: body.caption || null,
      mimeType: img.mime,
      sizeBytes: img.buffer.length,
      filePath,
      takenAt: body.takenAt ? deviceTime(body.takenAt) : null,
      // Empreinte du fichier tel que reçu : toute retouche ultérieure se verrait
      sha256: createHash('sha256').update(img.buffer).digest('hex'),
      createdBy: p.userId,
    }).onConflictDoNothing().returning(photoColumns);
    if (!photo) {
      // Même photo reçue deux fois en même temps : on garde la première
      await removePhotoFile(filePath);
      const [first] = await db.select(photoColumns).from(schema.reportPhotos)
        .where(and(eq(schema.reportPhotos.reportId, report.id), eq(schema.reportPhotos.clientId, body.clientId)));
      return first;
    }
    return reply.code(201).send(photo);
  });

  /** Modifie la légende d'une photo */
  app.patch('/interventions/:id/report/photos/:photoId', async (req) => {
    const p = req.principal;
    const { id, photoId } = z.object({ id: z.string().uuid(), photoId: z.string().uuid() }).parse(req.params);
    const { report } = await writableReport(p, id);
    if (report.status !== 'DRAFT') throw conflict('La fiche est signée : elle ne peut plus être modifiée');
    const body = z.object({ caption: z.string().trim().max(200) }).parse(req.body);
    const [photo] = await db.update(schema.reportPhotos)
      .set({ caption: body.caption || null })
      .where(and(eq(schema.reportPhotos.id, photoId), eq(schema.reportPhotos.reportId, report.id)))
      .returning(photoColumns);
    if (!photo) throw notFound('Photo');
    return photo;
  });

  /** Supprime une photo (déjà supprimée : réponse identique, pour les renvois après coupure) */
  app.delete('/interventions/:id/report/photos/:photoId', async (req, reply) => {
    const p = req.principal;
    const { id, photoId } = z.object({ id: z.string().uuid(), photoId: z.string().uuid() }).parse(req.params);
    const { report } = await writableReport(p, id);
    if (report.status !== 'DRAFT') throw conflict('La fiche est signée : elle ne peut plus être modifiée');
    const [removed] = await db.delete(schema.reportPhotos)
      .where(and(eq(schema.reportPhotos.id, photoId), eq(schema.reportPhotos.reportId, report.id)))
      .returning({ filePath: schema.reportPhotos.filePath });
    if (removed) await removePhotoFile(removed.filePath);
    return reply.code(204).send();
  });

  /** Image d'une photo (pour toute personne qui peut voir l'intervention) */
  app.get('/interventions/:id/report/photos/:photoId', async (req, reply) => {
    const p = req.principal;
    const { id, photoId } = z.object({ id: z.string().uuid(), photoId: z.string().uuid() }).parse(req.params);
    const iv = await loadIntervention(p, id);
    const [photo] = await db
      .select({ filePath: schema.reportPhotos.filePath, mimeType: schema.reportPhotos.mimeType })
      .from(schema.reportPhotos)
      .innerJoin(schema.reports, eq(schema.reports.id, schema.reportPhotos.reportId))
      .where(and(eq(schema.reportPhotos.id, photoId), eq(schema.reports.interventionId, iv.id)));
    const image = photo ? await readPhoto(photo.filePath) : null;
    if (!photo || !image) throw notFound('Photo');
    return reply.type(photo.mimeType).header('Cache-Control', 'private, max-age=86400').send(image);
  });

  /** Enregistre la saisie (appelé régulièrement pendant que le technicien remplit) */
  app.put('/interventions/:id/report', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { iv, report } = await writableReport(p, id);
    if (report.status !== 'DRAFT') throw conflict('La fiche est signée : elle ne peut plus être modifiée');

    const body = z.object({
      data: z.record(dataValue).optional(),
      arrivedAt: z.coerce.date().nullable().optional(),
      leftAt: z.coerce.date().nullable().optional(),
      laborMinutes: z.number().int().min(0).max(100_000).nullable().optional(),
      travelMinutes: z.number().int().min(0).max(100_000).nullable().optional(),
      outcome: z.enum(OUTCOMES).nullable().optional(),
      parts: z.array(z.object({
        label: z.string().min(1),
        reference: z.string().nullable().optional(),
        quantity: z.number().positive().default(1),
        articleId: z.string().uuid().nullable().optional(),
      })).optional(),
      // Points de passage pointés (heure de l'appareil : pointage fait sans réseau, envoyé plus tard)
      checkpointScans: z.array(z.object({
        checkpointId: z.string().uuid(),
        name: z.string().max(200),
        at: z.coerce.date().transform((d) => deviceTime(d).toISOString()),
      })).max(200).optional(),
    }).parse(req.body);

    const { parts, data, checkpointScans, ...fields } = body;
    // Seuls les points de ce site comptent, sous leur nom actuel ; un point pointé deux fois garde le premier passage
    let scans: typeof report.checkpointScans | undefined;
    if (checkpointScans) {
      const known = new Map((await siteCheckpoints(iv.siteId)).map((cp) => [cp.id, cp.name]));
      scans = [];
      for (const s of checkpointScans) {
        if (known.has(s.checkpointId) && !scans.some((x) => x.checkpointId === s.checkpointId)) {
          scans.push({ checkpointId: s.checkpointId, name: known.get(s.checkpointId)!, at: s.at });
        }
      }
    }
    await db.transaction(async (tx) => {
      await tx
        .update(schema.reports)
        .set({
          ...fields,
          ...(data ? { data: sanitizeData(report.templateSchema, data) } : {}),
          ...(scans ? { checkpointScans: scans } : {}),
          updatedAt: new Date(),
        })
        .where(eq(schema.reports.id, report.id));
      if (parts) {
        await tx.delete(schema.reportParts).where(eq(schema.reportParts.reportId, report.id));
        if (parts.length) {
          await tx.insert(schema.reportParts).values(parts.map((pt) => ({ ...pt, reportId: report.id })));
        }
      }
    });
    return getReport(id);
  });

  /** Signatures : la fiche est figée ensuite */
  app.post('/interventions/:id/report/sign', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { iv, report } = await writableReport(p, id);
    if (report.status !== 'DRAFT') throw conflict('La fiche est déjà signée');

    const body = z.object({
      technicianSignature: signature,
      clientAbsent: z.boolean().default(false),
      clientSignature: signature.optional(),
      clientSignerName: z.string().trim().optional(),
      clientAbsentReason: z.string().trim().optional(),
      // Heure de signature sur l'appareil (signature faite hors connexion, envoyée plus tard)
      signedAt: z.coerce.date().optional(),
    }).parse(req.body);

    const missing = missingRequiredFields(report.templateSchema, report.data);
    if (!report.outcome) missing.push('Résultat de l’intervention');
    if (missing.length) throw badRequest('Champs obligatoires à compléter', { missing });
    if (!body.clientAbsent && (!body.clientSignature || !body.clientSignerName)) {
      throw badRequest('Signature et nom du client obligatoires, ou cochez « client absent »');
    }
    if (body.clientAbsent && !body.clientAbsentReason) {
      throw badRequest("Indiquez pourquoi le client n'a pas pu signer");
    }

    const now = deviceTime(body.signedAt);
    const [signed] = await db
      .update(schema.reports)
      .set({
        technicianSignature: body.technicianSignature,
        clientAbsent: body.clientAbsent,
        clientSignature: body.clientAbsent ? null : body.clientSignature,
        clientSignerName: body.clientAbsent ? null : body.clientSignerName,
        clientAbsentReason: body.clientAbsent ? body.clientAbsentReason : null,
        leftAt: report.leftAt ?? now,
        signedAt: now,
        status: 'SIGNED',
        updatedAt: new Date(),
      })
      .where(and(eq(schema.reports.id, report.id), eq(schema.reports.status, 'DRAFT')))
      .returning();
    if (!signed) throw conflict('La fiche a été signée entre-temps');
    // Pièces posées choisies dans le catalogue : déduites du véhicule du technicien
    const consumed = await consumeReportParts(iv, report.id, p.userId).catch((err) => {
      req.log.error(err, 'déduction du stock à la signature');
      return 0;
    });
    await audit(p, 'sign', 'report', report.id, { clientAbsent: body.clientAbsent, partsConsumed: consumed });
    return { status: signed.status, signedAt: signed.signedAt };
  });

  /** Génère et archive le PDF, l'envoie au client et clôture l'intervention */
  app.post('/interventions/:id/report/send', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { iv, report, parts } = await writableReport(p, id);
    if (report.status === 'DRAFT') throw badRequest("La fiche doit être signée avant l'envoi");
    // Demande rejouée (réponse perdue, renvoi après coupure) : le client ne reçoit pas l'e-mail deux fois
    if (report.status === 'SENT') {
      return { status: 'SENT', sentTo: report.sentTo ? report.sentTo.split(', ') : [], archived: true };
    }

    const body = z.object({
      to: z.array(z.string().email()).optional(),
      sendEmail: z.boolean().default(true),
      // Copie au bureau (adresse de l'agence, sinon de la société)
      copyOffice: z.boolean().default(false),
    }).parse(req.body ?? {});

    const ctx = await loadContext(iv);
    const recipients = body.to?.length ? body.to : ctx.client.email ? [ctx.client.email] : [];
    if (body.sendEmail && !recipients.length) {
      throw badRequest("Le client n'a pas d'adresse e-mail : indiquez-en une, ou archivez sans envoyer");
    }

    const pdf = await buildPdf(iv, ctx, report, parts);
    const dir = path.resolve(env.STORAGE_DIR, 'reports', iv.companyId);
    await mkdir(dir, { recursive: true });
    const pdfPath = path.join(dir, `${iv.number}.pdf`);
    await writeFile(pdfPath, pdf);

    if (body.sendEmail) {
      // Le client répond au technicien, qui reçoit une copie ; le bureau aussi s'il le demande
      const [techUser] = iv.technicianId
        ? await db.select({ email: schema.users.email, firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, iv.technicianId))
        : [];
      const office = body.copyOffice ? ctx.agency.email ?? ctx.company.email : null;
      const bcc = [...new Set([techUser?.email, office].filter((x): x is string => !!x && !recipients.includes(x)))];
      await sendMail({
        to: recipients,
        bcc,
        brand: { name: ctx.company.name, logoPath: ctx.company.logoPath },
        ...(techUser ? { replyTo: { name: `${techUser.firstName} ${techUser.lastName}`, address: techUser.email } } : {}),
        ...docTexts(clientLocale(ctx.client, ctx.company)).reportMail({ company: ctx.company.name, agency: ctx.agency.name, number: iv.number }),
        attachments: [{ filename: `${iv.number}.pdf`, content: pdf, contentType: 'application/pdf' }],
      });
    }

    const now = new Date();
    const followUp = report.outcome === 'TO_RESUME' || report.outcome === 'WAITING_PARTS';
    await db.transaction(async (tx) => {
      await tx
        .update(schema.reports)
        .set({ status: 'SENT', pdfPath, sentAt: body.sendEmail ? now : report.sentAt, sentTo: body.sendEmail ? recipients.join(', ') : report.sentTo, updatedAt: now })
        .where(eq(schema.reports.id, report.id));
      await tx
        .update(schema.interventions)
        .set({ status: followUp ? 'TO_RESUME' : 'DONE', updatedAt: now })
        .where(eq(schema.interventions.id, iv.id));
    });
    await audit(p, 'send', 'report', report.id, { to: body.sendEmail ? recipients : [] });
    // Le bureau est prévenu (qui l'a planifiée, chef de l'agence)
    notifyCompleted(iv, followUp, p.userId);
    return { status: 'SENT', sentTo: body.sendEmail ? recipients : [], archived: true };
  });

  /** Télécharge le PDF */
  app.get('/interventions/:id/report/pdf', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const iv = await loadIntervention(p, id);
    const found = await getReport(iv.id);
    if (!found || found.report.status === 'DRAFT') throw notFound('PDF');
    let pdf: Buffer;
    try {
      if (!found.report.pdfPath) throw new Error('pas encore archivé');
      pdf = await readFile(found.report.pdfPath);
    } catch {
      pdf = await buildPdf(iv, await loadContext(iv), found.report, found.parts);
    }
    return reply
      .type('application/pdf')
      .header('Content-Disposition', `inline; filename="${iv.number}.pdf"`)
      .send(pdf);
  });
}
