/**
 * Messagerie interne : conversations à deux ou de groupe entre les personnes du groupe d'entreprises
 * (bureau et techniciens). Pas de droit particulier : chacun peut écrire à ses collègues.
 *
 * Les messages du système (« X a ajouté Y ») n'ont pas d'auteur ; leur texte est un petit objet JSON
 * ({ e: 'added', by, names }) que l'appli affiche dans la langue de chacun.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, inArray, lt, sql } from 'drizzle-orm';
import { z } from 'zod';
import { ROLE_LABELS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { notifyLater } from '../services/notify.js';
import { contentDisposition, FILE_BODY_LIMIT, parseFileDataUrl, readStoredFile, removeStoredFile, storeFile } from '../services/files.js';

const c = schema.conversations;
const cm = schema.conversationMembers;
const m = schema.messages;
const u = schema.users;

export const MESSAGE_MAX = 4000;

/** Message tel qu'envoyé à l'appli : sans le chemin du fichier sur le serveur */
function publicMessage(x: typeof m.$inferSelect) {
  const { attachmentPath: _p, attachmentName, attachmentMime, attachmentSize, ...rest } = x;
  return {
    ...rest,
    body: x.deletedAt ? '' : x.body,
    attachment: !x.deletedAt && attachmentName ? { name: attachmentName, mime: attachmentMime ?? '', size: attachmentSize ?? 0 } : null,
  };
}

type SystemEvent = { e: 'created' | 'added' | 'left' | 'renamed'; by: string; names?: string; title?: string };

/** Clé d'une conversation à deux : les deux identifiants triés */
export function directKey(a: string, b: string): string {
  return [a, b].sort().join(':');
}

async function nameOf(userId: string): Promise<string> {
  const [row] = await db.select({ f: u.firstName, l: u.lastName }).from(u).where(eq(u.id, userId));
  return row ? `${row.f} ${row.l}` : '';
}

/** Personnes actives du groupe parmi les identifiants donnés */
async function activeColleagues(groupId: string, ids: string[]) {
  if (!ids.length) return [];
  return db.select({ id: u.id, firstName: u.firstName, lastName: u.lastName })
    .from(u).where(and(eq(u.groupId, groupId), eq(u.active, true), inArray(u.id, ids)));
}

/** La conversation, si la personne connectée en fait partie */
async function loadMember(groupId: string, userId: string, conversationId: string) {
  const [conv] = await db.select().from(c).where(and(eq(c.id, conversationId), eq(c.groupId, groupId)));
  if (!conv) throw notFound('Conversation');
  const [member] = await db.select().from(cm).where(and(eq(cm.conversationId, conversationId), eq(cm.userId, userId)));
  if (!member) throw forbidden();
  return conv;
}

async function systemMessage(conversationId: string, event: SystemEvent) {
  const now = new Date();
  await db.insert(m).values({ conversationId, senderId: null, body: JSON.stringify(event), createdAt: now });
  await db.update(c).set({ lastMessageAt: now }).where(eq(c.id, conversationId));
}

/** Conversations de la personne : membres, dernier message, nombre de messages non lus */
async function listFor(groupId: string, userId: string, onlyId?: string) {
  const mine = db.select({ id: cm.conversationId }).from(cm).where(eq(cm.userId, userId));
  const convs = await db.select().from(c)
    .where(and(eq(c.groupId, groupId), inArray(c.id, mine), onlyId ? eq(c.id, onlyId) : undefined))
    .orderBy(desc(c.lastMessageAt))
    .limit(200);
  if (!convs.length) return [];
  const ids = convs.map((x) => x.id);
  const members = await db.select({ conversationId: cm.conversationId, id: u.id, firstName: u.firstName, lastName: u.lastName, active: u.active })
    .from(cm).innerJoin(u, eq(u.id, cm.userId)).where(inArray(cm.conversationId, ids));
  // Dernier message de chaque conversation
  const last = await db.execute<{ conversation_id: string; id: string; sender_id: string | null; body: string; attachment_name: string | null; created_at: Date; deleted_at: Date | null }>(sql`
    SELECT DISTINCT ON (conversation_id) conversation_id, id, sender_id, body, attachment_name, created_at, deleted_at
    FROM messages WHERE conversation_id IN (${sql.join(ids.map((i) => sql`${i}`), sql`, `)})
    ORDER BY conversation_id, created_at DESC`);
  // Non lus : messages des autres, plus récents que la dernière lecture (ou que l'arrivée dans la conversation)
  const unread = await db.execute<{ conversation_id: string; n: number }>(sql`
    SELECT msg.conversation_id, count(*)::int AS n
    FROM messages msg
    JOIN conversation_members me ON me.conversation_id = msg.conversation_id AND me.user_id = ${userId}
    WHERE msg.conversation_id IN (${sql.join(ids.map((i) => sql`${i}`), sql`, `)})
      AND msg.sender_id IS DISTINCT FROM ${userId}
      AND msg.deleted_at IS NULL
      AND msg.created_at > coalesce(me.last_read_at, me.joined_at)
    GROUP BY msg.conversation_id`);
  const lastBy = new Map(last.rows.map((r) => [r.conversation_id, r]));
  const unreadBy = new Map(unread.rows.map((r) => [r.conversation_id, r.n]));
  return convs.map((conv) => {
    const l = lastBy.get(conv.id);
    return {
      id: conv.id, kind: conv.kind, title: conv.title, createdAt: conv.createdAt, lastMessageAt: conv.lastMessageAt,
      members: members.filter((x) => x.conversationId === conv.id).map(({ conversationId: _c, ...rest }) => rest),
      lastMessage: l ? { id: l.id, senderId: l.sender_id, body: l.deleted_at ? '' : l.body, attachmentName: l.deleted_at ? null : l.attachment_name, deleted: !!l.deleted_at, createdAt: l.created_at } : null,
      unread: unreadBy.get(conv.id) ?? 0,
    };
  });
}

export async function messageRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Les collègues à qui écrire : personnes actives du groupe, avec leur rôle et leur agence */
  app.get('/messages/people', async (req) => {
    const p = req.principal;
    const ra = schema.roleAssignments;
    const rows = await db.select({
      id: u.id, firstName: u.firstName, lastName: u.lastName, phone: u.phone, email: u.email,
      role: ra.role, agencyName: schema.agencies.name, companyName: schema.companies.name,
    })
      .from(u)
      .leftJoin(ra, eq(ra.userId, u.id))
      .leftJoin(schema.agencies, eq(schema.agencies.id, ra.agencyId))
      .leftJoin(schema.companies, eq(schema.companies.id, ra.companyId))
      .where(and(eq(u.groupId, p.groupId), eq(u.active, true)))
      .orderBy(asc(u.lastName), asc(u.firstName));
    const people = new Map<string, { id: string; firstName: string; lastName: string; roles: string[]; places: string[] }>();
    for (const r of rows) {
      const person = people.get(r.id) ?? { id: r.id, firstName: r.firstName, lastName: r.lastName, roles: [], places: [] };
      if (r.role && !person.roles.includes(ROLE_LABELS[r.role])) person.roles.push(ROLE_LABELS[r.role]);
      const place = r.agencyName ?? r.companyName;
      if (place && !person.places.includes(place)) person.places.push(place);
      people.set(r.id, person);
    }
    return [...people.values()].filter((x) => x.id !== p.userId);
  });

  /** Nombre total de messages non lus (pastille du menu) */
  app.get('/messages/unread', async (req) => {
    const p = req.principal;
    const res = await db.execute<{ n: number }>(sql`
      SELECT count(*)::int AS n
      FROM messages msg
      JOIN conversation_members me ON me.conversation_id = msg.conversation_id AND me.user_id = ${p.userId}
      WHERE msg.sender_id IS DISTINCT FROM ${p.userId}
        AND msg.deleted_at IS NULL
        AND msg.created_at > coalesce(me.last_read_at, me.joined_at)`);
    return { unread: res.rows[0]?.n ?? 0 };
  });

  app.get('/conversations', async (req) => listFor(req.principal.groupId, req.principal.userId));

  /**
   * Nouvelle conversation. Avec une seule autre personne et sans nom : conversation à deux
   * (la même est rouverte si elle existe déjà). Sinon : conversation de groupe.
   */
  app.post('/conversations', async (req, reply) => {
    const p = req.principal;
    const body = z.object({
      userIds: z.array(z.string().uuid()).min(1).max(100),
      title: z.string().trim().max(80).optional(),
    }).parse(req.body);
    const others = [...new Set(body.userIds.filter((x) => x !== p.userId))];
    const found = await activeColleagues(p.groupId, others);
    if (found.length !== others.length || !others.length) throw badRequest('Choisissez au moins une personne');

    if (others.length === 1 && !body.title) {
      const key = directKey(p.userId, others[0]);
      const [existing] = await db.select().from(c).where(eq(c.directKey, key));
      if (existing) return (await listFor(p.groupId, p.userId, existing.id))[0];
      const [conv] = await db.insert(c).values({ groupId: p.groupId, kind: 'DIRECT', directKey: key, createdBy: p.userId }).returning();
      const joinedAt = new Date();
      await db.insert(cm).values([{ conversationId: conv.id, userId: p.userId, joinedAt }, { conversationId: conv.id, userId: others[0], joinedAt }]);
      return reply.code(201).send((await listFor(p.groupId, p.userId, conv.id))[0]);
    }

    const [conv] = await db.insert(c).values({ groupId: p.groupId, kind: 'GROUP', title: body.title || null, createdBy: p.userId }).returning();
    const joinedAt = new Date(Date.now() - 1);
    await db.insert(cm).values([p.userId, ...others].map((userId) => ({ conversationId: conv.id, userId, joinedAt })));
    await systemMessage(conv.id, { e: 'created', by: await nameOf(p.userId) });
    return reply.code(201).send((await listFor(p.groupId, p.userId, conv.id))[0]);
  });

  /** Messages d'une conversation, du plus ancien au plus récent (par pages de 50, en remontant) */
  app.get('/conversations/:id/messages', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const q = z.object({ before: z.coerce.date().optional(), limit: z.coerce.number().int().min(1).max(200).default(50) }).parse(req.query);
    await loadMember(p.groupId, p.userId, id);
    const rows = await db.select().from(m)
      .where(and(eq(m.conversationId, id), q.before ? lt(m.createdAt, q.before) : undefined))
      .orderBy(desc(m.createdAt))
      .limit(q.limit);
    return rows.reverse().map(publicMessage);
  });

  /** Nouveau message : du texte, une photo ou un fichier joint (10 Mo au plus), ou les deux */
  app.post('/conversations/:id/messages', { bodyLimit: FILE_BODY_LIMIT }, async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const input = z.object({
      body: z.string().trim().max(MESSAGE_MAX).default(''),
      file: z.object({ dataUrl: z.string().min(1), name: z.string().max(255).default('') }).optional(),
    }).parse(req.body);
    if (!input.body && !input.file) throw badRequest('Le message est vide');
    const conv = await loadMember(p.groupId, p.userId, id);
    const file = input.file ? parseFileDataUrl(input.file.dataUrl, input.file.name) : null;
    if (input.file && !file) throw badRequest('Fichier refusé : format non accepté ou plus de 10 Mo');
    const now = new Date();
    const [msg] = await db.insert(m).values({ conversationId: id, senderId: p.userId, body: input.body, createdAt: now }).returning();
    let saved = msg;
    if (file) {
      const path = await storeFile(`messages/${conv.groupId}/${id}`, msg.id, file.ext, file.buffer);
      [saved] = await db.update(m)
        .set({ attachmentPath: path, attachmentName: file.name, attachmentMime: file.mime, attachmentSize: file.size })
        .where(eq(m.id, msg.id)).returning();
    }
    await db.update(c).set({ lastMessageAt: now }).where(eq(c.id, id));
    await db.update(cm).set({ lastReadAt: now }).where(and(eq(cm.conversationId, id), eq(cm.userId, p.userId)));
    // Les autres participants sont prévenus (téléphone, e-mail selon leurs préférences)
    const others = (await db.select({ id: cm.userId }).from(cm).where(eq(cm.conversationId, id))).map((x) => x.id).filter((x) => x !== p.userId);
    const sender = await nameOf(p.userId);
    const preview = saved.body ? saved.body.slice(0, 140) : `📎 ${saved.attachmentName ?? ''}`;
    notifyLater(others, 'message', () => ({
      title: conv.kind === 'GROUP' && conv.title ? `${sender} · ${conv.title}` : sender,
      body: preview, url: `/messages?c=${id}`, tag: `conv-${id}`,
    }));
    return reply.code(201).send(publicMessage(saved));
  });

  /** Le fichier joint d'un message (membres de la conversation uniquement) */
  app.get('/messages/:id/attachment', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [msg] = await db.select().from(m).where(eq(m.id, id));
    if (!msg) throw notFound('Message');
    await loadMember(p.groupId, p.userId, msg.conversationId);
    const data = msg.attachmentPath && !msg.deletedAt ? await readStoredFile(msg.attachmentPath) : null;
    if (!data) throw notFound('Fichier');
    const mime = msg.attachmentMime ?? 'application/octet-stream';
    return reply.type(mime)
      .header('Content-Disposition', contentDisposition(mime, msg.attachmentName ?? 'fichier'))
      .header('X-Content-Type-Options', 'nosniff')
      .header('Cache-Control', 'private, max-age=86400')
      .send(data);
  });

  /** La conversation est lue jusqu'à maintenant */
  app.post('/conversations/:id/read', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    await loadMember(p.groupId, p.userId, id);
    await db.update(cm).set({ lastReadAt: new Date() }).where(and(eq(cm.conversationId, id), eq(cm.userId, p.userId)));
    return { ok: true };
  });

  /** Renommer une conversation de groupe */
  app.patch('/conversations/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { title } = z.object({ title: z.string().trim().min(1).max(80) }).parse(req.body);
    const conv = await loadMember(p.groupId, p.userId, id);
    if (conv.kind !== 'GROUP') throw badRequest('Une conversation à deux ne se renomme pas');
    await db.update(c).set({ title }).where(eq(c.id, id));
    await systemMessage(id, { e: 'renamed', by: await nameOf(p.userId), title });
    return (await listFor(p.groupId, p.userId, id))[0];
  });

  /** Ajouter des personnes à une conversation de groupe */
  app.post('/conversations/:id/members', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { userIds } = z.object({ userIds: z.array(z.string().uuid()).min(1).max(100) }).parse(req.body);
    const conv = await loadMember(p.groupId, p.userId, id);
    if (conv.kind !== 'GROUP') throw badRequest('Pour discuter à plusieurs, créez une conversation de groupe');
    const current = new Set((await db.select({ id: cm.userId }).from(cm).where(eq(cm.conversationId, id))).map((x) => x.id));
    const added = (await activeColleagues(p.groupId, userIds)).filter((x) => !current.has(x.id));
    if (added.length) {
      // Heure d'arrivée prise ici (et non par la base) : l'avis « X a ajouté… » qui suit compte comme non lu
      const joinedAt = new Date(Date.now() - 1);
      await db.insert(cm).values(added.map((x) => ({ conversationId: id, userId: x.id, joinedAt })));
      await systemMessage(id, { e: 'added', by: await nameOf(p.userId), names: added.map((x) => `${x.firstName} ${x.lastName}`).join(', ') });
    }
    return (await listFor(p.groupId, p.userId, id))[0];
  });

  /** Quitter une conversation de groupe */
  app.delete('/conversations/:id/members/me', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const conv = await loadMember(p.groupId, p.userId, id);
    if (conv.kind !== 'GROUP') throw badRequest('Une conversation à deux ne se quitte pas');
    await db.delete(cm).where(and(eq(cm.conversationId, id), eq(cm.userId, p.userId)));
    await systemMessage(id, { e: 'left', by: await nameOf(p.userId) });
    return reply.code(204).send();
  });

  /** Corriger ou retirer son propre message */
  app.patch('/messages/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { body } = z.object({ body: z.string().trim().min(1, 'Le message est vide').max(MESSAGE_MAX) }).parse(req.body);
    const [msg] = await db.select().from(m).where(eq(m.id, id));
    if (!msg) throw notFound('Message');
    await loadMember(p.groupId, p.userId, msg.conversationId);
    if (msg.senderId !== p.userId || msg.deletedAt) throw forbidden();
    const [updated] = await db.update(m).set({ body, editedAt: new Date() }).where(eq(m.id, id)).returning();
    return publicMessage(updated);
  });

  app.delete('/messages/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [msg] = await db.select().from(m).where(eq(m.id, id));
    if (!msg) throw notFound('Message');
    await loadMember(p.groupId, p.userId, msg.conversationId);
    if (msg.senderId !== p.userId) throw forbidden();
    // Un message retiré ne garde pas son fichier
    if (msg.attachmentPath) await removeStoredFile(msg.attachmentPath);
    await db.update(m).set({ deletedAt: new Date(), attachmentPath: null }).where(eq(m.id, id));
    return reply.code(204).send();
  });
}
