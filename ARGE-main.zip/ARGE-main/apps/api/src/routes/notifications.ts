/** Notifications de la personne connectée : abonnement de l'appareil, préférences, essai (voir services/notify.ts) */
import type { FastifyInstance } from 'fastify';
import { and, count, desc, eq, inArray, isNull } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { NOTIFY_EVENTS, notifyUsers, vapidKeys, wants } from '../services/notify.js';
import { FCM_PREFIX, fcmAccount } from '../services/fcm.js';
import { badRequest } from '../http.js';

import { PRODUCT_NAME } from '../env.js';
const ps = schema.pushSubscriptions;
const PREF_KEYS = NOTIFY_EVENTS.flatMap((e) => [`push_${e}`, `email_${e}`]) as [string, ...string[]];

async function prefsOf(userId: string) {
  const [u] = await db.select({ prefs: schema.users.notifyPrefs }).from(schema.users).where(eq(schema.users.id, userId));
  return Object.fromEntries(NOTIFY_EVENTS.flatMap((e) => [[`push_${e}`, wants(u?.prefs, e, 'push')], [`email_${e}`, wants(u?.prefs, e, 'email')]]));
}

export async function notificationRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  app.get('/notifications/config', async (req) => {
    const p = req.principal;
    const devices = await db.select({ endpoint: ps.endpoint }).from(ps).where(eq(ps.userId, p.userId));
    return { publicKey: vapidKeys().publicKey, prefs: await prefsOf(p.userId), devices: devices.length, appPush: !!fcmAccount() };
  });

  /** Cet appareil reçoit les notifications */
  app.post('/notifications/subscribe', async (req, reply) => {
    const p = req.principal;
    const b = z.object({
      endpoint: z.string().url().max(1000).refine((s) => s.startsWith('https://'), 'Adresse invalide'),
      keys: z.object({ p256dh: z.string().min(10).max(200), auth: z.string().min(8).max(100) }),
    }).parse(req.body);
    // Le même navigateur peut changer de compte : l'abonnement suit la personne connectée
    await db.insert(ps).values({ userId: p.userId, endpoint: b.endpoint, p256dh: b.keys.p256dh, auth: b.keys.auth, userAgent: String(req.headers['user-agent'] ?? '').slice(0, 300) })
      .onConflictDoUpdate({ target: ps.endpoint, set: { userId: p.userId, p256dh: b.keys.p256dh, auth: b.keys.auth } });
    return reply.code(201).send({ ok: true });
  });

  // ─── Cloche : historique des notifications de la personne connectée ───
  const nt = schema.notifications;
  app.get('/notifications/inbox', async (req) => {
    const p = req.principal;
    const { limit } = z.object({ limit: z.coerce.number().int().min(1).max(100).default(30) }).parse(req.query);
    const items = await db.select({ id: nt.id, kind: nt.kind, title: nt.title, body: nt.body, url: nt.url, createdAt: nt.createdAt, readAt: nt.readAt })
      .from(nt).where(eq(nt.userId, p.userId)).orderBy(desc(nt.createdAt)).limit(limit);
    const [{ n }] = await db.select({ n: count() }).from(nt).where(and(eq(nt.userId, p.userId), isNull(nt.readAt)));
    return { items, unread: n };
  });

  app.get('/notifications/unread', async (req) => {
    const p = req.principal;
    const [{ n }] = await db.select({ n: count() }).from(nt).where(and(eq(nt.userId, p.userId), isNull(nt.readAt)));
    return { count: n };
  });

  /** Marque comme lues : celles indiquées, sinon toutes */
  app.post('/notifications/read', async (req) => {
    const p = req.principal;
    const { ids } = z.object({ ids: z.array(z.string().uuid()).max(100).optional() }).parse(req.body ?? {});
    await db.update(nt).set({ readAt: new Date() })
      .where(and(eq(nt.userId, p.userId), isNull(nt.readAt), ...(ids?.length ? [inArray(nt.id, ids)] : [])));
    return { ok: true };
  });

  /** Appli Android : ce téléphone reçoit les notifications par Firebase (jeton donné par l'appli) */
  app.post('/notifications/device', async (req, reply) => {
    const p = req.principal;
    if (!fcmAccount()) throw badRequest('Les notifications de l’appli ne sont pas encore configurées sur le serveur.');
    const { token } = z.object({ token: z.string().min(20).max(4096).regex(/^[\w:.-]+$/) }).parse(req.body);
    const endpoint = FCM_PREFIX + token;
    await db.insert(ps).values({ userId: p.userId, endpoint, p256dh: 'fcm', auth: 'fcm', userAgent: String(req.headers['user-agent'] ?? '').slice(0, 300) })
      .onConflictDoUpdate({ target: ps.endpoint, set: { userId: p.userId } });
    return reply.code(201).send({ ok: true });
  });

  app.post('/notifications/device/remove', async (req) => {
    const p = req.principal;
    const { token } = z.object({ token: z.string().max(4096) }).parse(req.body);
    await db.delete(ps).where(and(eq(ps.userId, p.userId), eq(ps.endpoint, FCM_PREFIX + token)));
    return { ok: true };
  });

  app.post('/notifications/unsubscribe', async (req) => {
    const p = req.principal;
    const { endpoint } = z.object({ endpoint: z.string().max(1000) }).parse(req.body);
    await db.delete(ps).where(and(eq(ps.userId, p.userId), eq(ps.endpoint, endpoint)));
    return { ok: true };
  });

  app.patch('/notifications/prefs', async (req) => {
    const p = req.principal;
    const body = z.record(z.enum(PREF_KEYS), z.boolean()).parse(req.body);
    const next = { ...(await prefsOf(p.userId)), ...body };
    await db.update(schema.users).set({ notifyPrefs: next }).where(eq(schema.users.id, p.userId));
    return { prefs: next };
  });

  /** Notification d'essai sur tous ses appareils */
  app.post('/notifications/test', async (req) => {
    const p = req.principal;
    await notifyUsers([p.userId], 'message', (locale) => locale.startsWith('fr')
      ? { title: PRODUCT_NAME, body: 'Les notifications fonctionnent sur cet appareil.', url: '/account', tag: 'test' }
      : { title: PRODUCT_NAME, body: 'Notifications work on this device.', url: '/account', tag: 'test' });
    return { ok: true };
  });
}
