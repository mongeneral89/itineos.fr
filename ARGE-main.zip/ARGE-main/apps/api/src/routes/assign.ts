/**
 * Suggestion d'attribution (voir services/assign.ts) : réglage par société, matériel à prévoir sur
 * l'intervention, et liste des techniciens classés. Le planificateur choisit ; rien n'est attribué tout seul.
 */
import type { FastifyInstance } from 'fastify';
import { and, eq, inArray } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '../db/client.js';
import { can } from '../auth/access.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { suggestTechnicians } from '../services/assign.js';
import { loadIntervention } from './interventions.js';

export async function assignRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Activer ou non la suggestion d'attribution (et la localisation des adresses) pour une société */
  app.patch('/org/companies/:companyId/planning', async (req) => {
    const p = req.principal;
    const { companyId } = z.object({ companyId: z.string().uuid() }).parse(req.params);
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw notFound('Société');
    if (!can(p, 'org.write', { companyId }) && !can(p, 'intervention.assign', { companyId, agencyId: null })) throw forbidden();
    const body = z.object({ assignSuggestions: z.boolean().optional(), geocodeSites: z.boolean().optional() }).parse(req.body);
    const [updated] = await db.update(schema.companies).set(body).where(eq(schema.companies.id, companyId)).returning();
    await audit(p, 'update', 'company.planning', companyId, body);
    return { assignSuggestions: updated.assignSuggestions, geocodeSites: updated.geocodeSites };
  });

  /** Matériel à prévoir pour l'intervention (articles du catalogue de la société) */
  app.put('/interventions/:id/needed-parts', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { parts } = z.object({
      parts: z.array(z.object({ articleId: z.string().uuid(), quantity: z.number().positive().max(100_000) })).max(100),
    }).parse(req.body);
    const job = await loadIntervention(p, id);
    if (!can(p, 'intervention.write', job)) throw forbidden();
    if (parts.length) {
      const ids = [...new Set(parts.map((x) => x.articleId))];
      const found = await db.select({ id: schema.articles.id }).from(schema.articles)
        .where(and(inArray(schema.articles.id, ids), eq(schema.articles.companyId, job.companyId)));
      if (found.length !== ids.length) throw badRequest('Article inconnu');
    }
    await db.update(schema.interventions).set({ neededParts: parts, updatedAt: new Date() }).where(eq(schema.interventions.id, id));
    return { parts };
  });

  /** Techniciens classés pour cette intervention, au jour donné (sinon : sa date, ou le prochain jour utile) */
  app.get('/interventions/:id/suggestions', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const q = z.object({ day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() }).parse(req.query);
    const job = await loadIntervention(p, id);
    if (!can(p, 'intervention.assign', job)) throw forbidden();
    const company = await getCompany(p.groupId, job.companyId);
    if (!company?.assignSuggestions) throw conflict("La suggestion d'attribution n'est pas activée pour cette société");
    return suggestTechnicians(id, { day: q.day, geocode: company.geocodeSites });
  });
}
