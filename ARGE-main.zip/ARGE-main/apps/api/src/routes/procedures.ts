/**
 * Notices et procédures : bibliothèque de documents consultée sur le terrain (notices fabricants, procédures
 * internes, schémas, consignes de sécurité…).
 *
 * Le bureau (droit « procedure.manage » sur le périmètre) publie directement. Toute autre personne, en général
 * un technicien, peut proposer un document : il reste « en attente » jusqu'à ce que le bureau le valide ou le
 * refuse (avec un motif). Seuls les documents validés sont visibles de tous, selon leur périmètre.
 */
import type { FastifyInstance } from 'fastify';
import { and, desc, eq, inArray } from 'drizzle-orm';
import { z } from 'zod';
import { PROCEDURE_CATEGORIES } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canGroupWide, type Principal } from '../auth/access.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { notifyLater } from '../services/notify.js';
import { contentDisposition, FILE_BODY_LIMIT, parseFileDataUrl, readStoredFile, removeStoredFile, storeFile } from '../services/files.js';

const pr = schema.procedures;
const u = schema.users;
type Row = typeof pr.$inferSelect;

const text = (max: number) => z.string().trim().max(max).optional().nullable().transform((s) => (s ? s : null));
const body = z.object({
  companyId: z.string().uuid().nullable().default(null),
  agencyId: z.string().uuid().nullable().default(null),
  category: z.enum(PROCEDURE_CATEGORIES).default('OTHER'),
  title: z.string().trim().min(1, 'Indiquez un titre').max(160),
  description: text(2000),
  keywords: text(300),
  url: z.string().trim().max(500).optional().nullable()
    .transform((s) => (s ? (/^https?:\/\//i.test(s) ? s : `https://${s}`) : null))
    .refine((s) => !s || /^https?:\/\/[^\s]+$/i.test(s), 'Lien invalide'),
  file: z.object({ dataUrl: z.string().min(1), name: z.string().max(255).default('') }).optional(),
});

/** Gère-t-il les documents de ce périmètre ? (vide = tout le groupe) */
export function canManage(p: Principal, companyId: string | null, agencyId: string | null): boolean {
  if (!companyId) return canGroupWide(p, 'procedure.manage');
  return can(p, 'procedure.manage', { companyId, agencyId });
}

/** Un document validé est visible de tout le groupe, de la société ou de l'agence à laquelle il est rattaché */
export function canSee(p: Principal, companyId: string | null, agencyId: string | null): boolean {
  if (!companyId) return true;
  return can(p, 'org.read', { companyId, agencyId }, { sharedVisible: true });
}

async function checkScope(p: Principal, companyId: string | null, agencyId: string | null) {
  if (agencyId && !companyId) throw badRequest('Une agence doit être accompagnée de sa société');
  if (companyId) {
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw badRequest('Société inconnue');
    if (agencyId && !(await getAgency(company.id, agencyId))) throw badRequest('Agence inconnue');
  }
}

/** Périmètre proposé par défaut pour un technicien : son agence (ou sa société) */
function ownScope(p: Principal): { companyId: string | null; agencyId: string | null } {
  const a = p.assignments.find((x) => x.companyId) ?? p.assignments[0];
  return { companyId: a?.companyId ?? null, agencyId: a?.agencyId ?? null };
}

async function load(p: Principal, id: string): Promise<Row> {
  const [row] = await db.select().from(pr).where(and(eq(pr.id, id), eq(pr.groupId, p.groupId)));
  if (!row) throw notFound('Document');
  return row;
}

/** Peut-il voir ce document ? Validé et dans son périmètre ; sinon c'est le sien ou il le gère */
function visible(p: Principal, row: Row): boolean {
  if (canManage(p, row.companyId, row.agencyId)) return true;
  if (row.submittedBy === p.userId) return true;
  return row.status === 'APPROVED' && canSee(p, row.companyId, row.agencyId);
}

async function names(ids: (string | null)[]) {
  const list = [...new Set(ids.filter((x): x is string => !!x))];
  if (!list.length) return new Map<string, string>();
  const rows = await db.select({ id: u.id, f: u.firstName, l: u.lastName }).from(u).where(inArray(u.id, list));
  return new Map(rows.map((r) => [r.id, `${r.f} ${r.l}`]));
}

function publicRow(p: Principal, r: Row, who: Map<string, string>) {
  const { filePath: _f, groupId: _g, ...rest } = r;
  return {
    ...rest,
    hasFile: !!r.filePath,
    submittedByName: r.submittedBy ? who.get(r.submittedBy) ?? null : null,
    reviewedByName: r.reviewedBy ? who.get(r.reviewedBy) ?? null : null,
    canManage: canManage(p, r.companyId, r.agencyId),
    mine: r.submittedBy === p.userId,
  };
}

export async function procedureRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Les documents visibles : validés, plus les siens et ceux à valider pour le bureau */
  app.get('/procedures', async (req) => {
    const p = req.principal;
    const rows = await db.select().from(pr).where(eq(pr.groupId, p.groupId)).orderBy(desc(pr.updatedAt)).limit(2000);
    const shown = rows.filter((r) => visible(p, r));
    const who = await names(shown.flatMap((r) => [r.submittedBy, r.reviewedBy]));
    return shown.map((r) => publicRow(p, r, who));
  });

  /** Nombre de documents à valider (pastille du menu pour le bureau) */
  app.get('/procedures/pending-count', async (req) => {
    const p = req.principal;
    const rows = await db.select({ companyId: pr.companyId, agencyId: pr.agencyId }).from(pr)
      .where(and(eq(pr.groupId, p.groupId), eq(pr.status, 'PENDING')));
    return { pending: rows.filter((r) => canManage(p, r.companyId, r.agencyId)).length };
  });

  /** Publier (bureau) ou proposer (technicien) un document */
  app.post('/procedures', { bodyLimit: FILE_BODY_LIMIT }, async (req, reply) => {
    const p = req.principal;
    const input = body.parse(req.body);
    const file = input.file ? parseFileDataUrl(input.file.dataUrl, input.file.name) : null;
    if (input.file && !file) throw badRequest('Fichier refusé : format non accepté ou plus de 10 Mo');
    if (!file && !input.url) throw badRequest('Joignez un fichier ou indiquez un lien');

    // Sans périmètre précis, le document va à sa propre agence (ou société) ; sans le droit de publier,
    // c'est une proposition à valider par le bureau
    let { companyId, agencyId } = input;
    if (!companyId && !canManage(p, null, null)) ({ companyId, agencyId } = ownScope(p));
    const manager = canManage(p, companyId, agencyId);
    await checkScope(p, companyId, agencyId);
    if (!manager && !canSee(p, companyId, agencyId)) throw forbidden();

    const [row] = await db.insert(pr).values({
      groupId: p.groupId, companyId, agencyId, category: input.category, title: input.title,
      description: input.description, keywords: input.keywords, url: input.url,
      status: manager ? 'APPROVED' : 'PENDING', submittedBy: p.userId,
      ...(manager ? { reviewedBy: p.userId, reviewedAt: new Date() } : {}),
    }).returning();
    let saved = row;
    if (file) {
      const path = await storeFile(`procedures/${p.groupId}`, row.id, file.ext, file.buffer);
      [saved] = await db.update(pr).set({ filePath: path, fileName: file.name, fileMime: file.mime, fileSize: file.size }).where(eq(pr.id, row.id)).returning();
    }
    await audit(p, manager ? 'create' : 'submit', 'procedure', row.id, { title: row.title });
    if (!manager) {
      const grants = await db.select({ userId: schema.roleAssignments.userId, role: schema.roleAssignments.role, companyId: schema.roleAssignments.companyId, agencyId: schema.roleAssignments.agencyId })
        .from(schema.roleAssignments).innerJoin(u, eq(u.id, schema.roleAssignments.userId)).where(eq(u.groupId, p.groupId));
      const managers = grants.filter((g) => canManage({ userId: g.userId, groupId: p.groupId, assignments: [g] }, companyId, agencyId)).map((g) => g.userId);
      const who = await names([p.userId]);
      notifyLater(managers.filter((x) => x !== p.userId), 'procedure', (locale) => ({
        title: locale.startsWith('fr') ? 'Document à valider' : 'Document to approve',
        body: `${row.title} · ${who.get(p.userId) ?? ''}`, url: '/procedures', tag: `proc-${row.id}`,
      }));
    }
    return reply.code(201).send(publicRow(p, saved, await names([saved.submittedBy, saved.reviewedBy])));
  });

  /**
   * Modifier : le bureau, ou l'auteur tant que sa proposition n'est pas validée
   * (une proposition refusée puis corrigée repart en attente).
   */
  app.patch('/procedures/:id', { bodyLimit: FILE_BODY_LIMIT }, async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await load(p, id);
    const manager = canManage(p, current.companyId, current.agencyId);
    const author = current.submittedBy === p.userId && current.status !== 'APPROVED';
    if (!manager && !author) throw forbidden();
    const input = body.parse(req.body);
    let { companyId, agencyId } = input;
    if (manager) {
      await checkScope(p, companyId, agencyId);
      if (!canManage(p, companyId, agencyId)) throw forbidden();
    } else {
      ({ companyId, agencyId } = current);
    }
    const file = input.file ? parseFileDataUrl(input.file.dataUrl, input.file.name) : null;
    if (input.file && !file) throw badRequest('Fichier refusé : format non accepté ou plus de 10 Mo');
    if (!file && !current.filePath && !input.url) throw badRequest('Joignez un fichier ou indiquez un lien');

    const patch: Partial<typeof pr.$inferInsert> = {
      companyId, agencyId, category: input.category, title: input.title, description: input.description,
      keywords: input.keywords, url: input.url, updatedAt: new Date(),
      ...(!manager && current.status === 'REJECTED' ? { status: 'PENDING' as const, reviewNote: null, reviewedAt: null, reviewedBy: null } : {}),
    };
    if (file) {
      if (current.filePath) await removeStoredFile(current.filePath);
      Object.assign(patch, {
        filePath: await storeFile(`procedures/${p.groupId}`, `${id}-${Date.now()}`, file.ext, file.buffer),
        fileName: file.name, fileMime: file.mime, fileSize: file.size,
      });
    }
    const [row] = await db.update(pr).set(patch).where(eq(pr.id, id)).returning();
    await audit(p, 'update', 'procedure', id, { title: row.title });
    return publicRow(p, row, await names([row.submittedBy, row.reviewedBy]));
  });

  /** Valider ou refuser une proposition (bureau) */
  app.post('/procedures/:id/review', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const { decision, note } = z.object({
      decision: z.enum(['APPROVED', 'REJECTED']),
      note: z.string().trim().max(1000).optional().default(''),
    }).parse(req.body);
    const current = await load(p, id);
    if (!canManage(p, current.companyId, current.agencyId)) throw forbidden();
    if (decision === 'REJECTED' && !note) throw badRequest('Indiquez le motif du refus');
    const [row] = await db.update(pr).set({
      status: decision, reviewedBy: p.userId, reviewedAt: new Date(), reviewNote: decision === 'REJECTED' ? note : null, updatedAt: new Date(),
    }).where(eq(pr.id, id)).returning();
    await audit(p, decision === 'APPROVED' ? 'approve' : 'reject', 'procedure', id, { title: row.title });
    return publicRow(p, row, await names([row.submittedBy, row.reviewedBy]));
  });

  /** Supprimer : le bureau, ou l'auteur d'une proposition pas encore validée */
  app.delete('/procedures/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await load(p, id);
    const author = current.submittedBy === p.userId && current.status !== 'APPROVED';
    if (!canManage(p, current.companyId, current.agencyId) && !author) throw forbidden();
    await db.delete(pr).where(eq(pr.id, id));
    if (current.filePath) await removeStoredFile(current.filePath);
    await audit(p, 'delete', 'procedure', id, { title: current.title });
    return reply.code(204).send();
  });

  /** Le fichier du document */
  app.get('/procedures/:id/file', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const row = await load(p, id);
    if (!visible(p, row)) throw notFound('Document');
    const data = row.filePath ? await readStoredFile(row.filePath) : null;
    if (!data) throw notFound('Fichier');
    const mime = row.fileMime ?? 'application/octet-stream';
    return reply.type(mime)
      .header('Content-Disposition', contentDisposition(mime, row.fileName ?? 'document'))
      .header('X-Content-Type-Options', 'nosniff')
      .send(data);
  });
}

