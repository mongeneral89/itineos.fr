/**
 * Stock : catalogue d'articles, lieux (dépôts et véhicules), quantités, réceptions, inventaires et bons de sortie.
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, desc, eq, ilike, inArray, isNull, or, sql } from 'drizzle-orm';
import { z } from 'zod';
import { isLowStock, SLIP_STATUSES, STOCK_LOCATION_KINDS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { companyLogo } from '../services/logo.js';
import { can, scopeFor, type Principal } from '../auth/access.js';
import { scopeWhere } from '../auth/scope-sql.js';
import { badRequest, conflict, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';
import { nextNumber } from '../services/numbering.js';
import { recordMovement, round, vehicleOf } from '../services/stock.js';
import { generateSlipPdf } from '../services/slip-pdf.js';
import { isTechnicianFor, loadIntervention } from './interventions.js';

const a = schema.articles;
const loc = schema.stockLocations;
const lvl = schema.stockLevels;
const slip = schema.stockSlips;

type Perm = 'stock.read' | 'stock.write';

/** Le catalogue est commun à la société : visible et modifiable depuis n'importe quelle agence autorisée */
function canCatalog(p: Principal, perm: Perm, companyId: string) {
  return can(p, perm, { companyId, agencyId: null }, { sharedVisible: true });
}

async function loadArticle(p: Principal, id: string, perm: Perm) {
  const [row] = await db.select().from(a).where(and(eq(a.id, id), eq(a.groupId, p.groupId)));
  if (!row) throw notFound('Article');
  if (!canCatalog(p, perm, row.companyId)) throw forbidden();
  return row;
}

/** Un lieu de stock ; le technicien peut consulter son propre véhicule */
async function loadLocation(p: Principal, id: string, perm: Perm) {
  const [row] = await db.select().from(loc).where(and(eq(loc.id, id), eq(loc.groupId, p.groupId)));
  if (!row) throw notFound('Lieu de stock');
  const target = { companyId: row.companyId, agencyId: row.agencyId };
  const own = perm === 'stock.read' && row.technicianId === p.userId && can(p, 'stock.read.own', target, { sharedVisible: true });
  if (!own && !can(p, perm, target, { sharedVisible: true })) throw forbidden();
  return row;
}

const articleBody = z.object({
  reference: z.string().trim().min(1, 'La référence est obligatoire').max(60),
  name: z.string().trim().min(1, 'La désignation est obligatoire').max(300),
  category: z.string().trim().max(100).nullable().optional(),
  unit: z.string().trim().min(1).max(20).default('u'),
  purchasePriceCents: z.number().int().min(0).nullable().optional(),
  salePriceCents: z.number().int().min(0).nullable().optional(),
  vatRateBp: z.number().int().min(0).max(10_000).default(2000),
  active: z.boolean().optional(),
});

const lineBody = z.object({ articleId: z.string().uuid(), quantity: z.number().positive().max(1_000_000) });

/** Les articles doivent exister et appartenir à la société */
async function checkArticles(companyId: string, ids: string[]) {
  if (!ids.length) return new Map<string, typeof a.$inferSelect>();
  const rows = await db.select().from(a).where(and(inArray(a.id, ids), eq(a.companyId, companyId)));
  if (rows.length !== new Set(ids).size) throw badRequest("Un des articles n'existe pas dans le catalogue de cette société");
  return new Map(rows.map((r) => [r.id, r]));
}

const levelColumns = {
  locationId: lvl.locationId, articleId: lvl.articleId, quantity: lvl.quantity, minQuantity: lvl.minQuantity,
  reference: a.reference, name: a.name, unit: a.unit, category: a.category, salePriceCents: a.salePriceCents,
  vatRateBp: a.vatRateBp, locationName: loc.name, locationKind: loc.kind,
};

async function slipFull(id: string) {
  const [s] = await db.select().from(slip).where(eq(slip.id, id));
  const lines = await db
    .select({ id: schema.stockSlipLines.id, articleId: schema.stockSlipLines.articleId, quantity: schema.stockSlipLines.quantity, reference: a.reference, name: a.name, unit: a.unit })
    .from(schema.stockSlipLines).innerJoin(a, eq(a.id, schema.stockSlipLines.articleId))
    .where(eq(schema.stockSlipLines.slipId, id)).orderBy(asc(schema.stockSlipLines.position));
  const ids = [s.fromLocationId, s.toLocationId].filter((x): x is string => !!x);
  const places = await db.select({ id: loc.id, name: loc.name, kind: loc.kind }).from(loc).where(inArray(loc.id, ids));
  const [iv] = s.interventionId
    ? await db.select({ id: schema.interventions.id, number: schema.interventions.number, reason: schema.interventions.reason, clientName: schema.clients.name })
      .from(schema.interventions).innerJoin(schema.clients, eq(schema.clients.id, schema.interventions.clientId))
      .where(eq(schema.interventions.id, s.interventionId))
    : [null];
  return {
    ...s, lines,
    from: places.find((x) => x.id === s.fromLocationId)!,
    to: places.find((x) => x.id === s.toLocationId) ?? null,
    intervention: iv ?? null,
  };
}

export async function stockRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  // ─── Catalogue ───

  app.get('/articles', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid(), q: z.string().optional(), all: z.coerce.boolean().optional() }).parse(req.query);
    if (!canCatalog(p, 'stock.read', f.companyId) && !can(p, 'quote.read', { companyId: f.companyId, agencyId: null }, { sharedVisible: true })) throw forbidden();
    const term = f.q?.trim();
    return db.select().from(a).where(and(
      eq(a.companyId, f.companyId),
      f.all ? undefined : eq(a.active, true),
      term ? or(ilike(a.reference, `%${term}%`), ilike(a.name, `%${term}%`), ilike(a.category, `%${term}%`)) : undefined,
    )).orderBy(asc(a.category), asc(a.name)).limit(500);
  });

  app.post('/articles', async (req, reply) => {
    const p = req.principal;
    const body = articleBody.extend({ companyId: z.string().uuid() }).parse(req.body);
    if (!(await getCompany(p.groupId, body.companyId))) throw badRequest('Société inconnue');
    if (!canCatalog(p, 'stock.write', body.companyId)) throw forbidden();
    const [dup] = await db.select({ id: a.id }).from(a).where(and(eq(a.companyId, body.companyId), sql`lower(${a.reference}) = lower(${body.reference})`));
    if (dup) throw conflict(`La référence « ${body.reference} » existe déjà`);
    const [row] = await db.insert(a).values({ ...body, groupId: p.groupId }).returning();
    await audit(p, 'create', 'article', row.id, { reference: row.reference });
    return reply.code(201).send(row);
  });

  app.patch('/articles/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadArticle(p, id, 'stock.write');
    const body = articleBody.partial().parse(req.body);
    if (body.reference && body.reference.toLowerCase() !== current.reference.toLowerCase()) {
      const [dup] = await db.select({ id: a.id }).from(a).where(and(eq(a.companyId, current.companyId), sql`lower(${a.reference}) = lower(${body.reference})`));
      if (dup) throw conflict(`La référence « ${body.reference} » existe déjà`);
    }
    const [row] = await db.update(a).set(body).where(eq(a.id, id)).returning();
    await audit(p, 'update', 'article', id, body);
    return row;
  });

  // ─── Lieux de stock ───

  app.get('/stock/locations', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid().optional(), agencyId: z.string().uuid().optional() }).parse(req.query);
    return db
      .select({
        id: loc.id, companyId: loc.companyId, agencyId: loc.agencyId, kind: loc.kind, name: loc.name, technicianId: loc.technicianId, active: loc.active,
        technicianFirstName: schema.users.firstName, technicianLastName: schema.users.lastName,
      })
      .from(loc)
      .leftJoin(schema.users, eq(schema.users.id, loc.technicianId))
      .where(and(
        eq(loc.groupId, p.groupId),
        scopeWhere(scopeFor(p, 'stock.read'), { companyId: loc.companyId, agencyId: loc.agencyId }, { sharedVisible: true }),
        f.companyId ? eq(loc.companyId, f.companyId) : undefined,
        f.agencyId ? or(eq(loc.agencyId, f.agencyId), isNull(loc.agencyId)) : undefined,
      ))
      .orderBy(asc(loc.kind), asc(loc.name));
  });

  app.post('/stock/locations', async (req, reply) => {
    const p = req.principal;
    const body = z.object({
      companyId: z.string().uuid(),
      agencyId: z.string().uuid().nullable().default(null),
      kind: z.enum(STOCK_LOCATION_KINDS),
      name: z.string().trim().min(1, 'Le nom est obligatoire').max(120),
      technicianId: z.string().uuid().nullable().optional(),
    }).parse(req.body);
    const company = await getCompany(p.groupId, body.companyId);
    if (!company) throw badRequest('Société inconnue');
    if (body.agencyId && !(await getAgency(company.id, body.agencyId))) throw badRequest('Agence inconnue');
    if (!can(p, 'stock.write', { companyId: company.id, agencyId: body.agencyId })) throw forbidden();
    if (body.kind === 'VEHICLE') {
      if (!body.technicianId || !body.agencyId) throw badRequest('Un véhicule est rattaché à une agence et à un technicien');
      if (!(await isTechnicianFor(body.technicianId, company.id, body.agencyId))) throw badRequest("Ce technicien n'est pas rattaché à cette agence");
      if (await vehicleOf(body.technicianId, company.id)) throw conflict('Ce technicien a déjà un véhicule');
    }
    const [row] = await db.insert(loc).values({ ...body, technicianId: body.kind === 'VEHICLE' ? body.technicianId : null, groupId: p.groupId }).returning();
    await audit(p, 'create', 'stock_location', row.id, { name: row.name });
    return reply.code(201).send(row);
  });

  app.patch('/stock/locations/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const current = await loadLocation(p, id, 'stock.write');
    const body = z.object({ name: z.string().trim().min(1).max(120).optional(), active: z.boolean().optional() }).parse(req.body);
    if (body.active === false) {
      const [{ n }] = await db.select({ n: sql<string>`count(*)` }).from(lvl).where(and(eq(lvl.locationId, id), sql`abs(${lvl.quantity}) > 1e-9`));
      if (Number(n) > 0) throw conflict('Ce lieu contient encore du stock : transférez-le avant de le désactiver');
    }
    const [row] = await db.update(loc).set(body).where(eq(loc.id, current.id)).returning();
    await audit(p, 'update', 'stock_location', id, body);
    return row;
  });

  // ─── Quantités ───

  /** Stock d'un lieu, d'un article, ou toutes les alertes de stock bas d'une société */
  app.get('/stock/levels', async (req) => {
    const p = req.principal;
    const f = z.object({
      locationId: z.string().uuid().optional(),
      articleId: z.string().uuid().optional(),
      companyId: z.string().uuid().optional(),
      low: z.coerce.boolean().optional(),
    }).parse(req.query);
    if (f.locationId) await loadLocation(p, f.locationId, 'stock.read');
    else if (f.articleId) await loadArticle(p, f.articleId, 'stock.read');
    else if (!f.companyId) throw badRequest('Précisez un lieu, un article ou une société');
    const rows = await db.select(levelColumns).from(lvl)
      .innerJoin(a, eq(a.id, lvl.articleId))
      .innerJoin(loc, eq(loc.id, lvl.locationId))
      .where(and(
        eq(loc.groupId, p.groupId),
        eq(loc.active, true),
        f.locationId ? eq(lvl.locationId, f.locationId) : scopeWhere(scopeFor(p, 'stock.read'), { companyId: loc.companyId, agencyId: loc.agencyId }, { sharedVisible: true }),
        f.articleId ? eq(lvl.articleId, f.articleId) : undefined,
        f.companyId ? eq(loc.companyId, f.companyId) : undefined,
      ))
      .orderBy(asc(loc.name), asc(a.name));
    const out = rows.map((r) => ({ ...r, quantity: round(r.quantity), low: isLowStock(r) }));
    return f.low ? out.filter((r) => r.low) : out;
  });

  /** Seuil d'alerte d'un article dans un lieu */
  app.patch('/stock/levels', async (req) => {
    const p = req.principal;
    const body = z.object({ locationId: z.string().uuid(), articleId: z.string().uuid(), minQuantity: z.number().min(0).max(1_000_000) }).parse(req.body);
    const place = await loadLocation(p, body.locationId, 'stock.write');
    await checkArticles(place.companyId, [body.articleId]);
    await db.insert(lvl).values({ ...body, quantity: 0 })
      .onConflictDoUpdate({ target: [lvl.locationId, lvl.articleId], set: { minQuantity: body.minQuantity } });
    return { ok: true };
  });

  /** Réception de marchandise (livraison fournisseur) dans un lieu */
  app.post('/stock/receipts', async (req, reply) => {
    const p = req.principal;
    const body = z.object({ locationId: z.string().uuid(), lines: z.array(lineBody).min(1).max(200), note: z.string().max(500).nullable().optional() }).parse(req.body);
    const place = await loadLocation(p, body.locationId, 'stock.write');
    await checkArticles(place.companyId, body.lines.map((l) => l.articleId));
    await db.transaction(async (tx) => {
      for (const l of body.lines) {
        await recordMovement(tx, { groupId: p.groupId, companyId: place.companyId, articleId: l.articleId, kind: 'RECEIPT', toLocationId: place.id, quantity: l.quantity, note: body.note ?? null, userId: p.userId });
      }
    });
    await audit(p, 'receipt', 'stock_location', place.id, { lines: body.lines.length });
    return reply.code(201).send({ ok: true });
  });

  /** Inventaire : on saisit la quantité comptée, l'écart devient un mouvement d'inventaire */
  app.post('/stock/adjustments', async (req) => {
    const p = req.principal;
    const body = z.object({ locationId: z.string().uuid(), articleId: z.string().uuid(), countedQuantity: z.number().min(0).max(1_000_000), note: z.string().max(500).nullable().optional() }).parse(req.body);
    const place = await loadLocation(p, body.locationId, 'stock.write');
    await checkArticles(place.companyId, [body.articleId]);
    const [current] = await db.select({ q: lvl.quantity }).from(lvl).where(and(eq(lvl.locationId, place.id), eq(lvl.articleId, body.articleId)));
    const delta = round(body.countedQuantity - (current?.q ?? 0));
    if (delta === 0) return { delta: 0 };
    await db.transaction(async (tx) => {
      await recordMovement(tx, {
        groupId: p.groupId, companyId: place.companyId, articleId: body.articleId, kind: 'ADJUSTMENT',
        ...(delta > 0 ? { toLocationId: place.id } : { fromLocationId: place.id }),
        quantity: Math.abs(delta), note: body.note ?? 'Inventaire', userId: p.userId,
      }, { allowNegative: true });
    });
    await audit(p, 'adjust', 'stock_location', place.id, { articleId: body.articleId, delta });
    return { delta };
  });

  app.get('/stock/movements', async (req) => {
    const p = req.principal;
    const f = z.object({ locationId: z.string().uuid().optional(), articleId: z.string().uuid().optional(), limit: z.coerce.number().int().min(1).max(500).default(100) }).parse(req.query);
    if (f.locationId) await loadLocation(p, f.locationId, 'stock.read');
    else if (f.articleId) await loadArticle(p, f.articleId, 'stock.read');
    else throw badRequest('Précisez un lieu ou un article');
    const m = schema.stockMovements;
    return db.select({
      id: m.id, kind: m.kind, quantity: m.quantity, fromLocationId: m.fromLocationId, toLocationId: m.toLocationId,
      note: m.note, createdAt: m.createdAt, slipId: m.slipId, interventionId: m.interventionId,
      reference: a.reference, name: a.name, unit: a.unit, slipNumber: slip.number, interventionNumber: schema.interventions.number,
    })
      .from(m).innerJoin(a, eq(a.id, m.articleId))
      .leftJoin(slip, eq(slip.id, m.slipId))
      .leftJoin(schema.interventions, eq(schema.interventions.id, m.interventionId))
      .where(and(
        f.locationId ? or(eq(m.fromLocationId, f.locationId), eq(m.toLocationId, f.locationId)) : undefined,
        f.articleId ? eq(m.articleId, f.articleId) : undefined,
      ))
      .orderBy(desc(m.createdAt)).limit(f.limit);
  });

  /** Le véhicule du technicien connecté et son contenu (pour choisir les pièces posées, aussi hors ligne) */
  app.get('/stock/my-vehicle', async (req) => {
    const p = req.principal;
    const [vehicle] = await db.select().from(loc).where(and(eq(loc.technicianId, p.userId), eq(loc.active, true), eq(loc.groupId, p.groupId)));
    if (!vehicle) return { vehicle: null, levels: [] };
    const levels = await db.select(levelColumns).from(lvl)
      .innerJoin(a, eq(a.id, lvl.articleId)).innerJoin(loc, eq(loc.id, lvl.locationId))
      .where(and(eq(lvl.locationId, vehicle.id), eq(a.active, true))).orderBy(asc(a.name));
    return { vehicle, levels: levels.map((l) => ({ ...l, quantity: round(l.quantity) })) };
  });

  // ─── Bons de sortie ───

  app.get('/stock/slips', async (req) => {
    const p = req.principal;
    const f = z.object({ companyId: z.string().uuid().optional(), agencyId: z.string().uuid().optional(), status: z.enum(SLIP_STATUSES).optional() }).parse(req.query);
    const from = schema.stockLocations;
    return db.select({
      id: slip.id, number: slip.number, status: slip.status, companyId: slip.companyId, agencyId: slip.agencyId,
      fromLocationId: slip.fromLocationId, toLocationId: slip.toLocationId, interventionId: slip.interventionId,
      createdAt: slip.createdAt, validatedAt: slip.validatedAt, fromName: from.name,
      lineCount: sql<number>`(select count(*)::int from stock_slip_lines l where l.slip_id = ${slip.id})`,
    })
      .from(slip).innerJoin(from, eq(from.id, slip.fromLocationId))
      .where(and(
        eq(slip.groupId, p.groupId),
        scopeWhere(scopeFor(p, 'stock.read'), { companyId: slip.companyId, agencyId: slip.agencyId }, { sharedVisible: true }),
        f.companyId ? eq(slip.companyId, f.companyId) : undefined,
        f.agencyId ? or(eq(slip.agencyId, f.agencyId), isNull(slip.agencyId)) : undefined,
        f.status ? eq(slip.status, f.status) : undefined,
      ))
      .orderBy(desc(slip.createdAt)).limit(300);
  });

  app.get('/stock/slips/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [s] = await db.select().from(slip).where(and(eq(slip.id, id), eq(slip.groupId, p.groupId)));
    if (!s) throw notFound('Bon de sortie');
    if (!can(p, 'stock.read', { companyId: s.companyId, agencyId: s.agencyId }, { sharedVisible: true })) throw forbidden();
    return slipFull(id);
  });

  const slipBody = z.object({
    fromLocationId: z.string().uuid(),
    toLocationId: z.string().uuid().nullable().optional(),
    interventionId: z.string().uuid().nullable().optional(),
    notes: z.string().max(2000).nullable().optional(),
    lines: z.array(lineBody).max(200).default([]),
  }).refine((b) => !!b.toLocationId !== !!b.interventionId, { message: 'Choisissez une destination : un véhicule/dépôt OU une intervention' });

  async function checkSlip(p: Principal, b: z.infer<typeof slipBody>) {
    const from = await loadLocation(p, b.fromLocationId, 'stock.write');
    if (b.toLocationId) {
      const to = await loadLocation(p, b.toLocationId, 'stock.read');
      if (to.companyId !== from.companyId) throw badRequest('Les deux lieux doivent être dans la même société');
      if (to.id === from.id) throw badRequest('Le lieu de destination doit être différent');
    }
    if (b.interventionId) {
      const iv = await loadIntervention(p, b.interventionId);
      if (iv.companyId !== from.companyId) throw badRequest("L'intervention doit être dans la même société");
    }
    await checkArticles(from.companyId, b.lines.map((l) => l.articleId));
    return from;
  }

  app.post('/stock/slips', async (req, reply) => {
    const p = req.principal;
    const body = slipBody.parse(req.body);
    const from = await checkSlip(p, body);
    const created = await db.transaction(async (tx) => {
      const [row] = await tx.insert(slip).values({
        groupId: p.groupId, companyId: from.companyId, agencyId: from.agencyId, fromLocationId: from.id,
        toLocationId: body.toLocationId ?? null, interventionId: body.interventionId ?? null, notes: body.notes ?? null, createdById: p.userId,
      }).returning();
      if (body.lines.length) await tx.insert(schema.stockSlipLines).values(body.lines.map((l, i) => ({ ...l, slipId: row.id, position: i })));
      return row;
    });
    await audit(p, 'create', 'stock_slip', created.id);
    return reply.code(201).send(await slipFull(created.id));
  });

  app.put('/stock/slips/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [s] = await db.select().from(slip).where(and(eq(slip.id, id), eq(slip.groupId, p.groupId)));
    if (!s) throw notFound('Bon de sortie');
    if (s.status !== 'DRAFT') throw conflict('Un bon validé ne peut plus être modifié');
    const body = slipBody.parse(req.body);
    const from = await checkSlip(p, body);
    await db.transaction(async (tx) => {
      await tx.update(slip).set({ fromLocationId: from.id, agencyId: from.agencyId, toLocationId: body.toLocationId ?? null, interventionId: body.interventionId ?? null, notes: body.notes ?? null }).where(eq(slip.id, id));
      await tx.delete(schema.stockSlipLines).where(eq(schema.stockSlipLines.slipId, id));
      if (body.lines.length) await tx.insert(schema.stockSlipLines).values(body.lines.map((l, i) => ({ ...l, slipId: id, position: i })));
    });
    return slipFull(id);
  });

  /** Annuler un brouillon (un bon validé a déjà déplacé le stock : on fait un bon inverse) */
  app.post('/stock/slips/:id/cancel', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [s] = await db.select().from(slip).where(and(eq(slip.id, id), eq(slip.groupId, p.groupId)));
    if (!s) throw notFound('Bon de sortie');
    await loadLocation(p, s.fromLocationId, 'stock.write');
    if (s.status !== 'DRAFT') throw conflict('Seul un brouillon peut être annulé');
    await db.update(slip).set({ status: 'CANCELLED' }).where(eq(slip.id, id));
    return slipFull(id);
  });

  /** Validation : numéro, et le stock part du dépôt vers la destination (refusé si le dépôt n'a pas assez) */
  app.post('/stock/slips/:id/validate', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const full = await slipFull(id);
    if (full.groupId !== p.groupId) throw notFound('Bon de sortie');
    const from = await loadLocation(p, full.fromLocationId, 'stock.write');
    if (full.status !== 'DRAFT') throw conflict('Ce bon est déjà validé ou annulé');
    if (!full.lines.length) throw badRequest('Ajoutez au moins un article');
    const company = (await getCompany(p.groupId, from.companyId))!;
    await db.transaction(async (tx) => {
      const [locked] = await tx.update(slip).set({ status: 'VALIDATED', validatedAt: new Date(), validatedById: p.userId })
        .where(and(eq(slip.id, id), eq(slip.status, 'DRAFT'))).returning({ id: slip.id });
      if (!locked) throw conflict('Ce bon vient d’être validé par quelqu’un d’autre');
      for (const l of full.lines) {
        await recordMovement(tx, {
          groupId: p.groupId, companyId: from.companyId, articleId: l.articleId,
          kind: full.interventionId ? 'ISSUE' : 'TRANSFER', fromLocationId: from.id, toLocationId: full.toLocationId,
          quantity: l.quantity, slipId: id, interventionId: full.interventionId, userId: p.userId,
        }, { articleLabel: `${l.reference} – ${l.name}` });
      }
      const number = await nextNumber(tx, company, 'slip');
      await tx.update(slip).set({ number }).where(eq(slip.id, id));
    });
    await audit(p, 'validate', 'stock_slip', id);
    return slipFull(id);
  });

  app.get('/stock/slips/:id/pdf', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const full = await slipFull(id).catch(() => null);
    if (!full || full.groupId !== p.groupId) throw notFound('Bon de sortie');
    if (!can(p, 'stock.read', { companyId: full.companyId, agencyId: full.agencyId }, { sharedVisible: true })) throw forbidden();
    const company = (await getCompany(p.groupId, full.companyId))!;
    const pdf = await generateSlipPdf({
      locale: company.locale, timezone: company.timezone, company: { ...company, logo: await companyLogo(company) },
      number: full.number, date: full.validatedAt ?? full.createdAt, from: full.from.name,
      to: full.to ? full.to.name : full.intervention ? `${full.intervention.number} – ${full.intervention.clientName}\n${full.intervention.reason}` : '—',
      notes: full.notes, lines: full.lines.map((l) => ({ reference: l.reference, name: l.name, quantity: l.quantity, unit: l.unit })),
    });
    return reply.type('application/pdf').header('Content-Disposition', `inline; filename="${full.number ?? 'bon-de-sortie'}.pdf"`).send(pdf);
  });
}
