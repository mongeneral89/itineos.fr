/**
 * Annuaire : les numéros de l'entreprise (sociétés, agences), ceux des salariés (renseignés dans leur compte)
 * et les contacts extérieurs utiles (fournisseurs, sous-traitants, assistance des fabricants, urgences…).
 *
 * Tout le monde le consulte ; les contacts extérieurs se gèrent avec le droit « directory.write »
 * sur leur périmètre (tout le groupe, une société ou une agence).
 */
import type { FastifyInstance } from 'fastify';
import { and, asc, eq } from 'drizzle-orm';
import { z } from 'zod';
import { DIRECTORY_CATEGORIES, ROLE_LABELS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { can, canGroupWide, type Principal } from '../auth/access.js';
import { badRequest, forbidden, notFound } from '../http.js';
import { getAgency, getCompany } from '../services/org.js';
import { audit } from '../services/audit.js';

const dc = schema.directoryContacts;
const opt = z.string().trim().max(500).optional().nullable().transform((s) => (s ? s : null));

const contactBody = z.object({
  companyId: z.string().uuid().nullable().default(null),
  agencyId: z.string().uuid().nullable().default(null),
  category: z.enum(DIRECTORY_CATEGORIES).default('OTHER'),
  name: z.string().trim().min(1, 'Indiquez un nom').max(120),
  organization: opt,
  phone: opt,
  mobile: opt,
  email: z.string().trim().email().optional().nullable().or(z.literal('').transform(() => null)).transform((s) => s || null),
  address: opt,
  website: opt,
  notes: z.string().trim().max(2000).optional().nullable().transform((s) => (s ? s : null)),
});

/** Peut-il gérer un contact rattaché à ce périmètre ? (vide = tout le groupe) */
function canWrite(p: Principal, companyId: string | null, agencyId: string | null): boolean {
  if (!companyId) return canGroupWide(p, 'directory.write');
  return can(p, 'directory.write', { companyId, agencyId });
}

async function checkScope(p: Principal, companyId: string | null, agencyId: string | null) {
  if (agencyId && !companyId) throw badRequest('Une agence doit être accompagnée de sa société');
  if (companyId) {
    const company = await getCompany(p.groupId, companyId);
    if (!company) throw badRequest('Société inconnue');
    if (agencyId && !(await getAgency(company.id, agencyId))) throw badRequest('Agence inconnue');
  }
  if (!canWrite(p, companyId, agencyId)) throw forbidden();
}

export async function directoryRoutes(app: FastifyInstance) {
  app.addHook('preHandler', app.authenticate);

  /** Tout l'annuaire du groupe : standards, salariés, contacts extérieurs */
  app.get('/directory', async (req) => {
    const p = req.principal;
    const companies = await db.select({
      id: schema.companies.id, name: schema.companies.name, phone: schema.companies.phone, email: schema.companies.email,
      address: schema.companies.address, postalCode: schema.companies.postalCode, city: schema.companies.city,
    }).from(schema.companies).where(and(eq(schema.companies.groupId, p.groupId), eq(schema.companies.active, true))).orderBy(asc(schema.companies.name));
    const agencies = await db.select({
      id: schema.agencies.id, companyId: schema.agencies.companyId, name: schema.agencies.name, phone: schema.agencies.phone,
      email: schema.agencies.email, address: schema.agencies.address, postalCode: schema.agencies.postalCode, city: schema.agencies.city,
    }).from(schema.agencies)
      .innerJoin(schema.companies, eq(schema.companies.id, schema.agencies.companyId))
      .where(and(eq(schema.companies.groupId, p.groupId), eq(schema.agencies.active, true)))
      .orderBy(asc(schema.agencies.name));

    const u = schema.users;
    const ra = schema.roleAssignments;
    const rows = await db.select({
      id: u.id, firstName: u.firstName, lastName: u.lastName, phone: u.phone, email: u.email, skills: u.skills,
      role: ra.role, companyId: ra.companyId, agencyId: ra.agencyId,
    }).from(u).leftJoin(ra, eq(ra.userId, u.id))
      .where(and(eq(u.groupId, p.groupId), eq(u.active, true)))
      .orderBy(asc(u.lastName), asc(u.firstName));
    const staff = new Map<string, { id: string; firstName: string; lastName: string; phone: string | null; email: string; skills: string[]; roles: string[]; companyIds: string[]; agencyIds: string[] }>();
    for (const r of rows) {
      const s = staff.get(r.id) ?? { id: r.id, firstName: r.firstName, lastName: r.lastName, phone: r.phone, email: r.email, skills: r.skills, roles: [], companyIds: [], agencyIds: [] };
      if (r.role && !s.roles.includes(ROLE_LABELS[r.role])) s.roles.push(ROLE_LABELS[r.role]);
      if (r.companyId && !s.companyIds.includes(r.companyId)) s.companyIds.push(r.companyId);
      if (r.agencyId && !s.agencyIds.includes(r.agencyId)) s.agencyIds.push(r.agencyId);
      staff.set(r.id, s);
    }

    const contacts = await db.select().from(dc).where(eq(dc.groupId, p.groupId)).orderBy(asc(dc.category), asc(dc.name));
    return {
      companies, agencies, staff: [...staff.values()],
      contacts: contacts.map((x) => ({ ...x, canEdit: canWrite(p, x.companyId, x.agencyId) })),
    };
  });

  app.post('/directory/contacts', async (req, reply) => {
    const p = req.principal;
    const body = contactBody.parse(req.body);
    await checkScope(p, body.companyId, body.agencyId);
    const [row] = await db.insert(dc).values({ ...body, groupId: p.groupId, createdBy: p.userId }).returning();
    await audit(p, 'create', 'directory_contact', row.id, { name: row.name });
    return reply.code(201).send(row);
  });

  app.patch('/directory/contacts/:id', async (req) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(dc).where(and(eq(dc.id, id), eq(dc.groupId, p.groupId)));
    if (!current) throw notFound('Contact');
    if (!canWrite(p, current.companyId, current.agencyId)) throw forbidden();
    const body = contactBody.parse(req.body);
    await checkScope(p, body.companyId, body.agencyId);
    const [row] = await db.update(dc).set({ ...body, updatedAt: new Date() }).where(eq(dc.id, id)).returning();
    await audit(p, 'update', 'directory_contact', id, { name: row.name });
    return row;
  });

  app.delete('/directory/contacts/:id', async (req, reply) => {
    const p = req.principal;
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    const [current] = await db.select().from(dc).where(and(eq(dc.id, id), eq(dc.groupId, p.groupId)));
    if (!current) throw notFound('Contact');
    if (!canWrite(p, current.companyId, current.agencyId)) throw forbidden();
    await db.delete(dc).where(eq(dc.id, id));
    await audit(p, 'delete', 'directory_contact', id, { name: current.name });
    return reply.code(204).send();
  });
}
