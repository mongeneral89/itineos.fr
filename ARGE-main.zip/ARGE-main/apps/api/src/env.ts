import 'dotenv/config';
import { z } from 'zod';
import { productName, SECTORS } from '@itineo/shared';

const schema = z.object({
  DATABASE_URL: z.string().default('postgres://itineo:itineo@localhost:5432/itineo'),
  JWT_SECRET: z.string().min(16, 'JWT_SECRET doit faire au moins 16 caractères'),
  PORT: z.coerce.number().default(3000),
  /** Adresse d'écoute : 127.0.0.1 quand un proxy (Caddy) est devant, sur la même machine */
  HOST: z.string().default('0.0.0.0'),
  WEB_ORIGIN: z.string().default('http://localhost:5173'),
  SMTP_URL: z.string().optional(),
  MAIL_FROM: z.string().optional(),
  STORAGE_DIR: z.string().default('./storage'),
  // Derrière un proxy (Caddy en production) : lire l'adresse réelle du visiteur dans X-Forwarded-For.
  // À n'activer QUE derrière un proxy, sinon n'importe qui pourrait choisir son adresse.
  TRUST_PROXY: z.enum(['true', 'false']).default('false').transform((v) => v === 'true'),
  /**
   * Édition installée : chaque secteur est un logiciel à part (Itinéos Vigie, Itinéos Constat…).
   * Toutes les sociétés de cette installation sont de ce secteur. Doit être la même que celle de l'appli web.
   */
  EDITION: z.enum(SECTORS).default('TECH'),
  /**
   * Console de supervision (voir apps/supervision) : adresse de la console et code d'inscription donné par elle.
   * Sans SUPERVISION_URL, l'agent ne fait rien.
   */
  SUPERVISION_URL: z.string().url().optional().or(z.literal('').transform(() => undefined)),
  SUPERVISION_CODE: z.string().optional(),
  /** Fichier où l'agent garde son identité (identifiant, secret, clé publique) et ce qui reste à transmettre */
  SUPERVISION_STATE: z.string().optional(),
  /** Installation Windows : journaux, sauvegardes, paquets de mise à jour, réglages (itineo.env), RustDesk */
  LOG_DIR: z.string().optional(),
  BACKUP_DIR: z.string().optional(),
  UPDATE_DIR: z.string().optional(),
  ITINEO_ENV_FILE: z.string().optional(),
  RUSTDESK_PATH: z.string().optional(),
});

const PRODUCTION = process.env.NODE_ENV === 'production';
const DEV_SECRET = 'dev-secret-a-changer-en-production';
/** Valeurs d'exemple publiées (code, .env.example) : quiconque les connaît peut fabriquer une session */
const KNOWN_SECRETS = [DEV_SECRET, 'changez-moi-par-une-longue-chaine-aleatoire'];

const parsed = schema.parse({
  ...process.env,
  JWT_SECRET: process.env.JWT_SECRET ?? (PRODUCTION ? undefined : DEV_SECRET),
});

// En production : un secret long (openssl rand -base64 32 en donne 44 caractères) et jamais une valeur d'exemple
if (PRODUCTION) {
  if (parsed.JWT_SECRET.length < 32) throw new Error('JWT_SECRET doit faire au moins 32 caractères en production (openssl rand -base64 32)');
  if (KNOWN_SECRETS.includes(parsed.JWT_SECRET)) throw new Error("JWT_SECRET est encore la valeur d'exemple : remplacez-la par une longue chaîne aléatoire");
}

/** Nom du logiciel installé, repris dans les e-mails et les notifications : « Itinéos Vigie » */
export const PRODUCT_NAME = productName(parsed.EDITION);

export const env = { ...parsed, MAIL_FROM: parsed.MAIL_FROM || `${PRODUCT_NAME} <no-reply@itineos.local>` };
