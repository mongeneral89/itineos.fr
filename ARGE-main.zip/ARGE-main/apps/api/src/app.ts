import Fastify, { type FastifyRequest } from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import { ZodError } from 'zod';
import { env } from './env.js';
import { registerAuth } from './auth/plugin.js';
import { HttpError, redactUrl } from './http.js';
import { authRoutes } from './routes/auth.js';
import { orgRoutes } from './routes/org.js';
import { userRoutes } from './routes/users.js';
import { clientRoutes } from './routes/clients.js';
import { interventionRoutes } from './routes/interventions.js';
import { reportRoutes } from './routes/reports.js';
import { templateRoutes } from './routes/templates.js';
import { dashboardRoutes } from './routes/dashboard.js';
import { quoteRoutes } from './routes/quotes.js';
import { contractRoutes } from './routes/contracts.js';
import { invoiceRoutes } from './routes/invoices.js';
import { stockRoutes } from './routes/stock.js';
import { certificationRoutes } from './routes/certifications.js';
import { fleetRoutes } from './routes/fleet.js';
import { portalRoutes } from './routes/portal.js';
import { positionRoutes } from './routes/positions.js';
import { messageRoutes } from './routes/messages.js';
import { directoryRoutes } from './routes/directory.js';
import { procedureRoutes } from './routes/procedures.js';
import { simRoutes } from './routes/sims.js';
import { statsRoutes } from './routes/stats.js';
import { assignRoutes } from './routes/assign.js';
import { teamPlanningRoutes } from './routes/team-planning.js';
import { notificationRoutes } from './routes/notifications.js';
import { sectorRoutes } from './routes/sector.js';
import { logoRoutes } from './routes/logos.js';
import { supportRoutes } from './routes/support.js';
import { sepaRoutes } from './routes/sepa.js';
import { dunningRoutes } from './routes/dunning.js';
import { syncRoutes } from './routes/sync.js';
import { reportServerError } from './services/supervision.js';
import { appUpdateRoutes } from './routes/app-update.js';
import { invitationRoutes } from './routes/invitations.js';


export async function buildApp(opts: { logger?: boolean } = {}) {
  const app = Fastify({
    logger: (opts.logger ?? true) && {
      serializers: {
        req: (req: FastifyRequest) => ({ method: req.method, url: redactUrl(req.url), host: req.host, remoteAddress: req.ip }),
      },
    },
    bodyLimit: 5 * 1024 * 1024, // signatures en image
    trustProxy: env.TRUST_PROXY,
  });

  await app.register(cors, { origin: env.WEB_ORIGIN.split(',').map((s) => s.trim()) });
  await app.register(jwt, { secret: env.JWT_SECRET });
  registerAuth(app);

  app.setErrorHandler((err, req, reply) => {
    if (err instanceof ZodError) {
      return reply.code(400).send({
        error: 'Données invalides',
        issues: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
      });
    }
    if (err instanceof HttpError) {
      return reply.code(err.statusCode).send({ error: err.message, details: err.details });
    }
    const status = (err as { statusCode?: number }).statusCode;
    if (status && status < 500) return reply.code(status).send({ error: (err as Error).message });
    req.log.error(err);
    // Envoyée à la console de supervision (si elle est configurée) : la route, jamais le contenu de la requête
    reportServerError(err, `${req.method} ${req.routeOptions.url ?? '?'}`);
    return reply.code(500).send({ error: 'Erreur interne du serveur' });
  });

  app.get('/api/health', async () => ({ ok: true }));

  await app.register(async (api) => {
    await api.register(authRoutes);
    await api.register(orgRoutes);
    await api.register(userRoutes);
    await api.register(clientRoutes);
    await api.register(interventionRoutes);
    await api.register(reportRoutes);
    await api.register(templateRoutes);
    await api.register(dashboardRoutes);
    await api.register(quoteRoutes);
    await api.register(contractRoutes);
    await api.register(invoiceRoutes);
    await api.register(stockRoutes);
    await api.register(certificationRoutes);
    await api.register(fleetRoutes);
    await api.register(portalRoutes);
    await api.register(positionRoutes);
    await api.register(messageRoutes);
    await api.register(directoryRoutes);
    await api.register(procedureRoutes);
    await api.register(simRoutes);
    await api.register(statsRoutes);
    await api.register(assignRoutes);
    await api.register(teamPlanningRoutes);
    await api.register(notificationRoutes);
    await api.register(sectorRoutes);
    await api.register(logoRoutes);
    await api.register(supportRoutes);
    await api.register(sepaRoutes);
    await api.register(dunningRoutes);
    await api.register(syncRoutes);
    await api.register(appUpdateRoutes);
    await api.register(invitationRoutes);
  }, { prefix: '/api' });

  return app;
}
