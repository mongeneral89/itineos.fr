/**
 * Suggestion d'attribution : quel technicien envoyer sur une intervention ?
 *
 * Ce n'est qu'une suggestion, affichée au planificateur qui décide. Fonction à activer par société.
 * Critères, pesés selon la priorité de l'intervention :
 *  - la distance : position en direct du véhicule (si le technicien partage sa position et que c'est
 *    aujourd'hui), sinon ses autres interventions de la journée ;
 *  - la charge de la journée (et les chevauchements avec le créneau prévu) ;
 *  - le matériel à sortir : ce que son véhicule a en stock ;
 *  - les habilitations exigées (un technicien non habilité n'est jamais proposé en premier).
 * Une urgence privilégie le plus proche ; une intervention ordinaire, le moins chargé.
 */
import { and, eq, gte, inArray, isNull, lt, ne, or } from 'drizzle-orm';
import type { Priority } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { localDayStart } from './positions.js';
import { missingCertifications } from './certifications.js';
import { locateSite } from './geocode.js';

/** Au-delà, la distance ne rapporte plus de points */
export const MAX_USEFUL_KM = 80;
/** Journée pleine */
export const FULL_DAY_MIN = 8 * 60;
/** Une position plus ancienne n'est plus « en direct » */
export const LIVE_POSITION_MAX_MIN = 90;

const WEIGHTS: Record<Priority, { distance: number; load: number; stock: number }> = {
  URGENT: { distance: 0.55, load: 0.15, stock: 0.3 },
  HIGH: { distance: 0.45, load: 0.25, stock: 0.3 },
  NORMAL: { distance: 0.3, load: 0.4, stock: 0.3 },
  LOW: { distance: 0.2, load: 0.5, stock: 0.3 },
};

export interface CandidateFacts {
  distanceKm: number | null;
  loadMinutes: number;
  conflicts: number;
  /** Part du matériel à prévoir présente dans le véhicule (0 à 1), null si rien à prévoir */
  stockCoverage: number | null;
  missingCerts: number;
}

/** Distance à vol d'oiseau entre deux points, en km */
export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const rad = (x: number) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Temps de route estimé (détours compris, 50 km/h de moyenne) */
export const driveMinutes = (km: number) => Math.round((km * 1.3 * 60) / 50);

/**
 * Note de 0 à 100. Les critères inconnus pour tout le monde (pas de matériel à prévoir, aucune position connue)
 * ne comptent pas : leur poids est reporté sur les autres. Un technicien non habilité ou déjà pris sur le
 * créneau garde une note, mais passe derrière les autres.
 */
export function scoreCandidate(f: CandidateFacts, priority: Priority, ctx: { anyDistance: boolean; anyParts: boolean }): number {
  const w = { ...WEIGHTS[priority] };
  if (!ctx.anyParts) w.stock = 0;
  if (!ctx.anyDistance) w.distance = 0;
  const total = w.distance + w.load + w.stock || 1;
  const distance = f.distanceKm == null ? 0.4 : Math.max(0, 1 - f.distanceKm / MAX_USEFUL_KM);
  const load = Math.max(0, 1 - f.loadMinutes / FULL_DAY_MIN);
  const stock = f.stockCoverage ?? 1;
  let score = ((w.distance * distance + w.load * load + w.stock * stock) / total) * 100;
  if (f.conflicts > 0) score -= 40;
  if (f.missingCerts > 0) score -= 60;
  return Math.max(0, Math.min(100, Math.round(score)));
}

export interface Suggestion {
  technicianId: string;
  name: string;
  score: number;
  distanceKm: number | null;
  driveMinutes: number | null;
  /** D'où est mesurée la distance : position en direct, ou une autre intervention de la journée */
  distanceFrom: { kind: 'LIVE'; minutesAgo: number } | { kind: 'JOB'; number: string; clientName: string; time: string | null } | null;
  loadMinutes: number;
  jobs: number;
  conflicts: { number: string; start: string; end: string | null }[];
  missingCerts: string[];
  stock: { needed: number; covered: number; missing: { name: string; quantity: number; available: number }[] } | null;
  current: boolean;
}

export interface SuggestionResult {
  day: string;
  slot: { start: string; end: string } | null;
  siteLocated: boolean;
  neededParts: { articleId: string; reference: string; name: string; quantity: number }[];
  candidates: Suggestion[];
}

/** Jour (AAAA-MM-JJ) d'un instant dans un fuseau */
export function dayIn(d: Date, tz: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

/** Jour proposé quand l'intervention n'a pas de date : aujourd'hui si elle presse, sinon le prochain jour ouvré */
export function defaultDay(priority: Priority, now: Date, tz: string): string {
  if (priority === 'URGENT' || priority === 'HIGH') return dayIn(now, tz);
  const d = new Date(now.getTime() + 24 * 3600_000);
  while ([0, 6].includes(new Date(`${dayIn(d, tz)}T12:00:00Z`).getUTCDay())) d.setTime(d.getTime() + 24 * 3600_000);
  return dayIn(d, tz);
}

/** Pièces à prévoir : la liste saisie sur l'intervention + les bons de sortie en préparation qui lui sont liés */
async function neededParts(interventionId: string, listed: { articleId: string; quantity: number }[]) {
  const need = new Map<string, number>();
  for (const p of listed) need.set(p.articleId, (need.get(p.articleId) ?? 0) + p.quantity);
  const slips = await db.select({ articleId: schema.stockSlipLines.articleId, quantity: schema.stockSlipLines.quantity })
    .from(schema.stockSlipLines)
    .innerJoin(schema.stockSlips, eq(schema.stockSlips.id, schema.stockSlipLines.slipId))
    .where(and(eq(schema.stockSlips.interventionId, interventionId), eq(schema.stockSlips.status, 'DRAFT')));
  for (const l of slips) need.set(l.articleId, (need.get(l.articleId) ?? 0) + l.quantity);
  if (!need.size) return [];
  const arts = await db.select({ id: schema.articles.id, reference: schema.articles.reference, name: schema.articles.name })
    .from(schema.articles).where(inArray(schema.articles.id, [...need.keys()]));
  return arts.map((a) => ({ articleId: a.id, reference: a.reference, name: a.name, quantity: need.get(a.id) ?? 0 }));
}

export async function suggestTechnicians(interventionId: string, opts: { day?: string; now?: Date; geocode?: boolean } = {}): Promise<SuggestionResult> {
  const now = opts.now ?? new Date();
  const iv = schema.interventions;
  const [job] = await db.select().from(iv).where(eq(iv.id, interventionId));
  if (!job) throw new Error('Intervention introuvable');
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, job.companyId));
  const tz = company?.timezone ?? 'Europe/Paris';

  // Jour et créneau visés
  const day = opts.day ?? (job.scheduledStart ? dayIn(job.scheduledStart, tz) : defaultDay(job.priority, now, tz));
  const slot = job.scheduledStart && (!opts.day || opts.day === dayIn(job.scheduledStart, tz))
    ? { start: job.scheduledStart, end: job.scheduledEnd ?? new Date(job.scheduledStart.getTime() + 3600_000) }
    : null;
  const from = localDayStart(day, tz);
  const to = new Date(from.getTime() + 24 * 3600_000 + 2 * 3600_000); // marge pour les jours de changement d'heure

  // Techniciens possibles, actifs
  const ra = schema.roleAssignments;
  const techRows = await db.selectDistinct({ id: schema.users.id, firstName: schema.users.firstName, lastName: schema.users.lastName })
    .from(ra).innerJoin(schema.users, eq(schema.users.id, ra.userId))
    .where(and(
      eq(ra.role, 'TECHNICIAN'), eq(schema.users.active, true), eq(schema.users.groupId, job.groupId),
      // Mêmes règles que pour attribuer : technicien de la société, sur cette agence ou sur toute la société
      eq(ra.companyId, job.companyId), or(isNull(ra.agencyId), eq(ra.agencyId, job.agencyId)),
    ));
  const techIds = techRows.map((t) => t.id);
  const parts = await neededParts(job.id, job.neededParts ?? []);
  if (!techIds.length) return { day, slot: slot ? { start: slot.start.toISOString(), end: slot.end.toISOString() } : null, siteLocated: false, neededParts: parts, candidates: [] };

  // Coordonnées du site visé
  let target: { lat: number; lng: number } | null = null;
  const [site] = await db.select().from(schema.sites).where(eq(schema.sites.id, job.siteId));
  if (site?.latitude != null && site.longitude != null) target = { lat: site.latitude, lng: site.longitude };
  else if (opts.geocode) target = await locateSite(job.siteId);

  // Interventions de la journée de chaque technicien
  const dayJobs = await db.select({
    id: iv.id, number: iv.number, technicianId: iv.technicianId, start: iv.scheduledStart, end: iv.scheduledEnd, siteId: iv.siteId,
    clientName: schema.clients.name, lat: schema.sites.latitude, lng: schema.sites.longitude,
  }).from(iv)
    .innerJoin(schema.clients, eq(schema.clients.id, iv.clientId))
    .innerJoin(schema.sites, eq(schema.sites.id, iv.siteId))
    .where(and(inArray(iv.technicianId, techIds), gte(iv.scheduledStart, from), lt(iv.scheduledStart, to), ne(iv.status, 'CANCELLED'), ne(iv.id, job.id)));
  const inDay = dayJobs.filter((j) => j.start && dayIn(j.start, tz) === day);
  // Sites de la journée sans coordonnées : localisés aussi (10 au plus par calcul)
  if (target && opts.geocode) {
    let budget = 10;
    for (const j of inDay) {
      if (j.lat != null || budget-- <= 0) continue;
      const c = await locateSite(j.siteId);
      if (c) Object.assign(j, { lat: c.lat, lng: c.lng });
    }
  }

  // Position en direct (seulement si l'on regarde aujourd'hui)
  const today = day === dayIn(now, tz);
  const vehicles = await db.select({ driverId: schema.vehicles.driverId, lat: schema.vehicles.lastLat, lng: schema.vehicles.lastLng, at: schema.vehicles.lastPositionAt, stockLocationId: schema.vehicles.stockLocationId })
    .from(schema.vehicles).where(and(inArray(schema.vehicles.driverId, techIds), eq(schema.vehicles.status, 'ACTIVE')));

  // Stock des véhicules : lieux « véhicule » du technicien, et le stock du véhicule qu'il conduit
  const locs = await db.select({ id: schema.stockLocations.id, technicianId: schema.stockLocations.technicianId })
    .from(schema.stockLocations).where(and(inArray(schema.stockLocations.technicianId, techIds), eq(schema.stockLocations.active, true)));
  const locOwner = new Map<string, string>();
  for (const l of locs) if (l.technicianId) locOwner.set(l.id, l.technicianId);
  for (const v of vehicles) if (v.stockLocationId && v.driverId) locOwner.set(v.stockLocationId, v.driverId);
  const levels = parts.length && locOwner.size
    ? await db.select().from(schema.stockLevels).where(and(inArray(schema.stockLevels.locationId, [...locOwner.keys()]), inArray(schema.stockLevels.articleId, parts.map((p) => p.articleId))))
    : [];

  const candidates: Suggestion[] = [];
  for (const t of techRows) {
    const mine = inDay.filter((j) => j.technicianId === t.id).sort((a, b) => a.start!.getTime() - b.start!.getTime());
    const minutes = (j: { start: Date | null; end: Date | null }) => (j.end && j.start ? Math.max(15, (j.end.getTime() - j.start.getTime()) / 60000) : 60);
    const loadMinutes = Math.round(mine.reduce((s, j) => s + minutes(j), 0));
    const conflicts = slot
      ? mine.filter((j) => j.start! < slot.end && new Date(j.start!.getTime() + minutes(j) * 60000) > slot.start)
      : [];

    // Distance : la plus courte entre la position en direct et les interventions voisines de la journée
    let best: { km: number; from: Suggestion['distanceFrom'] } | null = null;
    if (target) {
      const v = vehicles.find((x) => x.driverId === t.id);
      if (today && v?.lat != null && v.lng != null && v.at && now.getTime() - v.at.getTime() <= LIVE_POSITION_MAX_MIN * 60000) {
        best = { km: haversineKm({ lat: v.lat, lng: v.lng }, target), from: { kind: 'LIVE', minutesAgo: Math.max(0, Math.round((now.getTime() - v.at.getTime()) / 60000)) } };
      }
      // Avec un créneau : l'intervention juste avant et celle juste après ; sans créneau : toutes celles du jour
      const near = slot
        ? [mine.filter((j) => j.start! <= slot.start).pop(), mine.find((j) => j.start! > slot.start)].filter((j): j is (typeof mine)[number] => !!j)
        : mine;
      for (const j of near) {
        if (j.lat == null || j.lng == null) continue;
        const km = haversineKm({ lat: j.lat, lng: j.lng }, target);
        if (!best || km < best.km) best = { km, from: { kind: 'JOB', number: j.number, clientName: j.clientName, time: j.start?.toISOString() ?? null } };
      }
    }

    let stock: Suggestion['stock'] = null;
    if (parts.length) {
      const have = new Map<string, number>();
      for (const l of levels) if (locOwner.get(l.locationId) === t.id) have.set(l.articleId, (have.get(l.articleId) ?? 0) + l.quantity);
      const needed = parts.reduce((s, p) => s + p.quantity, 0);
      const covered = parts.reduce((s, p) => s + Math.min(p.quantity, Math.max(0, have.get(p.articleId) ?? 0)), 0);
      stock = {
        needed, covered,
        missing: parts.filter((p) => (have.get(p.articleId) ?? 0) < p.quantity)
          .map((p) => ({ name: `${p.reference} · ${p.name}`, quantity: p.quantity, available: Math.max(0, have.get(p.articleId) ?? 0) })),
      };
    }

    const missing = await missingCertifications(t.id, job.requiredCertificationIds ?? [], day);
    candidates.push({
      technicianId: t.id, name: `${t.firstName} ${t.lastName}`, score: 0,
      distanceKm: best ? Math.round(best.km * 10) / 10 : null,
      driveMinutes: best ? driveMinutes(best.km) : null,
      distanceFrom: best?.from ?? null,
      loadMinutes, jobs: mine.length,
      conflicts: conflicts.map((j) => ({ number: j.number, start: j.start!.toISOString(), end: j.end?.toISOString() ?? null })),
      missingCerts: missing.map((m) => m.name),
      stock, current: job.technicianId === t.id,
    });
  }

  const ctx = { anyDistance: candidates.some((c) => c.distanceKm != null), anyParts: parts.length > 0 };
  for (const c of candidates) {
    c.score = scoreCandidate({
      distanceKm: c.distanceKm, loadMinutes: c.loadMinutes, conflicts: c.conflicts.length,
      stockCoverage: c.stock ? (c.stock.needed ? c.stock.covered / c.stock.needed : 1) : null, missingCerts: c.missingCerts.length,
    }, job.priority, ctx);
  }
  candidates.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  return {
    day, slot: slot ? { start: slot.start.toISOString(), end: slot.end.toISOString() } : null,
    siteLocated: !!target, neededParts: parts, candidates,
  };
}
