/**
 * Agent de supervision : relie cette installation d'Itinéos à la console de l'éditeur (apps/supervision).
 *
 * Chaque minute, il envoie l'état de l'installation (base, disque, sauvegarde, erreurs, activité), les bugs
 * (erreurs du serveur et problèmes signalés par les utilisateurs) et le résultat des ordres reçus ; il reçoit en
 * retour les ordres de la console : redémarrer, journaux, mise à jour (paquet signé, installée la nuit), réglages,
 * accès support (à accepter par l'administrateur du client), prise en main du PC (RustDesk).
 *
 * C'est toujours l'agent qui appelle la console (rien à ouvrir chez le client). Sans SUPERVISION_URL, rien ne se passe.
 * Aucune donnée des clients du client n'est envoyée : seulement des compteurs, des erreurs techniques et les journaux
 * quand on les demande.
 */
import { createHash, randomBytes, verify as verifySignature, createPublicKey } from 'node:crypto';
import { execFile } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdir, readdir, readFile, rename, stat, statfs, unlink, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import bcrypt from 'bcryptjs';
import { and, eq, gte, lt, sql } from 'drizzle-orm';
import { db, schema } from '../db/client.js';
import { env } from '../env.js';
import { APP_ROOT } from '../paths.js';
import { softwareFingerprint } from './integrity.js';

const run = promisify(execFile);
const ROOT = APP_ROOT;
const STATE_FILE = env.SUPERVISION_STATE ?? path.resolve(env.STORAGE_DIR, '..', 'supervision.json');
export const SUPPORT_EMAIL = 'support@supervision.itineo';
// Noms des tâches planifiées créées par l'installateur : gardés tels quels (installations existantes)
const UPDATE_TASK = 'Itinéo – mise à jour';
const RECONFIGURE_TASK = 'Itinéo – reconfigurer';

interface Result { commandId: string; ok: boolean; final?: boolean; result?: Record<string, unknown> }
interface State {
  installationId?: string;
  secret?: string;
  /** Ancienne forme : une seule clé (remplacée par publicKeys) */
  publicKey?: string;
  /** Clés de signature de confiance : la principale de la console et sa clé de secours */
  publicKeys?: string[];
  /** Serveur RustDesk réglé par la console (appliqué une fois) */
  remoteServer?: { server: string; key: string } | null;
  results: Result[];
  pendingUpdate?: { commandId: string; version: string; file: string; when: 'night' | 'now' } | null;
  remoteSession?: { until: string; commandId?: string } | null;
  /** Accès support et prises en main terminés : la console efface alors le mot de passe affiché */
  closed?: string[];
}
interface Bug { fingerprint: string; source: 'auto' | 'user'; title: string; message?: string | null; detail?: Record<string, unknown>; occurrences: number; at: string }
interface Command { id: string; kind: string; payload: Record<string, unknown> }

let state: State = { results: [] };
const bugs = new Map<string, Bug>();
const errorTimes: number[] = [];
let timer: NodeJS.Timeout | null = null;
let intervalMs = 60_000;
let running = false;
let version = '0.0.0';
let remoteIdCache: { id: string | null; at: number } | null = null;

export const supervisionEnabled = () => !!env.SUPERVISION_URL;

// ─── Bugs ────────────────────────────────────────────────────────────────

const fingerprintOf = (...parts: string[]) => createHash('sha1').update(parts.join('|')).digest('hex').slice(0, 20);

function queueBug(b: Omit<Bug, 'occurrences' | 'at'>) {
  if (!supervisionEnabled()) return;
  const prev = bugs.get(b.fingerprint);
  bugs.set(b.fingerprint, { ...b, occurrences: (prev?.occurrences ?? 0) + 1, at: new Date().toISOString() });
}

/** Erreur 500 du serveur : regroupée par type d'erreur, endroit du code et route (jamais le contenu de la requête) */
export function reportServerError(err: unknown, route?: string) {
  const now = Date.now();
  errorTimes.push(now);
  while (errorTimes.length && now - errorTimes[0] > 3_600_000) errorTimes.shift();
  const e = err instanceof Error ? err : new Error(String(err));
  const stack = (e.stack ?? '').split('\n').slice(0, 15).map((l) => l.replace(ROOT, '…')).join('\n');
  const where = stack.split('\n').find((l) => l.includes('/src/') || l.includes('\\src\\')) ?? stack.split('\n')[1] ?? '';
  queueBug({
    fingerprint: fingerprintOf(e.name, where.trim(), route ?? ''),
    source: 'auto',
    title: `${e.name} : ${e.message.slice(0, 160)}`,
    message: route ?? null,
    detail: { route: route ?? null, stack },
  });
}

/** « Signaler un problème » dans Itinéos : envoyé tel quel à la console */
export function reportUserProblem(p: { message: string; page?: string; userName: string; userEmail: string; userAgent?: string }) {
  queueBug({
    fingerprint: fingerprintOf('user', randomBytes(8).toString('hex')),
    source: 'user',
    title: `${p.userName} : ${p.message.slice(0, 120)}`,
    message: p.message,
    detail: { page: p.page ?? null, user: `${p.userName} <${p.userEmail}>`, userAgent: p.userAgent ?? null },
  });
}

// ─── État de l'installation ──────────────────────────────────────────────

async function lastBackupAt(): Promise<string | null | undefined> {
  if (!env.BACKUP_DIR) return undefined;
  try {
    const files = (await readdir(env.BACKUP_DIR)).filter((f) => f.startsWith('itineo-base-'));
    let latest = 0;
    for (const f of files) latest = Math.max(latest, (await stat(path.join(env.BACKUP_DIR, f))).mtimeMs);
    return latest ? new Date(latest).toISOString() : null;
  } catch {
    return null;
  }
}

function rustdeskPath(): string | null {
  const candidates = [env.RUSTDESK_PATH, 'C:\\Program Files\\RustDesk\\rustdesk.exe'].filter((x): x is string => !!x);
  return candidates.find((p) => existsSync(p)) ?? null;
}

async function remoteId(): Promise<string | null> {
  const exe = rustdeskPath();
  if (!exe) return null;
  if (remoteIdCache && Date.now() - remoteIdCache.at < 3_600_000) return remoteIdCache.id;
  try {
    const { stdout } = await run(exe, ['--get-id'], { timeout: 15_000, windowsHide: true });
    remoteIdCache = { id: stdout.trim() || null, at: Date.now() };
  } catch {
    remoteIdCache = { id: null, at: Date.now() };
  }
  return remoteIdCache.id;
}

/** Empreinte des fichiers installés : recalculée toutes les 15 minutes (lire les fichiers prend un peu de temps) */
let integrityCache: { at: number; value: { fingerprint: string; files: number } | null } | null = null;
async function integrity() {
  if (!integrityCache || Date.now() - integrityCache.at > 15 * 60_000) {
    integrityCache = { at: Date.now(), value: await softwareFingerprint().catch(() => null) };
  }
  return integrityCache.value;
}

export async function collectStatus() {
  const database: { ok: boolean; sizeBytes?: number; error?: string } = { ok: true };
  let activity: Record<string, number> | undefined;
  try {
    const res = await db.execute<{ size: string }>(sql`SELECT pg_database_size(current_database())::text AS size`);
    database.sizeBytes = Number(res.rows[0].size);
    const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart.getTime() + 86_400_000);
    const [{ users }] = await db.select({ users: sql<number>`count(*)::int` }).from(schema.users).where(eq(schema.users.active, true));
    const [{ jobs }] = await db.select({ jobs: sql<number>`count(*)::int` }).from(schema.interventions)
      .where(and(gte(schema.interventions.scheduledStart, dayStart), lt(schema.interventions.scheduledStart, dayEnd)));
    const [{ signed }] = await db.select({ signed: sql<number>`count(*)::int` }).from(schema.reports)
      .where(gte(schema.reports.signedAt, dayStart));
    activity = { users, interventionsToday: jobs, reportsSignedToday: signed };
  } catch (err) {
    database.ok = false;
    database.error = (err as Error).message.slice(0, 200);
  }
  let disk: { freeBytes: number; totalBytes: number } | null = null;
  try {
    const s = await statfs(path.resolve(env.STORAGE_DIR));
    disk = { freeBytes: s.bavail * s.bsize, totalBytes: s.blocks * s.bsize };
  } catch { /* disque illisible : non renseigné */ }
  const exe = rustdeskPath();
  return {
    version,
    edition: env.EDITION,
    uptimeSeconds: Math.round(process.uptime()),
    database,
    disk,
    lastBackupAt: await lastBackupAt(),
    errorsLastHour: errorTimes.filter((t) => Date.now() - t < 3_600_000).length,
    memoryBytes: process.memoryUsage().rss,
    activity,
    pendingUpdate: state.pendingUpdate?.version ?? null,
    remote: { available: !!exe, id: exe ? await remoteId() : null },
    integrity: await integrity(),
  };
}

// ─── Clés de signature et serveur RustDesk envoyés par la console ───────

interface AgentConfig {
  keys?: { signing: string; backup: { publicKeyPem: string; endorsement: string } | null };
  remoteServer?: { server: string; key: string } | null;
}

const trustedKeys = () => state.publicKeys ?? (state.publicKey ? [state.publicKey] : []);

/**
 * Clés de confiance : la console envoie sa clé principale et sa clé de secours « recommandée » par elle. La liste n'est
 * remplacée que si la clé principale est déjà connue et que la recommandation est valide : après une restauration de
 * la clé de secours, l'ancienne clé principale (perdue ou volée) est ainsi oubliée.
 */
export function nextTrustedKeys(trusted: string[], keys: AgentConfig['keys']): string[] {
  if (!keys?.signing || !trusted.includes(keys.signing) || !keys.backup) return trusted;
  const message = Buffer.from(`cle-secours|${keys.backup.publicKeyPem.trim()}`, 'utf8');
  try {
    if (!verifySignature(null, message, createPublicKey(keys.signing), Buffer.from(keys.backup.endorsement, 'base64'))) return trusted;
  } catch {
    return trusted;
  }
  return [keys.signing, keys.backup.publicKeyPem];
}

async function applyConfig(c: AgentConfig, log: (msg: string) => void) {
  const next = nextTrustedKeys(trustedKeys(), c.keys);
  if (JSON.stringify(next) !== JSON.stringify(trustedKeys())) {
    state.publicKeys = next;
    delete state.publicKey;
    await saveState();
    log('Supervision : clés de signature mises à jour');
  }
  // Serveur RustDesk de l'éditeur (au lieu des serveurs publics de RustDesk)
  const remote = c.remoteServer ?? null;
  const exe = rustdeskPath();
  if (exe && remote && JSON.stringify(remote) !== JSON.stringify(state.remoteServer ?? null)) {
    try {
      for (const [k, v] of [['custom-rendezvous-server', remote.server], ['relay-server', remote.server], ['key', remote.key]]) {
        await run(exe, ['--option', k, v], { timeout: 30_000, windowsHide: true });
      }
      state.remoteServer = remote;
      remoteIdCache = null;
      await saveState();
      log(`Supervision : prise en main réglée sur le serveur ${remote.server}`);
    } catch (err) {
      log(`Supervision : réglage de RustDesk impossible (${(err as Error).message})`);
    }
  }
}

// ─── Échanges avec la console ────────────────────────────────────────────

async function saveState() {
  await mkdir(path.dirname(STATE_FILE), { recursive: true });
  await writeFile(STATE_FILE, JSON.stringify(state, null, 2), { mode: 0o600 });
}

async function call<T>(method: string, route: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (state.installationId && state.secret) headers.Authorization = `Agent ${state.installationId}:${state.secret}`;
  const res = await fetch(new URL(route, env.SUPERVISION_URL), {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(30_000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error((data as { error?: string }).error ?? `HTTP ${res.status}`), { status: res.status });
  return data as T;
}

const publicUrl = () => (env.WEB_ORIGIN.split(',')[0].trim().startsWith('https://') ? env.WEB_ORIGIN.split(',')[0].trim() : undefined);

async function enroll(log: (msg: string) => void): Promise<boolean> {
  if (state.installationId) return true;
  if (!env.SUPERVISION_CODE) return false;
  try {
    const r = await call<{ installationId: string; secret: string; publicKey: string; heartbeatSeconds: number } & AgentConfig>('POST', '/agent/enroll', {
      code: env.SUPERVISION_CODE, hostname: os.hostname(), version, edition: env.EDITION, publicUrl: publicUrl(),
    });
    state = { ...state, installationId: r.installationId, secret: r.secret, publicKeys: [r.publicKey] };
    await applyConfig(r, log);
    intervalMs = r.heartbeatSeconds * 1000;
    await saveState();
    log('Supervision : installation inscrite auprès de la console');
    return true;
  } catch (err) {
    log(`Supervision : inscription impossible (${(err as Error).message})`);
    return false;
  }
}

async function beat(log: (msg: string) => void) {
  if (!(await enroll(log))) return;
  await reportSupportDecisions();
  await expireAccesses();
  await checkUpdateResult();
  const sentBugs = [...bugs.values()];
  const sentResults = [...state.results];
  const sentClosed = [...(state.closed ?? [])];
  const status = await collectStatus();
  let reply: { commands: Command[]; heartbeatSeconds: number } & AgentConfig;
  try {
    reply = await call('POST', '/agent/heartbeat', {
      hostname: os.hostname(), publicUrl: publicUrl(), status,
      bugs: sentBugs.slice(0, 200), results: sentResults.map((r) => ({ ...r, final: r.final ?? true })), closed: sentClosed,
    });
  } catch (err) {
    // Secret refusé : l'installation a été réinscrite depuis la console ; on repart du code d'inscription
    if ((err as { status?: number }).status === 401) {
      state = { results: [] };
      await saveState();
    }
    log(`Supervision : console injoignable (${(err as Error).message})`);
    return;
  }
  for (const b of sentBugs) if (bugs.get(b.fingerprint)?.occurrences === b.occurrences) bugs.delete(b.fingerprint);
  state.results = state.results.filter((r) => !sentResults.includes(r));
  state.closed = (state.closed ?? []).filter((id) => !sentClosed.includes(id));
  intervalMs = reply.heartbeatSeconds * 1000;
  await applyConfig(reply, log);
  await saveState();
  for (const c of reply.commands) {
    try {
      await execute(c, log);
    } catch (err) {
      await done(c.id, false, { error: (err as Error).message });
    }
  }
  await maybeStartUpdate(log);
}

async function done(commandId: string, ok: boolean, result: Record<string, unknown>, final = true) {
  state.results.push({ commandId, ok, final, result });
  await saveState();
}

// ─── Ordres de la console ────────────────────────────────────────────────

async function execute(c: Command, log: (msg: string) => void) {
  log(`Supervision : ordre « ${c.kind} » reçu`);
  switch (c.kind) {
    case 'restart':
      await done(c.id, true, { at: new Date().toISOString() });
      // Le service Windows redémarre le serveur ; le résultat part au premier passage suivant
      setTimeout(() => process.exit(3), 500);
      return;
    case 'logs':
      return done(c.id, true, { files: await readLogs(Number(c.payload.lines ?? 300)) });
    case 'update':
      return prepareUpdate(c);
    case 'settings':
      return applySettings(c);
    case 'support':
      await db.insert(schema.supportAccess).values({
        commandId: c.id, reason: String(c.payload.reason ?? ''), hours: Number(c.payload.hours ?? 2),
      }).onConflictDoNothing();
      return; // résultat envoyé quand l'administrateur du client a répondu
    case 'remote':
      return startRemote(c);
    default:
      return done(c.id, false, { error: `Ordre inconnu : ${c.kind}` });
  }
}

async function readLogs(lines: number) {
  if (!env.LOG_DIR) return [{ name: 'journal', text: 'Pas de dossier de journaux sur cette installation (LOG_DIR).' }];
  const files = [];
  const entries = await readdir(env.LOG_DIR).catch(() => [] as string[]);
  const withTime = await Promise.all(entries.filter((f) => /\.(log|txt)$/i.test(f)).map(async (f) => ({ f, t: (await stat(path.join(env.LOG_DIR!, f))).mtimeMs })));
  let budget = 400_000;
  for (const { f } of withTime.sort((a, b) => b.t - a.t).slice(0, 6)) {
    const text = (await readFile(path.join(env.LOG_DIR, f), 'utf8')).split(/\r?\n/).slice(-lines).join('\n');
    const part = text.slice(-Math.min(budget, 120_000));
    budget -= part.length;
    files.push({ name: f, text: part });
    if (budget <= 0) break;
  }
  return files;
}

/** Lance une tâche planifiée Windows créée par l'installateur (elle tourne hors du service, en administrateur) */
async function runTask(name: string) {
  if (process.platform !== 'win32') throw new Error('Possible seulement sur une installation Windows');
  try {
    await run('schtasks.exe', ['/Run', '/TN', name], { timeout: 30_000, windowsHide: true });
  } catch {
    // Le message de schtasks est dans la page de code de la console Windows : on le remplace par une phrase claire
    throw new Error(`Tâche planifiée « ${name} » introuvable ou impossible à lancer : installation faite sans l’installateur, ou à refaire`);
  }
}

async function prepareUpdate(c: Command) {
  const p = c.payload as { version: string; channel: string; sha256: string; signature: string; download: string; when: 'night' | 'now' };
  const trusted = trustedKeys();
  if (!trusted.length) throw new Error('Clé de signature inconnue : réinscrire l’installation');
  if (!env.UPDATE_DIR) throw new Error('Mises à jour automatiques non prévues sur cette installation (UPDATE_DIR)');
  // La signature d'abord : un paquet qui ne vient pas de la console est refusé avant même d'être téléchargé
  const message = Buffer.from(`${p.version}|${p.channel}|${p.sha256}`, 'utf8');
  if (!trusted.some((k) => verifySignature(null, message, createPublicKey(k), Buffer.from(p.signature, 'base64')))) {
    throw new Error('Signature de la version invalide : paquet refusé');
  }
  const res = await fetch(new URL(p.download, env.SUPERVISION_URL), {
    headers: { Authorization: `Agent ${state.installationId}:${state.secret}` }, signal: AbortSignal.timeout(30 * 60_000),
  });
  if (!res.ok) throw new Error(`Téléchargement impossible (HTTP ${res.status})`);
  const data = Buffer.from(await res.arrayBuffer());
  if (createHash('sha256').update(data).digest('hex') !== p.sha256) throw new Error('Paquet abîmé pendant le téléchargement (empreinte différente)');
  await mkdir(env.UPDATE_DIR, { recursive: true });
  const file = path.join(env.UPDATE_DIR, `itineo-${p.version}.zip`);
  await writeFile(file, data);
  state.pendingUpdate = { commandId: c.id, version: p.version, file, when: p.when };
  await done(c.id, true, { phase: 'scheduled', at: nextWindow(p.when).toISOString() }, false);
}

/** Fenêtre de mise à jour : tout de suite, ou entre 3 h et 5 h (après la sauvegarde de 2 h) */
export function nextWindow(when: 'night' | 'now', now = new Date()): Date {
  if (when === 'now') return now;
  const h = now.getHours();
  if (h >= 3 && h < 5) return now;
  const at = new Date(now);
  at.setHours(3, 0, 0, 0);
  if (h >= 5) at.setDate(at.getDate() + 1);
  return at;
}

async function maybeStartUpdate(log: (msg: string) => void) {
  const u = state.pendingUpdate;
  if (!u || nextWindow(u.when) > new Date()) return;
  log(`Supervision : installation de la version ${u.version}`);
  const job = path.join(env.UPDATE_DIR!, 'mise-a-jour.json');
  await writeFile(job, JSON.stringify({ commandId: u.commandId, version: u.version, zip: u.file }), 'utf8');
  try {
    await runTask(UPDATE_TASK);
  } catch (err) {
    state.pendingUpdate = null;
    await unlink(job).catch(() => undefined);
    await unlink(u.file).catch(() => undefined);
    await done(u.commandId, false, { message: (err as Error).message });
  }
  // La tâche arrête ce serveur, remplace le programme et le redémarre : le résultat est lu au démarrage suivant
}

/** Au démarrage après une mise à jour : le script a laissé son résultat (réussite, ou retour à l'ancienne version) */
async function checkUpdateResult() {
  if (!env.UPDATE_DIR) return;
  const file = path.join(env.UPDATE_DIR, 'mise-a-jour-resultat.json');
  if (!existsSync(file)) return;
  try {
    const r = JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, '')) as { commandId: string; ok: boolean; version: string; message?: string; rolledBack?: boolean };
    await done(r.commandId, r.ok, { version: r.version, message: r.message ?? null, rolledBack: !!r.rolledBack });
    if (state.pendingUpdate?.commandId === r.commandId) state.pendingUpdate = null;
    await saveState();
  } finally {
    await rename(file, `${file}.lu`).catch(() => unlink(file).catch(() => undefined));
  }
}

const SETTINGS_KEYS = ['SMTP_URL', 'MAIL_FROM', 'DOMAIN'];

async function applySettings(c: Command) {
  if (!env.ITINEO_ENV_FILE) throw new Error('Réglages à distance non prévus sur cette installation (ITINEO_ENV_FILE)');
  const changes = Object.entries((c.payload.env ?? {}) as Record<string, string>).filter(([k]) => SETTINGS_KEYS.includes(k));
  const lines = (await readFile(env.ITINEO_ENV_FILE, 'utf8').catch(() => '')).replace(/^\uFEFF/, '').split(/\r?\n/).filter(Boolean);
  const map = new Map(lines.map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]));
  for (const [k, v] of changes) map.set(k, v.replace(/[\r\n]/g, ''));
  await writeFile(env.ITINEO_ENV_FILE, `${[...map].map(([k, v]) => `${k}=${v}`).join('\r\n')}\r\n`, 'utf8');
  // Résultat gardé avant de lancer la reconfiguration (qui redémarre ce serveur)
  await done(c.id, true, { keys: changes.map(([k]) => k) });
  await runTask(RECONFIGURE_TASK);
}

async function startRemote(c: Command) {
  const exe = rustdeskPath();
  if (!exe) throw new Error('RustDesk n’est pas installé sur ce PC');
  const password = randomBytes(9).toString('base64url');
  await run(exe, ['--password', password], { timeout: 30_000, windowsHide: true });
  const until = new Date(Date.now() + Number(c.payload.minutes ?? 60) * 60_000);
  state.remoteSession = { until: until.toISOString(), commandId: c.id };
  remoteIdCache = null;
  await done(c.id, true, { id: await remoteId(), password, until: until.toISOString() });
}

// ─── Accès support et sessions de prise en main : fin et réponses ────────

async function reportSupportDecisions() {
  const rows = await db.select().from(schema.supportAccess)
    .where(and(eq(schema.supportAccess.reported, false), sql`${schema.supportAccess.status} <> 'PENDING'`));
  for (const r of rows) {
    const [by] = r.decidedBy ? await db.select({ firstName: schema.users.firstName, lastName: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, r.decidedBy)) : [];
    const who = by ? `${by.firstName} ${by.lastName}` : null;
    if (r.status === 'APPROVED' && r.userId) {
      // Mot de passe tiré maintenant et transmis une seule fois : il n'est gardé nulle part en clair
      const password = randomBytes(12).toString('base64url');
      await db.update(schema.users).set({ passwordHash: await bcrypt.hash(password, 10), passwordChangedAt: new Date(), active: true })
        .where(eq(schema.users.id, r.userId));
      await done(r.commandId, true, { decision: 'APPROVED', by: who, until: r.expiresAt?.toISOString(), email: SUPPORT_EMAIL, password, url: publicUrl() ?? null });
    } else {
      await done(r.commandId, r.status !== 'REFUSED', { decision: r.status, by: who });
    }
    await db.update(schema.supportAccess).set({ reported: true }).where(eq(schema.supportAccess.id, r.id));
  }
}

async function expireAccesses() {
  const now = new Date();
  // Demandes restées sans réponse 24 h : abandonnées
  await db.update(schema.supportAccess).set({ status: 'EXPIRED', decidedAt: now })
    .where(and(eq(schema.supportAccess.status, 'PENDING'), lt(schema.supportAccess.createdAt, new Date(now.getTime() - 86_400_000))));
  // Accès arrivés à échéance : compte « Support » fermé et ses sessions coupées
  const ended = await db.update(schema.supportAccess).set({ status: 'CLOSED' })
    .where(and(eq(schema.supportAccess.status, 'APPROVED'), lt(schema.supportAccess.expiresAt, now)))
    .returning({ userId: schema.supportAccess.userId, commandId: schema.supportAccess.commandId });
  for (const e of ended) {
    state.closed = [...(state.closed ?? []), e.commandId];
    if (e.userId) await db.update(schema.users).set({ active: false, sessionsRevokedAt: now }).where(eq(schema.users.id, e.userId));
  }
  // Fin de la prise en main : le mot de passe RustDesk est changé (personne ne le connaît)
  if (state.remoteSession && new Date(state.remoteSession.until) < now) {
    const exe = rustdeskPath();
    if (exe) await run(exe, ['--password', randomBytes(24).toString('base64url')], { timeout: 30_000, windowsHide: true }).catch(() => undefined);
    if (state.remoteSession.commandId) state.closed = [...(state.closed ?? []), state.remoteSession.commandId];
    state.remoteSession = null;
  }
  if (ended.length || state.closed?.length) await saveState();
}

// ─── Démarrage ───────────────────────────────────────────────────────────

export async function startSupervision(log: (msg: string) => void) {
  if (!supervisionEnabled()) return;
  try {
    version = (JSON.parse(await readFile(path.join(ROOT, 'package.json'), 'utf8')) as { version: string }).version;
  } catch { /* version inconnue */ }
  try {
    const saved = JSON.parse(await readFile(STATE_FILE, 'utf8')) as Partial<State>;
    state = { ...saved, results: saved.results ?? [] };
  } catch { /* première fois */ }
  process.on('uncaughtException', (err) => reportServerError(err, 'processus'));
  process.on('unhandledRejection', (err) => reportServerError(err, 'processus (promesse)'));
  const tick = async () => {
    if (!running) {
      running = true;
      try {
        await beat(log);
      } catch (err) {
        log(`Supervision : ${(err as Error).message}`);
      } finally {
        running = false;
      }
    }
    timer = setTimeout(tick, intervalMs);
  };
  timer = setTimeout(tick, 2_000);
  timer.unref?.();
}

export function stopSupervision() {
  if (timer) clearTimeout(timer);
}
