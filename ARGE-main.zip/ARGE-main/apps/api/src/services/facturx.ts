/**
 * Facture électronique (réforme française : émission obligatoire pour les PME au 1er septembre 2027).
 *
 * Factur-X = le PDF habituel de la facture, au format PDF/A-3, qui contient en pièce jointe les données
 * de la facture en XML (norme UN/CEFACT CII, profil EN 16931). Les plateformes agréées lisent ce XML ;
 * le client, lui, voit le PDF. Ce module fabrique le XML et les métadonnées qui l'annoncent dans le PDF.
 */
import { documentTotals, lineNetCents } from '@itineo/shared';

export type OperationType = 'SERVICES' | 'GOODS' | 'MIXED';
export const OPERATION_TYPES: OperationType[] = ['SERVICES', 'GOODS', 'MIXED'];

export interface FacturxParty {
  name: string;
  siren?: string | null;
  vatNumber?: string | null;
  address?: string | null;
  postalCode?: string | null;
  city?: string | null;
  countryCode?: string | null;
  email?: string | null;
}

export interface FacturxInput {
  kind: 'INVOICE' | 'CREDIT_NOTE';
  number: string;
  issueDate: string;
  serviceDate: string | null;
  dueDate: string | null;
  currency: string;
  title: string;
  operationType: OperationType;
  /** Option pour le paiement de la TVA d'après les débits (sinon : à l'encaissement, cas des services) */
  vatOnDebits: boolean;
  seller: FacturxParty & { bankDetails?: string | null };
  buyer: FacturxParty;
  /** Lieu d'intervention, s'il diffère de l'adresse de facturation */
  delivery?: { name: string; address?: string | null; postalCode?: string | null; city?: string | null; countryCode?: string | null } | null;
  /** Avoir : numéro de la facture corrigée */
  creditedNumber?: string | null;
  /** Déjà réglé (acomptes, paiements) : déduit du net à payer */
  paidCents?: number;
  lines: { description: string; quantity: number; unit: string | null; unitPriceCents: number; vatRateBp: number }[];
}

/** Cadre de facturation (BT-23, règles françaises) : services, biens ou mixte */
const FRAMEWORK: Record<OperationType, string> = { SERVICES: 'S1', GOODS: 'B1', MIXED: 'M1' };

/** Unités Itinéos → codes UN/ECE recommandation 20 */
function unitCode(unit: string | null): string {
  const u = (unit ?? '').trim().toLowerCase().replace(/\.$/, '');
  if (['h', 'heure', 'heures', 'hr'].includes(u)) return 'HUR';
  if (['min', 'minute', 'minutes'].includes(u)) return 'MIN';
  if (['j', 'jour', 'jours', 'day'].includes(u)) return 'DAY';
  if (['m', 'ml', 'mètre', 'metre'].includes(u)) return 'MTR';
  if (['m2', 'm²'].includes(u)) return 'MTK';
  if (['kg'].includes(u)) return 'KGM';
  if (['l', 'litre'].includes(u)) return 'LTR';
  if (['forfait', 'fft', 'lot'].includes(u)) return 'LS';
  return 'C62'; // unité (pièce)
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const amount = (cents: number) => (cents / 100).toFixed(2);
const qty = (n: number) => String(Math.round(n * 10_000) / 10_000);
const day = (iso: string) => `<udt:DateTimeString format="102">${iso.replace(/-/g, '')}</udt:DateTimeString>`;
const digits = (s: string | null | undefined) => (s ?? '').replace(/\D/g, '');

/** SIREN (9 chiffres) tiré d'un SIREN ou d'un SIRET saisi avec ou sans espaces */
export function sirenOf(s: string | null | undefined): string | null {
  const d = digits(s);
  return d.length === 9 || d.length === 14 ? d.slice(0, 9) : null;
}

/** IBAN trouvé dans les coordonnées bancaires (texte libre) */
export function ibanOf(text: string | null | undefined): string | null {
  const m = (text ?? '').replace(/[\s-]/g, '').toUpperCase().match(/[A-Z]{2}\d{2}[A-Z0-9]{11,30}/);
  return m ? m[0] : null;
}

function party(tag: 'SellerTradeParty' | 'BuyerTradeParty', p: FacturxParty): string {
  const siren = sirenOf(p.siren);
  const country = (p.countryCode ?? 'FR').toUpperCase();
  return [
    `<ram:${tag}>`,
    `<ram:Name>${esc(p.name)}</ram:Name>`,
    siren ? `<ram:SpecifiedLegalOrganization><ram:ID schemeID="0002">${siren}</ram:ID></ram:SpecifiedLegalOrganization>` : '',
    '<ram:PostalTradeAddress>',
    p.postalCode ? `<ram:PostcodeCode>${esc(p.postalCode)}</ram:PostcodeCode>` : '',
    p.address ? `<ram:LineOne>${esc(p.address)}</ram:LineOne>` : '',
    p.city ? `<ram:CityName>${esc(p.city)}</ram:CityName>` : '',
    `<ram:CountryID>${esc(country)}</ram:CountryID>`,
    '</ram:PostalTradeAddress>',
    p.email ? `<ram:URIUniversalCommunication><ram:URIID schemeID="EM">${esc(p.email)}</ram:URIID></ram:URIUniversalCommunication>` : '',
    p.vatNumber ? `<ram:SpecifiedTaxRegistration><ram:ID schemeID="VA">${esc(p.vatNumber.replace(/\s/g, '').toUpperCase())}</ram:ID></ram:SpecifiedTaxRegistration>` : '',
    `</ram:${tag}>`,
  ].join('');
}

/** Taux 0 % : exonération (ex. micro-entrepreneur, art. 293 B du CGI), sinon taux normal ou réduit */
function taxCategory(rateBp: number): { code: string; reason: string | null } {
  return rateBp === 0 ? { code: 'E', reason: 'TVA non applicable, art. 293 B du CGI' } : { code: 'S', reason: null };
}

/** Le XML Factur-X (CII, profil EN 16931) de la facture */
export function facturxXml(f: FacturxInput): string {
  const totals = documentTotals(f.lines);
  const paid = Math.max(0, Math.min(f.paidCents ?? 0, totals.grossCents));
  const iban = ibanOf(f.seller.bankDetails);
  // Date d'exigibilité de la TVA (BT-8) : 5 = date de facture (débits), 72 = date de paiement (encaissements)
  const vatPoint = f.vatOnDebits || f.operationType === 'GOODS' ? '5' : '72';
  const notes: [string, string][] = [
    ['PMT', 'Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40 €.'],
    ['PMD', 'Pénalités de retard : trois fois le taux d’intérêt légal, exigibles dès le lendemain de l’échéance.'],
    ['AAB', 'Pas d’escompte pour paiement anticipé.'],
  ];
  if (f.vatOnDebits) notes.push(['TXD', 'Option pour le paiement de la taxe d’après les débits.']);

  const lines = f.lines.map((l, i) => {
    const net = lineNetCents(l);
    // Prix unitaire jamais négatif (règle BR-27) : une remise se note par une quantité négative
    const negative = l.unitPriceCents < 0;
    const cat = taxCategory(l.vatRateBp);
    return [
      '<ram:IncludedSupplyChainTradeLineItem>',
      `<ram:AssociatedDocumentLineDocument><ram:LineID>${i + 1}</ram:LineID></ram:AssociatedDocumentLineDocument>`,
      `<ram:SpecifiedTradeProduct><ram:Name>${esc(l.description.slice(0, 500))}</ram:Name></ram:SpecifiedTradeProduct>`,
      `<ram:SpecifiedLineTradeAgreement><ram:NetPriceProductTradePrice><ram:ChargeAmount>${amount(Math.abs(l.unitPriceCents))}</ram:ChargeAmount></ram:NetPriceProductTradePrice></ram:SpecifiedLineTradeAgreement>`,
      `<ram:SpecifiedLineTradeDelivery><ram:BilledQuantity unitCode="${unitCode(l.unit)}">${qty(negative ? -l.quantity : l.quantity)}</ram:BilledQuantity></ram:SpecifiedLineTradeDelivery>`,
      '<ram:SpecifiedLineTradeSettlement>',
      `<ram:ApplicableTradeTax><ram:TypeCode>VAT</ram:TypeCode><ram:CategoryCode>${cat.code}</ram:CategoryCode><ram:RateApplicablePercent>${(l.vatRateBp / 100).toFixed(2)}</ram:RateApplicablePercent></ram:ApplicableTradeTax>`,
      `<ram:SpecifiedTradeSettlementLineMonetarySummation><ram:LineTotalAmount>${amount(net)}</ram:LineTotalAmount></ram:SpecifiedTradeSettlementLineMonetarySummation>`,
      '</ram:SpecifiedLineTradeSettlement>',
      '</ram:IncludedSupplyChainTradeLineItem>',
    ].join('');
  });

  const taxes = totals.byRate.map((r) => {
    const cat = taxCategory(r.vatRateBp);
    return [
      '<ram:ApplicableTradeTax>',
      `<ram:CalculatedAmount>${amount(r.vatCents)}</ram:CalculatedAmount>`,
      '<ram:TypeCode>VAT</ram:TypeCode>',
      cat.reason ? `<ram:ExemptionReason>${esc(cat.reason)}</ram:ExemptionReason>` : '',
      `<ram:BasisAmount>${amount(r.baseCents)}</ram:BasisAmount>`,
      `<ram:CategoryCode>${cat.code}</ram:CategoryCode>`,
      cat.code === 'E' ? '' : `<ram:DueDateTypeCode>${vatPoint}</ram:DueDateTypeCode>`,
      `<ram:RateApplicablePercent>${(r.vatRateBp / 100).toFixed(2)}</ram:RateApplicablePercent>`,
      '</ram:ApplicableTradeTax>',
    ].join('');
  });

  const d = f.delivery;
  const delivery = [
    '<ram:ApplicableHeaderTradeDelivery>',
    d ? [
      '<ram:ShipToTradeParty>',
      `<ram:Name>${esc(d.name)}</ram:Name>`,
      '<ram:PostalTradeAddress>',
      d.postalCode ? `<ram:PostcodeCode>${esc(d.postalCode)}</ram:PostcodeCode>` : '',
      d.address ? `<ram:LineOne>${esc(d.address)}</ram:LineOne>` : '',
      d.city ? `<ram:CityName>${esc(d.city)}</ram:CityName>` : '',
      `<ram:CountryID>${esc((d.countryCode ?? f.buyer.countryCode ?? 'FR').toUpperCase())}</ram:CountryID>`,
      '</ram:PostalTradeAddress>',
      '</ram:ShipToTradeParty>',
    ].join('') : '',
    f.serviceDate ? `<ram:ActualDeliverySupplyChainEvent><ram:OccurrenceDateTime>${day(f.serviceDate)}</ram:OccurrenceDateTime></ram:ActualDeliverySupplyChainEvent>` : '',
    '</ram:ApplicableHeaderTradeDelivery>',
  ].join('');

  const credit = f.kind === 'CREDIT_NOTE';
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<rsm:CrossIndustryInvoice xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"',
    ' xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100"',
    ' xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"',
    ' xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">',
    '<rsm:ExchangedDocumentContext>',
    `<ram:BusinessProcessSpecifiedDocumentContextParameter><ram:ID>${FRAMEWORK[f.operationType]}</ram:ID></ram:BusinessProcessSpecifiedDocumentContextParameter>`,
    '<ram:GuidelineSpecifiedDocumentContextParameter><ram:ID>urn:cen.eu:en16931:2017</ram:ID></ram:GuidelineSpecifiedDocumentContextParameter>',
    '</rsm:ExchangedDocumentContext>',
    '<rsm:ExchangedDocument>',
    `<ram:ID>${esc(f.number)}</ram:ID>`,
    `<ram:TypeCode>${credit ? '381' : '380'}</ram:TypeCode>`,
    `<ram:IssueDateTime>${day(f.issueDate)}</ram:IssueDateTime>`,
    `<ram:IncludedNote><ram:Content>${esc(f.title)}</ram:Content></ram:IncludedNote>`,
    ...notes.map(([code, text]) => `<ram:IncludedNote><ram:Content>${esc(text)}</ram:Content><ram:SubjectCode>${code}</ram:SubjectCode></ram:IncludedNote>`),
    '</rsm:ExchangedDocument>',
    '<rsm:SupplyChainTradeTransaction>',
    ...lines,
    '<ram:ApplicableHeaderTradeAgreement>',
    party('SellerTradeParty', f.seller),
    party('BuyerTradeParty', f.buyer),
    '</ram:ApplicableHeaderTradeAgreement>',
    delivery,
    '<ram:ApplicableHeaderTradeSettlement>',
    `<ram:InvoiceCurrencyCode>${esc(f.currency)}</ram:InvoiceCurrencyCode>`,
    // 58 = virement SEPA (avec l'IBAN de la société), 30 = virement
    iban
      ? `<ram:SpecifiedTradeSettlementPaymentMeans><ram:TypeCode>58</ram:TypeCode><ram:PayeePartyCreditorFinancialAccount><ram:IBANID>${iban}</ram:IBANID></ram:PayeePartyCreditorFinancialAccount></ram:SpecifiedTradeSettlementPaymentMeans>`
      : '<ram:SpecifiedTradeSettlementPaymentMeans><ram:TypeCode>30</ram:TypeCode></ram:SpecifiedTradeSettlementPaymentMeans>',
    ...taxes,
    !credit && f.dueDate
      ? `<ram:SpecifiedTradePaymentTerms><ram:DueDateDateTime>${day(f.dueDate)}</ram:DueDateDateTime></ram:SpecifiedTradePaymentTerms>`
      : '',
    '<ram:SpecifiedTradeSettlementHeaderMonetarySummation>',
    `<ram:LineTotalAmount>${amount(totals.netCents)}</ram:LineTotalAmount>`,
    `<ram:TaxBasisTotalAmount>${amount(totals.netCents)}</ram:TaxBasisTotalAmount>`,
    `<ram:TaxTotalAmount currencyID="${esc(f.currency)}">${amount(totals.vatCents)}</ram:TaxTotalAmount>`,
    `<ram:GrandTotalAmount>${amount(totals.grossCents)}</ram:GrandTotalAmount>`,
    paid ? `<ram:TotalPrepaidAmount>${amount(paid)}</ram:TotalPrepaidAmount>` : '',
    `<ram:DuePayableAmount>${amount(totals.grossCents - paid)}</ram:DuePayableAmount>`,
    '</ram:SpecifiedTradeSettlementHeaderMonetarySummation>',
    credit && f.creditedNumber
      ? `<ram:InvoiceReferencedDocument><ram:IssuerAssignedID>${esc(f.creditedNumber)}</ram:IssuerAssignedID></ram:InvoiceReferencedDocument>`
      : '',
    '</ram:ApplicableHeaderTradeSettlement>',
    '</rsm:SupplyChainTradeTransaction>',
    '</rsm:CrossIndustryInvoice>',
  ].join('\n');
}

/**
 * Métadonnées XMP qui annoncent le XML dans le PDF/A-3 (schéma d'extension Factur-X : nom du fichier,
 * type de document (INVOICE, aussi pour un avoir), version et profil).
 */
export function facturxXmp(): string {
  return `
<rdf:Description rdf:about="" xmlns:pdfaExtension="http://www.aiim.org/pdfa/ns/extension/" xmlns:pdfaSchema="http://www.aiim.org/pdfa/ns/schema#" xmlns:pdfaProperty="http://www.aiim.org/pdfa/ns/property#">
  <pdfaExtension:schemas>
    <rdf:Bag>
      <rdf:li rdf:parseType="Resource">
        <pdfaSchema:schema>Factur-X PDFA Extension Schema</pdfaSchema:schema>
        <pdfaSchema:namespaceURI>urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#</pdfaSchema:namespaceURI>
        <pdfaSchema:prefix>fx</pdfaSchema:prefix>
        <pdfaSchema:property>
          <rdf:Seq>
            <rdf:li rdf:parseType="Resource"><pdfaProperty:name>DocumentFileName</pdfaProperty:name><pdfaProperty:valueType>Text</pdfaProperty:valueType><pdfaProperty:category>external</pdfaProperty:category><pdfaProperty:description>The name of the embedded XML document</pdfaProperty:description></rdf:li>
            <rdf:li rdf:parseType="Resource"><pdfaProperty:name>DocumentType</pdfaProperty:name><pdfaProperty:valueType>Text</pdfaProperty:valueType><pdfaProperty:category>external</pdfaProperty:category><pdfaProperty:description>The type of the hybrid document in capital letters, e.g. INVOICE or ORDER</pdfaProperty:description></rdf:li>
            <rdf:li rdf:parseType="Resource"><pdfaProperty:name>Version</pdfaProperty:name><pdfaProperty:valueType>Text</pdfaProperty:valueType><pdfaProperty:category>external</pdfaProperty:category><pdfaProperty:description>The actual version of the standard applying to the embedded XML document</pdfaProperty:description></rdf:li>
            <rdf:li rdf:parseType="Resource"><pdfaProperty:name>ConformanceLevel</pdfaProperty:name><pdfaProperty:valueType>Text</pdfaProperty:valueType><pdfaProperty:category>external</pdfaProperty:category><pdfaProperty:description>The conformance level of the embedded XML document</pdfaProperty:description></rdf:li>
          </rdf:Seq>
        </pdfaSchema:property>
      </rdf:li>
    </rdf:Bag>
  </pdfaExtension:schemas>
</rdf:Description>
<rdf:Description rdf:about="" xmlns:fx="urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#">
  <fx:DocumentType>INVOICE</fx:DocumentType>
  <fx:DocumentFileName>factur-x.xml</fx:DocumentFileName>
  <fx:Version>1.0</fx:Version>
  <fx:ConformanceLevel>EN 16931</fx:ConformanceLevel>
</rdf:Description>`;
}

/** Ce qui manque pour une facture électronique valable (affiché avant l'émission et l'envoi) */
export function facturxWarnings(f: Pick<FacturxInput, 'seller' | 'buyer'> & { buyerIsCompany: boolean }): string[] {
  const out: string[] = [];
  if (!sirenOf(f.seller.siren)) out.push('Le SIREN de votre société n’est pas renseigné (Organisation).');
  if (!f.seller.vatNumber) out.push('Le numéro de TVA intracommunautaire de votre société n’est pas renseigné.');
  if (f.buyerIsCompany && (f.buyer.countryCode ?? 'FR').toUpperCase() === 'FR' && !sirenOf(f.buyer.siren)) {
    out.push('Le SIREN du client n’est pas renseigné : il est obligatoire sur les factures entre entreprises.');
  }
  if (!f.buyer.address || !f.buyer.postalCode || !f.buyer.city) out.push('L’adresse du client est incomplète.');
  return out;
}
