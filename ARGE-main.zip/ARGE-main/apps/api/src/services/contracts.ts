/**
 * Contrats d'entretien : création automatique des visites.
 *
 * Pour chaque contrat actif, chaque échéance qui tombe dans les VISIT_HORIZON_DAYS prochains jours
 * devient une intervention « À planifier » (type Entretien, origine Contrat), avec sa date d'échéance.
 * Une contrainte en base garantit une seule visite par contrat et par échéance : on peut relancer
 * la génération autant de fois qu'on veut (au démarrage, toutes les 6 h, à la création d'un contrat).
 */
import { and, eq } from 'drizzle-orm';
import { addDays, visitDueDates, VISIT_HORIZON_DAYS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { nextInterventionNumber } from './numbering.js';
import { langOf } from './prefill.js';

/** Date du jour (AAAA-MM-JJ) dans le fuseau horaire de la société */
export function todayIn(timezone: string, now = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
}

export function visitReason(title: string, locale: string): string {
  return langOf(locale) === 'en' ? `Maintenance visit – ${title}` : `Visite d'entretien – ${title}`;
}

/** Crée les visites à venir ; renvoie le nombre d'interventions créées */
export async function generateContractVisits(opts: { contractId?: string; now?: Date } = {}): Promise<number> {
  const c = schema.contracts;
  const rows = await db
    .select({ contract: c, company: schema.companies })
    .from(c)
    .innerJoin(schema.companies, eq(schema.companies.id, c.companyId))
    .where(and(eq(c.status, 'ACTIVE'), opts.contractId ? eq(c.id, opts.contractId) : undefined));

  let created = 0;
  for (const { contract, company } of rows) {
    const today = todayIn(company.timezone, opts.now);
    const dues = visitDueDates(contract, today, addDays(today, VISIT_HORIZON_DAYS));
    if (!dues.length) continue;
    const existing = new Set(
      (await db
        .select({ due: schema.interventions.dueDate })
        .from(schema.interventions)
        .where(eq(schema.interventions.contractId, contract.id)))
        .map((r) => r.due),
    );
    for (const due of dues) {
      if (existing.has(due)) continue;
      const inserted = await db.transaction(async (tx) => {
        const number = await nextInterventionNumber(tx, company);
        return tx.insert(schema.interventions).values({
          groupId: contract.groupId,
          companyId: contract.companyId,
          agencyId: contract.agencyId,
          number,
          clientId: contract.clientId,
          siteId: contract.siteId,
          equipmentId: contract.equipmentIds.length === 1 ? contract.equipmentIds[0] : null,
          kind: 'MAINTENANCE',
          status: 'TO_PLAN',
          priority: 'NORMAL',
          source: 'Contrat',
          reason: visitReason(contract.title, company.locale),
          contractId: contract.id,
          dueDate: due,
        }).onConflictDoNothing().returning({ id: schema.interventions.id });
      });
      if (inserted.length) created++;
    }
  }
  return created;
}

/** Lance la génération maintenant puis toutes les 6 heures (appelé au démarrage du serveur) */
export function scheduleContractVisits(log: (msg: string) => void) {
  const run = () =>
    generateContractVisits()
      .then((n) => n && log(`${n} visite(s) d'entretien créée(s)`))
      .catch((err) => log(`Génération des visites impossible : ${(err as Error).message}`));
  void run();
  const timer = setInterval(run, 6 * 60 * 60 * 1000);
  timer.unref();
}
