import { createHash, randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { env, PRODUCT_NAME } from '../env.js';

/** Durée de validité d'un lien « mot de passe oublié » */
export const RESET_TTL_MS = 60 * 60 * 1000;
/** Délai minimum entre deux liens pour un même compte (évite d'inonder la boîte mail) */
export const RESET_COOLDOWN_MS = 2 * 60 * 1000;

export const newPassword = z.string().min(8, 'Le mot de passe doit faire au moins 8 caractères').max(200);

/** Empreinte d'un mot de passe que personne ne connaît, même coût que les vraies */
const DUMMY_HASH = bcrypt.hashSync(randomBytes(16).toString('hex'), 10);

/**
 * Vérifie un mot de passe. Sans compte (ou compte pas encore activé), une vérification est faite quand même :
 * le temps de réponse est le même et ne révèle pas si l'adresse a un compte.
 */
export async function passwordMatches(password: string, hash: string | null | undefined): Promise<boolean> {
  const ok = await bcrypt.compare(password, hash || DUMMY_HASH);
  return ok && !!hash;
}

/** Jeton envoyé par e-mail (jamais stocké tel quel) et son empreinte (stockée en base) */
export function createResetToken(): { token: string; tokenHash: string } {
  const token = randomBytes(32).toString('base64url');
  return { token, tokenHash: hashResetToken(token) };
}

export function hashResetToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

/**
 * « Version » du mot de passe, gravée dans chaque jeton de session : la date exacte (en ms) du dernier
 * changement, ou 0 s'il n'a jamais changé. Après un changement, les jetons portant l'ancienne version
 * sont refusés, même ceux ouverts dans la même seconde.
 */
export function passwordVersion(passwordChangedAt: Date | null): number {
  return passwordChangedAt?.getTime() ?? 0;
}

/**
 * Version des sessions : la plus récente entre le dernier changement de mot de passe et le dernier
 * « Déconnecter tous mes appareils ». Un jeton portant une version plus ancienne est refusé.
 */
export function sessionVersion(passwordChangedAt: Date | null, sessionsRevokedAt?: Date | null): number {
  return Math.max(passwordVersion(passwordChangedAt), sessionsRevokedAt?.getTime() ?? 0);
}

export function sessionStillValid(tokenVersion: number | undefined, passwordChangedAt: Date | null, sessionsRevokedAt?: Date | null): boolean {
  return (tokenVersion ?? 0) === sessionVersion(passwordChangedAt, sessionsRevokedAt);
}

/** Durée d'une session : 12 h, ou un an avec « Rester connecté » (prolongée à chaque ouverture de l'appli) */
export const SESSION_TTL = { normal: '12h', remember: '365d' } as const;

/** Adresse de la page de réinitialisation dans l'appli web */
export function resetLink(token: string): string {
  const origin = env.WEB_ORIGIN.split(',')[0].trim().replace(/\/$/, '');
  return `${origin}/reset-password?token=${encodeURIComponent(token)}`;
}

export function resetMail(locale: string, firstName: string, link: string): { subject: string; text: string } {
  // E-mail en français ou en anglais : l'anglais sert aussi aux autres langues de l'interface
  if (!locale.startsWith('fr')) {
    return {
      subject: `${PRODUCT_NAME} – Reset your password`,
      text: `Hello ${firstName},\n\nTo choose a new password, open this link (valid for 1 hour, single use):\n${link}\n\nIf you did not ask for this, ignore this e-mail: your password stays the same.`,
    };
  }
  return {
    subject: `${PRODUCT_NAME} – Réinitialisation de votre mot de passe`,
    text: `Bonjour ${firstName},\n\nPour choisir un nouveau mot de passe, ouvrez ce lien (valable 1 heure, une seule fois) :\n${link}\n\nSi vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail : votre mot de passe reste inchangé.`,
  };
}
