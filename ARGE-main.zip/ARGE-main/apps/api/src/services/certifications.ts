import { and, eq, inArray } from 'drizzle-orm';
import { db, schema } from '../db/client.js';

/** Types d'habilitation exigés qui manquent (ou ne seront plus valables) au technicien à cette date */
export async function missingCertifications(technicianId: string, requiredTypeIds: string[], onDate: string) {
  if (!requiredTypeIds.length) return [];
  const uc = schema.userCertifications;
  const held = await db.select({ typeId: uc.typeId, expiresOn: uc.expiresOn }).from(uc)
    .where(and(eq(uc.userId, technicianId), inArray(uc.typeId, requiredTypeIds)));
  const valid = new Set(held.filter((h) => !h.expiresOn || h.expiresOn >= onDate).map((h) => h.typeId));
  const missing = requiredTypeIds.filter((t) => !valid.has(t));
  if (!missing.length) return [];
  const ct = schema.certificationTypes;
  return db.select({ id: ct.id, code: ct.code, name: ct.name }).from(ct).where(inArray(ct.id, missing));
}
