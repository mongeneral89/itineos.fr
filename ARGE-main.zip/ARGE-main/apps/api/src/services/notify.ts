/**
 * Notifications : sur le téléphone ou l'ordinateur même quand Itinéos est fermé (Web Push, standard des
 * navigateurs, sans service payant ; Firebase pour l'appli Android, voir fcm.ts), et/ou par e-mail, selon les préférences de chacun (Mon compte).
 *
 * Événements : nouveau message, intervention attribuée, déplacée ou annulée, document à valider ; pour le bureau :
 * intervention terminée ou à reprendre, technicien en retard, demande et réponse aux devis de l'espace client.
 * Chaque notification est aussi gardée pour la cloche du logiciel (table notifications), quelles que soient les préférences.
 * Les clés VAPID (qui identifient le serveur auprès des navigateurs) viennent de l'environnement
 * (VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY) ; sinon elles sont créées une fois et gardées dans STORAGE_DIR.
 * Pendant les tests, rien ne part : les envois sont notés dans `sentNotifications`.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import webpush from 'web-push';
import { eq, inArray } from 'drizzle-orm';
import { db, schema } from '../db/client.js';
import { env, PRODUCT_NAME } from '../env.js';
import { sendMail } from './mail.js';
import { FCM_PREFIX, sendFcm } from './fcm.js';

export const NOTIFY_EVENTS = ['message', 'assignment', 'procedure', 'completed', 'followup', 'late', 'request', 'quote'] as const;
export type NotifyEvent = (typeof NOTIFY_EVENTS)[number];

/**
 * Préférences : par défaut, notification sur l'appareil oui, e-mail non.
 * Une alerte SOS (agent isolé) part toujours par les deux canaux, quelles que soient les préférences.
 */
export function wants(prefs: Partial<Record<string, boolean>> | null | undefined, event: NotifyEvent | 'alert', channel: 'push' | 'email'): boolean {
  if (event === 'alert') return true;
  const v = prefs?.[`${channel}_${event}`];
  return v ?? channel === 'push';
}

const testing = () => process.env.NODE_ENV === 'test' || !!process.env.NODE_TEST_CONTEXT;

let keys: { publicKey: string; privateKey: string } | null = null;
export function vapidKeys(): { publicKey: string; privateKey: string } {
  if (keys) return keys;
  if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    keys = { publicKey: process.env.VAPID_PUBLIC_KEY, privateKey: process.env.VAPID_PRIVATE_KEY };
  } else {
    const file = path.resolve(env.STORAGE_DIR, 'vapid.json');
    if (existsSync(file)) keys = JSON.parse(readFileSync(file, 'utf8'));
    else {
      keys = webpush.generateVAPIDKeys();
      mkdirSync(path.dirname(file), { recursive: true });
      writeFileSync(file, JSON.stringify(keys));
    }
  }
  const origin = env.WEB_ORIGIN.split(',')[0].trim();
  webpush.setVapidDetails(process.env.VAPID_SUBJECT ?? (origin.startsWith('https://') ? origin : 'mailto:contact@itineos.app'), keys!.publicKey, keys!.privateKey);
  return keys!;
}

/** sync : l'appli ouverte recharge aussitôt sa journée et ses fiches (bouton « Synchroniser » du bureau) */
export interface Notice { title: string; body: string; url: string; tag?: string; sync?: boolean }
/** Envois notés pendant les tests */
export const sentNotifications: { userId: string; event: NotifyEvent | 'alert'; channel: 'push' | 'email'; notice: Notice }[] = [];

/** Textes dans la langue de la personne (français, sinon anglais) */
type Texts = (locale: string) => Notice;

/**
 * Prévient des personnes. Ne bloque jamais l'action qui déclenche : à appeler sans attendre (void).
 * Un abonnement que le navigateur a supprimé (410) est retiré.
 */
export async function notifyUsers(userIds: string[], event: NotifyEvent | 'alert', texts: Texts): Promise<void> {
  const ids = [...new Set(userIds)];
  if (!ids.length) return;
  const users = await db.select({ id: schema.users.id, email: schema.users.email, locale: schema.users.locale, prefs: schema.users.notifyPrefs, active: schema.users.active })
    .from(schema.users).where(inArray(schema.users.id, ids));
  const subs = await db.select().from(schema.pushSubscriptions).where(inArray(schema.pushSubscriptions.userId, ids));
  const active = users.filter((x) => x.active);
  const notices = new Map(active.map((u) => [u.id, texts(u.locale)]));
  // La cloche : toujours, même sans appareil abonné
  if (active.length) {
    await db.insert(schema.notifications).values(active.map((u) => {
      const n = notices.get(u.id)!;
      return { userId: u.id, kind: event, title: n.title.slice(0, 200), body: n.body.slice(0, 500), url: n.url };
    }));
  }
  for (const user of active) {
    const notice = notices.get(user.id)!;
    if (wants(user.prefs, event, 'push')) {
      for (const sub of subs.filter((s) => s.userId === user.id)) {
        if (testing()) {
          sentNotifications.push({ userId: user.id, event, channel: 'push', notice });
          continue;
        }
        // Appli Android : par Firebase (services/fcm.ts)
        if (sub.endpoint.startsWith(FCM_PREFIX)) {
          try {
            const r = await sendFcm(sub.endpoint.slice(FCM_PREFIX.length), notice);
            if (r === 'gone') await db.delete(schema.pushSubscriptions).where(eq(schema.pushSubscriptions.id, sub.id));
            else await db.update(schema.pushSubscriptions).set({ lastUsedAt: new Date() }).where(eq(schema.pushSubscriptions.id, sub.id));
          } catch (err) {
            console.warn('[notify] appli Android :', (err as Error).message);
          }
          continue;
        }
        try {
          vapidKeys();
          await webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, JSON.stringify(notice), { TTL: 24 * 3600 });
          await db.update(schema.pushSubscriptions).set({ lastUsedAt: new Date() }).where(eq(schema.pushSubscriptions.id, sub.id));
        } catch (err) {
          const status = (err as { statusCode?: number }).statusCode;
          if (status === 404 || status === 410) await db.delete(schema.pushSubscriptions).where(eq(schema.pushSubscriptions.id, sub.id));
          else console.warn('[notify] envoi impossible', status ?? (err as Error).message);
        }
      }
    }
    if (wants(user.prefs, event, 'email')) {
      if (testing()) sentNotifications.push({ userId: user.id, event, channel: 'email', notice });
      const origin = env.WEB_ORIGIN.split(',')[0].trim().replace(/\/$/, '');
      const fr = user.locale.startsWith('fr');
      await sendMail({
        to: [user.email],
        subject: `${PRODUCT_NAME} – ${notice.title}`,
        text: `${notice.body}\n\n${fr ? 'Ouvrir' : 'Open'} : ${origin}${notice.url}\n\n${fr ? 'Pour ne plus recevoir ces e-mails : Mon compte → Notifications.' : 'To stop these e-mails: My account → Notifications.'}`,
      }).catch((e) => console.warn('[notify] e-mail impossible', (e as Error).message));
    }
  }
}

/** Lance une notification sans attendre ni faire échouer la requête */
export function notifyLater(userIds: string[], event: NotifyEvent, texts: Texts) {
  void notifyUsers(userIds, event, texts).catch((e) => console.warn('[notify]', (e as Error).message));
}
