/**
 * Export comptable : journal des ventes et liste des factures, en CSV lisible par Excel
 * et importable dans les logiciels comptables (séparateur « ; », virgule décimale, UTF-8).
 *
 * Écritures d'une facture :  débit 411 (client) TTC  /  crédit 706 (prestations) HT par taux  /  crédit 44571 (TVA) par taux.
 * Un avoir passe les mêmes écritures en sens inverse. Chaque pièce est équilibrée (débit = crédit).
 */
import { documentTotals, type PricedLine } from '@itineo/shared';

/** Comptes par défaut du plan comptable général (modifiables plus tard par société) */
export const ACCOUNTS = { client: '411000', sales: '706000', vat: '445710' } as const;

export interface ExportDocument {
  kind: 'INVOICE' | 'CREDIT_NOTE';
  number: string;
  issueDate: string;
  dueDate: string | null;
  clientName: string;
  /** Code client du logiciel comptable (référence externe), sinon le nom */
  clientAccount: string;
  title: string;
  lines: PricedLine[];
  settledCents: number;
}

export interface JournalEntry {
  journal: string;
  date: string;
  piece: string;
  account: string;
  auxiliary: string;
  label: string;
  debitCents: number;
  creditCents: number;
}

export function salesJournal(docs: ExportDocument[], journal = 'VT'): JournalEntry[] {
  const out: JournalEntry[] = [];
  for (const d of docs) {
    const t = documentTotals(d.lines);
    const sign = d.kind === 'CREDIT_NOTE' ? -1 : 1;
    const label = `${d.kind === 'CREDIT_NOTE' ? 'Avoir' : 'Facture'} ${d.number} – ${d.clientName}`.slice(0, 120);
    const entry = (account: string, auxiliary: string, amount: number, debitSide: boolean, extra = ''): JournalEntry => {
      const value = amount * sign;
      // Montant négatif : il change de colonne (un avoir crédite le client)
      const debit = debitSide ? value >= 0 : value < 0;
      return {
        journal, date: d.issueDate, piece: d.number, account, auxiliary, label: extra ? `${label} ${extra}` : label,
        debitCents: debit ? Math.abs(value) : 0, creditCents: debit ? 0 : Math.abs(value),
      };
    };
    out.push(entry(ACCOUNTS.client, d.clientAccount, t.grossCents, true));
    for (const r of t.byRate) {
      if (r.baseCents) out.push(entry(ACCOUNTS.sales, '', r.baseCents, false, `HT ${r.vatRateBp / 100} %`));
      if (r.vatCents) out.push(entry(ACCOUNTS.vat, '', r.vatCents, false, `TVA ${r.vatRateBp / 100} %`));
    }
  }
  return out;
}

const cents = (c: number) => (c / 100).toFixed(2).replace('.', ',');
const frDate = (iso: string | null) => (iso ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : '');
/** Une cellule CSV : entre guillemets si besoin, sans formule exécutable dans Excel */
function cell(v: string): string {
  let s = v.replace(/\r?\n/g, ' ');
  if (/^[=+\-@]/.test(s)) s = `'${s}`;
  return /[;"]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function toCsv(header: string[], rows: string[][]): string {
  // BOM : Excel reconnaît l'UTF-8 (accents corrects)
  return '﻿' + [header, ...rows].map((r) => r.map(cell).join(';')).join('\r\n') + '\r\n';
}

export function salesJournalCsv(docs: ExportDocument[]): string {
  return toCsv(
    ['JournalCode', 'EcritureDate', 'PieceRef', 'CompteNum', 'CompteAux', 'EcritureLib', 'Debit', 'Credit'],
    salesJournal(docs).map((e) => [e.journal, frDate(e.date), e.piece, e.account, e.auxiliary, e.label, cents(e.debitCents), cents(e.creditCents)]),
  );
}

export function invoiceListCsv(docs: ExportDocument[]): string {
  return toCsv(
    ['Numéro', 'Type', 'Date', 'Échéance', 'Client', 'Objet', 'Total HT', 'TVA', 'Total TTC', 'Réglé', 'Reste à payer'],
    docs.map((d) => {
      const t = documentTotals(d.lines);
      const sign = d.kind === 'CREDIT_NOTE' ? -1 : 1;
      const remaining = d.kind === 'CREDIT_NOTE' ? 0 : Math.max(0, t.grossCents - d.settledCents);
      return [
        d.number, d.kind === 'CREDIT_NOTE' ? 'Avoir' : 'Facture', frDate(d.issueDate), frDate(d.dueDate), d.clientName, d.title,
        cents(sign * t.netCents), cents(sign * t.vatCents), cents(sign * t.grossCents), cents(d.kind === 'CREDIT_NOTE' ? 0 : d.settledCents), cents(remaining),
      ];
    }),
  );
}
