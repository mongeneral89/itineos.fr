import { db, schema } from '../db/client.js';
import type { Principal } from '../auth/access.js';

/** Trace une action dans le journal. Ne bloque jamais l'action si l'écriture échoue. */
export async function audit(
  p: Principal,
  action: string,
  entity: string,
  entityId: string | null,
  details?: Record<string, unknown>,
): Promise<void> {
  try {
    await db.insert(schema.auditLogs).values({
      groupId: p.groupId,
      userId: p.userId,
      action,
      entity,
      entityId,
      details: details ?? null,
    });
  } catch (err) {
    console.error('[audit] écriture impossible', err);
  }
}
