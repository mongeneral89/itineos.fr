/**
 * Pack « installateur d'alarme et de vidéosurveillance » : fiches et documents du métier, prêts à l'emploi.
 *
 * Repris des documents papier d'un installateur (voir db/arge/templates.ts), rendus génériques : ni nom de société,
 * ni télésurveilleur, ni partenaire financier. La société les ajoute depuis l'écran « Modèles de fiches », puis les
 * adapte comme ses autres modèles.
 *  - fiches (prises d'office) : dépannage, maintenance, installation
 *  - documents à choisir sur l'intervention : consignes de télésurveillance, dossiers techniques, PV de réception
 *
 * Comme pour tous les modèles, les horaires, le temps passé, les pièces, les photos et les signatures ne sont pas
 * dans les modèles : ils font partie de toutes les fiches.
 */
import { and, eq } from 'drizzle-orm';
import type { InterventionKind, TemplateSchema } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import {
  area, build, check, choice, day, list, num, text, yesNo,
  type FieldDef, type Lang, type SectionDef, type TemplateDef, type Tx,
} from './sector-templates.js';

const SYSTEMS: [string[], string[]] = [
  ['Intrusion', 'Vidéoprotection', 'Contrôle d’accès', 'Interphonie', 'Détection incendie', 'Autre'],
  ['Intrusion alarm', 'Video surveillance', 'Access control', 'Intercom', 'Fire detection', 'Other'],
];
const FOLLOW_UP: [string[], string[]] = [
  ['Devis à faire', 'Matériel à commander', 'Nouveau passage à prévoir', 'Consignes de télésurveillance à mettre à jour', 'Action commerciale'],
  ['Quote to prepare', 'Parts to order', 'Further visit needed', 'Monitoring instructions to update', 'Sales follow-up'],
];

const equipment: SectionDef = {
  id: 'equipment', title: ['Matériel', 'Equipment'], fields: [
    text('equipment', ['Matériel concerné', 'Equipment'], { prefill: 'equipment.category' }),
    text('brand', ['Marque', 'Brand'], { prefill: 'equipment.brand' }),
    text('model', ['Modèle', 'Model'], { prefill: 'equipment.model' }),
    text('serial', ['N° de série', 'Serial number'], { prefill: 'equipment.serialNumber' }),
    text('subscriber', ['N° d’abonné télésurveillance', 'Monitoring subscriber number'], { prefill: 'client.subscriberNumber' }),
  ],
};

const followUp: SectionDef = {
  id: 'followUp', title: ['Suites à donner', 'Follow-up'], fields: [
    list('followUp', ['Suites à donner', 'Follow-up'], FOLLOW_UP[0], FOLLOW_UP[1]),
    text('orderRefs', ['Matériel à commander : références et quantités', 'Parts to order: references and quantities']),
    area('remarks', ['Remarques sur l’installation', 'Remarks on the installation']),
  ],
};

/** Fiche de dépannage (SAV, et « autre ») */
const REPAIR: TemplateDef = {
  kind: 'SAV',
  name: ['Fiche de dépannage – alarme et vidéo', 'Repair report – alarm and video'],
  sections: [
    {
      id: 'call', title: ['Appel', 'Call'], fields: [
        day('callDate', ['Date de l’appel', 'Call date']),
        choice('origin', ['Origine de la demande', 'Request from'],
          ['Client', 'Télésurveilleur', 'Contrat de maintenance', 'Visite programmée', 'Autre'],
          ['Customer', 'Monitoring centre', 'Maintenance contract', 'Scheduled visit', 'Other']),
        choice('system', ['Système concerné', 'System'], SYSTEMS[0], SYSTEMS[1], { required: true }),
        area('problem', ['Problème signalé', 'Reported problem'], { prefill: 'intervention.reason', required: true }),
      ],
    },
    equipment,
    {
      id: 'work', title: ['Intervention', 'Work done'], fields: [
        area('diagnosis', ['Diagnostic', 'Diagnosis'], { required: true }),
        area('work', ['Travaux réalisés', 'Work carried out'], { required: true }),
      ],
    },
    {
      id: 'tests', title: ['Essais avant de partir', 'Checks before leaving'], fields: [
        list('tests', ['Contrôles faits', 'Checks done'],
          ['Système remis en service', 'Transmission testée avec le télésurveilleur', 'Télésurveilleur prévenu de la fin d’intervention', 'Sirène testée', 'Images vérifiées sur l’enregistreur', 'Accès à distance vérifié', 'Client informé'],
          ['System back in service', 'Transmission tested with the monitoring centre', 'Monitoring centre told the job is finished', 'Siren tested', 'Images checked on the recorder', 'Remote access checked', 'Customer informed']),
      ],
    },
    followUp,
  ],
};

/** Visite de maintenance annuelle */
const MAINTENANCE: TemplateDef = {
  kind: 'MAINTENANCE',
  name: ['Fiche de maintenance – alarme et vidéo', 'Maintenance report – alarm and video'],
  sections: [
    {
      id: 'visit', title: ['Visite', 'Visit'], fields: [
        list('systems', ['Systèmes contrôlés', 'Systems checked'], SYSTEMS[0].slice(0, 5), SYSTEMS[1].slice(0, 5), { required: true }),
        text('subscriber', ['N° d’abonné télésurveillance', 'Monitoring subscriber number'], { prefill: 'client.subscriberNumber' }),
        yesNo('monitoringWarned', ['Télésurveilleur prévenu (mise en essai)', 'Monitoring centre warned (test mode)']),
      ],
    },
    {
      id: 'intrusion', title: ['Intrusion', 'Intrusion alarm'], fields: [
        list('intrusionChecks', ['Contrôles', 'Checks'],
          ['Centrale et alimentation', 'Batterie de la centrale', 'Détecteurs testés un par un', 'Sirène intérieure', 'Sirène extérieure et flash', 'Autoprotections', 'Claviers et badges', 'Transmetteur et test cyclique', 'Journal des événements consulté', 'Logiciel à jour'],
          ['Control panel and power supply', 'Control panel battery', 'Each detector tested', 'Indoor siren', 'Outdoor siren and strobe', 'Tamper switches', 'Keypads and tags', 'Transmitter and periodic test', 'Event log reviewed', 'Firmware up to date']),
        num('batteryVoltage', ['Tension de la batterie (V)', 'Battery voltage (V)']),
        choice('batteryState', ['Batterie', 'Battery'], ['Bon état', 'À remplacer à la prochaine visite', 'Remplacée'], ['Good', 'To replace at next visit', 'Replaced']),
        num('detectorsTested', ['Détecteurs testés', 'Detectors tested']),
        num('detectorsTotal', ['Détecteurs installés', 'Detectors installed']),
      ],
    },
    {
      id: 'video', title: ['Vidéoprotection', 'Video surveillance'], fields: [
        list('videoChecks', ['Contrôles', 'Checks'],
          ['Enregistreur et disque dur', 'Date et heure exactes', 'Images de jour', 'Images de nuit', 'Optiques nettoyées', 'Cadrages vérifiés', 'Masquages des zones privées', 'Accès à distance'],
          ['Recorder and hard drive', 'Correct date and time', 'Daytime images', 'Night images', 'Lenses cleaned', 'Camera angles checked', 'Privacy masks', 'Remote access']),
        num('cameras', ['Caméras contrôlées', 'Cameras checked']),
        num('retentionDays', ['Durée de conservation des images (jours)', 'Image retention (days)'],
          { help: ['30 jours au plus pour un lieu ouvert au public', 'At most 30 days for premises open to the public (France)'] }),
      ],
    },
    {
      id: 'access', title: ['Contrôle d’accès', 'Access control'], fields: [
        list('accessChecks', ['Contrôles', 'Checks'],
          ['Lecteurs et badges', 'Gâches et ventouses', 'Boutons de sortie', 'Déverrouillage sur alarme incendie'],
          ['Readers and badges', 'Strikes and maglocks', 'Exit buttons', 'Release on fire alarm']),
      ],
    },
    {
      id: 'result', title: ['Conclusion', 'Conclusion'], fields: [
        choice('state', ['État de l’installation', 'Installation status'],
          ['Conforme', 'Conforme avec réserves', 'Non conforme : intervention nécessaire'],
          ['Compliant', 'Compliant with reservations', 'Not compliant: work needed'], { required: true }),
        area('anomalies', ['Anomalies constatées', 'Faults found']),
      ],
    },
    followUp,
  ],
};

/** Installation et mise en service */
const INSTALLATION: TemplateDef = {
  kind: 'INSTALLATION',
  name: ['Fiche d’installation – alarme et vidéo', 'Installation report – alarm and video'],
  sections: [
    {
      id: 'work', title: ['Installation', 'Installation'], fields: [
        area('description', ['Travaux prévus', 'Planned work'], { prefill: 'intervention.reason' }),
        list('systems', ['Systèmes posés', 'Systems installed'], SYSTEMS[0].slice(0, 5), SYSTEMS[1].slice(0, 5), { required: true }),
        num('zones', ['Nombre de détecteurs ou de caméras', 'Number of detectors or cameras']),
        text('transmitter', ['Transmetteur (modèle, n° de série)', 'Transmitter (model, serial number)']),
        choice('transmission', ['Transmission', 'Transmission'], ['IP', '4G', 'IP et 4G', 'RTC', 'Radio', 'Sans transmission'], ['IP', '4G', 'IP and 4G', 'PSTN', 'Radio', 'No transmission']),
        text('subscriber', ['N° d’abonné télésurveillance', 'Monitoring subscriber number'], { prefill: 'client.subscriberNumber' }),
      ],
    },
    {
      id: 'commissioning', title: ['Mise en service', 'Commissioning'], fields: [
        list('steps', ['Étapes faites', 'Steps done'],
          ['Raccordement au télésurveilleur testé', 'Consignes de télésurveillance remplies', 'Autocollants et signalétique posés', 'Notice d’utilisation remise', 'Utilisateurs formés', 'Codes personnels changés par le client'],
          ['Connection to the monitoring centre tested', 'Monitoring instructions filled in', 'Stickers and signs fitted', 'User manual handed over', 'Users trained', 'Personal codes changed by the customer']),
        text('trained', ['Personnes formées', 'People trained']),
        check('pictures', ['Photos de l’installation prises', 'Photos of the installation taken']),
      ],
    },
    {
      id: 'reception', title: ['Réception', 'Handover'], fields: [
        choice('reception', ['Réception des travaux', 'Handover'], ['Sans réserve', 'Avec réserves', 'À programmer'], ['Without reservations', 'With reservations', 'To be scheduled'], { required: true }),
        area('reservations', ['Réserves', 'Reservations']),
      ],
    },
    followUp,
  ],
};

/** Consignes à transmettre au centre de télésurveillance */
function monitoringInstructions(): TemplateDef {
  const contacts: FieldDef[] = [];
  for (let i = 1; i <= 5; i++) {
    contacts.push(
      text(`resp${i}Name`, [`Responsable ${i} : nom, prénom, fonction`, `Contact ${i}: name and role`]),
      text(`resp${i}Phone`, [`Responsable ${i} : téléphone`, `Contact ${i}: phone`]),
      text(`resp${i}Password`, [`Responsable ${i} : mot de passe de levée de doute`, `Contact ${i}: verification password`]),
      list(`resp${i}When`, [`Responsable ${i} : à appeler`, `Contact ${i}: to call`], ['Détient les clés', 'Jour', 'Nuit', 'Week-end'], ['Key holder', 'Day', 'Night', 'Weekend']),
    );
  }
  const days: Tx[] = [['lundi', 'Monday'], ['mardi', 'Tuesday'], ['mercredi', 'Wednesday'], ['jeudi', 'Thursday'], ['vendredi', 'Friday'], ['samedi', 'Saturday'], ['dimanche', 'Sunday'], ['jours fériés', 'public holidays']];
  return {
    kind: 'INSTALLATION',
    name: ['Consignes de télésurveillance – complètes', 'Remote monitoring instructions – full'],
    sections: [
      {
        id: 'site', title: ['Site', 'Site'], fields: [
          text('subscriber', ['N° d’abonné', 'Subscriber number'], { prefill: 'client.subscriberNumber', required: true }),
          text('siteName', ['Nom du site', 'Site name'], { prefill: 'site.name' }),
          text('siteAddress', ['Adresse', 'Address'], { prefill: 'site.fullAddress' }),
          text('sitePhone', ['Téléphone du site', 'Site phone'], { prefill: 'client.phone' }),
          choice('siteType', ['Type de site', 'Site type'], ['Résidence principale', 'Résidence secondaire', 'Commerce', 'Bureaux', 'Entrepôt / industrie', 'Établissement recevant du public'],
            ['Main home', 'Second home', 'Shop', 'Offices', 'Warehouse / industrial', 'Public building'], { required: true }),
        ],
      },
      {
        id: 'transmitter', title: ['Transmetteur', 'Transmitter'], fields: [
          text('model', ['Modèle', 'Model'], { prefill: 'equipment.model' }),
          text('protocol', ['Protocole de transmission', 'Transmission protocol']),
          text('backup', ['Secours de transmission', 'Backup path']),
        ],
      },
      {
        id: 'onSite', title: ['A – Appels sur place', 'A – Calls on site'], fields: [
          text('onSite1', ['N° 1', 'No. 1']),
          text('onSite2', ['N° 2', 'No. 2']),
        ],
      },
      { id: 'contacts', title: ['B – Responsables, dans l’ordre d’appel', 'B – Contacts, in calling order'], fields: contacts },
      {
        id: 'companies', title: ['C, D – Intervenants', 'C, D – Responders'], fields: [
          text('responder', ['C – Société d’intervention (agent sur place)', 'C – Response company (guard on site)']),
          text('installer', ['D – Installateur', 'D – Installer'], { prefill: 'company.name' }),
        ],
      },
      {
        id: 'events', title: ['Événements à gérer', 'Events to handle'], fields: [
          list('handled', ['Événements à traiter (appels dans l’ordre A, B, C, D)', 'Events to handle (calls in order A, B, C, D)'],
            ['Intrusion', 'Autoprotection', 'Absence de test cyclique', 'Défaut secteur', 'Défaut batterie', 'Défaut technique', 'Agression', 'Incendie', 'Assistance', 'Absence de mise en service', 'Mise hors service non prévue'],
            ['Intrusion', 'Tamper', 'Missing periodic test', 'Mains failure', 'Battery fault', 'Technical fault', 'Panic / duress', 'Fire', 'Assistance', 'Not armed on time', 'Unexpected disarming']),
          choice('mainsHours', ['Défaut secteur : appeler', 'Mains failure: call'], ['De 8 h à 21 h', '24 h / 24'], ['8 am to 9 pm', '24/7']),
          area('orderChanges', ['Modification de l’ordre d’appel', 'Changes to the calling order']),
        ],
      },
      {
        id: 'options', title: ['Options et horaires', 'Options and schedule'], fields: [
          yesNo('delegation', ['Délégation au centre pour prendre des mesures conservatoires', 'Centre may take protective measures']),
          yesNo('guarding', ['Gardiennage du site après effraction (selon disponibilités)', 'Site guarding after a break-in (subject to availability)']),
          yesNo('police', ['Prévenir les forces de l’ordre après levée de doute', 'Call the police after verification']),
          ...days.flatMap((d, i): FieldDef[] => [
            text(`armOn${i}`, [`Mise en service : ${d[0]}`, `Arming: ${d[1]}`]),
            text(`armOff${i}`, [`Mise hors service : ${d[0]}`, `Disarming: ${d[1]}`]),
          ]),
          yesNo('armReports', ['Transmettre les mises en et hors service', 'Report arming and disarming']),
        ],
      },
      {
        id: 'comments', title: ['Commentaires', 'Comments'], fields: [
          area('comments', ['Informations utiles au centre de télésurveillance', 'Useful information for the monitoring centre']),
        ],
      },
    ],
  };
}

/** Dossier technique et bon de sortie, transmis au service administratif */
function technicalFile(video: boolean): TemplateDef {
  return {
    kind: 'INSTALLATION',
    name: video
      ? ['Dossier technique – vidéoprotection', 'Technical file – video surveillance']
      : ['Dossier technique – alarme et télésurveillance', 'Technical file – alarm and monitoring'],
    sections: [
      {
        id: 'file', title: ['Dossier', 'File'], fields: [
          text('client', ['Client', 'Customer'], { prefill: 'client.name' }),
          text('subscriber', ['N° d’abonné', 'Subscriber number'], { prefill: 'client.subscriberNumber' }),
          day('handoverDate', ['Date de réception (PV et dossier de financement)', 'Handover date (acceptance report and financing file)'], { required: true }),
          list('todo', ['Pièces du dossier', 'Documents in the file'],
            video
              ? ['Plan d’implantation', 'Photos', 'Bon de sortie du matériel', 'PV de réception signé', 'Dossier préfecture (si lieu ouvert au public)']
              : ['Consignes de télésurveillance signées', 'Bon de sortie du matériel', 'PV de réception signé', 'Mandat de prélèvement SEPA'],
            video
              ? ['Layout plan', 'Photos', 'Parts issue slip', 'Signed acceptance report', 'Prefecture file (premises open to the public, France)']
              : ['Signed monitoring instructions', 'Parts issue slip', 'Signed acceptance report', 'SEPA direct debit mandate']),
        ],
      },
      {
        id: 'financing', title: ['Financement', 'Financing'], fields: [
          choice('financing', ['Mode de financement', 'Financing'], ['Achat comptant', 'Location financière', 'Abonnement'], ['Cash purchase', 'Leasing', 'Subscription']),
          text('partner', ['Partenaire financier', 'Finance partner']),
          text('signatory', ['Personne habilitée à signer les contrats', 'Person authorised to sign contracts']),
        ],
      },
      {
        id: 'admin', title: ['Partie réservée au service administratif', 'For the office'], fields: [
          check('validated', ['Dossier complet', 'File complete']),
          ...(video ? [choice('disk', ['Disque dur de l’enregistreur', 'Recorder hard drive'], ['1 To', '2 To', '4 To', '6 To', '8 To'], ['1 TB', '2 TB', '4 TB', '6 TB', '8 TB'])] : []),
          area('serials', ['N° de série du matériel posé', 'Serial numbers of installed equipment'], { required: true, prefill: 'equipment.serialNumber' }),
        ],
      },
    ],
  };
}

/** Procès-verbal de réception des travaux */
const HANDOVER: TemplateDef = {
  kind: 'INSTALLATION',
  name: ['Procès-verbal de réception des travaux', 'Works acceptance report'],
  sections: [
    {
      id: 'works', title: ['Travaux', 'Works'], fields: [
        area('works', ['Travaux réceptionnés', 'Works accepted'], { prefill: 'intervention.reason', required: true }),
        text('site', ['Lieu', 'Place'], { prefill: 'site.fullAddress' }),
        day('date', ['Date de réception', 'Acceptance date'], { required: true }),
      ],
    },
    {
      id: 'decision', title: ['Décision du client', 'Customer decision'], fields: [
        choice('decision', ['Le client prononce la réception', 'The customer accepts the works'], ['Sans réserve', 'Avec les réserves ci-dessous'], ['Without reservations', 'With the reservations below'], { required: true }),
        area('reservations', ['Réserves', 'Reservations']),
        day('reservationsBy', ['Réserves à lever avant le', 'Reservations to be cleared by']),
      ],
    },
    {
      id: 'documents', title: ['Documents remis', 'Documents handed over'], fields: [
        list('documents', ['Documents remis au client', 'Documents given to the customer'],
          ['Notice d’utilisation', 'Plan d’implantation', 'Attestation de formation', 'Consignes de télésurveillance', 'Conditions de garantie'],
          ['User manual', 'Layout plan', 'Training certificate', 'Monitoring instructions', 'Warranty terms']),
        text('warranty', ['Garantie', 'Warranty']),
      ],
    },
  ],
};

interface PackItem { def: TemplateDef; kind: InterventionKind; autoPick: boolean }

/** Le contenu du pack : les fiches prises d'office (une par type), puis les documents à choisir */
export function securityPackItems(): PackItem[] {
  return [
    { def: REPAIR, kind: 'SAV', autoPick: true },
    { def: REPAIR, kind: 'OTHER', autoPick: true },
    { def: MAINTENANCE, kind: 'MAINTENANCE', autoPick: true },
    { def: INSTALLATION, kind: 'INSTALLATION', autoPick: true },
    { def: monitoringInstructions(), kind: 'INSTALLATION', autoPick: false },
    { def: technicalFile(false), kind: 'INSTALLATION', autoPick: false },
    { def: technicalFile(true), kind: 'INSTALLATION', autoPick: false },
    { def: HANDOVER, kind: 'INSTALLATION', autoPick: false },
  ];
}

export function securityPackTemplates(lang: Lang): { name: string; kind: InterventionKind; schema: TemplateSchema; autoPick: boolean }[] {
  return securityPackItems().map(({ def, kind, autoPick }) => ({ ...build(def, lang), kind, autoPick }));
}

/**
 * Ajoute le pack à une société, dans la langue de ses documents. Un modèle déjà présent (même nom, même type)
 * n'est pas ajouté une deuxième fois. Renvoie le nombre de modèles ajoutés.
 */
export async function installSecurityPack(company: { id: string; groupId: string; locale: string }): Promise<number> {
  const lang: Lang = company.locale.toLowerCase().startsWith('fr') ? 'fr' : 'en';
  const existing = await db
    .select({ name: schema.formTemplates.name, kind: schema.formTemplates.kind })
    .from(schema.formTemplates)
    .where(and(eq(schema.formTemplates.companyId, company.id), eq(schema.formTemplates.active, true)));
  const have = new Set(existing.map((t) => `${t.kind}|${t.name}`));
  const toAdd = securityPackTemplates(lang).filter((t) => !have.has(`${t.kind}|${t.name}`));
  if (toAdd.length) {
    await db.insert(schema.formTemplates).values(toAdd.map((t) => ({ ...t, groupId: company.groupId, companyId: company.id })));
  }
  return toAdd.length;
}
