/**
 * Écriture des PDF dans toutes les langues de l'interface.
 *
 * Les polices standard des PDF (Helvetica) ne savent écrire que l'alphabet latin de l'Europe de l'Ouest.
 * Ici, chaque morceau de texte reçoit la police qui sait l'écrire (polices Noto, dossier assets/fonts) :
 * Noto Sans pour le latin et le cyrillique, et selon les caractères : arabe, devanagari (hindi),
 * chinois, japonais ou coréen.
 *
 * Un texte d'une seule écriture passe tel quel à PDFKit. Un texte qui en mélange plusieurs, ou qui
 * contient de l'arabe, est mis en page ici : coupure en lignes, ordre d'affichage de droite à gauche
 * calculé par l'algorithme bidirectionnel d'Unicode (bidi-js), puis dessin morceau par morceau.
 */
import path from 'node:path';
import bidiFactory from 'bidi-js';
import { API_DIR } from '../paths.js';

const FONTS = path.join(API_DIR, 'assets', 'fonts');

type Script = 'latin' | 'arabic' | 'deva' | 'sc' | 'jp' | 'kr';

/** Fichiers de police : gras réel quand il existe, sinon gras simulé (contour) */
const FILES: Record<Script, { regular: string; bold: string | null }> = {
  latin: { regular: 'NotoSans_400Regular.ttf', bold: 'NotoSans_700Bold.ttf' },
  arabic: { regular: 'NotoSansArabic_400Regular.ttf', bold: 'NotoSansArabic_700Bold.ttf' },
  deva: { regular: 'NotoSansDevanagari_400Regular.ttf', bold: 'NotoSansDevanagari_700Bold.ttf' },
  sc: { regular: 'NotoSansSC_400Regular.ttf', bold: null },
  jp: { regular: 'NotoSansJP_400Regular.ttf', bold: null },
  kr: { regular: 'NotoSansKR_400Regular.ttf', bold: null },
};

const isArabic = (cp: number) => (cp >= 0x0600 && cp <= 0x06ff) || (cp >= 0x0750 && cp <= 0x077f) || (cp >= 0x08a0 && cp <= 0x08ff) || (cp >= 0xfb50 && cp <= 0xfdff) || (cp >= 0xfe70 && cp <= 0xfeff);
const ARABIC = /[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]/;
/** Idéogrammes et syllabes : une coupure de ligne est possible entre deux d'entre eux */
const WIDE = '　-ヿ㐀-䶿一-鿿가-힯豈-﫿＀-￯';
const TOKENS = new RegExp(`[${WIDE}]|[^\\s${WIDE}]+|\\s+`, 'g');

let bidi: ReturnType<typeof bidiFactory> | null = null;

export interface WriteOptions extends PDFKit.Mixins.TextOptions {
  bold?: boolean;
}

interface Piece { script: Script; text: string }

export class PdfWriter {
  /** Écriture chinoise, japonaise ou coréenne préférée pour les idéogrammes, selon la langue du document */
  private readonly han: Script;
  /** Document en arabe : les paragraphes se lisent de droite à gauche */
  readonly rtl: boolean;
  private readonly registered = new Set<string>();

  constructor(private readonly doc: PDFKit.PDFDocument, lang: string) {
    this.han = lang === 'ja' ? 'jp' : lang === 'ko' ? 'kr' : 'sc';
    this.rtl = lang === 'ar';
  }

  private scriptOf(ch: string, prev: Script): Script {
    const cp = ch.codePointAt(0)!;
    if (/\s/.test(ch)) return prev; // une espace garde la police du mot précédent
    if (isArabic(cp)) return 'arabic';
    if (cp >= 0x0900 && cp <= 0x097f) return 'deva';
    if ((cp >= 0xac00 && cp <= 0xd7af) || (cp >= 0x1100 && cp <= 0x11ff) || (cp >= 0x3130 && cp <= 0x318f)) return 'kr';
    if (cp >= 0x3040 && cp <= 0x30ff) return 'jp';
    if ((cp >= 0x3000 && cp <= 0x303f) || (cp >= 0x3400 && cp <= 0x4dbf) || (cp >= 0x4e00 && cp <= 0x9fff) || (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xff00 && cp <= 0xffef)) return this.han;
    return 'latin';
  }

  /** Nom de police PDFKit (enregistrée à la première utilisation) et gras simulé si besoin */
  private use(script: Script, bold: boolean): { name: string; fakeBold: boolean } {
    const f = FILES[script];
    const name = `${script}${bold && f.bold ? '-b' : ''}`;
    if (!this.registered.has(name)) {
      this.doc.registerFont(name, path.join(FONTS, bold && f.bold ? f.bold : f.regular));
      this.registered.add(name);
    }
    return { name, fakeBold: bold && !f.bold };
  }

  /** Découpe en morceaux d'une même police */
  private pieces(text: string): Piece[] {
    const out: Piece[] = [];
    let prev: Script = 'latin';
    for (const ch of text) {
      const s = this.scriptOf(ch, prev);
      if (out.length && out[out.length - 1].script === s) out[out.length - 1].text += ch;
      else out.push({ script: s, text: ch });
      prev = s;
    }
    return out;
  }

  /** Sélectionne la police latine (normale ou grasse) */
  font(bold = false): this {
    this.doc.font(this.use('latin', bold).name);
    return this;
  }

  /** Largeur d'un texte dans la taille de police en cours */
  width(text: string, bold = false): number {
    let w = 0;
    for (const p of this.pieces(text)) w += this.doc.font(this.use(p.script, bold).name).widthOfString(p.text);
    return w;
  }

  private simple(text: string): Piece | null {
    if (ARABIC.test(text)) return null;
    const p = this.pieces(text);
    return p.length <= 1 ? p[0] ?? { script: 'latin', text } : null;
  }

  private lineHeight(text: string, bold: boolean, lineGap = 0): number {
    const scripts = new Set(this.pieces(text).map((p) => p.script));
    let h = 0;
    for (const s of scripts) h = Math.max(h, this.doc.font(this.use(s, bold).name).currentLineHeight(true));
    return (h || this.doc.font(this.use('latin', bold).name).currentLineHeight(true)) + lineGap;
  }

  /** Lignes d'un texte coupé à la largeur donnée (ordre logique) */
  private wrap(text: string, width: number, bold: boolean, lineBreak: boolean): string[] {
    const lines: string[] = [];
    for (const para of text.split('\n')) {
      if (!lineBreak) {
        lines.push(para);
        continue;
      }
      let line = '';
      for (const tok of para.match(TOKENS) ?? []) {
        if (!line && /^\s+$/.test(tok)) continue;
        const next = line + tok;
        if (line && !/^\s+$/.test(tok) && this.width(next.trimEnd(), bold) > width) {
          lines.push(line.trimEnd());
          line = tok;
        } else line = next;
      }
      lines.push(line.trimEnd());
    }
    return lines;
  }

  /** Hauteur d'un texte une fois coupé à la largeur donnée */
  height(text: string, opts: WriteOptions = {}): number {
    const bold = !!opts.bold;
    const s = this.simple(text);
    if (s) return this.doc.font(this.use(s.script, bold).name).heightOfString(text, opts);
    const width = opts.width ?? this.doc.page.width - this.doc.page.margins.left - this.doc.page.margins.right;
    return this.wrap(text, width, bold, opts.lineBreak !== false).length * this.lineHeight(text, bold, opts.lineGap);
  }

  /** Comme doc.text(texte, x, y, options), avec la bonne police pour chaque morceau */
  text(text: string, x?: number, y?: number, opts: WriteOptions = {}): this {
    const doc = this.doc;
    const { bold, ...rest } = opts;
    const s = this.simple(text);
    if (s) {
      const { name, fakeBold } = this.use(s.script, !!bold);
      doc.font(name);
      this.draw(() => (x === undefined ? doc.text(text, rest) : doc.text(text, x, y, rest)), fakeBold);
      return this;
    }
    return this.layout(text, x ?? doc.x, y ?? doc.y, opts);
  }

  /** Gras simulé : le texte est aussi tracé en contour fin, de sa propre couleur */
  private draw(fn: () => void, fakeBold: boolean) {
    if (!fakeBold) return fn();
    const doc = this.doc as PDFKit.PDFDocument & { _fillColor?: [unknown, number] };
    const color = doc._fillColor?.[0];
    doc.save();
    doc.lineWidth(0.35).strokeColor(typeof color === 'string' ? color : '#14181F');
    const text = doc.text.bind(doc);
    // Toutes les écritures faites dans fn reçoivent le contour en plus du remplissage
    (doc as unknown as { text: unknown }).text = (...args: unknown[]) => {
      const last = args[args.length - 1];
      if (last && typeof last === 'object') Object.assign(last, { stroke: true, fill: true });
      else args.push({ stroke: true, fill: true });
      return (text as (...a: unknown[]) => unknown)(...args);
    };
    try {
      fn();
    } finally {
      (doc as unknown as { text: unknown }).text = text;
      doc.restore();
    }
  }

  /**
   * Mise en page d'un texte mêlant plusieurs écritures : coupure en lignes dans l'ordre logique, puis
   * chaque ligne est remise dans l'ordre d'affichage et dessinée morceau par morceau.
   */
  private layout(text: string, x: number, y: number, opts: WriteOptions): this {
    const doc = this.doc;
    const bold = !!opts.bold;
    const width = opts.width ?? doc.page.width - doc.page.margins.right - x;
    const lineHeight = this.lineHeight(text, bold, opts.lineGap);

    let cy = y;
    for (const logical of this.wrap(text, width, bold, opts.lineBreak !== false)) {
      const firstStrong = logical.match(/\p{L}/u)?.[0] ?? '';
      const base = this.rtl || ARABIC.test(firstStrong) ? 'rtl' : 'ltr';
      const chars = [...logical];
      // Ordre d'affichage, sans puis avec les caractères « miroirs » (une parenthèse ouvrante devient fermante)
      let plain = chars;
      let mirroredChars = chars;
      if (ARABIC.test(logical)) {
        bidi ??= bidiFactory();
        const levels = bidi.getEmbeddingLevels(logical, base);
        const order = chars.map((_, i) => i);
        for (const [s, e] of bidi.getReorderSegments(logical, levels)) {
          const seg = order.slice(s, e + 1).reverse();
          order.splice(s, seg.length, ...seg);
        }
        const mirrored = bidi.getMirroredCharactersMap(logical, levels);
        plain = order.map((i) => chars[i]);
        mirroredChars = order.map((i) => mirrored.get(i) ?? chars[i]);
      }
      // Morceaux à dessiner de gauche à droite. Un mot arabe est donné à la police dans l'ordre
      // logique : elle le met en forme, le retourne et retourne elle-même ses parenthèses.
      // Les autres morceaux sont dessinés tels quels, avec les caractères miroirs.
      const parts: { script: Script; text: string; w: number }[] = [];
      let offset = 0;
      for (const p of this.pieces(plain.join(''))) {
        const len = [...p.text].length;
        const tokens: string[] = [];
        if (p.script === 'arabic') {
          let at = offset;
          for (const tok of p.text.split(/(\s+)/).filter(Boolean)) {
            const n = [...tok].length;
            tokens.push(ARABIC.test(tok) ? plain.slice(at, at + n).reverse().join('') : mirroredChars.slice(at, at + n).join(''));
            at += n;
          }
        } else tokens.push(mirroredChars.slice(offset, offset + len).join(''));
        offset += len;
        doc.font(this.use(p.script, bold).name);
        for (const t of tokens) parts.push({ script: p.script, text: t, w: doc.widthOfString(t) });
      }
      const total = parts.reduce((s, p) => s + p.w, 0);
      // Sans alignement demandé, un paragraphe de droite à gauche se cale à droite
      const align = opts.align ?? (base === 'rtl' ? 'right' : 'left');
      let cx = align === 'center' ? x + (width - total) / 2 : align === 'right' ? x + width - total : x;
      for (const p of parts) {
        const { name, fakeBold } = this.use(p.script, bold);
        doc.font(name);
        if (/\S/.test(p.text)) this.draw(() => doc.text(p.text, cx, cy, { lineBreak: false, characterSpacing: opts.characterSpacing }), fakeBold);
        cx += p.w;
      }
      cy += lineHeight;
    }
    doc.x = x;
    doc.y = cy;
    return this;
  }
}

// ─── Pied de page commun (fiches, devis et factures, bons de sortie) ───

const FOOTER_FONT = 7.5;
const FOOTER_LINE = 9.5;
/** Caractères par ligne de pied de page, au plus juste (A4, marges de 40) : sert à réserver la place */
const FOOTER_CHARS_PER_LINE = 110;

/**
 * Marge du bas d'un document : les mentions légales longues (agréments, capital…) tiennent sur plusieurs
 * lignes ; la page leur laisse la place pour que le texte ne passe jamais dessous.
 */
export function footerMargin(legalMentions: string | null | undefined, base = 40): number {
  const lines = legalMentions ? Math.ceil(legalMentions.length / FOOTER_CHARS_PER_LINE) : 0;
  return base + Math.max(0, lines - 1) * FOOTER_LINE;
}

/**
 * Pied de page : mentions légales et « n° · page x/y ». Sur une seule ligne s'il tient, sinon les mentions
 * au-dessus (sur plusieurs lignes, centrées) et le numéro de page dessous.
 */
export function drawFooter(doc: PDFKit.PDFDocument, w: PdfWriter, legalMentions: string | null | undefined, pageLine: string, color: string) {
  const left = doc.page.margins.left;
  const width = doc.page.width - left - doc.page.margins.right;
  const pageLineY = doc.page.height - 40 - 18;
  const bottom = doc.page.margins.bottom;
  // Pas de saut de page automatique pendant que l'on écrit sous la zone de texte
  doc.page.margins.bottom = 0;
  doc.fontSize(FOOTER_FONT).fillColor(color);
  const oneLine = [legalMentions, pageLine].filter(Boolean).join('   ');
  if (!legalMentions || w.width(oneLine) <= width) {
    w.text(oneLine, left, pageLineY, { width, align: 'center', lineBreak: false });
  } else {
    const h = w.height(legalMentions, { width, align: 'center' });
    w.text(legalMentions, left, pageLineY - h, { width, align: 'center' });
    w.text(pageLine, left, pageLineY, { width, align: 'center', lineBreak: false });
  }
  doc.page.margins.bottom = bottom;
}
