/**
 * Heure d'une action faite sur l'appareil, éventuellement hors connexion
 * (« je suis sur place », signature…) et envoyée plus tard.
 *
 * On garde l'heure de l'appareil si elle est plausible : pas dans le futur (5 min de tolérance
 * pour les horloges mal réglées), pas plus vieille que 7 jours. Sinon, l'heure du serveur.
 */
const FUTURE_TOLERANCE_MS = 5 * 60 * 1000;
const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

export function deviceTime(at: Date | undefined, now = new Date()): Date {
  if (!at || Number.isNaN(at.getTime())) return now;
  const t = at.getTime();
  if (t > now.getTime() + FUTURE_TOLERANCE_MS || t < now.getTime() - MAX_AGE_MS) return now;
  return t > now.getTime() ? now : at;
}
