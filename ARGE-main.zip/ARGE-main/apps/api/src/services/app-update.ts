/**
 * Mises à jour de l'appli Android installée hors Play Store : le serveur garde la dernière APK publiée
 * (STORAGE_DIR/app) et son numéro de version. L'appli le compare au sien et propose la mise à jour.
 */
import { createHash } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import { env } from '../env.js';

export const MAX_APK_BYTES = 150 * 1024 * 1024;

const dir = () => path.resolve(env.STORAGE_DIR, 'app');
export const apkPath = () => path.join(dir(), 'android.apk');
const infoPath = () => path.join(dir(), 'android.json');

export const releaseInput = z.object({
  /** Numéro croissant donné à chaque construction (versionCode d'Android) */
  versionCode: z.coerce.number().int().min(1).max(2_100_000_000),
  versionName: z.string().trim().min(1).max(40),
  notes: z.string().trim().max(500).optional().default(''),
});
export type ReleaseInput = z.infer<typeof releaseInput>;
/** sha256 : empreinte de l'APK, vérifiée par l'appli avant l'installation */
export type Release = ReleaseInput & { size: number; sha256: string; publishedAt: string };

/** Dernière version publiée, ou null */
export async function currentRelease(): Promise<Release | null> {
  try {
    return JSON.parse(await readFile(infoPath(), 'utf8')) as Release;
  } catch {
    return null;
  }
}

/** Une APK est une archive ZIP : on vérifie la signature, pas seulement le type annoncé */
export const looksLikeApk = (b: Buffer) => b.length > 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;

/** Range la nouvelle APK puis sa fiche (écrites à côté puis renommées : jamais de fichier à moitié écrit) */
export async function publishRelease(apk: Buffer, input: ReleaseInput): Promise<Release> {
  await mkdir(dir(), { recursive: true });
  const sha256 = createHash('sha256').update(apk).digest('hex');
  const release: Release = { ...input, size: apk.length, sha256, publishedAt: new Date().toISOString() };
  await writeFile(`${apkPath()}.tmp`, apk);
  await rename(`${apkPath()}.tmp`, apkPath());
  await writeFile(`${infoPath()}.tmp`, JSON.stringify(release, null, 2));
  await rename(`${infoPath()}.tmp`, infoPath());
  return release;
}
