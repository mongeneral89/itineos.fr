/**
 * Génération du PDF de la fiche d'intervention.
 * La mise en page suit le modèle de la fiche (sections et champs). Les textes fixes sont dans la langue\n * du client (à défaut celle de la société) ; les champs du modèle restent tels que la société les a écrits.
 */
import PDFDocument from 'pdfkit';
import type { InterventionKind, Outcome, PhotoKind, ReportData, Sector, TemplateSchema } from '@itineo/shared';
import { docLang, docTexts, formatLocale, type DocTexts } from './doc-i18n.js';
import { drawFooter, footerMargin, PdfWriter } from './pdf-text.js';
import { sectorDocTexts, sectorKindLabel, sectorWordsFor } from './sector-doc.js';
import { drawPdfLogo } from './logo.js';

export interface ReportPdfInput {
  /** Langue du document (celle du client, sinon celle de la société) */
  locale: string;
  /** Titre du document, à la place de « Fiche d'intervention » */
  title?: string;
  timezone: string;
  company: {
    name: string; legalName?: string | null; address?: string | null; postalCode?: string | null;
    city?: string | null; phone?: string | null; email?: string | null; vatNumber?: string | null;
    legalMentions?: string | null;
    /** Logo de la société (PNG ou JPEG) */
    logo?: Buffer | null;
  };
  agency: { name: string; phone?: string | null; email?: string | null };
  intervention: { number: string; kind: InterventionKind; reason: string };
  client: { name: string; address: string; phone?: string | null; email?: string | null };
  site: { name: string; address: string };
  technicianName: string;
  report: {
    schema: TemplateSchema;
    data: ReportData;
    arrivedAt: Date | null;
    leftAt: Date | null;
    laborMinutes: number | null;
    travelMinutes: number | null;
    outcome: string | null;
    technicianSignature: string | null;
    clientSignature: string | null;
    clientSignerName: string | null;
    clientAbsent: boolean;
    clientAbsentReason: string | null;
    signedAt: Date | null;
  };
  parts: { label: string; reference: string | null; quantity: number }[];
  photos: { kind: PhotoKind; caption: string | null; image: Buffer; takenAt?: Date | null; sha256?: string | null }[];
  /** Édition : vocabulaire et type d'intervention du métier */
  sector?: Sector;
  /** Ville du lieu (« Fait à … ») */
  place?: string | null;
  /** Itinéos Vigie : points de passage du site et heure de pointage */
  checkpoints?: { name: string; at: Date | null }[];
  /** Itinéos Clés : état des lieux d'entrée à comparer */
  comparison?: { number: string; date: Date | null; fields: { label: string; before: ReportData[string]; after: ReportData[string] }[] } | null;
  /** Itinéos Constat / Expertise : photos numérotées, horodatées, avec leur empreinte */
  photoProof?: boolean;
}

const INK = '#14181F';
const MUTED = '#5B616B';
const RULE = '#D9D4CA';

function dataUrlToBuffer(dataUrl: string | null): Buffer | null {
  if (!dataUrl) return null;
  const m = /^data:image\/(png|jpeg);base64,(.+)$/.exec(dataUrl);
  return m ? Buffer.from(m[2], 'base64') : null;
}

function formatValue(v: ReportData[string], t: DocTexts, type?: string, locale = 'fr-FR'): string {
  if (v === null || v === undefined || v === '') return '—';
  if (typeof v === 'boolean') return v ? t.yes : t.no;
  // Champ date (AAAA-MM-JJ) : écrit comme sur le reste du document (19/10/2026), pas au format informatique
  if (type === 'date' && typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) {
    return new Intl.DateTimeFormat(locale, { timeZone: 'UTC', dateStyle: 'short' }).format(new Date(`${v}T00:00:00Z`));
  }
  if (Array.isArray(v)) return v.length ? v.join(' · ') : '—';
  return String(v);
}

export function generateReportPdf(input: ReportPdfInput): Promise<Buffer> {
  const t = docTexts(input.locale);
  const st = sectorDocTexts(input.locale);
  const sector = input.sector ?? 'TECH';
  // « Technicien » devient « Agent », « Intervention » devient « Mission »… (documents en français ou en anglais)
  const sw = sectorWordsFor(sector, input.locale);
  const loc = formatLocale(input.locale);
  const fmtDateTime = (d: Date | null) =>
    d ? new Intl.DateTimeFormat(loc, { timeZone: input.timezone, dateStyle: 'short', timeStyle: 'short' }).format(d) : '—';
  const fmtDate = (d: Date) =>
    new Intl.DateTimeFormat(loc, { timeZone: input.timezone, dateStyle: 'long' }).format(d);

  // Document particulier (« Consignes de télésurveillance ») : son nom sert de titre
  const title = input.title ?? t.reportTitle;
  const doc = new PDFDocument({ size: 'A4', margins: { top: 40, left: 40, right: 40, bottom: footerMargin(input.company.legalMentions) }, bufferPages: true, info: { Title: `${title} ${input.intervention.number}` } });
  const w = new PdfWriter(doc, docLang(input.locale));
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  const left = doc.page.margins.left;
  const width = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const bottomLimit = () => doc.page.height - doc.page.margins.bottom - 40;
  const ensureSpace = (h: number) => {
    if (doc.y + h > bottomLimit()) doc.addPage();
  };

  const heading = (text: string) => {
    ensureSpace(40);
    doc.moveDown(0.6);
    doc.fontSize(11).fillColor(INK);
    w.text(text.toUpperCase(), left, doc.y, { characterSpacing: 0.5, bold: true });
    const y = doc.y + 2;
    doc.moveTo(left, y).lineTo(left + width, y).lineWidth(0.8).strokeColor(RULE).stroke();
    doc.moveDown(0.4);
  };

  const row = (label: string, value: string) => {
    ensureSpace(24);
    const y = doc.y;
    doc.fontSize(9).fillColor(MUTED);
    w.text(label, left, y, { width: 150 });
    const afterLabel = doc.y;
    doc.fontSize(10).fillColor(INK);
    w.text(value, left + 160, y, { width: width - 160 });
    doc.y = Math.max(doc.y, afterLabel);
    doc.moveDown(0.3);
  };

  // ─── En-tête ───
  const c = input.company;
  const top = doc.y;
  const logoH = drawPdfLogo(doc, c.logo, left, top);
  doc.fontSize(15).fillColor(INK);
  w.text(c.name, left, top + logoH, { width: width * 0.55, bold: true });
  doc.fontSize(8.5).fillColor(MUTED);
  const companyLines = [
    c.legalName,
    [c.address, [c.postalCode, c.city].filter(Boolean).join(' ')].filter(Boolean).join(', '),
    [c.phone, c.email].filter(Boolean).join(' · '),
    c.vatNumber ? `${t.vat} ${c.vatNumber}` : null,
    input.agency.name,
  ].filter(Boolean) as string[];
  for (const line of companyLines) w.text(line, left, doc.y, { width: width * 0.55, align: 'left' });
  const afterCompany = doc.y;

  doc.fontSize(13).fillColor(INK);
  w.text(title, left + width * 0.55, top, { width: width * 0.45, align: 'right', bold: true });
  doc.fontSize(10);
  w.text(`${t.number} ${input.intervention.number}`, left + width * 0.55, doc.y, { width: width * 0.45, align: 'right' });
  doc.fillColor(MUTED).fontSize(9);
  w.text(`${t.date} : ${fmtDate(input.report.signedAt ?? input.report.leftAt ?? new Date())}`, left + width * 0.55, doc.y, { width: width * 0.45, align: 'right' });
  doc.y = Math.max(afterCompany, doc.y) + 10;

  // ─── Client et lieu ───
  const boxTop = doc.y;
  const half = (width - 12) / 2;
  const box = (x: number, title: string, lines: string[]) => {
    doc.fontSize(9).fillColor(MUTED);
    w.text(title.toUpperCase(), x + 10, boxTop + 8, { width: half - 20, bold: true });
    doc.fontSize(10).fillColor(INK);
    for (const l of lines.filter(Boolean)) w.text(l, x + 10, doc.y + 1, { width: half - 20 });
    return doc.y;
  };
  const endA = box(left, t.client, [input.client.name, input.client.address, input.client.phone ?? '', input.client.email ?? '']);
  const endB = box(left + half + 12, t.site, [input.site.name, input.site.address]);
  const boxBottom = Math.max(endA, endB) + 8;
  doc.roundedRect(left, boxTop, half, boxBottom - boxTop, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  doc.roundedRect(left + half + 12, boxTop, half, boxBottom - boxTop, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  doc.y = boxBottom + 4;

  // ─── Intervention ───
  heading(sw(t.intervention));
  row(t.type, sectorKindLabel(sector, input.intervention.kind, input.locale) ?? t.kinds[input.intervention.kind]);
  row(sw(t.technician), input.technicianName);
  row(t.arrival, fmtDateTime(input.report.arrivedAt));
  row(t.departure, fmtDateTime(input.report.leftAt));
  row(t.reason, input.intervention.reason);

  // ─── Sections du modèle ───
  for (const section of input.report.schema.sections) {
    heading(section.title);
    for (const field of section.fields) row(field.label, formatValue(input.report.data[field.id], t, field.type, loc));
  }

  // ─── Itinéos Vigie : points de passage ───
  if (input.checkpoints?.length) {
    heading(st.checkpoints);
    const done = input.checkpoints.filter((cp) => cp.at).length;
    for (const cp of input.checkpoints) row(cp.name, cp.at ? fmtDateTime(cp.at) : st.notScanned);
    doc.fontSize(9).fillColor(MUTED);
    w.text(st.checkpointsDone(done, input.checkpoints.length), left, doc.y, { width });
  }

  // ─── Itinéos Clés : différences avec l'état des lieux d'entrée ───
  if (input.comparison) {
    heading(st.comparison);
    doc.fontSize(9).fillColor(MUTED);
    w.text(st.comparisonOf(input.comparison.number, input.comparison.date ? fmtDate(input.comparison.date) : '—'), left, doc.y, { width });
    doc.moveDown(0.3);
    const changed = input.comparison.fields.filter((f) => formatValue(f.before, t) !== formatValue(f.after, t));
    for (const f of changed) row(f.label, `${st.atEntry} : ${formatValue(f.before, t)}\n${st.atExit} : ${formatValue(f.after, t)}`);
    doc.fontSize(9).fillColor(MUTED);
    w.text(changed.length ? st.unchanged(input.comparison.fields.length - changed.length) : st.noDifference, left, doc.y, { width });
  }

  // ─── Pièces ───
  if (input.parts.length) {
    heading(t.parts);
    const cols = [left, left + width * 0.6, left + width * 0.88];
    ensureSpace(20);
    let y = doc.y;
    doc.fontSize(9).fillColor(MUTED);
    w.text(t.description, cols[0], y, { width: width * 0.58, bold: true });
    w.text(t.reference, cols[1], y, { width: width * 0.26, bold: true });
    w.text(t.qty, cols[2], y, { width: width * 0.12, align: 'right', bold: true });
    doc.moveDown(0.3);
    doc.fontSize(10).fillColor(INK);
    for (const p of input.parts) {
      ensureSpace(18);
      y = doc.y;
      w.text(p.label, cols[0], y, { width: width * 0.58 });
      const h = doc.y;
      w.text(p.reference ?? '—', cols[1], y, { width: width * 0.26 });
      w.text(String(p.quantity), cols[2], y, { width: width * 0.12, align: 'right' });
      doc.y = Math.max(h, doc.y) + 2;
    }
  }

  // ─── Temps et résultat ───
  heading(t.time);
  row(t.labor, input.report.laborMinutes != null ? `${input.report.laborMinutes} ${t.min}` : '—');
  row(t.travel, input.report.travelMinutes != null ? `${input.report.travelMinutes} ${t.min}` : '—');
  row(t.outcome, input.report.outcome ? (t.outcomes[input.report.outcome as Outcome] ?? input.report.outcome) : '—');

  // ─── Photos : deux par ligne, légendées ───
  if (input.photos.length) {
    const photoH = 180;
    ensureSpace(photoH + 70); // le titre ne reste pas seul en bas de page
    heading(t.photos);
    for (let i = 0; i < input.photos.length; i += 2) {
      ensureSpace(photoH + 30);
      const rowTop = doc.y + 2;
      input.photos.slice(i, i + 2).forEach((ph, k) => {
        const x = left + k * (half + 12);
        try {
          doc.image(ph.image, x, rowTop, { fit: [half, photoH], align: 'center', valign: 'center' });
        } catch {
          doc.roundedRect(x, rowTop, half, photoH, 4).lineWidth(0.8).strokeColor(RULE).stroke();
        }
        // Procès-verbal : photos numérotées et horodatées, reprises dans les empreintes plus bas
        const proof = input.photoProof
          ? [st.photoNo(i + k + 1), ph.takenAt ? `${st.takenAt} ${fmtDateTime(ph.takenAt)}` : null].filter(Boolean).join(' ')
          : null;
        const caption = [proof, t.photoKinds[ph.kind], ph.caption].filter(Boolean).join(' · ');
        doc.fontSize(9).fillColor(MUTED);
        w.text(caption, x, rowTop + photoH + 4, { width: half });
      });
      doc.y = rowTop + photoH + 22;
    }
    if (input.photoProof) {
      heading(st.fingerprints);
      doc.fontSize(8.5).fillColor(MUTED);
      w.text(st.fingerprintsInfo, left, doc.y, { width });
      doc.moveDown(0.4);
      input.photos.forEach((ph, k) => {
        ensureSpace(16);
        const y = doc.y;
        doc.fontSize(8.5).fillColor(MUTED);
        w.text(st.photoNo(k + 1), left, y, { width: 80 });
        doc.fontSize(8).fillColor(INK);
        w.text(ph.sha256 ?? '—', left + 90, y, { width: width - 90 });
        doc.moveDown(0.15);
      });
    }
  }

  // ─── Lieu et date (procès-verbal) ───
  if (input.photoProof) {
    ensureSpace(30);
    doc.moveDown(0.6);
    doc.fontSize(10).fillColor(INK);
    const when = fmtDate(input.report.signedAt ?? input.report.leftAt ?? new Date());
    w.text(input.place ? st.madeAt(input.place, when) : st.madeOn(when), left, doc.y, { width });
  }

  // ─── Signatures ───
  ensureSpace(150);
  heading(t.signatures);
  const sigTop = doc.y + 4;
  const sigH = 80;
  const drawSig = (x: number, title: string, img: Buffer | null, caption: string) => {
    doc.fontSize(9).fillColor(MUTED);
    w.text(title, x, sigTop, { width: half });
    doc.roundedRect(x, sigTop + 14, half, sigH, 4).lineWidth(0.8).strokeColor(RULE).stroke();
    if (img) {
      try {
        doc.image(img, x + 8, sigTop + 18, { fit: [half - 16, sigH - 8], align: 'center', valign: 'center' });
      } catch {
        /* image illisible : on laisse le cadre vide */
      }
    }
    doc.fontSize(9).fillColor(INK);
    w.text(caption, x, sigTop + sigH + 18, { width: half });
  };
  drawSig(left, sw(t.techSign), dataUrlToBuffer(input.report.technicianSignature), input.technicianName);
  const clientCaption = input.report.clientAbsent
    ? `${t.absent}${input.report.clientAbsentReason ? ` : ${input.report.clientAbsentReason}` : ''}`
    : input.report.clientSignerName ?? '';
  drawSig(left + half + 12, t.clientSign, input.report.clientAbsent ? null : dataUrlToBuffer(input.report.clientSignature), clientCaption);
  doc.y = sigTop + sigH + 36;
  doc.fontSize(8.5).fillColor(MUTED);
  w.text(sw(t.reportAcceptance), left, doc.y, { width });

  // ─── Pied de page sur chaque page ───
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    drawFooter(doc, w, c.legalMentions, `${input.intervention.number} · ${t.page} ${i + 1}/${range.count}`, MUTED);
  }

  doc.end();
  return done;
}
