/**
 * Localisation des adresses des sites (France) par le service public d'adresses de l'IGN (Géoplateforme,
 * gratuit, sans compte). Utilisée seulement si la société l'a activée ; les coordonnées trouvées sont gardées
 * sur le site pour ne plus jamais redemander.
 */
import { and, eq, isNull } from 'drizzle-orm';
import { db, schema } from '../db/client.js';

const URL_BASE = 'https://data.geopf.fr/geocodage/search';

export async function geocodeAddress(address: string): Promise<{ lat: number; lng: number } | null> {
  // Jamais d'appel extérieur pendant les tests automatiques
  if (process.env.NODE_ENV === 'test' || process.env.NODE_TEST_CONTEXT) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 4000);
  try {
    const res = await fetch(`${URL_BASE}?q=${encodeURIComponent(address)}&limit=1`, { signal: controller.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) return null;
    const data = (await res.json()) as { features?: { geometry?: { coordinates?: [number, number] }; properties?: { score?: number } }[] };
    const f = data.features?.[0];
    const c = f?.geometry?.coordinates;
    if (!c || (f?.properties?.score ?? 0) < 0.5) return null;
    return { lng: c[0], lat: c[1] };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Localise un site sans coordonnées (adresses françaises seulement) ; renvoie ses coordonnées si trouvées */
export async function locateSite(siteId: string): Promise<{ lat: number; lng: number } | null> {
  const s = schema.sites;
  const [site] = await db.select().from(s).where(eq(s.id, siteId));
  if (!site) return null;
  if (site.latitude != null && site.longitude != null) return { lat: site.latitude, lng: site.longitude };
  if (site.countryCode && site.countryCode !== 'FR') return null;
  const q = [site.address, site.postalCode, site.city].filter(Boolean).join(' ');
  if (q.trim().length < 6) return null;
  const found = await geocodeAddress(q);
  if (!found) return null;
  await db.update(s).set({ latitude: found.lat, longitude: found.lng, geoSource: 'GEOCODED' }).where(and(eq(s.id, siteId), isNull(s.latitude)));
  return found;
}
