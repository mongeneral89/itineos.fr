/**
 * Limitation des tentatives (connexion, mot de passe oublié…), en mémoire du serveur.
 *
 * Chaque clé (un e-mail, une adresse IP) a droit à `max` échecs sur une fenêtre de `windowMs`.
 * Au-delà, elle est bloquée jusqu'à ce que les plus anciens échecs sortent de la fenêtre.
 * Suffisant pour un serveur unique ; avec plusieurs serveurs, il faudrait un stockage partagé.
 */
export class AttemptLimiter {
  private readonly hits = new Map<string, number[]>();

  constructor(private readonly max: number, private readonly windowMs: number) {}

  private recent(key: string, now: number): number[] {
    const list = (this.hits.get(key) ?? []).filter((t) => now - t < this.windowMs);
    if (list.length) this.hits.set(key, list);
    else this.hits.delete(key);
    return list;
  }

  /** Bloqué ? et pour combien de temps encore (ms) */
  check(key: string, now = Date.now()): { blocked: boolean; retryAfterMs: number } {
    const list = this.recent(key, now);
    if (list.length < this.max) return { blocked: false, retryAfterMs: 0 };
    return { blocked: true, retryAfterMs: this.windowMs - (now - list[list.length - this.max]) };
  }

  /** Enregistre un échec (ou une demande, pour ce qui est limité à chaque appel) */
  hit(key: string, now = Date.now()): void {
    const list = this.recent(key, now);
    list.push(now);
    this.hits.set(key, list);
    if (this.hits.size > 50_000) this.sweep(now);
  }

  /** Réussite : le compteur repart de zéro */
  reset(key: string): void {
    this.hits.delete(key);
  }

  /** Oublie les clés dont tous les essais sont trop anciens (mémoire bornée) */
  sweep(now = Date.now()): void {
    for (const key of [...this.hits.keys()]) this.recent(key, now);
  }
}

const FIFTEEN_MIN = 15 * 60 * 1000;

/**
 * Mauvais mots de passe pour un même compte depuis une même adresse. Le blocage vise l'adresse qui se trompe,
 * pas le compte : quelqu'un qui connaît l'e-mail d'un collègue ne peut pas l'empêcher de se connecter.
 */
export const loginByAccountIp = new AttemptLimiter(5, FIFTEEN_MIN);
/** Mauvais mots de passe pour un même compte, toutes adresses confondues : freine une attaque répartie */
export const loginByAccount = new AttemptLimiter(100, FIFTEEN_MIN);
/** Mauvais mots de passe depuis une même adresse, tous comptes confondus */
export const loginByIp = new AttemptLimiter(30, FIFTEEN_MIN);
/** Mauvais mot de passe actuel lors d'un changement de mot de passe (par utilisateur connecté) */
export const passwordChangeByUser = new AttemptLimiter(5, FIFTEEN_MIN);

/** Les compteurs d'une connexion (compte = e-mail en minuscules, préfixé pour le portail) */
export const loginAttempts = {
  check(account: string, ip: string) {
    return [loginByAccountIp.check(`${account}|${ip}`), loginByAccount.check(account), loginByIp.check(ip)];
  },
  /** Échec : compté partout. Renvoie vrai si cette adresse est désormais bloquée pour ce compte. */
  fail(account: string, ip: string): boolean {
    loginByAccountIp.hit(`${account}|${ip}`);
    loginByAccount.hit(account);
    loginByIp.hit(ip);
    return loginByAccountIp.check(`${account}|${ip}`).blocked;
  },
  succeed(account: string, ip: string) {
    loginByAccountIp.reset(`${account}|${ip}`);
  },
};
/** Demandes « mot de passe oublié » depuis une même adresse */
export const forgotByIp = new AttemptLimiter(5, FIFTEEN_MIN);
/** Liens d'invitation (page, mot de passe choisi, ouverture de l'appli) : de quoi finir, pas de quoi deviner un lien */
export const invitationByIp = new AttemptLimiter(20, FIFTEEN_MIN);

export function tooManyMessage(retryAfterMs: number): string {
  const min = Math.max(1, Math.ceil(retryAfterMs / 60_000));
  return `Trop de tentatives. Réessayez dans ${min} minute${min > 1 ? 's' : ''}.`;
}
