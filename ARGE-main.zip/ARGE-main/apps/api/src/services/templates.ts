import { and, desc, eq, isNull, ne, or } from 'drizzle-orm';
import { INTERVENTION_KINDS, type InterventionKind, type Sector } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { buildDefaultTemplate, buildExtraTemplates, DEFAULT_LANGS } from './default-templates.js';
import { buildSectorTemplates, TEMPLATE_SECTORS } from './sector-templates.js';
import { langOf } from './prefill.js';

/** Crée les modèles neutres et ceux de chaque secteur s'ils n'existent pas encore (appelé au démarrage). */
export async function ensureSystemTemplates(): Promise<number> {
  const existing = await db
    .select({ name: schema.formTemplates.name, kind: schema.formTemplates.kind, sector: schema.formTemplates.sector })
    .from(schema.formTemplates)
    .where(and(isNull(schema.formTemplates.groupId), isNull(schema.formTemplates.companyId)));
  const have = new Set(existing.map((t) => `${t.sector ?? ''}|${t.kind}|${t.name}`));
  let created = 0;
  for (const lang of DEFAULT_LANGS) {
    for (const kind of INTERVENTION_KINDS) {
      const { name, schema: s } = buildDefaultTemplate(kind, lang);
      if (have.has(`|${kind}|${name}`)) continue;
      await db.insert(schema.formTemplates).values({ name, kind, schema: s });
      created++;
    }
    for (const extra of buildExtraTemplates(lang)) {
      if (have.has(`|${extra.kind}|${extra.name}`)) continue;
      await db.insert(schema.formTemplates).values({ ...extra, autoPick: false });
      created++;
    }
    for (const sector of TEMPLATE_SECTORS) {
      for (const tpl of buildSectorTemplates(sector, lang)) {
        if (have.has(`${sector}|${tpl.kind}|${tpl.name}`)) continue;
        await db.insert(schema.formTemplates).values({ ...tpl, sector });
        created++;
      }
    }
  }
  return created;
}

/** Une installation = une édition : les sociétés prennent le secteur de l'édition (renvoie le nombre modifié) */
export async function alignCompaniesToEdition(edition: Sector): Promise<number> {
  const rows = await db.update(schema.companies).set({ sector: edition })
    .where(ne(schema.companies.sector, edition))
    .returning({ id: schema.companies.id });
  return rows.length;
}

/** Documents supplémentaires : jamais choisis automatiquement (voir buildExtraTemplates) */
export const EXTRA_NAMES = new Set(DEFAULT_LANGS.flatMap((l) => buildExtraTemplates(l).map((x) => x.name)));

/**
 * Un modèle fourni (neutre ou de secteur) est-il proposé à une société de ce secteur ?
 * Les techniciens voient les modèles neutres ; les autres secteurs voient les leurs,
 * plus les documents communs (ex. « Consignes de télésurveillance »).
 */
export function systemTemplateVisible(t: { sector: Sector | null; name: string }, sector: Sector): boolean {
  if (t.sector) return t.sector === sector;
  return sector === 'TECH' || EXTRA_NAMES.has(t.name);
}

/**
 * Choisit le modèle d'une nouvelle fiche, du plus spécifique au plus général :
 * modèle de la société → modèle du groupe → modèle du secteur → modèle neutre, dans la langue de la société.
 */
export async function pickTemplate(
  company: { id: string; groupId: string; locale: string; sector?: Sector | null },
  kind: InterventionKind,
  chosenId?: string | null,
) {
  // Document choisi pour cette intervention (ex. « Consignes de télésurveillance »), s'il est toujours utilisable
  if (chosenId) {
    const [chosen] = await db.select().from(schema.formTemplates).where(and(
      eq(schema.formTemplates.id, chosenId),
      eq(schema.formTemplates.active, true),
      or(eq(schema.formTemplates.companyId, company.id), and(eq(schema.formTemplates.groupId, company.groupId), isNull(schema.formTemplates.companyId)), isNull(schema.formTemplates.groupId)),
    ));
    if (chosen) return chosen;
  }
  const candidates = await db
    .select()
    .from(schema.formTemplates)
    .where(and(
      eq(schema.formTemplates.kind, kind),
      eq(schema.formTemplates.active, true),
      // Les documents à choisir (consignes, dossier technique…) ne sont jamais pris d'office
      eq(schema.formTemplates.autoPick, true),
      or(
        eq(schema.formTemplates.companyId, company.id),
        and(eq(schema.formTemplates.groupId, company.groupId), isNull(schema.formTemplates.companyId)),
        and(isNull(schema.formTemplates.groupId), isNull(schema.formTemplates.companyId)),
      ),
    ))
    .orderBy(desc(schema.formTemplates.version));

  const lang = langOf(company.locale);
  const sector = company.sector ?? 'TECH';
  const provided = (t: (typeof candidates)[number]) => !t.groupId && !EXTRA_NAMES.has(t.name);
  const ofSector = (t: (typeof candidates)[number]) => provided(t) && sector !== 'TECH' && t.sector === sector;
  const neutral = (t: (typeof candidates)[number]) => provided(t) && !t.sector;
  return (
    candidates.find((t) => t.companyId === company.id) ??
    candidates.find((t) => t.groupId === company.groupId && !t.companyId) ??
    candidates.find((t) => ofSector(t) && (t.schema.lang ?? 'fr') === lang) ??
    candidates.find(ofSector) ??
    candidates.find((t) => neutral(t) && (t.schema.lang ?? 'fr') === lang) ??
    candidates.find(neutral) ??
    null
  );
}
