/**
 * Lecture d'un tableau importé : CSV (Excel, EBP, Sage…) ou classeur Excel .xlsx, sans dépendance extérieure.
 * Le résultat est une liste de lignes de texte ; la première est celle des titres.
 */
import { inflateRawSync } from 'node:zlib';

/** Au-delà, le fichier est refusé (protection contre les archives piégées) */
const MAX_UNZIPPED_BYTES = 60 * 1024 * 1024;

export class TableError extends Error {}

export function readTable(buffer: Buffer): string[][] {
  const rows = isZip(buffer) ? readXlsx(buffer) : readCsv(decodeText(buffer));
  // Lignes entièrement vides retirées, cellules nettoyées
  return rows
    .map((r) => r.map((c) => c.replace(/ /g, ' ').trim()))
    .filter((r) => r.some((c) => c !== ''));
}

const isZip = (b: Buffer) => b.length > 4 && b.readUInt32LE(0) === 0x04034b50;

// ─── CSV ──────────────────────────────────────────────────────────────────

/** UTF-8 (avec ou sans BOM), sinon Windows-1252 : l'encodage des CSV enregistrés par Excel en France */
export function decodeText(buffer: Buffer): string {
  if (buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) return buffer.subarray(3).toString('utf8');
  if (buffer[0] === 0xff && buffer[1] === 0xfe) return new TextDecoder('utf-16le').decode(buffer.subarray(2));
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buffer);
  } catch {
    return new TextDecoder('windows-1252').decode(buffer);
  }
}

/** Séparateur le plus fréquent de la première ligne : point-virgule, virgule ou tabulation */
function guessDelimiter(text: string): string {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? '';
  const counts = [';', ',', '\t'].map((d) => ({ d, n: firstLine.split(d).length - 1 }));
  counts.sort((a, b) => b.n - a.n);
  return counts[0].n > 0 ? counts[0].d : ';';
}

/** CSV avec guillemets (« "Dupont; fils" »), guillemets doublés et retours à la ligne dans une cellule */
export function readCsv(text: string): string[][] {
  const d = guessDelimiter(text);
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"' && cell === '') quoted = true;
    else if (ch === d) {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else cell += ch;
  }
  if (cell !== '' || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

// ─── Excel .xlsx (archive zip de fichiers XML) ────────────────────────────

/** Fichiers de l'archive, décompressés à la demande */
export function unzip(buffer: Buffer): Map<string, () => Buffer> {
  // Fin du répertoire central : cherchée en partant de la fin (commentaire éventuel)
  let eocd = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 22 - 65535); i--) {
    if (buffer.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new TableError('Fichier Excel illisible');
  const count = buffer.readUInt16LE(eocd + 10);
  let p = buffer.readUInt32LE(eocd + 16);
  const files = new Map<string, () => Buffer>();
  let total = 0;
  for (let n = 0; n < count; n++) {
    if (buffer.readUInt32LE(p) !== 0x02014b50) throw new TableError('Fichier Excel illisible');
    const method = buffer.readUInt16LE(p + 10);
    const compressed = buffer.readUInt32LE(p + 20);
    const size = buffer.readUInt32LE(p + 24);
    const nameLen = buffer.readUInt16LE(p + 28);
    const extraLen = buffer.readUInt16LE(p + 30);
    const commentLen = buffer.readUInt16LE(p + 32);
    const local = buffer.readUInt32LE(p + 42);
    const name = buffer.subarray(p + 46, p + 46 + nameLen).toString('utf8');
    p += 46 + nameLen + extraLen + commentLen;
    total += size;
    if (total > MAX_UNZIPPED_BYTES) throw new TableError('Fichier Excel trop volumineux');
    files.set(name, () => {
      const start = local + 30 + buffer.readUInt16LE(local + 26) + buffer.readUInt16LE(local + 28);
      const data = buffer.subarray(start, start + compressed);
      if (method === 0) return data;
      if (method === 8) return inflateRawSync(data, { maxOutputLength: MAX_UNZIPPED_BYTES });
      throw new TableError('Fichier Excel illisible');
    });
  }
  return files;
}

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function xmlText(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e: string) => {
    if (e[0] === '#') return String.fromCodePoint(e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10));
    return ENTITIES[e] ?? m;
  });
}

/** Texte d'un élément pouvant contenir plusieurs morceaux mis en forme (<r><t>…</t></r>) */
const runsText = (xml: string) => [...xml.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map((m) => xmlText(m[1])).join('');

/** « AB12 » → 27 (colonnes numérotées à partir de 0) */
function columnIndex(ref: string): number {
  const letters = /^[A-Z]+/.exec(ref)?.[0] ?? 'A';
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

export function readXlsx(buffer: Buffer): string[][] {
  const files = unzip(buffer);
  const read = (name: string) => files.get(name)?.().toString('utf8');

  // Première feuille du classeur
  const workbook = read('xl/workbook.xml');
  const rels = read('xl/_rels/workbook.xml.rels');
  if (!workbook || !rels) throw new TableError('Fichier Excel illisible');
  const firstSheet = /<sheet\b[^>]*\br:id="([^"]+)"/.exec(workbook)?.[1];
  const rel = [...rels.matchAll(/<Relationship\b[^>]*>/g)].map((m) => m[0]).find((r) => r.includes(`Id="${firstSheet}"`));
  let target = rel ? /Target="([^"]+)"/.exec(rel)?.[1] : undefined;
  if (!target) throw new TableError('Fichier Excel illisible');
  target = target.startsWith('/') ? target.slice(1) : `xl/${target}`;
  const sheet = read(target);
  if (!sheet) throw new TableError('Fichier Excel illisible');

  const shared = [...(read('xl/sharedStrings.xml') ?? '').matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => runsText(m[1]));

  const rows: string[][] = [];
  for (const rowMatch of sheet.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)) {
    const row: string[] = [];
    for (const c of rowMatch[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const attrs = c[1];
      const inner = c[2] ?? '';
      const ref = /\br="([A-Z]+)\d*"/.exec(attrs)?.[1];
      const type = /\bt="(\w+)"/.exec(attrs)?.[1];
      const v = /<v>([\s\S]*?)<\/v>/.exec(inner)?.[1];
      let value = '';
      if (type === 's') value = shared[Number(v)] ?? '';
      else if (type === 'inlineStr') value = runsText(inner);
      else if (type === 'b') value = v === '1' ? 'oui' : 'non';
      else if (v !== undefined) value = xmlText(v);
      const col = ref ? columnIndex(ref) : row.length;
      while (row.length < col) row.push('');
      row[col] = value;
    }
    rows.push(row);
  }
  return rows;
}
