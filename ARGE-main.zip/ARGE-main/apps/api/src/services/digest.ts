/**
 * Récapitulatif quotidien des échéances, envoyé à partir de 7 h (heure de la société) :
 *  - la direction reçoit toute la société, chaque chef d'agence reçoit son agence ;
 *  - rien n'est envoyé s'il n'y a rien à signaler ;
 *  - un seul envoi par société et par jour, même si le serveur redémarre (table job_runs).
 */
import { and, eq, inArray, isNull } from 'drizzle-orm';
import { DUE_STATE_LABELS, VEHICLE_DEADLINE_LABELS } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { todayIn } from './contracts.js';
import { certificationsDue, vehiclesDue, type CertificationDue, type VehicleDue } from './deadlines.js';
import { sendMail } from './mail.js';

import { PRODUCT_NAME } from '../env.js';
const SEND_FROM_HOUR = 7;

function hourIn(timezone: string, now: Date) {
  return Number(new Intl.DateTimeFormat('en-GB', { timeZone: timezone, hour: '2-digit', hourCycle: 'h23' }).format(now));
}

const fmt = (iso: string) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`;

export function digestText(companyName: string, vehicles: VehicleDue[], certs: CertificationDue[]): string {
  const lines = [`Bonjour,`, ``, `Voici les échéances à traiter pour ${companyName} :`, ``];
  if (vehicles.length) {
    lines.push(`VÉHICULES (${vehicles.length})`);
    for (const x of vehicles) {
      const due = [x.dueDate ? `le ${fmt(x.dueDate)}` : null, x.dueMileage != null ? `à ${x.dueMileage.toLocaleString('fr-FR')} km` : null].filter(Boolean).join(' ou ');
      const rdv = x.appointmentOn ? ` – RDV le ${fmt(x.appointmentOn)}${x.appointmentWith ? ` (${x.appointmentWith})` : ''}` : ' – à programmer';
      lines.push(`- [${DUE_STATE_LABELS[x.state]}] ${x.plate} ${[x.make, x.model].filter(Boolean).join(' ')} : ${x.label || VEHICLE_DEADLINE_LABELS[x.kind]} ${due}${rdv}`);
    }
    lines.push('');
  }
  if (certs.length) {
    lines.push(`HABILITATIONS (${certs.length})`);
    for (const c of certs) {
      lines.push(`- [${c.state === 'OVERDUE' ? 'Expirée' : 'Expire bientôt'}] ${c.firstName} ${c.lastName} : ${c.typeName} – ${c.state === 'OVERDUE' ? 'expirée le' : 'expire le'} ${fmt(c.expiresOn)}`);
    }
    lines.push('');
  }
  lines.push(`Retrouvez le détail dans ${PRODUCT_NAME} : Parc véhicules → À programmer, et Habilitations.`);
  return lines.join('\n');
}

/** Envoie les récapitulatifs du jour qui ne sont pas encore partis ; renvoie le nombre d'e-mails envoyés */
export async function sendDailyDigests(now = new Date()): Promise<number> {
  const companies = await db.select().from(schema.companies).where(eq(schema.companies.active, true));
  let sent = 0;
  for (const company of companies) {
    if (hourIn(company.timezone, now) < SEND_FROM_HOUR) continue;
    const today = todayIn(company.timezone, now);
    // Réserve l'envoi du jour : un seul serveur, une seule fois
    const claimed = await db.insert(schema.jobRuns).values({ job: `digest:${company.id}`, runOn: today }).onConflictDoNothing().returning();
    if (!claimed.length) continue;
    const [vehicles, certs] = await Promise.all([vehiclesDue(company.id, today), certificationsDue(company.id, today)]);
    if (!vehicles.length && !certs.length) continue;

    const ra = schema.roleAssignments;
    const managers = await db.select({ email: schema.users.email, role: ra.role, agencyId: ra.agencyId })
      .from(ra).innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(eq(ra.companyId, company.id), inArray(ra.role, ['DIRECTOR', 'AGENCY_MANAGER']), eq(schema.users.active, true)));
    const directors = await db.select({ email: schema.users.email }).from(ra).innerJoin(schema.users, eq(schema.users.id, ra.userId))
      .where(and(eq(ra.companyId, company.id), eq(ra.role, 'DIRECTOR'), isNull(ra.agencyId), eq(schema.users.active, true)));

    const subject = `${company.name} – Échéances du ${fmt(today)}`;
    const all = [...new Set(directors.map((d) => d.email))];
    if (all.length) {
      await sendMail({ to: all, subject, text: digestText(company.name, vehicles, certs), brand: { name: company.name, logoPath: company.logoPath } });
      sent++;
    }
    const byAgency = new Map<string, string[]>();
    for (const m of managers.filter((x) => x.role === 'AGENCY_MANAGER' && x.agencyId && !all.includes(x.email))) {
      byAgency.set(m.agencyId!, [...(byAgency.get(m.agencyId!) ?? []), m.email]);
    }
    for (const [agencyId, emails] of byAgency) {
      const v = vehicles.filter((x) => x.agencyId === agencyId || x.agencyId === null);
      const c = certs.filter((x) => x.agencyId === agencyId);
      if (!v.length && !c.length) continue;
      await sendMail({ to: [...new Set(emails)], subject, text: digestText(company.name, v, c), brand: { name: company.name, logoPath: company.logoPath } });
      sent++;
    }
  }
  return sent;
}

/** Vérifie toutes les heures s'il faut envoyer le récapitulatif du jour */
export function scheduleDailyDigests(log: (msg: string) => void) {
  const run = () =>
    sendDailyDigests()
      .then((n) => n && log(`${n} récapitulatif(s) d'échéances envoyé(s)`))
      .catch((err) => log(`Récapitulatif des échéances impossible : ${(err as Error).message}`));
  void run();
  const timer = setInterval(run, 60 * 60 * 1000);
  timer.unref();
}
