/**
 * Mouvements de stock. Chaque mouvement met à jour les quantités des lieux concernés dans la même
 * transaction : le stock affiché est toujours la somme exacte des mouvements.
 */
import { and, eq, inArray, sql } from 'drizzle-orm';
import type { StockMovementKind } from '@itineo/shared';
import { db, schema, type Db } from '../db/client.js';
import { badRequest } from '../http.js';

type Tx = Parameters<Parameters<Db['transaction']>[0]>[0];

export interface Movement {
  groupId: string;
  companyId: string;
  articleId: string;
  kind: StockMovementKind;
  fromLocationId?: string | null;
  toLocationId?: string | null;
  quantity: number;
  slipId?: string | null;
  interventionId?: string | null;
  note?: string | null;
  userId?: string | null;
}

/** Ajoute (ou retire, si négatif) une quantité dans un lieu ; renvoie la nouvelle quantité */
async function addToLevel(tx: Tx, locationId: string, articleId: string, delta: number): Promise<number> {
  const res = await tx.execute<{ quantity: number }>(sql`
    INSERT INTO stock_levels (location_id, article_id, quantity) VALUES (${locationId}, ${articleId}, ${delta})
    ON CONFLICT (location_id, article_id) DO UPDATE SET quantity = stock_levels.quantity + EXCLUDED.quantity
    RETURNING quantity`);
  return Number(res.rows[0].quantity);
}

/** Petite tolérance pour les quantités décimales (0,1 + 0,2…) */
const EPS = 1e-9;

/**
 * Enregistre un mouvement. Sans `allowNegative`, refuse de sortir plus que ce qu'il y a dans le lieu de départ
 * (le dépôt ne peut pas donner ce qu'il n'a pas). Une pièce déjà posée, elle, est déduite même si le stock
 * du véhicule n'était pas à jour : le stock devient négatif et se voit à l'inventaire.
 */
export async function recordMovement(tx: Tx, m: Movement, opts: { allowNegative?: boolean; articleLabel?: string } = {}) {
  if (!(m.quantity > 0)) throw badRequest('La quantité doit être positive');
  if (m.fromLocationId) {
    const left = await addToLevel(tx, m.fromLocationId, m.articleId, -m.quantity);
    if (!opts.allowNegative && left < -EPS) {
      const available = left + m.quantity;
      throw badRequest(`Stock insuffisant pour ${opts.articleLabel ?? "l'article"} : ${round(available)} disponible(s), ${round(m.quantity)} demandé(s)`);
    }
  }
  if (m.toLocationId) await addToLevel(tx, m.toLocationId, m.articleId, m.quantity);
  await tx.insert(schema.stockMovements).values({
    groupId: m.groupId, companyId: m.companyId, articleId: m.articleId, kind: m.kind,
    fromLocationId: m.fromLocationId ?? null, toLocationId: m.toLocationId ?? null, quantity: m.quantity,
    slipId: m.slipId ?? null, interventionId: m.interventionId ?? null, note: m.note ?? null, createdById: m.userId ?? null,
  });
}

export const round = (n: number) => Math.round(n * 1000) / 1000;

/** Véhicule actif d'un technicien dans une société */
export async function vehicleOf(technicianId: string, companyId: string) {
  const [loc] = await db.select().from(schema.stockLocations).where(and(
    eq(schema.stockLocations.technicianId, technicianId),
    eq(schema.stockLocations.companyId, companyId),
    eq(schema.stockLocations.active, true),
  ));
  return loc ?? null;
}

/**
 * À la signature d'une fiche : les pièces choisies dans le catalogue sont déduites du véhicule
 * du technicien de l'intervention. Sans véhicule enregistré, rien n'est déduit (la fiche reste valable).
 */
export async function consumeReportParts(
  intervention: { id: string; groupId: string; companyId: string; technicianId: string | null },
  reportId: string,
  userId: string,
): Promise<number> {
  if (!intervention.technicianId) return 0;
  const vehicle = await vehicleOf(intervention.technicianId, intervention.companyId);
  if (!vehicle) return 0;
  const parts = (await db.select().from(schema.reportParts).where(eq(schema.reportParts.reportId, reportId)))
    .filter((p) => p.articleId && p.quantity > 0);
  if (!parts.length) return 0;
  // Seulement les articles de la même société
  const valid = new Set((await db.select({ id: schema.articles.id }).from(schema.articles).where(and(
    inArray(schema.articles.id, parts.map((p) => p.articleId!)),
    eq(schema.articles.companyId, intervention.companyId),
  ))).map((a) => a.id));
  let count = 0;
  await db.transaction(async (tx) => {
    for (const part of parts) {
      if (!valid.has(part.articleId!)) continue;
      await recordMovement(tx, {
        groupId: intervention.groupId, companyId: intervention.companyId, articleId: part.articleId!,
        kind: 'CONSUMPTION', fromLocationId: vehicle.id, quantity: part.quantity,
        interventionId: intervention.id, userId,
      }, { allowNegative: true });
      count++;
    }
  });
  return count;
}
