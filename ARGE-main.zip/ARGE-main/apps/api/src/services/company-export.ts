/**
 * Export complet des données d'une société (garantie de réversibilité) : une archive .zip lisible sans Itinéos.
 *
 *   donnees/*.csv   une table par fichier (séparateur point-virgule, UTF-8 : s'ouvre dans Excel)
 *   fiches/         fiches d'intervention signées (PDF) et signatures (PNG)
 *   photos/         photos des fiches, rangées par n° d'intervention
 *   devis/ factures/ habilitations/ notices/   documents
 *   LISEZ-MOI.txt   ce que contient chaque fichier
 *
 * Ne sont jamais exportés : mots de passe, jetons, clé de la plateforme de facturation,
 * chemins des fichiers sur le serveur (remplacés par le chemin dans l'archive).
 * La messagerie interne et le journal des actions ne sont pas inclus (conversations entre personnes).
 */
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { pool } from '../db/client.js';
import { ZipStream } from './zip.js';

/** Colonnes jamais exportées */
const SECRET = new Set(['password_hash', 'token_hash', 'app_code_hash', 'einvoice_api_token']);
/** Colonnes de chemins sur le serveur : remplacées par le chemin du fichier dans l'archive */
const SERVER_PATHS = new Set(['pdf_path', 'file_path', 'document_path', 'attachment_path', 'logo_path']);
/** Images en data URL : exportées comme fichiers à part */
const INLINE_IMAGES = new Set(['technician_signature', 'client_signature']);

interface Table {
  file: string;
  /** Description pour le LISEZ-MOI */
  about: string;
  /** Requête : $1 = société, $2 = groupe */
  sql: string;
}

const CLIENTS = 'SELECT id FROM clients WHERE company_id = $1';
const USERS = `SELECT DISTINCT u.id FROM users u JOIN role_assignments r ON r.user_id = u.id
  WHERE u.group_id = $2 AND (r.company_id = $1 OR r.company_id IS NULL)`;

export const EXPORT_TABLES: Table[] = [
  { file: 'societe', about: 'La société : coordonnées, mentions légales, réglages de facturation', sql: 'SELECT * FROM companies WHERE id = $1' },
  { file: 'agences', about: 'Agences', sql: 'SELECT * FROM agencies WHERE company_id = $1' },
  { file: 'equipes', about: 'Équipes des agences', sql: 'SELECT * FROM teams WHERE agency_id IN (SELECT id FROM agencies WHERE company_id = $1)' },
  { file: 'utilisateurs', about: 'Personnes ayant accès à la société (sans mot de passe)', sql: `SELECT * FROM users WHERE id IN (${USERS})` },
  { file: 'roles', about: 'Rôles des utilisateurs et leur périmètre (groupe, société, agence)', sql: 'SELECT * FROM role_assignments WHERE group_id = $2 AND (company_id = $1 OR company_id IS NULL)' },
  { file: 'clients', about: 'Clients (n° d’abonné, SIREN, référence dans un autre logiciel…)', sql: 'SELECT * FROM clients WHERE company_id = $1' },
  { file: 'contacts', about: 'Contacts des clients', sql: `SELECT * FROM contacts WHERE client_id IN (${CLIENTS})` },
  { file: 'sites', about: 'Sites des clients (adresse, accès et consignes)', sql: `SELECT * FROM sites WHERE client_id IN (${CLIENTS})` },
  { file: 'materiels', about: 'Matériels installés sur les sites (n° de série, date de pose, contrat)', sql: `SELECT * FROM equipments WHERE site_id IN (SELECT id FROM sites WHERE client_id IN (${CLIENTS}))` },
  { file: 'points_de_passage', about: 'Points de passage des sites (rondes)', sql: `SELECT * FROM checkpoints WHERE site_id IN (SELECT id FROM sites WHERE client_id IN (${CLIENTS}))` },
  { file: 'acces_espace_client', about: 'Accès des clients à leur espace en ligne (sans mot de passe)', sql: `SELECT * FROM portal_users WHERE client_id IN (${CLIENTS})` },
  { file: 'modeles_de_fiches', about: 'Modèles de fiches et de documents (structure en JSON)', sql: 'SELECT * FROM form_templates WHERE company_id = $1 OR (group_id = $2 AND company_id IS NULL)' },
  { file: 'interventions', about: 'Interventions (planning, statut, motif)', sql: 'SELECT * FROM interventions WHERE company_id = $1' },
  { file: 'fiches', about: 'Fiches d’intervention remplies (réponses en JSON, temps, signataire) ; colonne « fichier » = PDF', sql: 'SELECT * FROM reports WHERE intervention_id IN (SELECT id FROM interventions WHERE company_id = $1)' },
  { file: 'pieces_posees', about: 'Pièces posées notées sur les fiches', sql: 'SELECT * FROM report_parts WHERE report_id IN (SELECT r.id FROM reports r JOIN interventions i ON i.id = r.intervention_id WHERE i.company_id = $1)' },
  { file: 'photos', about: 'Photos des fiches (légende, heure, empreinte SHA-256) ; colonne « fichier » = photo', sql: 'SELECT * FROM report_photos WHERE report_id IN (SELECT r.id FROM reports r JOIN interventions i ON i.id = r.intervention_id WHERE i.company_id = $1)' },
  { file: 'devis', about: 'Devis (montants en centimes)', sql: 'SELECT * FROM quotes WHERE company_id = $1' },
  { file: 'lignes_de_devis', about: 'Lignes des devis (prix en centimes, TVA en centièmes de % : 2000 = 20 %)', sql: 'SELECT * FROM quote_lines WHERE quote_id IN (SELECT id FROM quotes WHERE company_id = $1)' },
  { file: 'contrats', about: 'Contrats d’entretien', sql: 'SELECT * FROM contracts WHERE company_id = $1' },
  { file: 'factures', about: 'Factures et avoirs (montants en centimes)', sql: 'SELECT * FROM invoices WHERE company_id = $1' },
  { file: 'lignes_de_factures', about: 'Lignes des factures (prix en centimes, TVA en centièmes de %)', sql: 'SELECT * FROM invoice_lines WHERE invoice_id IN (SELECT id FROM invoices WHERE company_id = $1)' },
  { file: 'paiements', about: 'Paiements reçus (montants en centimes)', sql: 'SELECT * FROM payments WHERE invoice_id IN (SELECT id FROM invoices WHERE company_id = $1)' },
  { file: 'relances', about: 'Relances envoyées pour les factures impayées (niveau 1 rappel, 2 relance, 3 mise en demeure)', sql: 'SELECT * FROM invoice_reminders WHERE invoice_id IN (SELECT id FROM invoices WHERE company_id = $1)' },
  { file: 'mandats_sepa', about: 'Mandats de prélèvement SEPA signés par les clients (référence, IBAN, date de signature)', sql: `SELECT * FROM sepa_mandates WHERE client_id IN (${CLIENTS})` },
  { file: 'lots_de_prelevement', about: 'Lots de prélèvement SEPA remis à la banque (colonne xml : le fichier lui-même)', sql: 'SELECT * FROM sepa_batches WHERE company_id = $1' },
  { file: 'articles', about: 'Catalogue des articles (prix en centimes)', sql: 'SELECT * FROM articles WHERE company_id = $1' },
  { file: 'lieux_de_stock', about: 'Dépôts et véhicules de stock', sql: 'SELECT * FROM stock_locations WHERE company_id = $1' },
  { file: 'niveaux_de_stock', about: 'Quantités en stock par lieu', sql: 'SELECT * FROM stock_levels WHERE location_id IN (SELECT id FROM stock_locations WHERE company_id = $1)' },
  { file: 'bons_de_sortie', about: 'Bons de sortie et de transfert de stock', sql: 'SELECT * FROM stock_slips WHERE company_id = $1' },
  { file: 'lignes_de_bons', about: 'Lignes des bons de stock', sql: 'SELECT * FROM stock_slip_lines WHERE slip_id IN (SELECT id FROM stock_slips WHERE company_id = $1)' },
  { file: 'mouvements_de_stock', about: 'Historique des mouvements de stock', sql: 'SELECT * FROM stock_movements WHERE company_id = $1' },
  { file: 'types_habilitations', about: 'Types d’habilitation', sql: 'SELECT * FROM certification_types WHERE group_id = $2' },
  { file: 'habilitations', about: 'Habilitations des personnes ; colonne « fichier » = justificatif', sql: `SELECT * FROM user_certifications WHERE user_id IN (${USERS})` },
  { file: 'vehicules', about: 'Parc de véhicules', sql: 'SELECT * FROM vehicles WHERE company_id = $1' },
  { file: 'echeances_vehicules', about: 'Échéances des véhicules (contrôle technique, entretien…)', sql: 'SELECT * FROM vehicle_deadlines WHERE vehicle_id IN (SELECT id FROM vehicles WHERE company_id = $1)' },
  { file: 'evenements_vehicules', about: 'Entretiens, réparations et frais des véhicules', sql: 'SELECT * FROM vehicle_events WHERE vehicle_id IN (SELECT id FROM vehicles WHERE company_id = $1)' },
  { file: 'positions_vehicules', about: 'Positions des véhicules (30 derniers jours seulement)', sql: 'SELECT * FROM vehicle_positions WHERE vehicle_id IN (SELECT id FROM vehicles WHERE company_id = $1)' },
  { file: 'cartes_sim', about: 'Cartes SIM', sql: 'SELECT * FROM sim_cards WHERE company_id = $1' },
  { file: 'annuaire', about: 'Annuaire (fournisseurs, sous-traitants, numéros utiles)', sql: 'SELECT * FROM directory_contacts WHERE company_id = $1 OR (group_id = $2 AND company_id IS NULL)' },
  { file: 'notices', about: 'Notices et procédures ; colonne « fichier » = document', sql: 'SELECT * FROM procedures WHERE company_id = $1 OR (group_id = $2 AND company_id IS NULL)' },
];

/** Une cellule CSV : entre guillemets si besoin, sans formule exécutable dans Excel */
function cell(v: unknown): string {
  if (v === null || v === undefined) return '';
  let s = typeof v === 'object' ? JSON.stringify(v) : String(v);
  if (/^[=+\-@]/.test(s) && !/^-?\d/.test(s)) s = `'${s}`;
  return /[;"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const csv = (header: string[], rows: unknown[][]) =>
  Buffer.from('﻿' + [header, ...rows].map((r) => r.map(cell).join(';')).join('\r\n') + '\r\n', 'utf8');

/** Nom de fichier sûr dans l'archive */
const safe = (s: string) => s.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim().slice(0, 100) || 'sans-nom';

/** « data:image/png;base64,… » → image */
function dataUrlImage(s: unknown): { data: Buffer; ext: string } | null {
  const m = typeof s === 'string' ? /^data:image\/(png|jpeg);base64,([A-Za-z0-9+/=]+)$/.exec(s) : null;
  return m ? { data: Buffer.from(m[2], 'base64'), ext: m[1] === 'jpeg' ? 'jpg' : 'png' } : null;
}

export interface ExportSummary { tables: Record<string, number>; files: number; missingFiles: number }

/**
 * Écrit l'archive de la société dans `write` (le flux de la réponse HTTP).
 * Les lignes sont lues en JSON par PostgreSQL : dates et nombres gardent leur forme exacte.
 */
export async function writeCompanyExport(companyId: string, groupId: string, write: (chunk: Buffer) => Promise<void>, now = new Date()): Promise<ExportSummary> {
  const zip = new ZipStream(write, now);
  const summary: ExportSummary = { tables: {}, files: 0, missingFiles: 0 };
  const params = [companyId, groupId];
  const used = new Set<string>();
  /** Chemin unique dans l'archive */
  const unique = (p: string) => {
    let name = p;
    const dot = p.lastIndexOf('.');
    for (let n = 2; used.has(name); n++) name = dot > 0 ? `${p.slice(0, dot)}-${n}${p.slice(dot)}` : `${p}-${n}`;
    used.add(name);
    return name;
  };
  /** Copie un fichier du serveur dans l'archive ; renvoie son chemin dans l'archive ('' s'il est introuvable) */
  const addFile = async (serverPath: unknown, archivePath: string): Promise<string> => {
    if (typeof serverPath !== 'string' || !serverPath) return '';
    const data = await readFile(serverPath).catch(() => null);
    if (!data) {
      summary.missingFiles++;
      return '';
    }
    const name = unique(archivePath);
    await zip.add(name, data);
    summary.files++;
    return name;
  };

  // Numéros lisibles pour nommer les fichiers (fiche → n° d'intervention, photo → fiche)
  const interventionNumber = new Map<string, string>(
    (await pool.query<{ id: string; number: string }>('SELECT id, number FROM interventions WHERE company_id = $1', [companyId])).rows.map((r) => [r.id, r.number]),
  );
  const reportNumber = new Map<string, string>();
  const userName = new Map<string, string>(
    (await pool.query<{ id: string; name: string }>("SELECT id, first_name || ' ' || last_name AS name FROM users WHERE group_id = $1", [groupId])).rows.map((r) => [r.id, r.name]),
  );
  const certTypeName = new Map<string, string>(
    (await pool.query<{ id: string; name: string }>('SELECT id, name FROM certification_types WHERE group_id = $1', [groupId])).rows.map((r) => [r.id, r.name]),
  );

  for (const table of EXPORT_TABLES) {
    // Le WITH donne un type aux deux paramètres, même quand la requête n'en utilise qu'un
    const typed = `WITH _p AS (SELECT $1::uuid, $2::uuid)`;
    const columns = (await pool.query(`${typed} SELECT * FROM (${table.sql}) t LIMIT 0`, params)).fields.map((f) => f.name);
    const rows = (await pool.query<{ r: Record<string, unknown> }>(`${typed} SELECT row_to_json(t) AS r FROM (${table.sql}) t`, params)).rows.map((x) => x.r);
    const keep = columns.filter((c) => !SECRET.has(c) && !SERVER_PATHS.has(c) && !INLINE_IMAGES.has(c));
    const hasFile = columns.some((c) => SERVER_PATHS.has(c));
    const header = hasFile ? [...keep, 'fichier'] : keep;
    const out: unknown[][] = [];

    for (const row of rows) {
      let file = '';
      switch (table.file) {
        case 'societe':
          file = await addFile(row.logo_path, `logo${path.extname(String(row.logo_path ?? '')) || '.png'}`);
          break;
        case 'fiches': {
          const number = interventionNumber.get(String(row.intervention_id)) ?? String(row.id);
          reportNumber.set(String(row.id), number);
          file = await addFile(row.pdf_path, `fiches/${safe(number)}.pdf`);
          for (const [col, who] of [['client_signature', 'client'], ['technician_signature', 'technicien']] as const) {
            const img = dataUrlImage(row[col]);
            if (img) {
              await zip.add(unique(`fiches/${safe(number)}-signature-${who}.${img.ext}`), img.data);
              summary.files++;
            }
          }
          break;
        }
        case 'photos': {
          const number = reportNumber.get(String(row.report_id)) ?? 'sans-fiche';
          const ext = path.extname(String(row.file_path ?? '')) || '.jpg';
          file = await addFile(row.file_path, `photos/${safe(number)}/${safe(String(row.kind ?? 'photo')).toLowerCase()}${ext}`);
          break;
        }
        case 'devis':
          file = await addFile(row.pdf_path, `devis/${safe(String(row.number ?? row.id))}.pdf`);
          break;
        case 'factures':
          file = await addFile(row.pdf_path, `factures/${safe(String(row.number ?? row.id))}.pdf`);
          break;
        case 'habilitations': {
          const ext = path.extname(String(row.document_path ?? '')) || '.pdf';
          file = await addFile(row.document_path, `habilitations/${safe(`${userName.get(String(row.user_id)) ?? ''} - ${certTypeName.get(String(row.type_id)) ?? ''}`)}${ext}`);
          break;
        }
        case 'notices':
          file = await addFile(row.file_path, `notices/${safe(String(row.file_name ?? row.title ?? row.id))}`);
          break;
      }
      const values = keep.map((c) => row[c]);
      out.push(hasFile ? [...values, file] : values);
    }
    await zip.add(`donnees/${table.file}.csv`, csv(header, out), true);
    summary.tables[table.file] = rows.length;
  }

  await zip.add('LISEZ-MOI.txt', Buffer.from(readme(summary, now), 'utf8'), true);
  await zip.finish();
  return summary;
}

function readme(summary: ExportSummary, now: Date): string {
  const lines = [
    'Export complet Itinéos',
    `Réalisé le ${now.toISOString().slice(0, 16).replace('T', ' à ')} (heure UTC)`,
    '',
    'Ce dossier contient toutes les données de la société, lisibles sans Itinéos.',
    '',
    'donnees/      Un tableau par fichier CSV (séparateur point-virgule, accents en UTF-8) : s’ouvre dans Excel ou LibreOffice.',
    '              La première ligne donne le nom de chaque colonne. Les identifiants (colonnes « id » et « …_id »)',
    '              relient les tableaux entre eux : par exemple sites.client_id = clients.id.',
    '              Montants en centimes (colonnes « …_cents ») ; taux de TVA en centièmes de % (2000 = 20 %).',
    '              Dates au format AAAA-MM-JJ, heures en UTC.',
    '              La colonne « fichier » donne le chemin du document correspondant dans ce dossier.',
    'fiches/       Fiches d’intervention signées (PDF) et signatures (PNG), nommées par n° d’intervention.',
    'photos/       Photos des fiches, rangées par n° d’intervention.',
    'devis/        Devis en PDF.',
    'factures/     Factures et avoirs en PDF (Factur-X quand ils ont été émis comme tels).',
    'habilitations/, notices/   Justificatifs et documents déposés.',
    '',
    'Contenu :',
    ...Object.entries(summary.tables).map(([file, n]) => {
      const t = EXPORT_TABLES.find((x) => x.file === file)!;
      return `  donnees/${file}.csv : ${n} ligne(s). ${t.about}`;
    }),
    `  Documents, photos et signatures : ${summary.files} fichier(s).`,
    ...(summary.missingFiles ? [`  ${summary.missingFiles} document(s) référencé(s) introuvable(s) sur le serveur : leur colonne « fichier » est vide.`] : []),
    '',
    'Ne sont pas inclus : les mots de passe et jetons de connexion (jamais exportés), la messagerie interne',
    '(conversations entre personnes) et le journal technique des actions. Ils peuvent être fournis sur demande écrite.',
  ];
  return lines.join('\r\n') + '\r\n';
}
