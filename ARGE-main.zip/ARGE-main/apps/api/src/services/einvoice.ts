/**
 * Envoi des factures électroniques à la plateforme agréée choisie par la société.
 *
 * Itinéos n'est pas une plateforme : il dépose la facture (PDF Factur-X) sur celle du client par son API,
 * puis suit son cycle de vie (déposée, reçue, mise à disposition, approuvée, refusée, encaissée…).
 * Le dialogue suit l'API de dépôt de flux normalisée (AFNOR XP Z12-013) : POST /v1/flows pour déposer,
 * GET /v1/flows/{id} pour suivre. Chaque plateforme publie l'adresse de son API et délivre un jeton d'accès ;
 * à vérifier sur son environnement de test avant la mise en service.
 */
import { createHash } from 'node:crypto';

export interface PlatformConfig { url: string; token: string }

/** Cycle de vie d'une facture électronique (codes de statut de la réforme) */
export const LIFECYCLE: Record<string, string> = {
  '200': 'Déposée',
  '201': 'Émise par la plateforme',
  '202': 'Reçue par la plateforme du client',
  '203': 'Mise à disposition du client',
  '204': 'Prise en charge',
  '205': 'Approuvée',
  '206': 'Approuvée partiellement',
  '207': 'En litige',
  '208': 'Suspendue',
  '209': 'Complétée',
  '210': 'Refusée',
  '211': 'Paiement transmis',
  '212': 'Encaissée',
  '213': 'Rejetée',
};

/** Statuts après lesquels la facture n'évolue plus (on arrête de demander) */
export const FINAL_STATUSES = new Set(['210', '212', '213']);

const base = (url: string) => url.replace(/\/+$/, '');

async function call(cfg: PlatformConfig, path: string, init: RequestInit = {}): Promise<{ status: number; body: unknown }> {
  let res: Response;
  try {
    res = await fetch(`${base(cfg.url)}${path}`, {
      ...init,
      headers: { Authorization: `Bearer ${cfg.token}`, Accept: 'application/json', ...(init.headers ?? {}) },
      signal: AbortSignal.timeout(20_000),
    });
  } catch (e) {
    throw new Error(`Plateforme injoignable : ${(e as Error).message}`);
  }
  const text = await res.text();
  let body: unknown = text;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    /* réponse non JSON : gardée telle quelle */
  }
  return { status: res.status, body };
}

function errorText(status: number, body: unknown): string {
  if (status === 401 || status === 403) return 'La plateforme refuse le jeton d’accès : vérifiez-le dans Organisation.';
  const detail = body && typeof body === 'object'
    ? String((body as Record<string, unknown>).message ?? (body as Record<string, unknown>).error ?? (body as Record<string, unknown>).detail ?? '')
    : String(body ?? '');
  return `La plateforme a répondu ${status}${detail ? ` : ${detail.slice(0, 300)}` : ''}`;
}

/** Statut d'un dépôt, quelle que soit la façon dont la plateforme le nomme */
export function readStatus(body: unknown): string | null {
  if (!body || typeof body !== 'object') return null;
  const b = body as Record<string, unknown>;
  const raw = b.lifecycleStatus ?? b.statusCode ?? b.status ?? b.code ?? b.acknowledgementStatus ?? (b.acknowledgement as Record<string, unknown> | undefined)?.status;
  if (raw && typeof raw === 'object') return readStatus(raw);
  return raw == null ? null : String(raw);
}

export const statusLabel = (code: string | null) => (code ? LIFECYCLE[code] ?? code : null);

/** Dépose une facture Factur-X ; renvoie l'identifiant du dépôt sur la plateforme */
export async function depositInvoice(cfg: PlatformConfig, pdf: Buffer, info: { invoiceId: string; number: string }): Promise<{ flowId: string; status: string | null }> {
  const form = new FormData();
  form.append('flowInfo', new Blob([JSON.stringify({
    trackingId: info.invoiceId,
    name: `${info.number}.pdf`,
    flowSyntax: 'Factur-X',
    flowProfile: 'EN16931',
    sha256: createHash('sha256').update(pdf).digest('hex'),
  })], { type: 'application/json' }));
  form.append('file', new Blob([new Uint8Array(pdf)], { type: 'application/pdf' }), `${info.number}.pdf`);
  const { status, body } = await call(cfg, '/v1/flows', { method: 'POST', body: form });
  if (status < 200 || status >= 300) throw new Error(errorText(status, body));
  const b = (body ?? {}) as Record<string, unknown>;
  const flowId = String(b.flowId ?? b.id ?? '');
  if (!flowId) throw new Error('La plateforme n’a pas renvoyé d’identifiant de dépôt');
  return { flowId, status: readStatus(body) ?? '200' };
}

/** Où en est la facture déposée */
export async function flowStatus(cfg: PlatformConfig, flowId: string): Promise<string | null> {
  const { status, body } = await call(cfg, `/v1/flows/${encodeURIComponent(flowId)}`);
  if (status < 200 || status >= 300) throw new Error(errorText(status, body));
  return readStatus(body);
}

/** Vérifie l'adresse et le jeton (Organisation → « Tester la connexion ») */
export async function testPlatform(cfg: PlatformConfig): Promise<void> {
  const { status, body } = await call(cfg, '/v1/flows?limit=1');
  if (status < 200 || status >= 300) throw new Error(errorText(status, body));
}
