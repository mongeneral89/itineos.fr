/**
 * Statistiques à la carte : des indicateurs (mesures) regroupés selon un ou deux critères
 * (technicien, agence, client, mois…), sur une période et avec des filtres.
 *
 * Trois sources : les interventions (avec leur fiche), les factures émises et les devis. Chaque source a ses
 * propres droits de lecture : un planificateur voit les indicateurs d'interventions mais pas le chiffre
 * d'affaires s'il n'a pas accès aux factures.
 */
import { sql, type SQL } from 'drizzle-orm';
import type { Permission } from '@itineo/shared';
import { db } from '../db/client.js';
import { scopeFor, type Principal, type ScopeFilter } from '../auth/access.js';

export type Source = 'interventions' | 'invoices' | 'quotes';

export const STAT_MEASURES = [
  // Interventions
  'count', 'done', 'toResume', 'cancelled', 'unassigned', 'urgent', 'firstTimeFix', 'clients',
  'laborHours', 'travelHours', 'avgOnSiteMin', 'onTimeRate', 'avgDelayMin', 'responseHours', 'clientSignedRate', 'partsQty',
  // Factures
  'revenue', 'invoiceCount', 'avgInvoice',
  // Devis
  'quoteCount', 'quoteAccepted', 'quoteRate', 'quoteAcceptedAmount',
] as const;
export type StatMeasure = (typeof STAT_MEASURES)[number];

export const STAT_DIMENSIONS = [
  'all', 'technician', 'agency', 'company', 'client', 'city', 'kind', 'priority', 'status', 'origin', 'author',
  'month', 'week', 'day', 'weekday', 'hour', 'year',
] as const;
export type StatDimension = (typeof STAT_DIMENSIONS)[number];

const SOURCE_OF: Record<StatMeasure, Source> = {
  count: 'interventions', done: 'interventions', toResume: 'interventions', cancelled: 'interventions', unassigned: 'interventions',
  urgent: 'interventions', firstTimeFix: 'interventions', clients: 'interventions', laborHours: 'interventions',
  travelHours: 'interventions', avgOnSiteMin: 'interventions', onTimeRate: 'interventions', avgDelayMin: 'interventions',
  responseHours: 'interventions', clientSignedRate: 'interventions', partsQty: 'interventions',
  revenue: 'invoices', invoiceCount: 'invoices', avgInvoice: 'invoices',
  quoteCount: 'quotes', quoteAccepted: 'quotes', quoteRate: 'quotes', quoteAcceptedAmount: 'quotes',
};

/** Droit de lecture nécessaire pour chaque source */
const READ: Record<Source, Permission> = { interventions: 'intervention.read', invoices: 'invoice.read', quotes: 'quote.read' };

/** Critères possibles pour chaque source */
const DIMS: Record<Source, readonly StatDimension[]> = {
  interventions: ['all', 'technician', 'agency', 'company', 'client', 'city', 'kind', 'priority', 'status', 'origin', 'month', 'week', 'day', 'weekday', 'hour', 'year'],
  invoices: ['all', 'technician', 'agency', 'company', 'client', 'city', 'kind', 'month', 'week', 'day', 'weekday', 'year'],
  quotes: ['all', 'technician', 'agency', 'company', 'client', 'city', 'kind', 'status', 'author', 'month', 'week', 'day', 'weekday', 'year'],
};

export const sourceOf = (m: StatMeasure) => SOURCE_OF[m];
export const dimensionsFor = (s: Source) => DIMS[s];

export interface StatFilters {
  from: string; // AAAA-MM-JJ, inclus
  to: string; // AAAA-MM-JJ, inclus
  tz: string;
  companyId?: string;
  agencyId?: string;
  technicianId?: string;
  clientId?: string;
  kind?: string;
  priority?: string;
}

/** Colonnes de chaque source, sous les mêmes noms, pour écrire les critères une seule fois */
interface Cols {
  table: SQL; // FROM … JOIN …
  when: (tz: string) => SQL; // date de référence (instant)
  companyId: SQL; agencyId: SQL; clientId: SQL; technicianId: SQL; siteId: SQL;
  kind: SQL; status: SQL; author: SQL;
  base: SQL; // conditions propres à la source
}

const COLS: Record<Source, Cols> = {
  interventions: {
    table: sql`interventions i
      LEFT JOIN reports r ON r.intervention_id = i.id
      LEFT JOIN (SELECT report_id, sum(quantity) AS qty FROM report_parts GROUP BY report_id) rp ON rp.report_id = r.id`,
    when: () => sql`coalesce(i.scheduled_start, i.created_at)`,
    companyId: sql`i.company_id`, agencyId: sql`i.agency_id`, clientId: sql`i.client_id`, technicianId: sql`i.technician_id`,
    siteId: sql`i.site_id`, kind: sql`i.kind::text`, status: sql`i.status::text`, author: sql`i.created_by_id`,
    base: sql`true`,
  },
  invoices: {
    table: sql`invoices v LEFT JOIN interventions i ON i.id = v.source_intervention_id`,
    // Date sans heure : minuit dans le fuseau de la société
    when: (tz) => sql`(v.issue_date::timestamp AT TIME ZONE ${tz})`,
    companyId: sql`v.company_id`, agencyId: sql`coalesce(v.agency_id, i.agency_id)`, clientId: sql`v.client_id`,
    technicianId: sql`i.technician_id`, siteId: sql`coalesce(v.site_id, i.site_id)`, kind: sql`v.kind`, status: sql`v.status`,
    author: sql`v.issued_by_id`,
    base: sql`v.status = 'ISSUED' AND v.issue_date IS NOT NULL`,
  },
  quotes: {
    table: sql`quotes q LEFT JOIN interventions i ON i.id = q.source_intervention_id`,
    when: () => sql`q.created_at`,
    companyId: sql`q.company_id`, agencyId: sql`coalesce(q.agency_id, i.agency_id)`, clientId: sql`q.client_id`,
    technicianId: sql`i.technician_id`, siteId: sql`coalesce(q.site_id, i.site_id)`, kind: sql`q.kind`, status: sql`q.status`,
    author: sql`q.created_by_id`,
    base: sql`q.status <> 'DRAFT'`,
  },
};

const MEASURE_SQL: Record<StatMeasure, SQL> = {
  count: sql`count(*)`,
  done: sql`count(*) FILTER (WHERE i.status = 'DONE')`,
  toResume: sql`count(*) FILTER (WHERE i.status = 'TO_RESUME')`,
  cancelled: sql`count(*) FILTER (WHERE i.status = 'CANCELLED')`,
  unassigned: sql`count(*) FILTER (WHERE i.technician_id IS NULL AND i.status <> 'CANCELLED')`,
  urgent: sql`count(*) FILTER (WHERE i.priority IN ('HIGH', 'URGENT'))`,
  // Réglé au premier passage : terminée, et non « à reprendre »
  firstTimeFix: sql`100.0 * count(*) FILTER (WHERE i.status = 'DONE') / nullif(count(*) FILTER (WHERE i.status IN ('DONE', 'TO_RESUME')), 0)`,
  clients: sql`count(DISTINCT i.client_id)`,
  laborHours: sql`sum(r.labor_minutes) / 60.0`,
  travelHours: sql`sum(r.travel_minutes) / 60.0`,
  avgOnSiteMin: sql`avg(extract(epoch FROM r.left_at - r.arrived_at) / 60) FILTER (WHERE r.left_at > r.arrived_at)`,
  // À l'heure : arrivé au plus tard 15 minutes après l'heure prévue
  onTimeRate: sql`100.0 * count(*) FILTER (WHERE r.arrived_at <= i.scheduled_start + interval '15 minutes')
    / nullif(count(*) FILTER (WHERE r.arrived_at IS NOT NULL AND i.scheduled_start IS NOT NULL), 0)`,
  avgDelayMin: sql`avg(greatest(0, extract(epoch FROM r.arrived_at - i.scheduled_start) / 60)) FILTER (WHERE r.arrived_at IS NOT NULL AND i.scheduled_start IS NOT NULL)`,
  // De la demande à l'arrivée sur place
  responseHours: sql`avg(extract(epoch FROM r.arrived_at - i.created_at) / 3600) FILTER (WHERE r.arrived_at > i.created_at)`,
  clientSignedRate: sql`100.0 * count(*) FILTER (WHERE r.signed_at IS NOT NULL AND r.client_signature IS NOT NULL)
    / nullif(count(*) FILTER (WHERE r.signed_at IS NOT NULL), 0)`,
  partsQty: sql`coalesce(sum(rp.qty), 0)`,
  revenue: sql`sum(CASE WHEN v.kind = 'CREDIT_NOTE' THEN -v.net_cents ELSE v.net_cents END) / 100.0`,
  invoiceCount: sql`count(*) FILTER (WHERE v.kind = 'INVOICE')`,
  avgInvoice: sql`avg(v.net_cents) FILTER (WHERE v.kind = 'INVOICE') / 100.0`,
  quoteCount: sql`count(*)`,
  quoteAccepted: sql`count(*) FILTER (WHERE q.status = 'ACCEPTED')`,
  quoteRate: sql`100.0 * count(*) FILTER (WHERE q.status = 'ACCEPTED') / nullif(count(*) FILTER (WHERE q.status IN ('ACCEPTED', 'REFUSED')), 0)`,
  quoteAcceptedAmount: sql`coalesce(sum(q.net_cents) FILTER (WHERE q.status = 'ACCEPTED'), 0) / 100.0`,
};

/** Clé et libellé d'un critère pour une source (le libellé des codes est traduit par l'appli) */
function dimension(d: StatDimension, c: Cols, tz: string): { key: SQL; label: SQL } {
  const local = sql`(${c.when(tz)} AT TIME ZONE ${tz})`;
  switch (d) {
    case 'all': return { key: sql`'all'`, label: sql`''` };
    case 'technician': return {
      key: sql`coalesce(${c.technicianId}::text, '')`,
      label: sql`coalesce((SELECT u.first_name || ' ' || u.last_name FROM users u WHERE u.id = ${c.technicianId}), '')`,
    };
    case 'author': return {
      key: sql`coalesce(${c.author}::text, '')`,
      label: sql`coalesce((SELECT u.first_name || ' ' || u.last_name FROM users u WHERE u.id = ${c.author}), '')`,
    };
    case 'agency': return {
      key: sql`coalesce(${c.agencyId}::text, '')`,
      label: sql`coalesce((SELECT a.name FROM agencies a WHERE a.id = ${c.agencyId}), '')`,
    };
    case 'company': return { key: sql`${c.companyId}::text`, label: sql`(SELECT co.name FROM companies co WHERE co.id = ${c.companyId})` };
    case 'client': return { key: sql`${c.clientId}::text`, label: sql`(SELECT cl.name FROM clients cl WHERE cl.id = ${c.clientId})` };
    case 'city': {
      const city = sql`coalesce((SELECT s.city FROM sites s WHERE s.id = ${c.siteId}), '')`;
      return { key: city, label: city };
    }
    case 'kind': return { key: c.kind, label: c.kind };
    case 'status': return { key: c.status, label: c.status };
    case 'priority': return { key: sql`i.priority::text`, label: sql`i.priority::text` };
    case 'origin': return { key: sql`coalesce(i.source, '')`, label: sql`coalesce(i.source, '')` };
    case 'year': return { key: sql`to_char(${local}, 'YYYY')`, label: sql`to_char(${local}, 'YYYY')` };
    case 'month': return { key: sql`to_char(${local}, 'YYYY-MM')`, label: sql`to_char(${local}, 'YYYY-MM')` };
    case 'week': return { key: sql`to_char(${local}, 'IYYY-"W"IW')`, label: sql`to_char(date_trunc('week', ${local}), 'YYYY-MM-DD')` };
    case 'day': return { key: sql`to_char(${local}, 'YYYY-MM-DD')`, label: sql`to_char(${local}, 'YYYY-MM-DD')` };
    case 'weekday': return { key: sql`extract(isodow FROM ${local})::text`, label: sql`extract(isodow FROM ${local})::text` };
    case 'hour': return { key: sql`lpad(extract(hour FROM ${local})::text, 2, '0')`, label: sql`lpad(extract(hour FROM ${local})::text, 2, '0')` };
  }
}

/** Périmètre de lecture traduit en condition SQL sur les colonnes de la source */
function scopeSql(f: ScopeFilter, c: Cols): SQL {
  if (f.all) return sql`true`;
  const parts: SQL[] = [];
  const list = (ids: string[]) => sql.join(ids.map((x) => sql`${x}::uuid`), sql`, `);
  if (f.companyIds.length) parts.push(sql`${c.companyId} IN (${list(f.companyIds)})`);
  if (f.agencyIds.length) parts.push(sql`${c.agencyId} IN (${list(f.agencyIds)})`);
  if (!parts.length) return sql`false`;
  return sql`(${sql.join(parts, sql` OR `)})`;
}

export interface StatRow { key: string; label: string; key2?: string; label2?: string; values: Partial<Record<StatMeasure, number | null>> }

async function runSource(p: Principal, source: Source, measures: StatMeasure[], by: StatDimension, by2: StatDimension | null, f: StatFilters) {
  const c = COLS[source];
  const d1 = dimension(by, c, f.tz);
  const d2 = by2 ? dimension(by2, c, f.tz) : null;
  const conds: SQL[] = [
    sql`${c.companyId} IN (SELECT id FROM companies WHERE group_id = ${p.groupId})`,
    c.base,
    scopeSql(scopeFor(p, READ[source]), c),
    sql`(${c.when(f.tz)} AT TIME ZONE ${f.tz}) >= ${f.from}::date`,
    sql`(${c.when(f.tz)} AT TIME ZONE ${f.tz}) < (${f.to}::date + 1)`,
  ];
  if (f.companyId) conds.push(sql`${c.companyId} = ${f.companyId}::uuid`);
  if (f.agencyId) conds.push(sql`${c.agencyId} = ${f.agencyId}::uuid`);
  if (f.clientId) conds.push(sql`${c.clientId} = ${f.clientId}::uuid`);
  if (f.technicianId) conds.push(sql`${c.technicianId} = ${f.technicianId}::uuid`);
  // Type et priorité : ceux de l'intervention (pour les factures et devis, celle d'où ils viennent)
  if (f.kind) conds.push(sql`i.kind::text = ${f.kind}`);
  if (f.priority) conds.push(sql`i.priority::text = ${f.priority}`);

  const select = [
    sql`${d1.key} AS k1`, sql`min(${d1.label}) AS l1`,
    ...(d2 ? [sql`${d2.key} AS k2`, sql`min(${d2.label}) AS l2`] : []),
    ...measures.map((m) => sql`(${MEASURE_SQL[m]})::float8 AS ${sql.identifier(m)}`),
  ];
  const groupBy = d2 ? sql`GROUP BY 1, 3` : sql`GROUP BY 1`;
  const res = await db.execute<Record<string, string | number | null>>(sql`
    SELECT ${sql.join(select, sql`, `)}
    FROM ${c.table}
    WHERE ${sql.join(conds, sql` AND `)}
    ${groupBy}
    LIMIT 5000`);
  return res.rows;
}

/**
 * Calcule les indicateurs demandés. Les mesures de sources différentes sont calculées séparément puis réunies
 * par critère ; les totaux sont calculés à part (une moyenne ou un taux ne s'additionne pas).
 */
export async function computeStats(p: Principal, measures: StatMeasure[], by: StatDimension, by2: StatDimension | null, f: StatFilters) {
  const sources = [...new Set(measures.map(sourceOf))];
  const rows = new Map<string, StatRow>();
  const totals: Partial<Record<StatMeasure, number | null>> = {};
  for (const s of sources) {
    const ms = measures.filter((m) => sourceOf(m) === s);
    for (const r of await runSource(p, s, ms, by, by2, f)) {
      const id = `${r.k1}\u0000${r.k2 ?? ''}`;
      const row = rows.get(id) ?? { key: String(r.k1 ?? ''), label: String(r.l1 ?? ''), ...(by2 ? { key2: String(r.k2 ?? ''), label2: String(r.l2 ?? '') } : {}), values: {} };
      for (const m of ms) row.values[m] = r[m] == null ? null : Number(r[m]);
      rows.set(id, row);
    }
    const [t] = await runSource(p, s, ms, 'all', null, f);
    for (const m of ms) totals[m] = t?.[m] == null ? null : Number(t[m]);
  }
  return { rows: [...rows.values()], totals };
}

/** Les sources que la personne peut lire (pour proposer seulement les indicateurs utiles) */
export function readableSources(p: Principal): Source[] {
  return (Object.keys(READ) as Source[]).filter((s) => {
    const f = scopeFor(p, READ[s]);
    return f.all || f.companyIds.length > 0 || f.agencyIds.length > 0;
  });
}
