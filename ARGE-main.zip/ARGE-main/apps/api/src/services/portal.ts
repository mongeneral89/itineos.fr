/**
 * Portail client : liens envoyés par e-mail et textes des e-mails.
 * Les e-mails destinés au client sont dans sa langue : celle de la personne (choisie dans son espace),
 * à l'invitation celle du client, sinon celle de la société.
 */
import { env, PRODUCT_NAME } from '../env.js';
import { langOf } from './prefill.js';
import { docTexts } from './doc-i18n.js';

/** Validité d'une invitation : le temps pour le client de la voir passer */
export const INVITE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
/** Validité d'un lien « mot de passe oublié » */
export const PORTAL_RESET_TTL_MS = 60 * 60 * 1000;

export function portalLink(path: string): string {
  const origin = env.WEB_ORIGIN.split(',')[0].trim().replace(/\/$/, '');
  return `${origin}/portail${path}`;
}

export function inviteMail(locale: string, o: { name: string; clientName: string; companyName: string; link: string }) {
  return docTexts(locale).inviteMail({ name: o.name, client: o.clientName, company: o.companyName, link: o.link });
}

export function portalResetMail(locale: string, o: { name: string; companyName: string; link: string }) {
  return docTexts(locale).resetMail({ name: o.name, company: o.companyName, link: o.link });
}

/** Accusé de réception envoyé au client après une demande d'intervention */
export function requestReceivedMail(locale: string, o: { name: string; companyName: string; number: string; reason: string }) {
  return docTexts(locale).requestMail({ name: o.name, company: o.companyName, number: o.number, reason: o.reason });
}
/** Prévient le bureau (e-mail de l'agence, sinon de la société) — en français ou en anglais selon la société */
export function officeNoticeMail(locale: string, o: { clientName: string; subject: string; lines: string[] }) {
  const en = langOf(locale) === 'en';
  return {
    subject: `${en ? 'Customer area' : 'Espace client'} – ${o.clientName} : ${o.subject}`,
    text: `${o.lines.join('\n')}\n\n${en ? `Sent automatically by ${PRODUCT_NAME} (customer area).` : `Envoyé automatiquement par ${PRODUCT_NAME} (espace client).`}`,
  };
}
