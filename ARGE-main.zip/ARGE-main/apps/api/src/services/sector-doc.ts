/**
 * Textes des documents propres aux métiers (points de passage, comparaison des états des lieux,
 * empreintes des photos, SOS, registre des traitements), en français et en anglais.
 * Les autres langues reçoivent l'anglais : ces éditions visent d'abord la France, la Belgique et le Royaume-Uni.
 */
import { applySectorWords, SECTOR_KINDS, SECTOR_VOCABULARY, type InterventionKind, type Sector } from '@itineo/shared';
import { docLang } from './doc-i18n.js';

const fr = {
  checkpoints: 'Points de passage',
  checkpointsDone: (n: number, total: number) => `${n} point${n > 1 ? 's' : ''} pointé${n > 1 ? 's' : ''} sur ${total}`,
  notScanned: 'Non pointé',
  comparison: 'Comparaison avec l’état des lieux d’entrée',
  comparisonOf: (num: string, date: string) => `État des lieux d’entrée n° ${num} du ${date}`,
  atEntry: 'Entrée', atExit: 'Sortie',
  noDifference: 'Aucune différence relevée avec l’état des lieux d’entrée.',
  unchanged: (n: number) => `${n} point${n > 1 ? 's' : ''} identique${n > 1 ? 's' : ''} à l’entrée.`,
  photoNo: (n: number) => `Photo n° ${n}`,
  takenAt: 'prise le',
  fingerprints: 'Empreintes numériques des photos',
  fingerprintsInfo: 'L’empreinte SHA-256 de chaque photo a été calculée à sa réception. Recalculée sur le fichier d’origine, elle permet de vérifier que la photo n’a pas été modifiée.',
  madeAt: (place: string, date: string) => `Fait à ${place}, le ${date}.`,
  madeOn: (date: string) => `Fait le ${date}.`,
};
type SectorDocTexts = typeof fr;

const en: SectorDocTexts = {
  checkpoints: 'Checkpoints',
  checkpointsDone: (n, total) => `${n} of ${total} checkpoint${total > 1 ? 's' : ''} scanned`,
  notScanned: 'Not scanned',
  comparison: 'Comparison with the check-in inventory',
  comparisonOf: (num, date) => `Check-in inventory no. ${num} of ${date}`,
  atEntry: 'Check-in', atExit: 'Check-out',
  noDifference: 'No difference found with the check-in inventory.',
  unchanged: (n) => `${n} item${n > 1 ? 's' : ''} unchanged since check-in.`,
  photoNo: (n) => `Photo no. ${n}`,
  takenAt: 'taken on',
  fingerprints: 'Photo fingerprints',
  fingerprintsInfo: 'The SHA-256 fingerprint of each photo was computed when it was received. Recomputed on the original file, it proves the photo has not been altered.',
  madeAt: (place, date) => `Done at ${place} on ${date}.`,
  madeOn: (date) => `Done on ${date}.`,
};

export function sectorDocTexts(locale: string): SectorDocTexts {
  return docLang(locale) === 'fr' ? fr : en;
}

/** Vocabulaire du métier dans un document : « Technicien » devient « Agent » (français et anglais) */
export function sectorWordsFor(sector: Sector, locale: string): (s: string) => string {
  const lang = docLang(locale);
  const vocab = SECTOR_VOCABULARY[sector];
  if (!vocab || (lang !== 'fr' && lang !== 'en')) return (s) => s;
  return (s) => applySectorWords(s, vocab[lang], lang);
}

/** Type d'intervention dans le vocabulaire du métier, si le document est en français ou en anglais */
export function sectorKindLabel(sector: Sector, kind: InterventionKind, locale: string): string | null {
  const lang = docLang(locale);
  const labels = SECTOR_KINDS[sector];
  return labels && (lang === 'fr' || lang === 'en') ? labels[lang][kind] : null;
}
