/**
 * Empreinte des fichiers du logiciel installé : serveur compilé, migrations, polices et appli web.
 * Le même calcul est fait à la fabrication du paquet (installeur/empreinte.mts) et par l'agent de supervision,
 * qui l'envoie à la console : si elle diffère de celle de la version, des fichiers ont été modifiés chez le client.
 * Sans serveur compilé (développement, code source), rien n'est vérifié.
 */
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { API_DIR, APP_ROOT } from '../paths.js';

/** Dossiers vérifiés, avec le nom sous lequel ils entrent dans l'empreinte */
export function integrityRoots(apiDir: string, webDir: string | null): { name: string; dir: string }[] {
  return [
    { name: 'api/dist', dir: path.join(apiDir, 'dist') },
    { name: 'api/migrations', dir: path.join(apiDir, 'migrations') },
    { name: 'api/assets', dir: path.join(apiDir, 'assets') },
    ...(webDir ? [{ name: 'web', dir: webDir }] : []),
  ];
}

async function listFiles(dir: string, prefix = ''): Promise<string[]> {
  const out: string[] = [];
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    if (e.isDirectory()) out.push(...(await listFiles(path.join(dir, e.name), rel)));
    else if (e.isFile()) out.push(rel);
  }
  return out;
}

/** « chemin empreinte » de chaque fichier, triés, puis l'empreinte de l'ensemble (SHA-256) */
export async function computeFingerprint(roots: { name: string; dir: string }[]): Promise<{ fingerprint: string; files: number }> {
  const lines: string[] = [];
  for (const r of roots) {
    if (!existsSync(r.dir)) continue;
    for (const rel of await listFiles(r.dir)) {
      const hash = createHash('sha256').update(await readFile(path.join(r.dir, rel))).digest('hex');
      lines.push(`${r.name}/${rel} ${hash}`);
    }
  }
  lines.sort();
  return { fingerprint: createHash('sha256').update(lines.join('\n')).digest('hex'), files: lines.length };
}

/** Empreinte de cette installation (null en développement : pas de serveur compilé) */
export async function softwareFingerprint(): Promise<{ fingerprint: string; files: number } | null> {
  if (!existsSync(path.join(API_DIR, 'dist'))) return null;
  // Installé : l'appli web est à côté du dossier app (C:\Program Files\Itineo\web)
  const web = path.resolve(APP_ROOT, '..', 'web');
  return computeFingerprint(integrityRoots(API_DIR, existsSync(web) ? web : null));
}
