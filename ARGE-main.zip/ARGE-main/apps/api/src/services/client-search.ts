/**
 * Recherche client avancée : sans tenir compte des accents ni des majuscules, numéros de téléphone écrits de
 * n'importe quelle façon (06 12…, 06.12…, +33 6 12…), dans les sites, contacts et matériels installés,
 * avec un critère au choix et un filtre par département.
 * Les fonctions SQL itn_norm et itn_digits viennent de la migration 0016.
 */
import { sql, type SQL } from 'drizzle-orm';

export const CLIENT_SEARCH_FIELDS = ['all', 'name', 'city', 'postalCode', 'phone', 'email', 'subscriber', 'serial', 'equipment', 'notes'] as const;
export type ClientSearchField = (typeof CLIENT_SEARCH_FIELDS)[number];
export const CLIENT_SORTS = ['name', 'city', 'postalCode', 'recent'] as const;
export type ClientSort = (typeof CLIENT_SORTS)[number];

/** Comme itn_norm côté base : minuscules, sans accents */
export function normalize(s: string): string {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/œ/g, 'oe').replace(/æ/g, 'ae').trim();
}

/** Chiffres d'un numéro, au format national français (+33 6… et 0033 6… deviennent 06…) */
export function phoneDigits(s: string): string {
  const d = s.replace(/\D/g, '');
  // Indicatif écrit explicitement (+33…, 0033…) : même un début de numéro est converti
  if (/^\s*(\+|00)33/.test(s)) return `0${d.replace(/^(00)?33/, '')}`;
  return d.replace(/^33(?=\d{9}$)/, '0');
}

const like = (s: string) => `%${s.replace(/[\\%_]/g, (m) => `\\${m}`)}%`;
/** Même conversion en SQL, pour les numéros enregistrés */
const sqlPhone = (col: SQL) => sql`regexp_replace(itn_digits(${col}), '^(00)?33(?=[0-9]{9}$)', '0')`;

/** Condition SQL pour la recherche (client « c ») ; null si rien à chercher */
export function clientSearchWhere(q: string, field: ClientSearchField): SQL | null {
  const text = normalize(q);
  if (!text) return null;
  const n = like(text);
  const digits = phoneDigits(q);
  const has = (cond: SQL) => cond;
  const site = (cond: SQL) => sql`EXISTS (SELECT 1 FROM sites s WHERE s.client_id = c.id AND ${cond})`;
  const equip = (cond: SQL) => sql`EXISTS (SELECT 1 FROM sites s JOIN equipments e ON e.site_id = s.id WHERE s.client_id = c.id AND ${cond})`;
  const contact = (cond: SQL) => sql`EXISTS (SELECT 1 FROM contacts k WHERE k.client_id = c.id AND ${cond})`;

  const parts: Record<Exclude<ClientSearchField, 'all'>, SQL | null> = {
    name: sql`(itn_norm(c.name) LIKE ${n} OR ${contact(sql`itn_norm(k.name) LIKE ${n}`)} OR ${site(sql`itn_norm(s.name) LIKE ${n}`)})`,
    city: sql`(itn_norm(c.city) LIKE ${n} OR ${site(sql`itn_norm(s.city) LIKE ${n}`)} OR itn_norm(c.address) LIKE ${n} OR ${site(sql`itn_norm(s.address) LIKE ${n}`)})`,
    postalCode: has(sql`(replace(c.postal_code, ' ', '') LIKE ${`${text.replace(/\s/g, '')}%`} OR ${site(sql`replace(s.postal_code, ' ', '') LIKE ${`${text.replace(/\s/g, '')}%`}`)})`),
    phone: digits.length >= 3
      ? sql`(${sqlPhone(sql`c.phone`)} LIKE ${like(digits)} OR ${contact(sql`${sqlPhone(sql`k.phone`)} LIKE ${like(digits)}`)})`
      : null,
    email: sql`(lower(c.email) LIKE ${n} OR ${contact(sql`lower(k.email) LIKE ${n}`)})`,
    subscriber: sql`(itn_norm(c.subscriber_number) LIKE ${n} OR itn_norm(c.external_ref) LIKE ${n})`,
    serial: sql`${equip(sql`itn_norm(replace(e.serial_number, ' ', '')) LIKE ${like(text.replace(/\s/g, ''))}`)}`,
    equipment: sql`${equip(sql`(itn_norm(e.category) LIKE ${n} OR itn_norm(e.brand) LIKE ${n} OR itn_norm(e.model) LIKE ${n} OR itn_norm(e.serial_number) LIKE ${n})`)}`,
    notes: sql`(itn_norm(c.notes) LIKE ${n} OR ${site(sql`itn_norm(s.access_notes) LIKE ${n}`)} OR ${equip(sql`(itn_norm(e.notes) LIKE ${n} OR itn_norm(e.locate_hint) LIKE ${n})`)})`,
  };
  if (field !== 'all') return parts[field] ?? sql`false`;
  const all = Object.values(parts).filter((x): x is SQL => !!x);
  return sql`(${sql.join(all, sql` OR `)})`;
}

/** Département : début du code postal du client ou d'un de ses sites (« 54 », « 2A », « 974 ») */
export function departmentWhere(dept: string): SQL | null {
  const d = dept.trim().toUpperCase().replace(/\s/g, '');
  if (!/^(\d{2,3}|2[AB])$/.test(d)) return null;
  // Corse : codes postaux 20…
  const prefix = d === '2A' || d === '2B' ? '20' : d;
  return sql`(replace(c.postal_code, ' ', '') LIKE ${`${prefix}%`} OR EXISTS (SELECT 1 FROM sites s WHERE s.client_id = c.id AND replace(s.postal_code, ' ', '') LIKE ${`${prefix}%`}))`;
}

export function clientOrder(sort: ClientSort): SQL {
  switch (sort) {
    case 'city': return sql`itn_norm(c.city) NULLS LAST, itn_norm(c.name)`;
    case 'postalCode': return sql`c.postal_code NULLS LAST, itn_norm(c.name)`;
    case 'recent': return sql`c.created_at DESC`;
    default: return sql`itn_norm(c.name)`;
  }
}
