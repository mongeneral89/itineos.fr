/** PDF du bon de sortie : ce qui quitte le dépôt, vers où, avec les signatures « remis par » / « reçu par » */
import PDFDocument from 'pdfkit';
import { pdfSafe } from './document-pdf.js';
import { docLang, docTexts, formatLocale } from './doc-i18n.js';
import { drawFooter, footerMargin, PdfWriter } from './pdf-text.js';
import { drawPdfLogo } from './logo.js';

export interface SlipPdfInput {
  /** Langue du document (celle de la société) */
  locale: string;
  company: { name: string; legalName?: string | null; address?: string | null; postalCode?: string | null; city?: string | null; legalMentions?: string | null; logo?: Buffer | null };
  number: string | null;
  date: Date;
  timezone: string;
  from: string;
  to: string;
  notes: string | null;
  lines: { reference: string; name: string; quantity: number; unit: string }[];
}

const INK = '#14181F';
const MUTED = '#5B616B';
const RULE = '#D9D4CA';

export function generateSlipPdf(input: SlipPdfInput): Promise<Buffer> {
  const t = docTexts(input.locale);
  const loc = formatLocale(input.locale);
  const doc = new PDFDocument({ size: 'A4', margins: { top: 40, left: 40, right: 40, bottom: footerMargin(input.company.legalMentions) }, bufferPages: true, info: { Title: `${t.slipTitle} ${input.number ?? ''}` } });
  const w = new PdfWriter(doc, docLang(input.locale));
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });
  const left = doc.page.margins.left;
  const width = doc.page.width - left - doc.page.margins.right;
  const num = (n: number) => pdfSafe(new Intl.NumberFormat(loc, { maximumFractionDigits: 3 }).format(n));
  const c = input.company;

  const top = doc.y;
  const logoH = drawPdfLogo(doc, c.logo, left, top);
  doc.fontSize(15).fillColor(INK);
  w.text(c.name, left, top + logoH, { width: width * 0.55, bold: true });
  doc.fontSize(8.5).fillColor(MUTED);
  for (const line of [c.legalName, [c.address, [c.postalCode, c.city].filter(Boolean).join(' ')].filter(Boolean).join(', ')].filter(Boolean) as string[]) {
    w.text(line, left, doc.y, { width: width * 0.55, align: 'left' });
  }
  const afterCompany = doc.y;
  doc.fontSize(14).fillColor(INK);
  w.text(t.slipTitle, left + width * 0.55, top, { width: width * 0.45, align: 'right', bold: true });
  doc.fontSize(10);
  w.text(`${t.number} ${input.number ?? t.draft}`, left + width * 0.55, doc.y, { width: width * 0.45, align: 'right' });
  doc.fillColor(MUTED).fontSize(9);
  w.text(`${t.date} : ${new Intl.DateTimeFormat(loc, { timeZone: input.timezone, dateStyle: 'long' }).format(input.date)}`, left + width * 0.55, doc.y, { width: width * 0.45, align: 'right' });
  doc.y = Math.max(afterCompany, doc.y) + 14;

  const half = (width - 12) / 2;
  const boxTop = doc.y;
  for (const [i, [title, value]] of [[t.from, input.from], [t.to, input.to]].entries()) {
    const x = left + i * (half + 12);
    doc.fontSize(9).fillColor(MUTED);
    w.text(title.toUpperCase(), x + 10, boxTop + 8, { width: half - 20, bold: true });
    doc.fontSize(10.5).fillColor(INK);
    w.text(value, x + 10, doc.y + 2, { width: half - 20 });
  }
  doc.roundedRect(left, boxTop, half, 56, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  doc.roundedRect(left + half + 12, boxTop, half, 56, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  doc.y = boxTop + 70;

  const cols = [
    { x: left, w: width * 0.22, align: 'left' as const, label: t.reference },
    { x: left + width * 0.23, w: width * 0.55, align: 'left' as const, label: t.description },
    { x: left + width * 0.78, w: width * 0.1, align: 'right' as const, label: t.qty },
    { x: left + width * 0.9, w: width * 0.1, align: 'left' as const, label: t.unit },
  ];
  let y = doc.y;
  doc.fontSize(8.5).fillColor(MUTED);
  for (const col of cols) w.text(col.label.toUpperCase(), col.x, y, { width: col.w, align: col.align, bold: true });
  doc.y = y + 14;
  doc.moveTo(left, doc.y - 3).lineTo(left + width, doc.y - 3).lineWidth(0.8).strokeColor(RULE).stroke();
  for (const l of input.lines) {
    if (doc.y > doc.page.height - 200) doc.addPage();
    y = doc.y;
    doc.fontSize(10).fillColor(INK);
    const h = w.height(l.name, { width: cols[1].w });
    [l.reference, l.name, num(l.quantity), l.unit].forEach((v, i) => w.text(v, cols[i].x, y, { width: cols[i].w, align: cols[i].align }));
    doc.y = y + h + 6;
  }
  doc.moveTo(left, doc.y).lineTo(left + width, doc.y).lineWidth(0.8).strokeColor(RULE).stroke();

  if (input.notes) {
    doc.moveDown(0.8);
    doc.fontSize(9).fillColor(MUTED);
    w.text(t.notes.toUpperCase(), left, doc.y, { width, bold: true });
    doc.fontSize(9.5).fillColor(INK);
    w.text(input.notes, left, doc.y, { width });
  }

  if (doc.y > doc.page.height - 190) doc.addPage();
  doc.moveDown(1.5);
  const sy = doc.y;
  for (const [i, title] of [t.given, t.received].entries()) {
    const x = left + i * (half + 12);
    doc.fontSize(10).fillColor(INK);
    w.text(title, x, sy, { width: half, bold: true });
    doc.fontSize(8).fillColor(MUTED);
    w.text(t.signHint, x, sy + 14, { width: half });
    doc.roundedRect(x, sy + 28, half, 70, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  }

  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    drawFooter(doc, w, c.legalMentions, `${input.number ?? t.draft} · ${t.page} ${i + 1}/${range.count}`, MUTED);
  }
  doc.end();
  return done;
}
