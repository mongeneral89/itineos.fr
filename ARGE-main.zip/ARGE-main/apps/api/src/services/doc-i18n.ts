/**
 * Textes des documents envoyés aux clients (devis, factures, avoirs, fiches d'intervention, bons de sortie)
 * et des e-mails qui les accompagnent, dans les 16 langues de l'interface.
 *
 * La langue d'un document est celle choisie sur la fiche du client, sinon celle de la société.
 */
import type { InterventionKind, Outcome, PhotoKind } from '@itineo/shared';

type Mail = { subject: string; text: string };

export interface DocTexts {
  // Devis, factures, avoirs
  quote: string; invoice: string; creditNote: string; draft: string;
  number: string; date: string; validUntil: string; serviceDate: string; dueDate: string;
  client: string; site: string;
  description: string; qty: string; unit: string; unitPrice: string; vat: string; lineTotal: string;
  net: string; vatOn: (rate: string, base: string) => string; gross: string; paid: string; due: string;
  contract: (months: number) => string;
  notes: string; acceptance: string; acceptanceHint: string;
  payment: string; paymentBy: (date: string) => string; bank: string;
  /** Mention de pénalités de retard exigée en France */
  latePenaltyFr: string;
  latePenalty: string;
  credits: (number: string) => string;
  vatNumber: string; page: string;
  // Fiche d'intervention
  reportTitle: string; intervention: string; type: string; technician: string; arrival: string; departure: string;
  reason: string; parts: string; reference: string; time: string; labor: string; travel: string; outcome: string;
  signatures: string; techSign: string; clientSign: string; absent: string; yes: string; no: string;
  reportAcceptance: string; min: string; photos: string;
  photoKinds: Record<PhotoKind, string>;
  kinds: Record<InterventionKind, string>;
  outcomes: Record<Outcome, string>;
  // Bon de sortie
  slipTitle: string; from: string; to: string; given: string; received: string; signHint: string;
  // Lignes créées automatiquement sur une facture
  laborLine: string; travelLine: string; flat: string;
  jobTitle: (number: string, reason: string) => string;
  contractTitle: (number: string, title: string) => string;
  period: (from: string, to: string) => string;
  /** Facture qui regroupe plusieurs contrats ou abonnements d'un client */
  contracts: (n: number) => string;
  /** Abonnement sans visite (télésurveillance…) */
  subscriptionTitle: (number: string, title: string) => string;
  // E-mails au client
  quoteMail: (o: { company: string; number: string; title: string }) => Mail;
  invoiceMail: (o: { company: string; number: string; credit: boolean; due: string | null }) => Mail;
  /** Relance d'une facture impayée : 1 rappel, 2 relance, 3 mise en demeure */
  reminderMail: (o: { company: string; number: string; due: string; remaining: string; level: 1 | 2 | 3 }) => Mail;
  reportMail: (o: { company: string; agency: string; number: string }) => Mail;
  inviteMail: (o: { name: string; client: string; company: string; link: string }) => Mail;
  resetMail: (o: { name: string; company: string; link: string }) => Mail;
  requestMail: (o: { name: string; company: string; number: string; reason: string }) => Mail;
}

const fr: DocTexts = {
  quote: 'DEVIS', invoice: 'FACTURE', creditNote: 'AVOIR', draft: 'BROUILLON',
  number: 'N°', date: 'Date', validUntil: "Valable jusqu'au", serviceDate: 'Date de la prestation', dueDate: 'Échéance',
  client: 'Client', site: "Lieu d'intervention",
  description: 'Désignation', qty: 'Qté', unit: 'Unité', unitPrice: 'PU HT', vat: 'TVA', lineTotal: 'Total HT',
  net: 'Total HT', vatOn: (r, b) => `TVA ${r} sur ${b}`, gross: 'Total TTC', paid: 'Déjà réglé', due: 'Reste à payer',
  contract: (f) => `Contrat d'entretien : une visite ${f === 12 ? 'par an' : `tous les ${f} mois`}.`,
  notes: 'Conditions', acceptance: 'Bon pour accord', acceptanceHint: 'Date, nom et signature du client, précédés de la mention « Bon pour accord »',
  payment: 'Règlement', paymentBy: (d) => `À régler au plus tard le ${d}.`, bank: 'Coordonnées bancaires',
  latePenaltyFr: "En cas de retard de paiement : pénalités au taux de 3 fois le taux d'intérêt légal, et indemnité forfaitaire pour frais de recouvrement de 40 € (clients professionnels). Pas d'escompte pour paiement anticipé.",
  latePenalty: 'En cas de retard de paiement, des intérêts et une indemnité de recouvrement peuvent être appliqués.',
  credits: (n) => `Avoir sur la facture ${n}.`, vatNumber: 'TVA', page: 'Page',
  reportTitle: "FICHE D'INTERVENTION", intervention: 'Intervention', type: 'Type', technician: 'Technicien', arrival: 'Arrivée', departure: 'Départ',
  reason: 'Motif', parts: 'Pièces et fournitures', reference: 'Référence', time: 'Temps passé et résultat', labor: "Main-d'œuvre", travel: 'Déplacement', outcome: 'Résultat',
  signatures: 'Signatures', techSign: 'Signature du technicien', clientSign: 'Signature du client', absent: 'Client absent', yes: 'Oui', no: 'Non',
  reportAcceptance: 'La signature du client vaut constat des travaux réalisés décrits ci-dessus.', min: 'min', photos: 'Photos',
  photoKinds: { BEFORE: 'Avant', AFTER: 'Après', OTHER: 'Autre' },
  kinds: { INSTALLATION: 'Installation', SAV: 'SAV / Dépannage', MAINTENANCE: 'Entretien', OTHER: 'Autre' },
  outcomes: { DONE: 'Terminé / réparé', TEMPORARY: 'Solution provisoire', TO_RESUME: 'À reprendre', WAITING_PARTS: 'En attente de pièces', QUOTE_NEEDED: 'Devis à établir' },
  slipTitle: 'BON DE SORTIE', from: 'Sortie de', to: 'Destination', given: 'Remis par', received: 'Reçu par', signHint: 'Nom, date et signature',
  laborLine: "Main-d'œuvre", travelLine: 'Déplacement', flat: 'forfait',
  jobTitle: (n, r) => `Intervention ${n} – ${r}`, contractTitle: (n, t) => `Contrat d'entretien ${n} – ${t}`, period: (a, b) => `Période du ${a} au ${b}`,
  contracts: (n) => `Contrats et abonnements (${n})`,
  subscriptionTitle: (n, t) => `Abonnement ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Devis ${o.number}`, text: `Bonjour,\n\nVous trouverez ci-joint notre devis ${o.number} : ${o.title}.\n\nCordialement,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Avoir' : 'Facture'} ${o.number}`,
    text: `Bonjour,\n\nVous trouverez ci-joint notre ${o.credit ? 'avoir' : 'facture'} ${o.number}.${o.due ? `\nÉchéance de paiement : ${o.due}.` : ''}\n\nCordialement,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Rappel', 'Relance', 'Mise en demeure'][o.level - 1]} – facture ${o.number}`,
    text: `Bonjour,\n\n${[
      `Sauf erreur de notre part, la facture ${o.number}, échue le ${o.due}, reste à régler : ${o.remaining}. Si votre règlement est déjà parti, merci de ne pas tenir compte de ce message.`,
      `Malgré notre précédent rappel, la facture ${o.number}, échue le ${o.due}, n'est toujours pas réglée (reste à payer : ${o.remaining}). Merci de procéder au règlement dès réception, ou de nous contacter en cas de difficulté.`,
      `Malgré nos relances, la facture ${o.number}, échue le ${o.due}, reste impayée pour un montant de ${o.remaining}. Nous vous mettons en demeure de la régler dans un délai de 8 jours. À défaut, nous engagerons les démarches de recouvrement prévues à nos conditions générales.`,
    ][o.level - 1]}\nLa facture est jointe à ce message.\n\nCordialement,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Fiche d'intervention ${o.number}`, text: `Bonjour,\n\nVous trouverez ci-joint la fiche de notre intervention (${o.number}).\n\nCordialement,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Votre espace client`,
    text: `Bonjour ${o.name},\n\n${o.company} vous invite à son espace client pour ${o.client}. Vous pourrez y suivre vos interventions, télécharger vos fiches signées et vos factures, répondre aux devis et demander une intervention.\n\nPour choisir votre mot de passe, ouvrez ce lien (valable 7 jours) :\n${o.link}\n\nCordialement,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Nouveau mot de passe`,
    text: `Bonjour ${o.name},\n\nPour choisir un nouveau mot de passe pour votre espace client, ouvrez ce lien (valable 1 heure, une seule fois) :\n${o.link}\n\nSi vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Demande ${o.number} bien reçue`,
    text: `Bonjour ${o.name},\n\nNous avons bien reçu votre demande ${o.number} :\n« ${o.reason} »\n\nNous revenons vers vous pour fixer le rendez-vous. Vous pouvez la suivre dans votre espace client.\n\nCordialement,\n${o.company}`,
  }),
};

const en: DocTexts = {
  quote: 'QUOTE', invoice: 'INVOICE', creditNote: 'CREDIT NOTE', draft: 'DRAFT',
  number: 'No.', date: 'Date', validUntil: 'Valid until', serviceDate: 'Service date', dueDate: 'Due date',
  client: 'Customer', site: 'Job location',
  description: 'Description', qty: 'Qty', unit: 'Unit', unitPrice: 'Unit price', vat: 'VAT', lineTotal: 'Net',
  net: 'Net total', vatOn: (r, b) => `VAT ${r} on ${b}`, gross: 'Total', paid: 'Already paid', due: 'Balance due',
  contract: (f) => `Maintenance contract: one visit ${f === 12 ? 'per year' : `every ${f} months`}.`,
  notes: 'Terms', acceptance: 'Accepted', acceptanceHint: 'Date, name and signature of the customer',
  payment: 'Payment', paymentBy: (d) => `Payment due by ${d}.`, bank: 'Bank details',
  latePenaltyFr: 'Late payment: penalties at three times the French statutory interest rate, plus a fixed recovery charge of €40 (business customers). No discount for early payment.',
  latePenalty: 'Late payments may incur statutory interest and a fixed recovery charge.',
  credits: (n) => `Credit note against invoice ${n}.`, vatNumber: 'VAT', page: 'Page',
  reportTitle: 'JOB REPORT', intervention: 'Job', type: 'Type', technician: 'Technician', arrival: 'Arrival', departure: 'Departure',
  reason: 'Reason', parts: 'Parts and supplies', reference: 'Reference', time: 'Time and outcome', labor: 'Labour', travel: 'Travel', outcome: 'Outcome',
  signatures: 'Signatures', techSign: 'Technician signature', clientSign: 'Customer signature', absent: 'Customer absent', yes: 'Yes', no: 'No',
  reportAcceptance: "The customer's signature confirms the work described above was carried out.", min: 'min', photos: 'Photos',
  photoKinds: { BEFORE: 'Before', AFTER: 'After', OTHER: 'Other' },
  kinds: { INSTALLATION: 'Installation', SAV: 'Service / Repair', MAINTENANCE: 'Maintenance', OTHER: 'Other' },
  outcomes: { DONE: 'Completed / repaired', TEMPORARY: 'Temporary fix', TO_RESUME: 'Follow-up needed', WAITING_PARTS: 'Waiting for parts', QUOTE_NEEDED: 'Quote required' },
  slipTitle: 'ISSUE SLIP', from: 'From', to: 'To', given: 'Issued by', received: 'Received by', signHint: 'Name, date and signature',
  laborLine: 'Labour', travelLine: 'Travel', flat: 'flat',
  jobTitle: (n, r) => `Job ${n} – ${r}`, contractTitle: (n, t) => `Maintenance contract ${n} – ${t}`, period: (a, b) => `Period ${a} – ${b}`,
  contracts: (n) => `Contracts and subscriptions (${n})`,
  subscriptionTitle: (n, t) => `Subscription ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Quote ${o.number}`, text: `Hello,\n\nPlease find attached our quote ${o.number}: ${o.title}.\n\nKind regards,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Credit note' : 'Invoice'} ${o.number}`,
    text: `Hello,\n\nPlease find attached our ${o.credit ? 'credit note' : 'invoice'} ${o.number}.${o.due ? `\nPayment is due by ${o.due}.` : ''}\n\nKind regards,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Reminder', 'Second reminder', 'Final notice'][o.level - 1]} – invoice ${o.number}`,
    text: `Hello,\n\n${[
      `Unless we are mistaken, invoice ${o.number}, due on ${o.due}, is still unpaid: ${o.remaining}. If you have already sent your payment, please disregard this message.`,
      `Despite our previous reminder, invoice ${o.number}, due on ${o.due}, has still not been paid (amount outstanding: ${o.remaining}). Please settle it on receipt, or contact us if there is a problem.`,
      `Despite our reminders, invoice ${o.number}, due on ${o.due}, remains unpaid for an amount of ${o.remaining}. We formally request payment within 8 days. Failing that, we will begin the collection steps set out in our terms and conditions.`,
    ][o.level - 1]}\nThe invoice is attached to this message.\n\nKind regards,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Job report ${o.number}`, text: `Hello,\n\nPlease find attached the report for our visit (${o.number}).\n\nKind regards,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Your customer area`,
    text: `Hello ${o.name},\n\n${o.company} invites you to its customer area for ${o.client}. You will be able to follow your jobs, download your signed reports and invoices, answer quotes and request a visit.\n\nTo choose your password, open this link (valid for 7 days):\n${o.link}\n\nKind regards,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Reset your password`,
    text: `Hello ${o.name},\n\nTo choose a new password for your customer area, open this link (valid for 1 hour, single use):\n${o.link}\n\nIf you did not ask for this, ignore this e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Request ${o.number} received`,
    text: `Hello ${o.name},\n\nWe have received your request ${o.number}:\n"${o.reason}"\n\nWe will contact you to arrange the visit. You can follow it in your customer area.\n\nKind regards,\n${o.company}`,
  }),
};

const es: DocTexts = {
  quote: 'PRESUPUESTO', invoice: 'FACTURA', creditNote: 'ABONO', draft: 'BORRADOR',
  number: 'N.º', date: 'Fecha', validUntil: 'Válido hasta el', serviceDate: 'Fecha de la prestación', dueDate: 'Vencimiento',
  client: 'Cliente', site: 'Lugar de intervención',
  description: 'Descripción', qty: 'Cant.', unit: 'Unidad', unitPrice: 'PU sin IVA', vat: 'IVA', lineTotal: 'Total sin IVA',
  net: 'Total sin IVA', vatOn: (r, b) => `IVA ${r} sobre ${b}`, gross: 'Total IVA incl.', paid: 'Ya pagado', due: 'Pendiente de pago',
  contract: (f) => `Contrato de mantenimiento: una visita ${f === 12 ? 'al año' : `cada ${f} meses`}.`,
  notes: 'Condiciones', acceptance: 'Conforme', acceptanceHint: 'Fecha, nombre y firma del cliente, precedidos de la mención «Conforme»',
  payment: 'Pago', paymentBy: (d) => `A pagar a más tardar el ${d}.`, bank: 'Datos bancarios',
  latePenaltyFr: 'En caso de retraso en el pago: penalizaciones del triple del tipo de interés legal francés e indemnización fija de 40 € por gastos de cobro (clientes profesionales). Sin descuento por pronto pago.',
  latePenalty: 'Los retrasos en el pago pueden generar intereses legales y una indemnización por gastos de cobro.',
  credits: (n) => `Abono sobre la factura ${n}.`, vatNumber: 'IVA', page: 'Página',
  reportTitle: 'PARTE DE INTERVENCIÓN', intervention: 'Intervención', type: 'Tipo', technician: 'Técnico', arrival: 'Llegada', departure: 'Salida',
  reason: 'Motivo', parts: 'Piezas y suministros', reference: 'Referencia', time: 'Tiempo empleado y resultado', labor: 'Mano de obra', travel: 'Desplazamiento', outcome: 'Resultado',
  signatures: 'Firmas', techSign: 'Firma del técnico', clientSign: 'Firma del cliente', absent: 'Cliente ausente', yes: 'Sí', no: 'No',
  reportAcceptance: 'La firma del cliente da constancia de los trabajos realizados descritos arriba.', min: 'min', photos: 'Fotos',
  photoKinds: { BEFORE: 'Antes', AFTER: 'Después', OTHER: 'Otra' },
  kinds: { INSTALLATION: 'Instalación', SAV: 'SAT / Avería', MAINTENANCE: 'Mantenimiento', OTHER: 'Otro' },
  outcomes: { DONE: 'Terminado / reparado', TEMPORARY: 'Solución provisional', TO_RESUME: 'Por retomar', WAITING_PARTS: 'En espera de piezas', QUOTE_NEEDED: 'Presupuesto por hacer' },
  slipTitle: 'ALBARÁN DE SALIDA', from: 'Salida de', to: 'Destino', given: 'Entregado por', received: 'Recibido por', signHint: 'Nombre, fecha y firma',
  laborLine: 'Mano de obra', travelLine: 'Desplazamiento', flat: 'tarifa fija',
  jobTitle: (n, r) => `Intervención ${n} – ${r}`, contractTitle: (n, t) => `Contrato de mantenimiento ${n} – ${t}`, period: (a, b) => `Periodo del ${a} al ${b}`,
  contracts: (n) => `Contratos y abonos (${n})`,
  subscriptionTitle: (n, t) => `Abono ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Presupuesto ${o.number}`, text: `Buenos días:\n\nLe adjuntamos nuestro presupuesto ${o.number}: ${o.title}.\n\nAtentamente,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Abono' : 'Factura'} ${o.number}`,
    text: `Buenos días:\n\nLe adjuntamos nuestro ${o.credit ? 'abono' : 'factura'} ${o.number}.${o.due ? `\nVencimiento del pago: ${o.due}.` : ''}\n\nAtentamente,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Recordatorio', 'Segundo aviso', 'Requerimiento de pago'][o.level - 1]} – factura ${o.number}`,
    text: `Buenos días:\n\n${[
      `Salvo error por nuestra parte, la factura ${o.number}, vencida el ${o.due}, sigue pendiente de pago: ${o.remaining}. Si ya ha realizado el pago, no tenga en cuenta este mensaje.`,
      `A pesar de nuestro recordatorio anterior, la factura ${o.number}, vencida el ${o.due}, sigue sin pagarse (importe pendiente: ${o.remaining}). Le rogamos que la abone a la mayor brevedad o que se ponga en contacto con nosotros si hay algún problema.`,
      `A pesar de nuestros avisos, la factura ${o.number}, vencida el ${o.due}, sigue impagada por un importe de ${o.remaining}. Le requerimos formalmente su pago en un plazo de 8 días. En caso contrario, iniciaremos las gestiones de cobro previstas en nuestras condiciones generales.`,
    ][o.level - 1]}\nAdjuntamos la factura a este mensaje.\n\nAtentamente,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Parte de intervención ${o.number}`, text: `Buenos días:\n\nLe adjuntamos el parte de nuestra intervención (${o.number}).\n\nAtentamente,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Su área de cliente`,
    text: `Hola, ${o.name}:\n\n${o.company} le invita a su área de cliente para ${o.client}. Podrá seguir sus intervenciones, descargar sus partes firmados y sus facturas, responder a los presupuestos y solicitar una intervención.\n\nPara elegir su contraseña, abra este enlace (válido 7 días):\n${o.link}\n\nAtentamente,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Nueva contraseña`,
    text: `Hola, ${o.name}:\n\nPara elegir una nueva contraseña para su área de cliente, abra este enlace (válido 1 hora, un solo uso):\n${o.link}\n\nSi no ha solicitado este cambio, ignore este e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Solicitud ${o.number} recibida`,
    text: `Hola, ${o.name}:\n\nHemos recibido su solicitud ${o.number}:\n«${o.reason}»\n\nLe contactaremos para fijar la cita. Puede seguirla en su área de cliente.\n\nAtentamente,\n${o.company}`,
  }),
};

const de: DocTexts = {
  quote: 'ANGEBOT', invoice: 'RECHNUNG', creditNote: 'GUTSCHRIFT', draft: 'ENTWURF',
  number: 'Nr.', date: 'Datum', validUntil: 'Gültig bis', serviceDate: 'Leistungsdatum', dueDate: 'Fällig am',
  client: 'Kunde', site: 'Einsatzort',
  description: 'Bezeichnung', qty: 'Menge', unit: 'Einheit', unitPrice: 'EP netto', vat: 'MwSt.', lineTotal: 'Netto',
  net: 'Summe netto', vatOn: (r, b) => `MwSt. ${r} auf ${b}`, gross: 'Summe brutto', paid: 'Bereits bezahlt', due: 'Offener Betrag',
  contract: (f) => `Wartungsvertrag: ein Besuch ${f === 12 ? 'pro Jahr' : `alle ${f} Monate`}.`,
  notes: 'Bedingungen', acceptance: 'Auftragsbestätigung', acceptanceHint: 'Datum, Name und Unterschrift des Kunden',
  payment: 'Zahlung', paymentBy: (d) => `Zahlbar bis spätestens ${d}.`, bank: 'Bankverbindung',
  latePenaltyFr: 'Bei Zahlungsverzug: Verzugszinsen in Höhe des Dreifachen des französischen gesetzlichen Zinssatzes und eine Pauschale von 40 € für Beitreibungskosten (Geschäftskunden). Kein Skonto bei vorzeitiger Zahlung.',
  latePenalty: 'Bei Zahlungsverzug können gesetzliche Zinsen und eine Mahnpauschale berechnet werden.',
  credits: (n) => `Gutschrift zur Rechnung ${n}.`, vatNumber: 'USt-IdNr.', page: 'Seite',
  reportTitle: 'EINSATZBERICHT', intervention: 'Einsatz', type: 'Art', technician: 'Techniker', arrival: 'Ankunft', departure: 'Abfahrt',
  reason: 'Grund', parts: 'Teile und Material', reference: 'Referenz', time: 'Aufwand und Ergebnis', labor: 'Arbeitszeit', travel: 'Fahrtzeit', outcome: 'Ergebnis',
  signatures: 'Unterschriften', techSign: 'Unterschrift des Technikers', clientSign: 'Unterschrift des Kunden', absent: 'Kunde abwesend', yes: 'Ja', no: 'Nein',
  reportAcceptance: 'Mit seiner Unterschrift bestätigt der Kunde die oben beschriebenen Arbeiten.', min: 'Min.', photos: 'Fotos',
  photoKinds: { BEFORE: 'Vorher', AFTER: 'Nachher', OTHER: 'Sonstiges' },
  kinds: { INSTALLATION: 'Installation', SAV: 'Kundendienst / Störung', MAINTENANCE: 'Wartung', OTHER: 'Sonstiges' },
  outcomes: { DONE: 'Erledigt / repariert', TEMPORARY: 'Provisorische Lösung', TO_RESUME: 'Wiederaufnahme nötig', WAITING_PARTS: 'Warten auf Teile', QUOTE_NEEDED: 'Angebot zu erstellen' },
  slipTitle: 'ENTNAHMESCHEIN', from: 'Entnahme aus', to: 'Ziel', given: 'Ausgegeben von', received: 'Erhalten von', signHint: 'Name, Datum und Unterschrift',
  laborLine: 'Arbeitszeit', travelLine: 'Anfahrt', flat: 'pauschal',
  jobTitle: (n, r) => `Einsatz ${n} – ${r}`, contractTitle: (n, t) => `Wartungsvertrag ${n} – ${t}`, period: (a, b) => `Zeitraum ${a} bis ${b}`,
  contracts: (n) => `Verträge und Abonnements (${n})`,
  subscriptionTitle: (n, t) => `Abonnement ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Angebot ${o.number}`, text: `Guten Tag,\n\nanbei erhalten Sie unser Angebot ${o.number}: ${o.title}.\n\nMit freundlichen Grüßen\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Gutschrift' : 'Rechnung'} ${o.number}`,
    text: `Guten Tag,\n\nanbei erhalten Sie unsere ${o.credit ? 'Gutschrift' : 'Rechnung'} ${o.number}.${o.due ? `\nZahlbar bis: ${o.due}.` : ''}\n\nMit freundlichen Grüßen\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Zahlungserinnerung', 'Mahnung', 'Letzte Mahnung'][o.level - 1]} – Rechnung ${o.number}`,
    text: `Guten Tag,\n\n${[
      `sofern wir uns nicht irren, ist die Rechnung ${o.number}, fällig am ${o.due}, noch offen: ${o.remaining}. Falls Sie die Zahlung bereits veranlasst haben, betrachten Sie diese Nachricht bitte als gegenstandslos.`,
      `trotz unserer Zahlungserinnerung ist die Rechnung ${o.number}, fällig am ${o.due}, noch nicht bezahlt (offener Betrag: ${o.remaining}). Bitte begleichen Sie den Betrag umgehend oder melden Sie sich bei uns, falls es ein Problem gibt.`,
      `trotz unserer Mahnungen ist die Rechnung ${o.number}, fällig am ${o.due}, über ${o.remaining} weiterhin unbezahlt. Wir fordern Sie auf, den Betrag innerhalb von 8 Tagen zu zahlen. Andernfalls leiten wir die in unseren Geschäftsbedingungen vorgesehenen Inkassoschritte ein.`,
    ][o.level - 1]}\nDie Rechnung finden Sie im Anhang.\n\nMit freundlichen Grüßen\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Einsatzbericht ${o.number}`, text: `Guten Tag,\n\nanbei erhalten Sie den Bericht zu unserem Einsatz (${o.number}).\n\nMit freundlichen Grüßen\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Ihr Kundenbereich`,
    text: `Hallo ${o.name},\n\n${o.company} lädt Sie in seinen Kundenbereich für ${o.client} ein. Dort können Sie Ihre Einsätze verfolgen, unterschriebene Berichte und Rechnungen herunterladen, auf Angebote antworten und einen Einsatz anfordern.\n\nUm Ihr Passwort festzulegen, öffnen Sie diesen Link (7 Tage gültig):\n${o.link}\n\nMit freundlichen Grüßen\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Neues Passwort`,
    text: `Hallo ${o.name},\n\num ein neues Passwort für Ihren Kundenbereich festzulegen, öffnen Sie diesen Link (1 Stunde gültig, nur einmal verwendbar):\n${o.link}\n\nFalls Sie dies nicht angefordert haben, ignorieren Sie diese E-Mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Anfrage ${o.number} erhalten`,
    text: `Hallo ${o.name},\n\nwir haben Ihre Anfrage ${o.number} erhalten:\n„${o.reason}“\n\nWir melden uns, um den Termin zu vereinbaren. Sie können sie in Ihrem Kundenbereich verfolgen.\n\nMit freundlichen Grüßen\n${o.company}`,
  }),
};

const it: DocTexts = {
  quote: 'PREVENTIVO', invoice: 'FATTURA', creditNote: 'NOTA DI CREDITO', draft: 'BOZZA',
  number: 'N.', date: 'Data', validUntil: 'Valido fino al', serviceDate: 'Data della prestazione', dueDate: 'Scadenza',
  client: 'Cliente', site: "Luogo dell'intervento",
  description: 'Descrizione', qty: 'Qtà', unit: 'Unità', unitPrice: 'PU IVA escl.', vat: 'IVA', lineTotal: 'Imponibile',
  net: 'Totale imponibile', vatOn: (r, b) => `IVA ${r} su ${b}`, gross: 'Totale IVA incl.', paid: 'Già pagato', due: 'Residuo da pagare',
  contract: (f) => `Contratto di manutenzione: una visita ${f === 12 ? "all'anno" : `ogni ${f} mesi`}.`,
  notes: 'Condizioni', acceptance: 'Per accettazione', acceptanceHint: 'Data, nome e firma del cliente, preceduti dalla dicitura «Per accettazione»',
  payment: 'Pagamento', paymentBy: (d) => `Da pagare entro il ${d}.`, bank: 'Coordinate bancarie',
  latePenaltyFr: 'In caso di ritardo nel pagamento: penali pari a tre volte il tasso di interesse legale francese e indennità forfettaria di 40 € per spese di recupero (clienti professionali). Nessuno sconto per pagamento anticipato.',
  latePenalty: 'In caso di ritardo nel pagamento possono essere applicati interessi legali e un indennizzo per le spese di recupero.',
  credits: (n) => `Nota di credito sulla fattura ${n}.`, vatNumber: 'P. IVA', page: 'Pagina',
  reportTitle: "RAPPORTINO D'INTERVENTO", intervention: 'Intervento', type: 'Tipo', technician: 'Tecnico', arrival: 'Arrivo', departure: 'Partenza',
  reason: 'Motivo', parts: 'Ricambi e materiali', reference: 'Riferimento', time: 'Tempo impiegato ed esito', labor: 'Manodopera', travel: 'Viaggio', outcome: 'Esito',
  signatures: 'Firme', techSign: 'Firma del tecnico', clientSign: 'Firma del cliente', absent: 'Cliente assente', yes: 'Sì', no: 'No',
  reportAcceptance: 'La firma del cliente attesta i lavori eseguiti descritti sopra.', min: 'min', photos: 'Foto',
  photoKinds: { BEFORE: 'Prima', AFTER: 'Dopo', OTHER: 'Altro' },
  kinds: { INSTALLATION: 'Installazione', SAV: 'Assistenza / Guasto', MAINTENANCE: 'Manutenzione', OTHER: 'Altro' },
  outcomes: { DONE: 'Completato / riparato', TEMPORARY: 'Soluzione provvisoria', TO_RESUME: 'Da riprendere', WAITING_PARTS: 'In attesa di ricambi', QUOTE_NEEDED: 'Preventivo da fare' },
  slipTitle: 'BUONO DI PRELIEVO', from: 'Uscita da', to: 'Destinazione', given: 'Consegnato da', received: 'Ricevuto da', signHint: 'Nome, data e firma',
  laborLine: 'Manodopera', travelLine: 'Diritto di chiamata', flat: 'forfait',
  jobTitle: (n, r) => `Intervento ${n} – ${r}`, contractTitle: (n, t) => `Contratto di manutenzione ${n} – ${t}`, period: (a, b) => `Periodo dal ${a} al ${b}`,
  contracts: (n) => `Contratti e abbonamenti (${n})`,
  subscriptionTitle: (n, t) => `Abbonamento ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Preventivo ${o.number}`, text: `Buongiorno,\n\nin allegato il nostro preventivo ${o.number}: ${o.title}.\n\nCordiali saluti,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Nota di credito' : 'Fattura'} ${o.number}`,
    text: `Buongiorno,\n\nin allegato la nostra ${o.credit ? 'nota di credito' : 'fattura'} ${o.number}.${o.due ? `\nScadenza del pagamento: ${o.due}.` : ''}\n\nCordiali saluti,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Promemoria', 'Sollecito', 'Diffida di pagamento'][o.level - 1]} – fattura ${o.number}`,
    text: `Buongiorno,\n\n${[
      `salvo errori da parte nostra, la fattura ${o.number}, scaduta il ${o.due}, risulta ancora da saldare: ${o.remaining}. Se ha già effettuato il pagamento, non tenga conto di questo messaggio.`,
      `nonostante il nostro precedente promemoria, la fattura ${o.number}, scaduta il ${o.due}, non è ancora stata saldata (importo residuo: ${o.remaining}). La preghiamo di provvedere al pagamento al ricevimento, o di contattarci in caso di difficoltà.`,
      `nonostante i nostri solleciti, la fattura ${o.number}, scaduta il ${o.due}, risulta ancora insoluta per un importo di ${o.remaining}. La diffidiamo a saldarla entro 8 giorni. In mancanza, avvieremo le procedure di recupero previste dalle nostre condizioni generali.`,
    ][o.level - 1]}\nLa fattura è allegata a questo messaggio.\n\nCordiali saluti,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Rapportino d'intervento ${o.number}`, text: `Buongiorno,\n\nin allegato il rapportino del nostro intervento (${o.number}).\n\nCordiali saluti,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – La sua area clienti`,
    text: `Buongiorno ${o.name},\n\n${o.company} la invita nella sua area clienti per ${o.client}. Potrà seguire i suoi interventi, scaricare rapportini firmati e fatture, rispondere ai preventivi e richiedere un intervento.\n\nPer scegliere la password, apra questo link (valido 7 giorni):\n${o.link}\n\nCordiali saluti,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Nuova password`,
    text: `Buongiorno ${o.name},\n\nper scegliere una nuova password per la sua area clienti, apra questo link (valido 1 ora, utilizzabile una sola volta):\n${o.link}\n\nSe non ha richiesto questa operazione, ignori questa e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Richiesta ${o.number} ricevuta`,
    text: `Buongiorno ${o.name},\n\nabbiamo ricevuto la sua richiesta ${o.number}:\n«${o.reason}»\n\nLa contatteremo per fissare l'appuntamento. Può seguirla nella sua area clienti.\n\nCordiali saluti,\n${o.company}`,
  }),
};

const pt: DocTexts = {
  quote: 'ORÇAMENTO', invoice: 'FATURA', creditNote: 'NOTA DE CRÉDITO', draft: 'RASCUNHO',
  number: 'N.º', date: 'Data', validUntil: 'Válido até', serviceDate: 'Data da prestação', dueDate: 'Vencimento',
  client: 'Cliente', site: 'Local da intervenção',
  description: 'Designação', qty: 'Qtd.', unit: 'Unidade', unitPrice: 'PU s/ IVA', vat: 'IVA', lineTotal: 'Total s/ IVA',
  net: 'Total s/ IVA', vatOn: (r, b) => `IVA ${r} sobre ${b}`, gross: 'Total c/ IVA', paid: 'Já pago', due: 'Por pagar',
  contract: (f) => `Contrato de manutenção: uma visita ${f === 12 ? 'por ano' : `a cada ${f} meses`}.`,
  notes: 'Condições', acceptance: 'Aprovado', acceptanceHint: 'Data, nome e assinatura do cliente, precedidos da menção «Aprovado»',
  payment: 'Pagamento', paymentBy: (d) => `A pagar até ${d}.`, bank: 'Dados bancários',
  latePenaltyFr: 'Em caso de atraso no pagamento: penalizações de três vezes a taxa de juro legal francesa e indemnização fixa de 40 € por custos de cobrança (clientes profissionais). Sem desconto por pagamento antecipado.',
  latePenalty: 'Os atrasos no pagamento podem dar lugar a juros legais e a uma indemnização por custos de cobrança.',
  credits: (n) => `Nota de crédito da fatura ${n}.`, vatNumber: 'NIF', page: 'Página',
  reportTitle: 'RELATÓRIO DE INTERVENÇÃO', intervention: 'Intervenção', type: 'Tipo', technician: 'Técnico', arrival: 'Chegada', departure: 'Partida',
  reason: 'Motivo', parts: 'Peças e materiais', reference: 'Referência', time: 'Tempo gasto e resultado', labor: 'Mão de obra', travel: 'Deslocação', outcome: 'Resultado',
  signatures: 'Assinaturas', techSign: 'Assinatura do técnico', clientSign: 'Assinatura do cliente', absent: 'Cliente ausente', yes: 'Sim', no: 'Não',
  reportAcceptance: 'A assinatura do cliente confirma os trabalhos realizados descritos acima.', min: 'min', photos: 'Fotos',
  photoKinds: { BEFORE: 'Antes', AFTER: 'Depois', OTHER: 'Outra' },
  kinds: { INSTALLATION: 'Instalação', SAV: 'Assistência / Avaria', MAINTENANCE: 'Manutenção', OTHER: 'Outro' },
  outcomes: { DONE: 'Concluído / reparado', TEMPORARY: 'Solução provisória', TO_RESUME: 'A retomar', WAITING_PARTS: 'A aguardar peças', QUOTE_NEEDED: 'Orçamento a fazer' },
  slipTitle: 'GUIA DE SAÍDA', from: 'Saída de', to: 'Destino', given: 'Entregue por', received: 'Recebido por', signHint: 'Nome, data e assinatura',
  laborLine: 'Mão de obra', travelLine: 'Deslocação', flat: 'valor fixo',
  jobTitle: (n, r) => `Intervenção ${n} – ${r}`, contractTitle: (n, t) => `Contrato de manutenção ${n} – ${t}`, period: (a, b) => `Período de ${a} a ${b}`,
  contracts: (n) => `Contratos e assinaturas (${n})`,
  subscriptionTitle: (n, t) => `Assinatura ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Orçamento ${o.number}`, text: `Bom dia,\n\nEnviamos em anexo o nosso orçamento ${o.number}: ${o.title}.\n\nCom os melhores cumprimentos,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Nota de crédito' : 'Fatura'} ${o.number}`,
    text: `Bom dia,\n\nEnviamos em anexo a nossa ${o.credit ? 'nota de crédito' : 'fatura'} ${o.number}.${o.due ? `\nVencimento: ${o.due}.` : ''}\n\nCom os melhores cumprimentos,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Lembrete', 'Segundo aviso', 'Interpelação para pagamento'][o.level - 1]} – fatura ${o.number}`,
    text: `Bom dia,\n\n${[
      `Salvo erro da nossa parte, a fatura ${o.number}, vencida a ${o.due}, continua por liquidar: ${o.remaining}. Se já efetuou o pagamento, não tenha em conta esta mensagem.`,
      `Apesar do nosso lembrete anterior, a fatura ${o.number}, vencida a ${o.due}, continua por pagar (valor em dívida: ${o.remaining}). Pedimos que proceda ao pagamento logo que possível, ou que nos contacte em caso de dificuldade.`,
      `Apesar dos nossos avisos, a fatura ${o.number}, vencida a ${o.due}, continua por pagar no valor de ${o.remaining}. Interpelamo-lo formalmente para a liquidar no prazo de 8 dias. Caso contrário, iniciaremos as diligências de cobrança previstas nas nossas condições gerais.`,
    ][o.level - 1]}\nA fatura segue em anexo a esta mensagem.\n\nCom os melhores cumprimentos,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Relatório de intervenção ${o.number}`, text: `Bom dia,\n\nEnviamos em anexo o relatório da nossa intervenção (${o.number}).\n\nCom os melhores cumprimentos,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – A sua área de cliente`,
    text: `Olá ${o.name},\n\nA ${o.company} convida-o para a sua área de cliente de ${o.client}. Poderá acompanhar as intervenções, descarregar relatórios assinados e faturas, responder a orçamentos e pedir uma intervenção.\n\nPara escolher a sua palavra-passe, abra esta ligação (válida 7 dias):\n${o.link}\n\nCom os melhores cumprimentos,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Nova palavra-passe`,
    text: `Olá ${o.name},\n\nPara escolher uma nova palavra-passe para a sua área de cliente, abra esta ligação (válida 1 hora, uma única vez):\n${o.link}\n\nSe não fez este pedido, ignore este e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Pedido ${o.number} recebido`,
    text: `Olá ${o.name},\n\nRecebemos o seu pedido ${o.number}:\n«${o.reason}»\n\nVamos contactá-lo para marcar a visita. Pode acompanhá-lo na sua área de cliente.\n\nCom os melhores cumprimentos,\n${o.company}`,
  }),
};

const nl: DocTexts = {
  quote: 'OFFERTE', invoice: 'FACTUUR', creditNote: 'CREDITNOTA', draft: 'CONCEPT',
  number: 'Nr.', date: 'Datum', validUntil: 'Geldig tot', serviceDate: 'Datum van de prestatie', dueDate: 'Vervaldatum',
  client: 'Klant', site: 'Plaats van de opdracht',
  description: 'Omschrijving', qty: 'Aant.', unit: 'Eenheid', unitPrice: 'EP excl. btw', vat: 'Btw', lineTotal: 'Excl. btw',
  net: 'Totaal excl. btw', vatOn: (r, b) => `Btw ${r} over ${b}`, gross: 'Totaal incl. btw', paid: 'Reeds betaald', due: 'Nog te betalen',
  contract: (f) => `Onderhoudscontract: één bezoek ${f === 12 ? 'per jaar' : `elke ${f} maanden`}.`,
  notes: 'Voorwaarden', acceptance: 'Voor akkoord', acceptanceHint: 'Datum, naam en handtekening van de klant, voorafgegaan door "Voor akkoord"',
  payment: 'Betaling', paymentBy: (d) => `Te betalen uiterlijk op ${d}.`, bank: 'Bankgegevens',
  latePenaltyFr: 'Bij laattijdige betaling: boete van driemaal de Franse wettelijke rentevoet en een vaste vergoeding van € 40 voor invorderingskosten (zakelijke klanten). Geen korting bij vervroegde betaling.',
  latePenalty: 'Bij laattijdige betaling kunnen wettelijke interesten en een invorderingsvergoeding worden aangerekend.',
  credits: (n) => `Creditnota op factuur ${n}.`, vatNumber: 'Btw-nr.', page: 'Pagina',
  reportTitle: 'WERKBON', intervention: 'Opdracht', type: 'Soort', technician: 'Technicus', arrival: 'Aankomst', departure: 'Vertrek',
  reason: 'Reden', parts: 'Onderdelen en materiaal', reference: 'Referentie', time: 'Bestede tijd en resultaat', labor: 'Arbeid', travel: 'Verplaatsing', outcome: 'Resultaat',
  signatures: 'Handtekeningen', techSign: 'Handtekening technicus', clientSign: 'Handtekening klant', absent: 'Klant afwezig', yes: 'Ja', no: 'Nee',
  reportAcceptance: 'Met zijn handtekening bevestigt de klant de hierboven beschreven werkzaamheden.', min: 'min', photos: "Foto's",
  photoKinds: { BEFORE: 'Voor', AFTER: 'Na', OTHER: 'Overig' },
  kinds: { INSTALLATION: 'Installatie', SAV: 'Service / Storing', MAINTENANCE: 'Onderhoud', OTHER: 'Overig' },
  outcomes: { DONE: 'Afgerond / gerepareerd', TEMPORARY: 'Tijdelijke oplossing', TO_RESUME: 'Opnieuw te doen', WAITING_PARTS: 'Wacht op onderdelen', QUOTE_NEEDED: 'Offerte nodig' },
  slipTitle: 'UITGIFTEBON', from: 'Uitgifte uit', to: 'Bestemming', given: 'Afgegeven door', received: 'Ontvangen door', signHint: 'Naam, datum en handtekening',
  laborLine: 'Arbeid', travelLine: 'Voorrijkosten', flat: 'forfait',
  jobTitle: (n, r) => `Opdracht ${n} – ${r}`, contractTitle: (n, t) => `Onderhoudscontract ${n} – ${t}`, period: (a, b) => `Periode van ${a} tot ${b}`,
  contracts: (n) => `Contracten en abonnementen (${n})`,
  subscriptionTitle: (n, t) => `Abonnement ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Offerte ${o.number}`, text: `Goedendag,\n\nIn bijlage vindt u onze offerte ${o.number}: ${o.title}.\n\nMet vriendelijke groeten,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Creditnota' : 'Factuur'} ${o.number}`,
    text: `Goedendag,\n\nIn bijlage vindt u onze ${o.credit ? 'creditnota' : 'factuur'} ${o.number}.${o.due ? `\nVervaldatum: ${o.due}.` : ''}\n\nMet vriendelijke groeten,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Herinnering', 'Tweede herinnering', 'Ingebrekestelling'][o.level - 1]} – factuur ${o.number}`,
    text: `Goedendag,\n\n${[
      `Behoudens vergissing onzerzijds staat factuur ${o.number}, vervallen op ${o.due}, nog open: ${o.remaining}. Hebt u al betaald, dan mag u dit bericht als niet verzonden beschouwen.`,
      `Ondanks onze eerdere herinnering is factuur ${o.number}, vervallen op ${o.due}, nog steeds niet betaald (openstaand bedrag: ${o.remaining}). Gelieve het bedrag onmiddellijk te betalen, of neem contact met ons op als er een probleem is.`,
      `Ondanks onze herinneringen blijft factuur ${o.number}, vervallen op ${o.due}, onbetaald voor een bedrag van ${o.remaining}. Wij stellen u in gebreke en verzoeken u het bedrag binnen 8 dagen te betalen. Zo niet, dan starten wij de invorderingsstappen uit onze algemene voorwaarden.`,
    ][o.level - 1]}\nDe factuur is bij dit bericht gevoegd.\n\nMet vriendelijke groeten,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Werkbon ${o.number}`, text: `Goedendag,\n\nIn bijlage vindt u de werkbon van ons bezoek (${o.number}).\n\nMet vriendelijke groeten,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Uw klantenzone`,
    text: `Hallo ${o.name},\n\n${o.company} nodigt u uit in zijn klantenzone voor ${o.client}. U kunt er uw opdrachten volgen, ondertekende werkbonnen en facturen downloaden, op offertes antwoorden en een opdracht aanvragen.\n\nOm uw wachtwoord te kiezen, opent u deze link (7 dagen geldig):\n${o.link}\n\nMet vriendelijke groeten,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Nieuw wachtwoord`,
    text: `Hallo ${o.name},\n\nOm een nieuw wachtwoord voor uw klantenzone te kiezen, opent u deze link (1 uur geldig, eenmalig te gebruiken):\n${o.link}\n\nHebt u dit niet gevraagd, negeer dan deze e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Aanvraag ${o.number} ontvangen`,
    text: `Hallo ${o.name},\n\nWe hebben uw aanvraag ${o.number} ontvangen:\n"${o.reason}"\n\nWe nemen contact op om de afspraak vast te leggen. U kunt ze volgen in uw klantenzone.\n\nMet vriendelijke groeten,\n${o.company}`,
  }),
};

const pl: DocTexts = {
  quote: 'OFERTA', invoice: 'FAKTURA', creditNote: 'FAKTURA KORYGUJĄCA', draft: 'SZKIC',
  number: 'Nr', date: 'Data', validUntil: 'Ważna do', serviceDate: 'Data wykonania usługi', dueDate: 'Termin płatności',
  client: 'Klient', site: 'Miejsce zlecenia',
  description: 'Nazwa', qty: 'Il.', unit: 'J.m.', unitPrice: 'Cena netto', vat: 'VAT', lineTotal: 'Wartość netto',
  net: 'Razem netto', vatOn: (r, b) => `VAT ${r} od ${b}`, gross: 'Razem brutto', paid: 'Już zapłacono', due: 'Pozostało do zapłaty',
  contract: (f) => `Umowa serwisowa: ${f === 12 ? 'jedna wizyta w roku' : `jedna wizyta co ${f} mies.`}.`,
  notes: 'Warunki', acceptance: 'Akceptuję', acceptanceHint: 'Data, imię i nazwisko oraz podpis klienta',
  payment: 'Płatność', paymentBy: (d) => `Płatne najpóźniej do ${d}.`, bank: 'Dane bankowe',
  latePenaltyFr: 'W przypadku opóźnienia w płatności: kary w wysokości trzykrotności francuskiej stopy odsetek ustawowych oraz ryczałtowe odszkodowanie 40 € za koszty windykacji (klienci biznesowi). Brak rabatu za wcześniejszą płatność.',
  latePenalty: 'Za opóźnienie w płatności mogą zostać naliczone odsetki ustawowe i rekompensata za koszty odzyskania należności.',
  credits: (n) => `Korekta do faktury ${n}.`, vatNumber: 'NIP', page: 'Strona',
  reportTitle: 'RAPORT SERWISOWY', intervention: 'Zlecenie', type: 'Rodzaj', technician: 'Technik', arrival: 'Przyjazd', departure: 'Wyjazd',
  reason: 'Powód', parts: 'Części i materiały', reference: 'Indeks', time: 'Czas pracy i wynik', labor: 'Robocizna', travel: 'Dojazd', outcome: 'Wynik',
  signatures: 'Podpisy', techSign: 'Podpis technika', clientSign: 'Podpis klienta', absent: 'Klient nieobecny', yes: 'Tak', no: 'Nie',
  reportAcceptance: 'Podpis klienta potwierdza wykonanie opisanych powyżej prac.', min: 'min', photos: 'Zdjęcia',
  photoKinds: { BEFORE: 'Przed', AFTER: 'Po', OTHER: 'Inne' },
  kinds: { INSTALLATION: 'Instalacja', SAV: 'Serwis / Awaria', MAINTENANCE: 'Konserwacja', OTHER: 'Inne' },
  outcomes: { DONE: 'Zakończone / naprawione', TEMPORARY: 'Rozwiązanie tymczasowe', TO_RESUME: 'Do ponownego wykonania', WAITING_PARTS: 'Oczekiwanie na części', QUOTE_NEEDED: 'Do przygotowania oferta' },
  slipTitle: 'DOWÓD WYDANIA', from: 'Wydanie z', to: 'Miejsce docelowe', given: 'Wydał', received: 'Odebrał', signHint: 'Imię i nazwisko, data i podpis',
  laborLine: 'Robocizna', travelLine: 'Dojazd', flat: 'ryczałt',
  jobTitle: (n, r) => `Zlecenie ${n} – ${r}`, contractTitle: (n, t) => `Umowa serwisowa ${n} – ${t}`, period: (a, b) => `Okres od ${a} do ${b}`,
  contracts: (n) => `Umowy i abonamenty (${n})`,
  subscriptionTitle: (n, t) => `Abonament ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Oferta ${o.number}`, text: `Dzień dobry,\n\nw załączeniu przesyłamy ofertę ${o.number}: ${o.title}.\n\nZ poważaniem\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Faktura korygująca' : 'Faktura'} ${o.number}`,
    text: `Dzień dobry,\n\nw załączeniu przesyłamy ${o.credit ? 'fakturę korygującą' : 'fakturę'} ${o.number}.${o.due ? `\nTermin płatności: ${o.due}.` : ''}\n\nZ poważaniem\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Przypomnienie', 'Ponaglenie', 'Wezwanie do zapłaty'][o.level - 1]} – faktura ${o.number}`,
    text: `Dzień dobry,\n\n${[
      `o ile się nie mylimy, faktura ${o.number} z terminem płatności ${o.due} pozostaje nieopłacona: ${o.remaining}. Jeśli płatność została już wysłana, prosimy zignorować tę wiadomość.`,
      `mimo naszego wcześniejszego przypomnienia faktura ${o.number} z terminem płatności ${o.due} nadal nie została opłacona (pozostało do zapłaty: ${o.remaining}). Prosimy o niezwłoczną zapłatę lub kontakt w razie problemu.`,
      `mimo naszych ponagleń faktura ${o.number} z terminem płatności ${o.due} pozostaje nieopłacona na kwotę ${o.remaining}. Wzywamy do jej zapłaty w terminie 8 dni. W przeciwnym razie podejmiemy działania windykacyjne przewidziane w naszych ogólnych warunkach.`,
    ][o.level - 1]}\nFaktura jest załączona do tej wiadomości.\n\nZ poważaniem\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Raport serwisowy ${o.number}`, text: `Dzień dobry,\n\nw załączeniu przesyłamy raport z naszej wizyty (${o.number}).\n\nZ poważaniem\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Twoja strefa klienta`,
    text: `Dzień dobry ${o.name},\n\n${o.company} zaprasza do strefy klienta dla ${o.client}. Możesz tam śledzić zlecenia, pobierać podpisane raporty i faktury, odpowiadać na oferty i zgłaszać zlecenia.\n\nAby ustawić hasło, otwórz ten link (ważny 7 dni):\n${o.link}\n\nZ poważaniem\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Nowe hasło`,
    text: `Dzień dobry ${o.name},\n\naby ustawić nowe hasło do strefy klienta, otwórz ten link (ważny 1 godzinę, jednorazowy):\n${o.link}\n\nJeśli to nie Ty, zignoruj tę wiadomość.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Zgłoszenie ${o.number} przyjęte`,
    text: `Dzień dobry ${o.name},\n\nprzyjęliśmy Twoje zgłoszenie ${o.number}:\n„${o.reason}”\n\nSkontaktujemy się, aby ustalić termin. Możesz je śledzić w strefie klienta.\n\nZ poważaniem\n${o.company}`,
  }),
};

const ro: DocTexts = {
  quote: 'OFERTĂ', invoice: 'FACTURĂ', creditNote: 'FACTURĂ DE STORNARE', draft: 'CIORNĂ',
  number: 'Nr.', date: 'Data', validUntil: 'Valabilă până la', serviceDate: 'Data prestației', dueDate: 'Scadență',
  client: 'Client', site: 'Locul intervenției',
  description: 'Denumire', qty: 'Cant.', unit: 'U.M.', unitPrice: 'PU fără TVA', vat: 'TVA', lineTotal: 'Valoare fără TVA',
  net: 'Total fără TVA', vatOn: (r, b) => `TVA ${r} la ${b}`, gross: 'Total cu TVA', paid: 'Deja plătit', due: 'Rest de plată',
  contract: (f) => `Contract de întreținere: o vizită ${f === 12 ? 'pe an' : `la fiecare ${f} luni`}.`,
  notes: 'Condiții', acceptance: 'De acord', acceptanceHint: 'Data, numele și semnătura clientului, precedate de mențiunea „De acord”',
  payment: 'Plată', paymentBy: (d) => `De plătit cel târziu la ${d}.`, bank: 'Date bancare',
  latePenaltyFr: 'În caz de întârziere la plată: penalități de trei ori rata dobânzii legale franceze și o indemnizație forfetară de 40 € pentru costurile de recuperare (clienți profesioniști). Fără reducere pentru plata anticipată.',
  latePenalty: 'Întârzierile la plată pot atrage dobânzi legale și o indemnizație pentru costurile de recuperare.',
  credits: (n) => `Stornare la factura ${n}.`, vatNumber: 'CUI', page: 'Pagina',
  reportTitle: 'FIȘĂ DE INTERVENȚIE', intervention: 'Intervenție', type: 'Tip', technician: 'Tehnician', arrival: 'Sosire', departure: 'Plecare',
  reason: 'Motiv', parts: 'Piese și materiale', reference: 'Referință', time: 'Timp lucrat și rezultat', labor: 'Manoperă', travel: 'Deplasare', outcome: 'Rezultat',
  signatures: 'Semnături', techSign: 'Semnătura tehnicianului', clientSign: 'Semnătura clientului', absent: 'Client absent', yes: 'Da', no: 'Nu',
  reportAcceptance: 'Semnătura clientului confirmă lucrările efectuate descrise mai sus.', min: 'min', photos: 'Fotografii',
  photoKinds: { BEFORE: 'Înainte', AFTER: 'După', OTHER: 'Alta' },
  kinds: { INSTALLATION: 'Instalare', SAV: 'Service / Defecțiune', MAINTENANCE: 'Întreținere', OTHER: 'Altele' },
  outcomes: { DONE: 'Finalizat / reparat', TEMPORARY: 'Soluție provizorie', TO_RESUME: 'De reluat', WAITING_PARTS: 'În așteptarea pieselor', QUOTE_NEEDED: 'Ofertă de întocmit' },
  slipTitle: 'BON DE IEȘIRE', from: 'Ieșire din', to: 'Destinație', given: 'Predat de', received: 'Primit de', signHint: 'Nume, dată și semnătură',
  laborLine: 'Manoperă', travelLine: 'Deplasare', flat: 'forfetar',
  jobTitle: (n, r) => `Intervenția ${n} – ${r}`, contractTitle: (n, t) => `Contract de întreținere ${n} – ${t}`, period: (a, b) => `Perioada ${a} – ${b}`,
  contracts: (n) => `Contracte și abonamente (${n})`,
  subscriptionTitle: (n, t) => `Abonament ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Oferta ${o.number}`, text: `Bună ziua,\n\nVă transmitem atașat oferta noastră ${o.number}: ${o.title}.\n\nCu stimă,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Factura de stornare' : 'Factura'} ${o.number}`,
    text: `Bună ziua,\n\nVă transmitem atașat ${o.credit ? 'factura de stornare' : 'factura'} ${o.number}.${o.due ? `\nScadența plății: ${o.due}.` : ''}\n\nCu stimă,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Memento', 'Revenire', 'Somație de plată'][o.level - 1]} – factura ${o.number}`,
    text: `Bună ziua,\n\n${[
      `Dacă nu ne înșelăm, factura ${o.number}, scadentă la ${o.due}, este încă neachitată: ${o.remaining}. Dacă ați efectuat deja plata, vă rugăm să ignorați acest mesaj.`,
      `În ciuda mementoului nostru anterior, factura ${o.number}, scadentă la ${o.due}, nu a fost încă achitată (rest de plată: ${o.remaining}). Vă rugăm să efectuați plata la primire sau să ne contactați dacă există o problemă.`,
      `În ciuda revenirilor noastre, factura ${o.number}, scadentă la ${o.due}, rămâne neachitată în valoare de ${o.remaining}. Vă somăm să o achitați în termen de 8 zile. În caz contrar, vom iniția demersurile de recuperare prevăzute în condițiile noastre generale.`,
    ][o.level - 1]}\nFactura este atașată acestui mesaj.\n\nCu stimă,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Fișa de intervenție ${o.number}`, text: `Bună ziua,\n\nVă transmitem atașat fișa intervenției noastre (${o.number}).\n\nCu stimă,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Spațiul dvs. de client`,
    text: `Bună ziua, ${o.name},\n\n${o.company} vă invită în spațiul său de client pentru ${o.client}. Veți putea urmări intervențiile, descărca fișele semnate și facturile, răspunde la oferte și solicita o intervenție.\n\nPentru a vă alege parola, deschideți acest link (valabil 7 zile):\n${o.link}\n\nCu stimă,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Parolă nouă`,
    text: `Bună ziua, ${o.name},\n\nPentru a alege o parolă nouă pentru spațiul de client, deschideți acest link (valabil 1 oră, o singură dată):\n${o.link}\n\nDacă nu ați cerut acest lucru, ignorați acest e-mail.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Solicitarea ${o.number} a fost primită`,
    text: `Bună ziua, ${o.name},\n\nAm primit solicitarea dvs. ${o.number}:\n„${o.reason}”\n\nVă vom contacta pentru a stabili programarea. O puteți urmări în spațiul de client.\n\nCu stimă,\n${o.company}`,
  }),
};

const tr: DocTexts = {
  quote: 'TEKLİF', invoice: 'FATURA', creditNote: 'İADE FATURASI', draft: 'TASLAK',
  number: 'No.', date: 'Tarih', validUntil: 'Geçerlilik tarihi', serviceDate: 'Hizmet tarihi', dueDate: 'Vade',
  client: 'Müşteri', site: 'İş yeri',
  description: 'Açıklama', qty: 'Mik.', unit: 'Birim', unitPrice: 'BF KDV hariç', vat: 'KDV', lineTotal: 'KDV hariç',
  net: 'KDV hariç toplam', vatOn: (r, b) => `${b} üzerinden KDV ${r}`, gross: 'KDV dahil toplam', paid: 'Ödenen', due: 'Kalan borç',
  contract: (f) => `Bakım sözleşmesi: ${f === 12 ? 'yılda bir ziyaret' : `${f} ayda bir ziyaret`}.`,
  notes: 'Koşullar', acceptance: 'Onaylıyorum', acceptanceHint: 'Müşterinin tarihi, adı ve imzası',
  payment: 'Ödeme', paymentBy: (d) => `En geç ${d} tarihinde ödenmelidir.`, bank: 'Banka bilgileri',
  latePenaltyFr: 'Geç ödemede: Fransız yasal faiz oranının üç katı tutarında ceza ve 40 € sabit tahsilat masrafı (kurumsal müşteriler). Erken ödemede indirim uygulanmaz.',
  latePenalty: 'Geç ödemelerde yasal faiz ve tahsilat masrafı uygulanabilir.',
  credits: (n) => `${n} numaralı faturaya iade.`, vatNumber: 'Vergi no.', page: 'Sayfa',
  reportTitle: 'SERVİS RAPORU', intervention: 'İş emri', type: 'Tür', technician: 'Teknisyen', arrival: 'Varış', departure: 'Ayrılış',
  reason: 'Neden', parts: 'Parçalar ve malzemeler', reference: 'Referans', time: 'Harcanan süre ve sonuç', labor: 'İşçilik', travel: 'Yol', outcome: 'Sonuç',
  signatures: 'İmzalar', techSign: 'Teknisyen imzası', clientSign: 'Müşteri imzası', absent: 'Müşteri yok', yes: 'Evet', no: 'Hayır',
  reportAcceptance: 'Müşterinin imzası, yukarıda açıklanan işlerin yapıldığını onaylar.', min: 'dk', photos: 'Fotoğraflar',
  photoKinds: { BEFORE: 'Önce', AFTER: 'Sonra', OTHER: 'Diğer' },
  kinds: { INSTALLATION: 'Kurulum', SAV: 'Servis / Arıza', MAINTENANCE: 'Bakım', OTHER: 'Diğer' },
  outcomes: { DONE: 'Tamamlandı / onarıldı', TEMPORARY: 'Geçici çözüm', TO_RESUME: 'Yeniden ele alınacak', WAITING_PARTS: 'Parça bekleniyor', QUOTE_NEEDED: 'Teklif hazırlanacak' },
  slipTitle: 'ÇIKIŞ FİŞİ', from: 'Çıkış yeri', to: 'Hedef', given: 'Teslim eden', received: 'Teslim alan', signHint: 'Ad, tarih ve imza',
  laborLine: 'İşçilik', travelLine: 'Yol ücreti', flat: 'sabit',
  jobTitle: (n, r) => `İş emri ${n} – ${r}`, contractTitle: (n, t) => `Bakım sözleşmesi ${n} – ${t}`, period: (a, b) => `Dönem: ${a} – ${b}`,
  contracts: (n) => `Sözleşmeler ve abonelikler (${n})`,
  subscriptionTitle: (n, t) => `Abonelik ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Teklif ${o.number}`, text: `Merhaba,\n\n${o.number} numaralı teklifimiz ekte: ${o.title}.\n\nSaygılarımızla,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'İade faturası' : 'Fatura'} ${o.number}`,
    text: `Merhaba,\n\n${o.number} numaralı ${o.credit ? 'iade faturamız' : 'faturamız'} ekte.${o.due ? `\nSon ödeme tarihi: ${o.due}.` : ''}\n\nSaygılarımızla,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Hatırlatma', 'İkinci hatırlatma', 'İhtarname'][o.level - 1]} – fatura ${o.number}`,
    text: `Merhaba,\n\n${[
      `Yanılmıyorsak, son ödeme tarihi ${o.due} olan ${o.number} numaralı fatura hâlâ ödenmedi: ${o.remaining}. Ödemenizi zaten yaptıysanız bu mesajı dikkate almayınız.`,
      `Önceki hatırlatmamıza rağmen, son ödeme tarihi ${o.due} olan ${o.number} numaralı fatura hâlâ ödenmedi (kalan tutar: ${o.remaining}). Lütfen ödemeyi en kısa sürede yapın veya bir sorun varsa bizimle iletişime geçin.`,
      `Hatırlatmalarımıza rağmen, son ödeme tarihi ${o.due} olan ${o.number} numaralı fatura ${o.remaining} tutarında ödenmemiş durumda. Faturayı 8 gün içinde ödemenizi resmen talep ediyoruz. Aksi takdirde genel koşullarımızda öngörülen tahsilat işlemlerini başlatacağız.`,
    ][o.level - 1]}\nFatura bu mesaja eklenmiştir.\n\nSaygılarımızla,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Servis raporu ${o.number}`, text: `Merhaba,\n\nZiyaretimizin raporu (${o.number}) ekte.\n\nSaygılarımızla,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Müşteri alanınız`,
    text: `Merhaba ${o.name},\n\n${o.company}, ${o.client} için sizi müşteri alanına davet ediyor. İş emirlerinizi takip edebilir, imzalı raporları ve faturaları indirebilir, tekliflere yanıt verebilir ve iş emri talep edebilirsiniz.\n\nŞifrenizi belirlemek için bu bağlantıyı açın (7 gün geçerli):\n${o.link}\n\nSaygılarımızla,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Yeni şifre`,
    text: `Merhaba ${o.name},\n\nMüşteri alanınız için yeni bir şifre belirlemek üzere bu bağlantıyı açın (1 saat geçerli, tek kullanımlık):\n${o.link}\n\nBu isteği siz yapmadıysanız bu e-postayı yok sayın.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – ${o.number} numaralı talep alındı`,
    text: `Merhaba ${o.name},\n\n${o.number} numaralı talebinizi aldık:\n«${o.reason}»\n\nRandevuyu belirlemek için sizinle iletişime geçeceğiz. Talebinizi müşteri alanınızdan takip edebilirsiniz.\n\nSaygılarımızla,\n${o.company}`,
  }),
};

const ru: DocTexts = {
  quote: 'СМЕТА', invoice: 'СЧЁТ', creditNote: 'КРЕДИТ-НОТА', draft: 'ЧЕРНОВИК',
  number: '№', date: 'Дата', validUntil: 'Действительна до', serviceDate: 'Дата оказания услуги', dueDate: 'Срок оплаты',
  client: 'Клиент', site: 'Место работ',
  description: 'Наименование', qty: 'Кол-во', unit: 'Ед.', unitPrice: 'Цена без НДС', vat: 'НДС', lineTotal: 'Сумма без НДС',
  net: 'Итого без НДС', vatOn: (r, b) => `НДС ${r} с ${b}`, gross: 'Итого с НДС', paid: 'Уже оплачено', due: 'Остаток к оплате',
  contract: (f) => `Договор на обслуживание: ${f === 12 ? 'один визит в год' : `один визит раз в ${f} мес.`}.`,
  notes: 'Условия', acceptance: 'Согласовано', acceptanceHint: 'Дата, имя и подпись клиента',
  payment: 'Оплата', paymentBy: (d) => `Оплатить не позднее ${d}.`, bank: 'Банковские реквизиты',
  latePenaltyFr: 'При просрочке оплаты: пени в размере трёхкратной законной процентной ставки Франции и фиксированная компенсация расходов на взыскание 40 € (для юридических лиц). Скидка за досрочную оплату не предоставляется.',
  latePenalty: 'При просрочке оплаты могут начисляться законные проценты и компенсация расходов на взыскание.',
  credits: (n) => `Кредит-нота к счёту ${n}.`, vatNumber: 'ИНН', page: 'Стр.',
  reportTitle: 'АКТ ВЫПОЛНЕННЫХ РАБОТ', intervention: 'Заявка', type: 'Тип', technician: 'Техник', arrival: 'Прибытие', departure: 'Отъезд',
  reason: 'Причина', parts: 'Запчасти и материалы', reference: 'Артикул', time: 'Затраченное время и результат', labor: 'Работа', travel: 'Дорога', outcome: 'Результат',
  signatures: 'Подписи', techSign: 'Подпись техника', clientSign: 'Подпись клиента', absent: 'Клиент отсутствует', yes: 'Да', no: 'Нет',
  reportAcceptance: 'Подпись клиента подтверждает выполнение описанных выше работ.', min: 'мин', photos: 'Фото',
  photoKinds: { BEFORE: 'До', AFTER: 'После', OTHER: 'Другое' },
  kinds: { INSTALLATION: 'Монтаж', SAV: 'Сервис / Неисправность', MAINTENANCE: 'Обслуживание', OTHER: 'Другое' },
  outcomes: { DONE: 'Выполнено / отремонтировано', TEMPORARY: 'Временное решение', TO_RESUME: 'Требует доработки', WAITING_PARTS: 'Ожидание запчастей', QUOTE_NEEDED: 'Нужна смета' },
  slipTitle: 'РАСХОДНАЯ НАКЛАДНАЯ', from: 'Откуда', to: 'Куда', given: 'Выдал', received: 'Получил', signHint: 'Имя, дата и подпись',
  laborLine: 'Работа', travelLine: 'Выезд', flat: 'фикс.',
  jobTitle: (n, r) => `Заявка ${n} – ${r}`, contractTitle: (n, t) => `Договор на обслуживание ${n} – ${t}`, period: (a, b) => `Период с ${a} по ${b}`,
  contracts: (n) => `Договоры и абонементы (${n})`,
  subscriptionTitle: (n, t) => `Абонемент ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – Смета ${o.number}`, text: `Здравствуйте!\n\nНаправляем вам смету ${o.number}: ${o.title}.\n\nС уважением,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'Кредит-нота' : 'Счёт'} ${o.number}`,
    text: `Здравствуйте!\n\nНаправляем вам ${o.credit ? 'кредит-ноту' : 'счёт'} ${o.number}.${o.due ? `\nСрок оплаты: ${o.due}.` : ''}\n\nС уважением,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['Напоминание', 'Повторное напоминание', 'Претензия об оплате'][o.level - 1]} – счёт ${o.number}`,
    text: `Здравствуйте!\n\n${[
      `Если мы не ошибаемся, счёт ${o.number} со сроком оплаты ${o.due} ещё не оплачен: ${o.remaining}. Если вы уже произвели оплату, просим не обращать внимания на это сообщение.`,
      `Несмотря на наше предыдущее напоминание, счёт ${o.number} со сроком оплаты ${o.due} до сих пор не оплачен (остаток к оплате: ${o.remaining}). Просим оплатить его как можно скорее или связаться с нами, если возникли трудности.`,
      `Несмотря на наши напоминания, счёт ${o.number} со сроком оплаты ${o.due} остаётся неоплаченным на сумму ${o.remaining}. Требуем оплатить его в течение 8 дней. В противном случае мы начнём взыскание в порядке, предусмотренном нашими общими условиями.`,
    ][o.level - 1]}\nСчёт приложен к этому сообщению.\n\nС уважением,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – Акт выполненных работ ${o.number}`, text: `Здравствуйте!\n\nНаправляем вам акт по нашему выезду (${o.number}).\n\nС уважением,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – Ваш личный кабинет`,
    text: `Здравствуйте, ${o.name}!\n\n${o.company} приглашает вас в личный кабинет клиента ${o.client}. В нём можно следить за заявками, скачивать подписанные акты и счета, отвечать на сметы и оставлять заявки.\n\nЧтобы задать пароль, откройте ссылку (действует 7 дней):\n${o.link}\n\nС уважением,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – Новый пароль`,
    text: `Здравствуйте, ${o.name}!\n\nЧтобы задать новый пароль для личного кабинета, откройте ссылку (действует 1 час, одноразовая):\n${o.link}\n\nЕсли вы этого не запрашивали, просто проигнорируйте письмо.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – Заявка ${o.number} получена`,
    text: `Здравствуйте, ${o.name}!\n\nМы получили вашу заявку ${o.number}:\n«${o.reason}»\n\nМы свяжемся с вами, чтобы согласовать визит. Следить за заявкой можно в личном кабинете.\n\nС уважением,\n${o.company}`,
  }),
};

const ar: DocTexts = {
  quote: 'عرض سعر', invoice: 'فاتورة', creditNote: 'إشعار دائن', draft: 'مسودة',
  number: 'رقم', date: 'التاريخ', validUntil: 'صالح حتى', serviceDate: 'تاريخ الخدمة', dueDate: 'تاريخ الاستحقاق',
  client: 'العميل', site: 'مكان التدخل',
  description: 'الوصف', qty: 'الكمية', unit: 'الوحدة', unitPrice: 'سعر الوحدة', vat: 'الضريبة', lineTotal: 'دون ضريبة',
  net: 'المجموع دون ضريبة', vatOn: (r, b) => `ضريبة ${r} على ${b}`, gross: 'المجموع شامل الضريبة', paid: 'المدفوع', due: 'المتبقي للدفع',
  contract: (f) => `عقد صيانة: ${f === 12 ? 'زيارة واحدة في السنة' : `زيارة كل ${f} أشهر`}.`,
  notes: 'الشروط', acceptance: 'موافق', acceptanceHint: 'التاريخ واسم العميل وتوقيعه',
  payment: 'الدفع', paymentBy: (d) => `يُدفع في موعد أقصاه ${d}.`, bank: 'البيانات البنكية',
  latePenaltyFr: 'في حال التأخر في الدفع: غرامات بثلاثة أضعاف سعر الفائدة القانوني الفرنسي وتعويض جزافي قدره 40 يورو عن مصاريف التحصيل (للعملاء المهنيين). لا خصم على الدفع المبكر.',
  latePenalty: 'قد يترتب على التأخر في الدفع فوائد قانونية وتعويض عن مصاريف التحصيل.',
  credits: (n) => `إشعار دائن على الفاتورة ${n}.`, vatNumber: 'الرقم الضريبي', page: 'صفحة',
  reportTitle: 'تقرير التدخل', intervention: 'التدخل', type: 'النوع', technician: 'الفني', arrival: 'الوصول', departure: 'المغادرة',
  reason: 'السبب', parts: 'القطع واللوازم', reference: 'المرجع', time: 'المدة والنتيجة', labor: 'اليد العاملة', travel: 'التنقل', outcome: 'النتيجة',
  signatures: 'التوقيعات', techSign: 'توقيع الفني', clientSign: 'توقيع العميل', absent: 'العميل غائب', yes: 'نعم', no: 'لا',
  reportAcceptance: 'توقيع العميل إقرار بتنفيذ الأعمال الموصوفة أعلاه.', min: 'دقيقة', photos: 'الصور',
  photoKinds: { BEFORE: 'قبل', AFTER: 'بعد', OTHER: 'أخرى' },
  kinds: { INSTALLATION: 'تركيب', SAV: 'خدمة ما بعد البيع / عطل', MAINTENANCE: 'صيانة', OTHER: 'أخرى' },
  outcomes: { DONE: 'منتهٍ / تم الإصلاح', TEMPORARY: 'حل مؤقت', TO_RESUME: 'تحتاج متابعة', WAITING_PARTS: 'بانتظار قطع الغيار', QUOTE_NEEDED: 'يلزم عرض سعر' },
  slipTitle: 'إذن صرف', from: 'صرف من', to: 'الوجهة', given: 'سلّمه', received: 'استلمه', signHint: 'الاسم والتاريخ والتوقيع',
  laborLine: 'اليد العاملة', travelLine: 'رسوم التنقل', flat: 'جزافي',
  jobTitle: (n, r) => `التدخل ${n} – ${r}`, contractTitle: (n, t) => `عقد صيانة ${n} – ${t}`, period: (a, b) => `الفترة من ${a} إلى ${b}`,
  contracts: (n) => `العقود والاشتراكات (${n})`,
  subscriptionTitle: (n, t) => `اشتراك ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – عرض سعر ${o.number}`, text: `مرحبًا،\n\nتجدون مرفقًا عرض السعر ${o.number}: ${o.title}.\n\nمع خالص التحية،\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'إشعار دائن' : 'فاتورة'} ${o.number}`,
    text: `مرحبًا،\n\nتجدون مرفقًا ${o.credit ? 'إشعار الدائن' : 'الفاتورة'} ${o.number}.${o.due ? `\nتاريخ استحقاق الدفع: ${o.due}.` : ''}\n\nمع خالص التحية،\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['تذكير', 'تذكير ثانٍ', 'إنذار بالدفع'][o.level - 1]} – الفاتورة ${o.number}`,
    text: `مرحبًا،\n\n${[
      `ما لم نكن مخطئين، لا تزال الفاتورة ${o.number} المستحقة في ${o.due} غير مسددة: ${o.remaining}. إذا كنتم قد سددتم المبلغ بالفعل، يُرجى تجاهل هذه الرسالة.`,
      `رغم تذكيرنا السابق، لم تُسدَّد الفاتورة ${o.number} المستحقة في ${o.due} حتى الآن (المبلغ المتبقي: ${o.remaining}). يُرجى السداد فور الاستلام أو التواصل معنا في حال وجود أي صعوبة.`,
      `رغم تذكيراتنا، لا تزال الفاتورة ${o.number} المستحقة في ${o.due} غير مسددة بمبلغ ${o.remaining}. نطالبكم رسميًا بسدادها خلال 8 أيام. وإلا فسنباشر إجراءات التحصيل المنصوص عليها في شروطنا العامة.`,
    ][o.level - 1]}\nالفاتورة مرفقة بهذه الرسالة.\n\nمع خالص التحية،\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – تقرير التدخل ${o.number}`, text: `مرحبًا،\n\nتجدون مرفقًا تقرير تدخلنا (${o.number}).\n\nمع خالص التحية،\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – فضاء العميل الخاص بكم`,
    text: `مرحبًا ${o.name}،\n\nتدعوكم ${o.company} إلى فضاء العميل الخاص بـ ${o.client}. يمكنكم فيه متابعة التدخلات وتحميل التقارير الموقعة والفواتير والرد على عروض الأسعار وطلب تدخل.\n\nلاختيار كلمة المرور، افتحوا هذا الرابط (صالح لمدة 7 أيام):\n${o.link}\n\nمع خالص التحية،\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – كلمة مرور جديدة`,
    text: `مرحبًا ${o.name}،\n\nلاختيار كلمة مرور جديدة لفضاء العميل، افتحوا هذا الرابط (صالح لمدة ساعة، لمرة واحدة):\n${o.link}\n\nإذا لم تطلبوا ذلك، تجاهلوا هذه الرسالة.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – تم استلام الطلب ${o.number}`,
    text: `مرحبًا ${o.name}،\n\nاستلمنا طلبكم ${o.number}:\n«${o.reason}»\n\nسنتصل بكم لتحديد الموعد. يمكنكم متابعته في فضاء العميل.\n\nمع خالص التحية،\n${o.company}`,
  }),
};

const hi: DocTexts = {
  quote: 'कोटेशन', invoice: 'इनवॉइस', creditNote: 'क्रेडिट नोट', draft: 'ड्राफ़्ट',
  number: 'सं.', date: 'तारीख़', validUntil: 'तक मान्य', serviceDate: 'सेवा की तारीख़', dueDate: 'देय तिथि',
  client: 'ग्राहक', site: 'काम का स्थान',
  description: 'विवरण', qty: 'मात्रा', unit: 'इकाई', unitPrice: 'इकाई मूल्य', vat: 'कर', lineTotal: 'कर रहित',
  net: 'कुल (कर रहित)', vatOn: (r, b) => `${b} पर कर ${r}`, gross: 'कुल (कर सहित)', paid: 'पहले से भुगतान', due: 'देय शेष',
  contract: (f) => `रखरखाव अनुबंध: ${f === 12 ? 'साल में एक विज़िट' : `हर ${f} महीने में एक विज़िट`}।`,
  notes: 'शर्तें', acceptance: 'स्वीकृत', acceptanceHint: 'ग्राहक की तारीख़, नाम और हस्ताक्षर',
  payment: 'भुगतान', paymentBy: (d) => `${d} तक भुगतान करें।`, bank: 'बैंक विवरण',
  latePenaltyFr: 'भुगतान में देरी पर: फ़्रांस की वैधानिक ब्याज दर का तीन गुना दंड, और वसूली ख़र्च के लिए 40 € की निश्चित राशि (व्यावसायिक ग्राहक)। जल्दी भुगतान पर कोई छूट नहीं।',
  latePenalty: 'भुगतान में देरी पर वैधानिक ब्याज और वसूली शुल्क लग सकता है।',
  credits: (n) => `इनवॉइस ${n} पर क्रेडिट नोट।`, vatNumber: 'कर संख्या', page: 'पेज',
  reportTitle: 'काम रिपोर्ट', intervention: 'काम', type: 'प्रकार', technician: 'तकनीशियन', arrival: 'पहुँच', departure: 'प्रस्थान',
  reason: 'कारण', parts: 'पुर्ज़े और सामग्री', reference: 'संदर्भ', time: 'लगा समय और परिणाम', labor: 'श्रम', travel: 'यात्रा', outcome: 'परिणाम',
  signatures: 'हस्ताक्षर', techSign: 'तकनीशियन के हस्ताक्षर', clientSign: 'ग्राहक के हस्ताक्षर', absent: 'ग्राहक अनुपस्थित', yes: 'हाँ', no: 'नहीं',
  reportAcceptance: 'ग्राहक के हस्ताक्षर ऊपर वर्णित कार्य पूरा होने की पुष्टि करते हैं।', min: 'मिनट', photos: 'फ़ोटो',
  photoKinds: { BEFORE: 'पहले', AFTER: 'बाद में', OTHER: 'अन्य' },
  kinds: { INSTALLATION: 'इंस्टॉलेशन', SAV: 'सर्विस / खराबी', MAINTENANCE: 'रखरखाव', OTHER: 'अन्य' },
  outcomes: { DONE: 'पूरा / मरम्मत हो गई', TEMPORARY: 'अस्थायी समाधान', TO_RESUME: 'दोबारा करना है', WAITING_PARTS: 'पुर्ज़ों की प्रतीक्षा', QUOTE_NEEDED: 'कोटेशन बनाना है' },
  slipTitle: 'जारी पर्ची', from: 'से जारी', to: 'गंतव्य', given: 'सौंपने वाला', received: 'प्राप्त करने वाला', signHint: 'नाम, तारीख़ और हस्ताक्षर',
  laborLine: 'श्रम', travelLine: 'आने-जाने का शुल्क', flat: 'निश्चित',
  jobTitle: (n, r) => `काम ${n} – ${r}`, contractTitle: (n, t) => `रखरखाव अनुबंध ${n} – ${t}`, period: (a, b) => `अवधि ${a} से ${b}`,
  contracts: (n) => `अनुबंध और सदस्यताएँ (${n})`,
  subscriptionTitle: (n, t) => `सदस्यता ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – कोटेशन ${o.number}`, text: `नमस्ते,\n\nहमारा कोटेशन ${o.number} संलग्न है: ${o.title}।\n\nसादर,\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? 'क्रेडिट नोट' : 'इनवॉइस'} ${o.number}`,
    text: `नमस्ते,\n\nहमारा ${o.credit ? 'क्रेडिट नोट' : 'इनवॉइस'} ${o.number} संलग्न है।${o.due ? `\nभुगतान की देय तिथि: ${o.due}।` : ''}\n\nसादर,\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['अनुस्मारक', 'दूसरा अनुस्मारक', 'भुगतान हेतु अंतिम सूचना'][o.level - 1]} – इनवॉइस ${o.number}`,
    text: `नमस्ते,\n\n${[
      `हमारी जानकारी के अनुसार, ${o.due} को देय इनवॉइस ${o.number} का भुगतान अभी बाकी है: ${o.remaining}। यदि आप भुगतान कर चुके हैं, तो कृपया इस संदेश को अनदेखा करें।`,
      `हमारे पिछले अनुस्मारक के बावजूद, ${o.due} को देय इनवॉइस ${o.number} का भुगतान अभी तक नहीं हुआ है (बकाया राशि: ${o.remaining})। कृपया शीघ्र भुगतान करें, या कोई समस्या हो तो हमसे संपर्क करें।`,
      `हमारे अनुस्मारकों के बावजूद, ${o.due} को देय इनवॉइस ${o.number} की ${o.remaining} की राशि अभी भी बकाया है। हम आपसे 8 दिनों के भीतर भुगतान करने का औपचारिक अनुरोध करते हैं। अन्यथा हम अपनी सामान्य शर्तों में बताई गई वसूली प्रक्रिया शुरू करेंगे।`,
    ][o.level - 1]}\nइनवॉइस इस संदेश के साथ संलग्न है।\n\nसादर,\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – काम रिपोर्ट ${o.number}`, text: `नमस्ते,\n\nहमारी विज़िट (${o.number}) की रिपोर्ट संलग्न है।\n\nसादर,\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – आपका ग्राहक क्षेत्र`,
    text: `नमस्ते ${o.name},\n\n${o.company} आपको ${o.client} के ग्राहक क्षेत्र में आमंत्रित करता है। वहाँ आप अपने काम देख सकते हैं, हस्ताक्षरित रिपोर्ट और इनवॉइस डाउनलोड कर सकते हैं, कोटेशन का उत्तर दे सकते हैं और काम का अनुरोध कर सकते हैं।\n\nअपना पासवर्ड चुनने के लिए यह लिंक खोलें (7 दिन मान्य):\n${o.link}\n\nसादर,\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – नया पासवर्ड`,
    text: `नमस्ते ${o.name},\n\nअपने ग्राहक क्षेत्र का नया पासवर्ड चुनने के लिए यह लिंक खोलें (1 घंटे के लिए मान्य, केवल एक बार):\n${o.link}\n\nअगर आपने यह अनुरोध नहीं किया, तो इस ई-मेल को अनदेखा करें।\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – अनुरोध ${o.number} प्राप्त हुआ`,
    text: `नमस्ते ${o.name},\n\nहमें आपका अनुरोध ${o.number} मिल गया है:\n«${o.reason}»\n\nअपॉइंटमेंट तय करने के लिए हम आपसे संपर्क करेंगे। आप इसे अपने ग्राहक क्षेत्र में देख सकते हैं।\n\nसादर,\n${o.company}`,
  }),
};

const zh: DocTexts = {
  quote: '报价单', invoice: '发票', creditNote: '红字发票', draft: '草稿',
  number: '编号', date: '日期', validUntil: '有效期至', serviceDate: '服务日期', dueDate: '付款期限',
  client: '客户', site: '工单地点',
  description: '名称', qty: '数量', unit: '单位', unitPrice: '不含税单价', vat: '税率', lineTotal: '不含税金额',
  net: '不含税合计', vatOn: (r, b) => `${b} 的增值税 ${r}`, gross: '含税合计', paid: '已付', due: '应付余额',
  contract: (f) => `保养合同：${f === 12 ? '每年上门一次' : `每 ${f} 个月上门一次`}。`,
  notes: '条款', acceptance: '同意', acceptanceHint: '客户签署日期、姓名及签名',
  payment: '付款', paymentBy: (d) => `请于 ${d} 前付款。`, bank: '银行信息',
  latePenaltyFr: '逾期付款：按法国法定利率的三倍计收罚金，并收取 40 欧元固定催收费用（企业客户）。提前付款不享受折扣。',
  latePenalty: '逾期付款可能产生法定利息及催收费用。',
  credits: (n) => `对应发票 ${n} 的红字发票。`, vatNumber: '税号', page: '页',
  reportTitle: '工单报告', intervention: '工单', type: '类型', technician: '技术员', arrival: '到达', departure: '离开',
  reason: '原因', parts: '配件与耗材', reference: '编码', time: '工时与结果', labor: '人工', travel: '路程', outcome: '结果',
  signatures: '签名', techSign: '技术员签名', clientSign: '客户签名', absent: '客户不在场', yes: '是', no: '否',
  reportAcceptance: '客户签名即确认已完成上述工作。', min: '分钟', photos: '照片',
  photoKinds: { BEFORE: '之前', AFTER: '之后', OTHER: '其他' },
  kinds: { INSTALLATION: '安装', SAV: '售后 / 故障', MAINTENANCE: '保养', OTHER: '其他' },
  outcomes: { DONE: '已完成 / 已修复', TEMPORARY: '临时解决', TO_RESUME: '待跟进', WAITING_PARTS: '等待配件', QUOTE_NEEDED: '需出报价' },
  slipTitle: '出库单', from: '出库地点', to: '目的地', given: '发货人', received: '收货人', signHint: '姓名、日期及签名',
  laborLine: '人工', travelLine: '上门费', flat: '固定',
  jobTitle: (n, r) => `工单 ${n} – ${r}`, contractTitle: (n, t) => `保养合同 ${n} – ${t}`, period: (a, b) => `期间：${a} 至 ${b}`,
  contracts: (n) => `合同与订阅（${n}）`,
  subscriptionTitle: (n, t) => `订阅 ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – 报价单 ${o.number}`, text: `您好：\n\n附件为我们的报价单 ${o.number}：${o.title}。\n\n此致\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? '红字发票' : '发票'} ${o.number}`,
    text: `您好：\n\n附件为我们的${o.credit ? '红字发票' : '发票'} ${o.number}。${o.due ? `\n付款期限：${o.due}。` : ''}\n\n此致\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['付款提醒', '再次提醒', '催款通知'][o.level - 1]} – 发票 ${o.number}`,
    text: `您好：\n\n${[
      `如无差错，发票 ${o.number}（到期日 ${o.due}）尚未付清：${o.remaining}。如您已付款，请忽略本邮件。`,
      `尽管我们此前已发出提醒，发票 ${o.number}（到期日 ${o.due}）仍未支付（未付金额：${o.remaining}）。请尽快付款；如有困难，请与我们联系。`,
      `尽管我们多次提醒，发票 ${o.number}（到期日 ${o.due}）仍有 ${o.remaining} 未支付。现正式要求您在 8 天内付清。否则，我们将按照通用条款启动催收程序。`,
    ][o.level - 1]}\n发票已附在本邮件中。\n\n此致\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – 工单报告 ${o.number}`, text: `您好：\n\n附件为本次上门服务的报告（${o.number}）。\n\n此致\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – 您的客户空间`,
    text: `${o.name} 您好：\n\n${o.company} 邀请您使用 ${o.client} 的客户空间。您可以在其中查看工单、下载已签署的报告和发票、回复报价并申请上门服务。\n\n请打开以下链接设置密码（7 天内有效）：\n${o.link}\n\n此致\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – 设置新密码`,
    text: `${o.name} 您好：\n\n请打开以下链接为客户空间设置新密码（1 小时内有效，仅可使用一次）：\n${o.link}\n\n如果这不是您本人的操作，请忽略此邮件。\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – 已收到申请 ${o.number}`,
    text: `${o.name} 您好：\n\n我们已收到您的申请 ${o.number}：\n“${o.reason}”\n\n我们会联系您确定上门时间。您可以在客户空间中查看进度。\n\n此致\n${o.company}`,
  }),
};

const ja: DocTexts = {
  quote: '見積書', invoice: '請求書', creditNote: '赤伝（返金伝票）', draft: '下書き',
  number: '番号', date: '日付', validUntil: '有効期限', serviceDate: '作業日', dueDate: '支払期限',
  client: 'お客様', site: '作業場所',
  description: '品名', qty: '数量', unit: '単位', unitPrice: '税抜単価', vat: '税率', lineTotal: '税抜金額',
  net: '税抜合計', vatOn: (r, b) => `${b} に対する消費税 ${r}`, gross: '税込合計', paid: '入金済み', due: '残額',
  contract: (f) => `保守契約：${f === 12 ? '年 1 回の訪問' : `${f} か月ごとに 1 回の訪問`}。`,
  notes: '条件', acceptance: '承諾', acceptanceHint: 'お客様の日付・お名前・署名',
  payment: 'お支払い', paymentBy: (d) => `${d} までにお支払いください。`, bank: '振込先',
  latePenaltyFr: '支払遅延の場合：フランス法定利率の 3 倍の遅延損害金と、回収費用として定額 40 ユーロ（法人のお客様）を申し受けます。早期支払いによる割引はありません。',
  latePenalty: '支払いが遅れた場合、法定利息および回収費用を請求することがあります。',
  credits: (n) => `請求書 ${n} に対する赤伝。`, vatNumber: '登録番号', page: 'ページ',
  reportTitle: '作業報告書', intervention: '作業', type: '種類', technician: '技術者', arrival: '到着', departure: '出発',
  reason: '理由', parts: '部品・資材', reference: '品番', time: '作業時間と結果', labor: '作業', travel: '移動', outcome: '結果',
  signatures: '署名', techSign: '技術者の署名', clientSign: 'お客様の署名', absent: 'お客様不在', yes: 'はい', no: 'いいえ',
  reportAcceptance: 'お客様の署名により、上記の作業が実施されたことを確認します。', min: '分', photos: '写真',
  photoKinds: { BEFORE: '作業前', AFTER: '作業後', OTHER: 'その他' },
  kinds: { INSTALLATION: '設置', SAV: 'アフターサービス / 故障', MAINTENANCE: '保守点検', OTHER: 'その他' },
  outcomes: { DONE: '完了 / 修理済み', TEMPORARY: '応急処置', TO_RESUME: '再対応が必要', WAITING_PARTS: '部品待ち', QUOTE_NEEDED: '見積もりが必要' },
  slipTitle: '出庫伝票', from: '出庫元', to: '出庫先', given: '引渡者', received: '受領者', signHint: '氏名・日付・署名',
  laborLine: '作業料', travelLine: '出張費', flat: '一式',
  jobTitle: (n, r) => `作業 ${n} – ${r}`, contractTitle: (n, t) => `保守契約 ${n} – ${t}`, period: (a, b) => `期間：${a}〜${b}`,
  contracts: (n) => `契約・定期サービス（${n}）`,
  subscriptionTitle: (n, t) => `定期サービス ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – 見積書 ${o.number}`, text: `お世話になっております。\n\n見積書 ${o.number}（${o.title}）を添付いたします。\n\nよろしくお願いいたします。\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? '赤伝' : '請求書'} ${o.number}`,
    text: `お世話になっております。\n\n${o.credit ? '赤伝' : '請求書'} ${o.number} を添付いたします。${o.due ? `\nお支払期限：${o.due}` : ''}\n\nよろしくお願いいたします。\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['お支払いのお願い', '再度のお願い', '督促状'][o.level - 1]} – 請求書 ${o.number}`,
    text: `お世話になっております。\n\n${[
      `お支払期限 ${o.due} の請求書 ${o.number}（${o.remaining}）のご入金がまだ確認できておりません。既にお振込みいただいている場合は、本メールを破棄してください。`,
      `先日ご連絡いたしましたが、お支払期限 ${o.due} の請求書 ${o.number} のご入金がまだ確認できておりません（未払額：${o.remaining}）。至急お支払いいただくか、ご事情がある場合はご連絡ください。`,
      `再三のお願いにもかかわらず、お支払期限 ${o.due} の請求書 ${o.number}（${o.remaining}）が未払いとなっております。8日以内にお支払いくださいますよう、正式にお願い申し上げます。期限までにお支払いがない場合は、当社の約款に基づき回収手続きを開始いたします。`,
    ][o.level - 1]}\n請求書を添付しております。\n\nよろしくお願いいたします。\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – 作業報告書 ${o.number}`, text: `お世話になっております。\n\n今回の作業（${o.number}）の報告書を添付いたします。\n\nよろしくお願いいたします。\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – お客様ページのご案内`,
    text: `${o.name} 様\n\n${o.company} より、${o.client} のお客様ページへご招待いたします。作業状況の確認、署名済み報告書・請求書のダウンロード、見積もりへのご回答、作業のご依頼ができます。\n\n以下のリンクからパスワードを設定してください（有効期間 7 日）：\n${o.link}\n\nよろしくお願いいたします。\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – パスワードの再設定`,
    text: `${o.name} 様\n\nお客様ページの新しいパスワードを設定するには、以下のリンクを開いてください（有効期間 1 時間、1 回のみ）：\n${o.link}\n\nお心当たりがない場合は、このメールを無視してください。\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – ご依頼 ${o.number} を受け付けました`,
    text: `${o.name} 様\n\nご依頼 ${o.number} を受け付けました：\n「${o.reason}」\n\n訪問日時の調整のためご連絡いたします。進捗はお客様ページでご確認いただけます。\n\nよろしくお願いいたします。\n${o.company}`,
  }),
};

const ko: DocTexts = {
  quote: '견적서', invoice: '청구서', creditNote: '취소 청구서', draft: '초안',
  number: '번호', date: '날짜', validUntil: '유효 기한', serviceDate: '서비스 제공일', dueDate: '결제 기한',
  client: '고객', site: '작업 장소',
  description: '품명', qty: '수량', unit: '단위', unitPrice: '단가(부가세 별도)', vat: '부가세', lineTotal: '공급가액',
  net: '공급가액 합계', vatOn: (r, b) => `${b}에 대한 부가세 ${r}`, gross: '합계(부가세 포함)', paid: '결제 완료', due: '남은 금액',
  contract: (f) => `유지보수 계약: ${f === 12 ? '연 1회 방문' : `${f}개월마다 1회 방문`}.`,
  notes: '조건', acceptance: '승인', acceptanceHint: '고객의 날짜, 이름 및 서명',
  payment: '결제', paymentBy: (d) => `${d}까지 결제해 주세요.`, bank: '입금 계좌',
  latePenaltyFr: '결제 지연 시: 프랑스 법정 이율의 3배에 해당하는 지연 이자와 추심 비용 40유로(사업자 고객)가 부과됩니다. 조기 결제 할인은 없습니다.',
  latePenalty: '결제가 지연되면 법정 이자와 추심 비용이 부과될 수 있습니다.',
  credits: (n) => `청구서 ${n}에 대한 취소 청구서.`, vatNumber: '사업자등록번호', page: '페이지',
  reportTitle: '작업 보고서', intervention: '작업', type: '유형', technician: '기술자', arrival: '도착', departure: '출발',
  reason: '사유', parts: '부품 및 자재', reference: '품번', time: '작업 시간 및 결과', labor: '작업', travel: '이동', outcome: '결과',
  signatures: '서명', techSign: '기술자 서명', clientSign: '고객 서명', absent: '고객 부재', yes: '예', no: '아니요',
  reportAcceptance: '고객의 서명은 위에 기재된 작업이 완료되었음을 확인합니다.', min: '분', photos: '사진',
  photoKinds: { BEFORE: '작업 전', AFTER: '작업 후', OTHER: '기타' },
  kinds: { INSTALLATION: '설치', SAV: 'A/S / 고장', MAINTENANCE: '정기 점검', OTHER: '기타' },
  outcomes: { DONE: '완료 / 수리됨', TEMPORARY: '임시 조치', TO_RESUME: '재방문 필요', WAITING_PARTS: '부품 대기', QUOTE_NEEDED: '견적 필요' },
  slipTitle: '출고 전표', from: '출고지', to: '도착지', given: '인계자', received: '인수자', signHint: '이름, 날짜 및 서명',
  laborLine: '작업비', travelLine: '출장비', flat: '정액',
  jobTitle: (n, r) => `작업 ${n} – ${r}`, contractTitle: (n, t) => `유지보수 계약 ${n} – ${t}`, period: (a, b) => `기간: ${a} ~ ${b}`,
  contracts: (n) => `계약 및 구독(${n})`,
  subscriptionTitle: (n, t) => `구독 ${n} – ${t}`,
  quoteMail: (o) => ({ subject: `${o.company} – 견적서 ${o.number}`, text: `안녕하세요.\n\n견적서 ${o.number}(${o.title})를 첨부합니다.\n\n감사합니다.\n${o.company}` }),
  invoiceMail: (o) => ({
    subject: `${o.company} – ${o.credit ? '취소 청구서' : '청구서'} ${o.number}`,
    text: `안녕하세요.\n\n${o.credit ? '취소 청구서' : '청구서'} ${o.number}를 첨부합니다.${o.due ? `\n결제 기한: ${o.due}` : ''}\n\n감사합니다.\n${o.company}`,
  }),
  reminderMail: (o) => ({
    subject: `${o.company} – ${['결제 안내', '2차 결제 안내', '최종 독촉'][o.level - 1]} – 청구서 ${o.number}`,
    text: `안녕하세요.\n\n${[
      `결제 기한이 ${o.due}인 청구서 ${o.number}의 대금 ${o.remaining}이(가) 아직 결제되지 않았습니다. 이미 결제하셨다면 이 메일은 무시해 주십시오.`,
      `앞서 안내드렸으나 결제 기한이 ${o.due}인 청구서 ${o.number}이(가) 아직 결제되지 않았습니다(미결제 금액: ${o.remaining}). 조속히 결제해 주시거나 문제가 있으면 연락해 주십시오.`,
      `여러 차례 안내에도 불구하고 결제 기한이 ${o.due}인 청구서 ${o.number}의 ${o.remaining}이(가) 미결제 상태입니다. 8일 이내에 결제해 주실 것을 정식으로 요청드립니다. 기한 내 결제가 없을 경우 당사 약관에 따라 추심 절차를 진행합니다.`,
    ][o.level - 1]}\n청구서를 첨부합니다.\n\n감사합니다.\n${o.company}`,
  }),
  reportMail: (o) => ({ subject: `${o.company} – 작업 보고서 ${o.number}`, text: `안녕하세요.\n\n이번 방문(${o.number})의 보고서를 첨부합니다.\n\n감사합니다.\n${o.company} – ${o.agency}` }),
  inviteMail: (o) => ({
    subject: `${o.company} – 고객 공간 안내`,
    text: `${o.name}님, 안녕하세요.\n\n${o.company}에서 ${o.client}의 고객 공간에 초대합니다. 작업 현황 확인, 서명된 보고서와 청구서 다운로드, 견적 회신, 작업 요청을 할 수 있습니다.\n\n아래 링크에서 비밀번호를 설정하세요(7일간 유효):\n${o.link}\n\n감사합니다.\n${o.company}`,
  }),
  resetMail: (o) => ({
    subject: `${o.company} – 새 비밀번호`,
    text: `${o.name}님, 안녕하세요.\n\n고객 공간의 새 비밀번호를 설정하려면 아래 링크를 여세요(1시간 유효, 1회만 사용 가능):\n${o.link}\n\n요청하지 않으셨다면 이 메일을 무시하세요.\n\n${o.company}`,
  }),
  requestMail: (o) => ({
    subject: `${o.company} – 요청 ${o.number} 접수`,
    text: `${o.name}님, 안녕하세요.\n\n요청 ${o.number}을(를) 접수했습니다:\n"${o.reason}"\n\n방문 일정을 정하기 위해 연락드리겠습니다. 고객 공간에서 진행 상황을 확인할 수 있습니다.\n\n감사합니다.\n${o.company}`,
  }),
};

const TEXTS: Record<string, DocTexts> = { fr, en, es, de, it, pt, nl, pl, ro, tr, ru, ar, hi, zh, ja, ko };
export const DOC_LANGS = Object.keys(TEXTS);

/** Langue des documents : "es-ES" → "es" ; une langue sans textes passe à l'anglais (au français pour "fr-…") */
export function docLang(locale: string | null | undefined): string {
  const code = (locale ?? 'fr').slice(0, 2).toLowerCase();
  return TEXTS[code] ? code : 'en';
}

export function docTexts(locale: string | null | undefined): DocTexts {
  return TEXTS[docLang(locale)];
}

/** Langue d'un document destiné à un client : la sienne si elle est choisie, sinon celle de la société */
export function clientLocale(client: { locale?: string | null } | null | undefined, company: { locale: string }): string {
  return client?.locale || company.locale;
}

/** Formats de date et de nombre : pour l'arabe, chiffres latins et calendrier grégorien (Maroc) */
export function formatLocale(locale: string): string {
  return docLang(locale) === 'ar' && !/^ar-(MA|DZ|TN)/i.test(locale) ? 'ar-MA' : locale;
}

/** Date AAAA-MM-JJ écrite en toutes lettres dans la langue du document */
export function longDay(iso: string, locale: string): string {
  return new Intl.DateTimeFormat(formatLocale(locale), { dateStyle: 'long', timeZone: 'UTC' }).format(new Date(`${iso}T00:00:00Z`));
}
