/**
 * Notifications du bureau : intervention terminée ou à reprendre, technicien en retard, demande et réponse aux devis
 * de l'espace client. Destinataires : la personne qui a planifié l'intervention (sinon qui l'a créée) et le chef de
 * l'agence ; pour une demande de client, la planification et le chef de l'agence.
 */
import { and, eq, gt, inArray, isNotNull, isNull, lt, or } from 'drizzle-orm';
import type { Role } from '@itineo/shared';
import { db, schema } from '../db/client.js';
import { notifyLater, notifyUsers } from './notify.js';

const ra = schema.roleAssignments;
const i = schema.interventions;

/** Personnes actives ayant l'un de ces rôles sur l'agence ; à défaut, sur toute la société */
async function peopleOf(agencyId: string | null, companyId: string, roles: Role[]): Promise<string[]> {
  const rows = await db.select({ userId: ra.userId, agencyId: ra.agencyId }).from(ra)
    .innerJoin(schema.users, eq(schema.users.id, ra.userId))
    .where(and(inArray(ra.role, roles), eq(schema.users.active, true),
      agencyId ? or(eq(ra.agencyId, agencyId), and(isNull(ra.agencyId), eq(ra.companyId, companyId))) : and(isNull(ra.agencyId), eq(ra.companyId, companyId))));
  const local = agencyId ? rows.filter((r) => r.agencyId === agencyId).map((r) => r.userId) : [];
  return local.length ? local : rows.map((r) => r.userId);
}

interface IvRef { id: string; number: string; agencyId: string; companyId: string; clientId: string; technicianId: string | null; plannedById: string | null; createdById: string | null; scheduledStart?: Date | null }

/** Qui a planifié (sinon créé) l'intervention, et le chef de l'agence ; jamais la personne qui agit */
export async function officeRecipients(iv: IvRef, exclude?: string | null): Promise<string[]> {
  const chiefs = await peopleOf(iv.agencyId, iv.companyId, ['AGENCY_MANAGER']);
  const author = iv.plannedById ?? iv.createdById;
  return [...new Set([author, ...chiefs].filter((x): x is string => !!x && x !== exclude))];
}

async function names(iv: IvRef) {
  const [row] = await db.select({ client: schema.clients.name, tz: schema.companies.timezone })
    .from(schema.clients).innerJoin(schema.companies, eq(schema.companies.id, iv.companyId)).where(eq(schema.clients.id, iv.clientId));
  const [tech] = iv.technicianId
    ? await db.select({ first: schema.users.firstName, last: schema.users.lastName }).from(schema.users).where(eq(schema.users.id, iv.technicianId))
    : [];
  return { client: row?.client ?? '', tz: row?.tz ?? 'Europe/Paris', tech: tech ? `${tech.first} ${tech.last}` : '' };
}

/** Fiche envoyée : intervention terminée, ou à reprendre (pièces, devis, suite à prévoir) */
export function notifyCompleted(iv: IvRef, followUp: boolean, actorId: string) {
  void (async () => {
    const to = await officeRecipients(iv, actorId);
    if (!to.length) return;
    const n = await names(iv);
    notifyLater(to, followUp ? 'followup' : 'completed', (locale) => {
      const fr = locale.startsWith('fr');
      return {
        title: followUp ? (fr ? 'Intervention à reprendre' : 'Job needs follow-up') : (fr ? 'Intervention terminée' : 'Job completed'),
        body: [iv.number, n.client, n.tech].filter(Boolean).join(' · '),
        url: `/interventions/${iv.id}`, tag: `iv-${iv.id}`,
      };
    });
  })().catch((e) => console.warn('[notify] fin d’intervention', (e as Error).message));
}

/** Retard : toujours « planifiée » 15 minutes après l'heure prévue (le technicien n'est ni parti ni sur place) */
export const LATE_AFTER_MIN = 15;

export async function notifyLateInterventions(now = new Date()): Promise<number> {
  const rows = await db.select().from(i).where(and(
    eq(i.status, 'PLANNED'), isNotNull(i.technicianId), isNull(i.lateNotifiedAt),
    lt(i.scheduledStart, new Date(now.getTime() - LATE_AFTER_MIN * 60_000)),
    // Pas les vieilles interventions oubliées : seulement la journée en cours
    gt(i.scheduledStart, new Date(now.getTime() - 12 * 3600_000)),
  ));
  for (const iv of rows) {
    // Une seule fois par intervention, même si deux serveurs tournaient
    const marked = await db.update(i).set({ lateNotifiedAt: now }).where(and(eq(i.id, iv.id), isNull(i.lateNotifiedAt))).returning({ id: i.id });
    if (!marked.length) continue;
    const to = await officeRecipients(iv);
    if (!to.length) continue;
    const n = await names(iv);
    await notifyUsers(to, 'late', (locale) => {
      const fr = locale.startsWith('fr');
      const time = new Intl.DateTimeFormat(locale, { timeZone: n.tz, hour: '2-digit', minute: '2-digit' }).format(iv.scheduledStart!);
      return {
        title: fr ? `En retard : ${n.tech || 'technicien'}` : `Running late: ${n.tech || 'technician'}`,
        body: fr ? `Prévu à ${time}, pas encore parti · ${n.client} · ${iv.number}` : `Due at ${time}, not on the way yet · ${n.client} · ${iv.number}`,
        url: `/interventions/${iv.id}`, tag: `late-${iv.id}`,
      };
    });
  }
  return rows.length;
}

/** Vérifie les retards toutes les 5 minutes */
export function scheduleLateChecks(log: (msg: string) => void) {
  const run = () => notifyLateInterventions()
    .then((n) => n && log(`${n} intervention(s) en retard signalée(s) au bureau`))
    // La cloche garde 90 jours
    .then(() => db.delete(schema.notifications).where(lt(schema.notifications.createdAt, new Date(Date.now() - 90 * 86400_000))))
    .catch((err) => log(`Vérification des retards impossible : ${(err as Error).message}`));
  const timer = setInterval(run, 5 * 60_000);
  timer.unref();
}

/** Demande d'un client depuis l'espace client : la planification et le chef de l'agence */
export function notifyClientRequest(r: { id: string; number: string; agencyId: string; companyId: string; client: string; reason: string; urgent: boolean }) {
  void (async () => {
    const to = await peopleOf(r.agencyId, r.companyId, ['PLANNER', 'AGENCY_MANAGER']);
    notifyLater(to, 'request', (locale) => {
      const fr = locale.startsWith('fr');
      return {
        title: fr ? `Demande client${r.urgent ? ' URGENTE' : ''} : ${r.client}` : `Customer request${r.urgent ? ' (URGENT)' : ''}: ${r.client}`,
        body: `${r.number} · ${r.reason}`.slice(0, 300),
        url: `/interventions/${r.id}`,
      };
    });
  })().catch((e) => console.warn('[notify] demande client', (e as Error).message));
}

/** Réponse du client à un devis : son auteur et le chef de l'agence */
export function notifyQuoteDecision(q: { id: string; number: string; title: string; agencyId: string | null; companyId: string; createdById: string | null; client: string; accepted: boolean }) {
  void (async () => {
    const chiefs = await peopleOf(q.agencyId, q.companyId, ['AGENCY_MANAGER']);
    const to = [...new Set([q.createdById, ...chiefs].filter((x): x is string => !!x))];
    notifyLater(to, 'quote', (locale) => {
      const fr = locale.startsWith('fr');
      return {
        title: q.accepted ? (fr ? `Devis accepté : ${q.client}` : `Quote accepted: ${q.client}`) : (fr ? `Devis refusé : ${q.client}` : `Quote declined: ${q.client}`),
        body: `${q.number} · ${q.title}`,
        url: `/quotes/${q.id}`,
      };
    });
  })().catch((e) => console.warn('[notify] devis', (e as Error).message));
}
