/**
 * Modèles de fiches fournis pour chaque secteur (sécurité privée, commissaires de justice, expertise,
 * états des lieux, multiservices), en français et en anglais : un par type d'intervention.
 * Ils remplacent les modèles neutres des techniciens pour les sociétés de ce secteur ; chaque société peut
 * ensuite les copier et les adapter depuis l'écran « Modèles de fiches ».
 *
 * Comme pour les modèles neutres, les horaires, le temps passé, les photos et les signatures ne sont pas dans
 * les modèles : ils font partie de toutes les fiches.
 */
import type { FieldType, InterventionKind, Sector, TemplateField, TemplateSchema } from '@itineo/shared';

export type Lang = 'fr' | 'en';
/** Un texte en français et en anglais */
export type Tx = [fr: string, en: string];

export interface FieldDef {
  id: string;
  label: Tx;
  type: FieldType;
  required?: boolean;
  options?: [fr: string[], en: string[]];
  prefill?: string;
  dictation?: boolean;
  help?: Tx;
}
export interface SectionDef { id: string; title: Tx; fields: FieldDef[] }
export interface TemplateDef { kind: InterventionKind; name: Tx; sections: SectionDef[] }

export type Extra = Partial<Pick<FieldDef, 'required' | 'prefill' | 'help' | 'dictation'>>;
export const text = (id: string, label: Tx, x: Extra = {}): FieldDef => ({ id, label, type: 'text', ...x });
export const area = (id: string, label: Tx, x: Extra = {}): FieldDef => ({ id, label, type: 'textarea', dictation: true, ...x });
export const num = (id: string, label: Tx, x: Extra = {}): FieldDef => ({ id, label, type: 'number', ...x });
export const day = (id: string, label: Tx, x: Extra = {}): FieldDef => ({ id, label, type: 'date', ...x });
export const time = (id: string, label: Tx, x: Extra = {}): FieldDef => ({ id, label, type: 'time', ...x });
export const check = (id: string, label: Tx, x: Extra = {}): FieldDef => ({ id, label, type: 'checkbox', ...x });
export const choice = (id: string, label: Tx, fr: string[], en: string[], x: Extra = {}): FieldDef =>
  ({ id, label, type: 'select', options: [fr, en], ...x });
export const list = (id: string, label: Tx, fr: string[], en: string[], x: Extra = {}): FieldDef =>
  ({ id, label, type: 'checklist', options: [fr, en], ...x });

const YES_NO: [string[], string[]] = [['Oui', 'Non'], ['Yes', 'No']];
export const yesNo = (id: string, label: Tx, x: Extra = {}) => choice(id, label, YES_NO[0], YES_NO[1], x);

const observations: SectionDef = {
  id: 'observations',
  title: ['Observations', 'Observations'],
  fields: [area('remarks', ['Observations et recommandations', 'Observations and recommendations'])],
};

// ─── Sécurité privée (Vigie) ─────────────────────────────────────────────

const SECURITY: TemplateDef[] = [
  {
    kind: 'MAINTENANCE',
    name: ['Rapport de ronde', 'Patrol report'],
    sections: [
      {
        id: 'patrol', title: ['Ronde', 'Patrol'], fields: [
          text('siteName', ['Site', 'Site'], { prefill: 'site.name' }),
          list('checkpoints', ['Points contrôlés', 'Items checked'],
            ['Accès et portes fermés', 'Fenêtres et ouvrants fermés', 'Éclairage', 'Système d’alarme en service', 'Issues de secours dégagées', 'Absence de trace d’intrusion'],
            ['Doors and accesses locked', 'Windows closed', 'Lighting', 'Alarm system armed', 'Emergency exits clear', 'No sign of intrusion']),
          choice('anomaly', ['Anomalies constatées', 'Anomalies found'],
            ['Aucune', 'Anomalie mineure', 'Anomalie à signaler au client', 'Intrusion ou effraction'],
            ['None', 'Minor anomaly', 'Anomaly to report to the customer', 'Intrusion or break-in'], { required: true }),
          area('anomalyDetails', ['Détail des anomalies', 'Anomaly details']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'SAV',
    name: ['Rapport de levée de doute', 'Alarm response report'],
    sections: [
      {
        id: 'alarm', title: ['Alarme', 'Alarm'], fields: [
          text('subscriber', ['N° d’abonné', 'Subscriber number'], { prefill: 'client.subscriberNumber' }),
          time('alarmTime', ['Heure de réception de l’alarme', 'Time alarm received']),
          time('arrivalTime', ['Heure d’arrivée sur site', 'Time of arrival on site']),
          choice('alarmType', ['Type d’alarme', 'Alarm type'],
            ['Intrusion', 'Incendie', 'Agression', 'Technique', 'Autoprotection / sabotage'],
            ['Intrusion', 'Fire', 'Panic / assault', 'Technical', 'Tamper'], { required: true }),
        ],
      },
      {
        id: 'verification', title: ['Levée de doute', 'Verification'], fields: [
          choice('result', ['Résultat', 'Result'],
            ['Alarme justifiée (intrusion avérée)', 'Fausse alarme / cause technique', 'Cause indéterminée'],
            ['Genuine alarm (confirmed intrusion)', 'False alarm / technical cause', 'Cause unknown'], { required: true }),
          area('findings', ['Constatations', 'Findings'], { required: true }),
          list('actions', ['Actions menées', 'Actions taken'],
            ['Extérieur du site inspecté', 'Intérieur du site inspecté', 'Responsable prévenu', 'Forces de l’ordre prévenues', 'Gardiennage mis en place', 'Système remis en service'],
            ['Outside of site inspected', 'Inside of site inspected', 'Key holder informed', 'Police called', 'Guarding put in place', 'System re-armed']),
          text('police', ['Forces de l’ordre : service et heure d’appel', 'Police: unit and time called']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'INSTALLATION',
    name: ['Mise en place de site / audit de sécurité', 'Site setup / security audit'],
    sections: [
      {
        id: 'site', title: ['Site', 'Site'], fields: [
          text('siteName', ['Nom du site', 'Site name'], { prefill: 'site.name' }),
          text('siteAddress', ['Adresse du site', 'Site address'], { prefill: 'site.fullAddress' }),
          choice('siteType', ['Type de site', 'Site type'],
            ['Habitation', 'Commerce', 'Bureaux', 'Entrepôt / industrie', 'Chantier', 'Établissement recevant du public', 'Autre'],
            ['Home', 'Shop', 'Offices', 'Warehouse / industrial', 'Construction site', 'Public building', 'Other'], { required: true }),
        ],
      },
      {
        id: 'audit', title: ['Audit', 'Audit'], fields: [
          area('instructions', ['Consignes reçues du client', 'Instructions from the customer'], { required: true }),
          area('weakPoints', ['Points sensibles du site', 'Weak points of the site']),
          list('handedOver', ['Moyens remis à l’agent', 'Items handed to the officer'],
            ['Clés', 'Badges', 'Codes d’accès', 'Consignes écrites', 'Plan du site'],
            ['Keys', 'Badges', 'Access codes', 'Written instructions', 'Site plan']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'OTHER',
    name: ['Rapport d’incident / main courante', 'Incident report / logbook'],
    sections: [
      {
        id: 'event', title: ['Événement', 'Event'], fields: [
          choice('nature', ['Nature de l’événement', 'Type of event'],
            ['Incident', 'Accident', 'Dégradation', 'Personne suspecte', 'Visite / livraison', 'Autre'],
            ['Incident', 'Accident', 'Damage', 'Suspicious person', 'Visit / delivery', 'Other'], { required: true }),
          time('eventTime', ['Heure de l’événement', 'Time of event']),
          area('description', ['Description des faits', 'Description of events'], { required: true }),
          area('people', ['Personnes impliquées et témoins', 'People involved and witnesses']),
          area('followUp', ['Suites données', 'Follow-up']),
        ],
      },
    ],
  },
];

// ─── Commissaires de justice (Constat) ───────────────────────────────────

const presentPeople = area('present', ['Personnes présentes (nom et qualité)', 'People present (name and capacity)']);
const constatHelp: Tx = [
  'Décrire ce qui est vu, sans interpréter, pièce par pièce ou point par point. Les photos sont annexées au procès-verbal.',
  'Describe what is seen, without interpretation, room by room or point by point. Photos are appended to the report.',
];

const BAILIFF: TemplateDef[] = [
  {
    kind: 'SAV',
    name: ['Procès-verbal de constat de dégâts', 'Damage report'],
    sections: [
      {
        id: 'parties', title: ['Requérant et lieux', 'Requesting party and premises'], fields: [
          text('requester', ['Requérant', 'Requesting party'], { prefill: 'client.name', required: true }),
          text('premises', ['Adresse des lieux', 'Address of the premises'], { prefill: 'site.fullAddress' }),
          area('purpose', ['Objet du constat', 'Purpose of the report'], { prefill: 'intervention.reason', required: true, dictation: false }),
          presentPeople,
        ],
      },
      {
        id: 'findings', title: ['Constatations', 'Findings'], fields: [
          area('findings', ['Constatations', 'Findings'], { required: true, help: constatHelp }),
          area('origin', ['Origine apparente indiquée par les personnes présentes', 'Apparent cause stated by those present']),
          area('statements', ['Déclarations recueillies', 'Statements taken']),
        ],
      },
    ],
  },
  {
    kind: 'INSTALLATION',
    name: ['Procès-verbal de constat de travaux', 'Works report'],
    sections: [
      {
        id: 'parties', title: ['Requérant et lieux', 'Requesting party and premises'], fields: [
          text('requester', ['Requérant', 'Requesting party'], { prefill: 'client.name', required: true }),
          text('premises', ['Adresse du chantier', 'Site address'], { prefill: 'site.fullAddress' }),
          area('purpose', ['Objet du constat', 'Purpose of the report'], { prefill: 'intervention.reason', required: true, dictation: false }),
          presentPeople,
        ],
      },
      {
        id: 'works', title: ['Travaux', 'Works'], fields: [
          choice('progress', ['Avancement constaté', 'Progress observed'],
            ['Non commencés', 'En cours', 'Achevés', 'Arrêtés ou abandonnés'],
            ['Not started', 'In progress', 'Completed', 'Stopped or abandoned'], { required: true }),
          area('findings', ['Constatations', 'Findings'], { required: true, help: constatHelp }),
          area('defects', ['Malfaçons ou non-conformités apparentes', 'Apparent defects or non-compliance']),
        ],
      },
    ],
  },
  {
    kind: 'MAINTENANCE',
    name: ['Procès-verbal de constat d’affichage', 'Notice posting report'],
    sections: [
      {
        id: 'posting', title: ['Affichage', 'Posting'], fields: [
          text('requester', ['Requérant', 'Requesting party'], { prefill: 'client.name', required: true }),
          text('premises', ['Adresse du terrain', 'Address of the land'], { prefill: 'site.fullAddress' }),
          text('permitRef', ['Référence de l’autorisation (permis, déclaration…)', 'Permit reference']),
          choice('visit', ['Passage', 'Visit'], ['1er passage', '2e passage', '3e passage'], ['1st visit', '2nd visit', '3rd visit'], { required: true }),
          yesNo('visible', ['Panneau visible et lisible depuis la voie publique', 'Sign visible and legible from the public road'], { required: true }),
          list('mentions', ['Mentions lisibles sur le panneau', 'Details legible on the sign'],
            ['Nom du bénéficiaire', 'Date et numéro de l’autorisation', 'Nature des travaux', 'Hauteur ou surface', 'Adresse de la mairie', 'Délais et voies de recours'],
            ['Name of the beneficiary', 'Permit date and number', 'Nature of the works', 'Height or floor area', 'Town hall address', 'Appeal periods']),
          area('findings', ['Constatations', 'Findings'], { help: constatHelp }),
        ],
      },
    ],
  },
  {
    kind: 'OTHER',
    name: ['Procès-verbal de constat', 'Official report'],
    sections: [
      {
        id: 'parties', title: ['Requérant et lieux', 'Requesting party and premises'], fields: [
          text('requester', ['Requérant', 'Requesting party'], { prefill: 'client.name', required: true }),
          text('premises', ['Lieu du constat', 'Place of the report'], { prefill: 'site.fullAddress' }),
          area('purpose', ['Objet du constat', 'Purpose of the report'], { prefill: 'intervention.reason', required: true, dictation: false }),
          presentPeople,
        ],
      },
      {
        id: 'findings', title: ['Constatations', 'Findings'], fields: [
          area('findings', ['Constatations', 'Findings'], { required: true, help: constatHelp }),
          area('statements', ['Déclarations recueillies', 'Statements taken']),
        ],
      },
    ],
  },
];

// ─── Expertise et diagnostic ─────────────────────────────────────────────

const EXPERTISE: TemplateDef[] = [
  {
    kind: 'SAV',
    name: ['Rapport d’expertise sinistre', 'Claim inspection report'],
    sections: [
      {
        id: 'claim', title: ['Dossier', 'Claim'], fields: [
          text('claimRef', ['Référence du sinistre / n° de dossier', 'Claim reference'], { required: true }),
          text('principal', ['Assureur ou donneur d’ordre', 'Insurer or instructing party'], { prefill: 'client.name' }),
          text('premises', ['Adresse du risque', 'Risk address'], { prefill: 'site.fullAddress' }),
          choice('claimType', ['Nature du sinistre', 'Type of claim'],
            ['Dégât des eaux', 'Incendie', 'Vol / effraction', 'Bris de glace', 'Catastrophe naturelle', 'Tempête / grêle', 'Autre'],
            ['Water damage', 'Fire', 'Theft / break-in', 'Glass breakage', 'Natural disaster', 'Storm / hail', 'Other'], { required: true }),
          day('claimDate', ['Date du sinistre', 'Date of loss']),
        ],
      },
      {
        id: 'findings', title: ['Constatations', 'Findings'], fields: [
          area('circumstances', ['Circonstances déclarées', 'Stated circumstances']),
          area('damage', ['Dommages constatés', 'Damage observed'], { required: true }),
          area('cause', ['Cause et origine', 'Cause and origin']),
          area('measures', ['Mesures conservatoires', 'Protective measures']),
        ],
      },
      {
        id: 'assessment', title: ['Chiffrage', 'Assessment'], fields: [
          num('estimate', ['Estimation des dommages (montant TTC)', 'Estimated damage (gross amount)']),
          choice('recourse', ['Recours possible contre un tiers', 'Recovery from a third party'], ['Oui', 'Non', 'À vérifier'], ['Yes', 'No', 'To be checked']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'INSTALLATION',
    name: ['Diagnostic immobilier', 'Property survey'],
    sections: [
      {
        id: 'property', title: ['Bien', 'Property'], fields: [
          text('premises', ['Adresse du bien', 'Property address'], { prefill: 'site.fullAddress' }),
          choice('propertyType', ['Type de bien', 'Property type'],
            ['Maison', 'Appartement', 'Local commercial', 'Immeuble', 'Autre'],
            ['House', 'Flat', 'Commercial premises', 'Building', 'Other'], { required: true }),
          num('buildYear', ['Année de construction', 'Year built']),
          num('area', ['Surface (m²)', 'Floor area (m²)']),
        ],
      },
      {
        id: 'surveys', title: ['Diagnostics', 'Surveys'], fields: [
          list('done', ['Diagnostics réalisés', 'Surveys carried out'],
            ['Performance énergétique (DPE)', 'Amiante', 'Plomb (CREP)', 'Électricité', 'Gaz', 'Termites', 'État des risques', 'Mesurage (Carrez / Boutin)'],
            ['Energy performance (EPC)', 'Asbestos', 'Lead', 'Electrical', 'Gas', 'Termites', 'Risk report', 'Floor area measurement'], { required: true }),
          area('notVisited', ['Pièces non visitées et motif', 'Rooms not inspected and why']),
          area('findings', ['Constatations', 'Findings'], { required: true }),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'MAINTENANCE',
    name: ['Compte rendu de visite de contrôle', 'Inspection visit report'],
    sections: [
      {
        id: 'visit', title: ['Visite', 'Visit'], fields: [
          area('purpose', ['Objet de la visite', 'Purpose of the visit'], { prefill: 'intervention.reason', dictation: false }),
          list('checked', ['Points contrôlés', 'Items inspected'],
            ['Structure', 'Toiture', 'Façades', 'Réseaux', 'Équipements', 'Accessibilité'],
            ['Structure', 'Roof', 'Façades', 'Utilities', 'Equipment', 'Accessibility']),
          area('readings', ['Relevés et mesures', 'Readings and measurements']),
          area('findings', ['Constatations', 'Findings'], { required: true }),
          area('reserves', ['Réserves', 'Reservations']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'OTHER',
    name: ['Compte rendu de mission', 'Assignment report'],
    sections: [
      {
        id: 'mission', title: ['Mission', 'Assignment'], fields: [
          text('principal', ['Donneur d’ordre', 'Instructing party'], { prefill: 'client.name' }),
          area('purpose', ['Objet de la mission', 'Purpose of the assignment'], { prefill: 'intervention.reason', required: true, dictation: false }),
          area('findings', ['Constatations', 'Findings'], { required: true }),
          area('conclusions', ['Conclusions', 'Conclusions']),
        ],
      },
    ],
  },
];

// ─── États des lieux (Clés) ──────────────────────────────────────────────

const roomHelp: Tx = [
  'Sols, murs, plafonds, menuiseries, équipements : état (neuf, bon, usage normal, mauvais) et détails.',
  'Floors, walls, ceilings, joinery, fittings: condition (new, good, normal wear, poor) and details.',
];
const ROOMS: [string, Tx][] = [
  ['roomEntrance', ['Entrée', 'Entrance hall']],
  ['roomLiving', ['Séjour', 'Living room']],
  ['roomKitchen', ['Cuisine', 'Kitchen']],
  ['roomBedrooms', ['Chambre(s)', 'Bedroom(s)']],
  ['roomBathroom', ['Salle de bains et WC', 'Bathroom and WC']],
  ['roomOther', ['Annexes (cave, garage, balcon, jardin)', 'Outbuildings (cellar, garage, balcony, garden)']],
];

function rentalTemplate(kind: InterventionKind, name: Tx, exit: boolean): TemplateDef {
  return {
    kind,
    name,
    sections: [
      {
        id: 'parties', title: ['Parties et logement', 'Parties and property'], fields: [
          text('landlord', ['Bailleur ou mandataire', 'Landlord or agent'], { prefill: 'client.name', required: true }),
          text('tenants', ['Locataire(s)', 'Tenant(s)'], { required: true }),
          text('premises', ['Adresse du logement', 'Property address'], { prefill: 'site.fullAddress' }),
          choice('propertyType', ['Type de logement', 'Property type'],
            ['Studio', '2 pièces', '3 pièces', '4 pièces', '5 pièces et plus', 'Maison'],
            ['Studio', '1 bedroom', '2 bedrooms', '3 bedrooms', '4 bedrooms or more', 'House']),
          yesNo('furnished', ['Logement meublé', 'Furnished']),
          ...(exit ? [text('newAddress', ['Nouvelle adresse du locataire', 'Tenant’s new address'])] : []),
        ],
      },
      {
        id: 'meters', title: ['Compteurs', 'Meters'], fields: [
          text('meterElec', ['Électricité (index)', 'Electricity (reading)']),
          text('meterGas', ['Gaz (index)', 'Gas (reading)']),
          text('meterColdWater', ['Eau froide (index)', 'Cold water (reading)']),
          text('meterHotWater', ['Eau chaude (index)', 'Hot water (reading)']),
        ],
      },
      {
        id: 'rooms', title: ['Pièce par pièce', 'Room by room'],
        fields: ROOMS.map(([id, label]) => area(id, label, { help: roomHelp })),
      },
      {
        id: 'keys', title: ['Clés et équipements', 'Keys and fittings'], fields: [
          text('keys', exit ? ['Clés et badges restitués (nombre et type)', 'Keys and badges returned (number and type)'] : ['Clés et badges remis (nombre et type)', 'Keys and badges handed over (number and type)'], { required: true }),
          list('fittings', ['Équipements vérifiés', 'Fittings checked'],
            ['Détecteur de fumée présent', 'Chaudière / chauffe-eau en état', 'Radiateurs fonctionnent', 'Volets et fenêtres fonctionnent', 'Robinetterie sans fuite'],
            ['Smoke alarm present', 'Boiler / water heater working', 'Radiators working', 'Shutters and windows working', 'No leaking taps']),
          ...(exit ? [area('damage', ['Dégradations constatées par rapport à l’entrée', 'Damage compared with check-in'], { required: true })] : []),
        ],
      },
      observations,
    ],
  };
}

const RENTAL: TemplateDef[] = [
  rentalTemplate('INSTALLATION', ['État des lieux d’entrée', 'Check-in inventory'], false),
  rentalTemplate('SAV', ['État des lieux de sortie', 'Check-out inventory'], true),
  {
    kind: 'MAINTENANCE',
    name: ['Pré-état des lieux', 'Pre-check-out visit'],
    sections: [
      {
        id: 'visit', title: ['Visite', 'Visit'], fields: [
          text('tenants', ['Locataire(s)', 'Tenant(s)'], { required: true }),
          day('exitDate', ['Date de sortie prévue', 'Planned move-out date']),
          area('tenantWork', ['Travaux ou nettoyage à prévoir par le locataire', 'Repairs or cleaning to be done by the tenant'], { required: true }),
          area('watch', ['Points à vérifier à la sortie', 'Points to check at check-out']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'OTHER',
    name: ['Inventaire du mobilier', 'Furniture inventory'],
    sections: [
      {
        id: 'inventory', title: ['Inventaire', 'Inventory'], fields: [
          text('premises', ['Adresse du logement', 'Property address'], { prefill: 'site.fullAddress' }),
          area('furniture', ['Mobilier, pièce par pièce (quantité et état)', 'Furniture, room by room (quantity and condition)'], { required: true }),
          area('appliances', ['Électroménager (quantité et état)', 'Appliances (quantity and condition)']),
          area('kitchenware', ['Vaisselle, ustensiles et linge', 'Crockery, utensils and linen']),
        ],
      },
      observations,
    ],
  },
];

// ─── Multiservices ───────────────────────────────────────────────────────

const SERVICES: TemplateDef[] = [
  {
    kind: 'MAINTENANCE',
    name: ['Fiche de passage', 'Service visit sheet'],
    sections: [
      {
        id: 'visit', title: ['Prestation', 'Service'], fields: [
          choice('service', ['Prestation', 'Service'],
            ['Nettoyage', 'Espaces verts', 'Désinsectisation / dératisation', 'Entretien d’ascenseur', 'Autre'],
            ['Cleaning', 'Grounds maintenance', 'Pest control', 'Lift maintenance', 'Other'], { required: true }),
          list('tasks', ['Tâches réalisées', 'Tasks completed'],
            ['Tâches du cahier des charges', 'Parties communes', 'Sanitaires', 'Vitrerie', 'Évacuation des déchets'],
            ['Tasks in the specification', 'Common areas', 'Washrooms', 'Windows', 'Waste removal']),
          area('work', ['Travaux réalisés', 'Work carried out'], { required: true }),
          area('products', ['Produits utilisés (nom et quantité)', 'Products used (name and quantity)']),
          area('anomalies', ['Anomalies constatées', 'Issues found']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'SAV',
    name: ['Fiche d’intervention ponctuelle', 'Call-out sheet'],
    sections: [
      {
        id: 'callout', title: ['Intervention', 'Call-out'], fields: [
          area('request', ['Demande du client', 'Customer request'], { prefill: 'intervention.reason', required: true, dictation: false }),
          area('work', ['Travaux réalisés', 'Work carried out'], { required: true }),
          area('products', ['Produits ou matériaux utilisés', 'Products or materials used']),
          choice('next', ['Suite à donner', 'Next step'], ['Aucune', 'Nouveau passage', 'Devis à établir'], ['None', 'Another visit', 'Quote needed']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'INSTALLATION',
    name: ['Démarrage de prestation', 'Service start-up'],
    sections: [
      {
        id: 'startup', title: ['Mise en place', 'Start-up'], fields: [
          yesNo('specs', ['Cahier des charges remis', 'Specification received'], { required: true }),
          area('zones', ['Zones et surfaces concernées', 'Areas covered'], { required: true }),
          text('frequency', ['Fréquence convenue', 'Agreed frequency']),
          area('access', ['Accès (clés, codes, horaires)', 'Access (keys, codes, hours)']),
          text('contact', ['Interlocuteur sur site', 'On-site contact']),
        ],
      },
      observations,
    ],
  },
  {
    kind: 'OTHER',
    name: ['Fiche de traitement anti-nuisibles', 'Pest control treatment sheet'],
    sections: [
      {
        id: 'treatment', title: ['Traitement', 'Treatment'], fields: [
          choice('pest', ['Nuisible ciblé', 'Target pest'],
            ['Rats / souris', 'Cafards / blattes', 'Punaises de lit', 'Guêpes / frelons', 'Fourmis', 'Autre'],
            ['Rats / mice', 'Cockroaches', 'Bed bugs', 'Wasps / hornets', 'Ants', 'Other'], { required: true }),
          area('zones', ['Zones traitées', 'Areas treated'], { required: true }),
          area('biocides', ['Produits biocides utilisés (nom, n° d’autorisation, dose)', 'Biocides used (name, authorisation number, dose)'], { required: true }),
          num('baitStations', ['Postes d’appâtage posés ou contrôlés (nombre)', 'Bait stations placed or checked (number)']),
          text('reentry', ['Délai avant de réoccuper les lieux', 'Time before re-entering the premises']),
          check('safetyNotice', ['Consignes de sécurité remises au client', 'Safety instructions given to the customer']),
        ],
      },
      observations,
    ],
  },
];

const DEFS: Record<Exclude<Sector, 'TECH'>, TemplateDef[]> = { SECURITY, BAILIFF, EXPERTISE, RENTAL, SERVICES };

export function build(def: TemplateDef, lang: Lang): { name: string; kind: InterventionKind; schema: TemplateSchema } {
  const i = lang === 'fr' ? 0 : 1;
  return {
    name: def.name[i],
    kind: def.kind,
    schema: {
      lang,
      sections: def.sections.map((s) => ({
        id: s.id,
        title: s.title[i],
        fields: s.fields.map((f): TemplateField => ({
          id: f.id,
          label: f.label[i],
          type: f.type,
          ...(f.required ? { required: true } : {}),
          ...(f.options ? { options: f.options[i] } : {}),
          ...(f.prefill ? { prefill: f.prefill } : {}),
          ...(f.dictation ? { dictation: true } : {}),
          ...(f.help ? { help: f.help[i] } : {}),
        })),
      })),
    },
  };
}

/** Secteurs qui ont leurs propres modèles (les techniciens gardent les modèles neutres) */
export const TEMPLATE_SECTORS = Object.keys(DEFS) as Exclude<Sector, 'TECH'>[];

/** Les modèles fournis pour un secteur, dans une langue : un par type d'intervention */
export function buildSectorTemplates(sector: Exclude<Sector, 'TECH'>, lang: Lang) {
  return DEFS[sector].map((d) => build(d, lang));
}
