/**
 * Géolocalisation des véhicules.
 *
 * La position vient du téléphone du conducteur, pendant que l'appli terrain est ouverte, et seulement s'il a
 * activé le partage lui-même. Les positions sont gardées 30 jours puis effacées (règles CNIL : finalité
 * limitée à l'organisation des interventions, durée de conservation courte, possibilité d'arrêter).
 */
import { lt } from 'drizzle-orm';
import { db, schema } from '../db/client.js';

/** Durée de conservation de l'historique */
export const POSITION_RETENTION_DAYS = 30;
/** Une position plus imprécise que cela n'apporte rien (téléphone sans GPS, en intérieur…) */
export const MAX_ACCURACY_M = 5000;
/** Une position envoyée après une longue coupure de réseau reste acceptée jusqu'à 7 jours */
const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
/** Petite marge pour l'horloge du téléphone */
const MAX_FUTURE_MS = 5 * 60 * 1000;

export interface IncomingPosition {
  lat: number;
  lng: number;
  accuracy?: number | null;
  recordedAt: string;
  event?: 'TRACK' | 'EN_ROUTE' | 'ON_SITE';
  interventionId?: string | null;
}

/**
 * Garde les positions valables : coordonnées possibles, heure plausible, assez précises, et jamais antérieures
 * à l'activation du partage (aucune position d'avant l'accord du technicien).
 */
export function acceptablePositions<T extends IncomingPosition>(list: T[], sharingSince: Date, now = new Date()): (T & { at: Date })[] {
  const out: (T & { at: Date })[] = [];
  for (const p of list) {
    const at = new Date(p.recordedAt);
    if (Number.isNaN(at.getTime())) continue;
    if (at.getTime() > now.getTime() + MAX_FUTURE_MS || at.getTime() < now.getTime() - MAX_AGE_MS) continue;
    if (at.getTime() < sharingSince.getTime() - 1000) continue;
    if (!(p.lat >= -90 && p.lat <= 90 && p.lng >= -180 && p.lng <= 180)) continue;
    if (p.lat === 0 && p.lng === 0) continue; // position « nulle » renvoyée par certains téléphones
    if (p.accuracy != null && p.accuracy > MAX_ACCURACY_M) continue;
    out.push({ ...p, at });
  }
  return out.sort((a, b) => a.at.getTime() - b.at.getTime());
}

/** Minuit d'une journée (AAAA-MM-JJ) dans le fuseau de la société, en heure universelle (heure d'été comprise) */
export function localDayStart(day: string, timezone: string): Date {
  const guess = new Date(`${day}T00:00:00Z`);
  const offsetAt = (d: Date) => {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', {
      timeZone: timezone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit',
    }).formatToParts(d).map((x) => [x.type, x.value]));
    const asUtc = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second);
    return asUtc - d.getTime();
  };
  // Deux passes : le décalage de minuit peut différer de celui du « minuit UTC » les jours de changement d'heure
  const first = new Date(guess.getTime() - offsetAt(guess));
  return new Date(guess.getTime() - offsetAt(first));
}

/** Efface l'historique de plus de 30 jours ; renvoie le nombre de positions effacées */
export async function purgeOldPositions(now = new Date()): Promise<number> {
  const limit = new Date(now.getTime() - POSITION_RETENTION_DAYS * 24 * 60 * 60 * 1000);
  const res = await db.delete(schema.vehiclePositions).where(lt(schema.vehiclePositions.recordedAt, limit)).returning({ id: schema.vehiclePositions.id });
  return res.length;
}

/** Effacement au démarrage du serveur puis toutes les 6 heures */
export function schedulePositionPurge(log: (msg: string) => void) {
  const run = () =>
    purgeOldPositions()
      .then((n) => n && log(`${n} position(s) de véhicules de plus de ${POSITION_RETENTION_DAYS} jours effacée(s)`))
      .catch((err) => log(`Effacement des anciennes positions impossible : ${(err as Error).message}`));
  void run();
  const timer = setInterval(run, 6 * 60 * 60 * 1000);
  timer.unref();
}
