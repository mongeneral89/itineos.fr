/** Règles d'un modèle de fiche (sections et champs), vérifiées à chaque enregistrement */
import { z } from 'zod';
import { FIELD_TYPES, PREFILL_SOURCES, TEMPLATE_LIMITS } from '@itineo/shared';

const L = TEMPLATE_LIMITS;
const PREFILL_PATHS = PREFILL_SOURCES.map((s) => s.path) as [string, ...string[]];

const fieldSchema = z.object({
  id: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]*$/, 'Identifiant de champ invalide').max(60),
  label: z.string().trim().min(1, 'Chaque champ doit avoir un libellé').max(L.label),
  type: z.enum(FIELD_TYPES),
  required: z.boolean().optional(),
  options: z.array(z.string().trim().min(1).max(L.label)).max(L.options).optional(),
  prefill: z.enum(PREFILL_PATHS).optional(),
  dictation: z.boolean().optional(),
  help: z.string().max(500).optional(),
});

export const templateSchema = z.object({
  lang: z.string().max(10).optional(),
  sections: z.array(z.object({
    id: z.string().min(1).max(60),
    title: z.string().trim().min(1, 'Chaque section doit avoir un titre').max(L.label),
    fields: z.array(fieldSchema).min(1, 'Chaque section doit contenir au moins un champ').max(L.fieldsPerSection),
  })).min(1, 'Le modèle doit contenir au moins une section').max(L.sections),
}).superRefine((s, ctx) => {
  const ids = s.sections.flatMap((sec) => sec.fields.map((f) => f.id));
  const dup = ids.find((x, idx) => ids.indexOf(x) !== idx);
  if (dup) ctx.addIssue({ code: 'custom', message: `Champ en double : ${dup}` });
  const secIds = s.sections.map((sec) => sec.id);
  const dupSec = secIds.find((x, idx) => secIds.indexOf(x) !== idx);
  if (dupSec) ctx.addIssue({ code: 'custom', message: `Section en double : ${dupSec}` });
  for (const f of s.sections.flatMap((sec) => sec.fields)) {
    if ((f.type === 'select' || f.type === 'checklist') && !f.options?.length) {
      ctx.addIssue({ code: 'custom', message: `Le champ « ${f.label} » doit avoir des choix` });
    }
    if (f.options && new Set(f.options).size !== f.options.length) {
      ctx.addIssue({ code: 'custom', message: `Le champ « ${f.label} » a deux choix identiques` });
    }
  }
});
