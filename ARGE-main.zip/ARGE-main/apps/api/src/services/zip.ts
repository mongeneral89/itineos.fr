/**
 * Archive .zip simple (fichiers stockés sans compression), pour exporter plusieurs factures d'un coup.
 * Les PDF sont déjà compressés : les compresser à nouveau ne ferait presque rien gagner.
 */

import { deflateRawSync } from 'node:zlib';

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

export function crc32(data: Buffer): number {
  let c = 0xffffffff;
  for (const b of data) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** Date et heure au format MS-DOS des en-têtes zip */
function dosTime(d: Date): { time: number; date: number } {
  return {
    time: (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2),
    date: ((Math.max(1980, d.getFullYear()) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate(),
  };
}

export function createZip(files: { name: string; data: Buffer }[], now = new Date()): Buffer {
  const { time, date } = dosTime(now);
  const locals: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'utf8');
    const crc = crc32(f.data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4); // version nécessaire
    local.writeUInt16LE(0x0800, 6); // noms en UTF-8
    local.writeUInt16LE(0, 8); // stocké, sans compression
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(f.data.length, 18);
    local.writeUInt32LE(f.data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    locals.push(local, name, f.data);

    const entry = Buffer.alloc(46);
    entry.writeUInt32LE(0x02014b50, 0);
    entry.writeUInt16LE(20, 4);
    entry.writeUInt16LE(20, 6);
    entry.writeUInt16LE(0x0800, 8);
    entry.writeUInt16LE(0, 10);
    entry.writeUInt16LE(time, 12);
    entry.writeUInt16LE(date, 14);
    entry.writeUInt32LE(crc, 16);
    entry.writeUInt32LE(f.data.length, 20);
    entry.writeUInt32LE(f.data.length, 24);
    entry.writeUInt16LE(name.length, 28);
    entry.writeUInt32LE(offset, 42);
    central.push(entry, name);
    offset += 30 + name.length + f.data.length;
  }
  const centralSize = central.reduce((s, b) => s + b.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, ...central, end]);
}

/**
 * Archive .zip écrite au fur et à mesure (export complet d'une société : des milliers de photos).
 * Chaque fichier est envoyé dès qu'il est prêt ; seul le répertoire final reste en mémoire.
 * Au-delà de 65 535 fichiers ou de 4 Go, les champs ZIP64 sont ajoutés (lisibles par Windows, macOS, 7-Zip).
 */
export class ZipStream {
  private central: Buffer[] = [];
  private count = 0;
  private offset = 0;
  private readonly time: number;
  private readonly date: number;

  constructor(private readonly write: (chunk: Buffer) => Promise<void>, now = new Date()) {
    ({ time: this.time, date: this.date } = dosTime(now));
  }

  /** Ajoute un fichier ; compress = deflate (textes, CSV), sinon stocké tel quel (PDF, photos) */
  async add(name: string, data: Buffer, compress = false): Promise<void> {
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    const body = compress ? deflateRawSync(data) : data;
    const method = compress ? 8 : 0;
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6); // noms en UTF-8
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(this.time, 10);
    local.writeUInt16LE(this.date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(body.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);

    // Position au-delà de 4 Go : notée dans un champ ZIP64 du répertoire
    const big = this.offset >= 0xffffffff;
    const extra = big ? Buffer.alloc(12) : Buffer.alloc(0);
    if (big) {
      extra.writeUInt16LE(0x0001, 0);
      extra.writeUInt16LE(8, 2);
      extra.writeBigUInt64LE(BigInt(this.offset), 4);
    }
    const entry = Buffer.alloc(46);
    entry.writeUInt32LE(0x02014b50, 0);
    entry.writeUInt16LE(45, 4);
    entry.writeUInt16LE(big ? 45 : 20, 6);
    entry.writeUInt16LE(0x0800, 8);
    entry.writeUInt16LE(method, 10);
    entry.writeUInt16LE(this.time, 12);
    entry.writeUInt16LE(this.date, 14);
    entry.writeUInt32LE(crc, 16);
    entry.writeUInt32LE(body.length, 20);
    entry.writeUInt32LE(data.length, 24);
    entry.writeUInt16LE(nameBuf.length, 28);
    entry.writeUInt16LE(extra.length, 30);
    entry.writeUInt32LE(big ? 0xffffffff : this.offset, 42);
    this.central.push(entry, nameBuf, extra);
    this.count++;

    await this.write(Buffer.concat([local, nameBuf]));
    await this.write(body);
    this.offset += 30 + nameBuf.length + body.length;
  }

  /** Écrit le répertoire final ; renvoie la taille totale de l'archive */
  async finish(): Promise<number> {
    const dir = Buffer.concat(this.central);
    const dirOffset = this.offset;
    const zip64 = this.count >= 0xffff || dirOffset >= 0xffffffff || dir.length >= 0xffffffff;
    const parts: Buffer[] = [dir];
    if (zip64) {
      const rec = Buffer.alloc(56);
      rec.writeUInt32LE(0x06064b50, 0);
      rec.writeBigUInt64LE(44n, 4);
      rec.writeUInt16LE(45, 12);
      rec.writeUInt16LE(45, 14);
      rec.writeBigUInt64LE(BigInt(this.count), 24);
      rec.writeBigUInt64LE(BigInt(this.count), 32);
      rec.writeBigUInt64LE(BigInt(dir.length), 40);
      rec.writeBigUInt64LE(BigInt(dirOffset), 48);
      const locator = Buffer.alloc(20);
      locator.writeUInt32LE(0x07064b50, 0);
      locator.writeBigUInt64LE(BigInt(dirOffset + dir.length), 8);
      locator.writeUInt32LE(1, 16);
      parts.push(rec, locator);
    }
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(zip64 ? 0xffff : this.count, 8);
    end.writeUInt16LE(zip64 ? 0xffff : this.count, 10);
    end.writeUInt32LE(zip64 ? 0xffffffff : dir.length, 12);
    end.writeUInt32LE(zip64 ? 0xffffffff : dirOffset, 16);
    parts.push(end);
    const tail = Buffer.concat(parts);
    await this.write(tail);
    return dirOffset + tail.length;
  }
}
