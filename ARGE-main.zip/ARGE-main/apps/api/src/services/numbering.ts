import { sql } from 'drizzle-orm';
import type { Db } from '../db/client.js';
import { formatNumber, langOf } from './prefill.js';

type Tx = Parameters<Parameters<Db['transaction']>[0]>[0];

/** Année courante dans le fuseau horaire de la société */
export function yearIn(timezone: string, date = new Date()): number {
  return Number(new Intl.DateTimeFormat('en', { timeZone: timezone, year: 'numeric' }).format(date));
}

export type DocumentKind = 'intervention' | 'quote' | 'contract' | 'invoice' | 'credit_note' | 'slip' | 'mandate' | 'sepa_batch';

/** Code du type de document dans le numéro, selon la langue de la société (les interventions n'en ont pas) */
const CODES: Record<Exclude<DocumentKind, 'intervention'>, { fr: string; en: string }> = {
  quote: { fr: 'DEV', en: 'QUO' },
  contract: { fr: 'CTR', en: 'CON' },
  invoice: { fr: 'FAC', en: 'INV' },
  credit_note: { fr: 'AVO', en: 'CRN' },
  slip: { fr: 'BS', en: 'ISS' },
  // Référence unique de mandat (RUM) et lot de prélèvement
  mandate: { fr: 'RUM', en: 'MDT' },
  sepa_batch: { fr: 'PRLV', en: 'DD' },
};

export function documentCode(kind: DocumentKind, locale: string): string | null {
  if (kind === 'intervention') return null;
  return CODES[kind][langOf(locale) === 'en' ? 'en' : 'fr'];
}

/**
 * Numéro suivant pour une société et un type de document, sans trou ni doublon même avec des
 * créations simultanées (l'incrément est fait par PostgreSQL en une seule instruction).
 *   intervention : FR-2026-00042      devis : FR-DEV-2026-00007      contrat : FR-CTR-2026-00003
 */
export async function nextNumber(
  tx: Db | Tx,
  company: { id: string; documentPrefix: string; timezone: string; locale?: string },
  kind: DocumentKind = 'intervention',
): Promise<string> {
  const year = yearIn(company.timezone);
  const res = await tx.execute<{ value: number }>(sql`
    INSERT INTO counters (company_id, kind, year, value) VALUES (${company.id}, ${kind}, ${year}, 1)
    ON CONFLICT (company_id, kind, year) DO UPDATE SET value = counters.value + 1
    RETURNING value`);
  const code = documentCode(kind, company.locale ?? 'fr');
  return formatNumber(code ? `${company.documentPrefix}-${code}` : company.documentPrefix, year, Number(res.rows[0].value));
}

/** Numéro d'intervention suivant (inchangé : PREFIXE-ANNÉE-00001) */
export function nextInterventionNumber(
  tx: Db | Tx,
  company: { id: string; documentPrefix: string; timezone: string },
): Promise<string> {
  return nextNumber(tx, company, 'intervention');
}
