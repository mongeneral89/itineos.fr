/** Fonctions propres aux métiers, côté fiches (voir FEATURES dans packages/shared) */
import { randomBytes } from 'node:crypto';
import { and, asc, desc, eq, inArray, ne } from 'drizzle-orm';
import { db, schema } from '../db/client.js';

/** Contenu d'un QR code de point de passage : imprévisible (on ne peut pas pointer sans être passé) */
export function newCheckpointCode(): string {
  return `ITN-CP-${randomBytes(9).toString('base64url')}`;
}

/** Points de passage en service d'un site, dans l'ordre de la ronde */
export function siteCheckpoints(siteId: string) {
  return db.select({ id: schema.checkpoints.id, name: schema.checkpoints.name, code: schema.checkpoints.code, position: schema.checkpoints.position })
    .from(schema.checkpoints)
    .where(and(eq(schema.checkpoints.siteId, siteId), eq(schema.checkpoints.active, true)))
    .orderBy(asc(schema.checkpoints.position), asc(schema.checkpoints.createdAt));
}

/**
 * Itinéos Clés : l'état des lieux d'entrée qui précède une sortie (même logement), le plus récent signé.
 * Les champs de même identifiant (pièces, compteurs, clés) sont comparés.
 */
export async function findCheckinReport(iv: { id: string; siteId: string }) {
  const i = schema.interventions;
  const r = schema.reports;
  const [row] = await db
    .select({ number: i.number, signedAt: r.signedAt, data: r.data, schema: r.templateSchema })
    .from(r)
    .innerJoin(i, eq(i.id, r.interventionId))
    .where(and(eq(i.siteId, iv.siteId), ne(i.id, iv.id), eq(i.kind, 'INSTALLATION'), inArray(r.status, ['SIGNED', 'SENT'])))
    .orderBy(desc(r.signedAt))
    .limit(1);
  return row ?? null;
}
