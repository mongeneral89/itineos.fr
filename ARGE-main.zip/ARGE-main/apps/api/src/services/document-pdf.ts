/**
 * PDF des documents commerciaux (devis, factures, avoirs), dans la langue du client
 * (à défaut celle de la société) : en-tête, client, lignes, totaux par taux de TVA, puis le bloc
 * propre à chaque document (« bon pour accord » d'un devis, conditions de paiement d'une facture).
 */
import PDFDocument from 'pdfkit';
import { documentTotals, formatMoney, formatVatRate, lineNetCents, type QuoteKind } from '@itineo/shared';
import { docLang, docTexts, formatLocale, longDay, type DocTexts } from './doc-i18n.js';
import { drawFooter, footerMargin, PdfWriter } from './pdf-text.js';
import { drawPdfLogo } from './logo.js';
import { facturxXmp } from './facturx.js';

/**
 * Les nombres en français utilisent une espace fine (U+202F) : on la remplace par une espace insécable
 * classique, plus sûre dans les PDF.
 */
export function pdfSafe(s: string): string {
  return s.replace(/ /g, ' ');
}

interface Common {
  /** Langue du document, ex. "es-ES" (celle du client, sinon celle de la société) */
  locale: string;
  currency: string;
  company: {
    name: string; legalName?: string | null; address?: string | null; postalCode?: string | null; city?: string | null;
    phone?: string | null; email?: string | null; vatNumber?: string | null; legalMentions?: string | null; bankDetails?: string | null;
    countryCode?: string | null;
    /** Logo de la société (PNG ou JPEG) */
    logo?: Buffer | null;
  };
  agencyName?: string | null;
  client: { name: string; address: string; email?: string | null };
  site: { name: string; address: string } | null;
  lines: { description: string; quantity: number; unit: string | null; unitPriceCents: number; vatRateBp: number }[];
}

export interface QuotePdfInput extends Common {
  quote: {
    number: string; title: string; intro: string | null; notes: string | null; kind: QuoteKind;
    contractFrequencyMonths: number | null; date: string; validUntil: string | null;
  };
}

export interface InvoicePdfInput extends Common {
  invoice: {
    kind: 'INVOICE' | 'CREDIT_NOTE'; number: string; title: string; notes: string | null;
    issueDate: string; serviceDate: string | null; dueDate: string | null; creditedNumber: string | null; paidCents: number;
  };
  /** Facture électronique : XML Factur-X joint au PDF, qui devient un PDF/A-3 (voir services/facturx.ts) */
  facturxXml?: string | null;
}

const INK = '#14181F';
const MUTED = '#5B616B';
const RULE = '#D9D4CA';

interface Ctx { doc: PDFKit.PDFDocument; w: PdfWriter; t: DocTexts; left: number; width: number; ensure: (h: number) => void; money: (c: number) => string; grossCents: number }

function render(
  input: Common,
  head: { title: string; number: string; meta: string[]; subject: string; intro: string | null },
  after: (ctx: Ctx) => void,
  facturxXml?: string | null,
): Promise<Buffer> {
  const t = docTexts(input.locale);
  const loc = formatLocale(input.locale);
  const money = (c: number) => pdfSafe(formatMoney(c, input.currency, loc));
  const num = (n: number) => pdfSafe(new Intl.NumberFormat(loc, { maximumFractionDigits: 2 }).format(n));

  const doc = new PDFDocument({
    size: 'A4', margins: { top: 40, left: 40, right: 40, bottom: footerMargin(input.company.legalMentions) }, bufferPages: true,
    info: { Title: `${head.title} ${head.number}`, Author: input.company.name, Creator: 'Itinéos' },
    // Facture électronique : PDF/A-3, le seul format PDF qui peut contenir le XML de la facture
    ...(facturxXml ? { subset: 'PDF/A-3b' as const, pdfVersion: '1.7' as const } : {}),
  });
  const w = new PdfWriter(doc, docLang(input.locale));
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  const left = doc.page.margins.left;
  const width = doc.page.width - left - doc.page.margins.right;
  const bottom = () => doc.page.height - doc.page.margins.bottom - 40;
  const ensure = (h: number) => {
    if (doc.y + h > bottom()) doc.addPage();
  };

  // En-tête
  const c = input.company;
  const top = doc.y;
  const logoH = drawPdfLogo(doc, c.logo, left, top);
  doc.fontSize(15).fillColor(INK);
  w.text(c.name, left, top + logoH, { width: width * 0.55, bold: true });
  doc.fontSize(8.5).fillColor(MUTED);
  for (const line of [
    c.legalName,
    [c.address, [c.postalCode, c.city].filter(Boolean).join(' ')].filter(Boolean).join(', '),
    [c.phone, c.email].filter(Boolean).join(' · '),
    c.vatNumber ? `${t.vatNumber} ${c.vatNumber}` : null,
    input.agencyName,
  ].filter(Boolean) as string[]) w.text(line, left, doc.y, { width: width * 0.55, align: 'left' });
  const afterCompany = doc.y;
  doc.fontSize(14).fillColor(INK);
  w.text(head.title, left + width * 0.55, top, { width: width * 0.45, align: 'right', bold: true });
  doc.fontSize(10);
  w.text(`${t.number} ${head.number}`, left + width * 0.55, doc.y, { width: width * 0.45, align: 'right' });
  doc.fillColor(MUTED).fontSize(9);
  for (const m of head.meta) w.text(m, left + width * 0.55, doc.y, { width: width * 0.45, align: 'right' });
  doc.y = Math.max(afterCompany, doc.y) + 12;

  // Client et lieu
  const half = (width - 12) / 2;
  const boxTop = doc.y;
  const box = (x: number, title: string, lines: string[]) => {
    doc.fontSize(9).fillColor(MUTED);
    w.text(title.toUpperCase(), x + 10, boxTop + 8, { width: half - 20, bold: true });
    doc.fontSize(10).fillColor(INK);
    for (const l of lines.filter(Boolean)) w.text(l, x + 10, doc.y + 1, { width: half - 20 });
    return doc.y;
  };
  const endA = box(left, t.client, [input.client.name, input.client.address, input.client.email ?? '']);
  const endB = input.site ? box(left + half + 12, t.site, [input.site.name, input.site.address]) : boxTop;
  const boxBottom = Math.max(endA, endB) + 8;
  doc.roundedRect(left, boxTop, half, boxBottom - boxTop, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  if (input.site) doc.roundedRect(left + half + 12, boxTop, half, boxBottom - boxTop, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  doc.y = boxBottom + 14;

  // Objet
  doc.fontSize(12).fillColor(INK);
  w.text(head.subject, left, doc.y, { width, bold: true });
  if (head.intro) {
    doc.moveDown(0.3).fontSize(10).fillColor(INK);
    w.text(head.intro, left, doc.y, { width });
  }
  doc.moveDown(0.8);

  // Lignes
  const cols = [
    { x: left, w: width * 0.42, align: 'left' as const, label: t.description },
    { x: left + width * 0.42, w: width * 0.08, align: 'right' as const, label: t.qty },
    { x: left + width * 0.51, w: width * 0.08, align: 'left' as const, label: t.unit },
    { x: left + width * 0.59, w: width * 0.14, align: 'right' as const, label: t.unitPrice },
    { x: left + width * 0.73, w: width * 0.1, align: 'right' as const, label: t.vat },
    { x: left + width * 0.83, w: width * 0.17, align: 'right' as const, label: t.lineTotal },
  ];
  const header = () => {
    const y = doc.y;
    doc.fontSize(8.5).fillColor(MUTED);
    let h = 0;
    for (const col of cols) {
      w.text(col.label.toUpperCase(), col.x, y, { width: col.w, align: col.align, bold: true });
      h = Math.max(h, doc.y - y);
    }
    doc.y = y + Math.max(14, h + 3);
    doc.moveTo(left, doc.y - 3).lineTo(left + width, doc.y - 3).lineWidth(0.8).strokeColor(RULE).stroke();
  };
  header();
  for (const l of input.lines) {
    doc.fontSize(10);
    const h = w.height(l.description, { width: cols[0].w });
    if (doc.y + h + 6 > bottom()) {
      doc.addPage();
      header();
    }
    const y = doc.y;
    doc.fontSize(10).fillColor(INK);
    const values = [l.description, num(l.quantity), l.unit ?? '', money(l.unitPriceCents), pdfSafe(formatVatRate(l.vatRateBp, loc)), money(lineNetCents(l))];
    cols.forEach((col, i) => w.text(values[i], col.x, y, { width: col.w, align: col.align }));
    doc.y = y + h + 6;
  }
  doc.moveTo(left, doc.y).lineTo(left + width, doc.y).lineWidth(0.8).strokeColor(RULE).stroke();
  doc.moveDown(0.6);

  // Totaux
  const totals = documentTotals(input.lines);
  ensure(30 + totals.byRate.length * 14);
  const tx = left + width * 0.5;
  const tw = width * 0.5;
  const totalRow = (label: string, value: string, bold = false) => {
    const y = doc.y;
    doc.fontSize(bold ? 11 : 10).fillColor(INK);
    w.text(label, tx, y, { width: tw * 0.62, bold });
    const after = doc.y;
    w.text(value, tx + tw * 0.62, y, { width: tw * 0.38, align: 'right', bold });
    doc.y = Math.max(after, y + (bold ? 16 : 14));
  };
  totalRow(t.net, money(totals.netCents));
  for (const r of totals.byRate) totalRow(t.vatOn(pdfSafe(formatVatRate(r.vatRateBp, loc)), money(r.baseCents)), money(r.vatCents));
  totalRow(t.gross, money(totals.grossCents), true);

  after({ doc, w, t, left, width, ensure, money, grossCents: totals.grossCents });

  // Pied de page
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    drawFooter(doc, w, c.legalMentions, `${head.number} · ${t.page} ${i + 1}/${range.count}`, MUTED);
  }
  if (facturxXml) {
    doc.file(Buffer.from(facturxXml, 'utf8'), {
      name: 'factur-x.xml', type: 'text/xml', description: 'Factur-X (EN 16931)', relationship: 'Data',
    } as PDFKit.Mixins.PDFAttachmentOptions);
    doc.appendXML(facturxXmp());
  }
  doc.end();
  return done;
}

function block(w: PdfWriter, doc: PDFKit.PDFDocument, title: string, text: string, left: number, width: number) {
  doc.fontSize(9).fillColor(MUTED);
  w.text(title.toUpperCase(), left, doc.y, { width, bold: true });
  doc.fontSize(9.5).fillColor(INK);
  w.text(text, left, doc.y, { width });
}

export function generateQuotePdf(input: QuotePdfInput): Promise<Buffer> {
  const t = docTexts(input.locale);
  const day = (iso: string) => longDay(iso, input.locale);
  const q = input.quote;
  const intro = [q.intro, q.kind === 'CONTRACT' && q.contractFrequencyMonths ? t.contract(q.contractFrequencyMonths) : null].filter(Boolean).join('\n');
  return render(input, {
    title: t.quote,
    number: q.number,
    meta: [`${t.date} : ${day(q.date)}`, ...(q.validUntil ? [`${t.validUntil} : ${day(q.validUntil)}`] : [])],
    subject: q.title,
    intro: intro || null,
  }, ({ doc, w, t: l, left, width, ensure }) => {
    if (q.notes) {
      ensure(50);
      doc.moveDown(0.8);
      block(w, doc, l.notes, q.notes, left, width);
    }
    ensure(110);
    doc.moveDown(1);
    const sy = doc.y;
    doc.fontSize(10).fillColor(INK);
    w.text(l.acceptance, left + width / 2, sy, { width: width / 2, bold: true });
    doc.fontSize(8).fillColor(MUTED);
    w.text(l.acceptanceHint, left + width / 2, doc.y + 2, { width: width / 2 });
    doc.roundedRect(left + width / 2, doc.y + 4, width / 2, 70, 4).lineWidth(0.8).strokeColor(RULE).stroke();
  });
}

export function generateInvoicePdf(input: InvoicePdfInput): Promise<Buffer> {
  const t = docTexts(input.locale);
  const day = (iso: string) => longDay(iso, input.locale);
  const inv = input.invoice;
  const credit = inv.kind === 'CREDIT_NOTE';
  return render(input, {
    title: credit ? t.creditNote : t.invoice,
    number: inv.number,
    meta: [
      `${t.date} : ${day(inv.issueDate)}`,
      ...(inv.serviceDate ? [`${t.serviceDate} : ${day(inv.serviceDate)}`] : []),
      ...(!credit && inv.dueDate ? [`${t.dueDate} : ${day(inv.dueDate)}`] : []),
    ],
    subject: inv.title,
    intro: credit && inv.creditedNumber ? t.credits(inv.creditedNumber) : null,
  }, ({ doc, w, t: l, left, width, ensure, money, grossCents }) => {
    if (!credit && inv.paidCents > 0) {
      const tx = left + width * 0.5;
      const tw = width * 0.5;
      for (const [label, value, bold] of [[l.paid, money(inv.paidCents), false], [l.due, money(Math.max(0, grossCents - inv.paidCents)), true]] as const) {
        const y = doc.y;
        doc.fontSize(10).fillColor(INK);
        w.text(label, tx, y, { width: tw * 0.62, bold });
        w.text(value, tx + tw * 0.62, y, { width: tw * 0.38, align: 'right', bold });
        doc.y = y + 14;
      }
    }
    doc.moveDown(0.8);
    if (!credit) {
      ensure(90);
      // Les pénalités de retard dépendent du pays de la société (mentions obligatoires en France)
      const penalty = (input.company.countryCode ?? 'FR') === 'FR' ? l.latePenaltyFr : l.latePenalty;
      const lines = [inv.dueDate ? l.paymentBy(day(inv.dueDate)) : null, penalty].filter(Boolean).join('\n');
      block(w, doc, l.payment, lines, left, width);
      if (input.company.bankDetails) {
        doc.moveDown(0.5);
        block(w, doc, l.bank, input.company.bankDetails, left, width);
      }
    }
    if (inv.notes) {
      ensure(40);
      doc.moveDown(0.5);
      block(w, doc, l.notes, inv.notes, left, width);
    }
  }, input.facturxXml);
}
