/**
 * Facturation des abonnements (télésurveillance, maintenance…) : périodes dues d'un contrat, à terme à échoir.
 *
 * Un contrat est facturé par périodes de `billingMonths` mois à partir de sa date de début ; `billedUntil` garde la
 * fin de la dernière période facturée, si bien qu'une période n'est jamais facturée deux fois. La dernière période
 * d'un contrat qui se termine est facturée au prorata des jours.
 */
import { addDays, addMonths } from '@itineo/shared';

/** Rattrapage maximal en une fois (3 ans de facturation mensuelle) */
export const MAX_PERIODS_PER_RUN = 36;

export interface BillableContract {
  status: string;
  startDate: string;
  endDate: string | null;
  billingMonths: number | null;
  billedUntil: string | null;
  annualPriceCents: number | null;
}

export interface DuePeriod { start: string; end: string; amountCents: number }

const days = (from: string, to: string) => Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000) + 1;

/** Périodes à facturer dont le début tombe au plus tard le jour `until` */
export function duePeriods(c: BillableContract, until: string): DuePeriod[] {
  if (c.status !== 'ACTIVE' || !c.billingMonths || c.annualPriceCents == null) return [];
  const m = c.billingMonths;
  const full = Math.round((c.annualPriceCents * m) / 12);
  const out: DuePeriod[] = [];
  let start = c.billedUntil ? addDays(c.billedUntil, 1) : c.startDate;
  while (out.length < MAX_PERIODS_PER_RUN && start <= until && (!c.endDate || start <= c.endDate)) {
    const fullEnd = addDays(addMonths(start, m), -1);
    const end = c.endDate && c.endDate < fullEnd ? c.endDate : fullEnd;
    const amountCents = end === fullEnd ? full : Math.round((full * days(start, end)) / days(start, fullEnd));
    out.push({ start, end, amountCents });
    start = addDays(end, 1);
  }
  return out;
}
