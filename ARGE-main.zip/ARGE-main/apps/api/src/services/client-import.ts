/**
 * Import de clients, sites et matériels depuis un fichier (voir import-table.ts pour la lecture).
 *
 * Une ligne = un matériel (ou un site, ou un client sans matériel). Les lignes d'un même client
 * (même référence, sinon même nom) sont regroupées, puis celles d'un même site.
 * Rien n'est écrasé : un client déjà présent (même référence, même n° d'abonné ou même nom) est complété,
 * un matériel déjà présent (même n° de série sur le site) n'est pas recréé. Réimporter le même fichier
 * ne crée donc pas de doublons.
 */
import { and, eq, inArray, isNull, or } from 'drizzle-orm';
import {
  CLIENT_IMPORT_FIELDS,
  type ClientImportField, type ClientImportIssue, type ClientImportPreview,
} from '@itineo/shared';
import { db, schema } from '../db/client.js';

export const MAX_IMPORT_ROWS = 5000;

/** Minuscules, sans accents ni ponctuation : « N° de série » → « n de serie » */
export function normalize(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/n[°º]|\bno\./g, 'n ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

/** Titres de colonnes reconnus (déjà normalisés), pour chaque colonne Itinéos */
const HEADER_WORDS: Record<ClientImportField, string[]> = {
  clientName: ['client', 'nom client', 'nom du client', 'raison sociale', 'nom raison sociale', 'societe', 'nom', 'denomination', 'customer', 'client name', 'name'],
  clientType: ['type client', 'type de client', 'type', 'categorie client'],
  clientRef: ['code client', 'ref client', 'reference client', 'n client', 'numero client', 'num client', 'id client', 'code', 'customer id'],
  subscriberNumber: ['n abonne', 'n d abonne', 'numero abonne', 'numero d abonne', 'num abonne', 'abonne', 'code abonne', 'n telesurveillance', 'numero telesurveillance', 'subscriber number'],
  email: ['email', 'e mail', 'mail', 'courriel', 'adresse mail', 'adresse email', 'adresse e mail'],
  phone: ['telephone', 'tel', 'portable', 'mobile', 'tel fixe', 'phone', 'n telephone'],
  address: ['adresse', 'adresse client', 'adresse 1', 'adresse1', 'rue', 'voie', 'address'],
  postalCode: ['cp', 'code postal', 'cp client', 'code postal client', 'postal code', 'zip'],
  city: ['ville', 'commune', 'localite', 'ville client', 'city'],
  siren: ['siren', 'siret', 'n siren', 'n siret'],
  vatNumber: ['tva', 'n tva', 'numero tva', 'tva intracommunautaire', 'n tva intracommunautaire', 'vat', 'vat number'],
  clientNotes: ['notes', 'note', 'remarques', 'commentaire', 'commentaires', 'observations', 'notes client', 'remarques client', 'commentaire client'],
  contactName: ['contact', 'nom contact', 'nom du contact', 'interlocuteur'],
  contactPhone: ['tel contact', 'telephone contact', 'portable contact', 'telephone du contact'],
  contactEmail: ['email contact', 'mail contact', 'e mail contact', 'email du contact'],
  siteName: ['site', 'nom site', 'nom du site', 'lieu', 'lieu d intervention', 'chantier', 'etablissement'],
  siteAddress: ['adresse site', 'adresse du site', 'adresse intervention', 'adresse d intervention', 'adresse chantier'],
  sitePostalCode: ['cp site', 'code postal site', 'code postal du site', 'cp intervention'],
  siteCity: ['ville site', 'ville du site', 'commune site', 'ville intervention'],
  accessNotes: ['acces', 'consignes', 'consignes d acces', 'code acces', 'code d acces', 'digicode', 'infos acces', 'acces site'],
  category: ['materiel', 'type materiel', 'type de materiel', 'equipement', 'type equipement', 'type d equipement', 'categorie', 'famille', 'appareil'],
  brand: ['marque', 'fabricant', 'constructeur', 'brand'],
  model: ['modele', 'ref materiel', 'reference materiel', 'reference produit', 'model'],
  serialNumber: ['n serie', 'n de serie', 'numero de serie', 'num serie', 'serie', 'sn', 's n', 'serial', 'serial number'],
  location: ['emplacement', 'localisation', 'position', 'zone', 'location'],
  installedAt: ['date pose', 'date de pose', 'pose', 'date installation', 'date d installation', 'mise en service', 'date mise en service', 'date de mise en service'],
  warrantyUntil: ['fin garantie', 'fin de garantie', 'garantie', 'date fin garantie', 'garantie jusqu au'],
  underContract: ['sous contrat', 'contrat', 'sous contrat maintenance', 'sous contrat de maintenance', 'maintenance'],
  equipmentNotes: ['notes materiel', 'remarques materiel', 'commentaire materiel', 'observations materiel', 'notes equipement'],
};

/** Colonne Itinéos de chaque titre du fichier (chaque colonne Itinéos n'est prise qu'une fois) */
export function guessMapping(headers: string[]): (ClientImportField | null)[] {
  const used = new Set<ClientImportField>();
  return headers.map((h) => {
    const n = normalize(h);
    const field = CLIENT_IMPORT_FIELDS.find((f) => !used.has(f) && HEADER_WORDS[f].includes(n)) ?? null;
    if (field) used.add(field);
    return field;
  });
}

// ─── Valeurs ──────────────────────────────────────────────────────────────

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** « 25/03/2021 », « 25-03-21 », « 2021-03-25 » ou n° de jour Excel → « 2021-03-25 » */
export function parseDate(s: string): string | null {
  let y: number, m: number, d: number;
  let match: RegExpExecArray | null;
  if ((match = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s))) [y, m, d] = [+match[1], +match[2], +match[3]];
  else if ((match = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2}|\d{4})$/.exec(s))) {
    [d, m, y] = [+match[1], +match[2], +match[3]];
    if (y < 100) y += y < 70 ? 2000 : 1900;
  } else if (/^\d{4,5}(\.\d+)?$/.test(s)) {
    // Date Excel : nombre de jours depuis le 30/12/1899
    const date = new Date(Date.UTC(1899, 11, 30) + Math.floor(Number(s)) * 86400000);
    return date.toISOString().slice(0, 10);
  } else return null;
  const date = new Date(Date.UTC(y, m - 1, d));
  if (date.getUTCFullYear() !== y || date.getUTCMonth() !== m - 1 || date.getUTCDate() !== d) return null;
  return date.toISOString().slice(0, 10);
}

const isYes = (s: string) => /^(oui|o|yes|y|x|1|vrai|true)$/i.test(s.trim());
const isIndividual = (s: string) => /^(particulier|individuel|prive|private|individual|p)$/.test(normalize(s));

// ─── Plan d'import ────────────────────────────────────────────────────────

type ClientInsert = typeof schema.clients.$inferInsert;
type SiteInsert = Omit<typeof schema.sites.$inferInsert, 'clientId'>;
type EquipmentInsert = Omit<typeof schema.equipments.$inferInsert, 'siteId'>;

interface PlannedSite {
  existingId: string | null;
  data: SiteInsert;
  equipments: EquipmentInsert[];
  /** N° de série et descriptions déjà présents (base et fichier), pour éviter les doublons */
  known: Set<string>;
}

interface PlannedClient {
  existingId: string | null;
  data: Omit<ClientInsert, 'groupId' | 'companyId' | 'agencyId'>;
  /** Client déjà présent : champs vides à compléter */
  fill: Partial<ClientInsert>;
  contacts: { name: string; phone?: string; email?: string }[];
  knownContacts: Set<string>;
  sites: Map<string, PlannedSite>;
  /** Sites existants du client, par clé (nom, sinon adresse) */
  existingSites: Map<string, { id: string; name: string; city: string | null }>;
  firstExistingSite: { id: string; name: string; city: string | null } | null;
}

export interface ImportPlan {
  preview: ClientImportPreview;
  clients: PlannedClient[];
}

interface Target { groupId: string; companyId: string; agencyId: string | null; countryCode: string }

const equipmentKey = (e: { serialNumber?: string | null; category: string; brand?: string | null; model?: string | null; location?: string | null }) =>
  e.serialNumber ? `sn:${normalize(e.serialNumber)}` : `d:${normalize([e.category, e.brand, e.model, e.location].filter(Boolean).join(' '))}`;

const siteKey = (name: string | undefined, address: string | undefined, city: string | undefined) =>
  name ? `n:${normalize(name)}` : address ? `a:${normalize(`${address} ${city ?? ''}`)}` : '';

export async function planImport(table: string[][], mapping: (ClientImportField | null)[], target: Target): Promise<ImportPlan> {
  const [headers, ...body] = table;
  const issues: ClientImportIssue[] = [];
  const columns = headers.map((header, i) => ({ header, field: mapping[i] ?? null }));
  const emptyPreview = (): ClientImportPreview => ({
    columns, rows: body.length, clientsNew: 0, clientsExisting: 0, sitesNew: 0, equipmentsNew: 0, equipmentsExisting: 0,
    contactsNew: 0, rowsSkipped: 0, issues, sample: [],
  });
  if (body.length > MAX_IMPORT_ROWS) {
    issues.push({ line: MAX_IMPORT_ROWS + 2, code: 'tooManyRows', value: String(MAX_IMPORT_ROWS) });
    return { preview: emptyPreview(), clients: [] };
  }

  // Clients déjà présents dans la société (ceux de l'agence visée et ceux partagés)
  const existing = await db
    .select({
      id: schema.clients.id, name: schema.clients.name, externalRef: schema.clients.externalRef,
      subscriberNumber: schema.clients.subscriberNumber, postalCode: schema.clients.postalCode,
      email: schema.clients.email, phone: schema.clients.phone, address: schema.clients.address, city: schema.clients.city,
      siren: schema.clients.siren, vatNumber: schema.clients.vatNumber, notes: schema.clients.notes,
    })
    .from(schema.clients)
    .where(and(
      eq(schema.clients.groupId, target.groupId),
      eq(schema.clients.companyId, target.companyId),
      target.agencyId ? or(eq(schema.clients.agencyId, target.agencyId), isNull(schema.clients.agencyId)) : isNull(schema.clients.agencyId),
    ));
  const byRef = new Map(existing.filter((c) => c.externalRef).map((c) => [normalize(c.externalRef!), c]));
  const bySubscriber = new Map(existing.filter((c) => c.subscriberNumber).map((c) => [normalize(c.subscriberNumber!), c]));
  const byName = new Map(existing.map((c) => [normalize(c.name), c]));

  const clients = new Map<string, PlannedClient>();
  let rowsSkipped = 0;

  for (const [index, cells] of body.entries()) {
    const line = index + 2;
    const get = (f: ClientImportField) => {
      const i = mapping.indexOf(f);
      const v = i >= 0 ? cells[i]?.trim() : '';
      return v ? v : undefined;
    };
    const name = get('clientName');
    if (!name) {
      rowsSkipped++;
      issues.push({ line, code: 'missingName' });
      continue;
    }

    let email = get('email');
    if (email && !EMAIL.test(email)) {
      issues.push({ line, code: 'badEmail', value: email });
      email = undefined;
    }
    let siren = get('siren')?.replace(/\s/g, '');
    if (siren && !/^\d{9}(\d{5})?$/.test(siren)) {
      issues.push({ line, code: 'badSiren', value: siren });
      siren = undefined;
    }
    const date = (f: 'installedAt' | 'warrantyUntil') => {
      const v = get(f);
      if (!v) return undefined;
      const d = parseDate(v);
      if (!d) issues.push({ line, code: 'badDate', value: v });
      return d ?? undefined;
    };
    const ref = get('clientRef');
    const subscriber = get('subscriberNumber');

    // Le client : celui d'une ligne précédente, sinon un client déjà présent, sinon un nouveau
    const key = ref ? `r:${normalize(ref)}` : `n:${normalize(name)}`;
    let client = clients.get(key);
    if (!client) {
      const found = (ref && byRef.get(normalize(ref)))
        || (subscriber && bySubscriber.get(normalize(subscriber)))
        || byName.get(normalize(name))
        || null;
      const data = {
        type: get('clientType') && isIndividual(get('clientType')!) ? 'INDIVIDUAL' as const : 'COMPANY' as const,
        name,
        email: email ?? null,
        phone: get('phone') ?? null,
        address: get('address') ?? null,
        postalCode: get('postalCode') ?? null,
        city: get('city') ?? null,
        countryCode: target.countryCode,
        externalRef: ref ?? null,
        siren: siren ?? null,
        vatNumber: get('vatNumber') ?? null,
        subscriberNumber: subscriber ?? null,
        notes: get('clientNotes') ?? null,
      };
      const fill: Partial<ClientInsert> = {};
      if (found) {
        // Seuls les champs vides du client existant sont complétés
        for (const k of ['email', 'phone', 'address', 'postalCode', 'city', 'externalRef', 'siren', 'vatNumber', 'subscriberNumber', 'notes'] as const) {
          if (!found[k] && data[k]) fill[k] = data[k];
        }
      }
      client = {
        existingId: found?.id ?? null, data, fill, contacts: [], knownContacts: new Set(), sites: new Map(),
        existingSites: new Map(), firstExistingSite: null,
      };
      clients.set(key, client);
    } else if (subscriber && client.data.subscriberNumber && normalize(subscriber) !== normalize(client.data.subscriberNumber)) {
      // Un client avec plusieurs n° d'abonné (un par site) : les suivants sont notés sur le site
      issues.push({ line, code: 'otherSubscriber', value: subscriber });
    }

    const contactName = get('contactName');
    if (contactName && !client.knownContacts.has(normalize(contactName))) {
      client.knownContacts.add(normalize(contactName));
      const contactEmail = get('contactEmail');
      client.contacts.push({
        name: contactName,
        phone: get('contactPhone'),
        email: contactEmail && EMAIL.test(contactEmail) ? contactEmail : undefined,
      });
    }

    // Le site : nommé dans le fichier, sinon son adresse, sinon le site principal du client
    const siteName = get('siteName');
    const siteAddress = get('siteAddress');
    const siteCity = get('siteCity');
    const sKey = siteKey(siteName, siteAddress, siteCity);
    let site = client.sites.get(sKey);
    if (!site) {
      const extraSubscriber = subscriber && client.data.subscriberNumber && normalize(subscriber) !== normalize(client.data.subscriberNumber)
        ? `N° d’abonné : ${subscriber}` : undefined;
      site = {
        existingId: null,
        data: {
          name: siteName ?? (siteAddress ? [siteAddress, siteCity].filter(Boolean).join(', ') : name),
          address: siteAddress ?? (sKey ? null : client.data.address ?? null),
          postalCode: get('sitePostalCode') ?? (sKey ? null : client.data.postalCode ?? null),
          city: siteCity ?? (sKey ? null : client.data.city ?? null),
          countryCode: target.countryCode,
          accessNotes: [extraSubscriber, get('accessNotes')].filter(Boolean).join(' · ') || null,
        },
        equipments: [],
        known: new Set(),
      };
      client.sites.set(sKey, site);
    }

    // Le matériel
    const category = get('category');
    const brand = get('brand');
    const model = get('model');
    const serialNumber = get('serialNumber');
    if (category || brand || model || serialNumber) {
      const equipment: EquipmentInsert = {
        category: category ?? model ?? 'Matériel',
        brand: brand ?? null,
        model: model ?? null,
        serialNumber: serialNumber ?? null,
        location: get('location') ?? null,
        installedAt: date('installedAt') ?? null,
        warrantyUntil: date('warrantyUntil') ?? null,
        underContract: get('underContract') ? isYes(get('underContract')!) : false,
        notes: get('equipmentNotes') ?? null,
      };
      const eKey = equipmentKey({ ...equipment, category: equipment.category });
      if (site.known.has(eKey)) {
        issues.push({ line, code: 'duplicateEquipment', value: serialNumber ?? equipment.category });
      } else {
        site.known.add(eKey);
        site.equipments.push(equipment);
      }
    }
  }

  // Clients déjà présents : leurs sites et matériels, pour ne rien créer en double
  const existingIds = [...clients.values()].map((c) => c.existingId).filter((id): id is string => !!id);
  let equipmentsExisting = 0;
  if (existingIds.length) {
    const sites = await db
      .select({ id: schema.sites.id, clientId: schema.sites.clientId, name: schema.sites.name, address: schema.sites.address, city: schema.sites.city })
      .from(schema.sites)
      .where(inArray(schema.sites.clientId, existingIds))
      .orderBy(schema.sites.name);
    const equipments = sites.length
      ? await db
        .select({ siteId: schema.equipments.siteId, serialNumber: schema.equipments.serialNumber, category: schema.equipments.category, brand: schema.equipments.brand, model: schema.equipments.model, location: schema.equipments.location })
        .from(schema.equipments)
        .where(inArray(schema.equipments.siteId, sites.map((s) => s.id)))
      : [];
    const contacts = await db
      .select({ clientId: schema.contacts.clientId, name: schema.contacts.name })
      .from(schema.contacts)
      .where(inArray(schema.contacts.clientId, existingIds));
    for (const client of clients.values()) {
      if (!client.existingId) continue;
      const own = sites.filter((s) => s.clientId === client.existingId);
      client.firstExistingSite = own[0] ?? null;
      for (const s of own) {
        client.existingSites.set(`n:${normalize(s.name)}`, s);
        if (s.address) client.existingSites.set(`a:${normalize(`${s.address} ${s.city ?? ''}`)}`, s);
      }
      client.contacts = client.contacts.filter((c) => !contacts.some((x) => x.clientId === client.existingId && normalize(x.name) === normalize(c.name)));
      for (const [key, site] of client.sites) {
        const match = key === '' ? client.firstExistingSite : client.existingSites.get(key);
        if (!match) continue;
        site.existingId = match.id;
        const present = new Set(equipments.filter((e) => e.siteId === match.id).map((e) => equipmentKey(e)));
        const before = site.equipments.length;
        site.equipments = site.equipments.filter((e) => !present.has(equipmentKey({ ...e, category: e.category })));
        equipmentsExisting += before - site.equipments.length;
        site.data.name = match.name;
        site.data.city = match.city;
      }
    }
  }

  const list = [...clients.values()];
  const allSites = list.flatMap((c) => [...c.sites.values()]);
  const preview: ClientImportPreview = {
    columns,
    rows: body.length,
    clientsNew: list.filter((c) => !c.existingId).length,
    clientsExisting: list.filter((c) => c.existingId).length,
    sitesNew: allSites.filter((s) => !s.existingId).length,
    equipmentsNew: allSites.reduce((n, s) => n + s.equipments.length, 0),
    equipmentsExisting,
    contactsNew: list.reduce((n, c) => n + c.contacts.length, 0),
    rowsSkipped,
    issues,
    sample: list.slice(0, 5).map((c) => ({
      name: c.existingId ? (existing.find((e) => e.id === c.existingId)?.name ?? c.data.name) : c.data.name,
      existing: !!c.existingId,
      subscriberNumber: c.data.subscriberNumber ?? null,
      sites: [...c.sites.values()].map((s) => ({
        name: s.data.name,
        city: s.data.city ?? null,
        equipments: s.equipments.map((e) => [e.category, e.brand, e.model, e.serialNumber && `n° ${e.serialNumber}`].filter(Boolean).join(' · ')),
      })),
    })),
  };
  return { preview, clients: list };
}

/** Enregistre le plan en une seule transaction ; renvoie le nombre d'éléments créés */
export async function applyImport(plan: ImportPlan, target: Target) {
  return db.transaction(async (tx) => {
    let clientsNew = 0, sitesNew = 0, equipmentsNew = 0, contactsNew = 0, clientsUpdated = 0;
    for (const c of plan.clients) {
      let clientId = c.existingId;
      if (!clientId) {
        const [row] = await tx.insert(schema.clients).values({
          ...c.data, groupId: target.groupId, companyId: target.companyId, agencyId: target.agencyId,
        }).returning({ id: schema.clients.id });
        clientId = row.id;
        clientsNew++;
      } else if (Object.keys(c.fill).length) {
        await tx.update(schema.clients).set(c.fill).where(eq(schema.clients.id, clientId));
        clientsUpdated++;
      }
      if (c.contacts.length) {
        await tx.insert(schema.contacts).values(c.contacts.map((ct) => ({ ...ct, clientId: clientId! })));
        contactsNew += c.contacts.length;
      }
      for (const s of c.sites.values()) {
        let siteId = s.existingId;
        if (!siteId) {
          const [row] = await tx.insert(schema.sites).values({ ...s.data, clientId }).returning({ id: schema.sites.id });
          siteId = row.id;
          sitesNew++;
        }
        if (s.equipments.length) {
          await tx.insert(schema.equipments).values(s.equipments.map((e) => ({ ...e, siteId: siteId! })));
          equipmentsNew += s.equipments.length;
        }
      }
    }
    return { clientsNew, clientsUpdated, sitesNew, equipmentsNew, contactsNew };
  });
}

/** Fichier modèle à remplir (CSV pour Excel, séparateur point-virgule) */
export function importTemplateCsv(): string {
  const header = ['Nom du client', 'Type', 'Code client', 'N° abonné', 'E-mail', 'Téléphone', 'Adresse', 'Code postal', 'Ville',
    'SIRET', 'Contact', 'Tél contact', 'Nom du site', 'Adresse du site', 'CP site', 'Ville site', 'Consignes d’accès',
    'Type de matériel', 'Marque', 'Modèle', 'N° de série', 'Emplacement', 'Date de pose', 'Sous contrat'];
  const rows = [
    ['Pharmacie des Tilleuls', 'Entreprise', 'C0042', 'TS-04512', 'contact@pharmacie-exemple.fr', '03 80 00 00 00', '12 rue des Tilleuls', '21000', 'Dijon',
      '', 'Mme Martin', '06 00 00 00 00', 'Pharmacie', '', '', '', 'Clé au coffre, code 1234',
      'Centrale intrusion', 'Marque A', 'Modèle 8 zones', '1A2B-3C4D', 'Réserve', '15/03/2021', 'oui'],
    ['Pharmacie des Tilleuls', 'Entreprise', 'C0042', 'TS-04512', '', '', '', '', '',
      '', '', '', 'Pharmacie', '', '', '', '',
      'Détecteur', 'Marque A', 'IR 12 m', '5E6F-7A8B', 'Entrée', '15/03/2021', 'oui'],
    ['M. Durand', 'Particulier', '', 'TS-07730', '', '06 11 11 11 11', '4 impasse des Lilas', '21800', 'Quetigny',
      '', '', '', '', '', '', '', '',
      'Caméra', 'Marque B', 'Dôme 4 MP', 'CAM-0091', 'Garage', '02/09/2023', 'non'],
  ];
  const cell = (v: string) => (/[;"]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
  return '﻿' + [header, ...rows].map((r) => r.map(cell).join(';')).join('\r\n') + '\r\n';
}
