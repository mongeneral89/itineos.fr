/**
 * Prélèvement SEPA (SDD CORE) : contrôle des IBAN, BIC et identifiants créanciers (ICS), et fichier
 * « pain.008.001.02 » que la société dépose sur le site de sa banque.
 *
 * Le fichier ne contient que des caractères acceptés par toutes les banques (alphabet latin de base) :
 * les accents sont retirés, les autres caractères remplacés par une espace.
 */

/** « fr76 3000 6000 … » → « FR7630006000… » */
export const compactIban = (s: string) => s.replace(/\s+/g, '').toUpperCase();

/** Reste de la division par 97 d'un numéro où les lettres valent 10 à 35 (contrôle ISO 7064) */
function mod97(s: string): number {
  let rest = 0;
  for (const ch of s) {
    const v = /[A-Z]/.test(ch) ? String(ch.charCodeAt(0) - 55) : ch;
    for (const d of v) rest = (rest * 10 + Number(d)) % 97;
  }
  return rest;
}

export function ibanValid(raw: string): boolean {
  const iban = compactIban(raw);
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return false;
  if (iban.startsWith('FR') && iban.length !== 27) return false;
  return mod97(iban.slice(4) + iban.slice(0, 4)) === 1;
}

export const bicValid = (s: string) => /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(s.replace(/\s+/g, '').toUpperCase());

/** Identifiant créancier SEPA (ICS), ex. FR12ZZZ123456 : la clé ne porte pas sur le code d'activité (« ZZZ ») */
export function creditorIdValid(raw: string): boolean {
  const id = raw.replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{3}[A-Z0-9]{1,28}$/.test(id)) return false;
  return mod97(id.slice(7) + id.slice(0, 4)) === 1;
}

/** Samedi ou dimanche : les banques ne prélèvent pas ces jours-là */
export const isWeekend = (day: string) => [0, 6].includes(new Date(`${day}T00:00:00Z`).getUTCDay());

/** Première date de prélèvement possible : deux jours après aujourd'hui, un jour de semaine */
export function earliestCollectionDate(today: string): string {
  const d = new Date(`${today}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 2);
  while ([0, 6].includes(d.getUTCDay())) d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

/** IBAN affiché à l'écran : seuls les 4 derniers caractères (« FR76 •••• •••• 1234 ») */
export function maskIban(raw: string): string {
  const iban = compactIban(raw);
  return `${iban.slice(0, 4)} •••• •••• ${iban.slice(-4)}`;
}

/** Texte accepté dans un fichier SEPA : sans accent, caractères de l'alphabet latin de base, longueur limitée */
export function sepaText(s: string, max: number): string {
  return s
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[’‘]/g, "'").replace(/[«»“”]/g, '"')
    .replace(/[^A-Za-z0-9/\-?:().,'+ ]/g, ' ')
    .replace(/\s+/g, ' ').trim()
    .slice(0, max).trim();
}

/** Identifiant (référence de mandat, n° de facture…) : 35 caractères, sans « / » au début, à la fin ni doublé */
export function sepaId(s: string): string {
  return sepaText(s, 35).replace(/\s/g, '').replace(/\/{2,}/g, '/').replace(/^\/+|\/+$/g, '') || 'NOTPROVIDED';
}

const xml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
const amount = (cents: number) => (cents / 100).toFixed(2);

export interface DirectDebitTx {
  /** Référence de bout en bout : le n° de facture */
  endToEndId: string;
  amountCents: number;
  mandateRef: string;
  mandateSignedOn: string;
  /** FRST : premier prélèvement du mandat ; RCUR : les suivants */
  sequence: 'FRST' | 'RCUR';
  debtorName: string;
  debtorIban: string;
  debtorBic: string | null;
  /** Libellé lu par le client sur son relevé (140 caractères) */
  remittance: string;
}

export interface DirectDebitFile {
  messageId: string;
  createdAt: Date;
  collectionDate: string;
  creditor: { name: string; iban: string; bic: string | null; creditorId: string };
  transactions: DirectDebitTx[];
}

const agent = (bic: string | null) => (bic
  ? `<FinInstnId><BIC>${xml(bic.replace(/\s+/g, '').toUpperCase())}</BIC></FinInstnId>`
  : '<FinInstnId><Othr><Id>NOTPROVIDED</Id></Othr></FinInstnId>');

/** Fichier pain.008.001.02 : un bloc de paiement par type de prélèvement (premier, récurrent) */
export function directDebitXml(f: DirectDebitFile): string {
  const total = (txs: DirectDebitTx[]) => txs.reduce((s, t) => s + t.amountCents, 0);
  const created = f.createdAt.toISOString().slice(0, 19);
  const blocks = (['FRST', 'RCUR'] as const).map((seq) => ({ seq, txs: f.transactions.filter((t) => t.sequence === seq) })).filter((b) => b.txs.length);
  const creditorName = sepaText(f.creditor.name, 70);
  const out: string[] = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.008.001.02" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">',
    '<CstmrDrctDbtInitn>',
    '<GrpHdr>',
    `<MsgId>${xml(sepaId(f.messageId))}</MsgId>`,
    `<CreDtTm>${created}</CreDtTm>`,
    `<NbOfTxs>${f.transactions.length}</NbOfTxs>`,
    `<CtrlSum>${amount(total(f.transactions))}</CtrlSum>`,
    `<InitgPty><Nm>${xml(creditorName)}</Nm></InitgPty>`,
    '</GrpHdr>',
  ];
  for (const b of blocks) {
    out.push(
      '<PmtInf>',
      `<PmtInfId>${xml(sepaId(`${f.messageId}-${b.seq}`))}</PmtInfId>`,
      '<PmtMtd>DD</PmtMtd>',
      '<BtchBookg>true</BtchBookg>',
      `<NbOfTxs>${b.txs.length}</NbOfTxs>`,
      `<CtrlSum>${amount(total(b.txs))}</CtrlSum>`,
      `<PmtTpInf><SvcLvl><Cd>SEPA</Cd></SvcLvl><LclInstrm><Cd>CORE</Cd></LclInstrm><SeqTp>${b.seq}</SeqTp></PmtTpInf>`,
      `<ReqdColltnDt>${f.collectionDate}</ReqdColltnDt>`,
      `<Cdtr><Nm>${xml(creditorName)}</Nm></Cdtr>`,
      `<CdtrAcct><Id><IBAN>${xml(compactIban(f.creditor.iban))}</IBAN></Id></CdtrAcct>`,
      `<CdtrAgt>${agent(f.creditor.bic)}</CdtrAgt>`,
      '<ChrgBr>SLEV</ChrgBr>',
      `<CdtrSchmeId><Id><PrvtId><Othr><Id>${xml(f.creditor.creditorId.replace(/\s+/g, '').toUpperCase())}</Id><SchmeNm><Prtry>SEPA</Prtry></SchmeNm></Othr></PrvtId></Id></CdtrSchmeId>`,
    );
    for (const t of b.txs) {
      out.push(
        '<DrctDbtTxInf>',
        `<PmtId><EndToEndId>${xml(sepaId(t.endToEndId))}</EndToEndId></PmtId>`,
        `<InstdAmt Ccy="EUR">${amount(t.amountCents)}</InstdAmt>`,
        `<DrctDbtTx><MndtRltdInf><MndtId>${xml(sepaId(t.mandateRef))}</MndtId><DtOfSgntr>${t.mandateSignedOn}</DtOfSgntr></MndtRltdInf></DrctDbtTx>`,
        `<DbtrAgt>${agent(t.debtorBic)}</DbtrAgt>`,
        `<Dbtr><Nm>${xml(sepaText(t.debtorName, 70))}</Nm></Dbtr>`,
        `<DbtrAcct><Id><IBAN>${xml(compactIban(t.debtorIban))}</IBAN></Id></DbtrAcct>`,
        `<RmtInf><Ustrd>${xml(sepaText(t.remittance, 140))}</Ustrd></RmtInf>`,
        '</DrctDbtTxInf>',
      );
    }
    out.push('</PmtInf>');
  }
  out.push('</CstmrDrctDbtInitn>', '</Document>');
  return out.join('\n') + '\n';
}
