/**
 * Relances des factures impayées : 1 rappel, 2 relance, 3 mise en demeure, envoyés par e-mail au client avec la
 * facture en pièce jointe, tant de jours après l'échéance (réglable par société).
 *
 * Un niveau à la fois, au moins 7 jours entre deux relances : une facture très en retard au moment où l'envoi
 * automatique est activé reçoit d'abord le rappel, pas directement la mise en demeure. Une facture présentée au
 * prélèvement (lot pas encore encaissé) ou dont les relances sont suspendues n'est pas relancée.
 */
import { and, asc, eq, inArray, lt } from 'drizzle-orm';
import { readFile } from 'node:fs/promises';
import { db, schema } from '../db/client.js';
import { buildPdf, settlements } from '../routes/invoices.js';
import { todayIn } from './contracts.js';
import { clientLocale, docTexts, formatLocale, longDay } from './doc-i18n.js';
import { sendMail } from './mail.js';

export const DUNNING_DEFAULT_DAYS = [7, 15, 30];
/** Jours minimum entre deux relances d'une même facture */
export const DUNNING_MIN_GAP = 7;

const addDays = (day: string, n: number) => {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
export const daysBetween = (from: string, to: string) => Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400_000);

export interface DunningState {
  dueDate: string | null;
  /** Dernier niveau envoyé (0 : aucun) */
  level: number;
  lastOn: string | null;
  paused: boolean;
  /** Présentée au prélèvement, lot pas encore encaissé */
  inCollection: boolean;
}

/** Prochaine relance d'une facture impayée : son niveau et le jour où elle part ; null s'il n'y en a plus */
export function nextReminder(s: DunningState, days: number[]): { level: 1 | 2 | 3; on: string } | null {
  if (!s.dueDate || s.paused || s.inCollection || s.level >= 3) return null;
  const level = (s.level + 1) as 1 | 2 | 3;
  const byDue = addDays(s.dueDate, days[level - 1] ?? DUNNING_DEFAULT_DAYS[level - 1]);
  const byGap = s.lastOn ? addDays(s.lastOn, DUNNING_MIN_GAP) : byDue;
  return { level, on: byDue > byGap ? byDue : byGap };
}

/** Factures émises, échues et pas entièrement réglées d'une société, avec leur état de relance */
export async function overdueInvoices(companyId: string, today: string) {
  const inv = schema.invoices;
  const rows = await db
    .select({
      id: inv.id, number: inv.number, agencyId: inv.agencyId, clientId: inv.clientId, title: inv.title, dueDate: inv.dueDate,
      grossCents: inv.grossCents, currency: inv.currency, level: inv.dunningLevel, lastOn: inv.dunningLastOn, paused: inv.dunningPaused,
      batchStatus: schema.sepaBatches.status, clientName: schema.clients.name, clientEmail: schema.clients.email,
    })
    .from(inv)
    .innerJoin(schema.clients, eq(schema.clients.id, inv.clientId))
    .leftJoin(schema.sepaBatches, eq(schema.sepaBatches.id, inv.sepaBatchId))
    .where(and(eq(inv.companyId, companyId), eq(inv.kind, 'INVOICE'), eq(inv.status, 'ISSUED'), lt(inv.dueDate, today)))
    .orderBy(asc(inv.dueDate), asc(inv.number));
  const { paid, credited } = await settlements(rows.map((r) => r.id));
  return rows
    .map(({ batchStatus, ...r }) => ({
      ...r,
      remainingCents: Math.max(0, r.grossCents - (paid.get(r.id) ?? 0) - (credited.get(r.id) ?? 0)),
      daysLate: daysBetween(r.dueDate!, today),
      inCollection: batchStatus === 'SENT',
    }))
    .filter((r) => r.remainingCents > 0);
}

/**
 * Envoie la relance de ce niveau au client et la note sur la facture. `byUserId` vide : envoi automatique.
 * Renvoie l'adresse utilisée, ou null si le client n'a pas d'adresse e-mail.
 */
export async function sendReminder(invoiceId: string, level: 1 | 2 | 3, byUserId: string | null): Promise<string | null> {
  const [row] = await db.select().from(schema.invoices).where(eq(schema.invoices.id, invoiceId));
  const [client] = await db.select().from(schema.clients).where(eq(schema.clients.id, row.clientId));
  if (!client.email) return null;
  const [company] = await db.select().from(schema.companies).where(eq(schema.companies.id, row.companyId));
  const { paid, credited } = await settlements([invoiceId]);
  const remaining = Math.max(0, row.grossCents - (paid.get(invoiceId) ?? 0) - (credited.get(invoiceId) ?? 0));
  const locale = clientLocale(client, company);
  const pdf = (row.pdfPath && (await readFile(row.pdfPath).catch(() => null))) || (await buildPdf(invoiceId));
  await sendMail({
    to: [client.email],
    brand: { name: company.name, logoPath: company.logoPath },
    ...docTexts(locale).reminderMail({
      company: company.name, number: row.number!, level,
      due: longDay(row.dueDate!, locale),
      remaining: new Intl.NumberFormat(formatLocale(locale), { style: 'currency', currency: row.currency }).format(remaining / 100),
    }),
    attachments: [{ filename: `${row.number}.pdf`, content: pdf, contentType: 'application/pdf' }],
  });
  await db.transaction(async (tx) => {
    await tx.insert(schema.invoiceReminders).values({ invoiceId, level, sentTo: client.email!, sentById: byUserId });
    await tx.update(schema.invoices).set({ dunningLevel: level, dunningLastOn: todayIn(company.timezone), updatedAt: new Date() })
      .where(eq(schema.invoices.id, invoiceId));
  });
  return client.email;
}

/** Heure et jour de la semaine dans le fuseau de la société : les relances partent en semaine, de 8 h à 18 h */
function officeHours(timezone: string, now: Date): boolean {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: timezone, weekday: 'short', hour: 'numeric', hourCycle: 'h23' }).formatToParts(now);
  const hour = Number(parts.find((x) => x.type === 'hour')?.value);
  const day = parts.find((x) => x.type === 'weekday')?.value;
  return day !== 'Sat' && day !== 'Sun' && hour >= 8 && hour < 18;
}

/** Envoie les relances dues des sociétés qui ont activé l'envoi automatique ; renvoie le nombre envoyé */
export async function runDunning(now = new Date(), opts: { anyHour?: boolean } = {}): Promise<number> {
  const companies = await db.select().from(schema.companies).where(eq(schema.companies.dunningEnabled, true));
  let sent = 0;
  for (const company of companies) {
    if (!opts.anyHour && !officeHours(company.timezone, now)) continue;
    const today = todayIn(company.timezone, now);
    for (const r of await overdueInvoices(company.id, today)) {
      const next = nextReminder(r, company.dunningDays);
      if (!next || next.on > today || !r.clientEmail) continue;
      try {
        if (await sendReminder(r.id, next.level, null)) sent++;
      } catch {
        // E-mail refusé : nouvel essai au prochain passage
      }
    }
  }
  return sent;
}

/** Historique des relances de factures */
export async function remindersOf(invoiceIds: string[]) {
  if (!invoiceIds.length) return [];
  return db.select({
    id: schema.invoiceReminders.id, invoiceId: schema.invoiceReminders.invoiceId, level: schema.invoiceReminders.level,
    sentTo: schema.invoiceReminders.sentTo, sentAt: schema.invoiceReminders.sentAt,
    sentBy: schema.users.firstName, sentByLast: schema.users.lastName,
  }).from(schema.invoiceReminders)
    .leftJoin(schema.users, eq(schema.users.id, schema.invoiceReminders.sentById))
    .where(inArray(schema.invoiceReminders.invoiceId, invoiceIds))
    .orderBy(asc(schema.invoiceReminders.sentAt));
}

/** Toutes les heures (seulement pendant les heures de bureau de chaque société) */
export function scheduleDunning(log: (msg: string) => void) {
  const run = () => runDunning()
    .then((n) => n && log(`${n} relance(s) de facture impayée envoyée(s)`))
    .catch((err) => log(`Relances impossibles : ${(err as Error).message}`));
  void run();
  const timer = setInterval(run, 60 * 60_000);
  timer.unref();
}
