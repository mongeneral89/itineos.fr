import nodemailer from 'nodemailer';
import { readFile } from 'node:fs/promises';
import { env } from '../env.js';
import { logoMime } from './logo.js';

// Sans SMTP_URL, les e-mails ne partent pas : ils sont résumés dans la console
// et les derniers sont gardés en mémoire (les tests d'intégration les relisent).
const transport = env.SMTP_URL
  ? nodemailer.createTransport(env.SMTP_URL)
  : nodemailer.createTransport({ jsonTransport: true });

export interface Mail {
  to: string[];
  subject: string;
  text: string;
  attachments?: { filename: string; content: Buffer; contentType?: string }[];
  /** Copies cachées (technicien, bureau) : le client ne voit pas ces adresses */
  bcc?: string[];
  /** Adresse qui reçoit la réponse du client (le technicien) */
  replyTo?: { name: string; address: string };
  /**
   * Société qui écrit : l'e-mail part aussi en version mise en forme, avec son logo en tête
   * (la version texte reste jointe pour les messageries qui n'affichent pas la mise en forme).
   */
  brand?: { name: string; logoPath?: string | null };
}

/** Derniers e-mails « envoyés » quand aucun SMTP n'est configuré */
export const unsentMails: (Mail & { html?: string })[] = [];

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]!));

/** Texte de l'e-mail en HTML : paragraphes, retours à la ligne et adresses web cliquables */
function textToHtml(text: string): string {
  return text.split(/\n{2,}/).map((para) => {
    const html = esc(para)
      .replace(/https?:\/\/[^\s<]+/g, (u) => `<a href="${u}" style="color:#9A3412">${u}</a>`)
      .replace(/\n/g, '<br>');
    return `<p style="margin:0 0 14px">${html}</p>`;
  }).join('');
}

/** Version mise en forme : en-tête avec le logo (image jointe, affichée sans téléchargement) ou le nom */
export function brandedHtml(text: string, brand: { name: string }, logoCid: string | null): string {
  const head = logoCid
    ? `<img src="cid:${logoCid}" alt="${esc(brand.name)}" style="display:block;max-height:56px;max-width:220px;border:0">`
    : `<div style="font:700 20px Arial,sans-serif;color:#14181F">${esc(brand.name)}</div>`;
  return `<!doctype html><html><body style="margin:0;padding:24px;background:#F4F2EE">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;background:#FFFFFF;border:1px solid #DDD8CF;border-radius:12px">
<tr><td style="padding:20px 28px;border-bottom:1px solid #DDD8CF">${head}</td></tr>
<tr><td style="padding:24px 28px;font:15px/1.55 Arial,sans-serif;color:#14181F">${textToHtml(text)}</td></tr>
<tr><td style="padding:14px 28px;border-top:1px solid #DDD8CF;font:12px Arial,sans-serif;color:#5B616B">${esc(brand.name)}</td></tr>
</table></body></html>`;
}

export async function sendMail(mail: Mail): Promise<void> {
  // Logo de la société, joint à l'e-mail et affiché en tête
  let logo: { filename: string; content: Buffer; contentType: string; cid: string } | null = null;
  if (mail.brand?.logoPath) {
    try {
      const content = await readFile(mail.brand.logoPath);
      logo = { filename: `logo.${mail.brand.logoPath.endsWith('.png') ? 'png' : 'jpg'}`, content, contentType: logoMime(mail.brand.logoPath), cid: 'logo@itineo' };
    } catch {
      logo = null;
    }
  }
  const html = mail.brand ? brandedHtml(mail.text, mail.brand, logo ? logo.cid : null) : undefined;

  if (!env.SMTP_URL) {
    // Copie gardée avant l'envoi : nodemailer transforme les pièces jointes en texte
    unsentMails.push({ ...mail, html, attachments: mail.attachments?.map((a) => ({ ...a })) });
    if (unsentMails.length > 50) unsentMails.shift();
  }
  await transport.sendMail({
    from: env.MAIL_FROM,
    to: mail.to.join(', '),
    subject: mail.subject,
    text: mail.text,
    ...(html ? { html } : {}),
    ...(mail.bcc?.length ? { bcc: mail.bcc.join(', ') } : {}),
    ...(mail.replyTo ? { replyTo: mail.replyTo } : {}),
    attachments: [...(mail.attachments?.map((a) => ({ ...a })) ?? []), ...(logo ? [logo] : [])],
  });
  if (!env.SMTP_URL) {
    console.info(`[mail] SMTP non configuré, e-mail non envoyé → ${mail.to.join(', ')} : ${mail.subject}`);
  }
}
