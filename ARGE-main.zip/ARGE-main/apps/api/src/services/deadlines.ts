/**
 * Échéances à surveiller dans une société : habilitations qui expirent et échéances des véhicules
 * (entretien, contrôle technique, assurance…). Sert au tableau de bord, à l'onglet « À programmer »
 * et au récapitulatif envoyé chaque matin.
 */
import { and, eq, inArray } from 'drizzle-orm';
import { certificationState, vehicleDeadlineState, type DueState, type VehicleDeadlineKind } from '@itineo/shared';
import { db, schema } from '../db/client.js';

export interface CertificationDue {
  id: string; userId: string; firstName: string; lastName: string; agencyId: string | null;
  typeCode: string; typeName: string; expiresOn: string; state: DueState;
}

export interface VehicleDue {
  id: string; vehicleId: string; plate: string; make: string | null; model: string | null; agencyId: string | null;
  kind: VehicleDeadlineKind; label: string | null; dueDate: string | null; dueMileage: number | null; mileage: number | null;
  appointmentOn: string | null; appointmentWith: string | null; state: DueState;
}

const urgent = (s: DueState) => s === 'SOON' || s === 'OVERDUE';
const order = (s: DueState) => (s === 'OVERDUE' ? 0 : 1);

export async function certificationsDue(companyId: string, today: string, all = false): Promise<CertificationDue[]> {
  const ra = schema.roleAssignments;
  const people = await db.selectDistinct({ userId: ra.userId, agencyId: ra.agencyId }).from(ra)
    .innerJoin(schema.users, eq(schema.users.id, ra.userId))
    .where(and(eq(ra.companyId, companyId), eq(ra.role, 'TECHNICIAN'), eq(schema.users.active, true)));
  if (!people.length) return [];
  const agencyOf = new Map(people.map((x) => [x.userId, x.agencyId]));
  const uc = schema.userCertifications;
  const rows = await db.select({
    id: uc.id, userId: uc.userId, expiresOn: uc.expiresOn, firstName: schema.users.firstName, lastName: schema.users.lastName,
    typeCode: schema.certificationTypes.code, typeName: schema.certificationTypes.name,
  })
    .from(uc).innerJoin(schema.users, eq(schema.users.id, uc.userId))
    .innerJoin(schema.certificationTypes, eq(schema.certificationTypes.id, uc.typeId))
    .where(inArray(uc.userId, [...agencyOf.keys()]));
  return rows
    .filter((r) => r.expiresOn)
    .map((r) => ({ ...r, expiresOn: r.expiresOn!, agencyId: agencyOf.get(r.userId) ?? null, state: certificationState(r.expiresOn, today) }))
    .filter((r) => all || urgent(r.state))
    .sort((a, b) => order(a.state) - order(b.state) || a.expiresOn.localeCompare(b.expiresOn));
}

export async function vehiclesDue(companyId: string, today: string, all = false): Promise<VehicleDue[]> {
  const v = schema.vehicles;
  const d = schema.vehicleDeadlines;
  const rows = await db.select({
    id: d.id, vehicleId: v.id, plate: v.plate, make: v.make, model: v.model, agencyId: v.agencyId, mileage: v.mileage,
    kind: d.kind, label: d.label, dueDate: d.dueDate, dueMileage: d.dueMileage, appointmentOn: d.appointmentOn, appointmentWith: d.appointmentWith,
  })
    .from(d).innerJoin(v, eq(v.id, d.vehicleId))
    .where(and(eq(v.companyId, companyId), eq(d.active, true), inArray(v.status, ['ACTIVE', 'IMMOBILIZED'])));
  return rows
    .map((r) => ({ ...r, state: vehicleDeadlineState(r, today, r.mileage) }))
    .filter((r) => all || urgent(r.state))
    .sort((a, b) => order(a.state) - order(b.state) || (a.dueDate ?? '9999').localeCompare(b.dueDate ?? '9999'));
}
