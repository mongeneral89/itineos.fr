/**
 * Fichiers joints (messagerie, notices et procédures) : photos, PDF, documents bureautiques, vidéos courtes,
 * texte. Le contenu est vérifié (signature du format), pas seulement le type annoncé. Pas de HTML ni de SVG :
 * rien qui puisse s'exécuter dans le navigateur.
 */
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../env.js';

export const MAX_FILE_BYTES = 10 * 1024 * 1024;
/** Taille d'une requête qui transporte un fichier de 10 Mo en base64 (+ un peu de marge) */
export const FILE_BODY_LIMIT = Math.ceil(MAX_FILE_BYTES * 1.37) + 64 * 1024;

const ZIP = [0x50, 0x4b, 0x03, 0x04];
const OLE = [0xd0, 0xcf, 0x11, 0xe0];

type Format = { ext: string; check: (b: Buffer) => boolean };
const starts = (magic: number[], offset = 0) => (b: Buffer) => magic.every((x, i) => b[offset + i] === x);
/** Texte : pas d'octet nul et UTF-8 valide */
const isText = (b: Buffer) => !b.includes(0) && Buffer.from(b.toString('utf8'), 'utf8').equals(b);

export const FILE_FORMATS: Record<string, Format> = {
  'image/jpeg': { ext: 'jpg', check: starts([0xff, 0xd8, 0xff]) },
  'image/png': { ext: 'png', check: starts([0x89, 0x50, 0x4e, 0x47]) },
  'image/gif': { ext: 'gif', check: starts([0x47, 0x49, 0x46, 0x38]) },
  'image/webp': { ext: 'webp', check: (b) => starts([0x52, 0x49, 0x46, 0x46])(b) && starts([0x57, 0x45, 0x42, 0x50], 8)(b) },
  'application/pdf': { ext: 'pdf', check: starts([0x25, 0x50, 0x44, 0x46]) },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { ext: 'docx', check: starts(ZIP) },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { ext: 'xlsx', check: starts(ZIP) },
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': { ext: 'pptx', check: starts(ZIP) },
  'application/vnd.oasis.opendocument.text': { ext: 'odt', check: starts(ZIP) },
  'application/vnd.oasis.opendocument.spreadsheet': { ext: 'ods', check: starts(ZIP) },
  'application/msword': { ext: 'doc', check: starts(OLE) },
  'application/vnd.ms-excel': { ext: 'xls', check: starts(OLE) },
  'application/zip': { ext: 'zip', check: starts(ZIP) },
  'video/mp4': { ext: 'mp4', check: starts([0x66, 0x74, 0x79, 0x70], 4) },
  'video/quicktime': { ext: 'mov', check: starts([0x66, 0x74, 0x79, 0x70], 4) },
  'text/plain': { ext: 'txt', check: isText },
  'text/csv': { ext: 'csv', check: isText },
};

export type ParsedFile = { buffer: Buffer; mime: string; ext: string; name: string; size: number };

/** Nom affiché du fichier : sans dossier ni caractères de contrôle, 120 caractères au plus */
export function cleanFileName(name: string, ext: string): string {
  // eslint-disable-next-line no-control-regex
  const base = (name.split(/[\\/]/).pop() ?? '').replace(/[\u0000-\u001f\u007f"]/g, '').trim().slice(0, 120);
  return base || `fichier.${ext}`;
}

/** Décode un fichier envoyé en data URL ; null si le format n'est pas accepté ou si le contenu ne correspond pas */
export function parseFileDataUrl(dataUrl: string, name: string): ParsedFile | null {
  const m = /^data:([a-z0-9.+/-]+);base64,([A-Za-z0-9+/=]+)$/i.exec(dataUrl);
  if (!m) return null;
  const mime = m[1].toLowerCase();
  const format = FILE_FORMATS[mime];
  if (!format) return null;
  const buffer = Buffer.from(m[2], 'base64');
  if (!buffer.length || buffer.length > MAX_FILE_BYTES) return null;
  if (!format.check(buffer)) return null;
  return { buffer, mime, ext: format.ext, name: cleanFileName(name, format.ext), size: buffer.length };
}

export async function storeFile(folder: string, id: string, ext: string, buffer: Buffer): Promise<string> {
  const dir = path.resolve(env.STORAGE_DIR, folder);
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, `${id}.${ext}`);
  await writeFile(file, buffer);
  return file;
}

export const readStoredFile = (file: string) => readFile(file).catch(() => null);
export const removeStoredFile = (file: string) => unlink(file).catch(() => undefined);

/** En-tête Content-Disposition : images, PDF et vidéos s'affichent, le reste se télécharge */
export function contentDisposition(mime: string, name: string): string {
  const inline = mime.startsWith('image/') || mime === 'application/pdf' || mime.startsWith('video/');
  const ascii = name.replace(/[^\x20-\x7e]/g, '_');
  return `${inline ? 'inline' : 'attachment'}; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(name)}`;
}
