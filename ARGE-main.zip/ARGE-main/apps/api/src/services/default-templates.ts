/**
 * Modèles de fiches NEUTRES fournis avec Itinéos, en français et en anglais.
 * Chaque société peut ensuite créer ses propres modèles (route /api/templates).
 *
 * Les horaires, le temps passé, les pièces, le statut et les signatures ne sont pas
 * dans les modèles : ils font partie de toutes les fiches.
 */
import type { InterventionKind, TemplateSchema, TemplateField } from '@itineo/shared';

type Lang = 'fr' | 'en';

const L = {
  fr: {
    names: { SAV: 'Fiche SAV / Dépannage', INSTALLATION: "Fiche d'installation", MAINTENANCE: "Fiche d'entretien", OTHER: "Fiche d'intervention" },
    equipment: 'Matériel concerné', category: 'Type de matériel', brand: 'Marque', model: 'Modèle',
    serial: 'N° de série', location: 'Emplacement',
    diagnosis: 'Diagnostic', symptom: 'Symptôme signalé par le client', callType: "Type d'intervention",
    callTypes: ['Sous contrat', 'Sous garantie', 'Facturable'],
    cause: 'Diagnostic et cause identifiée', work: 'Travaux réalisés', workDone: 'Opérations réalisées',
    observations: 'Observations', recommendations: 'Observations et recommandations',
    installation: 'Installation', orderRef: 'Référence du devis ou de la commande',
    request: 'Installation demandée', commissioning: 'Mise en service',
    tests: 'Essais réalisés et résultats', settings: 'Paramétrages effectués',
    handover: 'Remise au client',
    handoverItems: ['Prise en main expliquée', 'Notice remise', 'Garantie remise', 'Certificat ou attestation remis'],
    reserves: 'Réserves éventuelles du client',
    checks: 'Contrôles', checklist: 'Points contrôlés',
    checkItems: ['Nettoyage', 'Contrôle visuel', 'Contrôle des sécurités', 'Mesures et relevés', 'Essais de fonctionnement'],
    measures: 'Relevés et mesures', details: 'Intervention', description: 'Description de la demande',
  },
  en: {
    names: { SAV: 'Service / Repair report', INSTALLATION: 'Installation report', MAINTENANCE: 'Maintenance report', OTHER: 'Job report' },
    equipment: 'Equipment', category: 'Equipment type', brand: 'Brand', model: 'Model',
    serial: 'Serial number', location: 'Location',
    diagnosis: 'Diagnosis', symptom: 'Fault reported by the customer', callType: 'Job type',
    callTypes: ['Under contract', 'Under warranty', 'Chargeable'],
    cause: 'Diagnosis and root cause', work: 'Work carried out', workDone: 'Operations carried out',
    observations: 'Observations', recommendations: 'Observations and recommendations',
    installation: 'Installation', orderRef: 'Quote or order reference',
    request: 'Requested installation', commissioning: 'Commissioning',
    tests: 'Tests carried out and results', settings: 'Settings applied',
    handover: 'Customer handover',
    handoverItems: ['Operation explained', 'Manual handed over', 'Warranty handed over', 'Certificate handed over'],
    reserves: 'Customer reservations',
    checks: 'Checks', checklist: 'Items checked',
    checkItems: ['Cleaning', 'Visual inspection', 'Safety checks', 'Readings and measurements', 'Operational tests'],
    measures: 'Readings and measurements', details: 'Job', description: 'Request description',
  },
};

function equipmentSection(t: (typeof L)['fr'], prefill: boolean) {
  const f = (id: string, label: string, path: string): TemplateField => ({
    id, label, type: 'text', ...(prefill ? { prefill: path } : {}),
  });
  return {
    id: 'equipment',
    title: t.equipment,
    fields: [
      f('equipmentCategory', t.category, 'equipment.category'),
      f('equipmentBrand', t.brand, 'equipment.brand'),
      f('equipmentModel', t.model, 'equipment.model'),
      f('equipmentSerial', t.serial, 'equipment.serialNumber'),
      f('equipmentLocation', t.location, 'equipment.location'),
    ],
  };
}

export function buildDefaultTemplate(kind: InterventionKind, lang: Lang): { name: string; schema: TemplateSchema } {
  const t = L[lang];
  const observations = {
    id: 'observations',
    title: t.observations,
    fields: [{ id: 'recommendations', label: t.recommendations, type: 'textarea', dictation: true } as TemplateField],
  };
  let sections: TemplateSchema['sections'];

  switch (kind) {
    case 'SAV':
      sections = [
        {
          id: 'diagnosis',
          title: t.diagnosis,
          fields: [
            { id: 'symptom', label: t.symptom, type: 'textarea', required: true, prefill: 'intervention.reason' },
            { id: 'callType', label: t.callType, type: 'select', required: true, options: t.callTypes },
            { id: 'cause', label: t.cause, type: 'textarea', required: true, dictation: true },
            { id: 'work', label: t.work, type: 'textarea', required: true, dictation: true },
          ],
        },
        equipmentSection(t, true),
        observations,
      ];
      break;
    case 'INSTALLATION':
      sections = [
        {
          id: 'installation',
          title: t.installation,
          fields: [
            { id: 'orderRef', label: t.orderRef, type: 'text' },
            { id: 'request', label: t.request, type: 'textarea', required: true, prefill: 'intervention.reason' },
            { id: 'work', label: t.work, type: 'textarea', required: true, dictation: true },
          ],
        },
        equipmentSection(t, true),
        {
          id: 'commissioning',
          title: t.commissioning,
          fields: [
            { id: 'tests', label: t.tests, type: 'textarea', required: true, dictation: true },
            { id: 'settings', label: t.settings, type: 'textarea', dictation: true },
            { id: 'handover', label: t.handover, type: 'checklist', options: t.handoverItems },
            { id: 'reserves', label: t.reserves, type: 'textarea', dictation: true },
          ],
        },
        observations,
      ];
      break;
    case 'MAINTENANCE':
      sections = [
        equipmentSection(t, true),
        {
          id: 'checks',
          title: t.checks,
          fields: [
            { id: 'checklist', label: t.checklist, type: 'checklist', options: t.checkItems },
            { id: 'measures', label: t.measures, type: 'textarea', dictation: true },
            { id: 'work', label: t.workDone, type: 'textarea', required: true, dictation: true },
          ],
        },
        observations,
      ];
      break;
    default:
      sections = [
        {
          id: 'details',
          title: t.details,
          fields: [
            { id: 'request', label: t.description, type: 'textarea', prefill: 'intervention.reason' },
            { id: 'work', label: t.work, type: 'textarea', required: true, dictation: true },
          ],
        },
        equipmentSection(t, true),
        observations,
      ];
  }
  return { name: t.names[kind], schema: { lang, sections } };
}

export const DEFAULT_LANGS: Lang[] = ['fr', 'en'];

/**
 * Documents supplémentaires fournis avec Itinéos : jamais choisis automatiquement, on les sélectionne sur
 * l'intervention (« Document à remplir »). Le client signe en fin de fiche, comme pour toutes les fiches.
 */
export function buildExtraTemplates(lang: Lang): { name: string; kind: InterventionKind; schema: TemplateSchema }[] {
  const fr = lang === 'fr';
  const yesNo = fr ? ['Oui', 'Non'] : ['Yes', 'No'];
  const when = fr ? ['Jour', 'Nuit', 'Week-end', 'Détient les clés'] : ['Day', 'Night', 'Weekend', 'Key holder'];
  const responsibles: TemplateField[] = [];
  for (let i = 1; i <= 6; i++) {
    responsibles.push(
      { id: `resp${i}Name`, label: fr ? `Responsable ${i} : nom et qualité` : `Contact ${i}: name and role`, type: 'text' },
      { id: `resp${i}Phones`, label: fr ? `Responsable ${i} : téléphone(s)` : `Contact ${i}: phone number(s)`, type: 'text' },
      { id: `resp${i}When`, label: fr ? `Responsable ${i} : à prévenir` : `Contact ${i}: to call`, type: 'checklist', options: when },
    );
  }
  return [{
    name: fr ? 'Consignes de télésurveillance' : 'Remote monitoring instructions',
    kind: 'INSTALLATION',
    schema: {
      lang,
      sections: [
        {
          id: 'site',
          title: fr ? 'Site surveillé' : 'Monitored site',
          fields: [
            { id: 'siteName', label: fr ? 'Nom du site' : 'Site name', type: 'text', prefill: 'site.name' },
            { id: 'siteAddress', label: fr ? 'Adresse du site' : 'Site address', type: 'text', prefill: 'site.fullAddress' },
            { id: 'subscriber', label: fr ? 'N° d’abonné' : 'Subscriber number', type: 'text', prefill: 'client.subscriberNumber' },
            { id: 'siteType', label: fr ? 'Type de site' : 'Site type', type: 'select', required: true,
              options: fr ? ['Habitation', 'Commerce', 'Bureaux', 'Entrepôt / industrie', 'Établissement recevant du public', 'Autre']
                : ['Home', 'Shop', 'Offices', 'Warehouse / industrial', 'Public building', 'Other'] },
            { id: 'transmitter', label: fr ? 'Transmetteur (modèle, n° de série, mode de transmission)' : 'Transmitter (model, serial number, transmission)', type: 'text' },
            { id: 'breaker', label: fr ? 'Emplacement du disjoncteur / de la centrale' : 'Location of breaker / control panel', type: 'text' },
          ],
        },
        {
          id: 'responsibles',
          title: fr ? 'Responsables à prévenir' : 'Contacts to call',
          fields: [
            { id: 'callOrder', label: fr ? 'Appeler les responsables dans l’ordre de la liste' : 'Call contacts in the order of the list', type: 'select', options: yesNo },
            ...responsibles,
          ],
        },
        {
          id: 'instructions',
          title: fr ? 'Consignes' : 'Instructions',
          fields: [
            { id: 'patrol', label: fr ? 'En cas d’alarme : envoi d’un agent (ronde)' : 'On alarm: send a guard (patrol)', type: 'select',
              options: fr ? ['Oui, systématiquement', 'Seulement si personne ne répond', 'Non'] : ['Yes, always', 'Only if nobody answers', 'No'] },
            { id: 'police', label: fr ? 'Prévenir les forces de l’ordre après levée de doute' : 'Call the police after verification', type: 'select', options: yesNo },
            { id: 'hours', label: fr ? 'Horaires d’ouverture / de mise en service' : 'Opening / arming hours', type: 'textarea', dictation: true },
            { id: 'password', label: fr ? 'Mot de passe convenu avec le centre (levée de doute)' : 'Password agreed with the monitoring centre', type: 'text' },
            { id: 'comments', label: fr ? 'Commentaires et consignes particulières' : 'Comments and special instructions', type: 'textarea', dictation: true },
          ],
        },
      ],
    },
  }];
}
