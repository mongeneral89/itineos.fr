/**
 * Pré-remplissage d'une fiche à partir du contexte (client, site, matériel, intervention).
 * Fonctions pures, sans base de données : faciles à tester.
 */
import type { ReportData, TemplateSchema } from '@itineo/shared';

export type PrefillContext = Record<string, Record<string, unknown> | null | undefined>;

/** Lit une valeur par son chemin : getPath(ctx, "equipment.serialNumber") */
export function getPath(ctx: PrefillContext, path: string): unknown {
  return path.split('.').reduce<unknown>((acc, key) => {
    if (acc && typeof acc === 'object') return (acc as Record<string, unknown>)[key];
    return undefined;
  }, ctx);
}

export function buildPrefill(schema: TemplateSchema, ctx: PrefillContext): ReportData {
  const data: ReportData = {};
  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (!field.prefill) continue;
      const v = getPath(ctx, field.prefill);
      if (v === undefined || v === null || v === '') continue;
      data[field.id] = typeof v === 'number' || typeof v === 'boolean' ? v : String(v);
    }
  }
  return data;
}

/** Choisit la langue du modèle à partir de la langue de la société ("fr-BE" → "fr") */
export function langOf(locale: string | null | undefined): string {
  return (locale ?? 'fr').slice(0, 2).toLowerCase();
}

/** Assemble une adresse sur une ligne en ignorant les morceaux vides */
export function oneLineAddress(...parts: Array<string | null | undefined>): string {
  return parts.filter((p) => p && p.trim()).join(', ');
}

/** Format du numéro de fiche : PREFIXE-ANNÉE-00042 */
export function formatNumber(prefix: string, year: number, n: number): string {
  return `${prefix}-${year}-${String(n).padStart(5, '0')}`;
}
