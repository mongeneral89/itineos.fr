import { and, asc, eq, inArray } from 'drizzle-orm';
import { db, schema } from '../db/client.js';
import { scopeFor, type Principal } from '../auth/access.js';

/** Sociétés et agences que l'utilisateur peut voir, sous forme d'arbre */
export async function visibleOrg(p: Principal) {
  const f = scopeFor(p, 'org.read');
  const companyIds = new Set([...f.companyIds, ...f.agencyCompanyIds]);

  const companies = await db
    .select()
    .from(schema.companies)
    .where(and(
      eq(schema.companies.groupId, p.groupId),
      f.all ? undefined : inArray(schema.companies.id, companyIds.size ? [...companyIds] : ['00000000-0000-0000-0000-000000000000']),
    ))
    .orderBy(asc(schema.companies.name));

  const ids = companies.map((c) => c.id);
  const agencies = ids.length
    ? await db.select().from(schema.agencies).where(inArray(schema.agencies.companyId, ids)).orderBy(asc(schema.agencies.name))
    : [];
  const agencyIds = agencies.map((a) => a.id);
  const teams = agencyIds.length
    ? await db.select().from(schema.teams).where(inArray(schema.teams.agencyId, agencyIds)).orderBy(asc(schema.teams.name))
    : [];

  const fullCompany = (companyId: string) => f.all || f.companyIds.includes(companyId);

  return companies.map((c) => ({
    ...publicCompany(c),
    agencies: agencies
      .filter((a) => a.companyId === c.id && (fullCompany(c.id) || f.agencyIds.includes(a.id)))
      .map((a) => ({ ...a, teams: teams.filter((t) => t.agencyId === a.id) })),
  }));
}

/**
 * Société telle qu'envoyée au navigateur : sans l'emplacement du logo sur le serveur (logoUpdatedAt suffit)
 * ni le jeton d'accès à la plateforme de facture électronique (seulement s'il est renseigné).
 */
export function publicCompany<T extends { logoPath?: string | null; einvoiceApiToken?: string | null }>(c: T): Omit<T, 'logoPath' | 'einvoiceApiToken'> & { einvoiceTokenSet: boolean } {
  const { logoPath: _hidden, einvoiceApiToken: token, ...rest } = c;
  return { ...rest, einvoiceTokenSet: !!token };
}

export async function getCompany(groupId: string, companyId: string) {
  const [c] = await db
    .select()
    .from(schema.companies)
    .where(and(eq(schema.companies.id, companyId), eq(schema.companies.groupId, groupId)));
  return c ?? null;
}

export async function getAgency(companyId: string, agencyId: string) {
  const [a] = await db
    .select()
    .from(schema.agencies)
    .where(and(eq(schema.agencies.id, agencyId), eq(schema.agencies.companyId, companyId)));
  return a ?? null;
}
