/** Justificatifs (habilitations…) : PDF, JPEG ou PNG, contenu vérifié, stockés sur disque */
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../env.js';

export const MAX_DOCUMENT_BYTES = 5 * 1024 * 1024;

const FORMATS = {
  'application/pdf': { ext: 'pdf', magic: [0x25, 0x50, 0x44, 0x46] }, // %PDF
  'image/jpeg': { ext: 'jpg', magic: [0xff, 0xd8, 0xff] },
  'image/png': { ext: 'png', magic: [0x89, 0x50, 0x4e, 0x47] },
} as const;
export type DocumentMime = keyof typeof FORMATS;

export function parseDocumentDataUrl(dataUrl: string): { buffer: Buffer; mime: DocumentMime; ext: string } | null {
  const m = /^data:(application\/pdf|image\/jpeg|image\/png);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) return null;
  const mime = m[1] as DocumentMime;
  const buffer = Buffer.from(m[2], 'base64');
  const { ext, magic } = FORMATS[mime];
  if (!buffer.length || buffer.length > MAX_DOCUMENT_BYTES) return null;
  if (!magic.every((b, i) => buffer[i] === b)) return null;
  return { buffer, mime, ext };
}

export async function storeDocument(folder: string, name: string, ext: string, buffer: Buffer): Promise<string> {
  const dir = path.resolve(env.STORAGE_DIR, folder);
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, `${name}.${ext}`);
  await writeFile(file, buffer);
  return file;
}

export const readDocument = (file: string) => readFile(file).catch(() => null);
export const removeDocument = (file: string) => unlink(file).catch(() => undefined);
