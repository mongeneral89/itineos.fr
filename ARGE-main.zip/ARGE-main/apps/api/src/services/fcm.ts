/**
 * Notifications de l'appli Android par Firebase Cloud Messaging (FCM, API HTTP v1) : l'appli installée ne reçoit pas
 * le Web Push des navigateurs. Les téléphones s'enregistrent comme les navigateurs, dans push_subscriptions, avec une
 * adresse « fcm:<jeton> ».
 *
 * Le compte de service Firebase (fichier JSON secret, Firebase → Paramètres du projet → Comptes de service) est lu
 * dans FCM_SERVICE_ACCOUNT_FILE. Sans lui, l'appli Android ne reçoit simplement pas de notification.
 */
import { createSign } from 'node:crypto';
import { readFileSync } from 'node:fs';

export const FCM_PREFIX = 'fcm:';
/** Canal Android des notifications (créé par l'appli, tech/push-native.ts) */
export const FCM_CHANNEL = 'arge';

interface ServiceAccount { project_id: string; client_email: string; private_key: string; token_uri?: string }

let account: ServiceAccount | null | undefined;
export function fcmAccount(): ServiceAccount | null {
  if (account !== undefined) return account;
  const file = process.env.FCM_SERVICE_ACCOUNT_FILE;
  account = null;
  if (file) {
    try {
      const a = JSON.parse(readFileSync(file, 'utf8')) as ServiceAccount;
      if (a.project_id && a.client_email && a.private_key) account = a;
      else console.warn('[fcm] compte de service incomplet :', file);
    } catch (e) {
      console.warn('[fcm] compte de service illisible :', (e as Error).message);
    }
  }
  return account;
}

const b64url = (s: string | Buffer) => Buffer.from(s).toString('base64url');

/** Jeton d'accès Google (1 h), gardé jusqu'à quelques minutes de sa fin */
let access: { token: string; until: number } | null = null;
async function accessToken(a: ServiceAccount): Promise<string> {
  if (access && access.until > Date.now()) return access.token;
  const tokenUri = a.token_uri ?? 'https://oauth2.googleapis.com/token';
  const now = Math.floor(Date.now() / 1000);
  const unsigned = `${b64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }))}.${b64url(JSON.stringify({
    iss: a.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: tokenUri, iat: now, exp: now + 3600,
  }))}`;
  const signature = createSign('RSA-SHA256').update(unsigned).sign(a.private_key);
  const res = await fetch(tokenUri, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: `${unsigned}.${b64url(signature)}` }),
  });
  if (!res.ok) throw new Error(`jeton Google refusé (${res.status})`);
  const json = (await res.json()) as { access_token: string; expires_in: number };
  access = { token: json.access_token, until: Date.now() + (json.expires_in - 300) * 1000 };
  return access.token;
}

/**
 * Envoie une notification à un téléphone. « gone » : le jeton n'est plus valable (appli désinstallée…),
 * l'enregistrement est à supprimer.
 */
export async function sendFcm(token: string, notice: { title: string; body: string; url: string; tag?: string }): Promise<'ok' | 'gone'> {
  const a = fcmAccount();
  if (!a) throw new Error('FCM non configuré (FCM_SERVICE_ACCOUNT_FILE)');
  const res = await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(a.project_id)}/messages:send`, {
    method: 'POST',
    headers: { authorization: `Bearer ${await accessToken(a)}`, 'content-type': 'application/json' },
    body: JSON.stringify({
      message: {
        token,
        notification: { title: notice.title, body: notice.body },
        // Touchée : l'appli s'ouvre sur cette page
        data: { url: notice.url },
        android: {
          priority: 'HIGH',
          ttl: '86400s',
          notification: { channel_id: FCM_CHANNEL, ...(notice.tag ? { tag: notice.tag } : {}) },
        },
      },
    }),
  });
  if (res.ok) return 'ok';
  const detail = await res.text().catch(() => '');
  // Appli désinstallée, ou jeton qui n'en est pas un : l'enregistrement ne sert plus
  if (res.status === 404 || detail.includes('UNREGISTERED') || detail.includes('not a valid FCM registration token')) return 'gone';
  throw new Error(`FCM ${res.status} ${detail.slice(0, 200)}`);
}
