import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../env.js';

/** Taille maximale d'une photo, après réduction par l'appareil */
export const MAX_PHOTO_BYTES = 3 * 1024 * 1024;

const FORMATS = {
  'image/jpeg': { ext: 'jpg', magic: [0xff, 0xd8, 0xff] },
  'image/png': { ext: 'png', magic: [0x89, 0x50, 0x4e, 0x47] },
} as const;
export type PhotoMime = keyof typeof FORMATS;

/**
 * Décode une photo envoyée en data URL et vérifie qu'il s'agit bien d'un JPEG ou d'un PNG
 * (le contenu, pas seulement l'en-tête annoncé). Renvoie null sinon.
 */
export function parsePhotoDataUrl(dataUrl: string): { buffer: Buffer; mime: PhotoMime; ext: string } | null {
  const m = /^data:(image\/(?:jpeg|png));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) return null;
  const mime = m[1] as PhotoMime;
  const buffer = Buffer.from(m[2], 'base64');
  const { ext, magic } = FORMATS[mime];
  if (buffer.length === 0 || buffer.length > MAX_PHOTO_BYTES) return null;
  if (!magic.every((b, i) => buffer[i] === b)) return null;
  return { buffer, mime, ext };
}

function photoDir(companyId: string, reportId: string): string {
  return path.resolve(env.STORAGE_DIR, 'photos', companyId, reportId);
}

export async function storePhoto(companyId: string, reportId: string, photoId: string, ext: string, buffer: Buffer): Promise<string> {
  const dir = photoDir(companyId, reportId);
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, `${photoId}.${ext}`);
  await writeFile(file, buffer);
  return file;
}

export async function readPhoto(filePath: string): Promise<Buffer | null> {
  try {
    return await readFile(filePath);
  } catch {
    return null;
  }
}

export async function removePhotoFile(filePath: string): Promise<void> {
  try {
    await unlink(filePath);
  } catch {
    /* déjà absent : rien à faire */
  }
}
