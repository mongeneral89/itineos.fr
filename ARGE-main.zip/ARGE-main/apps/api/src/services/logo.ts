/**
 * Logo de la société : un fichier PNG ou JPEG par société (STORAGE_DIR/logos), repris dans le logiciel,
 * l'espace client et en tête des documents PDF (fiches, devis, factures, bons de sortie).
 * L'appli convertit l'image choisie (y compris SVG ou WebP) en PNG avant de l'envoyer.
 */
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../env.js';

export const MAX_LOGO_BYTES = 1024 * 1024;

const FORMATS = {
  'image/png': { ext: 'png', magic: [0x89, 0x50, 0x4e, 0x47] },
  'image/jpeg': { ext: 'jpg', magic: [0xff, 0xd8, 0xff] },
} as const;

/** Décode le logo envoyé en data URL (PNG ou JPEG, contenu vérifié), sinon null */
export function parseLogoDataUrl(dataUrl: string): { buffer: Buffer; mime: keyof typeof FORMATS; ext: string } | null {
  const m = /^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!m) return null;
  const mime = m[1] as keyof typeof FORMATS;
  const buffer = Buffer.from(m[2], 'base64');
  const { ext, magic } = FORMATS[mime];
  if (!buffer.length || buffer.length > MAX_LOGO_BYTES || !magic.every((b, i) => buffer[i] === b)) return null;
  return { buffer, mime, ext };
}

export async function storeLogo(companyId: string, ext: string, buffer: Buffer): Promise<string> {
  const dir = path.resolve(env.STORAGE_DIR, 'logos');
  await mkdir(dir, { recursive: true });
  // Un seul logo par société : l'ancien (autre format) est retiré
  for (const other of Object.values(FORMATS)) {
    if (other.ext !== ext) await unlink(path.join(dir, `${companyId}.${other.ext}`)).catch(() => undefined);
  }
  const file = path.join(dir, `${companyId}.${ext}`);
  await writeFile(file, buffer);
  return file;
}

export async function removeLogo(filePath: string | null): Promise<void> {
  if (filePath) await unlink(filePath).catch(() => undefined);
}

/** Le logo d'une société (pour les PDF), ou null s'il n'y en a pas ou s'il est illisible */
export async function companyLogo(company: { logoPath?: string | null }): Promise<Buffer | null> {
  if (!company.logoPath) return null;
  try {
    return await readFile(company.logoPath);
  } catch {
    return null;
  }
}

/** Adresse publique du logo (la date de mise à jour évite de garder l'ancien en cache), ou null */
export function logoUrl(company: { id: string; logoUpdatedAt?: Date | null }): string | null {
  return company.logoUpdatedAt ? `/api/logos/${company.id}?v=${company.logoUpdatedAt.getTime()}` : null;
}

export function logoMime(filePath: string): string {
  return filePath.endsWith('.png') ? 'image/png' : 'image/jpeg';
}

/**
 * Dessine le logo en haut à gauche d'un PDF (au plus 160 × 52 points) et renvoie la hauteur occupée,
 * pour placer le nom de la société dessous. Un logo illisible est ignoré.
 */
export function drawPdfLogo(doc: PDFKit.PDFDocument, logo: Buffer | null | undefined, x: number, y: number): number {
  if (!logo) return 0;
  try {
    // Sans « align » : l'image réduite reste collée en haut à gauche du cadre
    doc.image(logo, x, y, { fit: [160, 52] });
    return 60;
  } catch {
    return 0;
  }
}
