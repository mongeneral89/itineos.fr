/**
 * Emplacements sur le disque, valables pour le code source (src/paths.ts) comme pour le serveur compilé
 * (dist/index.mjs) : les deux sont un dossier sous apps/api.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** Dossier apps/api (migrations/, assets/) */
export const API_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
/** Racine du logiciel (package.json et sa version) */
export const APP_ROOT = path.resolve(API_DIR, '..', '..');
