# Polices des documents PDF

Polices **Noto** de Google, sous licence libre **SIL Open Font License 1.1** (OFL) : utilisation, intégration dans
les PDF et redistribution autorisées. Texte de la licence : https://openfontlicense.org

| Fichier | Écritures |
| --- | --- |
| NotoSans (normal, gras) | latin, cyrillique, grec |
| NotoSansArabic (normal, gras) | arabe |
| NotoSansDevanagari (normal, gras) | hindi |
| NotoSansSC / JP / KR (normal) | chinois, japonais, coréen (le gras est simulé) |

Source : paquets npm `@expo-google-fonts/noto-sans*` (mêmes fichiers que Google Fonts).
Utilisées par `src/services/pdf-text.ts`. Seuls les caractères employés sont intégrés dans chaque PDF.
