/**
 * Serveur compilé pour les installations chez les clients : un fichier JavaScript compacté par point d'entrée,
 * sans le code source lisible (dist/index.mjs : le serveur ; dist/create-admin.mjs : le premier compte).
 *   npm run build -w @itineo/api
 * Les bibliothèques (node_modules) restent à part ; le code d'Itinéos et @itineo/shared sont intégrés.
 * Les dossiers migrations/ et assets/ sont lus à côté (voir src/paths.ts).
 */
import { readFileSync, rmSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const pkg = JSON.parse(readFileSync(path.join(here, 'package.json'), 'utf8'));
// Toutes les dépendances restent dans node_modules, sauf le code partagé d'Itinéos, intégré au fichier
const external = Object.keys(pkg.dependencies).filter((d) => d !== '@itineo/shared');

rmSync(path.join(here, 'dist'), { recursive: true, force: true });
await build({
  entryPoints: { index: path.join(here, 'src/index.ts'), 'create-admin': path.join(here, 'src/db/create-admin.ts') },
  outdir: path.join(here, 'dist'),
  outExtension: { '.js': '.mjs' },
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  external,
  minify: true,
  legalComments: 'none',
  sourcemap: false,
  // Certaines bibliothèques CommonJS appellent require() : on le fournit dans le module ESM
  banner: { js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);" },
  logLevel: 'warning',
});
console.log('Serveur compilé : apps/api/dist (index.mjs, create-admin.mjs)');
