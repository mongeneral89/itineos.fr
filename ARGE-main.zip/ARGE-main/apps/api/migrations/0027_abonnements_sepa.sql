-- Facturation des abonnements (télésurveillance, maintenance…) : période facturée à terme à échoir,
-- et date jusqu'à laquelle le contrat est déjà facturé (rien n'est facturé deux fois)
ALTER TABLE contracts ADD COLUMN billing_months integer;
ALTER TABLE contracts ADD COLUMN billed_until date;
-- Contrat sans visite (abonnement seul, par exemple la télésurveillance) : fréquence 0
ALTER TABLE contracts DROP CONSTRAINT IF EXISTS contracts_frequency_months_check;
ALTER TABLE contracts ADD CONSTRAINT contracts_frequency_months_check CHECK (frequency_months BETWEEN 0 AND 60);

-- Prélèvement SEPA : identifiant créancier (ICS) et compte de la société
ALTER TABLE companies ADD COLUMN sepa_creditor_id text;
ALTER TABLE companies ADD COLUMN sepa_iban text;
ALTER TABLE companies ADD COLUMN sepa_bic text;

-- Mandats de prélèvement signés par les clients (un seul actif par client)
CREATE TABLE sepa_mandates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  -- Référence unique du mandat (RUM)
  reference text NOT NULL,
  holder_name text NOT NULL,
  iban text NOT NULL,
  bic text,
  signed_on date NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE',
  -- Premier prélèvement fait : les suivants sont « récurrents »
  first_collected_at timestamptz,
  revoked_at timestamptz,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sepa_mandates_client_idx ON sepa_mandates (client_id);
CREATE UNIQUE INDEX sepa_mandates_reference_uq ON sepa_mandates (group_id, reference);

-- Lots de prélèvement : un fichier remis à la banque
CREATE TABLE sepa_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  message_id text NOT NULL,
  collection_date date NOT NULL,
  -- SENT : fichier produit ; COLLECTED : paiements enregistrés
  status text NOT NULL DEFAULT 'SENT',
  count integer NOT NULL,
  total_cents bigint NOT NULL,
  xml text NOT NULL,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  collected_at timestamptz
);
CREATE INDEX sepa_batches_company_idx ON sepa_batches (company_id, created_at);

-- Facture présentée au prélèvement : lot, mandat et type de prélèvement (premier ou récurrent)
ALTER TABLE invoices ADD COLUMN sepa_batch_id uuid REFERENCES sepa_batches(id);
ALTER TABLE invoices ADD COLUMN sepa_mandate_id uuid REFERENCES sepa_mandates(id);
ALTER TABLE invoices ADD COLUMN sepa_sequence text;
