-- Fonctions propres aux métiers (voir FEATURES dans packages/shared)

-- Itinéos Vigie : points de passage d'un site, chacun avec son QR code à coller sur place
CREATE TABLE checkpoints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  name text NOT NULL,
  -- Contenu du QR code : imprévisible, pour qu'on ne puisse pas pointer sans être passé
  code text NOT NULL UNIQUE,
  position integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX checkpoints_site_idx ON checkpoints (site_id);

-- Points pointés pendant la ronde : [{ checkpointId, name, at }]
ALTER TABLE reports ADD COLUMN checkpoint_scans jsonb NOT NULL DEFAULT '[]';

-- Itinéos Constat / Expertise : heure de prise de vue (appareil) et empreinte SHA-256 de chaque photo
ALTER TABLE report_photos ADD COLUMN taken_at timestamptz;
ALTER TABLE report_photos ADD COLUMN sha256 text;
