-- Suggestion d'attribution d'une intervention à un technicien (position, charge, habilitations, stock du véhicule).
-- Fonction à activer par société ; désactivée par défaut.
ALTER TABLE companies
  ADD COLUMN assign_suggestions boolean NOT NULL DEFAULT false,
  -- Localiser les adresses des sites (service public d'adresses, France) pour calculer les distances
  ADD COLUMN geocode_sites boolean NOT NULL DEFAULT false;

-- Matériel à prévoir pour l'intervention : [{ "articleId": "…", "quantity": 2 }]
ALTER TABLE interventions ADD COLUMN needed_parts jsonb NOT NULL DEFAULT '[]';

-- Origine des coordonnées d'un site : saisie, adresse localisée, ou position du technicien sur place
ALTER TABLE sites ADD COLUMN geo_source text;
