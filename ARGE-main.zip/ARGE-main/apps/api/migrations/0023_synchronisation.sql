-- Bouton « Synchroniser » du bureau : les téléphones des techniciens visés rechargent leur journée et leurs fiches
ALTER TABLE users ADD COLUMN sync_requested_at timestamptz;
