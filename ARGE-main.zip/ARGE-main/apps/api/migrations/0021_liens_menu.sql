-- Liens dans le menu : outils en ligne de la société (signature électronique, banque, comptabilité…),
-- ouverts dans un onglet à part (ces sites refusent en général d'être affichés à l'intérieur d'un autre)
ALTER TABLE companies ADD COLUMN menu_links jsonb NOT NULL DEFAULT '[]';
