-- Photos prises sur la fiche (avant / après / autre)

CREATE TABLE report_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  -- Identifiant créé par l'appareil : une photo renvoyée deux fois (réseau coupé) n'est gardée qu'une fois
  client_id uuid NOT NULL,
  kind text NOT NULL CHECK (kind IN ('BEFORE', 'AFTER', 'OTHER')),
  caption text,
  mime_type text NOT NULL,
  size_bytes integer NOT NULL,
  file_path text NOT NULL,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX report_photos_client_uq ON report_photos(report_id, client_id);
