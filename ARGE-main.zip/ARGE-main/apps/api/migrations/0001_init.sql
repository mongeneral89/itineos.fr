-- Itinéos : schéma initial
-- Doit rester cohérent avec src/db/schema.ts.
-- Pour toute évolution : créez un nouveau fichier 0002_xxx.sql, ne modifiez jamais un fichier déjà appliqué.

CREATE TYPE role AS ENUM ('GROUP_ADMIN','DIRECTOR','AGENCY_MANAGER','PLANNER','SALES','ACCOUNTANT','TECHNICIAN','VIEWER');
CREATE TYPE intervention_kind AS ENUM ('INSTALLATION','SAV','MAINTENANCE','OTHER');
CREATE TYPE intervention_status AS ENUM ('TO_PLAN','PLANNED','EN_ROUTE','ON_SITE','DONE','TO_RESUME','CANCELLED');
CREATE TYPE priority AS ENUM ('LOW','NORMAL','HIGH','URGENT');
CREATE TYPE report_status AS ENUM ('DRAFT','SIGNED','SENT');
CREATE TYPE client_type AS ENUM ('COMPANY','INDIVIDUAL');

-- Organisation

CREATE TABLE groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  name text NOT NULL,
  legal_name text,
  country_code varchar(2) NOT NULL,
  currency varchar(3) NOT NULL,
  locale text NOT NULL DEFAULT 'fr-FR',
  timezone text NOT NULL DEFAULT 'Europe/Paris',
  vat_number text,
  address text,
  postal_code text,
  city text,
  email text,
  phone text,
  document_prefix varchar(8) NOT NULL,
  legal_mentions text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX companies_group_idx ON companies(group_id);

CREATE TABLE agencies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id),
  name text NOT NULL,
  code varchar(16) NOT NULL,
  address text,
  postal_code text,
  city text,
  email text,
  phone text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX agencies_company_code_uq ON agencies(company_id, code);

CREATE TABLE teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agency_id uuid NOT NULL REFERENCES agencies(id),
  name text NOT NULL
);

-- Utilisateurs et droits

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  email text NOT NULL,
  password_hash text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text,
  locale text NOT NULL DEFAULT 'fr-FR',
  team_id uuid REFERENCES teams(id),
  skills text[] NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_uq ON users(email);

CREATE TABLE role_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  group_id uuid NOT NULL REFERENCES groups(id),
  role role NOT NULL,
  company_id uuid REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  -- une agence ne va jamais sans sa société
  CONSTRAINT role_scope_ck CHECK (agency_id IS NULL OR company_id IS NOT NULL)
);
CREATE INDEX role_assignments_user_idx ON role_assignments(user_id);

-- Clients, sites, équipements

CREATE TABLE clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  type client_type NOT NULL DEFAULT 'COMPANY',
  name text NOT NULL,
  email text,
  phone text,
  address text,
  postal_code text,
  city text,
  country_code varchar(2),
  external_ref text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX clients_company_idx ON clients(company_id);

CREATE TABLE contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text,
  phone text,
  role text
);

CREATE TABLE sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name text NOT NULL,
  address text,
  postal_code text,
  city text,
  country_code varchar(2),
  access_notes text,
  latitude double precision,
  longitude double precision
);

CREATE TABLE equipments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  category text NOT NULL,
  brand text,
  model text,
  serial_number text,
  location text,
  installed_at date,
  warranty_until date,
  under_contract boolean NOT NULL DEFAULT false,
  notes text
);

-- Modèles de fiches

CREATE TABLE form_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES groups(id),
  company_id uuid REFERENCES companies(id),
  name text NOT NULL,
  kind intervention_kind NOT NULL,
  version integer NOT NULL DEFAULT 1,
  schema jsonb NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Interventions et fiches

CREATE TABLE interventions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid NOT NULL REFERENCES agencies(id),
  number text NOT NULL,
  client_id uuid NOT NULL REFERENCES clients(id),
  site_id uuid NOT NULL REFERENCES sites(id),
  equipment_id uuid REFERENCES equipments(id),
  technician_id uuid REFERENCES users(id),
  kind intervention_kind NOT NULL,
  status intervention_status NOT NULL DEFAULT 'TO_PLAN',
  priority priority NOT NULL DEFAULT 'NORMAL',
  source text,
  reason text NOT NULL,
  scheduled_start timestamptz,
  scheduled_end timestamptz,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX interventions_company_number_uq ON interventions(company_id, number);
CREATE INDEX interventions_agency_start_idx ON interventions(agency_id, scheduled_start);
CREATE INDEX interventions_technician_idx ON interventions(technician_id);

CREATE TABLE reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  intervention_id uuid NOT NULL REFERENCES interventions(id) ON DELETE CASCADE,
  template_id uuid NOT NULL REFERENCES form_templates(id),
  template_schema jsonb NOT NULL,
  data jsonb NOT NULL DEFAULT '{}',
  arrived_at timestamptz,
  left_at timestamptz,
  labor_minutes integer,
  travel_minutes integer,
  outcome text,
  technician_signature text,
  client_signature text,
  client_signer_name text,
  client_absent boolean NOT NULL DEFAULT false,
  client_absent_reason text,
  status report_status NOT NULL DEFAULT 'DRAFT',
  signed_at timestamptz,
  pdf_path text,
  sent_at timestamptz,
  sent_to text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX reports_intervention_uq ON reports(intervention_id);

CREATE TABLE report_parts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  label text NOT NULL,
  reference text,
  quantity double precision NOT NULL DEFAULT 1
);

-- Technique

CREATE TABLE counters (
  company_id uuid NOT NULL REFERENCES companies(id),
  year integer NOT NULL,
  value integer NOT NULL DEFAULT 0,
  PRIMARY KEY (company_id, year)
);

CREATE TABLE audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL,
  user_id uuid,
  action text NOT NULL,
  entity text NOT NULL,
  entity_id uuid,
  details jsonb,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_group_at_idx ON audit_logs(group_id, at);
