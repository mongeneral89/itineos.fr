-- Langue des documents par client, messagerie interne et annuaire.

-- Langue des documents envoyés au client (devis, factures, fiches, e-mails) ; vide = langue de la société
ALTER TABLE clients ADD COLUMN locale text;

-- ─── Messagerie interne ───
-- Une conversation à deux (DIRECT) ou de groupe (GROUP), entre personnes du même groupe d'entreprises.
CREATE TABLE conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  kind text NOT NULL CHECK (kind IN ('DIRECT', 'GROUP')),
  -- Nom d'une conversation de groupe (vide pour une conversation à deux)
  title text,
  -- Conversation à deux : les deux identifiants triés, pour ne jamais en créer deux pour la même paire
  direct_key text UNIQUE,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_message_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX conversations_group_idx ON conversations (group_id, last_message_at DESC);

CREATE TABLE conversation_members (
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at timestamptz NOT NULL DEFAULT now(),
  -- Jusqu'où la personne a lu (les messages plus récents sont « non lus »)
  last_read_at timestamptz,
  PRIMARY KEY (conversation_id, user_id)
);
CREATE INDEX conversation_members_user_idx ON conversation_members (user_id);

CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  -- Vide : message du système (« X a ajouté Y »)
  sender_id uuid REFERENCES users(id) ON DELETE SET NULL,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  edited_at timestamptz,
  deleted_at timestamptz
);
CREATE INDEX messages_conversation_time_idx ON messages (conversation_id, created_at DESC);

-- ─── Annuaire : contacts extérieurs (fournisseurs, sous-traitants, numéros utiles…) ───
-- Les numéros des salariés viennent de leur compte (users.phone).
CREATE TABLE directory_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  -- Vide = visible de tout le groupe ; agence vide = toute la société
  company_id uuid REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  category text NOT NULL DEFAULT 'OTHER'
    CHECK (category IN ('SUPPLIER', 'SUBCONTRACTOR', 'MANUFACTURER', 'EMERGENCY', 'ADMINISTRATION', 'OTHER')),
  -- Personne ou service (« Service après-vente », « Jean Martin »)
  name text NOT NULL,
  organization text,
  phone text,
  mobile text,
  email text,
  address text,
  website text,
  notes text,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX directory_contacts_group_idx ON directory_contacts (group_id, category);
