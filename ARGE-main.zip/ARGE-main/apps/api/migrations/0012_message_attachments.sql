-- Messagerie : une photo ou un fichier joint par message (le texte devient facultatif).
ALTER TABLE messages
  ADD COLUMN attachment_path text,
  ADD COLUMN attachment_name text,
  ADD COLUMN attachment_mime text,
  ADD COLUMN attachment_size integer;
