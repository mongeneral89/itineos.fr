-- Mot de passe oublié et changement de mot de passe

-- Date du dernier changement : les sessions ouvertes avant sont refusées
ALTER TABLE users ADD COLUMN password_changed_at timestamptz;

-- Liens de réinitialisation envoyés par e-mail. Seule l'empreinte du jeton est gardée :
-- une fuite de la base ne permet pas de réutiliser un lien.
CREATE TABLE password_resets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX password_resets_token_uq ON password_resets(token_hash);
CREATE INDEX password_resets_user_idx ON password_resets(user_id);
