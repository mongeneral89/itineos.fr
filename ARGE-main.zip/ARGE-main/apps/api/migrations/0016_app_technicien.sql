-- Fonctions reprises de l'« App technicien admin » : rester connecté, planning de l'équipe pour les techniciens,
-- notifications, recherche client avancée, matériel difficile à repérer, document choisi pour une intervention.

-- « Déconnecter tous mes appareils » : les sessions ouvertes avant cette date sont refusées
ALTER TABLE users ADD COLUMN sessions_revoked_at timestamptz;

-- Planning de l'équipe vu par un technicien : le sien seulement (OWN), toute son agence (AGENCY),
-- ou les collègues choisis par le bureau (CUSTOM, liste dans planning_shares)
ALTER TABLE users ADD COLUMN planning_view text NOT NULL DEFAULT 'OWN' CHECK (planning_view IN ('OWN', 'AGENCY', 'CUSTOM'));
CREATE TABLE planning_shares (
  viewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (viewer_id, target_id)
);

-- Notifications : préférences de chacun et téléphones / navigateurs abonnés (Web Push)
ALTER TABLE users ADD COLUMN notify_prefs jsonb NOT NULL DEFAULT '{}';
CREATE TABLE push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint text NOT NULL UNIQUE,
  p256dh text NOT NULL,
  auth text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz
);
CREATE INDEX push_subscriptions_user_idx ON push_subscriptions (user_id);

-- Matériel installé : indication pour le retrouver (« derrière la trappe du placard… »)
ALTER TABLE equipments ADD COLUMN locate_hint text;

-- N° d'abonné du client (télésurveillance, contrat…)
ALTER TABLE clients ADD COLUMN subscriber_number text;

-- Document à remplir choisi pour cette intervention (sinon : le modèle par défaut de son type)
ALTER TABLE interventions ADD COLUMN template_id uuid REFERENCES form_templates(id);

-- Recherche sans accents ni majuscules
CREATE OR REPLACE FUNCTION itn_norm(t text) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT translate(replace(replace(lower(coalesce(t, '')), 'œ', 'oe'), 'æ', 'ae'),
    'àáâãäåāçćčèéêëēėęìíîïīñńòóôõöøōœùúûüūýÿžźżšśłđ',
    'aaaaaaaccceeeeeeeiiiiinnoooooooeuuuuuyyzzzssld')
$$;
-- Chiffres seuls (numéros de téléphone écrits de toutes les façons)
CREATE OR REPLACE FUNCTION itn_digits(t text) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT regexp_replace(coalesce(t, ''), '[^0-9]', '', 'g')
$$;
