-- Facture électronique (Factur-X) et envoi à une plateforme agréée
ALTER TABLE companies ADD COLUMN siren text;
-- Option pour le paiement de la TVA d'après les débits (mention obligatoire si elle est choisie)
ALTER TABLE companies ADD COLUMN vat_on_debits boolean NOT NULL DEFAULT false;
-- Plateforme agréée choisie par la société : adresse de son API, jeton d'accès, envoi automatique à l'émission
ALTER TABLE companies ADD COLUMN einvoice_api_url text;
ALTER TABLE companies ADD COLUMN einvoice_api_token text;
ALTER TABLE companies ADD COLUMN einvoice_auto_send boolean NOT NULL DEFAULT false;

ALTER TABLE clients ADD COLUMN siren text;
ALTER TABLE clients ADD COLUMN vat_number text;

-- Nature de l'opération (services, biens ou les deux) : mention obligatoire
ALTER TABLE invoices ADD COLUMN operation_type text NOT NULL DEFAULT 'SERVICES';
-- Suivi de la facture à la plateforme : identifiant du dépôt, statut (cycle de vie), dernière erreur
ALTER TABLE invoices ADD COLUMN einvoice_flow_id text;
ALTER TABLE invoices ADD COLUMN einvoice_status text;
ALTER TABLE invoices ADD COLUMN einvoice_status_at timestamptz;
ALTER TABLE invoices ADD COLUMN einvoice_error text;
