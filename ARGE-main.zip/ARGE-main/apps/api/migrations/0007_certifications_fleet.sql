-- Habilitations des techniciens et parc véhicules

-- ─── Habilitations ───

-- Types d'habilitation, communs au groupe (habilitation électrique, fluides frigorigènes, CACES…)
CREATE TABLE certification_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  code text NOT NULL,
  name text NOT NULL,
  description text,
  -- Durée de validité habituelle, pour proposer la date d'expiration
  validity_months integer,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX certification_types_code_uq ON certification_types(group_id, lower(code));

CREATE TABLE user_certifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type_id uuid NOT NULL REFERENCES certification_types(id),
  obtained_on date,
  expires_on date,
  reference text,
  notes text,
  document_path text,
  document_mime text,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX user_certifications_user_idx ON user_certifications(user_id);

-- Habilitations exigées pour une intervention
ALTER TABLE interventions ADD COLUMN required_certification_ids uuid[] NOT NULL DEFAULT '{}';

-- ─── Parc véhicules ───

CREATE TABLE vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  plate text NOT NULL,
  type text NOT NULL DEFAULT 'VAN' CHECK (type IN ('VAN', 'CAR', 'TRUCK', 'OTHER')),
  make text,
  model text,
  vin text,
  fuel text,
  first_registration date,
  ownership text NOT NULL DEFAULT 'OWNED' CHECK (ownership IN ('OWNED', 'LEASED', 'RENTED')),
  lessor text,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'IMMOBILIZED', 'RETIRED')),
  mileage integer,
  mileage_updated_on date,
  driver_id uuid REFERENCES users(id),
  stock_location_id uuid REFERENCES stock_locations(id),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX vehicles_plate_uq ON vehicles(company_id, upper(replace(plate, ' ', '')));

CREATE TABLE vehicle_deadlines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('SERVICE', 'TECH_INSPECTION', 'INSURANCE', 'TIRES', 'LEASE_END', 'OTHER')),
  label text,
  due_date date,
  due_mileage integer,
  -- Récurrence : la prochaine échéance est recalculée quand l'entretien est noté
  interval_months integer,
  interval_km integer,
  -- Rendez-vous pris (garage, date)
  appointment_on date,
  appointment_with text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (due_date IS NOT NULL OR due_mileage IS NOT NULL)
);
CREATE INDEX vehicle_deadlines_vehicle_idx ON vehicle_deadlines(vehicle_id);

CREATE TABLE vehicle_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('SERVICE', 'REPAIR', 'TECH_INSPECTION', 'TIRES', 'ACCIDENT', 'MILEAGE', 'OTHER')),
  occurred_on date NOT NULL,
  mileage integer,
  cost_cents bigint,
  provider text,
  description text,
  deadline_id uuid REFERENCES vehicle_deadlines(id) ON DELETE SET NULL,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX vehicle_events_vehicle_idx ON vehicle_events(vehicle_id, occurred_on);

-- Envois automatiques (récapitulatif quotidien des échéances) : une fois par jour, même après un redémarrage
CREATE TABLE job_runs (
  job text NOT NULL,
  run_on date NOT NULL,
  PRIMARY KEY (job, run_on)
);
