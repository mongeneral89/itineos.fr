-- Accès « support » demandé depuis la console de supervision : l'administrateur du client l'accepte ou le refuse.
-- Accepté, un compte « Support » est ouvert jusqu'à expires_at, puis fermé.
CREATE TABLE support_access (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  command_id uuid NOT NULL UNIQUE,
  reason text NOT NULL,
  hours integer NOT NULL,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REFUSED', 'EXPIRED', 'CLOSED')),
  decided_by uuid REFERENCES users(id),
  decided_at timestamptz,
  expires_at timestamptz,
  user_id uuid REFERENCES users(id),
  -- Résultat transmis à la console (une seule fois) : le mot de passe n'est jamais gardé ici
  reported boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX support_access_status_idx ON support_access(status);
