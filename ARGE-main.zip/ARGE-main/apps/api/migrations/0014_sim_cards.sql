-- Cartes SIM (transmetteurs d'alarme, routeurs…) : suivi de l'activation, faite sur le site du prestataire.
CREATE TABLE sim_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  -- Vide = carte de toute la société
  agency_id uuid REFERENCES agencies(id),
  -- Numéro imprimé sur la carte (19 ou 20 chiffres), unique dans le groupe
  iccid text NOT NULL,
  phone_number text,
  operator text,
  plan text,
  status text NOT NULL DEFAULT 'STOCK'
    CHECK (status IN ('STOCK', 'TO_ACTIVATE', 'REQUESTED', 'ACTIVE', 'SUSPENDED', 'TERMINATED')),
  client_id uuid REFERENCES clients(id) ON DELETE SET NULL,
  site_id uuid REFERENCES sites(id) ON DELETE SET NULL,
  -- Appareil dans lequel la carte est posée (transmetteur…)
  device text,
  requested_at timestamptz,
  activated_at timestamptz,
  terminated_at timestamptz,
  notes text,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (group_id, iccid)
);
CREATE INDEX sim_cards_company_idx ON sim_cards (company_id, status);

-- Site du prestataire où se fait l'activation (lien ouvert depuis l'onglet Cartes SIM)
ALTER TABLE companies ADD COLUMN sim_provider text, ADD COLUMN sim_portal_url text;
