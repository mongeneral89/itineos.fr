-- Documents fournis et documents de groupe déjà présents : à choisir sur l'intervention, jamais pris d'office
UPDATE form_templates SET auto_pick = false
WHERE company_id IS NULL
  AND name IN (
    'Consignes de télésurveillance', 'Remote monitoring instructions',
    'Consignes de télésurveillance (Teles)',
    'Dossier technique – bon de sortie télésurveillance', 'Dossier technique – bon de sortie vidéoprotection'
  );
