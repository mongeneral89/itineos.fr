-- Relances automatiques des factures impayées : 1 rappel, 2 relance, 3 mise en demeure,
-- envoyées par e-mail tant de jours après l'échéance (réglable par société, désactivé par défaut)
ALTER TABLE companies ADD COLUMN dunning_enabled boolean NOT NULL DEFAULT false;
ALTER TABLE companies ADD COLUMN dunning_days integer[] NOT NULL DEFAULT '{7,15,30}';

-- Où en est chaque facture : dernier niveau envoyé, quand, et relances suspendues (litige, promesse de paiement)
ALTER TABLE invoices ADD COLUMN dunning_level integer NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN dunning_last_on date;
ALTER TABLE invoices ADD COLUMN dunning_paused boolean NOT NULL DEFAULT false;

-- Historique des relances envoyées (sent_by_id vide : envoi automatique)
CREATE TABLE invoice_reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  level integer NOT NULL CHECK (level BETWEEN 1 AND 3),
  sent_to text NOT NULL,
  sent_by_id uuid REFERENCES users(id),
  sent_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX invoice_reminders_invoice_idx ON invoice_reminders (invoice_id);
