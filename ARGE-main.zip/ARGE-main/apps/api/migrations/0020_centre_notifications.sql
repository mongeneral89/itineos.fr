-- Centre de notifications (cloche du logiciel) : chaque notification envoyée y est gardée, lue ou non
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  url text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz
);
CREATE INDEX notifications_user_idx ON notifications (user_id, created_at DESC);

-- Qui a planifié l'intervention (prévenu quand elle est terminée), et retard déjà signalé
ALTER TABLE interventions ADD COLUMN planned_by_id uuid REFERENCES users(id);
ALTER TABLE interventions ADD COLUMN late_notified_at timestamptz;
