-- Modèle « document à choisir » : jamais pris d'office pour une nouvelle fiche, on le choisit sur l'intervention
-- (consignes de télésurveillance, dossier technique, procès-verbal de réception…)
ALTER TABLE form_templates ADD COLUMN auto_pick boolean NOT NULL DEFAULT true;
