-- Immatriculation unique quelle que soit l'écriture : « AB-123-CD », « ab 123 cd » et « AB123CD » sont identiques
DROP INDEX IF EXISTS vehicles_plate_uq;
CREATE UNIQUE INDEX vehicles_plate_uq ON vehicles(company_id, upper(regexp_replace(plate, '[^A-Za-z0-9]', '', 'g')));
