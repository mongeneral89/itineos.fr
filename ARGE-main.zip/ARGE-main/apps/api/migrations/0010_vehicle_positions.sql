-- Géolocalisation des véhicules : la position est envoyée par le téléphone du conducteur, pendant que l'appli
-- terrain est ouverte, et seulement s'il a lui-même activé le partage (règles de la CNIL sur la géolocalisation
-- des salariés : information, possibilité d'arrêter, durée de conservation limitée).

-- Accord du technicien : date d'activation du partage (vide = pas de partage)
ALTER TABLE users ADD COLUMN location_sharing_since timestamptz;

-- Dernière position connue de chaque véhicule (pour afficher la carte sans parcourir l'historique)
ALTER TABLE vehicles ADD COLUMN last_lat double precision;
ALTER TABLE vehicles ADD COLUMN last_lng double precision;
ALTER TABLE vehicles ADD COLUMN last_accuracy_m integer;
ALTER TABLE vehicles ADD COLUMN last_position_at timestamptz;
ALTER TABLE vehicles ADD COLUMN last_position_by uuid REFERENCES users(id) ON DELETE SET NULL;

-- Historique des positions (effacé automatiquement après 30 jours)
CREATE TABLE vehicle_positions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  accuracy_m integer,
  -- Heure réelle sur le téléphone (une position envoyée après une coupure de réseau garde son heure)
  recorded_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  -- Ce qui a déclenché l'envoi : suivi régulier, départ, arrivée sur place
  event text NOT NULL DEFAULT 'TRACK' CHECK (event IN ('TRACK', 'EN_ROUTE', 'ON_SITE')),
  intervention_id uuid REFERENCES interventions(id) ON DELETE SET NULL
);
CREATE INDEX vehicle_positions_vehicle_time_idx ON vehicle_positions (vehicle_id, recorded_at DESC);
CREATE INDEX vehicle_positions_time_idx ON vehicle_positions (recorded_at);
