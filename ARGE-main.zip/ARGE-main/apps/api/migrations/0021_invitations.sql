-- Invitation d'un collègue (technicien surtout) : lien personnel à usage unique, valable 7 jours, envoyé par
-- WhatsApp, e-mail ou QR code ; il choisit son mot de passe, puis l'appli s'ouvre connectée (code de 15 minutes)
CREATE TABLE invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  app_code_hash text UNIQUE,
  app_code_expires_at timestamptz,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX invitations_user_idx ON invitations (user_id);
