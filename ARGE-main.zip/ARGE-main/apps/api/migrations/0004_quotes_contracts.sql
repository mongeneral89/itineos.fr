-- Devis et contrats d'entretien

-- Numérotation : une suite par société, par type de document et par année
-- (interventions, devis, contrats, puis factures)
ALTER TABLE counters ADD COLUMN kind text NOT NULL DEFAULT 'intervention';
ALTER TABLE counters DROP CONSTRAINT counters_pkey;
ALTER TABLE counters ADD PRIMARY KEY (company_id, kind, year);

CREATE TABLE quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  number text NOT NULL,
  client_id uuid NOT NULL REFERENCES clients(id),
  site_id uuid REFERENCES sites(id),
  kind text NOT NULL DEFAULT 'WORK' CHECK (kind IN ('WORK', 'CONTRACT')),
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'SENT', 'ACCEPTED', 'REFUSED', 'CANCELLED')),
  title text NOT NULL,
  intro text,
  notes text,
  valid_until date,
  -- Pour un devis de contrat : fréquence des visites proposée
  contract_frequency_months integer,
  currency varchar(3) NOT NULL,
  net_cents bigint NOT NULL DEFAULT 0,
  vat_cents bigint NOT NULL DEFAULT 0,
  gross_cents bigint NOT NULL DEFAULT 0,
  source_intervention_id uuid REFERENCES interventions(id),
  created_by_id uuid REFERENCES users(id),
  sent_at timestamptz,
  sent_to text,
  decided_at timestamptz,
  pdf_path text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX quotes_company_number_uq ON quotes(company_id, number);
CREATE INDEX quotes_client_idx ON quotes(client_id);

CREATE TABLE quote_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id uuid NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
  position integer NOT NULL,
  description text NOT NULL,
  quantity double precision NOT NULL DEFAULT 1,
  unit text,
  unit_price_cents bigint NOT NULL DEFAULT 0,
  vat_rate_bp integer NOT NULL DEFAULT 2000
);
CREATE INDEX quote_lines_quote_idx ON quote_lines(quote_id);

CREATE TABLE contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid NOT NULL REFERENCES agencies(id),
  number text NOT NULL,
  client_id uuid NOT NULL REFERENCES clients(id),
  site_id uuid NOT NULL REFERENCES sites(id),
  equipment_ids uuid[] NOT NULL DEFAULT '{}',
  title text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED', 'ENDED')),
  frequency_months integer NOT NULL CHECK (frequency_months BETWEEN 1 AND 60),
  start_date date NOT NULL,
  end_date date,
  visit_hours double precision NOT NULL DEFAULT 1,
  annual_price_cents bigint,
  notes text,
  quote_id uuid REFERENCES quotes(id),
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX contracts_company_number_uq ON contracts(company_id, number);
CREATE INDEX contracts_client_idx ON contracts(client_id);

-- Interventions : d'où elles viennent, et pour quand elles sont attendues
ALTER TABLE interventions ADD COLUMN contract_id uuid REFERENCES contracts(id);
ALTER TABLE interventions ADD COLUMN quote_id uuid REFERENCES quotes(id);
ALTER TABLE interventions ADD COLUMN due_date date;
-- Une seule visite par contrat et par échéance : la génération peut être relancée sans doublon
CREATE UNIQUE INDEX interventions_contract_due_uq ON interventions(contract_id, due_date) WHERE contract_id IS NOT NULL;
