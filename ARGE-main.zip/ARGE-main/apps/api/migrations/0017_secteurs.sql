-- Secteurs d'activité : chaque société choisit son métier (techniciens, sécurité privée, commissaires de justice,
-- expertise, états des lieux, multiservices). Il fixe le vocabulaire, les modules visibles et les modèles fournis.
ALTER TABLE companies ADD COLUMN sector text NOT NULL DEFAULT 'TECH'
  CHECK (sector IN ('TECH', 'SECURITY', 'BAILIFF', 'EXPERTISE', 'RENTAL', 'SERVICES'));

-- Modèles fournis pour un secteur (vide = modèles neutres des techniciens, et documents communs à tous)
ALTER TABLE form_templates ADD COLUMN sector text
  CHECK (sector IS NULL OR sector IN ('SECURITY', 'BAILIFF', 'EXPERTISE', 'RENTAL', 'SERVICES'));
