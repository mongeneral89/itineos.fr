-- Portail client : les clients de l'entreprise se connectent pour suivre leurs interventions, devis et factures

-- Accès au portail : une personne chez le client (un client peut avoir plusieurs accès).
-- Le mot de passe est choisi par la personne elle-même, à partir du lien d'invitation reçu par e-mail.
CREATE TABLE portal_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  email text NOT NULL,
  name text NOT NULL,
  password_hash text,
  locale text NOT NULL DEFAULT 'fr-FR',
  active boolean NOT NULL DEFAULT true,
  password_changed_at timestamptz,
  last_login_at timestamptz,
  invited_at timestamptz,
  invited_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX portal_users_email_uq ON portal_users (lower(email));
CREATE INDEX portal_users_client_idx ON portal_users (client_id);

-- Liens envoyés par e-mail (invitation, mot de passe oublié) : seule l'empreinte du jeton est gardée
CREATE TABLE portal_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  portal_user_id uuid NOT NULL REFERENCES portal_users(id) ON DELETE CASCADE,
  purpose text NOT NULL CHECK (purpose IN ('invite', 'reset')),
  token_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX portal_tokens_hash_uq ON portal_tokens (token_hash);
CREATE INDEX portal_tokens_user_idx ON portal_tokens (portal_user_id);

-- Demande d'intervention faite depuis le portail : qui l'a faite, et ses disponibilités
ALTER TABLE interventions ADD COLUMN requested_by_portal_user_id uuid REFERENCES portal_users(id) ON DELETE SET NULL;
ALTER TABLE interventions ADD COLUMN client_notes text;

-- Devis accepté ou refusé par le client en ligne : par qui, et son commentaire
ALTER TABLE quotes ADD COLUMN decided_by_portal_user_id uuid REFERENCES portal_users(id) ON DELETE SET NULL;
ALTER TABLE quotes ADD COLUMN decision_name text;
ALTER TABLE quotes ADD COLUMN decision_note text;
