-- Stock : catalogue d'articles, lieux (dépôts, véhicules), niveaux, mouvements, bons de sortie

CREATE TABLE articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  reference text NOT NULL,
  name text NOT NULL,
  category text,
  unit text NOT NULL DEFAULT 'u',
  purchase_price_cents bigint,
  sale_price_cents bigint,
  vat_rate_bp integer NOT NULL DEFAULT 2000,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX articles_company_reference_uq ON articles(company_id, lower(reference));

CREATE TABLE stock_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  kind text NOT NULL CHECK (kind IN ('DEPOT', 'VEHICLE')),
  name text NOT NULL,
  -- Véhicule : le technicien qui l'utilise (un seul véhicule actif par technicien)
  technician_id uuid REFERENCES users(id),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (kind = 'DEPOT' OR technician_id IS NOT NULL)
);
CREATE UNIQUE INDEX stock_locations_technician_uq ON stock_locations(technician_id) WHERE active AND technician_id IS NOT NULL;

CREATE TABLE stock_levels (
  location_id uuid NOT NULL REFERENCES stock_locations(id),
  article_id uuid NOT NULL REFERENCES articles(id),
  quantity double precision NOT NULL DEFAULT 0,
  min_quantity double precision NOT NULL DEFAULT 0,
  PRIMARY KEY (location_id, article_id)
);

CREATE TABLE stock_slips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  number text,
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'VALIDATED', 'CANCELLED')),
  from_location_id uuid NOT NULL REFERENCES stock_locations(id),
  -- Destination : un autre lieu (véhicule) OU une intervention (sortie chantier)
  to_location_id uuid REFERENCES stock_locations(id),
  intervention_id uuid REFERENCES interventions(id),
  notes text,
  created_by_id uuid REFERENCES users(id),
  validated_by_id uuid REFERENCES users(id),
  validated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (to_location_id IS NULL OR to_location_id <> from_location_id)
);
CREATE UNIQUE INDEX stock_slips_company_number_uq ON stock_slips(company_id, number) WHERE number IS NOT NULL;

CREATE TABLE stock_slip_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slip_id uuid NOT NULL REFERENCES stock_slips(id) ON DELETE CASCADE,
  position integer NOT NULL,
  article_id uuid NOT NULL REFERENCES articles(id),
  quantity double precision NOT NULL CHECK (quantity > 0)
);

CREATE TABLE stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  article_id uuid NOT NULL REFERENCES articles(id),
  kind text NOT NULL CHECK (kind IN ('RECEIPT', 'TRANSFER', 'ISSUE', 'CONSUMPTION', 'ADJUSTMENT')),
  from_location_id uuid REFERENCES stock_locations(id),
  to_location_id uuid REFERENCES stock_locations(id),
  quantity double precision NOT NULL CHECK (quantity > 0),
  slip_id uuid REFERENCES stock_slips(id),
  intervention_id uuid REFERENCES interventions(id),
  note text,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (from_location_id IS NOT NULL OR to_location_id IS NOT NULL)
);
CREATE INDEX stock_movements_article_idx ON stock_movements(article_id, created_at);
CREATE INDEX stock_movements_location_idx ON stock_movements(from_location_id);
CREATE INDEX stock_movements_location_to_idx ON stock_movements(to_location_id);

-- Pièces de la fiche reliées au catalogue (déduites du véhicule à la signature)
ALTER TABLE report_parts ADD COLUMN article_id uuid REFERENCES articles(id);
