-- Logo de la société : affiché dans le logiciel, l'espace client et en tête des documents PDF
ALTER TABLE companies ADD COLUMN logo_path text;
ALTER TABLE companies ADD COLUMN logo_updated_at timestamptz;
