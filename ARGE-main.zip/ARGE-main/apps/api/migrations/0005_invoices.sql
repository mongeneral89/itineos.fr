-- Facturation : factures, avoirs, paiements

-- Réglages de facturation de chaque société
ALTER TABLE companies ADD COLUMN payment_terms_days integer NOT NULL DEFAULT 30;
ALTER TABLE companies ADD COLUMN hourly_rate_cents bigint;    -- taux horaire de main-d'œuvre HT
ALTER TABLE companies ADD COLUMN travel_fee_cents bigint;     -- forfait de déplacement HT
ALTER TABLE companies ADD COLUMN bank_details text;           -- IBAN / BIC imprimés sur les factures

CREATE TABLE invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  company_id uuid NOT NULL REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  kind text NOT NULL DEFAULT 'INVOICE' CHECK (kind IN ('INVOICE', 'CREDIT_NOTE')),
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'ISSUED')),
  -- Attribué à l'émission seulement : numérotation continue, sans trou
  number text,
  client_id uuid NOT NULL REFERENCES clients(id),
  site_id uuid REFERENCES sites(id),
  title text NOT NULL,
  notes text,
  issue_date date,
  service_date date,
  due_date date,
  payment_terms_days integer NOT NULL DEFAULT 30,
  currency varchar(3) NOT NULL,
  net_cents bigint NOT NULL DEFAULT 0,
  vat_cents bigint NOT NULL DEFAULT 0,
  gross_cents bigint NOT NULL DEFAULT 0,
  source_intervention_id uuid REFERENCES interventions(id),
  source_quote_id uuid REFERENCES quotes(id),
  contract_id uuid REFERENCES contracts(id),
  credited_invoice_id uuid REFERENCES invoices(id),
  pdf_path text,
  sent_at timestamptz,
  sent_to text,
  created_by_id uuid REFERENCES users(id),
  issued_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (status = 'DRAFT' OR (number IS NOT NULL AND issue_date IS NOT NULL))
);
CREATE UNIQUE INDEX invoices_company_number_uq ON invoices(company_id, number) WHERE number IS NOT NULL;
CREATE INDEX invoices_client_idx ON invoices(client_id);
CREATE INDEX invoices_company_issue_idx ON invoices(company_id, issue_date);

CREATE TABLE invoice_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  position integer NOT NULL,
  description text NOT NULL,
  quantity double precision NOT NULL DEFAULT 1,
  unit text,
  unit_price_cents bigint NOT NULL DEFAULT 0,
  vat_rate_bp integer NOT NULL DEFAULT 2000
);
CREATE INDEX invoice_lines_invoice_idx ON invoice_lines(invoice_id);

CREATE TABLE payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id),
  paid_on date NOT NULL,
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  method text NOT NULL,
  reference text,
  created_by_id uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payments_invoice_idx ON payments(invoice_id);
