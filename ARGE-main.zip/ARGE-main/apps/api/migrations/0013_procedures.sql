-- Notices et procédures : bibliothèque de documents consultée depuis l'appli terrain.
-- Le bureau publie directement ; un document proposé par un technicien attend sa validation.
CREATE TABLE procedures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id),
  -- Vide = tout le groupe ; agence vide = toute la société
  company_id uuid REFERENCES companies(id),
  agency_id uuid REFERENCES agencies(id),
  category text NOT NULL DEFAULT 'OTHER'
    CHECK (category IN ('PROCEDURE', 'MANUAL', 'TECHNICAL', 'SAFETY', 'FORM', 'OTHER')),
  title text NOT NULL,
  description text,
  -- Mots-clés pour la recherche sur le terrain : marque, modèle, référence…
  keywords text,
  -- Le document lui-même (PDF, photo, document bureautique, vidéo) et/ou un lien
  file_path text,
  file_name text,
  file_mime text,
  file_size integer,
  url text,
  status text NOT NULL DEFAULT 'APPROVED' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  submitted_by uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_by uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  -- Motif du refus, montré à la personne qui a proposé le document
  review_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX procedures_group_idx ON procedures (group_id, status, category);
