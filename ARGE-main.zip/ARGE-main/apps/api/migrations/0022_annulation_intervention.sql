-- Annulation d'une intervention : motif, date et auteur (le technicien concerné est prévenu)
ALTER TABLE interventions ADD COLUMN cancel_reason text;
ALTER TABLE interventions ADD COLUMN cancelled_at timestamptz;
ALTER TABLE interventions ADD COLUMN cancelled_by_id uuid REFERENCES users(id);
