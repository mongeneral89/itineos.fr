import type { CapacitorConfig } from '@capacitor/cli';

/**
 * Appli Android : les écrans (dist/, construit par Vite) sont rangés dans l'APK, l'API est sur le serveur
 * choisi à la connexion. Voir ANDROID.md.
 *
 * Les pages sont servies en http://localhost : le navigateur du téléphone le considère comme sûr (appareil photo,
 * position), et l'appli peut appeler un PC du réseau local en http pendant les essais.
 */
const config: CapacitorConfig = {
  // Version A.R.G.E. : nom, identifiant et logo du client (écrans construits avec .env.arge)
  appId: 'fr.arge.terrain',
  appName: 'A.R.G.E.',
  webDir: 'dist',
  server: {
    androidScheme: 'http',
    cleartext: true,
  },
  android: {
    // Inspection depuis Chrome du PC (chrome://inspect) : seulement si APP_DEBUG=1 à la construction,
    // jamais dans les versions publiées
    webContentsDebuggingEnabled: process.env.APP_DEBUG === '1',
  },
};

export default config;
