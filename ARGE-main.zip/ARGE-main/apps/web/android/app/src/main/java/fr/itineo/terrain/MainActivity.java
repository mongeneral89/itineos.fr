package fr.itineo.terrain;

import android.os.Bundle;
import android.webkit.WebSettings;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // L'appli garde sa mise en page : la taille du texte des réglages d'Android ne la fait plus déborder,
        // et le zoom à deux doigts est désactivé (voir aussi la balise viewport, main.tsx)
        WebSettings settings = getBridge().getWebView().getSettings();
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
    }
}
