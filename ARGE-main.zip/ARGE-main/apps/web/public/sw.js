/**
 * Service worker de l'appli : garde l'appli elle-même sur l'appareil pour qu'elle s'ouvre sans réseau.
 * Les données (journée, fiches, photos) ne passent pas par ici : elles sont gérées par l'appli
 * (src/offline/), qui sait quoi garder et quoi renvoyer.
 *
 *  - Pages : réseau d'abord (toujours la dernière version), sinon la copie
 *  - Fichiers de l'appli (/assets/…, noms uniques à chaque version) : la copie d'abord
 *  - Polices Google : la copie, mise à jour en arrière-plan
 *  - /api : jamais intercepté
 */
const CACHE = 'itineo-app-v2';
const SHELL = ['/', '/index.html', '/manifest.webmanifest', '/icon.svg'];

/** Fichiers de la version en cours, lus dans index.html */
async function currentAssets() {
  const html = await (await fetch('/index.html', { cache: 'no-store' })).text();
  return [...html.matchAll(/(?:src|href)="(\/assets\/[^"]+)"/g)].map((m) => m[1]);
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll([...SHELL, ...(await currentAssets())]);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    // Anciennes versions de l'appli : supprimées
    for (const name of await caches.keys()) if (name !== CACHE) await caches.delete(name);
    const cache = await caches.open(CACHE);
    const keep = new Set((await currentAssets().catch(() => [])).map((p) => new URL(p, self.location.origin).href));
    if (keep.size) {
      for (const req of await cache.keys()) {
        if (new URL(req.url).pathname.startsWith('/assets/') && !keep.has(req.url)) await cache.delete(req);
      }
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (url.origin === self.location.origin && url.pathname.startsWith('/api/')) return;

  // Pages de l'appli (/tech, /tech/123…) : toutes servies par index.html
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        const cache = await caches.open(CACHE);
        await cache.put('/index.html', fresh.clone());
        return fresh;
      } catch {
        return (await caches.match('/index.html')) ?? Response.error();
      }
    })());
    return;
  }

  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      const cached = await caches.match(req);
      if (cached) return cached;
      const fresh = await fetch(req);
      if (fresh.ok && url.pathname.startsWith('/assets/')) (await caches.open(CACHE)).put(req, fresh.clone());
      return fresh;
    })());
    return;
  }

  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE);
      const cached = await cache.match(req);
      const update = fetch(req).then((res) => {
        if (res.ok || res.type === 'opaque') cache.put(req, res.clone());
        return res;
      }).catch(() => cached);
      return cached ?? update;
    })());
  }
});

// ─── Notifications (même appli fermée) ───
self.addEventListener('push', (event) => {
  let n = { title: 'Itinéos', body: '', url: '/', tag: undefined };
  try {
    n = { ...n, ...event.data.json() };
  } catch {
    if (event.data) n.body = event.data.text();
  }
  event.waitUntil((async () => {
    // « Synchroniser » du bureau : l'appli déjà ouverte recharge sa journée et ses fiches tout de suite
    if (n.sync) {
      for (const w of await self.clients.matchAll({ type: 'window', includeUncontrolled: true })) w.postMessage({ type: 'itineo-sync' });
    }
    await self.registration.showNotification(n.title, {
      body: n.body, tag: n.tag, renotify: !!n.tag, icon: '/icon.svg', badge: '/icon.svg', data: { url: n.url },
    });
  })());
});

// Toucher la notification ouvre la bonne page (dans la fenêtre Itinéos déjà ouverte s'il y en a une)
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = new URL(event.notification.data?.url ?? '/', self.location.origin).href;
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const w of wins) {
      if (new URL(w.url).origin === self.location.origin) {
        await w.focus();
        return w.navigate(url);
      }
    }
    return self.clients.openWindow(url);
  })());
});
