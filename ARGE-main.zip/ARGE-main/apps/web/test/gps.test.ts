import { test } from 'node:test';
import assert from 'node:assert/strict';
import { routeUrl } from '../src/components/GoButton';

test('« Y aller » : itinéraire dans chaque appli GPS, par coordonnées ou par adresse', () => {
  const addr = { address: '12 rue de la Paix 54000 Nancy' };
  const ll = { address: 'x', lat: 48.69, lng: 6.18 };
  assert.equal(routeUrl('waze', ll), 'https://waze.com/ul?ll=48.69,6.18&navigate=yes');
  assert.equal(routeUrl('waze', addr), 'https://waze.com/ul?q=12%20rue%20de%20la%20Paix%2054000%20Nancy&navigate=yes');
  assert.match(routeUrl('google', addr), /^https:\/\/www\.google\.com\/maps\/dir\/\?api=1&destination=12%20rue/);
  assert.equal(routeUrl('apple', ll), 'https://maps.apple.com/?daddr=48.69,6.18');
  assert.equal(routeUrl('other', addr), 'geo:0,0?q=12%20rue%20de%20la%20Paix%2054000%20Nancy');
});
