import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import * as shared from '@itineo/shared';
import { EN, EN_PATTERNS } from '../src/i18n.en';
import { kindLabel, LANGS, langReady, MSG_PATTERNS, setLang, setLangLoader, setSector, t, tl, tp, tServer } from '../src/i18n';
import { techText } from '../src/tech/i18n';

const root = join(import.meta.dirname, '..', '..');

function files(dir: string, out: string[] = []): string[] {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) files(p, out);
    else if (/\.tsx?$/.test(name)) out.push(p);
  }
  return out;
}

/** Chaînes entre '…' ou "…" (sans gabarit `…`) */
const STR = String.raw`(?:'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)")`;
const unescape = (m: RegExpMatchArray, i: number) => (m[i] ?? m[i + 1]).replace(/\\(.)/g, '$1');

function used(src: string): string[] {
  const keys: string[] = [];
  // t(…) et tr(…) (alias de t là où « t » désigne les textes de l'appli terrain)
  for (const m of src.matchAll(new RegExp(String.raw`\btr?\(\s*${STR}`, 'g'))) keys.push(unescape(m, 1));
  for (const m of src.matchAll(new RegExp(String.raw`\btp\([^,]+,\s*${STR}\s*,\s*${STR}`, 'g'))) keys.push(unescape(m, 1), unescape(m, 3));
  return keys;
}

test('chaque texte du bureau a sa traduction anglaise', () => {
  const missing: string[] = [];
  for (const f of files(join(root, 'web', 'src'))) {
    if (/i18n(\.en)?\.ts$/.test(f)) continue;
    for (const k of used(readFileSync(f, 'utf8'))) if (!(k in EN)) missing.push(`${f.split(/[\\/]src[\\/]/)[1]} : ${k}`);
  }
  assert.deepEqual(missing, []);
});

test('chaque libellé partagé (statuts, types…) a sa traduction', () => {
  const missing: string[] = [];
  for (const [name, value] of Object.entries(shared)) {
    // Les noms de langues s'affichent dans leur propre langue (« Français », « English »)
    if (!/_LABELS$/.test(name) || name === 'UI_LOCALE_LABELS') continue;
    for (const label of Object.values(value as Record<string, string>)) if (label !== '—' && !(label in EN)) missing.push(`${name} : ${label}`);
  }
  for (const f of shared.CONTRACT_FREQUENCIES) if (!(f.label in EN)) missing.push(f.label);
  for (const s of shared.PREFILL_SOURCES) if (!(s.label in EN)) missing.push(s.label);
  assert.deepEqual(missing, []);
});

test("chaque message d'erreur du serveur a sa traduction", () => {
  const missing: string[] = [];
  const call = new RegExp(String.raw`(?:badRequest|conflict|forbidden|notFound|HttpError\(\d+,)\(?\s*${STR}|message:\s*${STR}`, 'g');
  for (const f of files(join(root, 'api', 'src'))) {
    for (const m of readFileSync(f, 'utf8').matchAll(call)) {
      const raw = m[1] ?? m[2] ?? m[3] ?? m[4];
      const msg = raw.replace(/\\(.)/g, '$1');
      const isNotFound = m[0].startsWith('notFound');
      const ok = isNotFound ? msg in EN : msg in EN || EN_PATTERNS.some(([re]) => re.test(msg));
      if (!ok) missing.push(`${f.split(/[\\/]src[\\/]/)[1]} : ${msg}`);
    }
  }
  assert.deepEqual(missing, []);
});

test('traduction : variables, pluriels, messages du serveur', () => {
  setLang('en-GB');
  assert.equal(t('Clients et sites'), 'Customers and sites');
  assert.equal(t('Texte inconnu'), 'Texte inconnu');
  assert.equal(tp(1, '{n} dépassée', '{n} dépassées'), '1 overdue');
  assert.equal(tServer('Client introuvable'), 'Customer not found');
  assert.equal(tServer('Trop de tentatives. Réessayez dans 3 minutes.'), 'Too many attempts. Try again in 3 minutes.');
  setLang('fr-FR');
  assert.equal(tp(0, '{n} dépassée', '{n} dépassées'), '0 dépassée');
  assert.equal(tp(2, '{n} dépassée', '{n} dépassées'), '2 dépassées');
  assert.equal(tServer('Client introuvable'), 'Client introuvable');
});

// ─── Autres langues (src/locales/xx.json) ───────────────────────────────

const locales = join(root, 'web', 'src', 'locales');
const readLocale = (lang: string): Record<string, string> => JSON.parse(readFileSync(join(locales, `${lang}.json`), 'utf8'));
const vars = (s: string) => [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');
const OTHER = LANGS.filter((l) => l !== 'fr' && l !== 'en');

test('chaque langue a tous les textes, avec les mêmes variables', () => {
  const keys = [...Object.keys(EN), ...MSG_PATTERNS.map(([, m]) => m), "l'article"];
  const problems: string[] = [];
  for (const lang of OTHER) {
    const dict = readLocale(lang);
    for (const k of keys) {
      if (!dict[k]?.trim()) problems.push(`${lang} : manque « ${k} »`);
      else if (vars(dict[k]) !== vars(k)) problems.push(`${lang} : variables de « ${k} »`);
    }
  }
  assert.deepEqual(problems.slice(0, 20), []);
});

test("chaque langue a les textes de l'appli terrain", () => {
  const fr = techText('fr-FR').t;
  for (const lang of OTHER) {
    const { t: tt, outcomes, lang: got } = techText(`${lang}-XX`);
    assert.equal(got, lang);
    assert.notEqual(tt, fr, lang);
    for (const k of Object.keys(fr)) assert.ok(k in tt, `${lang} : ${k}`);
    assert.equal(Object.keys(outcomes).length, 5, lang);
    assert.match(tt.interventions(3), /3/);
  }
});

test("le vocabulaire de l'édition remplace « intervention » et « technicien »", () => {
  setLang('fr-FR');
  setSector('SECURITY');
  assert.equal(t('Nouvelle intervention'), 'Nouvelle mission');
  assert.equal(tl(shared.ROLE_LABELS, 'TECHNICIAN'), 'Agent');
  assert.equal(kindLabel('MAINTENANCE'), 'Ronde');
  setLang('en-GB');
  assert.equal(t('Nouvelle intervention'), 'New assignment');
  assert.equal(kindLabel('SAV'), 'Alarm response');
  setSector('TECH');
  assert.equal(t('Nouvelle intervention'), 'New job');
  assert.equal(kindLabel('SAV'), 'Service / Repair');
  setLang('fr-FR');
});

test('une autre langue se charge et traduit les messages du serveur', async () => {
  setLangLoader(async (lang) => readLocale(lang));
  setLang('es-ES');
  await langReady();
  assert.equal(t('Clients et sites'), 'Clientes y sitios');
  assert.equal(tServer('Client introuvable'), 'Cliente no encontrado');
  assert.equal(tServer('Le code « ABC » existe déjà'), 'El código «ABC» ya existe');
  setLang('ja-JP');
  await langReady();
  assert.equal(tp(2, '{n} dépassée', '{n} dépassées'), '期限超過 2 件');
  setLang('xx-YY');
  assert.equal(t('Clients et sites'), 'Clients et sites');
});