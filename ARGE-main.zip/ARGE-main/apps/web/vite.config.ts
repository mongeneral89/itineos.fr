import { readFileSync } from 'node:fs';
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
// Chemin relatif : le fichier de configuration est assemblé par Vite, qui l'inclut directement
import { EDITION_THEMES, isSector, productName, type Sector } from '../../packages/shared/src/index';

/**
 * Édition construite : chaque secteur est un logiciel à part (nom, couleurs, icône, appli installable).
 *   EDITION=SECURITY npm run build -w @itineo/web   → Itinéos Vigie
 * Sans EDITION : l'édition des techniciens.
 */
const raw = process.env.EDITION ?? 'TECH';
if (!isSector(raw)) throw new Error(`EDITION inconnue : ${raw}`);
const edition: Sector = raw;
process.env.VITE_EDITION = edition;

const theme = EDITION_THEMES[edition];
const name = productName(edition);

/** Nom, couleurs, icône et fichier d'installation propres à l'édition */
function editionFiles(): Plugin {
  const icon = () => readFileSync(new URL('./brand/icon.svg', import.meta.url), 'utf8')
    .replaceAll('#14181F', theme.ink)
    .replaceAll('#F97316', theme.accent);
  const manifest = () => JSON.stringify({
    name,
    short_name: name,
    description: theme.description,
    start_url: '/tech',
    display: 'standalone',
    background_color: '#F4F2EE',
    theme_color: theme.ink,
    icons: [{ src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' }],
  }, null, 2);
  return {
    name: 'itineo-edition',
    transformIndexHtml: (html) => html
      .replace('<title>Itinéos</title>', `<title>${name}</title>`)
      .replace('content="#14181F"', `content="${theme.ink}"`),
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.url === '/manifest.webmanifest') {
          res.setHeader('Content-Type', 'application/manifest+json');
          res.end(manifest());
        } else if (req.url === '/icon.svg') {
          res.setHeader('Content-Type', 'image/svg+xml');
          res.end(icon());
        } else next();
      });
    },
    generateBundle() {
      this.emitFile({ type: 'asset', fileName: 'manifest.webmanifest', source: manifest() });
      this.emitFile({ type: 'asset', fileName: 'icon.svg', source: icon() });
    },
  };
}

// En développement, les appels /api sont redirigés vers l'API (port 3000 ; API_URL pour lancer plusieurs éditions côte à côte)
export default defineConfig({
  plugins: [react(), editionFiles()],
  server: {
    port: Number(process.env.WEB_PORT ?? 5173),
    host: true, // accessible depuis une tablette sur le même réseau
    proxy: { '/api': process.env.API_URL ?? 'http://localhost:3000' },
  },
});
