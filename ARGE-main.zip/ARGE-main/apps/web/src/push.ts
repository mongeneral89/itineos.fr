/** Notifications sur cet appareil (Web Push) : abonnement et désabonnement */
import { api } from './api';
import { isNativeApp } from './native';

// Appli Android : la WebView ne reçoit pas le Web Push, les notifications passent par Firebase (tech/push-native.ts)
// (seulement si l'APK a été construite avec le projet Firebase : VITE_PUSH, voir lanceurs/construire-apk.ps1)
export const pushSupported = () => (isNativeApp() ? import.meta.env.VITE_PUSH === '1' : ('serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window));
const native = () => import('./tech/push-native');

/** iPhone / iPad : les notifications ne marchent que si Itinéos est ajouté à l'écran d'accueil */
export const needsHomeScreen = () =>
  /iPhone|iPad|iPod/.test(navigator.userAgent) && !(window.matchMedia('(display-mode: standalone)').matches || (navigator as { standalone?: boolean }).standalone);

function keyBytes(base64: string): Uint8Array {
  const pad = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

async function registration(): Promise<ServiceWorkerRegistration> {
  return (await navigator.serviceWorker.getRegistration()) ?? navigator.serviceWorker.register('/sw.js');
}

export async function currentSubscription(): Promise<PushSubscription | null> {
  if (!pushSupported()) return null;
  const reg = await navigator.serviceWorker.getRegistration();
  return reg ? reg.pushManager.getSubscription() : null;
}

/** Cet appareil reçoit-il les notifications ? */
export async function isPushActive(): Promise<boolean> {
  if (isNativeApp()) return (await native()).nativePushActive();
  return !!(await currentSubscription()) && Notification.permission === 'granted';
}

/** Demande l'autorisation puis abonne cet appareil ; renvoie false si la personne refuse */
export async function enablePush(publicKey: string): Promise<boolean> {
  if (isNativeApp()) return (await native()).enableNativePush();
  if (!pushSupported()) return false;
  if ((await Notification.requestPermission()) !== 'granted') return false;
  const reg = await registration();
  await navigator.serviceWorker.ready;
  const sub = (await reg.pushManager.getSubscription())
    ?? await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(publicKey) as BufferSource });
  const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
  await api('/notifications/subscribe', { method: 'POST', body: { endpoint: json.endpoint, keys: json.keys } });
  return true;
}

export async function disablePush(): Promise<void> {
  if (isNativeApp()) return (await native()).disableNativePush();
  const sub = await currentSubscription();
  if (!sub) return;
  await api('/notifications/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } }).catch(() => undefined);
  await sub.unsubscribe();
}
