/** Mise en forme des dates, dans le fuseau horaire de la société et la langue du compte */
import { uiLocale } from './i18n';

export function fmtTime(iso: string | null | undefined, tz?: string, locale = uiLocale()): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(locale, { timeZone: tz, hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
}

export function fmtDate(iso: string | null | undefined, tz?: string, locale = uiLocale()): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(locale, { timeZone: tz, day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(iso));
}

export function fmtDateTime(iso: string | null | undefined, tz?: string, locale = uiLocale()): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(locale, { timeZone: tz, dateStyle: 'short', timeStyle: 'short' }).format(new Date(iso));
}

export function fmtLongDay(d: Date, locale = uiLocale()): string {
  return new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long' }).format(d);
}

/** Bornes d'une journée locale (heure de l'appareil) */
export function dayBounds(d: Date): { from: string; to: string } {
  const start = new Date(d);
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  return { from: start.toISOString(), to: end.toISOString() };
}

/** "2026-10-14" pour un champ <input type="date"> */
export function toDateInput(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** "2026-10-14T09:30" pour un champ <input type="datetime-local"> */
export function toDateTimeInput(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${toDateInput(d)}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

/** Date AAAA-MM-JJ (sans heure) affichée JJ/MM/AAAA */
export function fmtDay(isoDay: string | null | undefined, locale = uiLocale()): string {
  if (!isoDay) return '—';
  return new Intl.DateTimeFormat(locale, { timeZone: 'UTC', day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(`${isoDay}T00:00:00Z`));
}

/** Montant saisi (« 1 250,50 », « 1250.5 ») → centimes ; null si illisible */
export function parseMoneyInput(s: string): number | null {
  const clean = s.replace(/[\s €£]/g, '').replace(',', '.');
  if (!/^-?\d*(\.\d{0,2})?$/.test(clean) || clean === '' || clean === '-' || clean === '.') return null;
  return Math.round(Number(clean) * 100);
}

/** Centimes → texte modifiable dans un champ (« 1250,50 ») */
export function moneyInput(cents: number): string {
  return (cents / 100).toFixed(2).replace('.', ',');
}

export function fullName(first?: string | null, last?: string | null): string {
  return [first, last].filter(Boolean).join(' ') || '—';
}
