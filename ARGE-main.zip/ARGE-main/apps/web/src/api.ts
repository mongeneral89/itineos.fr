/** Appels à l'API avec le jeton de connexion */
import { t, tServer } from './i18n';
import { apiUrl, fileNameOf, isNativeApp, openNativeFile } from './native';

const TOKEN_KEY = 'itineo.token';

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* stockage indisponible : la session ne survivra pas au rechargement */
  }
}

export class ApiError extends Error {
  constructor(public status: number, message: string, public details?: unknown, public issues?: { path: string; message: string }[]) {
    super(message);
  }
}

/** Déclenché quand la session expire : l'appli renvoie vers la connexion */
export const SESSION_EXPIRED = 'itineo:session-expired';

export async function api<T>(path: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';

  let res: Response;
  try {
    res = await fetch(apiUrl(path), {
      method: options.method ?? 'GET',
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    throw new ApiError(0, t('Pas de connexion au serveur. Vérifiez le réseau.'));
  }

  if (res.status === 401 && token) {
    setToken(null);
    window.dispatchEvent(new Event(SESSION_EXPIRED));
  }
  if (!res.ok) {
    let payload: { error?: string; details?: unknown; issues?: { path: string; message: string }[] } = {};
    try {
      payload = await res.json();
    } catch {
      /* réponse sans JSON */
    }
    const issues = payload.issues;
    const message = issues?.length ? issues.map((i) => tServer(i.message)).join(' · ') : payload.error ? tServer(payload.error) : t('Erreur {n}', { n: res.status });
    throw new ApiError(res.status, message, payload.details, issues);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

/** Ouvre le PDF d'une fiche dans un nouvel onglet (le téléchargement a besoin du jeton) */
export function openReportPdf(interventionId: string) {
  return openPdf(`/interventions/${interventionId}/report/pdf`);
}

/** Ouvre un PDF de l'API (devis, facture…) dans un nouvel onglet */
export async function openPdf(path: string) {
  const win = isNativeApp() ? null : window.open('', '_blank');
  const res = await fetch(apiUrl(path), {
    headers: { Authorization: `Bearer ${getToken() ?? ''}` },
  });
  if (!res.ok) {
    win?.close();
    throw new ApiError(res.status, t('PDF indisponible'));
  }
  if (isNativeApp()) return openNativeFile(await res.blob(), fileNameOf(res, 'document.pdf'));
  const url = URL.createObjectURL(await res.blob());
  if (win) win.location.href = url;
  else window.location.href = url;
}

/** Télécharge un fichier de l'API (export CSV…) sous le nom donné par le serveur */
export async function downloadFile(path: string, fallbackName: string) {
  const res = await fetch(apiUrl(path), { headers: { Authorization: `Bearer ${getToken() ?? ''}` } });
  if (!res.ok) {
    let msg = t('Erreur {n}', { n: res.status });
    try {
      const err = ((await res.json()) as { error?: string }).error;
      if (err) msg = tServer(err);
    } catch {
      /* réponse sans JSON */
    }
    throw new ApiError(res.status, msg);
  }
  const name = fileNameOf(res, fallbackName);
  if (isNativeApp()) return openNativeFile(await res.blob(), name);
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Construit une chaîne de requête en ignorant les valeurs vides */
export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : '';
}
