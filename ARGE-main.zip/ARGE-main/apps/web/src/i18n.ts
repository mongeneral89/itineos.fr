/**
 * Traduction du bureau et de l'espace client.
 *
 * Le texte français sert de clé : t('Clients et sites') affiche « Clients and sites » pour un compte en anglais.
 * Un texte absent du dictionnaire reste en français (jamais d'écran vide).
 * Variables : t('Facture {num}', { num }) ; pluriel : tp(n, '{n} visite', '{n} visites') ;
 * mot à double sens : t('Modèle|matériel') (la partie après « | » ne s'affiche pas).
 *
 * L'anglais est inclus dans l'appli ; les autres langues (src/locales/xx.json) sont chargées
 * à la demande, puis l'écran est redessiné (voir useLangVersion).
 * Le test test/i18n.test.ts vérifie que chaque texte utilisé a sa traduction, dans chaque langue.
 */
import {
  applySectorWords, BRAND, KIND_LABELS, productName, SECTOR_KINDS, SECTOR_VOCABULARY, type InterventionKind, type Sector,
} from '@itineo/shared';
import { EN, EN_PATTERNS } from './i18n.en';

export const LANGS = ['fr', 'en', 'es', 'de', 'it', 'pt', 'nl', 'pl', 'ro', 'tr', 'ru', 'ar', 'hi', 'zh', 'ja', 'ko'] as const;
export type Lang = (typeof LANGS)[number];

/** Format des dates et nombres de chaque langue */
const LOCALE_TAGS: Record<Lang, string> = {
  fr: 'fr-FR', en: 'en-GB', es: 'es-ES', de: 'de-DE', it: 'it-IT', pt: 'pt-PT', nl: 'nl-NL', pl: 'pl-PL', ro: 'ro-RO',
  tr: 'tr-TR', ru: 'ru-RU', ar: 'ar-MA', hi: 'hi-IN', zh: 'zh-CN', ja: 'ja-JP', ko: 'ko-KR',
};
const RTL: Lang[] = ['ar'];

/** "es-ES" → "es" ; langue inconnue → français */
export function langFromLocale(locale: string | null | undefined): Lang {
  const code = (locale ?? '').slice(0, 2).toLowerCase();
  return (LANGS as readonly string[]).includes(code) ? (code as Lang) : 'fr';
}

// Avant la connexion : la langue du navigateur
let lang: Lang = typeof navigator !== 'undefined' ? langFromLocale(navigator.language) : 'fr';
let dict: Record<string, string> | null = lang === 'en' ? EN : null;
const loaded: Partial<Record<Lang, Record<string, string>>> = { en: EN };

// ─── Chargement des langues et redessin de l'écran ───────────────────────

type Loader = (lang: Lang) => Promise<Record<string, string>>;
let loader: Loader | null = null;
let version = 0;
const listeners = new Set<() => void>();
const notify = () => {
  version++;
  for (const fn of listeners) fn();
};

/** Indique comment lire le dictionnaire d'une langue (main.tsx : fichiers de src/locales ; tests : disque) */
export function setLangLoader(fn: Loader): void {
  loader = fn;
  if (!dict && lang !== 'fr') void ensure(lang);
}

async function ensure(l: Lang): Promise<void> {
  if (!loader || loaded[l]) return;
  try {
    loaded[l] = await loader(l);
  } catch (err) {
    console.warn(`[i18n] langue ${l} indisponible`, err);
    return;
  }
  if (lang === l) {
    dict = loaded[l]!;
    notify();
  }
}

/** Pour redessiner l'écran quand un dictionnaire arrive */
export function subscribeLang(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
export function langVersion(): number {
  return version;
}

/** Appelé à la connexion : la langue est celle du compte (ex. "es-ES" → espagnol) */
export function setLang(locale: string | null | undefined): void {
  const next = langFromLocale(locale);
  if (typeof document !== 'undefined') {
    document.documentElement.lang = next;
    document.documentElement.dir = RTL.includes(next) ? 'rtl' : 'ltr';
  }
  if (next === lang && (dict || next === 'fr')) return;
  lang = next;
  dict = next === 'fr' ? null : loaded[next] ?? null;
  notify();
  if (!dict && next !== 'fr') void ensure(next);
}

/** Attendre le dictionnaire de la langue en cours (tests) */
export async function langReady(): Promise<void> {
  if (lang !== 'fr') await ensure(lang);
}

export function getLang(): Lang {
  return lang;
}

/** Format des dates et nombres de l'interface */
export function uiLocale(): string {
  return LOCALE_TAGS[lang];
}

function fill(s: string, vars?: Record<string, string | number>): string {
  if (!vars) return s;
  return s.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? String(vars[k]) : m));
}

// ─── Vocabulaire du métier (secteur de la société) ───────────────────────
// « Intervention » devient « mission », « technicien » devient « agent »… en français et en anglais.
// Dans les autres langues, le vocabulaire standard reste affiché.

let sector: Sector = 'TECH';
const wordCache = new Map<string, string>();

/** Appelé quand la société choisie change */
export function setSector(next: Sector | null | undefined): void {
  const s = next ?? 'TECH';
  if (s === sector) return;
  sector = s;
  wordCache.clear();
  notify();
}

export function getSector(): Sector {
  return sector;
}

function sectorWords(raw: string): string {
  const vocab = SECTOR_VOCABULARY[sector];
  if (!vocab) return raw;
  // Nom de l'édition : « ajoutez Itinéos Vigie à l'écran d'accueil »
  const text = raw.includes(BRAND) ? raw.replaceAll(BRAND, productName(sector)) : raw;
  if (lang !== 'fr' && lang !== 'en') return text;
  if (!/nterven|echnic|\bjobs?\b/i.test(text)) return text;
  const key = `${lang}|${text}`;
  let out = wordCache.get(key);
  if (out === undefined) {
    out = applySectorWords(text, vocab[lang], lang);
    wordCache.set(key, out);
  }
  return out;
}

/** Type d'intervention dans le vocabulaire du métier (« Ronde », « État des lieux d'entrée »…) */
export function kindLabel(kind: InterventionKind): string {
  const labels = SECTOR_KINDS[sector];
  if (labels && (lang === 'fr' || lang === 'en')) return labels[lang][kind];
  return t(KIND_LABELS[kind]);
}

/** Un même mot français peut avoir deux sens : t('Modèle|matériel') affiche « Modèle » en français, « Model » en anglais */
export function t(fr: string, vars?: Record<string, string | number>): string {
  return fill(sectorWords(dict?.[fr] ?? fr.split('|')[0]), vars);
}

/** Pluriel : en français 0 et 1 sont au singulier ; ailleurs, la règle de la langue (en chinois ou japonais, une seule forme) */
export function tp(n: number, one: string, many: string, vars?: Record<string, string | number>): string {
  const plural = lang === 'fr' ? n > 1 : new Intl.PluralRules(LOCALE_TAGS[lang]).select(n) !== 'one';
  return t(plural ? many : one, { n, ...vars });
}

/**
 * Messages du serveur contenant une valeur variable, pour les langues autres que le français et l'anglais :
 * le modèle français (avec {0}, {1}…) sert de clé dans le dictionnaire de la langue.
 */
export const MSG_PATTERNS: [RegExp, string][] = [
  [/^(.+) introuvable$/, '{0} introuvable'],
  [/^Trop de tentatives\. Réessayez dans (\d+) minutes?\.$/, 'Trop de tentatives. Réessayez dans {0} minutes.'],
  [/^Stock insuffisant pour (.+) : (.+) disponible\(s\), (.+) demandé\(s\)$/, 'Stock insuffisant pour {0} : {1} disponible(s), {2} demandé(s)'],
  [/^Le code « (.+) » existe déjà$/, 'Le code « {0} » existe déjà'],
  [/^La référence « (.+) » existe déjà$/, 'La référence « {0} » existe déjà'],
  [/^Le véhicule (.+) existe déjà$/, 'Le véhicule {0} existe déjà'],
  [/^Vous ne pouvez pas attribuer le rôle (.+) sur ce périmètre$/, 'Vous ne pouvez pas attribuer le rôle {0} sur ce périmètre'],
  [/^Ligne sans prix : (.+)$/, 'Ligne sans prix : {0}'],
  [/^Le compteur ne peut pas reculer : dernier relevé (.+) km$/, 'Le compteur ne peut pas reculer : dernier relevé {0} km'],
  [/^Un devis « (.+) » ne peut pas passer à « (.+) »$/, 'Un devis « {0} » ne peut pas passer à « {1} »'],
  [/^(\d+) photos au maximum par fiche$/, '{0} photos au maximum par fiche'],
];

/**
 * Message d'erreur du serveur (rédigé en français) : texte fixe du dictionnaire,
 * ou message avec une valeur variable reconnu par les modèles.
 */
export function tServer(msg: string): string {
  if (lang === 'fr' || !dict) return msg;
  if (dict[msg]) return dict[msg];
  if (lang === 'en') {
    for (const [re, en] of EN_PATTERNS) {
      const m = re.exec(msg);
      if (m) return en(m.slice(1), t);
    }
    return msg;
  }
  for (const [re, model] of MSG_PATTERNS) {
    const m = re.exec(msg);
    if (m && dict[model]) return dict[model].replace(/\{(\d)\}/g, (_, i: string) => t(m[Number(i) + 1]));
  }
  return msg;
}

/** Libellé d'une liste partagée (statuts, types…) : LABELS[clé] traduit */
export function tl<K extends string>(labels: Record<K, string>, key: K): string {
  return t(labels[key]);
}
