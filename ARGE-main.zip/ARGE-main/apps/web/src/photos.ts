/** Photos de la fiche : réduction sur l'appareil et affichage (copie locale d'abord) */
import { useEffect, useState } from 'react';
import { photoBlob } from './offline/field';
import type { ReportPhoto } from './types';

/** Côté le plus long après réduction : assez pour lire une plaque signalétique, léger en 4G */
const MAX_SIDE = 1600;
const QUALITY = 0.8;

/**
 * Réduit une photo de l'appareil en JPEG (≈ 200 à 400 Ko) et la renvoie en data URL.
 * L'orientation du téléphone (EXIF) est appliquée.
 */
export async function compressPhoto(file: File): Promise<string> {
  const source = await loadImage(file);
  const scale = Math.min(1, MAX_SIDE / Math.max(source.width, source.height));
  const w = Math.round(source.width * scale);
  const h = Math.round(source.height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Impossible de traiter la photo sur cet appareil');
  ctx.drawImage(source.image, 0, 0, w, h);
  source.close();
  return canvas.toDataURL('image/jpeg', QUALITY);
}

async function loadImage(file: File): Promise<{ image: CanvasImageSource; width: number; height: number; close: () => void }> {
  if ('createImageBitmap' in window) {
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
      return { image: bmp, width: bmp.width, height: bmp.height, close: () => bmp.close() };
    } catch {
      /* format non pris en charge par createImageBitmap : on passe par <img> */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    return { image: img, width: img.naturalWidth, height: img.naturalHeight, close: () => undefined };
  } catch {
    throw new Error('Cette image ne peut pas être lue');
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Adresse affichable d'une photo : image locale (pas encore envoyée), copie de l'appareil, ou serveur */
export function usePhotoUrl(interventionId: string, photo: ReportPhoto): string | null {
  const [url, setUrl] = useState<string | null>(photo.localImage ?? null);
  useEffect(() => {
    if (photo.localImage) {
      setUrl(photo.localImage);
      return;
    }
    let objectUrl: string | null = null;
    let cancelled = false;
    void photoBlob(interventionId, photo.id).then((blob) => {
      if (!blob || cancelled) return;
      objectUrl = URL.createObjectURL(blob);
      setUrl(objectUrl);
    });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [interventionId, photo.id, photo.localImage]);
  return url;
}
