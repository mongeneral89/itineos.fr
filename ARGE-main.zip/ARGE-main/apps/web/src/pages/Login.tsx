import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../auth';
import { t } from '../i18n';
import { PRODUCT_NAME } from '../edition';
import { CLIENT } from '../client';
import { checkServer, getServer, isNativeApp, normalizeServer, setServer } from '../native';

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'forgot' | 'sent'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // Appli Android : adresse du serveur (le PC pour les essais, puis la version en ligne)
  const native = isNativeApp();
  const [server, setServerInput] = useState(getServer);
  // Appli d'un client (A.R.G.E.) : son serveur est déjà réglé, le champ reste caché sous « Autre serveur »
  const builtIn = import.meta.env.VITE_DEFAULT_SERVER ?? '';
  const [showServer, setShowServer] = useState(() => !builtIn || normalizeServer(getServer()) !== normalizeServer(builtIn));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (native) {
        if (!(await checkServer(server))) throw new Error(t('Serveur injoignable : vérifiez l’adresse et le réseau.'));
        setServer(server);
        setServerInput(normalizeServer(server));
      }
      if (mode === 'forgot') {
        await api('/auth/forgot', { method: 'POST', body: { email } });
        setMode('sent');
      } else {
        await login(email, password, remember);
        // Chacun repart de son propre accueil, pas de la page laissée par le compte précédent
        navigate('/', { replace: true });
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const switchTo = (next: 'login' | 'forgot') => {
    setMode(next);
    setError(null);
  };

  if (mode === 'sent') {
    return (
      <div className="login">
        <div className="card">
          <h1 className="login-title"><img src="/icon.svg" alt="" />{PRODUCT_NAME}</h1>
          <p className="success" role="status">{t('Si un compte existe pour {email}, un e-mail vient de partir avec un lien pour choisir un nouveau mot de passe.', { email })}</p>
          <p className="muted small">{t('Le lien est valable 1 heure. Pensez à regarder dans les indésirables.')}</p>
          <button type="button" className="secondary" onClick={() => switchTo('login')}>{t('Retour à la connexion')}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        {CLIENT ? <img className="login-logo" src={CLIENT.logo} alt={CLIENT.name} /> : <h1 className="login-title"><img src="/icon.svg" alt="" />{PRODUCT_NAME}</h1>}
        <p className="muted">
          {mode === 'forgot'
            ? t('Indiquez votre e-mail : vous recevrez un lien pour choisir un nouveau mot de passe.')
            : t('Connectez-vous avec votre compte professionnel.')}
        </p>
        {native && !showServer && (
          <button type="button" className="ghost small login-other-server" onClick={() => setShowServer(true)}>{t('Autre serveur')}</button>
        )}
        {native && showServer && (
          <div className="field">
            <label htmlFor="server">{t('Adresse du serveur')}</label>
            <input id="server" type="text" inputMode="url" autoCapitalize="off" autoCorrect="off" spellCheck={false}
              placeholder="itineo.exemple.fr" value={server} onChange={(e) => setServerInput(e.target.value)} required />
            <p className="muted small">{t('Pour les essais : l’adresse du PC sur le Wi-Fi, par exemple 192.168.1.20:3000.')}</p>
          </div>
        )}
        <div className="field">
          <label htmlFor="email">{t('E-mail')}</label>
          <input id="email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        {mode === 'login' && (
          <div className="field">
            <label htmlFor="password">{t('Mot de passe')}</label>
            <input id="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
        )}
        {mode === 'login' && (
          <label className="check">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            {t('Rester connecté sur cet appareil')}
          </label>
        )}
        {error && <p className="error" role="alert">{error}</p>}
        <button type="submit" className="big" disabled={busy}>
          {mode === 'forgot'
            ? (busy ? t('Envoi…') : t('Recevoir le lien'))
            : (busy ? t('Connexion…') : t('Se connecter'))}
        </button>
        <button type="button" className="ghost" onClick={() => switchTo(mode === 'login' ? 'forgot' : 'login')}>
          {mode === 'login' ? t('Mot de passe oublié ?') : t('Retour à la connexion')}
        </button>
      </form>
    </div>
  );
}
