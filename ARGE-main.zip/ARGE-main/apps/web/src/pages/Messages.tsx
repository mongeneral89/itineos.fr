/**
 * Messagerie interne : liste des conversations à gauche, conversation ouverte à droite
 * (sur téléphone, l'une ou l'autre). Les nouveaux messages arrivent en relisant régulièrement le serveur.
 */
import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, downloadFile, openPdf, qs } from '../api';
import { useAuth } from '../auth';
import { fmtDateTime, fmtTime } from '../format';
import { t, tp, uiLocale } from '../i18n';
import { conversationTitle, systemText, type Attachment, type Conversation, type Message, type Person } from '../messaging';
import { FILE_ACCEPT, fmtSize, isImage, opensInBrowser, pickFile, useApiBlobUrl, type PickedFile } from '../files';
import { useBackHandler } from '../tech/BackButton';
import { isNativeApp } from '../native';

const LIST_EVERY = 10_000;
const THREAD_EVERY = 4_000;

const sameDay = (a: Date, b: Date) => a.toDateString() === b.toDateString();
function when(iso: string): string {
  return sameDay(new Date(iso), new Date()) ? fmtTime(iso) : fmtDateTime(iso);
}
const readEvent = () => window.dispatchEvent(new Event('itineo:read'));

export function MessagesPage() {
  const { me } = useAuth();
  const meId = me?.user.id ?? '';
  const [params, setParams] = useSearchParams();
  const [list, setList] = useState<Conversation[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const [creating, setCreating] = useState(false);
  // Appli Android : le retour referme « Nouvelle conversation »
  useBackHandler(creating, () => setCreating(false));
  const openId = params.get('c');

  const loadList = useCallback(async () => {
    try {
      setList(await api<Conversation[]>('/conversations'));
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    }
  }, []);

  useEffect(() => {
    void loadList();
    const timer = window.setInterval(() => document.visibilityState !== 'hidden' && void loadList(), LIST_EVERY);
    return () => window.clearInterval(timer);
  }, [loadList]);

  const open = useCallback((id: string | null) => {
    setCreating(false);
    setParams(id ? { c: id } : {}, { replace: false });
  }, [setParams]);

  // Lien « Écrire » depuis l'annuaire : /messages?with=<personne>
  const withId = params.get('with');
  useEffect(() => {
    if (!withId) return;
    void api<Conversation>('/conversations', { method: 'POST', body: { userIds: [withId] } })
      .then((c) => {
        void loadList();
        open(c.id);
      })
      .catch((e) => setError((e as Error).message));
  }, [withId, loadList, open]);

  const current = list?.find((c) => c.id === openId) ?? null;
  const shown = useMemo(() => {
    const q = filter.trim().toLowerCase();
    return (list ?? []).filter((c) => !q || conversationTitle(c, meId).toLowerCase().includes(q)
      || c.members.some((m) => `${m.firstName} ${m.lastName}`.toLowerCase().includes(q)));
  }, [list, filter, meId]);

  return (
    <div className={`msg-shell${openId || creating ? ' msg-open' : ''}`}>
      <section className="card msg-list" aria-label={t('Conversations')}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h1 style={{ fontSize: 22 }}>{t('Messagerie')}</h1>
          <button type="button" className="accent" onClick={() => { setParams({}); setCreating(true); }}>{t('Nouvelle conversation')}</button>
        </div>
        <input type="search" placeholder={t('Rechercher une conversation')} aria-label={t('Rechercher une conversation')} value={filter} onChange={(e) => setFilter(e.target.value)} />
        {error && <p className="error small">{error}</p>}
        {!list && !error && <p className="muted">{t('Chargement…')}</p>}
        {list && !list.length && <p className="muted small">{t('Aucune conversation pour le moment. Écrivez à un collègue avec « Nouvelle conversation ».')}</p>}
        <ul className="msg-items">
          {shown.map((c) => {
            const last = c.lastMessage;
            const preview = !last ? '' : last.deleted ? t('Message retiré') : last.senderId ? last.body || (last.attachmentName ? `📎 ${last.attachmentName}` : '') : systemText(last.body);
            const mine = last?.senderId === meId;
            return (
              <li key={c.id}>
                <button type="button" className={`msg-item${c.id === openId ? ' on' : ''}`} onClick={() => open(c.id)}>
                  <span className="msg-avatar" aria-hidden="true">{c.kind === 'GROUP' ? '#' : initials(c, meId)}</span>
                  <span className="grow" style={{ minWidth: 0 }}>
                    <span className="row" style={{ gap: 6, justifyContent: 'space-between', flexWrap: 'nowrap' }}>
                      <strong className="msg-ellipsis">{conversationTitle(c, meId)}</strong>
                      {last && <span className="small muted" style={{ flexShrink: 0 }}>{when(last.createdAt)}</span>}
                    </span>
                    <span className="row" style={{ gap: 6, justifyContent: 'space-between', flexWrap: 'nowrap' }}>
                      <span className="small muted msg-ellipsis">{mine ? `${t('Vous :')} ` : ''}{preview}</span>
                      {c.unread > 0 && <span className="badge accent-badge" aria-label={tp(c.unread, '{n} message non lu', '{n} messages non lus')}>{c.unread}</span>}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="card msg-thread">
        {creating ? (
          <NewConversation onCancel={() => setCreating(false)} onCreated={(c) => { void loadList(); open(c.id); }} />
        ) : current ? (
          <Thread key={current.id} conv={current} meId={meId} onBack={() => open(null)} onChanged={loadList} />
        ) : openId && list ? (
          <p className="muted">{t('Cette conversation n’est plus disponible.')}</p>
        ) : (
          <div className="msg-empty muted">{t('Choisissez une conversation, ou commencez-en une nouvelle.')}</div>
        )}
      </section>
    </div>
  );
}

function initials(c: Conversation, meId: string): string {
  const other = c.members.find((m) => m.id !== meId);
  return other ? `${other.firstName.charAt(0)}${other.lastName.charAt(0)}`.toUpperCase() : '·';
}

/** Choisir une ou plusieurs personnes : à deux, ou en groupe avec un nom */
function NewConversation({ onCancel, onCreated }: { onCancel: () => void; onCreated: (c: Conversation) => void }) {
  const [people, setPeople] = useState<Person[] | null>(null);
  const [picked, setPicked] = useState<string[]>([]);
  const [q, setQ] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<Person[]>('/messages/people').then(setPeople).catch((e) => setError((e as Error).message));
  }, []);

  const shown = (people ?? []).filter((p) => {
    const s = q.trim().toLowerCase();
    return !s || `${p.firstName} ${p.lastName} ${p.roles.join(' ')} ${p.places.join(' ')}`.toLowerCase().includes(s);
  });
  const toggle = (id: string) => setPicked((x) => (x.includes(id) ? x.filter((y) => y !== id) : [...x, id]));
  const group = picked.length > 1 || !!name.trim();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!picked.length) return;
    setBusy(true);
    setError(null);
    try {
      const body = { userIds: picked, title: group ? name.trim() || undefined : undefined };
      onCreated(await api<Conversation>('/conversations', { method: 'POST', body }));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="stack" onSubmit={submit} style={{ minHeight: 0, flex: 1 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Nouvelle conversation')}</h2>
        <button type="button" className="ghost" onClick={onCancel}>{t('Annuler')}</button>
      </div>
      <p className="small muted">{t('Une personne : conversation à deux. Plusieurs personnes : conversation de groupe, que vous pouvez nommer.')}</p>
      <input type="search" placeholder={t('Rechercher : nom, rôle, agence')} aria-label={t('Rechercher : nom, rôle, agence')} value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="msg-people">
        {!people && !error && <p className="muted">{t('Chargement…')}</p>}
        {people && !shown.length && <p className="muted small">{t('Personne à ajouter.')}</p>}
        {shown.map((p) => (
          <label key={p.id} className="check msg-person">
            <input type="checkbox" checked={picked.includes(p.id)} onChange={() => toggle(p.id)} />
            <span>
              <strong>{p.firstName} {p.lastName}</strong>
              <span className="small muted"> · {[p.roles.map((r) => t(r)).join(', '), p.places.join(', ')].filter(Boolean).join(' · ')}</span>
            </span>
          </label>
        ))}
      </div>
      {group && (
        <div className="field">
          <label htmlFor="conv-name">{t('Nom du groupe (facultatif)')}</label>
          <input id="conv-name" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} placeholder={t('Ex. : Équipe dépannage Est')} />
        </div>
      )}
      {error && <p className="error small">{error}</p>}
      <div className="row">
        <button type="submit" disabled={!picked.length || busy}>
          {group ? t('Créer le groupe ({n})', { n: picked.length + 1 }) : t('Écrire')}
        </button>
      </div>
    </form>
  );
}

function Thread({ conv, meId, onBack, onChanged }: { conv: Conversation; meId: string; onBack: () => void; onChanged: () => Promise<void> | void }) {
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [hasOlder, setHasOlder] = useState(false);
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [file, setFile] = useState<PickedFile | null>(null);
  const [preparing, setPreparing] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const [panel, setPanel] = useState<'none' | 'add' | 'rename' | 'members'>('none');
  const [menu, setMenu] = useState(false);
  const [editing, setEditing] = useState<{ id: string; body: string } | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const lastSeen = useRef<string | null>(null);
  const names = useMemo(() => new Map(conv.members.map((m) => [m.id, `${m.firstName} ${m.lastName}`])), [conv.members]);

  /** Derniers messages, fusionnés avec ceux déjà chargés (plus anciens compris) */
  const refresh = useCallback(async () => {
    const latest = await api<Message[]>(`/conversations/${conv.id}/messages${qs({ limit: 50 })}`);
    setMessages((prev) => {
      if (!prev) {
        setHasOlder(latest.length === 50);
        return latest;
      }
      const byId = new Map(prev.map((m) => [m.id, m]));
      for (const m of latest) byId.set(m.id, m);
      return [...byId.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    });
  }, [conv.id]);

  useEffect(() => {
    void refresh().catch((e) => setError((e as Error).message));
    const timer = window.setInterval(() => document.visibilityState !== 'hidden' && void refresh().catch(() => undefined), THREAD_EVERY);
    return () => window.clearInterval(timer);
  }, [refresh]);

  // Nouveau dernier message : on descend en bas et on marque la conversation comme lue
  const lastId = messages?.[messages.length - 1]?.id ?? null;
  useEffect(() => {
    if (!lastId || lastId === lastSeen.current) return;
    const first = lastSeen.current === null;
    lastSeen.current = lastId;
    bottom.current?.scrollIntoView({ block: 'end', behavior: first ? 'auto' : 'smooth' });
    void api(`/conversations/${conv.id}/read`, { method: 'POST' }).then(() => {
      readEvent();
      void onChanged();
    }).catch(() => undefined);
  }, [lastId, conv.id, onChanged]);

  const older = async () => {
    if (!messages?.length) return;
    const page = await api<Message[]>(`/conversations/${conv.id}/messages${qs({ before: messages[0].createdAt, limit: 50 })}`);
    setHasOlder(page.length === 50);
    setMessages((prev) => [...page, ...(prev ?? [])]);
  };

  const send = async (e?: FormEvent) => {
    e?.preventDefault();
    const body = text.trim();
    if ((!body && !file) || sending || preparing) return;
    setSending(true);
    setError(null);
    try {
      await api(`/conversations/${conv.id}/messages`, { method: 'POST', body: { body, ...(file ? { file: { dataUrl: file.dataUrl, name: file.name } } : {}) } });
      setText('');
      setFile(null);
      await refresh();
      void onChanged();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSending(false);
    }
  };

  // Entrée envoie, Maj + Entrée passe à la ligne
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      void send();
    }
  };

  const choose = async (f: File | undefined | null) => {
    if (!f) return;
    setPreparing(true);
    setError(null);
    try {
      setFile(await pickFile(f));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setPreparing(false);
      if (fileInput.current) fileInput.current.value = '';
    }
  };

  const saveEdit = async () => {
    if (!editing?.body.trim()) return;
    try {
      await api(`/messages/${editing.id}`, { method: 'PATCH', body: { body: editing.body } });
      setEditing(null);
      await refresh();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const remove = async (id: string) => {
    if (!window.confirm(t('Retirer ce message ?'))) return;
    try {
      await api(`/messages/${id}`, { method: 'DELETE' });
      await refresh();
      void onChanged();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const leave = async () => {
    if (!window.confirm(t('Quitter cette conversation ? Vous ne recevrez plus ses messages.'))) return;
    try {
      await api(`/conversations/${conv.id}/members/me`, { method: 'DELETE' });
      await onChanged();
      onBack();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const group = conv.kind === 'GROUP';
  let prevDay = '';

  return (
    <div className="msg-conv">
      <div className="msg-head">
        <button type="button" className="ghost msg-back" onClick={onBack} aria-label={t('Retour aux conversations')}>←</button>
        <div className="grow" style={{ minWidth: 0 }}>
          <h2 className="msg-ellipsis">{conversationTitle(conv, meId)}</h2>
          {group && (
            <button type="button" className="ghost small" style={{ padding: 0, minHeight: 0 }} onClick={() => setPanel(panel === 'members' ? 'none' : 'members')}>
              {tp(conv.members.length, '{n} participant', '{n} participants')}
            </button>
          )}
        </div>
        {group && (
          <>
            {/* Téléphone : les actions du groupe derrière « ⋯ », pour laisser la place aux messages */}
            <button type="button" className="ghost msg-more" aria-expanded={menu} aria-label={t('Options de la conversation')}
              title={t('Options de la conversation')} onClick={() => setMenu((m) => !m)}>⋯</button>
            <div className={`row msg-actions${menu ? ' open' : ''}`} style={{ gap: 6 }}>
              <button type="button" className="secondary" onClick={() => { setMenu(false); setPanel(panel === 'add' ? 'none' : 'add'); }}>{t('Ajouter')}</button>
              <button type="button" className="secondary" onClick={() => { setMenu(false); setPanel(panel === 'rename' ? 'none' : 'rename'); }}>{t('Renommer')}</button>
              <button type="button" className="ghost" onClick={() => { setMenu(false); void leave(); }}>{t('Quitter')}</button>
            </div>
          </>
        )}
      </div>

      {panel === 'members' && (
        <p className="small muted">{conv.members.map((m) => `${m.firstName} ${m.lastName}`).join(', ')}</p>
      )}
      {panel === 'rename' && <RenameForm conv={conv} onDone={() => { setPanel('none'); void onChanged(); void refresh(); }} />}
      {panel === 'add' && (
        <div className="msg-panel">
          <AddMembers conv={conv} onDone={() => { setPanel('none'); void onChanged(); void refresh(); }} onCancel={() => setPanel('none')} />
        </div>
      )}

      <div className="msg-scroll" aria-live="polite">
        {hasOlder && <button type="button" className="ghost small" onClick={() => void older()}>{t('Voir les messages plus anciens')}</button>}
        {!messages && !error && <p className="muted">{t('Chargement…')}</p>}
        {messages && !messages.length && <p className="muted small">{t('Pas encore de message. Écrivez le premier !')}</p>}
        {messages?.map((m) => {
          const day = new Date(m.createdAt).toDateString();
          const showDay = day !== prevDay;
          prevDay = day;
          const dayLabel = showDay ? new Intl.DateTimeFormat(uiLocale(), { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(m.createdAt)) : null;
          if (!m.senderId) {
            return (
              <div key={m.id}>
                {dayLabel && <div className="msg-day">{dayLabel}</div>}
                <div className="msg-system">{systemText(m.body)}</div>
              </div>
            );
          }
          const mine = m.senderId === meId;
          return (
            <div key={m.id}>
              {dayLabel && <div className="msg-day">{dayLabel}</div>}
              <div className={`msg-bubble-row${mine ? ' mine' : ''}`}>
                <div className={`msg-bubble${mine ? ' mine' : ''}${m.deletedAt ? ' deleted' : ''}`}>
                  {group && !mine && <div className="msg-author">{names.get(m.senderId) ?? t('Ancien participant')}</div>}
                  {editing?.id === m.id ? (
                    <div className="stack" style={{ gap: 6 }}>
                      <textarea value={editing.body} rows={3} aria-label={t('Modifier le message')} onChange={(e) => setEditing({ id: m.id, body: e.target.value })} />
                      <div className="row" style={{ gap: 6 }}>
                        <button type="button" onClick={() => void saveEdit()}>{t('Enregistrer')}</button>
                        <button type="button" className="secondary" onClick={() => setEditing(null)}>{t('Annuler')}</button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {m.attachment && <AttachmentView messageId={m.id} att={m.attachment} />}
                      {(m.body || m.deletedAt) && <div className="msg-body">{m.deletedAt ? t('Message retiré') : m.body}</div>}
                    </>
                  )}
                  <div className="msg-meta">
                    {fmtTime(m.createdAt)}{m.editedAt && !m.deletedAt ? ` · ${t('modifié')}` : ''}
                    {mine && !m.deletedAt && editing?.id !== m.id && (
                      <>
                        {' · '}
                        <button type="button" className="msg-link" onClick={() => setEditing({ id: m.id, body: m.body })}>{t('Modifier')}</button>
                        {' · '}
                        <button type="button" className="msg-link" onClick={() => void remove(m.id)}>{t('Retirer')}</button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottom} />
      </div>

      {error && <p className="error small">{error}</p>}
      {(file || preparing) && (
        <div className="msg-pending">
          {preparing ? <span className="small muted">{t('Préparation du fichier…')}</span> : file && (
            <>
              {isImage(file.mime) ? <img src={file.dataUrl} alt="" /> : <span className="msg-file-icon" aria-hidden="true">📄</span>}
              <span className="grow msg-ellipsis small"><strong>{file.name}</strong> · {fmtSize(file.size)}</span>
              <button type="button" className="ghost" onClick={() => setFile(null)} aria-label={t('Retirer le fichier')}>✕</button>
            </>
          )}
        </div>
      )}
      <form className="msg-compose" onSubmit={send}
        onPaste={(e) => {
          const img = [...e.clipboardData.files].find((f) => f.type.startsWith('image/'));
          if (img) { e.preventDefault(); void choose(img); }
        }}>
        <input ref={fileInput} type="file" accept={FILE_ACCEPT} hidden onChange={(e) => void choose(e.target.files?.[0])} />
        <button type="button" className="secondary msg-attach" onClick={() => fileInput.current?.click()} disabled={sending || preparing}
          aria-label={t('Joindre une photo ou un fichier')} title={t('Joindre une photo ou un fichier')}>📎</button>
        <textarea value={text} rows={2} maxLength={4000} placeholder={isNativeApp() ? t('Votre message') : t('Votre message… (Entrée pour envoyer, Maj + Entrée pour aller à la ligne)')}
          aria-label={t('Votre message')} onChange={(e) => setText(e.target.value)} onKeyDown={onKey} />
        <button type="submit" className="accent msg-send" disabled={(!text.trim() && !file) || sending || preparing} aria-label={t('Envoyer')}>
          <span className="msg-send-label">{sending ? t('Envoi…') : t('Envoyer')}</span><span className="msg-send-icon" aria-hidden="true">➤</span>
        </button>
      </form>
    </div>
  );
}

/** Photo (aperçu, touchée = plein écran) ou fichier (nom, taille, ouvrir ou télécharger) */
function AttachmentView({ messageId, att }: { messageId: string; att: Attachment }) {
  const path = `/messages/${messageId}/attachment`;
  const preview = useApiBlobUrl(isImage(att.mime) ? path : null);
  const [error, setError] = useState<string | null>(null);
  const open = () => {
    setError(null);
    const p = opensInBrowser(att.mime) ? openPdf(path) : downloadFile(path, att.name);
    p.catch((e) => setError((e as Error).message));
  };
  if (isImage(att.mime)) {
    return (
      <button type="button" className="msg-photo" onClick={open} aria-label={t('Ouvrir la photo {name}', { name: att.name })}>
        {preview ? <img src={preview} alt={att.name} /> : <span className="small muted">{t('Chargement…')}</span>}
      </button>
    );
  }
  return (
    <div>
      <button type="button" className="msg-file" onClick={open}>
        <span className="msg-file-icon" aria-hidden="true">{att.mime === 'application/pdf' ? '📕' : att.mime.startsWith('video/') ? '🎬' : '📄'}</span>
        <span className="grow" style={{ minWidth: 0, textAlign: 'start' }}>
          <span className="msg-ellipsis" style={{ display: 'block' }}><strong>{att.name}</strong></span>
          <span className="small">{fmtSize(att.size)} · {opensInBrowser(att.mime) ? t('Ouvrir') : t('Télécharger')}</span>
        </span>
      </button>
      {error && <p className="error small">{error}</p>}
    </div>
  );
}

function RenameForm({ conv, onDone }: { conv: Conversation; onDone: () => void }) {
  const [title, setTitle] = useState(conv.title ?? '');
  const [error, setError] = useState<string | null>(null);
  const save = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api(`/conversations/${conv.id}`, { method: 'PATCH', body: { title } });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="row msg-panel" onSubmit={save}>
      <input className="grow" value={title} maxLength={80} aria-label={t('Nom du groupe')} onChange={(e) => setTitle(e.target.value)} required />
      <button type="submit">{t('Renommer')}</button>
      {error && <p className="error small">{error}</p>}
    </form>
  );
}

/** Même choix de personnes que pour une nouvelle conversation, envoyé à la conversation existante */
function AddMembers({ conv, onDone, onCancel }: { conv: Conversation; onDone: () => void; onCancel: () => void }) {
  const [people, setPeople] = useState<Person[] | null>(null);
  const [picked, setPicked] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<Person[]>('/messages/people').then(setPeople).catch((e) => setError((e as Error).message));
  }, []);
  const inside = new Set(conv.members.map((m) => m.id));
  const candidates = (people ?? []).filter((p) => !inside.has(p.id));
  const save = async () => {
    try {
      await api(`/conversations/${conv.id}/members`, { method: 'POST', body: { userIds: picked } });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <div className="stack" style={{ gap: 8 }}>
      <strong>{t('Ajouter des participants')}</strong>
      <div className="msg-people" style={{ maxHeight: 200 }}>
        {people && !candidates.length && <p className="muted small">{t('Personne à ajouter.')}</p>}
        {candidates.map((p) => (
          <label key={p.id} className="check msg-person">
            <input type="checkbox" checked={picked.includes(p.id)} onChange={() => setPicked((x) => (x.includes(p.id) ? x.filter((y) => y !== p.id) : [...x, p.id]))} />
            <span><strong>{p.firstName} {p.lastName}</strong> <span className="small muted">· {p.places.join(', ')}</span></span>
          </label>
        ))}
      </div>
      {error && <p className="error small">{error}</p>}
      <div className="row" style={{ gap: 6 }}>
        <button type="button" disabled={!picked.length} onClick={() => void save()}>{t('Ajouter')}</button>
        <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
      </div>
    </div>
  );
}
