import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  formatMoney, isQuoteExpired, QUOTE_KIND_LABELS, QUOTE_STATUS_LABELS, QUOTE_STATUSES, type QuoteStatus,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { fmtDate, fmtDay, toDateInput } from '../format';
import type { QuoteRow } from '../types';
import { t, tl } from '../i18n';

export function QuoteStatusBadge({ status, validUntil }: { status: QuoteStatus; validUntil: string | null }) {
  if (isQuoteExpired({ status, validUntil }, toDateInput(new Date()))) return <span className="badge warn">{t('Expiré')}</span>;
  const tone = { DRAFT: 'neutral', SENT: 'info', ACCEPTED: 'ok', REFUSED: 'warn', CANCELLED: 'neutral' }[status];
  return <span className={`badge ${tone}`}>{tl(QUOTE_STATUS_LABELS, status)}</span>;
}

export function QuotesPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [status, setStatus] = useState<QuoteStatus | ''>('');
  const [q, setQ] = useState('');
  const { data, error, loading } = useLoad(
    () => (company ? api<QuoteRow[]>(`/quotes${qs({ companyId: company.id, agencyId: agency?.id, status, q })}`) : Promise.resolve([])),
    [company?.id, agency?.id, status, q],
  );
  const rows = data ?? [];
  const pendingTotal = rows.filter((r) => r.status === 'SENT').reduce((s, r) => s + r.netCents, 0);

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Devis')}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="row">
        <input style={{ maxWidth: 320 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Rechercher : n°, objet, client')} aria-label={t('Rechercher un devis')} />
        <select style={{ maxWidth: 200 }} value={status} onChange={(e) => setStatus(e.target.value as QuoteStatus | '')} aria-label={t('Filtrer par statut')}>
          <option value="">{t('Tous les statuts')}</option>
          {QUOTE_STATUSES.map((s) => <option key={s} value={s}>{tl(QUOTE_STATUS_LABELS, s)}</option>)}
        </select>
        <div className="grow" />
        {has('quote.write') && <button type="button" className="accent" onClick={() => navigate('/quotes/new')}>{t('Nouveau devis')}</button>}
      </div>
      {company && rows.some((r) => r.status === 'SENT') && (
        <p className="small muted">{t('En attente de réponse : {amount} HT', { amount: formatMoney(pendingTotal, company.currency, company.locale) })}</p>
      )}
      {error && <p className="error">{error}</p>}
      <section className="card">
        {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('N°')}</th><th>{t('Client')}</th><th>{t('Objet')}</th><th>{t('Type')}</th><th style={{ textAlign: 'right' }}>{t('Total HT')}</th><th>{t('Statut')}</th><th>{t("Valable jusqu'au")}</th></tr></thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="clickable" onClick={() => navigate(`/quotes/${r.id}`)}>
                    <td><Link to={`/quotes/${r.id}`} onClick={(e) => e.stopPropagation()}><strong>{r.number}</strong></Link><div className="small muted">{fmtDate(r.createdAt)}</div></td>
                    <td>{r.clientName}</td>
                    <td>{r.title}</td>
                    <td className="small">{tl(QUOTE_KIND_LABELS, r.kind)}</td>
                    <td style={{ textAlign: 'right' }}>{formatMoney(r.netCents, r.currency)}</td>
                    <td><QuoteStatusBadge status={r.status} validUntil={r.validUntil} /></td>
                    <td className="small">{fmtDay(r.validUntil)}</td>
                  </tr>
                ))}
                {data && !rows.length && <tr><td colSpan={7} className="muted">{t('Aucun devis.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
