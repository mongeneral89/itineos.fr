/**
 * Statistiques à la carte : on choisit des indicateurs, un regroupement (technicien, agence, client, mois…),
 * éventuellement un second critère pour un tableau croisé, une période et des filtres.
 * Résultat en graphique et en tableau, exportable en CSV ; les réglages se gardent sous un nom (sur cet appareil).
 */
import { useEffect, useMemo, useState } from 'react';
import {
  INTERVENTION_KINDS, INVOICE_KIND_LABELS, PRIORITIES, PRIORITY_LABELS, QUOTE_KIND_LABELS, QUOTE_STATUS_LABELS, STATUS_LABELS, type InterventionKind,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { OrgPicker } from '../components/Layout';
import { kindLabel, t, tl, uiLocale } from '../i18n';
import type { UserRow } from '../types';

type Source = 'interventions' | 'invoices' | 'quotes';
type Dim = 'all' | 'technician' | 'agency' | 'company' | 'client' | 'city' | 'kind' | 'priority' | 'status' | 'origin' | 'author'
  | 'month' | 'week' | 'day' | 'weekday' | 'hour' | 'year';
interface Options { sources: Source[]; measures: string[]; dimensions: Record<Source, Dim[]> }
interface Row { key: string; label: string; key2?: string; label2?: string; values: Record<string, number | null> }
interface Result { rows: Row[]; totals: Record<string, number | null> }

type Unit = 'n' | 'h' | 'min' | '%' | 'money';
/** Indicateurs : source, libellé, unité, groupe d'affichage */
const MEASURES: Record<string, { source: Source; label: string; unit: Unit; group: string; help?: string }> = {
  count: { source: 'interventions', label: 'Interventions', unit: 'n', group: 'Activité' },
  done: { source: 'interventions', label: 'Terminées', unit: 'n', group: 'Activité' },
  toResume: { source: 'interventions', label: 'À reprendre', unit: 'n', group: 'Activité' },
  cancelled: { source: 'interventions', label: 'Annulées', unit: 'n', group: 'Activité' },
  unassigned: { source: 'interventions', label: 'Sans technicien', unit: 'n', group: 'Activité' },
  urgent: { source: 'interventions', label: 'Urgentes ou prioritaires', unit: 'n', group: 'Activité' },
  clients: { source: 'interventions', label: 'Clients différents', unit: 'n', group: 'Activité' },
  partsQty: { source: 'interventions', label: 'Pièces posées', unit: 'n', group: 'Activité' },
  laborHours: { source: 'interventions', label: 'Heures de travail', unit: 'h', group: 'Temps' },
  travelHours: { source: 'interventions', label: 'Heures de trajet', unit: 'h', group: 'Temps' },
  avgOnSiteMin: { source: 'interventions', label: 'Durée moyenne sur place', unit: 'min', group: 'Temps' },
  responseHours: { source: 'interventions', label: 'Délai moyen d’intervention', unit: 'h', group: 'Temps', help: 'De la demande à l’arrivée sur place' },
  onTimeRate: { source: 'interventions', label: 'Arrivées à l’heure', unit: '%', group: 'Qualité', help: 'Arrivé au plus tard 15 minutes après l’heure prévue' },
  avgDelayMin: { source: 'interventions', label: 'Retard moyen à l’arrivée', unit: 'min', group: 'Qualité' },
  firstTimeFix: { source: 'interventions', label: 'Réglé au premier passage', unit: '%', group: 'Qualité', help: 'Terminées sans être « à reprendre »' },
  clientSignedRate: { source: 'interventions', label: 'Fiches signées par le client', unit: '%', group: 'Qualité' },
  revenue: { source: 'invoices', label: 'Chiffre d’affaires HT', unit: 'money', group: 'Facturation', help: 'Factures émises moins les avoirs' },
  invoiceCount: { source: 'invoices', label: 'Factures émises', unit: 'n', group: 'Facturation' },
  avgInvoice: { source: 'invoices', label: 'Facture moyenne HT', unit: 'money', group: 'Facturation' },
  quoteCount: { source: 'quotes', label: 'Devis envoyés', unit: 'n', group: 'Devis' },
  quoteAccepted: { source: 'quotes', label: 'Devis acceptés', unit: 'n', group: 'Devis' },
  quoteRate: { source: 'quotes', label: 'Taux d’acceptation des devis', unit: '%', group: 'Devis', help: 'Acceptés sur acceptés + refusés' },
  quoteAcceptedAmount: { source: 'quotes', label: 'Montant des devis acceptés HT', unit: 'money', group: 'Devis' },
};
const GROUPS = ['Activité', 'Temps', 'Qualité', 'Facturation', 'Devis'];

const DIM_LABELS: Record<Dim, string> = {
  all: 'Total', technician: 'Technicien', agency: 'Agence', company: 'Société', client: 'Client', city: 'Ville',
  kind: 'Type', priority: 'Priorité', status: 'Statut', origin: 'Origine de la demande', author: 'Créé par',
  month: 'Mois', week: 'Semaine', day: 'Jour', weekday: 'Jour de la semaine', hour: 'Heure de la journée', year: 'Année',
};
const TIME_DIMS: Dim[] = ['year', 'month', 'week', 'day', 'weekday', 'hour'];

type Preset = 'month' | 'lastMonth' | 'quarter' | 'year' | 'last12' | 'lastYear' | 'custom';
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function presetRange(p: Preset): [string, string] {
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth();
  switch (p) {
    case 'month': return [iso(new Date(y, m, 1)), iso(new Date(y, m + 1, 0))];
    case 'lastMonth': return [iso(new Date(y, m - 1, 1)), iso(new Date(y, m, 0))];
    case 'quarter': { const q = Math.floor(m / 3) * 3; return [iso(new Date(y, q, 1)), iso(new Date(y, q + 3, 0))]; }
    case 'year': return [iso(new Date(y, 0, 1)), iso(new Date(y, 11, 31))];
    case 'lastYear': return [iso(new Date(y - 1, 0, 1)), iso(new Date(y - 1, 11, 31))];
    default: return [iso(new Date(y, m - 11, 1)), iso(new Date(y, m + 1, 0))];
  }
}

interface Settings { measures: string[]; by: Dim; by2: Dim | ''; preset: Preset; from: string; to: string; technicianId: string; kind: string; priority: string; allCompanies: boolean }

/** Rapports tout prêts, pour démarrer d'un clic */
const READY: { name: string; s: Partial<Settings> }[] = [
  { name: 'Activité par technicien', s: { measures: ['count', 'done', 'laborHours', 'travelHours', 'firstTimeFix'], by: 'technician', by2: '' } },
  { name: 'Ponctualité par technicien', s: { measures: ['onTimeRate', 'avgDelayMin', 'avgOnSiteMin', 'clientSignedRate'], by: 'technician', by2: '' } },
  { name: 'Activité par agence', s: { measures: ['count', 'done', 'urgent', 'unassigned', 'responseHours'], by: 'agency', by2: '' } },
  { name: 'Chiffre d’affaires par mois', s: { measures: ['revenue', 'invoiceCount', 'avgInvoice'], by: 'month', by2: '' } },
  { name: 'Chiffre d’affaires par agence et par mois', s: { measures: ['revenue'], by: 'agency', by2: 'month' } },
  { name: 'Interventions par type', s: { measures: ['count', 'laborHours', 'avgOnSiteMin'], by: 'kind', by2: '' } },
  { name: 'Charge par jour de la semaine', s: { measures: ['count', 'laborHours'], by: 'weekday', by2: '' } },
  { name: 'Meilleurs clients', s: { measures: ['count', 'revenue'], by: 'client', by2: '' } },
  { name: 'Devis par commercial', s: { measures: ['quoteCount', 'quoteAccepted', 'quoteRate', 'quoteAcceptedAmount'], by: 'author', by2: '' } },
  { name: 'Interventions par technicien et par mois', s: { measures: ['count'], by: 'technician', by2: 'month' } },
];

const SAVED_KEY = 'itineo.stats.saved';
const LAST_KEY = 'itineo.stats.last';
function readJson<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}
function writeJson(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* stockage indisponible */
  }
}

const DEFAULTS: Settings = { measures: ['count', 'done', 'laborHours'], by: 'technician', by2: '', preset: 'last12', from: '', to: '', technicianId: '', kind: '', priority: '', allCompanies: false };

export function StatsPage() {
  const { me, company, agency } = useAuth();
  const [options, setOptions] = useState<Options | null>(null);
  const [s, setS] = useState<Settings>(() => ({ ...DEFAULTS, ...readJson<Partial<Settings>>(LAST_KEY, {}) }));
  const [techs, setTechs] = useState<UserRow[]>([]);
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState<{ name: string; s: Settings }[]>(() => readJson(SAVED_KEY, []));
  const [sort, setSort] = useState<{ col: string; desc: boolean }>({ col: '', desc: true });
  const set = (patch: Partial<Settings>) => setS((x) => ({ ...x, ...patch }));

  useEffect(() => {
    api<Options>('/stats/options').then(setOptions).catch((e) => setError((e as Error).message));
  }, []);
  useEffect(() => {
    if (!company) return;
    api<UserRow[]>(`/users${qs({ companyId: company.id, agencyId: agency?.id, role: 'TECHNICIAN' })}`).then(setTechs).catch(() => setTechs([]));
  }, [company, agency]);

  const available = useMemo(() => Object.keys(MEASURES).filter((m) => options?.measures.includes(m)), [options]);
  const measures = s.measures.filter((m) => available.includes(m));
  const sources = [...new Set(measures.map((m) => MEASURES[m].source))];
  /** Critères possibles pour tous les indicateurs choisis */
  const dims = useMemo(() => {
    if (!options || !sources.length) return [] as Dim[];
    return (Object.keys(DIM_LABELS) as Dim[]).filter((d) => sources.every((src) => options.dimensions[src]?.includes(d)));
  }, [options, sources.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps
  const by = dims.includes(s.by) ? s.by : dims[1] ?? 'all';
  const by2 = s.by2 && dims.includes(s.by2) && s.by2 !== by && measures.length === 1 ? s.by2 : '';
  const [from, to] = s.preset === 'custom' && s.from && s.to ? [s.from, s.to] : presetRange(s.preset === 'custom' ? 'last12' : s.preset);

  const run = async () => {
    if (!measures.length) return;
    setLoading(true);
    setError(null);
    writeJson(LAST_KEY, s);
    try {
      const r = await api<Result>(`/stats${qs({
        measures: measures.join(','), by, by2: by2 || undefined, from, to,
        tz: company?.timezone ?? 'Europe/Paris',
        companyId: s.allCompanies ? undefined : company?.id, agencyId: s.allCompanies ? undefined : agency?.id,
        technicianId: s.technicianId || undefined, kind: s.kind || undefined, priority: s.priority || undefined,
      })}`);
      setResult(r);
    } catch (e) {
      setError((e as Error).message);
      setResult(null);
    } finally {
      setLoading(false);
    }
  };
  // Recalcul automatique quand un réglage change
  useEffect(() => {
    if (options) void run();
  }, [options, measures.join(','), by, by2, from, to, s.technicianId, s.kind, s.priority, s.allCompanies, company?.id, agency?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleMeasure = (m: string) => set({
    measures: s.measures.includes(m) ? s.measures.filter((x) => x !== m) : s.measures.length >= 6 ? s.measures : [...s.measures, m],
  });

  /** Libellé lisible d'une valeur de critère */
  const keyLabel = (dim: Dim, key: string, label: string): string => {
    const src = sources[0];
    switch (dim) {
      case 'all': return t('Total');
      case 'technician': case 'author': return label || t('Non attribuée');
      case 'agency': return label || t('Sans agence');
      case 'city': return label || t('Ville non renseignée');
      case 'origin': return label || t('Non précisée');
      case 'kind': return src === 'invoices' ? tl(INVOICE_KIND_LABELS, key as keyof typeof INVOICE_KIND_LABELS) : src === 'quotes' ? tl(QUOTE_KIND_LABELS, key as keyof typeof QUOTE_KIND_LABELS) : kindLabel(key as InterventionKind);
      case 'priority': return tl(PRIORITY_LABELS, key as keyof typeof PRIORITY_LABELS);
      case 'status': return src === 'quotes' ? tl(QUOTE_STATUS_LABELS, key as keyof typeof QUOTE_STATUS_LABELS) : tl(STATUS_LABELS, key as keyof typeof STATUS_LABELS);
      case 'month': return new Intl.DateTimeFormat(uiLocale(), { month: 'long', year: 'numeric' }).format(new Date(`${key}-01T12:00:00`));
      case 'week': return t('Semaine du {date}', { date: new Intl.DateTimeFormat(uiLocale(), { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${label}T12:00:00`)) });
      case 'day': return new Intl.DateTimeFormat(uiLocale(), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${key}T12:00:00`));
      case 'weekday': return new Intl.DateTimeFormat(uiLocale(), { weekday: 'long' }).format(new Date(2024, 0, Number(key))); // 1er janvier 2024 = lundi
      case 'hour': return t('{h} h', { h: key });
      default: return label || key;
    }
  };

  const fmt = (m: string, v: number | null | undefined): string => {
    if (v == null || Number.isNaN(v)) return '—';
    const unit = MEASURES[m].unit;
    const n = (d: number) => v.toLocaleString(uiLocale(), { maximumFractionDigits: d, minimumFractionDigits: 0 });
    if (unit === 'money') return v.toLocaleString(uiLocale(), { style: 'currency', currency: company?.currency ?? 'EUR', maximumFractionDigits: 0 });
    if (unit === '%') return `${n(0)} %`;
    if (unit === 'h') return t('{n} h', { n: n(1) });
    if (unit === 'min') return t('{n} min', { n: n(0) });
    return n(1);
  };

  // Lignes triées : par défaut dans l'ordre naturel pour le temps, sinon par le premier indicateur décroissant
  const rows = useMemo(() => {
    const list = [...(result?.rows ?? [])];
    const col = sort.col || (TIME_DIMS.includes(by) ? '' : measures[0]);
    if (!col) return list.sort((a, b) => (by === 'weekday' ? Number(a.key) - Number(b.key) : a.key.localeCompare(b.key)));
    if (col === '__label') return list.sort((a, b) => keyLabel(by, a.key, a.label).localeCompare(keyLabel(by, b.key, b.label)) * (sort.desc ? -1 : 1));
    return list.sort((a, b) => ((a.values[col] ?? -Infinity) - (b.values[col] ?? -Infinity)) * (sort.desc ? -1 : 1));
  }, [result, sort, by, measures.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps

  const exportCsv = () => {
    if (!result) return;
    const esc = (x: string) => (/[";\n]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x);
    const num = (v: number | null | undefined) => (v == null ? '' : String(Math.round(v * 100) / 100).replace('.', ','));
    let lines: string[];
    if (by2) {
      const cols = pivotCols(result.rows);
      lines = [[t(DIM_LABELS[by]), ...cols.map((c) => keyLabel(by2, c.key, c.label))].map(esc).join(';')];
      for (const r of pivotRows(result.rows)) lines.push([keyLabel(by, r.key, r.label), ...cols.map((c) => num(r.cells.get(c.key)))].map(esc).join(';'));
    } else {
      lines = [[t(DIM_LABELS[by]), ...measures.map((m) => t(MEASURES[m].label))].map(esc).join(';')];
      for (const r of rows) lines.push([keyLabel(by, r.key, r.label), ...measures.map((m) => num(r.values[m]))].map(esc).join(';'));
      lines.push([t('Total'), ...measures.map((m) => num(result.totals[m]))].map(esc).join(';'));
    }
    const blob = new Blob([`﻿${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `statistiques-${from}-${to}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };

  const saveReport = () => {
    const name = window.prompt(t('Nom de ce rapport :'));
    if (!name?.trim()) return;
    const next = [...saved.filter((x) => x.name !== name.trim()), { name: name.trim(), s }];
    setSaved(next);
    writeJson(SAVED_KEY, next);
  };
  const removeReport = (name: string) => {
    const next = saved.filter((x) => x.name !== name);
    setSaved(next);
    writeJson(SAVED_KEY, next);
  };

  const first = measures[0];
  const max = Math.max(0, ...rows.map((r) => Math.abs(r.values[first] ?? 0)));

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{s.allCompanies ? t('Tout le groupe') : `${company?.name ?? ''}${agency ? ` · ${agency.name}` : ''}`}</div>
          <h1>{t('Statistiques')}</h1>
        </div>
        <OrgPicker />
      </div>

      <section className="card stack">
        <div className="row" style={{ gap: 6 }}>
          <span className="small muted">{t('Rapports tout prêts :')}</span>
          {READY.filter((r) => r.s.measures!.every((m) => available.includes(m))).map((r) => (
            <button key={r.name} type="button" className="chip" onClick={() => { set(r.s); setSort({ col: '', desc: true }); }}>{t(r.name)}</button>
          ))}
        </div>
        {saved.length > 0 && (
          <div className="row" style={{ gap: 6 }}>
            <span className="small muted">{t('Mes rapports :')}</span>
            {saved.map((r) => (
              <span key={r.name} className="chip" style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>
                <button type="button" className="msg-link" style={{ textDecoration: 'none', fontSize: 13 }} onClick={() => setS({ ...DEFAULTS, ...r.s })}>{r.name}</button>
                <button type="button" className="msg-link" aria-label={t('Supprimer le rapport {name}', { name: r.name })} onClick={() => removeReport(r.name)}>✕</button>
              </span>
            ))}
          </div>
        )}
      </section>

      <section className="card stack">
        <h2 style={{ fontSize: 16 }}>{t('Indicateurs')} <span className="small muted">{t('(6 au maximum)')}</span></h2>
        <div className="stats-groups">
          {GROUPS.map((g) => {
            const list = available.filter((m) => MEASURES[m].group === g);
            if (!list.length) return null;
            return (
              <div key={g} className="stack" style={{ gap: 4 }}>
                <strong className="small">{t(g)}</strong>
                {list.map((m) => (
                  <label key={m} className="check small" title={MEASURES[m].help ? t(MEASURES[m].help!) : undefined}>
                    <input type="checkbox" checked={s.measures.includes(m)} disabled={!s.measures.includes(m) && s.measures.length >= 6} onChange={() => toggleMeasure(m)} />
                    {t(MEASURES[m].label)}
                  </label>
                ))}
              </div>
            );
          })}
        </div>

        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div className="field">
            <label htmlFor="st-by">{t('Regrouper par')}</label>
            <select id="st-by" value={by} onChange={(e) => { set({ by: e.target.value as Dim }); setSort({ col: '', desc: true }); }}>
              {dims.map((d) => <option key={d} value={d}>{t(DIM_LABELS[d])}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="st-by2">{t('Croiser avec')}</label>
            <select id="st-by2" value={by2} disabled={measures.length !== 1} onChange={(e) => set({ by2: e.target.value as Dim | '' })}
              title={measures.length !== 1 ? t('Pour croiser deux critères, choisissez un seul indicateur') : undefined}>
              <option value="">—</option>
              {dims.filter((d) => d !== 'all' && d !== by).map((d) => <option key={d} value={d}>{t(DIM_LABELS[d])}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="st-period">{t('Période')}</label>
            <select id="st-period" value={s.preset} onChange={(e) => {
              const preset = e.target.value as Preset;
              if (preset === 'custom') { const [f0, t0] = presetRange(s.preset); set({ preset, from: s.from || f0, to: s.to || t0 }); } else set({ preset });
            }}>
              <option value="month">{t('Ce mois-ci')}</option>
              <option value="lastMonth">{t('Le mois dernier')}</option>
              <option value="quarter">{t('Ce trimestre')}</option>
              <option value="year">{t('Cette année')}</option>
              <option value="lastYear">{t('L’année dernière')}</option>
              <option value="last12">{t('Les 12 derniers mois')}</option>
              <option value="custom">{t('Dates au choix')}</option>
            </select>
          </div>
          {s.preset === 'custom' && (
            <>
              <div className="field"><label htmlFor="st-from">{t('Du')}</label><input id="st-from" type="date" value={s.from} onChange={(e) => set({ from: e.target.value })} /></div>
              <div className="field"><label htmlFor="st-to">{t('Au')}</label><input id="st-to" type="date" value={s.to} onChange={(e) => set({ to: e.target.value })} /></div>
            </>
          )}
        </div>
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div className="field">
            <label htmlFor="st-tech">{t('Technicien')}</label>
            <select id="st-tech" value={s.technicianId} onChange={(e) => set({ technicianId: e.target.value })}>
              <option value="">{t('Tous')}</option>
              {techs.map((u) => <option key={u.id} value={u.id}>{u.firstName} {u.lastName}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="st-kind">{t('Type d’intervention')}</label>
            <select id="st-kind" value={s.kind} onChange={(e) => set({ kind: e.target.value })}>
              <option value="">{t('Tous')}</option>
              {INTERVENTION_KINDS.map((k) => <option key={k} value={k}>{kindLabel(k)}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="st-prio">{t('Priorité')}</label>
            <select id="st-prio" value={s.priority} onChange={(e) => set({ priority: e.target.value })}>
              <option value="">{t('Toutes')}</option>
              {PRIORITIES.map((k) => <option key={k} value={k}>{tl(PRIORITY_LABELS, k)}</option>)}
            </select>
          </div>
          {(me?.org.length ?? 0) > 1 && (
            <label className="check small"><input type="checkbox" checked={s.allCompanies} onChange={(e) => set({ allCompanies: e.target.checked })} />{t('Toutes les sociétés du groupe')}</label>
          )}
          <div className="grow" />
          <button type="button" className="secondary" onClick={saveReport}>{t('Enregistrer ce rapport')}</button>
          <button type="button" className="secondary" disabled={!result?.rows.length} onClick={exportCsv}>{t('Exporter (CSV)')}</button>
        </div>
        {(s.technicianId || s.kind || s.priority) && sources.some((x) => x !== 'interventions') && (
          <p className="small muted">{t('Pour les factures et les devis, ces filtres s’appliquent à l’intervention dont ils viennent.')}</p>
        )}
      </section>

      {error && <p className="error">{error}</p>}
      {!measures.length && <p className="muted">{t('Choisissez au moins un indicateur.')}</p>}
      {loading && !result && <p className="muted">{t('Calcul…')}</p>}

      {result && measures.length > 0 && (
        <section className="card stack" style={{ opacity: loading ? 0.6 : 1 }}>
          <p className="small muted">
            {t('Du {from} au {to}', { from: new Date(`${from}T12:00:00`).toLocaleDateString(uiLocale()), to: new Date(`${to}T12:00:00`).toLocaleDateString(uiLocale()) })}
          </p>
          {!result.rows.length && <p className="muted">{t('Aucune donnée sur cette période.')}</p>}

          {result.rows.length > 0 && !by2 && by !== 'all' && (
            <div className="stats-chart" role="img" aria-label={t('Graphique : {m} par {d}', { m: t(MEASURES[first].label), d: t(DIM_LABELS[by]).toLowerCase() })}>
              <div className="small muted">{t(MEASURES[first].label)}</div>
              {rows.slice(0, 30).map((r) => {
                const v = r.values[first] ?? 0;
                return (
                  <div key={r.key} className="stats-bar-row">
                    <span className="stats-bar-label" title={keyLabel(by, r.key, r.label)}>{keyLabel(by, r.key, r.label)}</span>
                    <span className="stats-bar-track"><span className={`stats-bar${v < 0 ? ' neg' : ''}`} style={{ width: `${max ? (Math.abs(v) / max) * 100 : 0}%` }} /></span>
                    <span className="stats-bar-value">{fmt(first, r.values[first])}</span>
                  </div>
                );
              })}
              {rows.length > 30 && <div className="small muted">{t('Les 30 premiers sont affichés ; tout est dans le tableau.')}</div>}
            </div>
          )}

          {result.rows.length > 0 && (by2 ? (
            <PivotTable rows={result.rows} fmtValue={(v) => fmt(first, v)} rowLabel={(k, l) => keyLabel(by, k, l)} colLabel={(k, l) => keyLabel(by2, k, l)}
              title={t(DIM_LABELS[by])} timeCols={TIME_DIMS.includes(by2)} />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th><button type="button" className="msg-link" style={{ fontSize: 'inherit' }} onClick={() => setSort({ col: '__label', desc: sort.col === '__label' ? !sort.desc : false })}>{t(DIM_LABELS[by])}</button></th>
                    {measures.map((m) => (
                      <th key={m} style={{ textAlign: 'right' }} title={MEASURES[m].help ? t(MEASURES[m].help!) : undefined}>
                        <button type="button" className="msg-link" style={{ fontSize: 'inherit' }} onClick={() => setSort({ col: m, desc: sort.col === m ? !sort.desc : true })}>
                          {t(MEASURES[m].label)}{sort.col === m ? (sort.desc ? ' ↓' : ' ↑') : ''}
                        </button>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {by !== 'all' && rows.map((r) => (
                    <tr key={r.key}>
                      <td>{keyLabel(by, r.key, r.label)}</td>
                      {measures.map((m) => <td key={m} style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{fmt(m, r.values[m])}</td>)}
                    </tr>
                  ))}
                  <tr style={{ fontWeight: 700 }}>
                    <td>{t('Total')}</td>
                    {measures.map((m) => <td key={m} style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{fmt(m, result.totals[m])}</td>)}
                  </tr>
                </tbody>
              </table>
            </div>
          ))}
        </section>
      )}
    </>
  );
}

function pivotCols(rows: Row[]) {
  const m = new Map<string, string>();
  for (const r of rows) if (r.key2 !== undefined && !m.has(r.key2)) m.set(r.key2, r.label2 ?? '');
  return [...m].map(([key, label]) => ({ key, label }));
}
function pivotRows(rows: Row[]) {
  const m = new Map<string, { key: string; label: string; cells: Map<string, number | null> }>();
  const measure = Object.keys(rows[0]?.values ?? {})[0];
  for (const r of rows) {
    const row = m.get(r.key) ?? { key: r.key, label: r.label, cells: new Map() };
    row.cells.set(r.key2 ?? '', r.values[measure] ?? null);
    m.set(r.key, row);
  }
  return [...m.values()];
}

/** Tableau croisé : un critère en lignes, l'autre en colonnes, couleur selon la valeur */
function PivotTable({ rows, fmtValue, rowLabel, colLabel, title, timeCols }: {
  rows: Row[]; fmtValue: (v: number | null) => string; rowLabel: (k: string, l: string) => string; colLabel: (k: string, l: string) => string;
  title: string; timeCols: boolean;
}) {
  const cols = pivotCols(rows).sort((a, b) => (timeCols ? (a.key.length === 1 ? Number(a.key) - Number(b.key) : a.key.localeCompare(b.key)) : colLabel(a.key, a.label).localeCompare(colLabel(b.key, b.label))));
  const lines = pivotRows(rows).sort((a, b) => rowLabel(a.key, a.label).localeCompare(rowLabel(b.key, b.label)));
  const max = Math.max(0, ...rows.map((r) => Math.abs(Object.values(r.values)[0] ?? 0)));
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>{title}</th>{cols.map((c) => <th key={c.key} style={{ textAlign: 'right' }}>{colLabel(c.key, c.label)}</th>)}</tr>
        </thead>
        <tbody>
          {lines.map((r) => (
            <tr key={r.key}>
              <td>{rowLabel(r.key, r.label)}</td>
              {cols.map((c) => {
                const v = r.cells.get(c.key) ?? null;
                const a = v == null || !max ? 0 : Math.abs(v) / max;
                return <td key={c.key} style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums', background: a ? `rgba(232, 93, 36, ${0.08 + a * 0.35})` : undefined }}>{fmtValue(v)}</td>;
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
