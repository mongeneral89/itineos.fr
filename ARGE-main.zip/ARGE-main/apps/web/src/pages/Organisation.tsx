import { useState, type FormEvent } from 'react';
import { ROLE_LABELS, ROLES, UI_LOCALE_LABELS, UI_LOCALES, type Role } from '@itineo/shared';
import { api, downloadFile, qs } from '../api';
import { useAuth } from '../auth';
import { InvitePanel } from '../components/InvitePanel';
import { UserEditor } from '../components/UserEditor';
import { useLoad } from '../hooks';
import type { Company, UserRow } from '../types';
import { moneyInput, parseMoneyInput } from '../format';
import { t, tl } from '../i18n';
import { logoSrc, logoToPng } from '../logo';

/** Organisation du groupe : sociétés (une par pays), agences et comptes */
export function OrganisationPage() {
  const { me, has, refresh, company, agency, select } = useAuth();
  const isGroupAdmin = me?.assignments.some((a) => a.role === 'GROUP_ADMIN') ?? false;
  const [addingCompany, setAddingCompany] = useState(false);
  // Même règle que le serveur : administrateur du groupe, ou directeur de toute la société
  const canExport = (companyId: string) => me?.assignments.some((a) =>
    (a.role === 'GROUP_ADMIN' && (!a.companyId || a.companyId === companyId) && !a.agencyId)
    || (a.role === 'DIRECTOR' && a.companyId === companyId && !a.agencyId)) ?? false;

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{t('Groupe')}</div>
          <h1>{t('Organisation')}</h1>
        </div>
        {isGroupAdmin && !addingCompany && <button type="button" className="accent" onClick={() => setAddingCompany(true)}>{t('Nouvelle société')}</button>}
      </div>
      {addingCompany && <CompanyForm onDone={async () => { setAddingCompany(false); await refresh(); }} />}

      <div className="grid">
        {me?.org.map((c) => (
          <section key={c.id} className="card stack">
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <h2>{c.name}</h2>
              <span className="badge neutral">{c.countryCode} · {c.currency}</span>
            </div>
            <div className="small muted">{t('Langue {locale} · Fuseau {tz} · Numéros {prefix}-AAAA-00001', { locale: c.locale, tz: c.timezone, prefix: c.documentPrefix })}</div>
            <div className="stack" style={{ gap: 6 }}>
              {c.agencies.map((a) => (
                <button key={a.id} type="button" className={company?.id === c.id && agency?.id === a.id ? '' : 'secondary'}
                  style={{ justifyContent: 'space-between' }} onClick={() => select(c.id, a.id)}>
                  <span>{a.name}</span><span className="small">{a.city ?? a.code}</span>
                </button>
              ))}
            </div>
            <LogoSetting company={c} canEdit={has('org.write')} onDone={refresh} />
            {has('org.write') && <AgencyForm companyId={c.id} onDone={refresh} />}
            {has('invoice.write') && <BillingSettings company={c} onDone={refresh} />}
            {has('invoice.write') && <EInvoiceSettings company={c} canEditIds={has('org.write')} onDone={refresh} />}
            {(has('org.write') || has('intervention.assign')) && <PlanningSettings company={c} onDone={refresh} />}
            {has('org.write') && <MenuLinksSettings company={c} onDone={refresh} />}
            {canExport(c.id) && <ExportSetting company={c} />}
          </section>
        ))}
      </div>

      {company && has('user.read') && <UsersSection />}
    </>
  );
}

/** Export complet (garantie de réversibilité) : toutes les données de la société dans une archive lisible sans Itinéos */
function ExportSetting({ company }: { company: Company }) {
  const [state, setState] = useState<'idle' | 'busy' | 'done'>('idle');
  const [error, setError] = useState<string | null>(null);
  const download = async () => {
    setError(null);
    setState('busy');
    try {
      await downloadFile(`/org/companies/${company.id}/export`, `itineos-export-${company.documentPrefix.toLowerCase()}.zip`);
      setState('done');
    } catch (err) {
      setError((err as Error).message);
      setState('idle');
    }
  };
  return (
    <div className="stack" style={{ gap: 6 }}>
      <h3>{t('Export complet des données')}</h3>
      <p className="small muted">{t('Toutes les données de {name} dans une archive .zip lisible sans Itinéos : tableaux CSV pour Excel, fiches, devis et factures en PDF, photos et signatures.', { name: company.name })}</p>
      <div className="row">
        <button type="button" className="secondary" disabled={state === 'busy'} onClick={() => void download()}>{t('Télécharger l’export complet')}</button>
      </div>
      {state === 'busy' && <p className="small muted">{t('Préparation de l’archive… (plusieurs minutes s’il y a beaucoup de photos)')}</p>}
      {state === 'done' && <p className="small">{t('Archive téléchargée.')}</p>}
      {error && <p className="error">{error}</p>}
    </div>
  );
}

/** Logo de la société : affiché dans le logiciel, l'espace client et en tête des documents PDF */
function LogoSetting({ company, canEdit, onDone }: { company: Company; canEdit: boolean; onDone: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const src = logoSrc(company);
  if (!src && !canEdit) return null;

  const upload = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    setBusy(true);
    try {
      const image = await logoToPng(file);
      await api(`/org/companies/${company.id}/logo`, { method: 'PUT', body: { image } });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const remove = async () => {
    if (!window.confirm(t('Retirer le logo de {name} ?', { name: company.name }))) return;
    try {
      await api(`/org/companies/${company.id}/logo`, { method: 'DELETE' });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <div className="stack" style={{ gap: 6, borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <strong>{t('Logo')}</strong>
      {src ? <img className="logo-preview" src={src} alt={company.name} /> : <p className="small muted">{t('Aucun logo : le nom de la société s’affiche seul.')}</p>}
      {canEdit && (
        <>
          <div className="row">
            <label className="btn secondary" style={{ cursor: busy ? 'wait' : 'pointer' }}>
              {busy ? t('Envoi…') : src ? t('Changer le logo') : t('Ajouter un logo')}
              <input type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp" hidden disabled={busy}
                onChange={(e) => { void upload(e.target.files?.[0]); e.target.value = ''; }} />
            </label>
            {src && <button type="button" className="ghost" onClick={() => void remove()}>{t('Retirer')}</button>}
          </div>
          <p className="small muted">{t('PNG, JPEG, SVG ou WebP. Il apparaît dans le menu, l’appli terrain, l’espace client et en tête des fiches, devis et factures.')}</p>
        </>
      )}
      {error && <p className="error small">{error}</p>}
    </div>
  );
}

/** Suggestion d'attribution : fonction à activer ou non, société par société */
function PlanningSettings({ company, onDone }: { company: Company; onDone: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const toggle = async (patch: { assignSuggestions?: boolean; geocodeSites?: boolean }) => {
    setError(null);
    try {
      await api(`/org/companies/${company.id}/planning`, { method: 'PATCH', body: patch });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <div className="stack" style={{ gap: 6, borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <strong>{t('Planification')}</strong>
      <label className="check small">
        <input type="checkbox" checked={!!company.assignSuggestions} onChange={(e) => void toggle({ assignSuggestions: e.target.checked })} />
        {t('Suggérer un technicien pour chaque intervention à planifier (position, charge, stock du véhicule, habilitations)')}
      </label>
      {company.assignSuggestions && (
        <label className="check small">
          <input type="checkbox" checked={!!company.geocodeSites} onChange={(e) => void toggle({ geocodeSites: e.target.checked })} />
          {t('Localiser les adresses des sites avec le service public d’adresses (France), pour calculer les distances')}
        </label>
      )}
      {company.assignSuggestions && !company.geocodeSites && (
        <p className="small muted">{t('Sans cela, un site est localisé la première fois qu’un technicien y signale « Je suis sur place » avec le partage de position activé.')}</p>
      )}
      {error && <p className="error small">{error}</p>}
    </div>
  );
}

/**
 * Liens du menu vers les outils en ligne de la société (DocuSign, banque, comptabilité…).
 * Ils s'ouvrent dans un onglet à part : ces sites refusent d'être affichés à l'intérieur d'Itinéos.
 */
function MenuLinksSettings({ company, onDone }: { company: Company; onDone: () => void }) {
  const [links, setLinks] = useState(company.menuLinks ?? []);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const change = (i: number, patch: Partial<{ label: string; url: string }>) => {
    setSaved(false);
    setLinks((ls) => ls.map((l, k) => (k === i ? { ...l, ...patch } : l)));
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api(`/org/companies/${company.id}/menu-links`, { method: 'PUT', body: { links: links.filter((l) => l.label.trim() || l.url.trim()) } });
      setSaved(true);
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="stack" style={{ gap: 6, borderTop: '1px solid var(--rule)', paddingTop: 10 }} onSubmit={(e) => void save(e)}>
      <strong>{t('Liens dans le menu')}</strong>
      <p className="small muted">{t('Vos outils en ligne (signature électronique, banque, comptabilité…) apparaissent dans le menu et s’ouvrent dans un onglet à part.')}</p>
      {links.map((l, i) => (
        <div key={i} className="row" style={{ alignItems: 'flex-end' }}>
          <div className="field" style={{ flex: '1 1 120px' }}>
            <label htmlFor={`ml-label-${company.id}-${i}`}>{t('Nom')}</label>
            <input id={`ml-label-${company.id}-${i}`} value={l.label} maxLength={40} placeholder="DocuSign" onChange={(e) => change(i, { label: e.target.value })} required />
          </div>
          <div className="field" style={{ flex: '3 1 220px' }}>
            <label htmlFor={`ml-url-${company.id}-${i}`}>{t('Adresse')}</label>
            <input id={`ml-url-${company.id}-${i}`} type="url" value={l.url} maxLength={500} placeholder="https://app.docusign.com" onChange={(e) => change(i, { url: e.target.value })} required />
          </div>
          <button type="button" className="ghost" onClick={() => { setSaved(false); setLinks((ls) => ls.filter((_, k) => k !== i)); }}>{t('Retirer')}</button>
        </div>
      ))}
      <div className="row">
        {links.length < 10 && <button type="button" className="secondary" onClick={() => { setSaved(false); setLinks((ls) => [...ls, { label: '', url: 'https://' }]); }}>{t('Ajouter un lien')}</button>}
        <button type="submit">{t('Enregistrer')}</button>
        {saved && <span className="small muted">✓</span>}
      </div>
      {error && <p className="error small">{error}</p>}
    </form>
  );
}

/** Réglages de facturation d'une société (repris sur les factures et pour facturer une fiche) */
function BillingSettings({ company, onDone }: { company: Company; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({
    terms: String(company.paymentTermsDays ?? 30),
    hourly: company.hourlyRateCents != null ? moneyInput(company.hourlyRateCents) : '',
    travel: company.travelFeeCents != null ? moneyInput(company.travelFeeCents) : '',
    bank: company.bankDetails ?? '',
    legal: company.legalMentions ?? '',
    ics: company.sepaCreditorId ?? '',
    iban: company.sepaIban ?? '',
    bic: company.sepaBic ?? '',
    d1: String(company.dunningDays?.[0] ?? 7),
    d2: String(company.dunningDays?.[1] ?? 15),
    d3: String(company.dunningDays?.[2] ?? 30),
  });
  const [dunning, setDunning] = useState(!!company.dunningEnabled);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  if (!open) return <button type="button" className="ghost" onClick={() => setOpen(true)}>{t('Réglages de facturation')}</button>;

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);
    const money = (s: string) => {
      if (!s.trim()) return null;
      const c = parseMoneyInput(s);
      if (c === null) throw new Error(t('Montant invalide : {value}', { value: s }));
      return c;
    };
    try {
      const terms = Number(f.terms);
      if (!Number.isInteger(terms) || terms < 0 || terms > 120) throw new Error(t('Délai de paiement : entre 0 et 120 jours'));
      const days = [f.d1, f.d2, f.d3].map(Number);
      if (days.some((d) => !Number.isInteger(d) || d < 1 || d > 365) || !(days[0] < days[1] && days[1] < days[2])) {
        throw new Error(t('Relances : des jours entre 1 et 365, en augmentant (rappel, puis relance, puis mise en demeure)'));
      }
      await api(`/org/companies/${company.id}/billing`, {
        method: 'PATCH',
        body: {
          paymentTermsDays: terms, hourlyRateCents: money(f.hourly), travelFeeCents: money(f.travel), bankDetails: f.bank.trim() || null, legalMentions: f.legal.trim() || null,
          sepaCreditorId: f.ics.trim() || null, sepaIban: f.iban.trim() || null, sepaBic: f.bic.trim() || null,
          dunningEnabled: dunning, dunningDays: days,
        },
      });
      setSaved(true);
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));

  return (
    <form className="stack" onSubmit={save} style={{ borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <strong>{t('Réglages de facturation')}</strong>
      <div className="row">
        <div className="field" style={{ width: 130 }}><label htmlFor={`bt-${company.id}`}>{t('Paiement à (jours)')}</label><input id={`bt-${company.id}`} inputMode="numeric" value={f.terms} onChange={set('terms')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor={`bh-${company.id}`}>{t('Taux horaire HT')}</label><input id={`bh-${company.id}`} inputMode="decimal" placeholder="65,00" value={f.hourly} onChange={set('hourly')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor={`bd-${company.id}`}>{t('Forfait déplacement HT')}</label><input id={`bd-${company.id}`} inputMode="decimal" placeholder="35,00" value={f.travel} onChange={set('travel')} /></div>
      </div>
      <div className="field"><label htmlFor={`bb-${company.id}`}>{t('Coordonnées bancaires (sur les factures)')}</label><input id={`bb-${company.id}`} placeholder="IBAN FR76 … · BIC …" value={f.bank} onChange={set('bank')} /></div>
      <div className="field"><label htmlFor={`bl-${company.id}`}>{t('Mentions légales (pied de page : forme, capital, SIRET, RCS…)')}</label><input id={`bl-${company.id}`} value={f.legal} onChange={set('legal')} /></div>
      <strong className="small">{t('Prélèvement SEPA des abonnements')}</strong>
      <div className="row">
        <div className="field" style={{ width: 200 }}><label htmlFor={`bs-${company.id}`}>{t('Identifiant créancier SEPA (ICS)')}</label><input id={`bs-${company.id}`} placeholder="FR12ZZZ123456" value={f.ics} onChange={set('ics')} /></div>
        <div className="field grow"><label htmlFor={`bi-${company.id}`}>{t('IBAN du compte qui reçoit les prélèvements')}</label><input id={`bi-${company.id}`} placeholder="FR76 …" value={f.iban} onChange={set('iban')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor={`bc-${company.id}`}>{t('BIC')}</label><input id={`bc-${company.id}`} value={f.bic} onChange={set('bic')} /></div>
      </div>
      <p className="small muted" style={{ margin: 0 }}>{t('L’ICS est attribué par votre banque quand vous demandez à prélever vos clients.')}</p>
      <strong className="small">{t('Relances des impayés')}</strong>
      <label className="check"><input type="checkbox" checked={dunning} onChange={(e) => setDunning(e.target.checked)} />{t('Envoyer les relances automatiquement par e-mail (facture jointe)')}</label>
      <div className="row">
        <div className="field" style={{ width: 150 }}><label htmlFor={`r1-${company.id}`}>{t('Rappel (jours après l’échéance)')}</label><input id={`r1-${company.id}`} inputMode="numeric" value={f.d1} onChange={set('d1')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor={`r2-${company.id}`}>{t('Relance (jours)')}</label><input id={`r2-${company.id}`} inputMode="numeric" value={f.d2} onChange={set('d2')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor={`r3-${company.id}`}>{t('Mise en demeure (jours)')}</label><input id={`r3-${company.id}`} inputMode="numeric" value={f.d3} onChange={set('d3')} /></div>
      </div>
      {error && <p className="error">{error}</p>}
      {saved && <p className="success">{t('Réglages enregistrés.')}</p>}
      <div className="row"><button type="submit">{t('Enregistrer')}</button><button type="button" className="secondary" onClick={() => setOpen(false)}>{t('Fermer')}</button></div>
    </form>
  );
}

/**
 * Facture électronique (obligatoire pour les PME au 1er septembre 2027) : SIREN et n° de TVA de la société,
 * option TVA sur les débits, et la plateforme agréée choisie (adresse de son API, jeton d'accès).
 */
function EInvoiceSettings({ company, canEditIds, onDone }: { company: Company; canEditIds: boolean; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({
    siren: company.siren ?? '', vat: company.vatNumber ?? '', debits: !!company.vatOnDebits,
    url: company.einvoiceApiUrl ?? '', token: '', auto: !!company.einvoiceAutoSend,
  });
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  if (!open) return <button type="button" className="ghost" onClick={() => setOpen(true)}>{t('Facture électronique')}</button>;

  const save = async (e?: FormEvent) => {
    e?.preventDefault();
    setError(null);
    setMsg(null);
    try {
      if (canEditIds && ((company.siren ?? '') !== f.siren.trim() || (company.vatNumber ?? '') !== f.vat.trim())) {
        await api(`/org/companies/${company.id}`, { method: 'PATCH', body: { siren: f.siren.trim(), vatNumber: f.vat.trim() } });
      }
      await api(`/org/companies/${company.id}/billing`, {
        method: 'PATCH',
        body: { vatOnDebits: f.debits, einvoiceApiUrl: f.url.trim() || null, einvoiceAutoSend: f.auto, ...(f.token.trim() ? { einvoiceApiToken: f.token.trim() } : {}) },
      });
      setF((x) => ({ ...x, token: '' }));
      setMsg(t('Réglages enregistrés.'));
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const test = async () => {
    setError(null);
    setMsg(null);
    try {
      await save();
      await api(`/org/companies/${company.id}/einvoice/test`, { method: 'POST' });
      setMsg(t('Connexion à la plateforme réussie.'));
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const set = (k: 'siren' | 'vat' | 'url' | 'token') => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));

  return (
    <form className="stack" onSubmit={save} style={{ borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <strong>{t('Facture électronique')}</strong>
      <p className="small muted" style={{ margin: 0 }}>
        {t('Vos factures émises sont au format Factur-X : un PDF qui contient aussi les données lisibles par les plateformes agréées. Les factures aux particuliers continuent d’être envoyées par e-mail.')}
      </p>
      <div className="row">
        <div className="field grow"><label htmlFor={`es-${company.id}`}>{t('SIREN ou SIRET')}</label><input id={`es-${company.id}`} inputMode="numeric" value={f.siren} disabled={!canEditIds} onChange={set('siren')} /></div>
        <div className="field grow"><label htmlFor={`ev-${company.id}`}>{t('N° de TVA intracommunautaire')}</label><input id={`ev-${company.id}`} value={f.vat} disabled={!canEditIds} onChange={set('vat')} /></div>
      </div>
      <label className="check"><input type="checkbox" checked={f.debits} onChange={(e) => setF((x) => ({ ...x, debits: e.target.checked }))} /> {t('Option pour le paiement de la TVA d’après les débits')}</label>
      <div className="field"><label htmlFor={`eu-${company.id}`}>{t('Adresse de l’API de votre plateforme agréée')}</label><input id={`eu-${company.id}`} type="url" placeholder="https://api.ma-plateforme.fr" value={f.url} onChange={set('url')} /></div>
      <div className="field">
        <label htmlFor={`et-${company.id}`}>{t('Jeton d’accès (fourni par la plateforme)')}</label>
        <input id={`et-${company.id}`} type="password" autoComplete="off" placeholder={company.einvoiceTokenSet ? t('Enregistré : laissez vide pour le garder') : ''} value={f.token} onChange={set('token')} />
      </div>
      <label className="check"><input type="checkbox" checked={f.auto} onChange={(e) => setF((x) => ({ ...x, auto: e.target.checked }))} /> {t('Envoyer automatiquement à la plateforme les factures émises pour des entreprises')}</label>
      {error && <p className="error">{error}</p>}
      {msg && <p className="success">{msg}</p>}
      <div className="row">
        <button type="submit">{t('Enregistrer')}</button>
        <button type="button" className="secondary" disabled={!f.url.trim() || (!f.token.trim() && !company.einvoiceTokenSet)} onClick={() => void test()}>{t('Tester la connexion')}</button>
        <button type="button" className="secondary" onClick={() => setOpen(false)}>{t('Fermer')}</button>
      </div>
    </form>
  );
}

function CompanyForm({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({ name: '', countryCode: 'FR', currency: 'EUR', locale: 'fr-FR', timezone: 'Europe/Paris', documentPrefix: '', legalMentions: '' });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api('/org/companies', { method: 'POST', body: f });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{t('Nouvelle société')}</h2>
      <div className="row">
        <div className="field grow"><label htmlFor="co-name">{t('Nom')}</label><input id="co-name" value={f.name} onChange={set('name')} required /></div>
        <div className="field" style={{ width: 110 }}><label htmlFor="co-prefix">{t('Préfixe')}</label><input id="co-prefix" value={f.documentPrefix} onChange={set('documentPrefix')} maxLength={8} required /></div>
      </div>
      <div className="row">
        <div className="field"><label htmlFor="co-country">{t('Pays (ISO)')}</label><input id="co-country" value={f.countryCode} onChange={set('countryCode')} maxLength={2} required /></div>
        <div className="field"><label htmlFor="co-cur">{t('Devise')}</label><input id="co-cur" value={f.currency} onChange={set('currency')} maxLength={3} required /></div>
        <div className="field"><label htmlFor="co-loc">{t('Langue des documents')}</label><input id="co-loc" value={f.locale} onChange={set('locale')} required /></div>
        <div className="field grow"><label htmlFor="co-tz">{t('Fuseau horaire')}</label><input id="co-tz" value={f.timezone} onChange={set('timezone')} required /></div>
      </div>
      <div className="field"><label htmlFor="co-legal">{t('Mentions légales (pied des documents)')}</label><input id="co-legal" value={f.legalMentions} onChange={set('legalMentions')} /></div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Créer la société')}</button><button type="button" className="secondary" onClick={() => onDone()}>{t('Annuler')}</button></div>
    </form>
  );
}

function AgencyForm({ companyId, onDone }: { companyId: string; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: '', code: '', city: '' });
  const [error, setError] = useState<string | null>(null);
  if (!open) return <button type="button" className="ghost" onClick={() => setOpen(true)}>{t('Ajouter une agence')}</button>;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api(`/org/companies/${companyId}/agencies`, { method: 'POST', body: f });
      setOpen(false);
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="stack" onSubmit={submit}>
      <div className="row">
        <div className="field grow"><label htmlFor={`a-name-${companyId}`}>{t('Nom')}</label><input id={`a-name-${companyId}`} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required /></div>
        <div className="field" style={{ width: 110 }}><label htmlFor={`a-code-${companyId}`}>{t('Code')}</label><input id={`a-code-${companyId}`} value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} required /></div>
      </div>
      <div className="field"><label htmlFor={`a-city-${companyId}`}>{t('Ville')}</label><input id={`a-city-${companyId}`} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} /></div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Ajouter')}</button><button type="button" className="secondary" onClick={() => setOpen(false)}>{t('Annuler')}</button></div>
    </form>
  );
}

function UsersSection() {
  const { company, agency, has } = useAuth();
  const [adding, setAdding] = useState(false);
  // Invitation affichée : celle du compte qu'on vient de créer sans mot de passe, ou demandée sur une ligne
  const [inviting, setInviting] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const { data, error, reload } = useLoad(
    () => api<UserRow[]>(`/users${qs({ companyId: company?.id, agencyId: agency?.id })}`),
    [company?.id, agency?.id],
  );
  const scopeName = (r: UserRow['roles'][number]) =>
    r.agencyId ? company?.agencies.find((a) => a.id === r.agencyId)?.name ?? t('Agence') : company?.name ?? '';

  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Comptes')} · {company?.name}{agency ? ` · ${agency.name}` : ''}</h2>
        {has('user.write') && !adding && <button type="button" className="secondary" onClick={() => setAdding(true)}>{t('Nouveau compte')}</button>}
      </div>
      {adding && <UserForm onDone={(invite) => { setAdding(false); if (invite) setInviting(invite); void reload(); }} />}
      {inviting && <InvitePanel userId={inviting} onClose={() => setInviting(null)} />}
      {editing && <UserEditor userId={editing} onDone={() => void reload()} key={editing} />}
      {error && <p className="error">{error}</p>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>{t('Nom')}</th><th>{t('E-mail')}</th><th>{t('Rôles')}</th><th>{t('Compétences')}</th><th>{t('Langue')}</th><th /></tr></thead>
          <tbody>
            {(data ?? []).map((u) => (
              <tr key={u.id} className={u.active ? '' : 'user-blocked'}>
                <td><strong>{u.firstName} {u.lastName}</strong>{!u.active && <> <span className="badge danger">{t('Bloqué')}</span></>}</td>
                <td>{u.email}</td>
                <td className="small">{u.roles.map((r) => `${tl(ROLE_LABELS, r.role)} (${scopeName(r)})`).join(', ')}</td>
                <td className="small">{u.skills.join(', ') || '—'}</td>
                <td className="small">{u.locale ? UI_LOCALE_LABELS[UI_LOCALES.find((l) => l.slice(0, 2) === u.locale!.slice(0, 2)) ?? 'fr-FR'] : '—'}</td>
                <td className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                  <button type="button" className="ghost small" onClick={() => { setInviting(null); setEditing(editing === u.id ? null : u.id); }}>{has('user.write') ? t('Modifier') : t('Voir')}</button>
                  {has('user.write') && u.active && (
                    <button type="button" className="ghost small" onClick={() => { setEditing(null); setInviting(u.id); }} title={t('Envoyer un lien pour installer l’appli et choisir son mot de passe')}>{t('Inviter')}</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

/** Nouveau compte ; sans mot de passe, la personne le choisira avec son lien d'invitation (ouvert ensuite) */
function UserForm({ onDone }: { onDone: (inviteUserId?: string) => void }) {
  const { company, agency } = useAuth();
  const defaultLocale = UI_LOCALES.find((l) => l.slice(0, 2) === company?.locale.slice(0, 2)) ?? 'fr-FR';
  const [f, setF] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '', skills: '', role: 'TECHNICIAN' as Role, agencyId: agency?.id ?? '', locale: defaultLocale as string });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const created = await api<{ id: string }>('/users', {
        method: 'POST',
        body: {
          firstName: f.firstName, lastName: f.lastName, email: f.email, phone: f.phone || undefined, password: f.password || undefined,
          locale: f.locale,
          skills: f.skills.split(',').map((s) => s.trim()).filter(Boolean),
          assignments: [{ role: f.role, companyId: company?.id ?? null, agencyId: f.agencyId || null }],
        },
      });
      onDone(f.password ? undefined : created.id);
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="stack" onSubmit={submit} style={{ borderTop: '1px solid var(--ground-2)', paddingTop: 12 }}>
      <div className="row">
        <div className="field grow"><label htmlFor="u-first">{t('Prénom')}</label><input id="u-first" value={f.firstName} onChange={set('firstName')} required /></div>
        <div className="field grow"><label htmlFor="u-last">{t('Nom')}</label><input id="u-last" value={f.lastName} onChange={set('lastName')} required /></div>
      </div>
      <div className="row">
        <div className="field grow"><label htmlFor="u-email">{t('E-mail')}</label><input id="u-email" type="email" value={f.email} onChange={set('email')} required /></div>
        <div className="field grow"><label htmlFor="u-phone">{t('Téléphone (pour WhatsApp)')}</label><input id="u-phone" type="tel" value={f.phone} onChange={set('phone')} /></div>
      </div>
      <div className="field">
        <label htmlFor="u-pass">{t('Mot de passe provisoire (facultatif)')}</label>
        <input id="u-pass" type="text" minLength={8} value={f.password} onChange={set('password')} />
        <p className="small muted">{t('Laissé vide : un lien d’invitation s’affiche après la création, à envoyer par WhatsApp, e-mail ou QR code. La personne choisit elle-même son mot de passe.')}</p>
      </div>
      <div className="row">
        <div className="field grow">
          <label htmlFor="u-role">{t('Rôle')}</label>
          <select id="u-role" value={f.role} onChange={set('role')}>
            {ROLES.filter((r) => r !== 'GROUP_ADMIN').map((r) => <option key={r} value={r}>{tl(ROLE_LABELS, r)}</option>)}
          </select>
        </div>
        <div className="field grow">
          <label htmlFor="u-agency">{t('Périmètre')}</label>
          <select id="u-agency" value={f.agencyId} onChange={set('agencyId')}>
            <option value="">{t('Toute la société {name}', { name: company?.name ?? '' })}</option>
            {company?.agencies.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>
        <div className="field grow"><label htmlFor="u-skills">{t('Compétences (séparées par des virgules)')}</label><input id="u-skills" value={f.skills} onChange={set('skills')} /></div>
        <div className="field">
          <label htmlFor="u-locale">{t('Langue')}</label>
          <select id="u-locale" value={f.locale} onChange={set('locale')}>
            {UI_LOCALES.map((l) => <option key={l} value={l}>{UI_LOCALE_LABELS[l]}</option>)}
          </select>
        </div>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Créer le compte')}</button><button type="button" className="secondary" onClick={() => onDone()}>{t('Annuler')}</button></div>
    </form>
  );
}
