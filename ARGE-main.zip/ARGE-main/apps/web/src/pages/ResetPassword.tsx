import { useState, type FormEvent } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../auth';
import { t } from '../i18n';
import { PRODUCT_NAME } from '../edition';

/** Page ouverte depuis le lien « mot de passe oublié » reçu par e-mail */
export function ResetPasswordPage() {
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const navigate = useNavigate();
  const { me, logout } = useAuth();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      setError(t('Les deux mots de passe ne sont pas identiques'));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api('/auth/reset', { method: 'POST', body: { token, password } });
      // Les sessions ouvertes avant sont fermées par le serveur : on repart de la connexion
      if (me) logout();
      setDone(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const toLogin = () => navigate('/', { replace: true });

  if (!token || done) {
    return (
      <div className="login">
        <div className="card">
          <h1>{PRODUCT_NAME}</h1>
          {done
            ? <p className="success" role="status">{t('Votre mot de passe a été changé. Vous pouvez vous connecter.')}</p>
            : <p className="error" role="alert">{t("Ce lien est incomplet. Recopiez-le en entier depuis l'e-mail, ou demandez-en un nouveau.")}</p>}
          <button type="button" className="big" onClick={toLogin}>{t('Aller à la connexion')}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        <h1>{t('Nouveau mot de passe')}</h1>
        <p className="muted">{t('Au moins 8 caractères. Toutes vos sessions ouvertes seront fermées.')}</p>
        <div className="field">
          <label htmlFor="new-password">{t('Nouveau mot de passe')}</label>
          <input id="new-password" type="password" autoComplete="new-password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="confirm-password">{t('Confirmer le mot de passe')}</label>
          <input id="confirm-password" type="password" autoComplete="new-password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
        </div>
        {error && <p className="error" role="alert">{error}</p>}
        <button type="submit" className="big" disabled={busy}>{busy ? t('Enregistrement…') : t('Enregistrer le mot de passe')}</button>
        <button type="button" className="ghost" onClick={toLogin}>{t('Retour à la connexion')}</button>
      </form>
    </div>
  );
}
