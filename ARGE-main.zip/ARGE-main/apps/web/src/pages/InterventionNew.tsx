import { TemplateSelect } from '../components/TemplateSelect';
import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  INTERVENTION_KINDS, PRIORITIES, PRIORITY_LABELS, type InterventionKind, type Priority,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import type { Client, ClientDetail, UserRow } from '../types';
import { kindLabel, t, tl } from '../i18n';
import { hasFeature } from '../edition';

const SOURCES = ['Appel client', 'E-mail', 'Portail client', 'Contrat', 'Devis signé', 'Interne'];

export function InterventionNewPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [agencyId, setAgencyId] = useState(agency?.id ?? company?.agencies[0]?.id ?? '');
  const [search, setSearch] = useState('');
  const [clients, setClients] = useState<Client[]>([]);
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [siteId, setSiteId] = useState('');
  const [equipmentId, setEquipmentId] = useState('');
  const [kind, setKind] = useState<InterventionKind>('SAV');
  const [priority, setPriority] = useState<Priority>('NORMAL');
  const [source, setSource] = useState(SOURCES[0]);
  const [reason, setReason] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [techs, setTechs] = useState<UserRow[]>([]);
  const [technicianId, setTechnicianId] = useState('');
  const [start, setStart] = useState('');
  const [hours, setHours] = useState('1');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Recherche de clients
  useEffect(() => {
    if (!company) return;
    const timer = setTimeout(() => {
      api<Client[]>(`/clients${qs({ companyId: company.id, agencyId, q: search, limit: 20 })}`)
        .then(setClients)
        .catch(() => setClients([]));
    }, 250);
    return () => clearTimeout(timer);
  }, [company?.id, agencyId, search]);

  // Techniciens de l'agence
  useEffect(() => {
    if (!company || !agencyId || !has('intervention.assign')) return;
    api<UserRow[]>(`/users${qs({ companyId: company.id, agencyId, role: 'TECHNICIAN' })}`).then(setTechs).catch(() => setTechs([]));
  }, [company?.id, agencyId]);

  const pickClient = async (id: string) => {
    const detail = await api<ClientDetail>(`/clients/${id}`);
    setClient(detail);
    setSiteId(detail.sites[0]?.id ?? '');
    setEquipmentId('');
  };

  const site = client?.sites.find((s) => s.id === siteId);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!company || !client) return;
    setBusy(true);
    setError(null);
    try {
      const s = start ? new Date(start) : null;
      const created = await api<{ id: string }>('/interventions', {
        method: 'POST',
        body: {
          companyId: company.id, agencyId, clientId: client.id, siteId, equipmentId: equipmentId || null,
          kind, priority, source, reason, templateId: templateId || null, dueDate: dueDate || null,
          technicianId: technicianId || null,
          scheduledStart: s ? s.toISOString() : null,
          scheduledEnd: s ? new Date(s.getTime() + Number(hours) * 3600_000).toISOString() : null,
        },
      });
      navigate(`/interventions/${created.id}`);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (!company) return null;

  return (
    <form onSubmit={submit} className="stack" style={{ maxWidth: 860 }}>
      <div>
        <div className="eyebrow">{company.name}</div>
        <h1>{t('Nouvelle intervention')}</h1>
      </div>

      <section className="card stack">
        <h2>{t('Client')}</h2>
        <div className="field">
          <label htmlFor="agency">{t('Agence')}</label>
          <select id="agency" value={agencyId} onChange={(e) => setAgencyId(e.target.value)} required>
            {company.agencies.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>
        {!client ? (
          <>
            <div className="field">
              <label htmlFor="search">{t('Rechercher un client')}</label>
              <input id="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t('Nom, ville ou e-mail')} />
            </div>
            <div className="stack" style={{ gap: 6 }}>
              {clients.map((c) => (
                <button key={c.id} type="button" className="secondary" style={{ justifyContent: 'space-between' }} onClick={() => void pickClient(c.id)}>
                  <span>{c.name}</span><span className="small muted">{c.city}</span>
                </button>
              ))}
              {!clients.length && <p className="small muted">{t('Aucun client trouvé. Créez-le depuis « Clients et sites ».')}</p>}
            </div>
          </>
        ) : (
          <>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <strong>{client.name}</strong>
              <button type="button" className="ghost" onClick={() => setClient(null)}>{t('Changer')}</button>
            </div>
            <div className="row">
              <div className="field grow">
                <label htmlFor="site">{t('Site')}</label>
                <select id="site" value={siteId} onChange={(e) => { setSiteId(e.target.value); setEquipmentId(''); }} required>
                  {client.sites.map((s) => <option key={s.id} value={s.id}>{s.name} · {s.city}</option>)}
                </select>
              </div>
              <div className="field grow">
                <label htmlFor="equipment">{t('Équipement')}</label>
                <select id="equipment" value={equipmentId} onChange={(e) => setEquipmentId(e.target.value)}>
                  <option value="">{t('Non précisé')}</option>
                  {site?.equipments.map((eq) => (
                    <option key={eq.id} value={eq.id}>{eq.category} {eq.brand ?? ''} {eq.model ?? ''}{eq.location ? ` · ${eq.location}` : ''}</option>
                  ))}
                </select>
              </div>
            </div>
          </>
        )}
      </section>

      <section className="card stack">
        <h2>{t('Demande')}</h2>
        <div className="row">
          <div className="field grow">
            <label htmlFor="kind">{t('Type')}</label>
            <select id="kind" value={kind} onChange={(e) => setKind(e.target.value as InterventionKind)}>
              {INTERVENTION_KINDS.map((k) => <option key={k} value={k}>{kindLabel(k)}</option>)}
            </select>
          </div>
          <div className="field grow">
            <label htmlFor="priority">{t('Priorité')}</label>
            <select id="priority" value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>
              {PRIORITIES.map((p) => <option key={p} value={p}>{tl(PRIORITY_LABELS, p)}</option>)}
            </select>
          </div>
          <div className="field grow">
            <label htmlFor="source">{t('Origine')}</label>
            <select id="source" value={source} onChange={(e) => setSource(e.target.value)}>
              {SOURCES.map((s) => <option key={s} value={s}>{t(s)}</option>)}
            </select>
          </div>
        </div>
        <div className="field">
          <label htmlFor="tpl">{t('Document à remplir')}</label>
          <TemplateSelect id="tpl" companyId={company?.id} value={templateId} onChange={setTemplateId} />
        </div>
        {hasFeature('deadlines') && (
          <div className="field" style={{ maxWidth: 260 }}>
            <label htmlFor="due">{t('Date limite de remise du rapport')}</label>
            <input id="due" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
        )}
        <div className="field">
          <label htmlFor="reason">{t('Motif')}</label>
          <textarea id="reason" value={reason} onChange={(e) => setReason(e.target.value)} required placeholder={t('Ce que le client a signalé, ou ce qui est à installer')} />
        </div>
      </section>

      {has('intervention.assign') && (
        <section className="card stack">
          <h2>{t('Planification')} <span className="small muted">{t('(facultatif)')}</span></h2>
          <div className="row">
            <div className="field grow">
              <label htmlFor="tech">{t('Technicien')}</label>
              <select id="tech" value={technicianId} onChange={(e) => setTechnicianId(e.target.value)}>
                <option value="">{t('À planifier plus tard')}</option>
                {techs.map((u) => <option key={u.id} value={u.id}>{u.firstName} {u.lastName}</option>)}
              </select>
            </div>
            <div className="field grow">
              <label htmlFor="start">{t('Début')}</label>
              <input id="start" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div className="field" style={{ width: 110 }}>
              <label htmlFor="hours">{t('Durée (h)')}</label>
              <input id="hours" type="number" min="0.25" step="0.25" value={hours} onChange={(e) => setHours(e.target.value)} />
            </div>
          </div>
        </section>
      )}

      {error && <p className="error" role="alert">{error}</p>}
      <div className="row">
        <button type="submit" className="accent" disabled={busy || !client || !siteId || !reason}>{t("Créer l'intervention")}</button>
        <button type="button" className="secondary" onClick={() => navigate(-1)}>{t('Annuler')}</button>
      </div>
    </form>
  );
}
