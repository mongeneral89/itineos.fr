import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { SLIP_STATUS_LABELS, STOCK_LOCATION_KIND_LABELS } from '@itineo/shared';
import { api, openPdf, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { fmtDateTime } from '../format';
import type { InterventionRow, SlipDetail, StockLevel, StockLocation } from '../types';
import { t, tl, uiLocale } from '../i18n';

interface Line { key: number; articleId: string; qty: string }
let k = 0;

/** Bon de sortie : du matériel quitte un dépôt vers un véhicule ou un chantier */
export function SlipEditPage() {
  const { id = 'new' } = useParams();
  const isNew = id === 'new';
  const navigate = useNavigate();
  const { company, agency, has } = useAuth();
  const [slip, setSlip] = useState<SlipDetail | null>(null);
  const [fromId, setFromId] = useState('');
  const [destKind, setDestKind] = useState<'location' | 'intervention'>('location');
  const [toId, setToId] = useState('');
  const [interventionId, setInterventionId] = useState('');
  const [notes, setNotes] = useState('');
  const [lines, setLines] = useState<Line[]>([{ key: ++k, articleId: '', qty: '1' }]);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const { data: locations } = useLoad(
    () => (company ? api<StockLocation[]>(`/stock/locations${qs({ companyId: company.id, agencyId: agency?.id })}`) : Promise.resolve([])),
    [company?.id, agency?.id],
  );
  const { data: interventions } = useLoad(
    () => (company ? api<InterventionRow[]>(`/interventions${qs({ companyId: company.id, agencyId: agency?.id, status: 'TO_PLAN,PLANNED,EN_ROUTE,ON_SITE', limit: 200 })}`) : Promise.resolve([])),
    [company?.id, agency?.id],
  );
  // Ce que contient le lieu de départ : seuls ces articles peuvent sortir
  const { data: available } = useLoad(
    () => (fromId ? api<StockLevel[]>(`/stock/levels${qs({ locationId: fromId })}`) : Promise.resolve([])),
    [fromId],
  );

  const show = (s: SlipDetail) => {
    setSlip(s);
    setFromId(s.fromLocationId);
    setDestKind(s.interventionId ? 'intervention' : 'location');
    setToId(s.toLocationId ?? '');
    setInterventionId(s.interventionId ?? '');
    setNotes(s.notes ?? '');
    setLines(s.lines.map((l) => ({ key: ++k, articleId: l.articleId, qty: String(l.quantity).replace('.', ',') })));
  };

  useEffect(() => {
    if (!isNew) api<SlipDetail>(`/stock/slips/${id}`).then(show).catch((e) => setError((e as Error).message));
  }, [id, isNew]);
  useEffect(() => {
    if (isNew && !fromId && locations?.length) setFromId(locations.find((l) => l.kind === 'DEPOT')?.id ?? locations[0].id);
  }, [isNew, fromId, locations]);

  if (!isNew && slip?.id !== id) return error ? <p className="error">{error}</p> : <p className="muted">{t('Chargement…')}</p>;
  const editable = has('stock.write') && (isNew || slip?.status === 'DRAFT');

  const payload = () => {
    const parsed = lines.filter((l) => l.articleId).map((l) => ({ articleId: l.articleId, quantity: Number(l.qty.replace(',', '.')) }));
    if (parsed.some((l) => !(l.quantity > 0))) throw new Error(t('Quantité invalide sur une ligne'));
    return {
      fromLocationId: fromId,
      toLocationId: destKind === 'location' ? toId || null : null,
      interventionId: destKind === 'intervention' ? interventionId || null : null,
      notes: notes.trim() || null,
      lines: parsed,
    };
  };
  const run = async (fn: () => Promise<void>, ok?: string) => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      await fn();
      if (ok) setMsg(ok);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const save = () => run(async () => {
    if (isNew) {
      const created = await api<SlipDetail>('/stock/slips', { method: 'POST', body: payload() });
      navigate(`/stock/slips/${created.id}`, { replace: true });
    } else show(await api<SlipDetail>(`/stock/slips/${id}`, { method: 'PUT', body: payload() }));
  }, t('Brouillon enregistré.'));
  const validate = () => run(async () => {
    await api(`/stock/slips/${id}`, { method: 'PUT', body: payload() });
    show(await api<SlipDetail>(`/stock/slips/${id}/validate`, { method: 'POST' }));
  }, t('Bon validé : le stock a été déplacé.'));

  const level = (articleId: string) => available?.find((a) => a.articleId === articleId);

  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="topbar">
        <div>
          <div className="eyebrow"><Link to="/stock">{t('Stock')}</Link></div>
          <h1>{isNew ? t('Nouveau bon de sortie') : t('Bon de sortie {num}', { num: slip?.number ?? t('(brouillon)') })}</h1>
        </div>
        {slip && <span className={`badge ${slip.status === 'VALIDATED' ? 'ok' : 'neutral'}`}>{tl(SLIP_STATUS_LABELS, slip.status)}</span>}
      </div>
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error" role="alert">{error}</p>}
      {slip?.validatedAt && <p className="small">{t('Validé le {date}.', { date: fmtDateTime(slip.validatedAt, company?.timezone) })}</p>}

      <section className="card stack">
        <div className="row">
          <div className="field grow"><label htmlFor="s-from">{t('Sortie de')}</label>
            <select id="s-from" value={fromId} disabled={!editable} onChange={(e) => setFromId(e.target.value)}>
              {locations?.map((l) => <option key={l.id} value={l.id}>{tl(STOCK_LOCATION_KIND_LABELS, l.kind)} · {l.name}</option>)}
            </select>
          </div>
          <div className="field"><label htmlFor="s-dest">{t('Vers')}</label>
            <select id="s-dest" value={destKind} disabled={!editable} onChange={(e) => setDestKind(e.target.value as 'location' | 'intervention')}>
              <option value="location">{t('Un véhicule ou un dépôt')}</option>
              <option value="intervention">{t('Un chantier (intervention)')}</option>
            </select>
          </div>
          {destKind === 'location' ? (
            <div className="field grow"><label htmlFor="s-to">{t('Destination')}</label>
              <select id="s-to" value={toId} disabled={!editable} onChange={(e) => setToId(e.target.value)}>
                <option value="">{t('— Choisir —')}</option>
                {locations?.filter((l) => l.id !== fromId).map((l) => <option key={l.id} value={l.id}>{tl(STOCK_LOCATION_KIND_LABELS, l.kind)} · {l.name}</option>)}
              </select>
            </div>
          ) : (
            <div className="field grow"><label htmlFor="s-iv">{t('Intervention')}</label>
              <select id="s-iv" value={interventionId} disabled={!editable} onChange={(e) => setInterventionId(e.target.value)}>
                <option value="">{t('— Choisir —')}</option>
                {slip?.intervention && !interventions?.some((i) => i.id === slip.intervention!.id) && (
                  <option value={slip.intervention.id}>{slip.intervention.number} · {slip.intervention.clientName}</option>
                )}
                {interventions?.map((i) => <option key={i.id} value={i.id}>{i.number} · {i.clientName} · {i.reason}</option>)}
              </select>
            </div>
          )}
        </div>
      </section>

      <section className="card stack">
        <h2>{t('Articles')}</h2>
        <div className="table-wrap">
          <table className="lines">
            <thead><tr><th>{t('Article')}</th><th style={{ width: 130 }}>{t('Disponible')}</th><th style={{ width: 110 }}>{t('Quantité')}</th>{editable && <th style={{ width: 40 }} />}</tr></thead>
            <tbody>
              {lines.map((l, i) => {
                const lv = level(l.articleId);
                const want = Number(l.qty.replace(',', '.'));
                const short = !!lv && want > lv.quantity;
                return (
                  <tr key={l.key}>
                    <td>
                      {editable ? (
                        <select aria-label={t('Article ligne {n}', { n: i + 1 })} value={l.articleId} onChange={(e) => setLines(lines.map((x) => (x.key === l.key ? { ...x, articleId: e.target.value } : x)))}>
                          <option value="">{t('— Choisir —')}</option>
                          {available?.filter((a) => a.quantity > 0 || a.articleId === l.articleId).map((a) => <option key={a.articleId} value={a.articleId}>{a.reference} – {a.name}</option>)}
                        </select>
                      ) : <>{slip?.lines[i]?.reference} – {slip?.lines[i]?.name}</>}
                    </td>
                    <td className="small">{lv ? `${new Intl.NumberFormat(uiLocale()).format(lv.quantity)} ${lv.unit}` : '—'}</td>
                    <td><input aria-label={t('Quantité ligne {n}', { n: i + 1 })} inputMode="decimal" value={l.qty} disabled={!editable} aria-invalid={short}
                      onChange={(e) => setLines(lines.map((x) => (x.key === l.key ? { ...x, qty: e.target.value } : x)))} /></td>
                    {editable && <td><button type="button" className="ghost" aria-label={t('Supprimer la ligne {n}', { n: i + 1 })} onClick={() => setLines(lines.filter((x) => x.key !== l.key))}>✕</button></td>}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {editable && <div><button type="button" className="secondary" onClick={() => setLines([...lines, { key: ++k, articleId: '', qty: '1' }])}>{t('+ Ajouter un article')}</button></div>}
        <div className="field"><label htmlFor="s-notes">{t('Observations')}</label>
          <textarea id="s-notes" rows={2} value={notes} disabled={!editable} onChange={(e) => setNotes(e.target.value)} />
        </div>
      </section>

      <div className="row" style={{ gap: 8 }}>
        {editable && <button type="button" disabled={busy || !fromId} onClick={() => void save()}>{isNew ? t('Créer le brouillon') : t('Enregistrer')}</button>}
        {editable && !isNew && <button type="button" className="accent" disabled={busy} onClick={() => void validate()}>{t('Valider la sortie')}</button>}
        {editable && !isNew && <button type="button" className="ghost" disabled={busy} onClick={() => void run(async () => show(await api<SlipDetail>(`/stock/slips/${id}/cancel`, { method: 'POST' })), t('Bon annulé.'))}>{t('Annuler le bon')}</button>}
        {slip && <button type="button" className="secondary" onClick={() => openPdf(`/stock/slips/${slip.id}/pdf`).catch((e) => setError(e.message))}>{slip.status === 'VALIDATED' ? t('PDF à signer') : t('Aperçu PDF')}</button>}
      </div>
    </div>
  );
}
