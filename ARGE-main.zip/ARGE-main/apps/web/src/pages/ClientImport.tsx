/**
 * Import de clients, sites et matériels depuis un fichier CSV ou Excel : aperçu (colonnes reconnues,
 * ce qui sera créé, lignes à vérifier), puis enregistrement. Le serveur fait tout le travail
 * (voir apps/api/src/services/client-import.ts) ; cet écran envoie le fichier et la correspondance des colonnes.
 */
import { useState } from 'react';
import {
  CLIENT_IMPORT_FIELD_LABELS, CLIENT_IMPORT_FIELDS,
  type ClientImportField, type ClientImportIssue, type ClientImportPreview,
} from '@itineo/shared';
import { api, downloadFile } from '../api';
import { useAuth } from '../auth';
import { MAX_FILE_BYTES } from '../files';
import { t, tServer } from '../i18n';

interface ImportResult { clientsNew: number; clientsUpdated: number; sitesNew: number; equipmentsNew: number; contactsNew: number }

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(new Error(t('Ce fichier ne peut pas être lu')));
    r.readAsDataURL(file);
  });
}

function issueText(i: ClientImportIssue): string {
  const v = { line: i.line, value: i.value ?? '' };
  switch (i.code) {
    case 'missingName': return t('Ligne {line} : pas de nom de client, ligne ignorée', v);
    case 'badEmail': return t('Ligne {line} : e-mail « {value} » non valide, laissé vide', v);
    case 'badSiren': return t('Ligne {line} : SIREN ou SIRET « {value} » non valide, laissé vide', v);
    case 'badDate': return t('Ligne {line} : date « {value} » non reconnue, laissée vide', v);
    case 'otherSubscriber': return t('Ligne {line} : autre n° d’abonné ({value}) pour ce client, noté sur son site', v);
    case 'duplicateEquipment': return t('Ligne {line} : matériel « {value} » en double dans le fichier, gardé une seule fois', v);
    case 'tooManyRows': return t('Fichier trop long : {value} lignes au plus', v);
  }
}

export function ClientImport({ onClose, onImported }: { onClose: () => void; onImported: () => void }) {
  const { company, agency } = useAuth();
  const [file, setFile] = useState<{ name: string; dataUrl: string } | null>(null);
  const [shared, setShared] = useState(!agency);
  const [mapping, setMapping] = useState<(ClientImportField | null)[] | null>(null);
  const [preview, setPreview] = useState<ClientImportPreview | null>(null);
  const [busy, setBusy] = useState<'reading' | 'importing' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);

  const agencyId = shared ? null : agency?.id ?? null;

  const runPreview = async (f: { dataUrl: string }, m: (ClientImportField | null)[] | null, agencyChoice = agencyId) => {
    if (!company) return;
    setBusy('reading');
    setError(null);
    try {
      const p = await api<ClientImportPreview>('/clients/import/preview', {
        method: 'POST',
        body: { companyId: company.id, agencyId: agencyChoice, file: f.dataUrl, mapping: m ?? undefined },
      });
      setPreview(p);
      setMapping(p.columns.map((c) => c.field));
    } catch (err) {
      setPreview(null);
      setError(tServer((err as Error).message));
    } finally {
      setBusy(null);
    }
  };

  const choose = async (picked: File | undefined) => {
    setResult(null);
    setPreview(null);
    setMapping(null);
    if (!picked) return;
    if (picked.size > MAX_FILE_BYTES) {
      setError(t('Fichier trop lourd : 10 Mo au maximum'));
      return;
    }
    try {
      const f = { name: picked.name, dataUrl: await readAsDataUrl(picked) };
      setFile(f);
      await runPreview(f, null);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  const changeColumn = (index: number, field: ClientImportField | null) => {
    if (!mapping || !file) return;
    // Une colonne Itinéos ne peut venir que d'une colonne du fichier
    const next = mapping.map((f, i) => (i === index ? field : f === field ? null : f));
    setMapping(next);
    void runPreview(file, next);
  };

  const submit = async () => {
    if (!company || !file || !mapping) return;
    setBusy('importing');
    setError(null);
    try {
      const r = await api<ImportResult>('/clients/import', {
        method: 'POST',
        body: { companyId: company.id, agencyId, file: file.dataUrl, mapping },
      });
      setResult(r);
      setPreview(null);
      setFile(null);
      onImported();
    } catch (err) {
      setError(tServer((err as Error).message));
    } finally {
      setBusy(null);
    }
  };

  const nothingNew = preview && !preview.clientsNew && !preview.sitesNew && !preview.equipmentsNew && !preview.contactsNew;
  const blocked = preview?.issues.some((i) => i.code === 'tooManyRows');

  return (
    <section className="card stack">
      <h2>{t('Importer des clients')}</h2>
      <p className="small muted">
        {t('Un fichier CSV ou Excel (.xlsx), une ligne par matériel : les lignes d’un même client sont regroupées, puis celles d’un même site. Les clients et matériels déjà présents ne sont pas recréés.')}
      </p>
      <div className="row">
        <div className="field grow">
          <label htmlFor="imp-file">{t('Fichier')}</label>
          <input id="imp-file" type="file" accept=".csv,.txt,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={(e) => void choose(e.target.files?.[0])} />
        </div>
        <button type="button" className="secondary" onClick={() => downloadFile('/clients/import/template', 'modele-import-clients.csv').catch((e) => setError((e as Error).message))}>
          {t('Télécharger le modèle à remplir')}
        </button>
      </div>
      {agency && (
        <label className="check">
          <input
            type="checkbox"
            checked={shared}
            onChange={(e) => {
              setShared(e.target.checked);
              if (file) void runPreview(file, mapping, e.target.checked ? null : agency.id);
            }}
          />
          {t('Clients partagés par toutes les agences de {name}', { name: company?.name ?? '' })}
        </label>
      )}

      {busy === 'reading' && <p className="muted">{t('Lecture du fichier…')}</p>}
      {error && <p className="error">{error}</p>}
      {result && (
        <p className="badge ok" role="status">
          {t('Import terminé : {clients} clients créés, {sites} sites et {equipments} matériels ajoutés.', { clients: result.clientsNew, sites: result.sitesNew, equipments: result.equipmentsNew })}
        </p>
      )}

      {preview && mapping && (
        <>
          <h3>{t('Colonnes du fichier')}</h3>
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Colonne du fichier')}</th><th>{t('Devient')}</th></tr></thead>
              <tbody>
                {preview.columns.map((c, i) => (
                  <tr key={i}>
                    <td>{c.header || '—'}</td>
                    <td>
                      <select value={mapping[i] ?? ''} aria-label={t('Devient')} onChange={(e) => changeColumn(i, (e.target.value || null) as ClientImportField | null)}>
                        <option value="">{t('Ignorée')}</option>
                        {CLIENT_IMPORT_FIELDS.map((f) => <option key={f} value={f}>{t(CLIENT_IMPORT_FIELD_LABELS[f])}</option>)}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <h3>{t('Ce qui sera enregistré')}</h3>
          <div className="table-wrap">
            <table>
              <tbody>
                <tr><td>{t('Clients nouveaux')}</td><td><strong>{preview.clientsNew}</strong></td></tr>
                <tr><td>{t('Clients déjà présents (complétés si besoin)')}</td><td>{preview.clientsExisting}</td></tr>
                <tr><td>{t('Sites nouveaux')}</td><td><strong>{preview.sitesNew}</strong></td></tr>
                <tr><td>{t('Matériels nouveaux')}</td><td><strong>{preview.equipmentsNew}</strong></td></tr>
                <tr><td>{t('Matériels déjà présents')}</td><td>{preview.equipmentsExisting}</td></tr>
                <tr><td>{t('Contacts nouveaux')}</td><td>{preview.contactsNew}</td></tr>
                <tr><td>{t('Lignes ignorées')}</td><td>{preview.rowsSkipped}</td></tr>
              </tbody>
            </table>
          </div>

          {preview.issues.length > 0 && (
            <>
              <h3>{t('À vérifier')}</h3>
              <ul className="small">
                {preview.issues.slice(0, 30).map((i, k) => <li key={k}>{issueText(i)}</li>)}
              </ul>
              {preview.issues.length > 30 && <p className="small muted">{t('… et {n} autres lignes à vérifier', { n: preview.issues.length - 30 })}</p>}
            </>
          )}

          {preview.sample.length > 0 && (
            <>
              <h3>{t('Aperçu des premiers clients')}</h3>
              <ul className="small">
                {preview.sample.map((c, k) => (
                  <li key={k}>
                    <strong>{c.name}</strong>
                    {c.existing && <> <span className="badge neutral">{t('déjà présent')}</span></>}
                    {c.subscriberNumber && <> · {t('Abonné n° {n}', { n: c.subscriberNumber })}</>}
                    <ul>
                      {c.sites.map((s, j) => (
                        <li key={j}>
                          {s.name}{s.city ? ` (${s.city})` : ''}
                          {s.equipments.length > 0 && <ul>{s.equipments.map((e, n) => <li key={n}>{e}</li>)}</ul>}
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            </>
          )}

          {nothingNew && <p className="muted">{t('Rien de nouveau à importer.')}</p>}
        </>
      )}

      <div className="row">
        {preview && !nothingNew && !blocked && (
          <button type="button" className="accent" disabled={busy !== null} onClick={() => void submit()}>
            {busy === 'importing' ? t('Import en cours…') : t('Importer')}
          </button>
        )}
        <button type="button" className="secondary" onClick={onClose}>{result ? t('Fermer') : t('Annuler')}</button>
      </div>
    </section>
  );
}
