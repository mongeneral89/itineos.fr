import { PlanningVisibility } from '../components/PlanningVisibility';
import { useEffect, useMemo, useRef, useState, type CSSProperties, type DragEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { addDays, PRIORITY_LABELS } from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import type { InterventionRow, UserRow } from '../types';
import { OrgPicker } from '../components/Layout';
import { KindBadge, PriorityBadge, StatusBadge } from '../components/Badges';
import { fmtDay, fmtLongDay, fmtTime, toDateInput } from '../format';
import { PlanForm, techniciansFor } from '../components/PlanForm';
import { CancelIntervention } from '../components/CancelIntervention';
import { kindLabel, t, tl, tp, uiLocale } from '../i18n';
import { FREE_COLOR, liveOf, sameDay, STATE_COLOR, stateLabel, stateOf, STATES, type Live } from '../planning-state';

const START_HOUR = 6;
const END_HOUR = 20;
const SPAN = END_HOUR - START_HOUR;
/** Glisser-déposer : arrondi au quart d'heure */
const SNAP_MIN = 15;

type View = 'day' | 'week' | 'month';
const VIEWS: { id: View; label: string }[] = [
  { id: 'day', label: 'Jour' },
  { id: 'week', label: 'Semaine' },
  { id: 'month', label: 'Mois' },
];
const VIEW_KEY = 'itineo.planning.view';
const TODO_KEY = 'itineo.planning.todo';
const WEEKEND_KEY = 'itineo.planning.weekend';

/** Seules les interventions pas encore commencées se déplacent */
const movable = (iv: InterventionRow) => iv.status === 'PLANNED' || iv.status === 'TO_PLAN' || iv.status === 'TO_RESUME';

function readPref(key: string, fallback: boolean): boolean {
  try {
    const v = localStorage.getItem(key);
    return v === null ? fallback : v === '1';
  } catch {
    return fallback;
  }
}
function writePref(key: string, v: boolean) {
  try {
    localStorage.setItem(key, v ? '1' : '0');
  } catch {
    /* ignoré */
  }
}

/** Lundi de la semaine (00:00) */
function startOfWeek(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
  return x;
}

/** Les jours affichés : un jour, la semaine du lundi au dimanche, ou le mois entier */
function periodDays(view: View, day: Date): Date[] {
  const first = new Date(day);
  first.setHours(0, 0, 0, 0);
  let count = 1;
  if (view === 'week') {
    first.setTime(startOfWeek(day).getTime());
    count = 7;
  } else if (view === 'month') {
    first.setDate(1);
    count = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
  }
  return Array.from({ length: count }, (_, k) => new Date(first.getFullYear(), first.getMonth(), first.getDate() + k));
}

/** Numéro de semaine ISO (lundi = premier jour, semaine 1 = celle du premier jeudi) */
function isoWeek(d: Date): number {
  const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  x.setUTCDate(x.getUTCDate() + 4 - (x.getUTCDay() || 7));
  const year = new Date(Date.UTC(x.getUTCFullYear(), 0, 1));
  return Math.ceil(((x.getTime() - year.getTime()) / 86400_000 + 1) / 7);
}

const endOf = (iv: InterventionRow) => (iv.scheduledEnd ? new Date(iv.scheduledEnd) : new Date(new Date(iv.scheduledStart!).getTime() + 3600_000));
const hoursOf = (jobs: InterventionRow[]) => jobs.reduce((s, iv) => s + Math.max(0, endOf(iv).getTime() - new Date(iv.scheduledStart!).getTime()) / 3600_000, 0);
/** 7,5 → « 7 h 30 » */
function fmtHours(h: number): string {
  const total = Math.round(h * 60);
  const m = total % 60;
  return `${Math.floor(total / 60)} h${m ? ` ${String(m).padStart(2, '0')}` : ''}`;
}
const jobTitle = (iv: InterventionRow) =>
  `${fmtTime(iv.scheduledStart)}–${fmtTime(endOf(iv).toISOString())} · ${iv.number} · ${iv.clientName}${iv.siteCity ? ` (${iv.siteCity})` : ''} · ${kindLabel(iv.kind)} · ${stateLabel(iv)}\n${iv.reason}`;

const isToday = (d: Date) => sameDay(new Date().toISOString(), d);
const isWeekend = (d: Date) => d.getDay() === 0 || d.getDay() === 6;

interface Row { id: string; techId: string | null; label: string; sub: string; jobs: InterventionRow[]; live?: Live | null }
interface Group { id: string; label: string | null; rows: Row[] }

/** Déplacement par glisser-déposer : l'intervention prise, le technicien et l'heure où elle est lâchée */
type DropTo = (iv: InterventionRow, technicianId: string, start: Date) => void;
/** Intervention en cours de glissement (partagée entre le planning et la liste « À planifier ») */
let dragged: InterventionRow | null = null;
const startDrag = (iv: InterventionRow) => (e: DragEvent<HTMLElement>) => {
  dragged = iv;
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', iv.id);
};
const endDrag = () => {
  dragged = null;
};
const durationOf = (iv: InterventionRow) => (iv.scheduledStart ? endOf(iv).getTime() - new Date(iv.scheduledStart).getTime() : 3600_000);

/** Où lâcher : une case qui accepte une intervention glissée (planificateurs seulement) */
function dropProps(enabled: boolean, onDrop: (iv: InterventionRow, e: DragEvent<HTMLElement>) => void) {
  if (!enabled) return {};
  return {
    onDragOver: (e: DragEvent<HTMLElement>) => {
      if (!dragged) return;
      e.preventDefault();
      e.currentTarget.classList.add('plan-over');
    },
    onDragLeave: (e: DragEvent<HTMLElement>) => e.currentTarget.classList.remove('plan-over'),
    onDrop: (e: DragEvent<HTMLElement>) => {
      e.preventDefault();
      e.currentTarget.classList.remove('plan-over');
      const iv = dragged;
      dragged = null;
      if (iv) onDrop(iv, e);
    },
  };
}

export function PlanningPage() {
  const { company, agency, has } = useAuth();
  const [showVisibility, setShowVisibility] = useState(false);
  const [day, setDay] = useState(() => new Date());
  const [view, setViewState] = useState<View>(() => {
    try {
      const v = localStorage.getItem(VIEW_KEY);
      return v === 'week' || v === 'month' ? v : 'day';
    } catch {
      return 'day';
    }
  });
  const [filter, setFilter] = useState('');
  const [showTodo, setShowTodo] = useState(() => readPref(TODO_KEY, true));
  const [weekend, setWeekend] = useState(() => readPref(WEEKEND_KEY, true));
  const [notice, setNotice] = useState<{ text: string; undo?: () => void; warn?: boolean } | null>(null);
  const [selected, setSelected] = useState<InterventionRow | null>(null);
  const navigate = useNavigate();
  const canAssign = has('intervention.assign');

  const setView = (v: View) => {
    setViewState(v);
    try {
      localStorage.setItem(VIEW_KEY, v);
    } catch {
      /* ignoré */
    }
  };
  const toggleTodo = () => setShowTodo((v) => {
    writePref(TODO_KEY, !v);
    return !v;
  });
  const toggleWeekend = () => setWeekend((v) => {
    writePref(WEEKEND_KEY, !v);
    return !v;
  });

  const days = useMemo(() => periodDays(view, day), [view, day]);
  // Semaine sans le samedi et le dimanche si on le demande (les données restent chargées)
  const shownDays = useMemo(() => (view === 'week' && !weekend ? days.filter((d) => !isWeekend(d)) : days), [view, weekend, days]);
  const from = days[0];
  const to = new Date(days[days.length - 1].getFullYear(), days[days.length - 1].getMonth(), days[days.length - 1].getDate() + 1);

  const { data, error, loading, reload } = useLoad(async () => {
    if (!company) return null;
    const scope = { companyId: company.id, agencyId: agency?.id };
    const [techs, planned, todo] = await Promise.all([
      api<UserRow[]>(`/users${qs({ ...scope, role: 'TECHNICIAN' })}`).catch(() => [] as UserRow[]),
      api<InterventionRow[]>(`/interventions${qs({ ...scope, from: from.toISOString(), to: to.toISOString(), limit: 3000 })}`),
      api<InterventionRow[]>(`/interventions${qs({ ...scope, status: 'TO_PLAN,TO_RESUME' })}`),
    ]);
    return { techs: techs.filter((u) => u.active), planned: planned.filter((iv) => iv.scheduledStart && iv.status !== 'CANCELLED'), todo };
  }, [company?.id, agency?.id, from.getTime(), to.getTime()]);

  // L'état des techniciens change toute la journée : le planning se met à jour toutes les minutes
  useEffect(() => {
    const timer = window.setInterval(() => document.visibilityState === 'visible' && reload(), 60_000);
    return () => window.clearInterval(timer);
  }, [reload]);

  const shift = (n: number) => setDay((d) => {
    if (view === 'month') return new Date(d.getFullYear(), d.getMonth() + n, 1, 12);
    const next = new Date(d);
    next.setDate(next.getDate() + n * (view === 'week' ? 7 : 1));
    return next;
  });

  /** Lignes du planning : les techniciens (par agence quand toutes sont affichées), puis les interventions sans technicien */
  const groups = useMemo<Group[]>(() => {
    if (!data || !company) return [];
    const q = filter.trim().toLowerCase();
    const techs = data.techs.filter((u) => !q || `${u.firstName} ${u.lastName} ${u.skills.join(' ')}`.toLowerCase().includes(q));
    const row = (u: UserRow): Row => {
      const jobs = data.planned.filter((iv) => iv.technicianId === u.id);
      return { id: u.id, techId: u.id, label: `${u.firstName} ${u.lastName}`, sub: u.skills.join(' · ') || '—', jobs, live: liveOf(jobs) };
    };
    const homeAgency = (u: UserRow) => u.roles.find((r) => r.role === 'TECHNICIAN' && r.companyId === company.id)?.agencyId ?? null;
    const out: Group[] = agency || company.agencies.length < 2
      ? [{ id: 'all', label: null, rows: techs.map(row) }]
      : [
          ...company.agencies.map((a) => ({ id: a.id, label: a.name, rows: techs.filter((u) => homeAgency(u) === a.id).map(row) })),
          { id: 'none', label: t('Toutes agences'), rows: techs.filter((u) => homeAgency(u) === null).map(row) },
        ].filter((g) => g.rows.length);
    const orphans = data.planned.filter((iv) => !iv.technicianId || !data.techs.some((u) => u.id === iv.technicianId));
    if (orphans.length && !q) out.push({ id: 'orphans', label: null, rows: [{ id: 'orphans', techId: null, label: t('Sans technicien'), sub: t('Planifiées mais pas attribuées'), jobs: orphans }] });
    return out;
  }, [data, company, agency, filter]);

  /** Glisser-déposer : nouveau technicien et nouvelle heure, même durée ; le technicien est prévenu par le serveur */
  const dropTo: DropTo = (iv, technicianId, start) => {
    if (technicianId === iv.technicianId && iv.scheduledStart && start.getTime() === new Date(iv.scheduledStart).getTime()) return;
    setNotice(null);
    const end = new Date(start.getTime() + durationOf(iv));
    // Une intervention déjà planifiée peut revenir à sa place (« Annuler le déplacement »)
    const before = iv.scheduledStart ? { technicianId: iv.technicianId, scheduledStart: iv.scheduledStart, scheduledEnd: iv.scheduledEnd } : null;
    const tech = data?.techs.find((u) => u.id === technicianId);
    void (async () => {
      try {
        const res = await api<{ missingCertifications?: { name: string }[] }>(`/interventions/${iv.id}`, {
          method: 'PATCH', body: { technicianId, scheduledStart: start.toISOString(), scheduledEnd: end.toISOString() },
        });
        const where = t('{client} : {who}, {when}', {
          client: iv.clientName, who: tech ? `${tech.firstName} ${tech.lastName}` : '—',
          when: `${fmtDay(toDateInput(start))} ${fmtTime(start.toISOString())}`,
        });
        const warn = res.missingCertifications?.length
          ? ` ${t("⚠ Le technicien prévu n'a pas : {list}.", { list: res.missingCertifications.map((m) => m.name).join(', ') })}`
          : '';
        setNotice({
          text: `${t(before ? 'Intervention déplacée' : 'Intervention planifiée')} · ${where}.${warn}`, warn: !!warn,
          undo: before ? () => void api(`/interventions/${iv.id}`, { method: 'PATCH', body: before }).then(() => { setNotice(null); reload(); }) : undefined,
        });
      } catch (e) {
        setNotice({ text: (e as Error).message, warn: true });
      }
      reload();
    })();
  };

  /** Bloc cliqué : panneau pour ouvrir la fiche, replanifier ou annuler, sans quitter le planning */
  const openJob = (id: string) => {
    const iv = data?.planned.find((x) => x.id === id);
    if (iv) setSelected(iv);
    else navigate(`/interventions/${id}`);
  };

  /** « Synchroniser les téléphones » : l'appli des techniciens recharge aussitôt journée et fiches */
  const [syncing, setSyncing] = useState(false);
  const syncPhones = async () => {
    if (!company) return;
    setSyncing(true);
    try {
      const { count } = await api<{ count: number }>('/sync/request', { method: 'POST', body: { companyId: company.id, agencyId: agency?.id ?? null } });
      setNotice({ text: count ? t('Envoyé à {n} technicien(s) : leur appli se met à jour dès qu’elle est ouverte.', { n: count }) : t('Aucun technicien à prévenir.') });
    } catch (e) {
      setNotice({ text: (e as Error).message, warn: true });
    } finally {
      setSyncing(false);
    }
  };

  const openDay = (d: Date) => {
    setDay(d);
    setView('day');
  };

  const title = view === 'day'
    ? fmtLongDay(day)
    : view === 'week'
      ? t('Semaine {n} · du {from} au {to}', {
        n: isoWeek(from), from: new Intl.DateTimeFormat(uiLocale(), { day: 'numeric', month: 'long' }).format(from),
        to: new Intl.DateTimeFormat(uiLocale(), { day: 'numeric', month: 'long', year: 'numeric' }).format(days[6]),
      })
      : new Intl.DateTimeFormat(uiLocale(), { month: 'long', year: 'numeric' }).format(from);

  const total = data ? data.planned.length : 0;
  const prevLabel = view === 'day' ? 'Jour précédent' : view === 'week' ? 'Semaine précédente' : 'Mois précédent';
  const nextLabel = view === 'day' ? 'Jour suivant' : view === 'week' ? 'Semaine suivante' : 'Mois suivant';
  // En arabe (lecture de droite à gauche), « précédent » pointe vers la droite
  const rtl = typeof document !== 'undefined' && document.documentElement.dir === 'rtl';

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ` · ${t('Toutes les agences')}`}</div>
          <h1>{t('Planning')} · {title}</h1>
        </div>
        <OrgPicker />
      </div>

      <div className="row">
        <div className="chips" role="tablist" aria-label={t('Affichage du planning')}>
          {VIEWS.map((v) => (
            <button key={v.id} type="button" role="tab" aria-selected={view === v.id} className={`chip${view === v.id ? ' on' : ''}`} onClick={() => setView(v.id)}>{t(v.label)}</button>
          ))}
        </div>
        <button type="button" className="secondary" onClick={() => shift(-1)} aria-label={t(prevLabel)}>{rtl ? '→' : '←'}</button>
        {view === 'month' ? (
          <input type="month" style={{ width: 'auto' }} value={toDateInput(day).slice(0, 7)} aria-label={t('Mois')}
            onChange={(e) => e.target.value && setDay(new Date(`${e.target.value}-01T12:00:00`))} />
        ) : (
          <input type="date" style={{ width: 'auto' }} value={toDateInput(day)} aria-label={t('Jour')}
            onChange={(e) => e.target.value && setDay(new Date(`${e.target.value}T12:00:00`))} />
        )}
        <button type="button" className="secondary" onClick={() => shift(1)} aria-label={t(nextLabel)}>{rtl ? '←' : '→'}</button>
        <button type="button" className="secondary" onClick={() => setDay(new Date())}>{t("Aujourd'hui")}</button>
        <input type="search" style={{ width: 200 }} placeholder={t('Filtrer les techniciens')} aria-label={t('Filtrer les techniciens')} value={filter} onChange={(e) => setFilter(e.target.value)} />
        {view === 'week' && (
          <label className="check small">
            <input type="checkbox" checked={!weekend} onChange={toggleWeekend} /> {t('Masquer le week-end')}
          </label>
        )}
        <div className="grow" />
        <button type="button" className="secondary" aria-pressed={showTodo} onClick={toggleTodo}>
          {t('À planifier')} <span className="badge warn">{data?.todo.length ?? 0}</span>
        </button>
        {has('intervention.assign') && company && (
          <button type="button" className="secondary" disabled={syncing} onClick={() => void syncPhones()}><span aria-hidden="true">⟳</span> {t('Synchroniser les téléphones')}</button>
        )}
        {has('intervention.assign') && company && (
          <button type="button" className="secondary" onClick={() => setShowVisibility(!showVisibility)}>{t('Ce que voient les techniciens')}</button>
        )}
        {has('intervention.write') && (
          <button type="button" className="accent" onClick={() => navigate('/interventions/new')}>{t('Nouvelle intervention')}</button>
        )}
      </div>
      {showVisibility && company && <PlanningVisibility companyId={company.id} agencyId={agency?.id} onClose={() => setShowVisibility(false)} />}
      {error && <p className="error">{error}</p>}
      {notice && (
        <div className="row card" role="status" style={{ padding: '10px 14px', gap: 10, borderInlineStart: `4px solid var(${notice.warn ? '--warn-fg' : '--ok-fg'})` }}>
          <span className="small grow">{notice.text}</span>
          {notice.undo && <button type="button" className="secondary" onClick={notice.undo}>{t('Annuler le déplacement')}</button>}
          <button type="button" className="ghost" onClick={() => setNotice(null)} aria-label={t('Fermer')}>✕</button>
        </div>
      )}

      <div className="row" style={{ alignItems: 'flex-start' }}>
        <section className="card stack" style={{ flex: view === 'day' && showTodo ? '999 1 620px' : '1 1 100%', minWidth: 0 }}>
          {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
            <>
              <div className="row small muted" style={{ gap: 12 }}>
                <span>{tp(total, '{n} intervention planifiée', '{n} interventions planifiées')} · {fmtHours(hoursOf(data?.planned ?? []))}</span>
                <div className="grow" />
                {STATES.map((x) => (
                  <span key={x.id} className="row" style={{ gap: 4 }}><span className="plan-swatch" style={{ background: x.color }} />{t(x.label)}</span>
                ))}
              </div>
              {canAssign && view !== 'month' && (
                <p className="small muted" style={{ margin: 0 }}>{t('Glissez une intervention sur un technicien et une heure pour la planifier ou la déplacer.')}</p>
              )}
              {view === 'day' && <DayGrid groups={groups} day={day} canMove={canAssign} onDrop={dropTo} onOpen={openJob} />}
              {view === 'week' && <WeekGrid groups={groups} days={shownDays} canMove={canAssign} onDrop={dropTo} onOpen={openJob} onDay={openDay} />}
              {view === 'month' && <MonthGrid groups={groups} days={days} onDay={openDay} />}
              {data && !data.techs.length && <p className="muted">{agency ? t('Aucun technicien rattaché à cette agence.') : t('Aucun technicien dans cette société.')}</p>}
            </>
          )}
        </section>

        {showTodo && (
          <aside className="card stack" style={{ flex: '1 1 300px', minWidth: 0 }}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <h2>{t('À planifier')}</h2>
              <span className="badge warn">{data?.todo.length ?? 0}</span>
            </div>
            <div className={view === 'day' ? 'stack' : 'plan-todo-wide'}>
              {(data?.todo ?? []).map((iv) => (
                <ToPlanCard key={iv.id} iv={iv} techs={techniciansFor(data?.techs ?? [], iv.agencyId)}
                  day={view === 'day' ? day : days.find(isToday) ?? days[0]} canAssign={canAssign} onDone={reload} />
              ))}
            </div>
            {data && !data.todo.length && <p className="muted small">{t('Rien en attente.')}</p>}
          </aside>
        )}
      </div>

      {selected && (
        <JobSheet iv={selected} techs={techniciansFor(data?.techs ?? [], selected.agencyId)} canAssign={canAssign} canCancel={has('intervention.write')}
          onOpen={() => navigate(`/interventions/${selected.id}`)} onClose={() => setSelected(null)}
          onChanged={(text) => { setSelected(null); if (text) setNotice({ text }); reload(); }} />
      )}
    </>
  );
}

function GroupHeader({ g, span }: { g: Group; span: number }) {
  if (!g.label) return null;
  return <tr className="plan-group"><th colSpan={span} scope="colgroup">{g.label}</th></tr>;
}

function TechCell({ r, extra }: { r: Row; extra?: string }) {
  return (
    <th scope="row" className="plan-tech">
      <strong>{r.label}</strong>
      {r.live && (
        <div className="small plan-live">
          <span className="plan-dot" style={{ background: r.live.state === 'free' ? FREE_COLOR : STATE_COLOR[r.live.state] }} aria-hidden="true" />
          {r.live.text}
        </div>
      )}
      <div className="small muted">{r.sub}</div>
      {extra && <div className="small">{extra}</div>}
    </th>
  );
}

/** Bloc d'une intervention : heure et client en gros, ville et type dessous ; couleur = état */
function Block({ iv, canMove, onOpen, className, style }: { iv: InterventionRow; canMove: boolean; onOpen: (id: string) => void; className: string; style?: CSSProperties }) {
  const st = stateOf(iv);
  const drag = canMove && movable(iv);
  return (
    <button type="button" title={jobTitle(iv)} onClick={() => onOpen(iv.id)} className={`${className}${drag ? ' plan-draggable' : ''}`}
      draggable={drag} onDragStart={drag ? startDrag(iv) : undefined} onDragEnd={endDrag}
      style={{ ...style, ['--plan-color' as string]: STATE_COLOR[st] }}>
      <span className="plan-line1">{st === 'late' && '⏰ '}{fmtTime(iv.scheduledStart)} {iv.clientName}</span>
      <span className="plan-line2">{[iv.siteCity, kindLabel(iv.kind)].filter(Boolean).join(' · ')}</span>
    </button>
  );
}

/** Jour : une ligne de temps de 6 h à 20 h par technicien, avec l'heure actuelle */
function DayGrid({ groups, day, canMove, onDrop, onOpen }: { groups: Group[]; day: Date; canMove: boolean; onDrop: DropTo; onOpen: (id: string) => void }) {
  const hourOf = (d: Date) => d.getHours() + d.getMinutes() / 60;
  const position = (iv: InterventionRow) => {
    const left = Math.max(0, (hourOf(new Date(iv.scheduledStart!)) - START_HOUR) / SPAN) * 100;
    const right = Math.min(1, (hourOf(endOf(iv)) - START_HOUR) / SPAN) * 100;
    // insetInlineStart : la ligne de temps se lit de droite à gauche en arabe
    return { insetInlineStart: `${Math.min(left, 98)}%`, width: `${Math.max(2, right - left)}%` };
  };
  const now = new Date();
  const nowPos = isToday(day) && hourOf(now) >= START_HOUR && hourOf(now) <= END_HOUR ? ((hourOf(now) - START_HOUR) / SPAN) * 100 : null;
  /** Heure sous la souris, au quart d'heure */
  const timeAt = (e: DragEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const rtl = document.documentElement.dir === 'rtl';
    const ratio = Math.min(1, Math.max(0, (rtl ? rect.right - e.clientX : e.clientX - rect.left) / rect.width));
    const minutes = Math.round((START_HOUR * 60 + ratio * SPAN * 60) / SNAP_MIN) * SNAP_MIN;
    const at = new Date(day);
    at.setHours(0, minutes, 0, 0);
    return at;
  };
  return (
    <div className="table-wrap">
      <table className="plan-table plan-day">
        <thead>
          <tr>
            <th className="plan-tech" />
            <th>
              <div style={{ display: 'flex' }}>
                {Array.from({ length: SPAN }, (_, k) => (
                  <div key={k} className="small muted" style={{ flex: 1, borderInlineStart: '1px solid var(--ground-2)', paddingInlineStart: 4, fontWeight: 400 }}>{START_HOUR + k}h</div>
                ))}
              </div>
            </th>
          </tr>
        </thead>
        <tbody>
          {groups.map((g) => [
            <GroupHeader key={`g-${g.id}`} g={g} span={2} />,
            ...g.rows.map((r) => (
              <tr key={r.id}>
                <TechCell r={r} extra={r.jobs.length ? fmtHours(hoursOf(r.jobs)) : undefined} />
                <td className="plan-lane" {...dropProps(canMove && !!r.techId, (iv, e) => onDrop(iv, r.techId!, timeAt(e)))}>
                  {Array.from({ length: SPAN - 1 }, (_, k) => <span key={k} className="plan-hourline" style={{ insetInlineStart: `${((k + 1) / SPAN) * 100}%` }} />)}
                  {nowPos !== null && <span className="plan-now" style={{ insetInlineStart: `${nowPos}%` }} aria-hidden="true" />}
                  {r.jobs.map((iv) => (
                    <Block key={iv.id} iv={iv} canMove={canMove} onOpen={onOpen} className="plan-block" style={{ position: 'absolute', top: 4, bottom: 4, ...position(iv) }} />
                  ))}
                </td>
              </tr>
            )),
          ])}
        </tbody>
      </table>
    </div>
  );
}

/** Semaine : du lundi au dimanche (ou au vendredi), les interventions de chaque technicien jour par jour */
function WeekGrid({ groups, days, canMove, onDrop, onOpen, onDay }: { groups: Group[]; days: Date[]; canMove: boolean; onDrop: DropTo; onOpen: (id: string) => void; onDay: (d: Date) => void }) {
  const head = new Intl.DateTimeFormat(uiLocale(), { weekday: 'short', day: 'numeric', month: 'short' });
  /** Lâchée sur un autre jour : même heure qu'avant (9 h pour une intervention pas encore planifiée) */
  const sameTimeOn = (iv: InterventionRow, d: Date) => {
    const at = new Date(d);
    const prev = iv.scheduledStart ? new Date(iv.scheduledStart) : null;
    at.setHours(prev ? prev.getHours() : 9, prev ? prev.getMinutes() : 0, 0, 0);
    return at;
  };
  return (
    <div className="table-wrap">
      <table className="plan-table plan-week">
        <thead>
          <tr>
            <th className="plan-tech" />
            {days.map((d) => (
              <th key={d.getTime()} className={`${isToday(d) ? 'plan-today' : ''}${isWeekend(d) ? ' plan-weekend' : ''}`}>
                <button type="button" className="plan-dayhead" onClick={() => onDay(d)} title={t('Voir la journée')} aria-label={`${t('Voir la journée')} : ${head.format(d)}`}>{head.format(d)}</button>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {groups.map((g) => [
            <GroupHeader key={`g-${g.id}`} g={g} span={days.length + 1} />,
            ...g.rows.map((r) => (
              <tr key={r.id}>
                <TechCell r={r} extra={r.jobs.length ? `${fmtHours(hoursOf(r.jobs))} · ${tp(r.jobs.length, '{n} interv.|1', '{n} interv.')}` : undefined} />
                {days.map((d) => {
                  const jobs = r.jobs.filter((iv) => sameDay(iv.scheduledStart!, d)).sort((a, b) => a.scheduledStart!.localeCompare(b.scheduledStart!));
                  return (
                    <td key={d.getTime()} className={`plan-weekcell${isToday(d) ? ' plan-today' : ''}${isWeekend(d) ? ' plan-weekend' : ''}`}
                      {...dropProps(canMove && !!r.techId, (iv) => onDrop(iv, r.techId!, sameTimeOn(iv, d)))}>
                      {jobs.map((iv) => <Block key={iv.id} iv={iv} canMove={canMove} onOpen={onOpen} className="plan-chip" />)}
                    </td>
                  );
                })}
              </tr>
            )),
          ])}
        </tbody>
      </table>
    </div>
  );
}

/** Charge d'une journée : vide, légère (moins de 4 h), normale (jusqu'à 8 h), lourde */
const loadClass = (h: number) => (h <= 0 ? '' : h < 4 ? 'plan-load-1' : h <= 8 ? 'plan-load-2' : 'plan-load-3');

/** Mois : une case par jour et par technicien, avec le nombre d'interventions et la charge */
function MonthGrid({ groups, days, onDay }: { groups: Group[]; days: Date[]; onDay: (d: Date) => void }) {
  const wd = new Intl.DateTimeFormat(uiLocale(), { weekday: 'narrow' });
  const long = new Intl.DateTimeFormat(uiLocale(), { weekday: 'long', day: 'numeric', month: 'long' });
  const allRows = groups.flatMap((g) => g.rows);
  return (
    <>
      <div className="table-wrap">
        <table className="plan-table plan-month">
          <thead>
            <tr>
              <th className="plan-tech" />
              {days.map((d) => (
                <th key={d.getTime()} className={`${isToday(d) ? 'plan-today' : ''}${isWeekend(d) ? ' plan-weekend' : ''}`}>
                  <button type="button" className="plan-dayhead" onClick={() => onDay(d)} title={long.format(d)}>
                    <span className="muted">{wd.format(d)}</span><br />{d.getDate()}
                  </button>
                </th>
              ))}
              <th className="plan-total">{t('Total')}</th>
            </tr>
          </thead>
          <tbody>
            {groups.map((g) => [
              <GroupHeader key={`g-${g.id}`} g={g} span={days.length + 2} />,
              ...g.rows.map((r) => (
                <tr key={r.id}>
                  <TechCell r={r} />
                  {days.map((d) => {
                    const jobs = r.jobs.filter((iv) => sameDay(iv.scheduledStart!, d));
                    const h = hoursOf(jobs);
                    const tip = jobs.length
                      ? `${r.label} · ${long.format(d)} · ${fmtHours(h)}\n${jobs.map((iv) => `${fmtTime(iv.scheduledStart)} ${iv.clientName} – ${iv.reason}`).join('\n')}`
                      : `${r.label} · ${long.format(d)} · ${t('libre')}`;
                    return (
                      <td key={d.getTime()} className={`${isToday(d) ? 'plan-today' : ''}${isWeekend(d) ? ' plan-weekend' : ''}`}>
                        <button type="button" className={`plan-cell ${loadClass(h)}`} title={tip} aria-label={tip} onClick={() => onDay(d)}>
                          {jobs.length || ''}
                        </button>
                      </td>
                    );
                  })}
                  <td className="plan-total small">
                    <strong>{fmtHours(hoursOf(r.jobs))}</strong>
                    <div className="muted">{tp(r.jobs.length, '{n} interv.|1', '{n} interv.')}</div>
                  </td>
                </tr>
              )),
            ])}
          </tbody>
          {allRows.length > 1 && (
            <tfoot>
              <tr>
                <th scope="row" className="plan-tech small">{t('Total du jour')}</th>
                {days.map((d) => {
                  const n = allRows.reduce((s, r) => s + r.jobs.filter((iv) => sameDay(iv.scheduledStart!, d)).length, 0);
                  return <td key={d.getTime()} className={`small${isWeekend(d) ? ' plan-weekend' : ''}`} style={{ textAlign: 'center' }}>{n || ''}</td>;
                })}
                <td className="plan-total small"><strong>{fmtHours(hoursOf(allRows.flatMap((r) => r.jobs)))}</strong></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
      <div className="row small muted" style={{ gap: 12 }}>
        <span>{t('Charge de la journée :')}</span>
        <span className="row" style={{ gap: 4 }}><span className="plan-swatch plan-load-1" />{t('moins de 4 h')}</span>
        <span className="row" style={{ gap: 4 }}><span className="plan-swatch plan-load-2" />{t('4 à 8 h')}</span>
        <span className="row" style={{ gap: 4 }}><span className="plan-swatch plan-load-3" />{t('plus de 8 h')}</span>
        <span>{t('Cliquez sur une case pour voir la journée.')}</span>
      </div>
    </>
  );
}

/** Échéance d'une visite de contrat : en orange si elle est dans moins de 7 jours ou dépassée */
function DueBadge({ due }: { due: string }) {
  const today = toDateInput(new Date());
  const soon = addDays(today, 7);
  const tone = due < today ? 'warn' : due <= soon ? 'warn' : 'info';
  return (
    <div className="small">
      <span className={`badge ${tone}`}>{t(due < today ? 'Échéance dépassée : {date}' : 'Échéance : {date}', { date: fmtDay(due) })}</span>{' '}
      <span className="muted">{t('visite de contrat')}</span>
    </div>
  );
}

function ToPlanCard({ iv, techs, day, canAssign, onDone }: {
  iv: InterventionRow; techs: UserRow[]; day: Date; canAssign: boolean; onDone: () => void;
}) {
  const [open, setOpen] = useState(false);
  const needsCerts = (iv.requiredCertificationIds?.length ?? 0) > 0;
  const drag = canAssign && !open;
  return (
    <div style={{ border: '1.5px solid var(--rule)', borderRadius: 10, padding: 12 }} className={`stack${drag ? ' plan-draggable' : ''}`}
      draggable={drag} onDragStart={drag ? startDrag(iv) : undefined} onDragEnd={endDrag}
      title={drag ? t('Glissez-la sur le planning pour la planifier') : undefined}>
      <div className="row" style={{ justifyContent: 'space-between', gap: 6 }}>
        <strong>{iv.clientName}</strong>
        <span className="row" style={{ gap: 4 }}><KindBadge kind={iv.kind} /><PriorityBadge priority={iv.priority} /></span>
      </div>
      <div className="small">{iv.reason}</div>
      <div className="small muted">{iv.number} · {iv.siteCity ?? ''} · <StatusBadge status={iv.status} /> · {t('Priorité {p}', { p: tl(PRIORITY_LABELS, iv.priority).toLowerCase() })}</div>
      {iv.dueDate && <DueBadge due={iv.dueDate} />}
      {needsCerts && <div className="small"><span className="badge info">{t('Habilitation exigée')}</span></div>}
      {canAssign && !open && <button type="button" className="secondary" onClick={() => setOpen(true)}>{t('Planifier')}</button>}
      {open && (
        <PlanForm iv={iv} techs={techs} defaultStart={new Date(`${toDateInput(day)}T09:00:00`)}
          onCancel={() => setOpen(false)} onSaved={() => { setOpen(false); onDone(); }} />
      )}
    </div>
  );
}

/** Intervention choisie au planning : voir, replanifier ou annuler, sans quitter le planning */
function JobSheet({ iv, techs, canAssign, canCancel, onOpen, onClose, onChanged }: {
  iv: InterventionRow; techs: UserRow[]; canAssign: boolean; canCancel: boolean;
  onOpen: () => void; onClose: () => void; onChanged: (notice?: string) => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const [mode, setMode] = useState<'view' | 'replan' | 'cancel'>('view');
  useEffect(() => {
    const d = ref.current;
    if (d && !d.open) d.showModal();
  }, []);
  const editable = !['DONE', 'TO_RESUME', 'CANCELLED', 'ON_SITE'].includes(iv.status);
  return (
    <dialog ref={ref} className="sheet" onClose={onClose} onClick={(e) => { if (e.target === ref.current) ref.current?.close(); }} aria-labelledby={`sheet-${iv.id}`}>
      <div className="stack">
        <div className="row" style={{ justifyContent: 'space-between', gap: 6 }}>
          <h2 id={`sheet-${iv.id}`} style={{ margin: 0 }}>{iv.clientName}</h2>
          <button type="button" className="ghost" onClick={() => ref.current?.close()} aria-label={t('Fermer')}>✕</button>
        </div>
        <div className="row" style={{ gap: 4 }}><KindBadge kind={iv.kind} /><PriorityBadge priority={iv.priority} /><StatusBadge status={iv.status} /></div>
        <div className="small">{iv.reason}</div>
        <div className="small muted">
          {iv.number} · {iv.siteCity ?? ''} · {fmtDay(toDateInput(new Date(iv.scheduledStart!)))} {fmtTime(iv.scheduledStart)}–{fmtTime(endOf(iv).toISOString())}
          {iv.technicianFirstName ? ` · ${iv.technicianFirstName} ${iv.technicianLastName ?? ''}` : ''}
        </div>
        {mode === 'view' && (
          <div className="row">
            <button type="button" onClick={onOpen}>{t('Ouvrir la fiche')}</button>
            {canAssign && editable && <button type="button" className="secondary" onClick={() => setMode('replan')}>{t('Replanifier')}</button>}
            {canCancel && editable && <button type="button" className="danger-outline" onClick={() => setMode('cancel')}>{t('Annuler l’intervention')}</button>}
          </div>
        )}
        {mode === 'replan' && (
          <PlanForm iv={iv} techs={techs} defaultStart={new Date(iv.scheduledStart!)} onCancel={() => setMode('view')}
            onSaved={(res) => onChanged(res.missingCertifications?.length
              ? t("⚠ Le technicien prévu n'a pas : {list}.", { list: res.missingCertifications.map((m) => m.name).join(', ') })
              : t('Intervention replanifiée.'))} />
        )}
        {mode === 'cancel' && <CancelIntervention id={iv.id} onCancel={() => setMode('view')} onDone={() => onChanged(t('Intervention annulée.'))} />}
      </div>
    </dialog>
  );
}
