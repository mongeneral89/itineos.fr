import { useEffect, useState, type FormEvent } from 'react';
import { ScanButton } from '../components/ScanButton';
import { DocLanguageSelect } from '../components/DocLanguageSelect';
import { useNavigate } from 'react-router-dom';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import type { Client } from '../types';
import { OrgPicker } from '../components/Layout';
import { ClientImport } from './ClientImport';
import { t } from '../i18n';

export function ClientsPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [field, setField] = useState('all');
  const [dept, setDept] = useState('');
  const [sort, setSort] = useState('name');
  // La recherche part 250 ms après la dernière touche
  const [search, setSearch] = useState({ q: '', dept: '' });
  useEffect(() => {
    const timer = window.setTimeout(() => setSearch({ q, dept }), 250);
    return () => window.clearTimeout(timer);
  }, [q, dept]);
  const [creating, setCreating] = useState(false);
  const [importing, setImporting] = useState(false);
  const { data, error, loading, reload } = useLoad(
    () => api<Client[]>(`/clients${qs({ companyId: company?.id, agencyId: agency?.id, q: search.q, field, dept: search.dept, sort, limit: 200 })}`),
    [company?.id, agency?.id, search.q, search.dept, field, sort],
  );

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Clients et sites')}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="row">
        <input type="search" style={{ maxWidth: 340 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Rechercher : nom, ville, téléphone, n° de série…')} aria-label={t('Rechercher un client')} />
        <ScanButton label={t('Scanner un n° de série pour retrouver le client')} onResult={(v) => { setField('serial'); setQ(v); }} />
        <select style={{ width: 'auto' }} value={field} onChange={(e) => setField(e.target.value)} aria-label={t('Chercher dans')}>
          <option value="all">{t('Partout')}</option>
          <option value="name">{t('Nom (client, contact, site)')}</option>
          <option value="city">{t('Ville ou adresse')}</option>
          <option value="postalCode">{t('Code postal')}</option>
          <option value="phone">{t('Téléphone')}</option>
          <option value="email">{t('E-mail')}</option>
          <option value="subscriber">{t('N° d’abonné ou référence')}</option>
          <option value="serial">{t('N° de série')}</option>
          <option value="equipment">{t('Matériel (type, marque, modèle)')}</option>
          <option value="notes">{t('Notes')}</option>
        </select>
        <input style={{ width: 110 }} value={dept} onChange={(e) => setDept(e.target.value)} placeholder={t('Départ. (54…)')} aria-label={t('Département')} maxLength={3} />
        <select style={{ width: 'auto' }} value={sort} onChange={(e) => setSort(e.target.value)} aria-label={t('Trier par')}>
          <option value="name">{t('Tri : nom')}</option>
          <option value="city">{t('Tri : ville')}</option>
          <option value="postalCode">{t('Tri : code postal')}</option>
          <option value="recent">{t('Tri : plus récents')}</option>
        </select>
        <div className="grow" />
        {has('client.write') && !creating && !importing && <button type="button" className="secondary" onClick={() => setImporting(true)}>{t('Importer un fichier')}</button>}
        {has('client.write') && !creating && !importing && <button type="button" className="accent" onClick={() => setCreating(true)}>{t('Nouveau client')}</button>}
      </div>
      {creating && <NewClientForm onCancel={() => setCreating(false)} onCreated={(id) => { setCreating(false); void reload(); navigate(`/clients/${id}`); }} />}
      {importing && <ClientImport onClose={() => setImporting(false)} onImported={() => void reload()} />}
      {error && <p className="error">{error}</p>}
      <section className="card">
        {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Client')}</th><th>{t('Ville')}</th><th>{t('Contact')}</th><th>{t('Rattachement')}</th></tr></thead>
              <tbody>
                {(data ?? []).map((c) => (
                  <tr key={c.id} className="clickable" onClick={() => navigate(`/clients/${c.id}`)}>
                    <td><a href={`/clients/${c.id}`} onClick={(e) => { e.preventDefault(); navigate(`/clients/${c.id}`); }}><strong>{c.name}</strong></a>{c.subscriberNumber && <div className="small muted">{t('Abonné n° {n}', { n: c.subscriberNumber })}</div>}</td>
                    <td>{[c.postalCode, c.city].filter(Boolean).join(' ') || '—'}</td>
                    <td className="small">{[c.phone, c.email].filter(Boolean).join(' · ') || '—'}</td>
                    <td>{c.agencyId ? <span className="badge neutral">{company?.agencies.find((a) => a.id === c.agencyId)?.name ?? t('Agence')}</span> : <span className="badge info">{t('Partagé société')}</span>}</td>
                  </tr>
                ))}
                {data && !data.length && <tr><td colSpan={4} className="muted">{t('Aucun client.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}

function NewClientForm({ onCancel, onCreated }: { onCancel: () => void; onCreated: (id: string) => void }) {
  const { company, agency } = useAuth();
  const [form, setForm] = useState({ type: 'COMPANY', name: '', email: '', phone: '', address: '', postalCode: '', city: '', subscriberNumber: '', siren: '', vatNumber: '', locale: '', shared: !agency });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!company) return;
    setError(null);
    try {
      const { shared, locale, siren, vatNumber, ...rest } = form;
      // Particulier : ni SIREN ni n° de TVA
      const ids = rest.type === 'COMPANY' ? { siren: siren.trim() || null, vatNumber: vatNumber.trim() || null } : {};
      const created = await api<{ id: string }>('/clients', {
        method: 'POST',
        body: { ...rest, ...ids, locale: locale || null, companyId: company.id, agencyId: shared ? null : agency?.id ?? null },
      });
      onCreated(created.id);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{t('Nouveau client')}</h2>
      <div className="row">
        <div className="field" style={{ width: 200 }}>
          <label htmlFor="c-type">{t('Type')}</label>
          <select id="c-type" value={form.type} onChange={set('type')}>
            <option value="COMPANY">{t('Entreprise')}</option>
            <option value="INDIVIDUAL">{t('Particulier')}</option>
          </select>
        </div>
        <div className="field grow"><label htmlFor="c-name">{t('Nom')}</label><input id="c-name" value={form.name} onChange={set('name')} required /></div>
        <div className="field" style={{ width: 200 }}><label htmlFor="c-sub">{t('N° d’abonné (facultatif)')}</label><input id="c-sub" value={form.subscriberNumber} onChange={set('subscriberNumber')} /></div>
      </div>
      <div className="row">
        <div className="field grow"><label htmlFor="c-email">{t("E-mail (pour l'envoi des fiches)")}</label><input id="c-email" type="email" value={form.email} onChange={set('email')} /></div>
        <div className="field grow"><label htmlFor="c-phone">{t('Téléphone')}</label><input id="c-phone" value={form.phone} onChange={set('phone')} /></div>
        <div className="field grow">
          <label htmlFor="c-locale">{t('Langue des documents')}</label>
          <DocLanguageSelect id="c-locale" value={form.locale} onChange={(v) => setForm((f) => ({ ...f, locale: v }))} />
        </div>
      </div>
      <div className="row">
        <div className="field grow"><label htmlFor="c-address">{t('Adresse')}</label><input id="c-address" value={form.address} onChange={set('address')} /></div>
        <div className="field" style={{ width: 140 }}><label htmlFor="c-pc">{t('Code postal')}</label><input id="c-pc" value={form.postalCode} onChange={set('postalCode')} /></div>
        <div className="field grow"><label htmlFor="c-city">{t('Ville')}</label><input id="c-city" value={form.city} onChange={set('city')} /></div>
      </div>
      {form.type === 'COMPANY' && (
        <div className="row">
          <div className="field grow"><label htmlFor="c-siren">{t('SIREN ou SIRET')}</label><input id="c-siren" inputMode="numeric" value={form.siren} onChange={set('siren')} /></div>
          <div className="field grow"><label htmlFor="c-vat">{t('N° de TVA intracommunautaire')}</label><input id="c-vat" value={form.vatNumber} onChange={set('vatNumber')} /></div>
        </div>
      )}
      {agency && (
        <label className="check">
          <input type="checkbox" checked={form.shared} onChange={(e) => setForm((f) => ({ ...f, shared: e.target.checked }))} />
          {t('Client partagé par toutes les agences de {name}', { name: company?.name ?? '' })}
        </label>
      )}
      <p className="small muted">{t("Un site est créé automatiquement à l'adresse du client. Vous pourrez en ajouter d'autres.")}</p>
      {error && <p className="error">{error}</p>}
      <div className="row">
        <button type="submit">{t('Créer')}</button>
        <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
      </div>
    </form>
  );
}
