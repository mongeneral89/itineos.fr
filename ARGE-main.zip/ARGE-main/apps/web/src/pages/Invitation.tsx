/**
 * Page ouverte depuis le lien d'invitation (WhatsApp, e-mail, QR code). Le but : la vraie appli, pas le navigateur.
 *  - Android : mot de passe choisi → l'APK se télécharge aussitôt → « Ouvrir l'appli » (App Link https …/ouvrir,
 *    code de 15 minutes) l'ouvre déjà connectée ;
 *  - iPhone : l'appli s'installe par le bureau (pas encore sur l'App Store) ; le compte est prêt pour elle ;
 *  - ordinateur : un QR code pour continuer sur le téléphone (ou le logiciel dans le navigateur, pour le bureau).
 */
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { api } from '../api';
import { useAuth } from '../auth';
import { CLIENT } from '../client';
import { PRODUCT_NAME } from '../edition';
import { t } from '../i18n';
import type { Me } from '../types';

interface Info { firstName: string; lastName: string; email: string; companyName: string | null }
interface Accepted { token: string; me: Me; appCode: string; server: string }

type Device = 'android' | 'ios' | 'desktop';
const device = (): Device => {
  const ua = navigator.userAgent;
  if (/Android/i.test(ua)) return 'android';
  // iPad récent : se présente comme un Mac, mais tactile
  if (/iPhone|iPad|iPod/i.test(ua) || (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1)) return 'ios';
  return 'desktop';
};

/** Page de téléchargement de l'APK : à côté du fichier de mises à jour (VITE_UPDATE_URL) */
function downloadPage(): string | null {
  const info = import.meta.env.VITE_UPDATE_URL;
  try {
    return info ? new URL('.', info).toString() : null;
  } catch {
    return null;
  }
}

/** Adresse directe de la dernière APK (fichier de mises à jour) ; à défaut, la page de téléchargement */
function useApkUrl(): string | null {
  const [url, setUrl] = useState<string | null>(downloadPage());
  useEffect(() => {
    const info = import.meta.env.VITE_UPDATE_URL;
    if (!info) return;
    fetch(info, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { url?: string } | null) => {
        // Seulement une APK du même site que le fichier de mises à jour
        if (j?.url && new URL(j.url).origin === new URL(info).origin) setUrl(j.url);
      })
      .catch(() => undefined);
  }, []);
  return url;
}

/** QR code de l'adresse donnée (pour passer de l'ordinateur au téléphone) */
function Qr({ text }: { text: string }) {
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    void import('@zxing/browser').then(({ BrowserQRCodeSvgWriter }) => el.replaceChildren(new BrowserQRCodeSvgWriter().write(text, 200, 200)));
  }, [text]);
  return <div ref={box} className="invite-qr" />;
}

/** Android : télécharger l'APK, l'installer, puis ouvrir l'appli */
function AndroidSteps({ apk, openApp, email, app }: { apk: string | null; openApp?: string; email?: string; app: string }) {
  return (
    <>
      {apk && (
        <a className="button big accent invite-step" href={apk}>{t('1. Télécharger l’appli {app}', { app })}</a>
      )}
      <p className="small muted">{t('Ouvrez le fichier téléchargé puis touchez « Installer ». Si Android le demande, autorisez l’installation depuis ce navigateur.')}</p>
      {openApp && (
        <>
          <a className="button big invite-step" href={openApp}>{t('2. Ouvrir l’appli (déjà connectée)')}</a>
          <p className="small muted">{t('Le bouton 2 marche pendant 15 minutes. Ensuite, connectez-vous dans l’appli avec {email} et votre mot de passe.', { email: email ?? '' })}</p>
        </>
      )}
    </>
  );
}

export function InvitationPage() {
  const { adopt } = useAuth();
  const token = window.location.hash.slice(1);
  const [info, setInfo] = useState<Info | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<Accepted | null>(null);
  const [here] = useState(() => window.location.href);
  const kind = device();
  const apk = useApkUrl();
  const app = CLIENT?.name ?? PRODUCT_NAME;

  useEffect(() => {
    if (!token) return setError(t('Ce lien d’invitation est invalide ou a expiré. Demandez-en un nouveau au bureau.'));
    api<Info>(`/invitations/${encodeURIComponent(token)}`).then(setInfo).catch((e) => setError((e as Error).message));
  }, [token]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password !== confirm) return setError(t('Les deux mots de passe ne sont pas identiques.'));
    setBusy(true);
    try {
      const res = await api<Accepted>(`/invitations/${encodeURIComponent(token)}/accept`, { method: 'POST', body: { password } });
      // Le lien ne doit pas resservir s'il reste dans l'historique du navigateur
      history.replaceState(null, '', '/invitation');
      await adopt(res);
      setDone(res);
      // Android : le téléchargement de l'appli démarre tout de suite (la page reste affichée)
      if (kind === 'android' && apk && apk.endsWith('.apk')) window.location.assign(apk);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  // Lien https vérifié par Android (App Link) : seule l'appli A.R.G.E. peut l'ouvrir ; sans elle, page /ouvrir
  const openApp = done ? `${done.server}/ouvrir?code=${encodeURIComponent(done.appCode)}` : '';

  return (
    <div className="login">
      <div className="card stack">
        {CLIENT ? <img className="login-logo" src={CLIENT.logo} alt={CLIENT.name} /> : <h1>{PRODUCT_NAME}</h1>}
        {!done && info && (
          <form className="stack" onSubmit={submit}>
            <h2>{t('Bienvenue {name} !', { name: info.firstName })}</h2>
            {kind === 'desktop' && (
              <div className="stack invite-desktop" style={{ gap: 6 }}>
                <p className="small"><strong>{t('Technicien ? Scannez ce QR code avec votre téléphone pour installer l’appli.')}</strong></p>
                <Qr text={here} />
              </div>
            )}
            {kind === 'android' && <p className="small muted">{t('Trois étapes : votre mot de passe, l’appli qui se télécharge, puis « Ouvrir l’appli ».')}</p>}
            <p className="muted">{t('Choisissez votre mot de passe pour {app}{company}. Votre identifiant est {email}.', {
              app, company: info.companyName ? ` (${info.companyName})` : '', email: info.email,
            })}</p>
            <div className="field">
              <label htmlFor="inv-pass">{t('Mot de passe (8 caractères minimum)')}</label>
              <input id="inv-pass" type="password" autoComplete="new-password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <div className="field">
              <label htmlFor="inv-pass2">{t('Le même, une seconde fois')}</label>
              <input id="inv-pass2" type="password" autoComplete="new-password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
            </div>
            {error && <p className="error" role="alert">{error}</p>}
            <button type="submit" className="big" disabled={busy}>{t('Activer mon compte')}</button>
          </form>
        )}
        {!info && !done && (error ? <p className="error" role="alert">{error}</p> : <p className="muted">{t('Chargement…')}</p>)}
        {done && (
          <div className="stack">
            <h2>{t('Votre compte est prêt ✓')}</h2>
            {kind === 'android' && <AndroidSteps apk={apk} openApp={openApp} email={done.me.user.email} app={app} />}
            {kind === 'ios' && (
              <>
                <p>{t('L’appli {app} pour iPhone n’est pas encore sur l’App Store : le bureau vous l’installe. Votre compte est prêt : vous vous y connecterez avec {email} et votre mot de passe.', { app, email: done.me.user.email })}</p>
                <a className="small" href="/">{t('En attendant, ouvrir {app} dans Safari', { app })}</a>
              </>
            )}
            {kind === 'desktop' && (
              <>
                <p>{t('Votre compte est prêt. Pour l’appli, connectez-vous dessus avec {email} et votre mot de passe.', { email: done.me.user.email })}</p>
                <a className="button secondary invite-step" href="/">{t('Ouvrir le logiciel du bureau')}</a>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Lien « Ouvrir l'appli » ouvert dans le navigateur : l'appli n'est pas encore installée (ou le téléphone n'a pas
 * encore reconnu le lien). On propose de la télécharger. Le code n'est pas utilisé ici : il ne sert qu'à l'appli.
 */
export function OpenAppPage() {
  const app = CLIENT?.name ?? PRODUCT_NAME;
  const apk = useApkUrl();
  const kind = device();
  return (
    <div className="login">
      <div className="card stack">
        {CLIENT ? <img className="login-logo" src={CLIENT.logo} alt={CLIENT.name} /> : <h1>{PRODUCT_NAME}</h1>}
        <h2>{t('Ouvrir l’appli {app}', { app })}</h2>
        <p>{t('Ce lien s’ouvre dans l’appli quand elle est installée. Installez-la, puis revenez sur la page d’invitation et touchez de nouveau « Ouvrir l’appli », ou connectez-vous dans l’appli avec votre e-mail et votre mot de passe.')}</p>
        {kind === 'android' ? <AndroidSteps apk={apk} app={app} /> : (
          <p className="small muted">{t('L’appli {app} pour iPhone n’est pas encore sur l’App Store : le bureau vous l’installe.', { app })}</p>
        )}
      </div>
    </div>
  );
}
