import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { UI_LOCALE_LABELS, UI_LOCALES, type DueState, type UiLocale } from '@itineo/shared';
import { api, setToken } from '../api';
import { disablePush, enablePush, isPushActive, needsHomeScreen, pushSupported } from '../push';
import { isNativeApp } from '../native';
import { useAuth } from '../auth';
import { DueBadge } from '../components/DueBadge';
import { fmtDay } from '../format';
import { t } from '../i18n';
import { useLocationSharing } from '../tech/location';
import { useInField } from '../tech/FieldShell';

/** Véhicule dont on est le conducteur : relevé du compteur */
function MyVehicle() {
  const [vehicle, setVehicle] = useState<{ id: string; plate: string; make: string | null; model: string | null; mileage: number | null } | null>(null);
  const [value, setValue] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const load = () => api<{ vehicle: typeof vehicle }>('/fleet/my-vehicle').then((r) => setVehicle(r.vehicle)).catch(() => undefined);
  useEffect(() => {
    void load();
  }, []);
  if (!vehicle) return null;
  return (
    <div className="card stack">
      <h2 style={{ fontSize: 18 }}>{t('Mon véhicule')} · {vehicle.plate}</h2>
      <div className="small muted">{[vehicle.make, vehicle.model].filter(Boolean).join(' ')} · {t('Kilométrage')} : {vehicle.mileage?.toLocaleString() ?? '—'} km</div>
      <div className="row" style={{ alignItems: 'flex-end' }}>
        <div className="field grow"><label htmlFor="my-km">{t('Nouveau relevé (km)')}</label><input id="my-km" inputMode="numeric" value={value} onChange={(e) => setValue(e.target.value)} /></div>
        <button type="button" disabled={!value.trim()} onClick={() => {
          setMsg(null);
          void api(`/fleet/vehicles/${vehicle.id}/mileage`, { method: 'POST', body: { mileage: Number(value.replace(/\s/g, '')) } })
            .then(async () => { setValue(''); setMsg(t('Kilométrage enregistré.')); await load(); }).catch((e) => setMsg((e as Error).message));
        }}>{t('Enregistrer')}</button>
      </div>
      {msg && <p className="small" role="status">{msg}</p>}
      <LocationToggle />
    </div>
  );
}

/** Partage de la position du véhicule : c'est le technicien qui décide, et il peut arrêter à tout moment */
function LocationToggle() {
  const loc = useLocationSharing();
  const [error, setError] = useState<string | null>(null);
  if (!loc.loaded || !loc.supported) return null;
  return (
    <div className="stack" style={{ gap: 6, borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <strong className="small">{t('Partage de ma position')}</strong>
      <span className="small muted">{loc.enabled
        ? t('Activé : le bureau voit la position de votre véhicule pendant que l’appli est ouverte. Historique effacé après {n} jours.', { n: loc.retentionDays })
        : t('Désactivé : le bureau ne voit pas la position de votre véhicule.')}</span>
      {error && <span className="error small">{error}</span>}
      <div><button type="button" className={loc.enabled ? 'secondary' : ''} onClick={() => {
        setError(null);
        loc.setEnabled(!loc.enabled).catch((e) => setError((e as Error).message));
      }}>{loc.enabled ? t('Arrêter le partage') : t('Activer le partage')}</button></div>
    </div>
  );
}

function MyCertifications({ userId }: { userId: string }) {
  const [list, setList] = useState<{ id: string; name: string; expiresOn: string | null; state: DueState }[] | null>(null);
  useEffect(() => {
    void api<typeof list>(`/certifications/user/${userId}`).then(setList).catch(() => setList(null));
  }, [userId]);
  if (!list) return null;
  return (
    <div className="card stack">
      <h2 style={{ fontSize: 18 }}>{t('Mes habilitations')}</h2>
      {list.length ? list.map((c) => (
        <div key={c.id} className="row small" style={{ justifyContent: 'space-between' }}>
          <span>{c.name}</span>
          <DueBadge state={c.state} label={c.expiresOn
            ? t(c.state === 'OVERDUE' ? 'expirée le {date}' : c.state === 'SOON' ? 'à renouveler : {date}' : "valable jusqu'au {date}", { date: fmtDay(c.expiresOn) })
            : t('sans limite')} />
        </div>
      )) : <p className="small muted">{t('Aucune habilitation enregistrée.')}</p>}
    </div>
  );
}

/** Langue de l'interface : la page est rechargée pour tout afficher dans la nouvelle langue */
function MyLanguage({ current }: { current: string }) {
  const [error, setError] = useState<string | null>(null);
  const value = UI_LOCALES.find((l) => l.slice(0, 2) === current.slice(0, 2)) ?? 'fr-FR';
  return (
    <div className="card stack">
      <div className="field">
        <label htmlFor="my-lang">{t('Langue')}</label>
        <select id="my-lang" value={value} onChange={(e) => {
          setError(null);
          void api('/me', { method: 'PATCH', body: { locale: e.target.value as UiLocale } })
            .then(() => window.location.reload()).catch((err) => setError((err as Error).message));
        }}>
          {UI_LOCALES.map((l) => <option key={l} value={l}>{UI_LOCALE_LABELS[l]}</option>)}
        </select>
      </div>
      {error && <p className="error small" role="alert">{error}</p>}
    </div>
  );
}

/** Numéro de téléphone professionnel : affiché à l'équipe dans l'annuaire */
function MyPhone({ current }: { current: string }) {
  const [phone, setPhone] = useState(current);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const save = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);
    try {
      await api('/me', { method: 'PATCH', body: { phone } });
      setSaved(true);
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={save}>
      <div className="field">
        <label htmlFor="my-phone">{t('Mon numéro de téléphone')}</label>
        <input id="my-phone" type="tel" autoComplete="tel" maxLength={40} value={phone} onChange={(e) => { setPhone(e.target.value); setSaved(false); }} />
        <span className="small muted">{t('Visible par vos collègues dans l’annuaire.')}</span>
      </div>
      {error && <p className="error small" role="alert">{error}</p>}
      {saved && <p className="success small">{t('Numéro enregistré.')}</p>}
      <div className="row"><button type="submit" className="secondary">{t('Enregistrer')}</button></div>
    </form>
  );
}

/** Notifications : sur cet appareil (même appli fermée) et/ou par e-mail */
function MyNotifications() {
  const { has } = useAuth();
  const [config, setConfig] = useState<{ publicKey: string; prefs: Record<string, boolean> } | null>(null);
  const [active, setActive] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => {
    api<{ publicKey: string; prefs: Record<string, boolean> }>('/notifications/config').then(setConfig).catch(() => undefined);
    void isPushActive().then(setActive).catch(() => undefined);
  }, []);
  const turnOn = async () => {
    setMsg(null);
    try {
      if (await enablePush(config!.publicKey)) {
        setActive(true);
        setMsg({ ok: true, text: t('Notifications activées sur cet appareil.') });
      } else setMsg({ ok: false, text: isNativeApp() ? t('Notifications refusées : autorisez-les pour cette appli dans les réglages du téléphone.') : t('Notifications refusées : autorisez-les dans les réglages du navigateur pour ce site.') });
    } catch (e) {
      setMsg({ ok: false, text: (e as Error).message });
    }
  };
  const turnOff = async () => {
    await disablePush();
    setActive(false);
  };
  const setPref = async (key: string, value: boolean) => {
    if (!config) return;
    setConfig({ ...config, prefs: { ...config.prefs, [key]: value } });
    await api('/notifications/prefs', { method: 'PATCH', body: { [key]: value } }).catch((e) => setMsg({ ok: false, text: (e as Error).message }));
  };
  const test = async () => {
    await api('/notifications/test', { method: 'POST' });
    setMsg({ ok: true, text: t('Notification d’essai envoyée.') });
  };
  if (!config) return null;
  const events: { id: string; label: string; show: boolean }[] = [
    { id: 'message', label: t('Nouveaux messages'), show: true },
    { id: 'assignment', label: t('Intervention qui m’est attribuée ou déplacée'), show: has('report.write.own') },
    { id: 'procedure', label: t('Document proposé à valider'), show: has('procedure.manage') },
    { id: 'completed', label: t('Intervention terminée'), show: has('intervention.assign') },
    { id: 'followup', label: t('Intervention à reprendre'), show: has('intervention.assign') },
    { id: 'late', label: t('Technicien en retard'), show: has('intervention.assign') },
    { id: 'request', label: t('Demande d’un client (espace client)'), show: has('intervention.assign') },
    { id: 'quote', label: t('Réponse d’un client à un devis'), show: has('quote.read') },
  ];
  return (
    <section className="card stack">
      <h2 style={{ fontSize: 18 }}>{t('Notifications')}</h2>
      {!pushSupported() ? (
        <p className="small muted">{t('Ce navigateur ne reçoit pas de notifications. Vous pouvez choisir de les recevoir par e-mail.')}</p>
      ) : needsHomeScreen() ? (
        <p className="small muted">{t('Sur iPhone : ajoutez d’abord Itinéos à l’écran d’accueil (bouton Partager → « Sur l’écran d’accueil »), ouvrez-le depuis l’icône, puis revenez ici.')}</p>
      ) : active ? (
        <div className="row" style={{ gap: 6 }}>
          <span className="badge ok">{t('Activées sur cet appareil')}</span>
          <button type="button" className="ghost" onClick={() => void test()}>{t('Envoyer un essai')}</button>
          <button type="button" className="ghost" onClick={() => void turnOff()}>{t('Désactiver')}</button>
        </div>
      ) : (
        <button type="button" className="accent" onClick={() => void turnOn()}>{t('Recevoir les notifications sur cet appareil')}</button>
      )}
      <table className="small notif-table">
        <thead><tr><th /><th>{t('Appareil')}</th><th>{t('E-mail')}</th></tr></thead>
        <tbody>
          {events.filter((e) => e.show).map((e) => (
            <tr key={e.id}>
              <td>{e.label}</td>
              <td><input type="checkbox" aria-label={`${e.label} : ${t('Appareil')}`} checked={!!config.prefs[`push_${e.id}`]} onChange={(ev) => void setPref(`push_${e.id}`, ev.target.checked)} /></td>
              <td><input type="checkbox" aria-label={`${e.label} : ${t('E-mail')}`} checked={!!config.prefs[`email_${e.id}`]} onChange={(ev) => void setPref(`email_${e.id}`, ev.target.checked)} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      {msg && <p className={msg.ok ? 'success' : 'error'} role="status">{msg.text}</p>}
    </section>
  );
}

/** « Déconnecter tous mes appareils » : téléphone perdu, tablette prêtée… (cet appareil reste connecté) */
function MyDevices() {
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const run = async () => {
    if (!window.confirm(t('Fermer la session Itinéos sur tous vos autres appareils (téléphone, tablette, ordinateur) ?'))) return;
    try {
      const res = await api<{ token: string }>('/auth/logout-all', { method: 'POST' });
      setToken(res.token);
      setMsg({ ok: true, text: t('Vos autres appareils sont déconnectés.') });
    } catch (e) {
      setMsg({ ok: false, text: (e as Error).message });
    }
  };
  return (
    <section className="card stack">
      <h2 style={{ fontSize: 18 }}>{t('Mes appareils')}</h2>
      <p className="muted small">{t('Avec « Rester connecté », la session dure un an et se prolonge à chaque ouverture. Un appareil perdu ? Déconnectez-le d’ici.')}</p>
      <button type="button" className="secondary" onClick={() => void run()}>{t('Déconnecter tous mes autres appareils')}</button>
      {msg && <p className={msg.ok ? 'success' : 'error'} role="status">{msg.text}</p>}
    </section>
  );
}

/** Compte de l'utilisateur connecté (bureau et appli terrain) */
export function AccountPage() {
  const { me, has } = useAuth();
  const inField = useInField();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setDone(false);
    if (next !== confirm) {
      setError(t('Les deux mots de passe ne sont pas identiques'));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ token: string }>('/auth/change-password', {
        method: 'POST',
        body: { currentPassword: current, newPassword: next },
      });
      // L'ancienne session n'est plus acceptée : on garde la nouvelle
      setToken(res.token);
      setCurrent('');
      setNext('');
      setConfirm('');
      setDone(true);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={inField ? 'account-field' : 'login'}>
      <div className="stack" style={{ width: '100%', maxWidth: inField ? 640 : 400 }}>
      {has('fleet.read.own') || has('fleet.read') ? <MyVehicle /> : null}
      {me && (has('certification.read.own') || has('certification.read')) && <MyCertifications userId={me.user.id} />}
      <form className="card" onSubmit={submit}>
        {/* Dans l'appli terrain, le titre et le retour sont dans la barre du haut */}
        {!inField && <Link to="/" className="small">{t('← Retour')}</Link>}
        {!inField && <h1>{t('Mon compte')}</h1>}
        <p className="muted">
          {me?.user.firstName} {me?.user.lastName}
          <br />
          <span className="small">{me?.user.email}</span>
        </p>
        <h2 style={{ fontSize: 18 }}>{t('Changer mon mot de passe')}</h2>
        <div className="field">
          <label htmlFor="current-password">{t('Mot de passe actuel')}</label>
          <input id="current-password" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="new-password">{t('Nouveau mot de passe')}</label>
          <input id="new-password" type="password" autoComplete="new-password" minLength={8} value={next} onChange={(e) => setNext(e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="confirm-password">{t('Confirmer le nouveau mot de passe')}</label>
          <input id="confirm-password" type="password" autoComplete="new-password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
        </div>
        <p className="muted small">{t('Au moins 8 caractères. Vos sessions sur les autres appareils seront fermées.')}</p>
        {error && <p className="error" role="alert">{error}</p>}
        {done && <p className="success" role="status">{t('Mot de passe changé.')}</p>}
        <button type="submit" className="big" disabled={busy}>{busy ? t('Enregistrement…') : t('Enregistrer')}</button>
      </form>
      {me && <MyLanguage current={me.user.locale} />}
      {me && <MyPhone current={me.user.phone ?? ''} />}
      <MyNotifications />
      <MyDevices />
      </div>
    </div>
  );
}
