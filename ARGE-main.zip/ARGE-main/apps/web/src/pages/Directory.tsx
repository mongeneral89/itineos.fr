/**
 * Annuaire : l'équipe (numéros renseignés par chacun dans « Mon compte »), les standards des sociétés et agences,
 * et les contacts utiles (fournisseurs, sous-traitants, assistance des fabricants, urgences…).
 */
import { useMemo, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { DIRECTORY_CATEGORIES, DIRECTORY_CATEGORY_LABELS, type DirectoryCategory } from '@itineo/shared';
import { api } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { t, tl, tp } from '../i18n';

interface Place { id: string; name: string; phone: string | null; email: string | null; address: string | null; postalCode: string | null; city: string | null }
interface Staff { id: string; firstName: string; lastName: string; phone: string | null; email: string; skills: string[]; roles: string[]; companyIds: string[]; agencyIds: string[] }
export interface DirectoryContact {
  id: string; companyId: string | null; agencyId: string | null; category: DirectoryCategory; name: string;
  organization: string | null; phone: string | null; mobile: string | null; email: string | null;
  address: string | null; website: string | null; notes: string | null; canEdit: boolean;
}
interface DirectoryData { companies: Place[]; agencies: (Place & { companyId: string })[]; staff: Staff[]; contacts: DirectoryContact[] }

type Tab = 'team' | 'contacts' | 'offices';
const TAB_KEY = 'itineo.directory.tab';

/** Lien d'appel : on garde les chiffres et le « + » */
const tel = (n: string) => `tel:${n.replace(/[^\d+]/g, '')}`;

function Phone({ n, label }: { n: string | null; label?: string }) {
  if (!n) return null;
  return <a className="dir-phone" href={tel(n)} aria-label={`${label ?? t('Appeler')} ${n}`}>☎ {n}</a>;
}

const match = (q: string, ...parts: (string | null | undefined)[]) => !q || parts.filter(Boolean).join(' ').toLowerCase().includes(q);

export function DirectoryPage() {
  const { me, has } = useAuth();
  const [tab, setTabState] = useState<Tab>(() => {
    try {
      const v = localStorage.getItem(TAB_KEY);
      return v === 'contacts' || v === 'offices' ? v : 'team';
    } catch {
      return 'team';
    }
  });
  const [q, setQ] = useState('');
  const [place, setPlace] = useState('');
  const { data, error, loading, reload } = useLoad(() => api<DirectoryData>('/directory'), []);

  const setTab = (v: Tab) => {
    setTabState(v);
    try {
      localStorage.setItem(TAB_KEY, v);
    } catch {
      /* ignoré */
    }
  };

  const companyName = useMemo(() => new Map((data?.companies ?? []).map((c) => [c.id, c.name])), [data]);
  const agencyName = useMemo(() => new Map((data?.agencies ?? []).map((a) => [a.id, a.name])), [data]);
  const search = q.trim().toLowerCase();
  // Filtre par lieu : « c:<société> » ou « a:<agence> »
  const inPlace = (companyIds: (string | null)[], agencyIds: (string | null)[]) => {
    if (!place) return true;
    const [kind, id] = place.split(':');
    return kind === 'c' ? companyIds.includes(id) : agencyIds.includes(id);
  };

  const staff = (data?.staff ?? []).filter((s) => match(search, s.firstName, s.lastName, s.phone, s.email, s.roles.map((r) => t(r)).join(' '), s.skills.join(' '),
    ...s.agencyIds.map((a) => agencyName.get(a)), ...s.companyIds.map((c) => companyName.get(c))))
    .filter((s) => inPlace(s.companyIds, s.agencyIds));
  const contacts = (data?.contacts ?? []).filter((c) => match(search, c.name, c.organization, c.phone, c.mobile, c.email, c.notes, tl(DIRECTORY_CATEGORY_LABELS, c.category)))
    .filter((c) => !place || !c.companyId || inPlace([c.companyId], [c.agencyId]));
  const companies = (data?.companies ?? []).filter((c) => match(search, c.name, c.phone, c.email, c.city)).filter((c) => inPlace([c.id], []));
  const agencies = (data?.agencies ?? []).filter((a) => match(search, a.name, a.phone, a.email, a.city, companyName.get(a.companyId)))
    .filter((a) => inPlace([a.companyId], [a.id]));

  const TABS: { id: Tab; label: string; n: number }[] = [
    { id: 'team', label: 'Équipe', n: staff.length },
    { id: 'contacts', label: 'Contacts utiles', n: contacts.length },
    { id: 'offices', label: 'Sociétés et agences', n: companies.length + agencies.length },
  ];

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{t('Numéros de l’équipe, des agences et des contacts utiles')}</div>
          <h1>{t('Annuaire')}</h1>
        </div>
      </div>
      <div className="row">
        <div className="chips" role="tablist" aria-label={t('Rubriques de l’annuaire')}>
          {TABS.map((x) => (
            <button key={x.id} type="button" role="tab" aria-selected={tab === x.id} className={`chip${tab === x.id ? ' on' : ''}`} onClick={() => setTab(x.id)}>
              {t(x.label)} <span className="muted small">({x.n})</span>
            </button>
          ))}
        </div>
        <input type="search" style={{ width: 240 }} placeholder={t('Rechercher : nom, numéro, métier…')} aria-label={t('Rechercher dans l’annuaire')} value={q} onChange={(e) => setQ(e.target.value)} />
        {data && (data.companies.length > 1 || data.agencies.length > 1) && (
          <select style={{ width: 'auto' }} value={place} aria-label={t('Société ou agence')} onChange={(e) => setPlace(e.target.value)}>
            <option value="">{t('Toutes les sociétés et agences')}</option>
            {data.companies.map((c) => (
              <optgroup key={c.id} label={c.name}>
                <option value={`c:${c.id}`}>{t('Toute la société {name}', { name: c.name })}</option>
                {data.agencies.filter((a) => a.companyId === c.id).map((a) => <option key={a.id} value={`a:${a.id}`}>{a.name}</option>)}
              </optgroup>
            ))}
          </select>
        )}
      </div>
      {error && <p className="error">{error}</p>}
      {loading && !data && <p className="muted">{t('Chargement…')}</p>}

      {data && tab === 'team' && (
        <section className="card stack">
          {!staff.length && <p className="muted">{t('Personne ne correspond à la recherche.')}</p>}
          <p className="small muted">{t('Chacun renseigne son numéro dans « Mon compte ».')}</p>
          <div className="dir-grid">
            {staff.map((s) => (
              <div key={s.id} className="dir-card">
                <strong>{s.firstName} {s.lastName}</strong>
                <span className="small muted">
                  {[s.roles.map((r) => t(r)).join(', '), [...s.agencyIds.map((a) => agencyName.get(a)), ...(s.agencyIds.length ? [] : s.companyIds.map((c) => companyName.get(c)))].filter(Boolean).join(', ')].filter(Boolean).join(' · ')}
                </span>
                {s.skills.length > 0 && <span className="small">{s.skills.join(' · ')}</span>}
                {s.phone ? <Phone n={s.phone} /> : <span className="small muted">{t('Pas de numéro renseigné')}</span>}
                <a className="small" href={`mailto:${s.email}`}>{s.email}</a>
                {s.id !== me?.user.id && <Link className="btn secondary dir-write" to={`/messages?with=${s.id}`}>{t('Écrire')}</Link>}
              </div>
            ))}
          </div>
        </section>
      )}

      {data && tab === 'contacts' && (
        <ContactsTab contacts={contacts} data={data} canAdd={has('directory.write')} onChanged={reload} companyName={companyName} agencyName={agencyName} />
      )}

      {data && tab === 'offices' && (
        <section className="card stack">
          {!companies.length && !agencies.length && <p className="muted">{t('Rien ne correspond à la recherche.')}</p>}
          <div className="dir-grid">
            {companies.map((c) => <OfficeCard key={c.id} p={c} sub={t('Société')} />)}
            {agencies.map((a) => <OfficeCard key={a.id} p={a} sub={companyName.get(a.companyId) ?? ''} />)}
          </div>
        </section>
      )}
    </>
  );
}

function OfficeCard({ p, sub }: { p: Place; sub: string }) {
  const address = [p.address, [p.postalCode, p.city].filter(Boolean).join(' ')].filter(Boolean).join(', ');
  return (
    <div className="dir-card">
      <strong>{p.name}</strong>
      <span className="small muted">{sub}</span>
      {p.phone ? <Phone n={p.phone} /> : <span className="small muted">{t('Pas de numéro renseigné')}</span>}
      {p.email && <a className="small" href={`mailto:${p.email}`}>{p.email}</a>}
      {address && <span className="small">{address}</span>}
    </div>
  );
}

function ContactsTab({ contacts, data, canAdd, onChanged, companyName, agencyName }: {
  contacts: DirectoryContact[]; data: DirectoryData; canAdd: boolean; onChanged: () => void;
  companyName: Map<string, string>; agencyName: Map<string, string>;
}) {
  const [editing, setEditing] = useState<DirectoryContact | 'new' | null>(null);
  const scopeLabel = (c: DirectoryContact) => (c.agencyId ? agencyName.get(c.agencyId) : c.companyId ? companyName.get(c.companyId) : t('Tout le groupe'));

  const remove = async (c: DirectoryContact) => {
    if (!window.confirm(t('Supprimer « {name} » de l’annuaire ?', { name: c.name }))) return;
    await api(`/directory/contacts/${c.id}`, { method: 'DELETE' });
    onChanged();
  };

  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <p className="small muted">{tp(contacts.length, '{n} contact', '{n} contacts')}</p>
        {canAdd && !editing && <button type="button" className="accent" onClick={() => setEditing('new')}>{t('Nouveau contact')}</button>}
      </div>
      {editing && (
        <ContactForm initial={editing === 'new' ? null : editing} data={data} onCancel={() => setEditing(null)} onSaved={() => { setEditing(null); onChanged(); }} />
      )}
      {!contacts.length && !editing && (
        <p className="muted">{canAdd ? t('Aucun contact pour l’instant : ajoutez vos fournisseurs, sous-traitants et numéros utiles.') : t('Aucun contact pour l’instant.')}</p>
      )}
      {DIRECTORY_CATEGORIES.map((cat) => {
        const list = contacts.filter((c) => c.category === cat);
        if (!list.length) return null;
        return (
          <div key={cat} className="stack" style={{ gap: 8 }}>
            <h2 style={{ fontSize: 16 }}>{tl(DIRECTORY_CATEGORY_LABELS, cat)} <span className="muted small">({list.length})</span></h2>
            <div className="dir-grid">
              {list.map((c) => (
                <div key={c.id} className="dir-card">
                  <strong>{c.name}</strong>
                  {c.organization && <span>{c.organization}</span>}
                  <span className="small muted">{scopeLabel(c)}</span>
                  <Phone n={c.phone} />
                  <Phone n={c.mobile} />
                  {c.email && <a className="small" href={`mailto:${c.email}`}>{c.email}</a>}
                  {c.website && <a className="small" href={/^https?:\/\//.test(c.website) ? c.website : `https://${c.website}`} target="_blank" rel="noreferrer">{c.website}</a>}
                  {c.address && <span className="small">{c.address}</span>}
                  {c.notes && <span className="small" style={{ whiteSpace: 'pre-wrap' }}>{c.notes}</span>}
                  {c.canEdit && (
                    <span className="row" style={{ gap: 6 }}>
                      <button type="button" className="ghost" onClick={() => setEditing(c)}>{t('Modifier')}</button>
                      <button type="button" className="ghost" onClick={() => void remove(c)}>{t('Supprimer')}</button>
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </section>
  );
}

function ContactForm({ initial, data, onCancel, onSaved }: { initial: DirectoryContact | null; data: DirectoryData; onCancel: () => void; onSaved: () => void }) {
  const { company, agency } = useAuth();
  const [f, setF] = useState({
    category: initial?.category ?? ('SUPPLIER' as DirectoryCategory),
    name: initial?.name ?? '', organization: initial?.organization ?? '', phone: initial?.phone ?? '', mobile: initial?.mobile ?? '',
    email: initial?.email ?? '', address: initial?.address ?? '', website: initial?.website ?? '', notes: initial?.notes ?? '',
    // Périmètre : « g » (tout le groupe), « c:<société> » ou « a:<société>:<agence> »
    scope: initial
      ? initial.agencyId ? `a:${initial.companyId}:${initial.agencyId}` : initial.companyId ? `c:${initial.companyId}` : 'g'
      : agency && company ? `a:${company.id}:${agency.id}` : company ? `c:${company.id}` : 'g',
  });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const [kind, companyId, agencyId] = f.scope.split(':');
    const { scope: _s, ...rest } = f;
    const body = { ...rest, companyId: kind === 'g' ? null : companyId, agencyId: kind === 'a' ? agencyId : null };
    try {
      await api(initial ? `/directory/contacts/${initial.id}` : '/directory/contacts', { method: initial ? 'PATCH' : 'POST', body });
      onSaved();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="stack dir-form" onSubmit={submit}>
      <h2 style={{ fontSize: 17 }}>{initial ? t('Modifier le contact') : t('Nouveau contact')}</h2>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div className="field grow">
          <label htmlFor="dc-cat">{t('Catégorie')}</label>
          <select id="dc-cat" value={f.category} onChange={set('category')}>
            {DIRECTORY_CATEGORIES.map((c) => <option key={c} value={c}>{tl(DIRECTORY_CATEGORY_LABELS, c)}</option>)}
          </select>
        </div>
        <div className="field grow">
          <label htmlFor="dc-scope">{t('Visible par')}</label>
          <select id="dc-scope" value={f.scope} onChange={set('scope')}>
            <option value="g">{t('Tout le groupe')}</option>
            {data.companies.map((c) => (
              <optgroup key={c.id} label={c.name}>
                <option value={`c:${c.id}`}>{t('Toute la société {name}', { name: c.name })}</option>
                {data.agencies.filter((a) => a.companyId === c.id).map((a) => <option key={a.id} value={`a:${c.id}:${a.id}`}>{a.name}</option>)}
              </optgroup>
            ))}
          </select>
        </div>
      </div>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div className="field grow">
          <label htmlFor="dc-name">{t('Nom (personne ou service)')}</label>
          <input id="dc-name" value={f.name} onChange={set('name')} required maxLength={120} placeholder={t('Ex. : Service après-vente')} />
        </div>
        <div className="field grow">
          <label htmlFor="dc-org">{t('Entreprise')}</label>
          <input id="dc-org" value={f.organization} onChange={set('organization')} placeholder={t('Ex. : Daikin France')} />
        </div>
      </div>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div className="field grow"><label htmlFor="dc-phone">{t('Téléphone')}</label><input id="dc-phone" type="tel" value={f.phone} onChange={set('phone')} /></div>
        <div className="field grow"><label htmlFor="dc-mobile">{t('Portable')}</label><input id="dc-mobile" type="tel" value={f.mobile} onChange={set('mobile')} /></div>
        <div className="field grow"><label htmlFor="dc-email">{t('E-mail')}</label><input id="dc-email" type="email" value={f.email} onChange={set('email')} /></div>
      </div>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div className="field grow"><label htmlFor="dc-address">{t('Adresse')}</label><input id="dc-address" value={f.address} onChange={set('address')} /></div>
        <div className="field grow"><label htmlFor="dc-web">{t('Site web')}</label><input id="dc-web" value={f.website} onChange={set('website')} /></div>
      </div>
      <div className="field">
        <label htmlFor="dc-notes">{t('Notes (horaires, n° de client, code d’accès…)')}</label>
        <textarea id="dc-notes" rows={2} value={f.notes} onChange={set('notes')} />
      </div>
      {error && <p className="error small">{error}</p>}
      <div className="row">
        <button type="submit" disabled={busy}>{initial ? t('Enregistrer') : t('Ajouter à l’annuaire')}</button>
        <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
      </div>
    </form>
  );
}
