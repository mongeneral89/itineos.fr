import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { addDays, formatMoney, PAYMENT_STATE_LABELS, type PaymentState } from '@itineo/shared';
import { api, downloadFile, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { fmtDay, toDateInput } from '../format';
import type { InvoiceRow } from '../types';
import { t, tl } from '../i18n';

const STATE_TONES: Record<PaymentState, string> = { DRAFT: 'neutral', UNPAID: 'info', PARTIAL: 'info', PAID: 'ok', OVERDUE: 'warn' };

export function InvoiceStateBadge({ state, credit }: { state: PaymentState; credit?: boolean }) {
  if (credit && state !== 'DRAFT') return <span className="badge neutral">{t('Avoir émis')}</span>;
  return <span className={`badge ${STATE_TONES[state]}`}>{tl(PAYMENT_STATE_LABELS, state)}</span>;
}

// Libellés en français, traduits à l'affichage
const FILTERS: { value: '' | 'OPEN' | PaymentState; label: string }[] = [
  { value: '', label: 'Toutes' },
  { value: 'OPEN', label: 'À encaisser' },
  { value: 'OVERDUE', label: 'En retard' },
  { value: 'PAID', label: 'Payées' },
  { value: 'DRAFT', label: 'Brouillons' },
];

export function InvoicesPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [state, setState] = useState<'' | 'OPEN' | PaymentState>('');
  const [q, setQ] = useState('');
  const { data, error, loading } = useLoad(
    () => (company ? api<InvoiceRow[]>(`/invoices${qs({ companyId: company.id, agencyId: agency?.id, state, q })}`) : Promise.resolve([])),
    [company?.id, agency?.id, state, q],
  );
  const rows = data ?? [];
  const money = (c: number, cur = company?.currency ?? 'EUR') => formatMoney(c, cur, company?.locale);
  const toCollect = rows.filter((r) => r.kind === 'INVOICE').reduce((s, r) => s + r.remainingCents, 0);
  const late = rows.filter((r) => r.state === 'OVERDUE').reduce((s, r) => s + r.remainingCents, 0);

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Factures')}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="row">
        <input style={{ maxWidth: 300 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Rechercher : n°, objet, client')} aria-label={t('Rechercher une facture')} />
        <div className="chips" role="radiogroup" aria-label={t('Filtrer')}>
          {FILTERS.map((f) => (
            <button key={f.value} type="button" role="radio" aria-checked={state === f.value} className={`chip${state === f.value ? ' on' : ''}`} onClick={() => setState(f.value)}>{t(f.label)}</button>
          ))}
        </div>
        <div className="grow" />
        {has('invoice.write') && <button type="button" className="accent" onClick={() => navigate('/invoices/new')}>{t('Nouvelle facture')}</button>}
      </div>
      {company && (
        <div className="row small">
          <span>{t('Reste à encaisser :')} <strong>{money(toCollect)}</strong> {t('TTC')}</span>
          {late > 0 && <span className="badge warn">{t('dont {amount} en retard', { amount: money(late) })}</span>}
        </div>
      )}
      {error && <p className="error">{error}</p>}
      <section className="card">
        {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('N°')}</th><th>{t('Client')}</th><th>{t('Objet')}</th><th>{t('Date')}</th><th>{t('Échéance')}</th><th style={{ textAlign: 'right' }}>{t('Total TTC')}</th><th style={{ textAlign: 'right' }}>{t('Reste')}</th><th>{t('État')}</th></tr></thead>
              <tbody>
                {rows.map((r) => {
                  const credit = r.kind === 'CREDIT_NOTE';
                  return (
                    <tr key={r.id} className="clickable" onClick={() => navigate(`/invoices/${r.id}`)}>
                      <td><Link to={`/invoices/${r.id}`} onClick={(e) => e.stopPropagation()}><strong>{r.number ?? t('Brouillon')}</strong></Link>{credit && <div className="small muted">{t('Avoir')}</div>}</td>
                      <td>{r.clientName}</td>
                      <td>{r.title}</td>
                      <td className="small">{fmtDay(r.issueDate)}</td>
                      <td className="small">{credit ? '—' : fmtDay(r.dueDate)}</td>
                      <td style={{ textAlign: 'right' }}>{credit ? '− ' : ''}{money(r.grossCents, r.currency)}</td>
                      <td style={{ textAlign: 'right' }}>{r.remainingCents ? money(r.remainingCents, r.currency) : '—'}</td>
                      <td><InvoiceStateBadge state={r.state} credit={credit} /></td>
                    </tr>
                  );
                })}
                {data && !rows.length && <tr><td colSpan={8} className="muted">{t('Aucune facture.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
      {company && <ExportPanel />}
    </>
  );
}

/** Export pour le comptable : journal des ventes et liste des factures sur une période */
function ExportPanel() {
  const { company } = useAuth();
  const now = new Date();
  const [from, setFrom] = useState(toDateInput(new Date(now.getFullYear(), now.getMonth() - 1, 1)));
  const [to, setTo] = useState(addDays(toDateInput(new Date(now.getFullYear(), now.getMonth(), 1)), -1));
  const [error, setError] = useState<string | null>(null);
  if (!company) return null;
  const get = (format: 'journal' | 'list') => {
    setError(null);
    downloadFile(`/invoices/export${qs({ companyId: company.id, from, to, format })}`, `${format}.csv`).catch((e) => setError((e as Error).message));
  };
  /** Factures électroniques de la période (PDF Factur-X) dans un .zip */
  const exportFacturx = () => {
    if (!company) return;
    setError(null);
    downloadFile(`/invoices/export/facturx${qs({ companyId: company.id, from, to })}`, 'factur-x.zip').catch((e) => setError((e as Error).message));
  };
  return (
    <section className="card stack">
      <h2>{t('Export comptable')}</h2>
      <p className="small muted" style={{ margin: 0 }}>
        {t('Factures et avoirs émis sur la période, pour {name}. Fichiers CSV lisibles par Excel et importables dans les logiciels comptables (journal des ventes : comptes 411, 706 et 44571).', { name: company.name })}
      </p>
      <div className="row">
        <div className="field"><label htmlFor="ex-from">{t('Du')}</label><input id="ex-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div className="field"><label htmlFor="ex-to">{t('Au')}</label><input id="ex-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <button type="button" onClick={() => get('journal')}>{t('Journal des ventes')}</button>
        <button type="button" className="secondary" onClick={() => get('list')}>{t('Liste des factures')}</button>
        <button type="button" className="secondary" onClick={exportFacturx}>{t('Factures électroniques (Factur-X, .zip)')}</button>
      </div>
      {error && <p className="error">{error}</p>}
    </section>
  );
}
