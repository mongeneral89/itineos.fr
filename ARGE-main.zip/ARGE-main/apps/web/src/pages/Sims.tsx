/**
 * Cartes SIM : inventaire, client et site de chaque carte, suivi de l'activation.
 * L'activation se fait sur le site du prestataire (bouton qui l'ouvre, numéro de carte copié d'un geste) ;
 * on note ensuite ici « activation demandée » puis « active ».
 */
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { SIM_STATUS_LABELS, SIM_STATUSES, type SimStatus } from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { fmtDate } from '../format';
import { t, tl, tp } from '../i18n';

interface SimCard {
  id: string; companyId: string; agencyId: string | null; iccid: string; phoneNumber: string | null;
  operator: string | null; plan: string | null; status: SimStatus; clientId: string | null; siteId: string | null;
  device: string | null; requestedAt: string | null; activatedAt: string | null; terminatedAt: string | null;
  notes: string | null; clientName: string | null; siteName: string | null; siteCity: string | null; updatedAt: string;
}
interface SimData { provider: string | null; portalUrl: string | null; canWrite: boolean; cards: SimCard[] }

const BADGE: Record<SimStatus, string> = {
  STOCK: 'neutral', TO_ACTIVATE: 'warn', REQUESTED: 'warn', ACTIVE: 'ok', SUSPENDED: 'danger', TERMINATED: 'neutral',
};
/** Étape suivante proposée sur chaque carte */
const NEXT: Partial<Record<SimStatus, SimStatus[]>> = {
  STOCK: ['TO_ACTIVATE'],
  TO_ACTIVATE: ['REQUESTED', 'ACTIVE'],
  REQUESTED: ['ACTIVE'],
  ACTIVE: ['SUSPENDED', 'TERMINATED'],
  SUSPENDED: ['ACTIVE', 'TERMINATED'],
};
const ACTION_LABEL: Record<SimStatus, string> = {
  STOCK: 'Remettre en stock',
  TO_ACTIVATE: 'À activer',
  REQUESTED: 'Activation demandée',
  ACTIVE: 'Marquer active',
  SUSPENDED: 'Suspendre',
  TERMINATED: 'Résilier',
};

/** Groupes de 4 chiffres, plus faciles à relire */
const spaced = (iccid: string) => iccid.replace(/(\d{4})(?=\d)/g, '$1 ');

export function SimsPage() {
  const { company, agency } = useAuth();
  const [status, setStatus] = useState<SimStatus | ''>('');
  const [q, setQ] = useState('');
  const [mode, setMode] = useState<'none' | 'add' | 'import' | 'settings'>('none');
  const [editing, setEditing] = useState<SimCard | null>(null);
  const { data, error, reload } = useLoad(
    () => (company ? api<SimData>(`/sims${qs({ companyId: company.id, agencyId: agency?.id })}`) : Promise.resolve(null)),
    [company?.id, agency?.id],
  );
  const cards = data?.cards ?? [];
  const counts = useMemo(() => {
    const m = new Map<SimStatus, number>();
    for (const c of cards) m.set(c.status, (m.get(c.status) ?? 0) + 1);
    return m;
  }, [cards]);
  const search = q.replace(/\s/g, '').toLowerCase();
  const shown = cards
    .filter((c) => !status || c.status === status)
    .filter((c) => !search || [c.iccid, c.phoneNumber, c.clientName, c.siteName, c.siteCity, c.operator, c.device, c.notes]
      .filter(Boolean).join(' ').replace(/\s/g, '').toLowerCase().includes(search));

  const done = () => {
    setMode('none');
    setEditing(null);
    void reload();
  };

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Cartes SIM')}</h1>
        </div>
        <OrgPicker />
      </div>

      {data && (
        <section className="card row" style={{ justifyContent: 'space-between' }}>
          <div className="stack" style={{ gap: 2 }}>
            <strong>{data.provider || t('Prestataire des cartes SIM')}</strong>
            <span className="small muted">
              {data.portalUrl ? t('L’activation se fait sur le site du prestataire, puis on note ici où en est chaque carte.') : t('Indiquez le site du prestataire pour l’ouvrir d’ici.')}
            </span>
          </div>
          <div className="row" style={{ gap: 6 }}>
            {data.portalUrl && <a className="btn accent" href={data.portalUrl} target="_blank" rel="noreferrer">{t('Ouvrir le site du prestataire')}</a>}
            {data.canWrite && <button type="button" className="secondary" onClick={() => setMode(mode === 'settings' ? 'none' : 'settings')}>{t('Régler le prestataire')}</button>}
          </div>
        </section>
      )}
      {mode === 'settings' && data && company && <SettingsForm companyId={company.id} data={data} onDone={done} onCancel={() => setMode('none')} />}

      <div className="row">
        <div className="chips" role="tablist" aria-label={t('État')}>
          <button type="button" role="tab" aria-selected={!status} className={`chip${!status ? ' on' : ''}`} onClick={() => setStatus('')}>{t('Toutes')} <span className="muted small">({cards.length})</span></button>
          {SIM_STATUSES.map((s) => (
            <button key={s} type="button" role="tab" aria-selected={status === s} className={`chip${status === s ? ' on' : ''}`} onClick={() => setStatus(s)}>
              {tl(SIM_STATUS_LABELS, s)} <span className="muted small">({counts.get(s) ?? 0})</span>
            </button>
          ))}
        </div>
        <input type="search" style={{ width: 300 }} placeholder={t('Rechercher : n° de carte, téléphone, client…')} aria-label={t('Rechercher une carte SIM')} value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="grow" />
        {data?.canWrite && mode === 'none' && !editing && (
          <>
            <button type="button" className="secondary" onClick={() => setMode('import')}>{t('Ajouter plusieurs cartes')}</button>
            <button type="button" className="accent" onClick={() => setMode('add')}>{t('Nouvelle carte')}</button>
          </>
        )}
      </div>
      {mode === 'import' && company && <ImportForm companyId={company.id} agencyId={agency?.id ?? null} onDone={done} onCancel={() => setMode('none')} />}
      {(mode === 'add' || editing) && company && (
        <SimForm companyId={company.id} agencyId={agency?.id ?? null} initial={editing} onDone={done} onCancel={() => { setMode('none'); setEditing(null); }} />
      )}
      {error && <p className="error">{error}</p>}

      <section className="card">
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('N° de carte (ICCID)')}</th><th>{t('Téléphone')}</th><th>{t('Client et site')}</th><th>{t('État')}</th><th>{t('Actions')}</th></tr></thead>
            <tbody>
              {shown.map((c) => (
                <SimRow key={c.id} c={c} portalUrl={data?.portalUrl ?? null} canWrite={!!data?.canWrite} onEdit={() => { setMode('none'); setEditing(c); }} onChanged={() => void reload()} />
              ))}
              {data && !shown.length && (
                <tr><td colSpan={5} className="muted">{cards.length ? t('Aucune carte ne correspond.') : t('Aucune carte SIM : ajoutez-les une par une ou en lot (une par ligne).')}</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

function SimRow({ c, portalUrl, canWrite, onEdit, onChanged }: { c: SimCard; portalUrl: string | null; canWrite: boolean; onEdit: () => void; onChanged: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const setTo = async (status: SimStatus) => {
    if (status === 'TERMINATED' && !window.confirm(t('Marquer la carte {n} comme résiliée ?', { n: spaced(c.iccid) }))) return;
    try {
      await api(`/sims/${c.id}/status`, { method: 'POST', body: { status } });
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  /** Copie le numéro de carte et ouvre le site du prestataire : il ne reste qu'à coller */
  const activate = async () => {
    try {
      await navigator.clipboard.writeText(c.iccid);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      /* presse-papiers refusé : le numéro reste affiché */
    }
    if (portalUrl) window.open(portalUrl, '_blank', 'noopener');
  };
  const remove = async () => {
    if (!window.confirm(t('Supprimer la carte {n} de la liste ?', { n: spaced(c.iccid) }))) return;
    try {
      await api(`/sims/${c.id}`, { method: 'DELETE' });
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  const when = c.status === 'ACTIVE' && c.activatedAt ? t('depuis le {date}', { date: fmtDate(c.activatedAt) })
    : c.status === 'REQUESTED' && c.requestedAt ? t('le {date}', { date: fmtDate(c.requestedAt) })
      : c.status === 'TERMINATED' && c.terminatedAt ? t('le {date}', { date: fmtDate(c.terminatedAt) }) : '';
  return (
    <tr>
      <td>
        <strong style={{ fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{spaced(c.iccid)}</strong>
        <div className="small muted">{[c.operator, c.plan, c.device].filter(Boolean).join(' · ')}</div>
        {c.notes && <div className="small" style={{ whiteSpace: 'pre-wrap' }}>{c.notes}</div>}
      </td>
      <td>{c.phoneNumber ?? <span className="muted">—</span>}</td>
      <td>
        {c.clientId ? <Link to={`/clients/${c.clientId}`}>{c.clientName}</Link> : <span className="muted">{t('Non attribuée')}</span>}
        {c.siteName && <div className="small muted">{c.siteName}{c.siteCity ? ` · ${c.siteCity}` : ''}</div>}
      </td>
      <td><span className={`badge ${BADGE[c.status]}`}>{tl(SIM_STATUS_LABELS, c.status)}</span>{when && <div className="small muted">{when}</div>}</td>
      <td>
        {canWrite && (
          <div className="row" style={{ gap: 4 }}>
            {portalUrl && (c.status === 'TO_ACTIVATE' || c.status === 'STOCK') && (
              <button type="button" className="accent" onClick={() => void activate()} title={t('Copie le numéro de carte et ouvre le site du prestataire')}>
                {copied ? t('Numéro copié ✓') : t('Activer chez le prestataire')}
              </button>
            )}
            {(NEXT[c.status] ?? []).map((s) => (
              <button key={s} type="button" className="secondary" onClick={() => void setTo(s)}>{t(ACTION_LABEL[s])}</button>
            ))}
            <button type="button" className="ghost" onClick={onEdit}>{t('Modifier')}</button>
            <button type="button" className="ghost" onClick={() => void remove()}>{t('Supprimer')}</button>
          </div>
        )}
        {error && <p className="error small">{error}</p>}
      </td>
    </tr>
  );
}

interface ClientOption { id: string; name: string; city: string | null }
interface SiteOption { id: string; name: string; city: string | null }

function SimForm({ companyId, agencyId, initial, onDone, onCancel }: { companyId: string; agencyId: string | null; initial: SimCard | null; onDone: () => void; onCancel: () => void }) {
  const [f, setF] = useState({
    iccid: initial?.iccid ?? '', phoneNumber: initial?.phoneNumber ?? '', operator: initial?.operator ?? '', plan: initial?.plan ?? '',
    device: initial?.device ?? '', notes: initial?.notes ?? '', status: initial?.status ?? ('STOCK' as SimStatus),
  });
  const [client, setClient] = useState<ClientOption | null>(initial?.clientId ? { id: initial.clientId, name: initial.clientName ?? '', city: null } : null);
  const [siteId, setSiteId] = useState(initial?.siteId ?? '');
  const [clientQ, setClientQ] = useState('');
  const [found, setFound] = useState<ClientOption[]>([]);
  const [sites, setSites] = useState<SiteOption[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));

  useEffect(() => {
    if (!clientQ.trim()) return setFound([]);
    const timer = window.setTimeout(() => {
      api<ClientOption[]>(`/clients${qs({ companyId, q: clientQ, limit: 10 })}`).then(setFound).catch(() => setFound([]));
    }, 250);
    return () => window.clearTimeout(timer);
  }, [clientQ, companyId]);
  useEffect(() => {
    if (!client) return setSites([]);
    api<{ sites: SiteOption[] }>(`/clients/${client.id}`).then((d) => {
      setSites(d.sites);
      if (d.sites.length === 1) setSiteId((s) => s || d.sites[0].id);
    }).catch(() => setSites([]));
  }, [client]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { status, ...rest } = f;
    const body = { ...rest, clientId: client?.id ?? null, siteId: client && siteId ? siteId : null };
    try {
      if (initial) await api(`/sims/${initial.id}`, { method: 'PATCH', body });
      else await api('/sims', { method: 'POST', body: { ...body, status, companyId, agencyId } });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card">
      <form className="stack" onSubmit={submit}>
        <h2 style={{ fontSize: 17 }}>{initial ? t('Modifier la carte SIM') : t('Nouvelle carte SIM')}</h2>
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div className="field grow"><label htmlFor="sim-iccid">{t('N° de carte (ICCID, 19 ou 20 chiffres)')}</label>
            <input id="sim-iccid" value={f.iccid} onChange={set('iccid')} required inputMode="numeric" autoComplete="off" /></div>
          <div className="field grow"><label htmlFor="sim-phone">{t('N° de téléphone de la carte')}</label><input id="sim-phone" type="tel" value={f.phoneNumber} onChange={set('phoneNumber')} /></div>
          {!initial && (
            <div className="field grow"><label htmlFor="sim-status">{t('État')}</label>
              <select id="sim-status" value={f.status} onChange={set('status')}>
                {SIM_STATUSES.map((s) => <option key={s} value={s}>{tl(SIM_STATUS_LABELS, s)}</option>)}
              </select></div>
          )}
        </div>
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div className="field grow"><label htmlFor="sim-op">{t('Opérateur')}</label><input id="sim-op" value={f.operator} onChange={set('operator')} placeholder={t('Ex. : Orange, SFR, multi-opérateur')} /></div>
          <div className="field grow"><label htmlFor="sim-plan">{t('Forfait')}</label><input id="sim-plan" value={f.plan} onChange={set('plan')} /></div>
          <div className="field grow"><label htmlFor="sim-device">{t('Appareil (transmetteur, routeur…)')}</label><input id="sim-device" value={f.device} onChange={set('device')} /></div>
        </div>
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div className="field grow">
            <label htmlFor="sim-client">{t('Client')}</label>
            {client ? (
              <div className="row" style={{ gap: 6 }}>
                <strong>{client.name}</strong>
                <button type="button" className="ghost" onClick={() => { setClient(null); setSiteId(''); }}>{t('Changer')}</button>
              </div>
            ) : (
              <>
                <input id="sim-client" type="search" value={clientQ} onChange={(e) => setClientQ(e.target.value)} placeholder={t('Rechercher un client (facultatif)')} />
                {found.length > 0 && (
                  <div className="msg-people" style={{ maxHeight: 180 }}>
                    {found.map((c) => (
                      <button key={c.id} type="button" className="ghost" style={{ justifyContent: 'flex-start' }} onClick={() => { setClient(c); setClientQ(''); setFound([]); setSiteId(''); }}>
                        {c.name}{c.city ? ` · ${c.city}` : ''}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
          {client && sites.length > 0 && (
            <div className="field grow">
              <label htmlFor="sim-site">{t('Site')}</label>
              <select id="sim-site" value={siteId} onChange={(e) => setSiteId(e.target.value)}>
                <option value="">—</option>
                {sites.map((s) => <option key={s.id} value={s.id}>{s.name}{s.city ? ` · ${s.city}` : ''}</option>)}
              </select>
            </div>
          )}
        </div>
        <div className="field"><label htmlFor="sim-notes">{t('Notes')}</label><textarea id="sim-notes" rows={2} value={f.notes} onChange={set('notes')} /></div>
        {error && <p className="error small">{error}</p>}
        <div className="row">
          <button type="submit" disabled={busy}>{initial ? t('Enregistrer') : t('Ajouter la carte')}</button>
          <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
        </div>
      </form>
    </section>
  );
}

function ImportForm({ companyId, agencyId, onDone, onCancel }: { companyId: string; agencyId: string | null; onDone: () => void; onCancel: () => void }) {
  const [lines, setLines] = useState('');
  const [operator, setOperator] = useState('');
  const [plan, setPlan] = useState('');
  const [result, setResult] = useState<{ created: number; duplicates: number; invalid: string[] } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api<{ created: number; duplicates: number; invalid: string[] }>('/sims/import', { method: 'POST', body: { companyId, agencyId, operator, plan, lines } });
      setResult(r);
      if (!r.invalid.length) setLines('');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="card">
      <form className="stack" onSubmit={submit}>
        <h2 style={{ fontSize: 17 }}>{t('Ajouter plusieurs cartes')}</h2>
        <p className="small muted">{t('Une carte par ligne : le numéro de carte, éventuellement suivi d’un point-virgule et du numéro de téléphone. Vous pouvez coller une colonne d’Excel. Les cartes arrivent « En stock ».')}</p>
        <textarea rows={6} value={lines} onChange={(e) => setLines(e.target.value)} aria-label={t('Numéros de carte, un par ligne')} placeholder={'8933150119000000001\n8933150119000000002 ; 0612345678'} style={{ fontFamily: 'monospace' }} />
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div className="field grow"><label htmlFor="imp-op">{t('Opérateur')}</label><input id="imp-op" value={operator} onChange={(e) => setOperator(e.target.value)} /></div>
          <div className="field grow"><label htmlFor="imp-plan">{t('Forfait')}</label><input id="imp-plan" value={plan} onChange={(e) => setPlan(e.target.value)} /></div>
        </div>
        {result && (
          <p className="small">
            {tp(result.created, '{n} carte ajoutée', '{n} cartes ajoutées')}
            {result.duplicates > 0 && ` · ${tp(result.duplicates, '{n} déjà enregistrée', '{n} déjà enregistrées')}`}
            {result.invalid.length > 0 && <span className="error"> · {t('Lignes ignorées (numéro invalide) : {list}', { list: result.invalid.slice(0, 10).join(', ') })}</span>}
          </p>
        )}
        {error && <p className="error small">{error}</p>}
        <div className="row">
          <button type="submit" disabled={busy || !lines.trim()}>{t('Ajouter')}</button>
          <button type="button" className="secondary" onClick={result ? onDone : onCancel}>{result ? t('Terminer') : t('Annuler')}</button>
        </div>
      </form>
    </section>
  );
}

function SettingsForm({ companyId, data, onDone, onCancel }: { companyId: string; data: SimData; onDone: () => void; onCancel: () => void }) {
  const [provider, setProvider] = useState(data.provider ?? '');
  const [portalUrl, setPortalUrl] = useState(data.portalUrl ?? '');
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api('/sims/settings', { method: 'PATCH', body: { companyId, provider, portalUrl } });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <section className="card">
      <form className="stack" onSubmit={submit}>
        <h2 style={{ fontSize: 17 }}>{t('Prestataire des cartes SIM')}</h2>
        <div className="row" style={{ alignItems: 'flex-start' }}>
          <div className="field grow"><label htmlFor="sim-prov">{t('Nom du prestataire')}</label><input id="sim-prov" value={provider} onChange={(e) => setProvider(e.target.value)} /></div>
          <div className="field grow"><label htmlFor="sim-url">{t('Adresse du site d’activation')}</label><input id="sim-url" value={portalUrl} onChange={(e) => setPortalUrl(e.target.value)} placeholder="https://…" /></div>
        </div>
        <p className="small muted">{t('Vos identifiants du site du prestataire ne sont pas enregistrés dans Itinéos : vous vous connectez sur son site comme d’habitude.')}</p>
        {error && <p className="error small">{error}</p>}
        <div className="row">
          <button type="submit">{t('Enregistrer')}</button>
          <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
        </div>
      </form>
    </section>
  );
}
