/** Fiche véhicule : dernière position et trajet d'une journée (positions envoyées par le téléphone du conducteur) */
import { useMemo, useState } from 'react';
import { api, qs } from '../api';
import { useLoad } from '../hooks';
import { fmtDay, fmtTime } from '../format';
import { t, tp } from '../i18n';
import { VehicleMap, type MapMarker } from '../components/VehicleMap';
import { since } from './FleetMap';

interface TrackPoint { lat: number; lng: number; accuracyM: number | null; recordedAt: string; event: 'TRACK' | 'EN_ROUTE' | 'ON_SITE'; interventionNumber: string | null }

export function VehicleTrack({ vehicleId, timezone, lastPositionAt }: { vehicleId: string; timezone?: string; lastPositionAt: string | null }) {
  const [date, setDate] = useState<string | null>(null);
  const { data, error } = useLoad(
    () => api<{ date: string; points: TrackPoint[]; days: string[] }>(`/fleet/vehicles/${vehicleId}/track${qs({ date })}`),
    [vehicleId, date],
  );
  const points = data?.points ?? [];
  const path = useMemo(() => points.map((p) => [p.lat, p.lng] as [number, number]), [points]);
  const markers = useMemo<MapMarker[]>(() => {
    if (!points.length) return [];
    const first = points[0];
    const last = points[points.length - 1];
    const out: MapMarker[] = [];
    if (points.length > 1) out.push({ id: 'start', lat: first.lat, lng: first.lng, tone: 'start', label: t('Départ {time}', { time: fmtTime(first.recordedAt, timezone) }) });
    points.forEach((p, i) => {
      if (p.event === 'ON_SITE') {
        out.push({ id: `site-${i}`, lat: p.lat, lng: p.lng, tone: 'start', label: t('Sur place {time}', { time: fmtTime(p.recordedAt, timezone) }) + (p.interventionNumber ? ` · ${p.interventionNumber}` : '') });
      }
    });
    out.push({ id: 'end', lat: last.lat, lng: last.lng, tone: 'end', label: t('Dernière position {time}', { time: fmtTime(last.recordedAt, timezone) }) });
    return out;
  }, [points, timezone]);

  const days = data?.days ?? [];
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h2>{t('Position et trajet')}</h2>
          <div className="small muted">
            {lastPositionAt ? t('Dernière position {when}', { when: since(lastPositionAt, timezone) }) : t('Pas encore de position pour ce véhicule.')}
          </div>
        </div>
        {days.length > 0 && (
          <div className="field">
            <label htmlFor="track-day">{t('Journée')}</label>
            <select id="track-day" value={data?.date ?? ''} onChange={(e) => setDate(e.target.value)}>
              {!days.includes(data?.date ?? '') && data?.date && <option value={data.date}>{fmtDay(data.date)}</option>}
              {days.map((d) => <option key={d} value={d}>{fmtDay(d)}</option>)}
            </select>
          </div>
        )}
      </div>
      {error && <p className="error small">{error}</p>}
      {points.length > 0
        ? <>
            <VehicleMap markers={markers} path={path} height={380} ariaLabel={t('Trajet du véhicule')} />
            <div className="small muted">{tp(points.length, '{n} position enregistrée ce jour-là.', '{n} positions enregistrées ce jour-là.')}</div>
          </>
        : data && <p className="small muted" style={{ margin: 0 }}>{t('Aucun trajet enregistré ce jour-là. La position vient du téléphone du conducteur, quand il a activé le partage dans l’appli.')}</p>}
    </section>
  );
}
