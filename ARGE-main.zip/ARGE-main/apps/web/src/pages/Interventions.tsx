import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { deadlineState, INTERVENTION_STATUSES, STATUS_LABELS, type InterventionStatus } from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import type { InterventionRow } from '../types';
import { OrgPicker } from '../components/Layout';
import { KindBadge, PriorityBadge, StatusBadge } from '../components/Badges';
import { fmtDateTime, fmtDay, fullName } from '../format';
import { DueBadge } from '../components/DueBadge';
import { hasFeature } from '../edition';
import { t, tl } from '../i18n';

export function InterventionsPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [status, setStatus] = useState<InterventionStatus | ''>('');
  // Itinéos Expertise : date limite de remise du rapport
  const deadlines = hasFeature('deadlines');
  const today = new Date().toISOString().slice(0, 10);

  const { data, error, loading } = useLoad(
    () => api<InterventionRow[]>(`/interventions${qs({ companyId: company?.id, agencyId: agency?.id, status })}`),
    [company?.id, agency?.id, status],
  );

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Interventions')}</h1>
        </div>
        <OrgPicker />
      </div>

      <div className="row">
        <div className="chips" role="group" aria-label={t('Filtrer par statut')}>
          <button type="button" className={`chip${status === '' ? ' on' : ''}`} onClick={() => setStatus('')}>{t('Toutes')}</button>
          {INTERVENTION_STATUSES.map((s) => (
            <button key={s} type="button" className={`chip${status === s ? ' on' : ''}`} onClick={() => setStatus(s)}>{tl(STATUS_LABELS, s)}</button>
          ))}
        </div>
        <div className="grow" />
        {has('intervention.write') && (
          <button type="button" className="accent" onClick={() => navigate('/interventions/new')}>{t('Nouvelle intervention')}</button>
        )}
      </div>

      {error && <p className="error">{error}</p>}
      <section className="card">
        {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>{t('N°')}</th><th>{t('Client')}</th><th>{t('Type')}</th><th>{t('Motif')}</th><th>{t('Prévue')}</th><th>{t('Technicien')}</th><th>{t('Statut')}</th></tr>
              </thead>
              <tbody>
                {(data ?? []).map((iv) => (
                  <tr key={iv.id} className="clickable" onClick={() => navigate(`/interventions/${iv.id}`)}>
                    <td><a href={`/interventions/${iv.id}`} onClick={(e) => { e.preventDefault(); navigate(`/interventions/${iv.id}`); }}>{iv.number}</a></td>
                    <td><strong>{iv.clientName}</strong><div className="small muted">{iv.siteCity}</div></td>
                    <td><KindBadge kind={iv.kind} /> <PriorityBadge priority={iv.priority} /></td>
                    <td>{iv.reason}</td>
                    <td>
                      {fmtDateTime(iv.scheduledStart, company?.timezone)}
                      {deadlines && iv.dueDate && iv.status !== 'DONE' && iv.status !== 'CANCELLED' && (
                        <div><DueBadge state={deadlineState(iv.dueDate, today)} label={t('À rendre le {date}', { date: fmtDay(iv.dueDate) })} /></div>
                      )}
                    </td>
                    <td>{iv.technicianId ? fullName(iv.technicianFirstName, iv.technicianLastName) : <span className="muted">{t('Non affectée')}</span>}</td>
                    <td><StatusBadge status={iv.status} /></td>
                  </tr>
                ))}
                {data && !data.length && <tr><td colSpan={7} className="muted">{t('Aucune intervention.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
