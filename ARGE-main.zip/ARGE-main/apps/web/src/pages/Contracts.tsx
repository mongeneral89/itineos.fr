import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  CONTRACT_FREQUENCIES, CONTRACT_STATUS_LABELS, CONTRACT_STATUSES, formatMoney, STATUS_LABELS, visitDueDates,
  type ContractStatus,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { fmtDateTime, fmtDay, moneyInput, parseMoneyInput, toDateInput } from '../format';
import type { Client, ClientDetail, ContractDetail, ContractRow } from '../types';
import { t, tl, tp } from '../i18n';

const frequencyLabel = (m: number) => {
  const known = CONTRACT_FREQUENCIES.find((f) => f.months === m)?.label;
  return known ? t(known) : t('Tous les {n} mois', { n: m });
};

function ContractStatusBadge({ status }: { status: ContractStatus }) {
  const tone = { ACTIVE: 'ok', SUSPENDED: 'warn', ENDED: 'neutral' }[status];
  return <span className={`badge ${tone}`}>{tl(CONTRACT_STATUS_LABELS, status)}</span>;
}

/** Prochaine échéance à partir d'aujourd'hui */
function nextDue(c: { startDate: string; endDate: string | null; frequencyMonths: number; status: ContractStatus }) {
  if (c.status !== 'ACTIVE') return null;
  const today = toDateInput(new Date());
  return visitDueDates(c, today, `${Number(today.slice(0, 4)) + 6}${today.slice(4)}`)[0] ?? null;
}

export function ContractsPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [status, setStatus] = useState<ContractStatus | ''>('ACTIVE');
  const [q, setQ] = useState('');
  const { data, error, loading } = useLoad(
    () => (company ? api<ContractRow[]>(`/contracts${qs({ companyId: company.id, agencyId: agency?.id, status, q })}`) : Promise.resolve([])),
    [company?.id, agency?.id, status, q],
  );
  const rows = data ?? [];
  const yearly = rows.filter((r) => r.status === 'ACTIVE').reduce((s, r) => s + (r.annualPriceCents ?? 0), 0);

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t("Contrats d'entretien")}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="row">
        <input style={{ maxWidth: 320 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Rechercher : n°, intitulé, client')} aria-label={t('Rechercher un contrat')} />
        <select style={{ maxWidth: 200 }} value={status} onChange={(e) => setStatus(e.target.value as ContractStatus | '')} aria-label={t('Filtrer par statut')}>
          <option value="">{t('Tous')}</option>
          {CONTRACT_STATUSES.map((s) => <option key={s} value={s}>{tl(CONTRACT_STATUS_LABELS, s)}</option>)}
        </select>
        <div className="grow" />
        {has('contract.write') && <button type="button" className="accent" onClick={() => navigate('/contracts/new')}>{t('Nouveau contrat')}</button>}
      </div>
      {company && yearly > 0 && <p className="small muted">{t('Contrats actifs affichés : {amount} HT par an', { amount: formatMoney(yearly, company.currency, company.locale) })}</p>}
      {error && <p className="error">{error}</p>}
      <section className="card">
        {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('N°')}</th><th>{t('Client · site')}</th><th>{t('Intitulé')}</th><th>{t('Fréquence')}</th><th>{t('Prochaine visite')}</th><th style={{ textAlign: 'right' }}>{t('Prix annuel HT')}</th><th>{t('Statut')}</th></tr></thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="clickable" onClick={() => navigate(`/contracts/${r.id}`)}>
                    <td><Link to={`/contracts/${r.id}`} onClick={(e) => e.stopPropagation()}><strong>{r.number}</strong></Link></td>
                    <td>{r.clientName}<div className="small muted">{r.siteName}{r.siteCity ? ` · ${r.siteCity}` : ''}</div></td>
                    <td>{r.title}</td>
                    <td className="small">{frequencyLabel(r.frequencyMonths)}</td>
                    <td className="small">{fmtDay(nextDue(r))}</td>
                    <td style={{ textAlign: 'right' }}>{r.annualPriceCents != null && company ? formatMoney(r.annualPriceCents, company.currency) : '—'}</td>
                    <td><ContractStatusBadge status={r.status} /></td>
                  </tr>
                ))}
                {data && !rows.length && <tr><td colSpan={7} className="muted">{t('Aucun contrat.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}

/** Facture d'une période du contrat (au prorata du prix annuel) */
function BillContract({ contractId, startDate }: { contractId: string; startDate: string }) {
  const navigate = useNavigate();
  const [periodStart, setPeriodStart] = useState(startDate);
  const [months, setMonths] = useState(12);
  const [error, setError] = useState<string | null>(null);
  return (
    <section className="card stack">
      <h2>{t('Facturer le contrat')}</h2>
      <div className="row" style={{ alignItems: 'flex-end' }}>
        <div className="field"><label htmlFor="b-start">{t('Période à partir du')}</label>
          <input id="b-start" type="date" value={periodStart} onChange={(e) => setPeriodStart(e.target.value)} />
        </div>
        <div className="field"><label htmlFor="b-months">{t('Durée')}</label>
          <select id="b-months" value={months} onChange={(e) => setMonths(Number(e.target.value))}>
            {[1, 3, 6, 12].map((m) => <option key={m} value={m}>{m === 12 ? t('1 an') : t('{n} mois', { n: m })}</option>)}
          </select>
        </div>
        <button type="button" onClick={() => api<{ id: string }>(`/invoices/from-contract/${contractId}`, { method: 'POST', body: { periodStart, months } })
          .then((r) => navigate(`/invoices/${r.id}`)).catch((e) => setError((e as Error).message))}>{t('Créer la facture')}</button>
      </div>
      {error && <p className="error">{error}</p>}
    </section>
  );
}

interface Form {
  clientId: string; siteId: string; agencyId: string; equipmentIds: string[]; title: string; frequencyMonths: number;
  startDate: string; endDate: string; visitHours: string; price: string; notes: string; status: ContractStatus;
  /** Facturation en lot : 0 = non, sinon tous les N mois */
  billingMonths: number; billedUntil: string;
}

export function ContractEditPage() {
  const { id = 'new' } = useParams();
  const isNew = id === 'new';
  const navigate = useNavigate();
  const { company, agency, me, has } = useAuth();
  const [contract, setContract] = useState<ContractDetail | null>(null);
  const [form, setForm] = useState<Form | null>(null);
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [clients, setClients] = useState<Client[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const canWrite = has('contract.write');
  const comp = me?.org.find((c) => c.id === (contract?.companyId ?? company?.id)) ?? company;

  const load = async () => {
    const c = await api<ContractDetail>(`/contracts/${id}`);
    setContract(c);
    setForm({
      clientId: c.clientId, siteId: c.siteId, agencyId: c.agencyId, equipmentIds: c.equipmentIds, title: c.title,
      frequencyMonths: c.frequencyMonths, startDate: c.startDate, endDate: c.endDate ?? '', visitHours: String(c.visitHours).replace('.', ','),
      price: c.annualPriceCents != null ? moneyInput(c.annualPriceCents) : '', notes: c.notes ?? '', status: c.status,
      billingMonths: c.billingMonths ?? 0, billedUntil: c.billedUntil ?? '',
    });
  };

  useEffect(() => {
    if (isNew) {
      setForm({
        clientId: '', siteId: '', agencyId: agency?.id ?? company?.agencies[0]?.id ?? '', equipmentIds: [], title: '',
        frequencyMonths: 12, startDate: toDateInput(new Date()), endDate: '', visitHours: '1', price: '', notes: '', status: 'ACTIVE',
        billingMonths: 0, billedUntil: '',
      });
    } else {
      load().catch((e) => setError((e as Error).message));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    if (!isNew || !company) return;
    void api<Client[]>(`/clients${qs({ companyId: company.id, agencyId: agency?.id, limit: 200 })}`).then(setClients).catch(() => undefined);
  }, [isNew, company, agency?.id]);

  useEffect(() => {
    if (!form?.clientId) return setClient(null);
    void api<ClientDetail>(`/clients/${form.clientId}`).then(setClient).catch(() => undefined);
  }, [form?.clientId]);

  if (error && !form) return <p className="error">{error}</p>;
  // Contrat existant pas encore chargé (par exemple juste après sa création)
  if (!form || (!isNew && contract?.id !== id)) return <p className="muted">{t('Chargement…')}</p>;
  const set = (patch: Partial<Form>) => setForm((f) => (f ? { ...f, ...patch } : f));
  const site = client?.sites.find((s) => s.id === form.siteId);

  const save = async () => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      const price = form.price.trim() ? parseMoneyInput(form.price) : null;
      if (form.price.trim() && price === null) throw new Error(t('Prix annuel invalide (ex. 960,00)'));
      const hours = Number(form.visitHours.replace(',', '.'));
      if (!(hours > 0)) throw new Error(t('Durée de visite invalide'));
      const body = {
        agencyId: form.agencyId, siteId: form.siteId, equipmentIds: form.equipmentIds, title: form.title.trim(),
        frequencyMonths: form.frequencyMonths, startDate: form.startDate, endDate: form.endDate || null, visitHours: hours,
        annualPriceCents: price, notes: form.notes.trim() || null,
        billingMonths: form.billingMonths || null, billedUntil: form.billingMonths ? form.billedUntil || null : null,
      };
      if (isNew) {
        const created = await api<{ id: string; visitsCreated: number }>('/contracts', { method: 'POST', body: { ...body, clientId: form.clientId } });
        navigate(`/contracts/${created.id}`, { replace: true });
        return;
      }
      const res = await api<{ visitsCreated: number; visitsRemoved: number }>(`/contracts/${id}`, { method: 'PATCH', body: { ...body, status: form.status } });
      await load();
      setMsg([
        t('Contrat enregistré.'),
        res.visitsCreated ? tp(res.visitsCreated, '{n} visite ajoutée.', '{n} visites ajoutées.') : '',
        res.visitsRemoved ? tp(res.visitsRemoved, '{n} visite non planifiée retirée.', '{n} visites non planifiées retirées.') : '',
      ].filter(Boolean).join(' '));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const upcoming = visitDueDates(form, toDateInput(new Date()), `${Number(form.startDate.slice(0, 4) || new Date().getFullYear()) + 3}-12-31`).slice(0, 4);

  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="topbar">
        <div>
          <div className="eyebrow"><Link to="/contracts">{t('Contrats')}</Link>{contract ? ` · ${contract.number}` : ''}</div>
          <h1>{isNew ? t("Nouveau contrat d'entretien") : contract?.title}</h1>
        </div>
        {contract && <ContractStatusBadge status={contract.status} />}
      </div>
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error" role="alert">{error}</p>}

      <section className="card stack">
        <div className="row">
          <div className="field grow"><label htmlFor="ct-client">{t('Client')}</label>
            {isNew ? (
              <select id="ct-client" value={form.clientId} onChange={(e) => set({ clientId: e.target.value, siteId: '', equipmentIds: [] })}>
                <option value="">{t('— Choisir —')}</option>
                {clients.map((c) => <option key={c.id} value={c.id}>{c.name}{c.city ? ` · ${c.city}` : ''}</option>)}
              </select>
            ) : <div><Link to={`/clients/${contract!.clientId}`}><strong>{contract!.client.name}</strong></Link></div>}
          </div>
          <div className="field grow"><label htmlFor="ct-site">{t('Site')}</label>
            <select id="ct-site" value={form.siteId} disabled={!canWrite || !client} onChange={(e) => set({ siteId: e.target.value, equipmentIds: [] })}>
              <option value="">{t('— Choisir —')}</option>
              {client?.sites.map((s) => <option key={s.id} value={s.id}>{s.name}{s.city ? ` · ${s.city}` : ''}</option>)}
            </select>
          </div>
          <div className="field"><label htmlFor="ct-agency">{t('Agence qui fait les visites')}</label>
            <select id="ct-agency" value={form.agencyId} disabled={!canWrite} onChange={(e) => set({ agencyId: e.target.value })}>
              {comp?.agencies.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
        </div>
        {site && site.equipments.length > 0 && (
          <fieldset className="field" style={{ border: 'none', padding: 0, margin: 0 }}>
            <legend className="section-title">{t('Matériel couvert')}</legend>
            {site.equipments.map((e) => (
              <label key={e.id} className="check">
                <input type="checkbox" disabled={!canWrite} checked={form.equipmentIds.includes(e.id)}
                  onChange={(ev) => set({ equipmentIds: ev.target.checked ? [...form.equipmentIds, e.id] : form.equipmentIds.filter((x) => x !== e.id) })} />
                {e.category}{e.brand ? ` · ${e.brand}` : ''}{e.serialNumber ? ` · ${e.serialNumber}` : ''}
              </label>
            ))}
          </fieldset>
        )}
        <div className="field"><label htmlFor="ct-title">{t('Intitulé')}</label>
          <input id="ct-title" value={form.title} disabled={!canWrite} maxLength={300} placeholder={t('Ex. : Entretien annuel de la chaudière')} onChange={(e) => set({ title: e.target.value })} />
        </div>
        <div className="row">
          <div className="field"><label htmlFor="ct-freq">{t('Fréquence des visites')}</label>
            <select id="ct-freq" value={form.frequencyMonths} disabled={!canWrite} onChange={(e) => set({ frequencyMonths: Number(e.target.value) })}>
              {CONTRACT_FREQUENCIES.map((f) => <option key={f.months} value={f.months}>{t(f.label)}</option>)}
              <option value={0}>{t('Aucune visite (abonnement seul)')}</option>
            </select>
          </div>
          <div className="field"><label htmlFor="ct-start">{form.frequencyMonths ? t('Première visite le') : t('Début du contrat')}</label>
            <input id="ct-start" type="date" value={form.startDate} disabled={!canWrite} onChange={(e) => set({ startDate: e.target.value })} />
          </div>
          <div className="field"><label htmlFor="ct-end">{t('Fin (vide = reconduit)')}</label>
            <input id="ct-end" type="date" value={form.endDate} disabled={!canWrite} onChange={(e) => set({ endDate: e.target.value })} />
          </div>
          <div className="field" style={{ width: 120 }}><label htmlFor="ct-hours">{t('Durée (h)')}</label>
            <input id="ct-hours" inputMode="decimal" value={form.visitHours} disabled={!canWrite} onChange={(e) => set({ visitHours: e.target.value })} />
          </div>
          <div className="field" style={{ width: 160 }}><label htmlFor="ct-price">{t('Prix annuel HT')}</label>
            <input id="ct-price" inputMode="decimal" value={form.price} disabled={!canWrite} placeholder="0,00" onChange={(e) => set({ price: e.target.value })} />
          </div>
          {!isNew && (
            <div className="field"><label htmlFor="ct-status">{t('Statut')}</label>
              <select id="ct-status" value={form.status} disabled={!canWrite} onChange={(e) => set({ status: e.target.value as ContractStatus })}>
                {CONTRACT_STATUSES.map((s) => <option key={s} value={s}>{tl(CONTRACT_STATUS_LABELS, s)}</option>)}
              </select>
            </div>
          )}
        </div>
        <p className="small muted" style={{ margin: 0 }}>
          {form.frequencyMonths
            ? t('Prochaines échéances : {dates}. Chaque visite est créée « à planifier » 60 jours avant son échéance. Les visites déjà planifiées ne sont jamais modifiées.', { dates: upcoming.length ? upcoming.map((d) => fmtDay(d)).join(' · ') : '—' })
            : t('Aucune visite n’est créée pour ce contrat.')}
        </p>
        <div className="row">
          <div className="field"><label htmlFor="ct-billing">{t('Facturation automatique')}</label>
            <select id="ct-billing" value={form.billingMonths} disabled={!canWrite} onChange={(e) => set({ billingMonths: Number(e.target.value) })}>
              <option value={0}>{t('Non : facture faite à la main')}</option>
              {CONTRACT_FREQUENCIES.filter((f) => [1, 3, 6, 12].includes(f.months)).map((f) => <option key={f.months} value={f.months}>{t(f.label)}</option>)}
            </select>
          </div>
          {form.billingMonths > 0 && (
            <div className="field"><label htmlFor="ct-billed">{t('Déjà facturé jusqu’au (facultatif)')}</label>
              <input id="ct-billed" type="date" value={form.billedUntil} disabled={!canWrite} onChange={(e) => set({ billedUntil: e.target.value })} />
            </div>
          )}
        </div>
        {form.billingMonths > 0 && (
          <p className="small muted" style={{ margin: 0 }}>
            {t('Facturé à terme à échoir à partir du début du contrat, depuis « Facturer les abonnements ». Le prix annuel est réparti sur chaque période.')}
          </p>
        )}
        <div className="field"><label htmlFor="ct-notes">{t('Notes')}</label>
          <textarea id="ct-notes" rows={2} value={form.notes} disabled={!canWrite} onChange={(e) => set({ notes: e.target.value })} />
        </div>
        {canWrite && (
          <div className="row">
            <button type="button" disabled={busy || !form.clientId || !form.siteId || !form.title.trim()} onClick={() => void save()}>
              {isNew ? t('Créer le contrat') : t('Enregistrer')}
            </button>
          </div>
        )}
      </section>

      {contract && has('invoice.write') && contract.annualPriceCents != null && <BillContract contractId={contract.id} startDate={contract.startDate} />}

      {contract && (
        <section className="card stack">
          <h2>{t('Visites ({n})', { n: contract.visits.length })}</h2>
          {contract.quote && <p className="small">{t('Issu du devis')} <Link to={`/quotes/${contract.quote.id}`}>{contract.quote.number}</Link></p>}
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('N°')}</th><th>{t('Échéance')}</th><th>{t('Planifiée le')}</th><th>{t('Statut')}</th></tr></thead>
              <tbody>
                {contract.visits.map((v) => (
                  <tr key={v.id} className="clickable" onClick={() => navigate(`/interventions/${v.id}`)}>
                    <td><Link to={`/interventions/${v.id}`} onClick={(e) => e.stopPropagation()}>{v.number}</Link></td>
                    <td>{fmtDay(v.dueDate)}</td>
                    <td>{fmtDateTime(v.scheduledStart, comp?.timezone)}</td>
                    <td>{tl(STATUS_LABELS, v.status)}</td>
                  </tr>
                ))}
                {!contract.visits.length && <tr><td colSpan={4} className="muted">{t("Aucune visite pour l'instant : elles apparaissent 60 jours avant leur échéance.")}</td></tr>}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
