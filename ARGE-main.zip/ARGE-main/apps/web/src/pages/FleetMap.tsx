/** Carte du parc : dernière position connue de chaque véhicule, son conducteur et ce qu'il fait */
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { STATUS_LABELS, type InterventionStatus } from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { fmtTime, fullName } from '../format';
import { t, tl, tp } from '../i18n';
import { VehicleMap, type MapMarker } from '../components/VehicleMap';

export interface MapVehicle {
  id: string; plate: string; make: string | null; model: string | null; status: string;
  lat: number | null; lng: number | null; accuracyM: number | null; positionAt: string | null;
  driverId: string | null; driverFirstName: string | null; driverLastName: string | null; sharing: boolean;
  job: { id: string; number: string; status: InterventionStatus; reason: string; scheduledStart: string | null; clientName: string; siteCity: string | null } | null;
}

/** Au-delà, la position est affichée en gris : le véhicule a pu bouger depuis */
const STALE_MINUTES = 30;

/** « il y a 3 min », « il y a 2 h », « le 09/10 à 14:05 » */
export function since(iso: string, tz?: string): string {
  const min = Math.round((Date.now() - new Date(iso).getTime()) / 60_000);
  if (min < 1) return t("à l'instant");
  if (min < 60) return t('il y a {n} min', { n: min });
  if (min < 24 * 60) return tp(Math.round(min / 60), 'il y a {n} heure', 'il y a {n} heures');
  return t('le {date} à {time}', {
    date: new Intl.DateTimeFormat(undefined, { timeZone: tz, day: '2-digit', month: '2-digit' }).format(new Date(iso)),
    time: fmtTime(iso, tz),
  });
}

export function FleetMapTab() {
  const { company, agency } = useAuth();
  const [selected, setSelected] = useState<string | null>(null);
  const { data, error, reload } = useLoad(
    () => (company ? api<{ vehicles: MapVehicle[] }>(`/fleet/map${qs({ companyId: company.id, agencyId: agency?.id })}`) : Promise.resolve({ vehicles: [] })),
    [company?.id, agency?.id],
  );
  // Rafraîchie chaque minute tant que la page est ouverte
  useEffect(() => {
    const timer = setInterval(() => void reload(), 60_000);
    return () => clearInterval(timer);
  }, [reload]);

  const vehicles = data?.vehicles ?? [];
  const markers = useMemo<MapMarker[]>(() => vehicles
    .filter((x) => x.lat != null && x.lng != null && x.positionAt)
    .map((x) => {
      const stale = Date.now() - new Date(x.positionAt!).getTime() > STALE_MINUTES * 60_000;
      return {
        id: x.id, lat: x.lat!, lng: x.lng!, tone: stale ? 'stale' : 'live',
        label: x.driverFirstName ? `${x.plate} · ${x.driverFirstName}` : x.plate,
        title: `${x.plate} – ${since(x.positionAt!, company?.timezone)}`,
      };
    }), [vehicles, company?.timezone]);

  return (
    <div className="row" style={{ alignItems: 'flex-start' }}>
      <section className="card" style={{ flex: '999 1 520px', minWidth: 0, padding: 8 }}>
        <VehicleMap markers={markers} selectedId={selected} onSelect={setSelected} height={540} ariaLabel={t('Carte des véhicules')} />
      </section>
      <aside className="card stack map-list" style={{ flex: '1 1 280px', minWidth: 0 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h2>{t('Véhicules')}</h2>
          <button type="button" className="ghost" onClick={() => void reload()}>{t('Actualiser')}</button>
        </div>
        {error && <p className="error small">{error}</p>}
        {vehicles.map((x) => {
          const stale = !x.positionAt || Date.now() - new Date(x.positionAt).getTime() > STALE_MINUTES * 60_000;
          return (
            <button key={x.id} type="button" className={selected === x.id ? '' : 'secondary'} disabled={!x.positionAt}
              onClick={() => setSelected(x.id)} style={{ flexDirection: 'column', alignItems: 'flex-start', gap: 2, minHeight: 0, padding: '10px 12px' }}>
              <span style={{ fontWeight: 600 }}>{x.plate}{x.driverId ? ` · ${fullName(x.driverFirstName, x.driverLastName)}` : ''}</span>
              <span className="small" style={{ fontWeight: 400 }}>
                {x.positionAt
                  ? `${stale ? '○' : '●'} ${t('Position {when}', { when: since(x.positionAt, company?.timezone) })}${x.accuracyM ? ` · ±${x.accuracyM} m` : ''}`
                  : !x.driverId ? t('Pas de conducteur') : !x.sharing ? t('Partage de position non activé par le conducteur') : t('Pas encore de position')}
              </span>
              {x.job && (
                <span className="small" style={{ fontWeight: 400 }}>
                  {tl(STATUS_LABELS, x.job.status)} · {x.job.clientName}{x.job.siteCity ? `, ${x.job.siteCity}` : ''}{x.job.scheduledStart ? ` · ${fmtTime(x.job.scheduledStart, company?.timezone)}` : ''}
                </span>
              )}
            </button>
          );
        })}
        {data && !vehicles.length && <p className="small muted">{t('Aucun véhicule.')}</p>}
        {selected && <Link className="small" to={`/fleet/${selected}`}>{t('Ouvrir la fiche du véhicule et son trajet du jour')}</Link>}
        <p className="small muted" style={{ margin: 0 }}>
          {t('La position vient du téléphone du conducteur, quand il a activé le partage et que l’appli est ouverte. En gris : position de plus de 30 minutes. Historique effacé après 30 jours.')}
        </p>
      </aside>
    </div>
  );
}
