import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useMemo } from 'react';
import { deadlineState, VEHICLE_DEADLINE_LABELS } from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import type { DashboardRow, DeadlineRow, DeadlinesOverview, InterventionRow, UserRow } from '../types';
import { OrgPicker } from '../components/Layout';
import { DueBadge } from '../components/DueBadge';
import { fmtDay, fmtLongDay, fmtTime, fullName } from '../format';
import { hasFeature, hasModule } from '../edition';
import { t, tl, tp, uiLocale } from '../i18n';
import { FREE_COLOR, liveOf, STATE_COLOR, stateLabel, stateOf } from '../planning-state';

/** Ce qui arrive à échéance : véhicules (entretien, contrôle…) et habilitations des techniciens */
function DeadlinesCard({ companyId, agencyId }: { companyId: string; agencyId?: string }) {
  const { data } = useLoad(() => api<DeadlinesOverview>(`/deadlines${qs({ companyId, agencyId })}`), [companyId, agencyId]);
  if (!data || (!data.vehicles.length && !data.certifications.length)) return null;
  const overdue = data.vehicles.filter((v) => v.state === 'OVERDUE').length + data.certifications.filter((c) => c.state === 'OVERDUE').length;
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Échéances')}</h2>
        {overdue > 0 && <span className="badge danger">{tp(overdue, '{n} dépassée', '{n} dépassées')}</span>}
      </div>
      <div className="grid">
        <div className="stack" style={{ gap: 6 }}>
          <strong><Link to="/fleet">{t('Véhicules ({n})', { n: data.vehicles.length })}</Link></strong>
          {data.vehicles.slice(0, 6).map((v) => (
            <div key={v.id} className="row small" style={{ justifyContent: 'space-between' }}>
              <span><Link to={`/fleet/${v.vehicleId}`}>{v.plate}</Link> · {v.label || tl(VEHICLE_DEADLINE_LABELS, v.kind)} {v.dueDate ? `· ${fmtDay(v.dueDate)}` : ''}</span>
              <DueBadge state={v.state} label={v.appointmentOn ? t('RDV {date}', { date: fmtDay(v.appointmentOn) }) : undefined} />
            </div>
          ))}
          {!data.vehicles.length && <span className="small muted">{t('Parc à jour.')}</span>}
        </div>
        <div className="stack" style={{ gap: 6 }}>
          <strong><Link to="/certifications">{t('Habilitations ({n})', { n: data.certifications.length })}</Link></strong>
          {data.certifications.slice(0, 6).map((c) => (
            <div key={c.id} className="row small" style={{ justifyContent: 'space-between' }}>
              <span>{c.firstName} {c.lastName} · {c.typeCode} · {fmtDay(c.expiresOn)}</span>
              <DueBadge state={c.state} label={c.state === 'OVERDUE' ? t('Expirée') : t('Expire bientôt')} />
            </div>
          ))}
          {!data.certifications.length && <span className="small muted">{t('Toutes valables.')}</span>}
        </div>
      </div>
    </section>
  );
}

/** « Aujourd'hui » : où en est chaque technicien, ce qui demande une action, et les chiffres du mois pour la direction */
export function DashboardPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ` · ${t('Toutes les agences')}`}</div>
          <h1>{t('Aujourd’hui')} · {fmtLongDay(new Date())}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="row">
        {has('intervention.write') && <button type="button" className="accent" onClick={() => navigate('/interventions/new')}>{t('Nouvelle intervention')}</button>}
        <button type="button" className="secondary" onClick={() => navigate('/planning')}>{t('Planning')}</button>
      </div>
      {company && <Today companyId={company.id} agencyId={agency?.id} />}
      {company && ((has('fleet.read') && hasModule('fleet')) || (has('certification.read') && hasModule('certifications'))) && <DeadlinesCard companyId={company.id} agencyId={agency?.id} />}
      {has('dashboard.read') && <MonthOverview />}
    </>
  );
}

/** Journée en cours : techniciens en direct, interventions à surveiller, terminées */
function Today({ companyId, agencyId }: { companyId: string; agencyId?: string }) {
  const { data, error, reload } = useLoad(async () => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const end = new Date(start.getTime() + 86400_000);
    const scope = { companyId, agencyId };
    const [jobs, todo, techs] = await Promise.all([
      api<InterventionRow[]>(`/interventions${qs({ ...scope, from: start.toISOString(), to: end.toISOString(), limit: 1000 })}`),
      api<InterventionRow[]>(`/interventions${qs({ ...scope, status: 'TO_PLAN,TO_RESUME' })}`),
      api<UserRow[]>(`/users${qs({ ...scope, role: 'TECHNICIAN' })}`).catch(() => [] as UserRow[]),
    ]);
    return { jobs: jobs.filter((iv) => iv.status !== 'CANCELLED' && iv.scheduledStart), todo, techs: techs.filter((u) => u.active) };
  }, [companyId, agencyId]);
  // Mise à jour chaque minute : départs, arrivées, fiches envoyées
  useEffect(() => {
    const timer = window.setInterval(() => document.visibilityState === 'visible' && reload(), 60_000);
    return () => window.clearInterval(timer);
  }, [reload]);

  const view = useMemo(() => {
    if (!data) return null;
    const now = Date.now();
    const by = (st: string) => data.jobs.filter((iv) => stateOf(iv, now) === st);
    const live = data.techs.map((u) => ({ u, live: liveOf(data.jobs.filter((iv) => iv.technicianId === u.id)) }))
      .sort((a, b) => (a.live ? 0 : 1) - (b.live ? 0 : 1) || a.u.lastName.localeCompare(b.u.lastName));
    // À surveiller : retards, urgences pas encore planifiées, interventions à reprendre
    const watch = [
      ...by('late'),
      ...data.todo.filter((iv) => iv.priority === 'URGENT' && iv.status === 'TO_PLAN'),
      ...data.todo.filter((iv) => iv.status === 'TO_RESUME'),
    ];
    return {
      planned: data.jobs.length,
      running: by('enroute').length + by('onsite').length,
      done: by('done').length + by('resume').length,
      late: by('late').length,
      toPlan: data.todo.filter((iv) => iv.status === 'TO_PLAN').length,
      live,
      watch,
      finished: [...by('done'), ...by('resume')].sort((a, b) => b.scheduledStart!.localeCompare(a.scheduledStart!)),
    };
  }, [data]);

  if (error) return <p className="error">{error}</p>;
  if (!view) return <p className="muted">{t('Chargement…')}</p>;
  return (
    <>
      <div className="grid today-kpis">
        <Kpi label={t('Prévues aujourd’hui')} value={view.planned} to="/planning" />
        <Kpi label={t('En cours')} value={view.running} to="/planning" tone={view.running ? 'info' : undefined} />
        <Kpi label={t('Terminées')} value={view.done} to="/interventions" tone={view.done ? 'ok' : undefined} />
        <Kpi label={t('En retard')} value={view.late} to="/planning" tone={view.late ? 'danger' : undefined} />
        <Kpi label={t('À planifier')} value={view.toPlan} to="/planning" tone={view.toPlan ? 'warn' : undefined} />
      </div>

      <div className="grid today-cols">
        <section className="card stack">
          <h2>{t('Techniciens')}</h2>
          {!view.live.length && <p className="muted small">{t('Aucun technicien dans cette société.')}</p>}
          <ul className="today-list">
            {view.live.map(({ u, live }) => (
              <li key={u.id}>
                <span className="plan-dot" style={{ background: !live || live.state === 'free' ? FREE_COLOR : STATE_COLOR[live.state] }} aria-hidden="true" />
                <span className="grow">
                  <strong>{u.firstName} {u.lastName}</strong>
                  <span className="small muted"> · {live ? live.text : t('Rien de prévu aujourd’hui')}</span>
                </span>
                {live?.current && <Link className="small" to={`/interventions/${live.current.id}`}>{live.current.number}</Link>}
              </li>
            ))}
          </ul>
        </section>

        <section className="card stack">
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <h2>{t('À surveiller')}</h2>
            {view.watch.length > 0 && <span className="badge danger">{view.watch.length}</span>}
          </div>
          {!view.watch.length && <p className="muted small">{t('Rien d’anormal pour le moment.')}</p>}
          <ul className="today-list">
            {view.watch.slice(0, 12).map((iv) => <JobLine key={iv.id} iv={iv} />)}
          </ul>
        </section>
      </div>

      {view.finished.length > 0 && (
        <section className="card stack">
          <h2>{t('Terminées aujourd’hui')}</h2>
          <ul className="today-list">
            {view.finished.map((iv) => <JobLine key={iv.id} iv={iv} />)}
          </ul>
        </section>
      )}
    </>
  );
}

function JobLine({ iv }: { iv: InterventionRow }) {
  const st = iv.status === 'TO_PLAN' ? null : stateOf(iv);
  return (
    <li>
      <span className="plan-dot" style={{ background: st ? STATE_COLOR[st] : '#B45309' }} aria-hidden="true" />
      <span className="grow">
        <Link to={`/interventions/${iv.id}`}><strong>{iv.clientName}</strong></Link>
        <span className="small muted">
          {' · '}{iv.scheduledStart ? fmtTime(iv.scheduledStart) : t('à planifier')}
          {iv.technicianFirstName ? ` · ${fullName(iv.technicianFirstName, iv.technicianLastName)}` : ''}
          {iv.siteCity ? ` · ${iv.siteCity}` : ''}
        </span>
      </span>
      <span className="small">{st ? stateLabel(iv) : iv.priority === 'URGENT' ? t('Urgente') : ''}</span>
    </li>
  );
}

/** Chiffres du mois et comparaison des agences (direction) */
function MonthOverview() {
  const { company } = useAuth();
  const { data, error, loading } = useLoad(
    () => api<{ agencies: DashboardRow[]; deadlines?: DeadlineRow[] }>(`/dashboard${qs({ companyId: company?.id })}`),
    [company?.id],
  );
  const rows = data?.agencies ?? [];
  const sum = (k: 'total' | 'done' | 'toPlan' | 'urgentOpen') => rows.reduce((s, r) => s + r[k], 0);
  const month = new Intl.DateTimeFormat(uiLocale(), { month: 'long', year: 'numeric' }).format(new Date());

  return (
    <>
      <h2 className="today-section">{t('Ce mois-ci')} · {month}</h2>
      {error && <p className="error">{error}</p>}

      <div className="grid">
        <Kpi label={t('Interventions du mois')} value={sum('total')} />
        <Kpi label={t('Terminées')} value={sum('done')} />
        <Kpi label={t('À planifier')} value={sum('toPlan')} />
        <Kpi label={t('Urgences en cours')} value={sum('urgentOpen')} />
      </div>

      {hasFeature('deadlines') && <ReportDeadlines rows={data?.deadlines ?? []} />}

      <section className="card">
        <h2 style={{ marginBottom: 12 }}>{t('Comparaison des agences')}</h2>
        {loading ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>{t('Agence')}</th>
                  <th className="num">{t('Interventions')}</th>
                  <th className="num">{t('Terminées')}</th>
                  <th className="num">{t('À planifier')}</th>
                  <th className="num">{t('À reprendre')}</th>
                  <th className="num">{t('Résolu au 1er passage')}</th>
                  <th className="num">{t('Délai fiche → envoi')}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td><strong>{r.name}</strong><div className="small muted">{r.companyName}</div></td>
                    <td className="num">{r.total}</td>
                    <td className="num">{r.done}</td>
                    <td className="num">{r.toPlan}</td>
                    <td className="num">{r.toResume}</td>
                    <td className="num">{r.firstTimeFixRate == null ? '—' : `${r.firstTimeFixRate} %`}</td>
                    <td className="num">{r.avgHoursToSend == null ? '—' : `${r.avgHoursToSend} h`}</td>
                  </tr>
                ))}
                {!rows.length && <tr><td colSpan={7} className="muted">{t('Aucune activité sur la période.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}

/** Itinéos Expertise : rapports à rendre, par date limite (délais de l'assureur) */
function ReportDeadlines({ rows }: { rows: DeadlineRow[] }) {
  const today = new Date().toISOString().slice(0, 10);
  const late = rows.filter((r) => deadlineState(r.dueDate, today) === 'OVERDUE').length;
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Rapports à rendre')}</h2>
        {late > 0 && <span className="badge danger">{tp(late, '{n} en retard', '{n} en retard')}</span>}
      </div>
      {rows.length ? (
        <div className="table-wrap">
          <table>
            <tbody>
              {rows.slice(0, 10).map((r) => (
                <tr key={r.id}>
                  <td><Link to={`/interventions/${r.id}`}>{r.number}</Link></td>
                  <td><strong>{r.clientName}</strong><div className="small muted">{r.reason}</div></td>
                  <td className="small">{r.technicianFirstName ? fullName(r.technicianFirstName, r.technicianLastName) : '—'}</td>
                  <td><DueBadge state={deadlineState(r.dueDate, today)} label={t('À rendre le {date}', { date: fmtDay(r.dueDate) })} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <p className="small muted">{t('Aucun rapport en attente.')}</p>}
    </section>
  );
}

function Kpi({ label, value, to, tone }: { label: string; value: number; to?: string; tone?: 'ok' | 'info' | 'warn' | 'danger' }) {
  const body = (
    <>
      <div className="small muted">{label}</div>
      <div className={`kpi-value${tone ? ` kpi-${tone}` : ''}`}>{value}</div>
    </>
  );
  return to ? <Link to={to} className="card kpi-link">{body}</Link> : <div className="card">{body}</div>;
}
