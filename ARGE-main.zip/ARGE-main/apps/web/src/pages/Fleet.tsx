import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  OWNERSHIP_LABELS, OWNERSHIPS, VEHICLE_DEADLINE_LABELS, VEHICLE_STATUS_LABELS, VEHICLE_TYPE_LABELS, VEHICLE_TYPES,
  type Ownership, type VehicleType,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { DueBadge } from '../components/DueBadge';
import { fmtDay, fullName } from '../format';
import type { DeadlinesOverview, VehicleRow } from '../types';
import { t, tl, uiLocale } from '../i18n';
import { FleetMapTab } from './FleetMap';

export const km = (n: number | null | undefined) => (n == null ? '—' : `${n.toLocaleString(uiLocale())} km`);

/** Parc véhicules : tous les véhicules, et ce qui est à programmer (entretiens, contrôles, assurances…) */
export function FleetPage() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<'vehicles' | 'todo' | 'map'>('vehicles');
  const [all, setAll] = useState(false);
  const [adding, setAdding] = useState(false);
  const { data: vehicles, reload } = useLoad(
    () => (company ? api<VehicleRow[]>(`/fleet/vehicles${qs({ companyId: company.id, agencyId: agency?.id, all })}`) : Promise.resolve([])),
    [company?.id, agency?.id, all],
  );
  const { data: todo, reload: reloadTodo } = useLoad(
    () => (company ? api<DeadlinesOverview>(`/deadlines${qs({ companyId: company.id, agencyId: agency?.id })}`) : Promise.resolve(null)),
    [company?.id, agency?.id],
  );
  const count = todo?.vehicles.length ?? 0;

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Parc véhicules')}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="row">
        <div className="chips" role="tablist">
          <button type="button" role="tab" aria-selected={tab === 'vehicles'} className={`chip${tab === 'vehicles' ? ' on' : ''}`} onClick={() => setTab('vehicles')}>{t('Véhicules ({n})', { n: vehicles?.length ?? 0 })}</button>
          <button type="button" role="tab" aria-selected={tab === 'todo'} className={`chip${tab === 'todo' ? ' on' : ''}`} onClick={() => setTab('todo')}>
            {t('À programmer')} {count > 0 && <span className="badge warn" style={{ marginLeft: 4 }}>{count}</span>}
          </button>
          <button type="button" role="tab" aria-selected={tab === 'map'} className={`chip${tab === 'map' ? ' on' : ''}`} onClick={() => setTab('map')}>{t('Carte')}</button>
        </div>
        <div className="grow" />
        {tab === 'vehicles' && <label className="check small"><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} />{t('Afficher les véhicules sortis du parc')}</label>}
        {has('fleet.write') && !adding && <button type="button" className="accent" onClick={() => setAdding(true)}>{t('Nouveau véhicule')}</button>}
      </div>
      {adding && <VehicleForm onDone={async (id) => { setAdding(false); if (id) navigate(`/fleet/${id}`); else await reload(); }} />}

      {tab === 'vehicles' && (
        <section className="card">
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Immatriculation')}</th><th>{t('Véhicule')}</th><th>{t('Conducteur')}</th><th style={{ textAlign: 'right' }}>{t('Kilométrage')}</th><th>{t('Prochaine échéance')}</th><th>{t('État')}</th></tr></thead>
              <tbody>
                {(vehicles ?? []).map((x) => (
                  <tr key={x.id} className="clickable" onClick={() => navigate(`/fleet/${x.id}`)}>
                    <td><Link to={`/fleet/${x.id}`} onClick={(e) => e.stopPropagation()}><strong>{x.plate}</strong></Link>
                      {x.status !== 'ACTIVE' && <div className="small muted">{tl(VEHICLE_STATUS_LABELS, x.status)}</div>}</td>
                    <td>{[x.make, x.model].filter(Boolean).join(' ') || '—'}<div className="small muted">{tl(VEHICLE_TYPE_LABELS, x.type)} · {tl(OWNERSHIP_LABELS, x.ownership)}</div></td>
                    <td>{x.driverId ? fullName(x.driverFirstName, x.driverLastName) : <span className="muted">—</span>}</td>
                    <td style={{ textAlign: 'right' }}>{km(x.mileage)}<div className="small muted">{x.mileageUpdatedOn ? t('relevé le {date}', { date: fmtDay(x.mileageUpdatedOn) }) : ''}</div></td>
                    <td className="small">{x.nextDue ? `${x.nextDue.label || tl(VEHICLE_DEADLINE_LABELS, x.nextDue.kind)} · ${fmtDay(x.nextDue.dueDate)}` : '—'}</td>
                    <td>{x.worstState && <DueBadge state={x.worstState} label={x.worstState === 'NONE' ? t('Aucune échéance') : undefined} />}</td>
                  </tr>
                ))}
                {vehicles && !vehicles.length && <tr><td colSpan={6} className="muted">{t('Aucun véhicule : ajoutez le premier avec « Nouveau véhicule ».')}</td></tr>}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {tab === 'map' && <FleetMapTab />}

      {tab === 'todo' && todo && <TodoList todo={todo} onChange={async () => { await Promise.all([reloadTodo(), reload()]); }} />}
    </>
  );
}

/** Échéances proches ou dépassées : prendre rendez-vous, puis noter l'entretien fait */
function TodoList({ todo, onChange }: { todo: DeadlinesOverview; onChange: () => Promise<void> }) {
  const { has } = useAuth();
  const [booking, setBooking] = useState<string | null>(null);
  const [date, setDate] = useState('');
  const [garage, setGarage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const book = async (id: string) => {
    setError(null);
    try {
      await api(`/fleet/deadlines/${id}`, { method: 'PATCH', body: { appointmentOn: date || null, appointmentWith: garage.trim() || null } });
      setBooking(null);
      await onChange();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  return (
    <section className="card stack">
      <p className="small muted" style={{ margin: 0 }}>
        {t("Échéances dépassées ou à moins de 30 jours (ou 1 500 km). Prenez rendez-vous, puis notez l'entretien dans la fiche du véhicule : l'échéance suivante se recalcule toute seule.")}
      </p>
      {error && <p className="error">{error}</p>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>{t('Véhicule')}</th><th>{t('Échéance')}</th><th>{t('Pour le')}</th><th>{t('État')}</th><th>{t('Rendez-vous')}</th></tr></thead>
          <tbody>
            {todo.vehicles.map((d) => (
              <tr key={d.id}>
                <td><Link to={`/fleet/${d.vehicleId}`}><strong>{d.plate}</strong></Link><div className="small muted">{[d.make, d.model].filter(Boolean).join(' ')}</div></td>
                <td>{d.label || tl(VEHICLE_DEADLINE_LABELS, d.kind)}</td>
                <td className="small">{[d.dueDate ? fmtDay(d.dueDate) : null, d.dueMileage != null ? t('{km} (actuel {now})', { km: km(d.dueMileage), now: km(d.mileage) }) : null].filter(Boolean).join(` ${t('ou')} `)}</td>
                <td><DueBadge state={d.state} /></td>
                <td>
                  {booking === d.id ? (
                    <span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                      <input type="date" aria-label={t('Date du rendez-vous')} value={date} onChange={(e) => setDate(e.target.value)} />
                      <input aria-label={t('Garage')} placeholder={t('Garage')} value={garage} onChange={(e) => setGarage(e.target.value)} style={{ width: 140 }} />
                      <button type="button" onClick={() => void book(d.id)}>OK</button>
                      <button type="button" className="ghost" onClick={() => setBooking(null)}>✕</button>
                    </span>
                  ) : d.appointmentOn ? (
                    <span className="small">{t('Le {date}', { date: fmtDay(d.appointmentOn) })}{d.appointmentWith ? ` · ${d.appointmentWith}` : ''}
                      {has('fleet.write') && <button type="button" className="ghost" onClick={() => { setBooking(d.id); setDate(d.appointmentOn ?? ''); setGarage(d.appointmentWith ?? ''); }}>{t('Modifier')}</button>}</span>
                  ) : has('fleet.write') ? (
                    <button type="button" className="secondary" onClick={() => { setBooking(d.id); setDate(''); setGarage(''); }}>{t('Prendre rendez-vous')}</button>
                  ) : <span className="muted small">{t('À programmer')}</span>}
                </td>
              </tr>
            ))}
            {!todo.vehicles.length && <tr><td colSpan={5} className="muted">{t('Rien à programmer : tout le parc est à jour.')}</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function VehicleForm({ onDone }: { onDone: (createdId: string | null) => void }) {
  const { company, agency } = useAuth();
  const [f, setF] = useState({ plate: '', type: 'VAN' as VehicleType, make: '', model: '', fuel: 'Diesel', ownership: 'OWNED' as Ownership, mileage: '', agencyId: agency?.id ?? '' });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const mileage = f.mileage.trim() ? Number(f.mileage.replace(/\s/g, '')) : null;
      if (mileage !== null && !(mileage >= 0)) throw new Error(t('Kilométrage invalide'));
      const created = await api<{ id: string }>('/fleet/vehicles', {
        method: 'POST',
        body: { companyId: company!.id, agencyId: f.agencyId || null, plate: f.plate, type: f.type, make: f.make || null, model: f.model || null, fuel: f.fuel || null, ownership: f.ownership, mileage },
      });
      onDone(created.id);
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{t('Nouveau véhicule')}</h2>
      <div className="row">
        <div className="field" style={{ width: 150 }}><label htmlFor="v-plate">{t('Immatriculation')}</label><input id="v-plate" value={f.plate} onChange={set('plate')} placeholder={t('AB-123-CD')} required /></div>
        <div className="field"><label htmlFor="v-type">{t('Type')}</label><select id="v-type" value={f.type} onChange={set('type')}>{VEHICLE_TYPES.map((x) => <option key={x} value={x}>{tl(VEHICLE_TYPE_LABELS, x)}</option>)}</select></div>
        <div className="field grow"><label htmlFor="v-make">{t('Marque')}</label><input id="v-make" value={f.make} onChange={set('make')} /></div>
        <div className="field grow"><label htmlFor="v-model">{t('Modèle|matériel')}</label><input id="v-model" value={f.model} onChange={set('model')} /></div>
      </div>
      <div className="row">
        <div className="field"><label htmlFor="v-own">{t('Propriété|statut')}</label><select id="v-own" value={f.ownership} onChange={set('ownership')}>{OWNERSHIPS.map((x) => <option key={x} value={x}>{tl(OWNERSHIP_LABELS, x)}</option>)}</select></div>
        <div className="field" style={{ width: 120 }}><label htmlFor="v-fuel">{t('Énergie')}</label><input id="v-fuel" value={f.fuel} onChange={set('fuel')} /></div>
        <div className="field" style={{ width: 140 }}><label htmlFor="v-km">{t('Kilométrage')}</label><input id="v-km" inputMode="numeric" value={f.mileage} onChange={set('mileage')} /></div>
        <div className="field"><label htmlFor="v-agency">{t('Agence')}</label>
          <select id="v-agency" value={f.agencyId} onChange={set('agencyId')}>
            <option value="">{t('Toute la société')}</option>
            {company?.agencies.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>
      </div>
      <p className="small muted" style={{ margin: 0 }}>{t('Vous pourrez ensuite choisir le conducteur et ajouter les échéances (entretien, contrôle technique…) dans la fiche du véhicule.')}</p>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Créer')}</button><button type="button" className="secondary" onClick={() => onDone(null)}>{t('Annuler')}</button></div>
    </form>
  );
}
