import { useState, type FormEvent } from 'react';
import { DocLanguageSelect } from '../components/DocLanguageSelect';
import { ScanButton } from '../components/ScanButton';
import { Link, useParams } from 'react-router-dom';
import { CONTRACT_STATUS_LABELS, formatMoney } from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import type { ClientDetail, ContractRow, QuoteRow } from '../types';
import { QuoteStatusBadge } from './Quotes';
import { KindBadge, StatusBadge } from '../components/Badges';
import { fmtDate } from '../format';
import { t, tl } from '../i18n';
import { hasFeature, hasModule } from '../edition';
import { SiteCheckpoints } from '../components/SiteCheckpoints';
import { getServer } from '../native';

function ClientContracts({ clientId }: { clientId: string }) {
  const { has } = useAuth();
  const { data } = useLoad(() => api<ContractRow[]>(`/contracts${qs({ clientId })}`), [clientId]);
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t("Contrats d'entretien")}</h2>
        {has('contract.write') && <Link className="btn secondary" to="/contracts/new">{t('Nouveau contrat')}</Link>}
      </div>
      {data?.length ? data.map((ct) => (
        <div key={ct.id} className="row small" style={{ justifyContent: 'space-between' }}>
          <span><Link to={`/contracts/${ct.id}`}>{ct.number}</Link> · {ct.title} · {ct.siteName}</span>
          <span className={`badge ${ct.status === 'ACTIVE' ? 'ok' : 'neutral'}`}>{tl(CONTRACT_STATUS_LABELS, ct.status)}</span>
        </div>
      )) : <p className="small muted">{t('Aucun contrat.')}</p>}
    </section>
  );
}

function ClientQuotes({ clientId }: { clientId: string }) {
  const { has } = useAuth();
  const { data } = useLoad(() => api<QuoteRow[]>(`/quotes${qs({ clientId })}`), [clientId]);
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Devis')}</h2>
        {has('quote.write') && <Link className="btn secondary" to="/quotes/new">{t('Nouveau devis')}</Link>}
      </div>
      {data?.length ? data.map((q) => (
        <div key={q.id} className="row small" style={{ justifyContent: 'space-between' }}>
          <span><Link to={`/quotes/${q.id}`}>{q.number}</Link> · {q.title} · {t('{amount} HT', { amount: formatMoney(q.netCents, q.currency) })}</span>
          <QuoteStatusBadge status={q.status} validUntil={q.validUntil} />
        </div>
      )) : <p className="small muted">{t('Aucun devis.')}</p>}
    </section>
  );
}

interface Mandate {
  id: string; reference: string; holderName: string; iban: string; bic: string | null; signedOn: string;
  status: 'ACTIVE' | 'REVOKED'; firstCollectedAt: string | null; revokedAt: string | null;
}

/** Mandat de prélèvement SEPA signé par le client : ses factures pourront être prélevées */
function ClientMandate({ client }: { client: ClientDetail }) {
  const { has } = useAuth();
  const canWrite = has('invoice.write');
  const { data, reload } = useLoad(() => api<Mandate[]>(`/clients/${client.id}/mandates`), [client.id]);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ holderName: client.name, iban: '', bic: '', reference: '', signedOn: '' });
  const [error, setError] = useState<string | null>(null);
  const active = data?.find((m) => m.status === 'ACTIVE');
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api(`/clients/${client.id}/mandates`, {
        method: 'POST',
        body: { holderName: form.holderName.trim(), iban: form.iban, bic: form.bic.trim() || null, reference: form.reference.trim() || null, signedOn: form.signedOn },
      });
      setAdding(false);
      setForm((f) => ({ ...f, iban: '', bic: '', reference: '' }));
      await reload();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const revoke = async (m: Mandate) => {
    if (!window.confirm(t('Révoquer le mandat {ref} ? Les factures de ce client ne seront plus prélevées.', { ref: m.reference }))) return;
    await api(`/mandates/${m.id}/revoke`, { method: 'POST' }).catch((err) => setError((err as Error).message));
    await reload();
  };

  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Prélèvement SEPA')}</h2>
        {canWrite && !adding && <button type="button" className="secondary" onClick={() => setAdding(true)}>{active ? t('Remplacer le mandat') : t('Enregistrer un mandat')}</button>}
      </div>
      {active ? (
        <div className="row small" style={{ justifyContent: 'space-between' }}>
          <span>
            <span className="badge ok">{t('Mandat actif')}</span>{' '}
            {t('Réf. {ref} · {holder} · {iban} · signé le {date}', { ref: active.reference, holder: active.holderName, iban: active.iban, date: fmtDate(active.signedOn) })}
            {!active.firstCollectedAt && <> · <span className="muted">{t('premier prélèvement à venir')}</span></>}
          </span>
          {canWrite && <button type="button" className="ghost" onClick={() => void revoke(active)}>{t('Révoquer')}</button>}
        </div>
      ) : <p className="small muted">{t('Aucun mandat : les factures de ce client se règlent par virement, chèque ou carte.')}</p>}
      {adding && (
        <form className="stack" onSubmit={save}>
          <div className="row">
            <div className="field grow"><label htmlFor="md-holder">{t('Titulaire du compte')}</label><input id="md-holder" value={form.holderName} onChange={set('holderName')} required /></div>
            <div className="field grow"><label htmlFor="md-iban">{t('IBAN')}</label><input id="md-iban" value={form.iban} onChange={set('iban')} placeholder="FR76 …" required autoComplete="off" /></div>
            <div className="field" style={{ width: 150 }}><label htmlFor="md-bic">{t('BIC (facultatif)')}</label><input id="md-bic" value={form.bic} onChange={set('bic')} autoComplete="off" /></div>
          </div>
          <div className="row">
            <div className="field"><label htmlFor="md-date">{t('Signé le')}</label><input id="md-date" type="date" value={form.signedOn} onChange={set('signedOn')} required /></div>
            <div className="field grow"><label htmlFor="md-ref">{t('Référence du mandat (vide = créée automatiquement)')}</label><input id="md-ref" value={form.reference} onChange={set('reference')} maxLength={35} /></div>
          </div>
          <p className="small muted" style={{ margin: 0 }}>{t('Gardez le mandat papier ou électronique signé par le client : la banque peut le demander.')}</p>
          {error && <p className="error">{error}</p>}
          <div className="row">
            <button type="submit">{t('Enregistrer')}</button>
            <button type="button" className="secondary" onClick={() => setAdding(false)}>{t('Annuler')}</button>
          </div>
        </form>
      )}
      {!adding && error && <p className="error">{error}</p>}
    </section>
  );
}

/** Entreprise cliente : SIREN et n° de TVA intracommunautaire, obligatoires sur les factures électroniques */
function ClientLegalIds({ client }: { client: ClientDetail }) {
  const { has } = useAuth();
  const [siren, setSiren] = useState(client.siren ?? '');
  const [vat, setVat] = useState(client.vatNumber ?? '');
  const [msg, setMsg] = useState<string | null>(null);
  const save = async () => {
    const body = { siren: siren.trim() || null, vatNumber: vat.trim() || null };
    if ((client.siren ?? null) === body.siren && (client.vatNumber ?? null) === body.vatNumber) return;
    try {
      await api(`/clients/${client.id}`, { method: 'PATCH', body });
      Object.assign(client, body);
      setMsg(t('Enregistré'));
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  return (
    <section className="card stack" style={{ gap: 8 }}>
      <div className="row">
        <div className="field grow">
          <label htmlFor="client-siren">{t('SIREN ou SIRET')}</label>
          <input id="client-siren" inputMode="numeric" value={siren} disabled={!has('client.write')} onChange={(e) => setSiren(e.target.value)} onBlur={() => void save()} />
        </div>
        <div className="field grow">
          <label htmlFor="client-vat">{t('N° de TVA intracommunautaire')}</label>
          <input id="client-vat" value={vat} disabled={!has('client.write')} onChange={(e) => setVat(e.target.value)} onBlur={() => void save()} />
        </div>
      </div>
      <span className="small muted">{msg ?? t('Obligatoires sur les factures électroniques entre entreprises.')}</span>
    </section>
  );
}

/** N° d'abonné (télésurveillance, contrat…) : retrouvé par la recherche, repris sur la fiche « Consignes » */
function ClientSubscriber({ client }: { client: ClientDetail }) {
  const { has } = useAuth();
  const [value, setValue] = useState(client.subscriberNumber ?? '');
  const [msg, setMsg] = useState<string | null>(null);
  const save = async () => {
    if ((client.subscriberNumber ?? '') === value.trim()) return;
    try {
      await api(`/clients/${client.id}`, { method: 'PATCH', body: { subscriberNumber: value.trim() || null } });
      client.subscriberNumber = value.trim() || null;
      setMsg(t('Enregistré'));
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  return (
    <section className="card stack" style={{ gap: 8 }}>
      <div className="field">
        <label htmlFor="client-sub">{t('N° d’abonné')}</label>
        <input id="client-sub" value={value} disabled={!has('client.write')} onChange={(e) => setValue(e.target.value)} onBlur={() => void save()} />
      </div>
      {msg && <span className="small muted">{msg}</span>}
    </section>
  );
}

/** Langue des devis, factures, fiches et e-mails envoyés à ce client */
function ClientDocLanguage({ client }: { client: ClientDetail }) {
  const { has } = useAuth();
  const [value, setValue] = useState(client.locale ?? '');
  const [msg, setMsg] = useState<string | null>(null);
  const change = async (v: string) => {
    setValue(v);
    setMsg(null);
    try {
      await api(`/clients/${client.id}`, { method: 'PATCH', body: { locale: v || null } });
      setMsg(t('Enregistré'));
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  return (
    <section className="card stack" style={{ gap: 8 }}>
      <div className="field">
        <label htmlFor="client-doc-lang">{t('Langue des documents')}</label>
        <DocLanguageSelect id="client-doc-lang" value={value} disabled={!has('client.write')} onChange={(v) => void change(v)} />
      </div>
      <span className="small muted">{t('Devis, factures, fiches d’intervention et e-mails envoyés à ce client sont rédigés dans cette langue.')}{msg ? ` · ${msg}` : ''}</span>
    </section>
  );
}

interface PortalAccess { id: string; email: string; name: string; active: boolean; activated: boolean; invitedAt: string | null; lastLoginAt: string | null }

/** Accès du client à son espace en ligne : invitation par e-mail, renvoi, coupure */
function ClientPortalAccess({ client }: { client: ClientDetail }) {
  const { has, company } = useAuth();
  const canWrite = has('client.write');
  const { data, reload } = useLoad(() => api<PortalAccess[]>(`/clients/${client.id}/portal-users`), [client.id]);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState(client.email ?? '');
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const invite = async (body: { email: string; name: string }) => {
    setError(null);
    setMsg(null);
    try {
      await api(`/clients/${client.id}/portal-users`, { method: 'POST', body });
      setMsg(t('Invitation envoyée à {email}.', { email: body.email }));
      setOpen(false);
      setName('');
      await reload();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  const toggle = async (a: PortalAccess) => {
    setError(null);
    await api(`/portal-users/${a.id}`, { method: 'PATCH', body: { active: !a.active } }).catch((e) => setError((e as Error).message));
    await reload();
  };

  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h2>{t('Espace client en ligne')}</h2>
          <div className="small muted">{t('Le client suit ses interventions, ses devis et ses factures, et demande une intervention.')}</div>
        </div>
        {canWrite && !open && <button type="button" className="secondary" onClick={() => setOpen(true)}>{t('Inviter une personne')}</button>}
      </div>
      {open && (
        <form className="row" style={{ alignItems: 'flex-end' }} onSubmit={(e: FormEvent) => { e.preventDefault(); void invite({ email, name }); }}>
          <div className="field grow" style={{ minWidth: 180 }}><label htmlFor="pa-name">{t('Nom')}</label><input id="pa-name" value={name} onChange={(e) => setName(e.target.value)} required /></div>
          <div className="field grow" style={{ minWidth: 220 }}><label htmlFor="pa-email">{t('E-mail')}</label><input id="pa-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
          <button type="submit">{t("Envoyer l'invitation")}</button>
          <button type="button" className="ghost" onClick={() => setOpen(false)}>{t('Annuler')}</button>
        </form>
      )}
      {msg && <p className="success small" role="status">{msg}</p>}
      {error && <p className="error small" role="alert">{error}</p>}
      {data?.length ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('Nom')}</th><th>{t('E-mail')}</th><th>{t('État')}</th><th>{t('Dernière connexion')}</th>{canWrite && <th />}</tr></thead>
            <tbody>
              {data.map((a) => (
                <tr key={a.id} style={{ opacity: a.active ? 1 : 0.55 }}>
                  <td>{a.name}</td>
                  <td className="small">{a.email}</td>
                  <td>{!a.active ? <span className="badge neutral">{t('Accès coupé')}</span>
                    : a.activated ? <span className="badge ok">{t('Actif')}</span>
                      : <span className="badge warn">{t('Invitation envoyée')}</span>}</td>
                  <td className="small">{fmtDate(a.lastLoginAt, company?.timezone)}</td>
                  {canWrite && (
                    <td className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                      {a.active && !a.activated && <button type="button" className="ghost" onClick={() => void invite({ email: a.email, name: a.name })}>{t("Renvoyer l'invitation")}</button>}
                      <button type="button" className="ghost" onClick={() => void toggle(a)}>{a.active ? t("Couper l'accès") : t("Rétablir l'accès")}</button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <p className="small muted">{t("Aucun accès pour l'instant.")}</p>}
      <p className="small muted" style={{ margin: 0 }}>{t('Adresse de l’espace client : {url}', { url: `${getServer() || window.location.origin}/portail` })}</p>
    </section>
  );
}

export function ClientDetailPage() {
  const { id } = useParams();
  const { has, company } = useAuth();
  const { data: c, error, reload } = useLoad(() => api<ClientDetail>(`/clients/${id}`), [id]);
  const [addingSite, setAddingSite] = useState(false);
  const [addingEquipmentTo, setAddingEquipmentTo] = useState<string | null>(null);
  const [editingEquipment, setEditingEquipment] = useState<string | null>(null);
  const canWrite = has('client.write');

  if (error) return <p className="error">{error}</p>;
  if (!c) return <p className="muted">{t('Chargement…')}</p>;

  return (
    <div className="stack" style={{ maxWidth: 1000 }}>
      <div>
        <div className="eyebrow">{c.type === 'COMPANY' ? t('Entreprise') : t('Particulier')}</div>
        <h1>{c.name}</h1>
        <p className="muted">{[c.address, c.postalCode, c.city].filter(Boolean).join(', ')} · {[c.phone, c.email].filter(Boolean).join(' · ')}</p>
      </div>

      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Sites et équipements')}</h2>
        {canWrite && <button type="button" className="secondary" onClick={() => setAddingSite(true)}>{t('Ajouter un site')}</button>}
      </div>
      {addingSite && <SiteForm clientId={c.id} onDone={() => { setAddingSite(false); void reload(); }} />}

      {c.sites.map((s) => (
        <section key={s.id} className="card stack">
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <div>
              <h3>{s.name}</h3>
              <div className="small muted">{[s.address, s.postalCode, s.city].filter(Boolean).join(', ')}</div>
              {s.accessNotes && <div className="small">{t('Accès : {notes}', { notes: s.accessNotes })}</div>}
            </div>
            {canWrite && <button type="button" className="ghost" onClick={() => setAddingEquipmentTo(s.id)}>{t('Ajouter un équipement')}</button>}
          </div>
          {s.equipments.length ? (
            <div className="table-wrap">
              <table>
                <thead><tr><th>{t('Équipement')}</th><th>{t('N° de série')}</th><th>{t('Emplacement')}</th><th>{t('Installé le')}</th><th>{t('Contrat')}</th>{canWrite && <th />}</tr></thead>
                <tbody>
                  {s.equipments.map((e) => (
                    <tr key={e.id}>
                      <td><strong>{e.category}</strong><div className="small muted">{[e.brand, e.model].filter(Boolean).join(' ')}</div></td>
                      <td>{e.serialNumber ?? '—'}</td>
                      <td>{e.location ?? '—'}{e.locateHint && <div className="small locate-hint">⚠ {e.locateHint}</div>}</td>
                      <td>{e.installedAt ? fmtDate(e.installedAt, company?.timezone) : '—'}</td>
                      <td>{e.underContract ? <span className="badge ok">{t('Sous contrat')}</span> : '—'}</td>
                      {canWrite && <td><button type="button" className="ghost" onClick={() => setEditingEquipment(e.id)}>{t('Modifier')}</button></td>}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <p className="small muted">{t('Aucun équipement enregistré.')}</p>}
          {addingEquipmentTo === s.id && <EquipmentForm siteId={s.id} onDone={() => { setAddingEquipmentTo(null); void reload(); }} />}
          {s.equipments.filter((e) => e.id === editingEquipment).map((e) => (
            <EquipmentForm key={e.id} siteId={s.id} initial={e} onDone={() => { setEditingEquipment(null); void reload(); }} />
          ))}
          {hasFeature('checkpoints') && <SiteCheckpoints siteId={s.id} siteName={s.name} canWrite={canWrite} />}
        </section>
      ))}

      <ClientSubscriber client={c} />
      {c.type === 'COMPANY' && <ClientLegalIds client={c} />}
      <ClientDocLanguage client={c} />
      <ClientPortalAccess client={c} />
      {has('invoice.read') && hasModule('invoices') && <ClientMandate client={c} />}
      {has('contract.read') && hasModule('contracts') && <ClientContracts clientId={c.id} />}
      {has('quote.read') && hasModule('quotes') && <ClientQuotes clientId={c.id} />}

      <section className="card stack">
        <h2>{t('Historique')}</h2>
        {c.history.length ? (
          <div className="table-wrap">
            <table>
              <tbody>
                {c.history.map((h) => (
                  <tr key={h.id}>
                    <td><Link to={`/interventions/${h.id}`}>{h.number}</Link></td>
                    <td>{fmtDate(h.scheduledStart, company?.timezone)}</td>
                    <td><KindBadge kind={h.kind} /></td>
                    <td>{h.reason}</td>
                    <td><StatusBadge status={h.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="small muted">{t('Aucune intervention pour ce client.')}</p>}
      </section>
    </div>
  );
}

function SiteForm({ clientId, onDone }: { clientId: string; onDone: () => void }) {
  const [f, setF] = useState({ name: '', address: '', postalCode: '', city: '', accessNotes: '' });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api(`/clients/${clientId}/sites`, { method: 'POST', body: f });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={submit}>
      <div className="row">
        <div className="field grow"><label htmlFor="s-name">{t('Nom du site')}</label><input id="s-name" value={f.name} onChange={set('name')} required /></div>
        <div className="field grow"><label htmlFor="s-address">{t('Adresse')}</label><input id="s-address" value={f.address} onChange={set('address')} /></div>
      </div>
      <div className="row">
        <div className="field" style={{ width: 140 }}><label htmlFor="s-pc">{t('Code postal')}</label><input id="s-pc" value={f.postalCode} onChange={set('postalCode')} /></div>
        <div className="field grow"><label htmlFor="s-city">{t('Ville')}</label><input id="s-city" value={f.city} onChange={set('city')} /></div>
        <div className="field grow"><label htmlFor="s-access">{t("Consignes d'accès")}</label><input id="s-access" value={f.accessNotes} onChange={set('accessNotes')} /></div>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Ajouter le site')}</button><button type="button" className="secondary" onClick={onDone}>{t('Annuler')}</button></div>
    </form>
  );
}

type EquipmentInput = { id: string; category: string; brand: string | null; model: string | null; serialNumber: string | null; location: string | null; locateHint?: string | null; installedAt: string | null; underContract: boolean };

function EquipmentForm({ siteId, initial, onDone }: { siteId: string; initial?: EquipmentInput; onDone: () => void }) {
  const [f, setF] = useState({
    category: initial?.category ?? '', brand: initial?.brand ?? '', model: initial?.model ?? '', serialNumber: initial?.serialNumber ?? '',
    location: initial?.location ?? '', locateHint: initial?.locateHint ?? '', installedAt: initial?.installedAt?.slice(0, 10) ?? '', underContract: initial?.underContract ?? false,
  });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const body = { ...f, installedAt: f.installedAt || undefined };
      if (initial) await api(`/equipments/${initial.id}`, { method: 'PATCH', body });
      else await api(`/sites/${siteId}/equipments`, { method: 'POST', body });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="stack" onSubmit={submit} style={{ borderTop: '1px solid var(--ground-2)', paddingTop: 12 }}>
      <div className="row">
        <div className="field grow"><label htmlFor="e-cat">{t('Type de matériel')}</label><input id="e-cat" value={f.category} onChange={set('category')} required placeholder={t('Climatiseur, chaudière, alarme…')} /></div>
        <div className="field grow"><label htmlFor="e-brand">{t('Marque')}</label><input id="e-brand" value={f.brand} onChange={set('brand')} /></div>
        <div className="field grow"><label htmlFor="e-model">{t('Modèle|matériel')}</label><input id="e-model" value={f.model} onChange={set('model')} /></div>
      </div>
      <div className="row">
        <div className="field grow"><label htmlFor="e-sn">{t('N° de série')}</label>
          <div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}><input id="e-sn" className="grow" value={f.serialNumber} onChange={set('serialNumber')} /><ScanButton onResult={(v) => setF((x) => ({ ...x, serialNumber: v }))} /></div></div>
        <div className="field grow"><label htmlFor="e-loc">{t('Emplacement')}</label><input id="e-loc" value={f.location} onChange={set('location')} /></div>
        <div className="field" style={{ width: 180 }}><label htmlFor="e-date">{t('Installé le')}</label><input id="e-date" type="date" value={f.installedAt} onChange={set('installedAt')} /></div>
      </div>
      <div className="field"><label htmlFor="e-hint">{t('Difficile à trouver ? Indiquez où il est (montré en évidence au technicien)')}</label><input id="e-hint" value={f.locateHint} onChange={set('locateHint')} placeholder={t('Ex. : dans le faux plafond du couloir, trappe à gauche de la porte')} /></div>
      <label className="check"><input type="checkbox" checked={f.underContract} onChange={(e) => setF((x) => ({ ...x, underContract: e.target.checked }))} />{t("Sous contrat d'entretien")}</label>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{initial ? t('Enregistrer') : t("Ajouter l'équipement")}</button><button type="button" className="secondary" onClick={onDone}>{t('Annuler')}</button></div>
    </form>
  );
}
