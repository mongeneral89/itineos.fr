/**
 * Itinéos Services : registre des traitements. Chaque fiche anti-nuisibles signée y figure avec les produits
 * biocides utilisés (nom, n° d'autorisation, dose), les zones traitées et le délai de réoccupation.
 * Exportable en CSV pour le client ou un contrôle.
 */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import type { TreatmentRow } from '../types';
import { OrgPicker } from '../components/Layout';
import { fmtDate, fullName } from '../format';
import { t, tp } from '../i18n';

const isoDay = (d: Date) => d.toISOString().slice(0, 10);

function downloadCsv(rows: TreatmentRow[], timezone: string | undefined) {
  const head = [t('Date'), t('N°'), t('Client'), t('Site'), t('Nuisible'), t('Zones traitées'), t('Produits biocides'), t('Postes d’appâtage'), t('Réoccupation'), t('Intervenant')];
  const cell = (v: string | number | null) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = rows.map((r) => [
    fmtDate(r.signedAt, timezone), r.number, r.clientName, [r.siteName, r.siteCity].filter(Boolean).join(', '), r.pest, r.zones,
    r.biocides, r.baitStations, r.reentry, fullName(r.technicianFirstName, r.technicianLastName),
  ].map(cell).join(';'));
  const blob = new Blob([`﻿${[head.map(cell).join(';'), ...lines].join('\r\n')}`], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `registre-traitements-${isoDay(new Date())}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

export function TreatmentsPage() {
  const { company, agency } = useAuth();
  const now = new Date();
  const [from, setFrom] = useState(isoDay(new Date(now.getFullYear() - 1, now.getMonth(), now.getDate())));
  const [to, setTo] = useState(isoDay(now));
  const end = isoDay(new Date(new Date(`${to}T00:00:00`).getTime() + 86_400_000));
  const { data, error, loading } = useLoad(
    () => api<TreatmentRow[]>(`/registers/treatments${qs({ companyId: company?.id, agencyId: agency?.id, from, to: end })}`),
    [company?.id, agency?.id, from, end],
  );
  const rows = data ?? [];

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Registre des traitements')}</h1>
        </div>
        <OrgPicker />
      </div>
      <p className="muted small">{t('Produits biocides utilisés, repris des fiches anti-nuisibles signées.')}</p>

      <div className="row" style={{ alignItems: 'flex-end' }}>
        <div className="field"><label htmlFor="tr-from">{t('Du')}</label><input id="tr-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div className="field"><label htmlFor="tr-to">{t('Au')}</label><input id="tr-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <div className="grow" />
        <span className="small muted">{tp(rows.length, '{n} traitement', '{n} traitements')}</span>
        <button type="button" className="secondary" disabled={!rows.length} onClick={() => downloadCsv(rows, company?.timezone)}>{t('Exporter en CSV')}</button>
      </div>

      {error && <p className="error">{error}</p>}
      <section className="card">
        {loading && !data ? <p className="muted">{t('Chargement…')}</p> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>{t('Date')}</th><th>{t('Client')}</th><th>{t('Nuisible')}</th><th>{t('Zones traitées')}</th><th>{t('Produits biocides')}</th><th>{t('Intervenant')}</th></tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.interventionId}>
                    <td>{fmtDate(r.signedAt, company?.timezone)}<div className="small"><Link to={`/interventions/${r.interventionId}`}>{r.number}</Link></div></td>
                    <td><strong>{r.clientName}</strong><div className="small muted">{[r.siteName, r.siteCity].filter(Boolean).join(', ')}</div></td>
                    <td>{r.pest || '—'}</td>
                    <td className="small">{r.zones || '—'}</td>
                    <td className="small">{r.biocides || '—'}{r.baitStations ? <div className="muted">{tp(r.baitStations, '{n} poste d’appâtage', '{n} postes d’appâtage')}</div> : null}</td>
                    <td className="small">{fullName(r.technicianFirstName, r.technicianLastName)}</td>
                  </tr>
                ))}
                {data && !rows.length && <tr><td colSpan={6} className="muted">{t('Aucun traitement sur la période.')}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
