import { useState, type FormEvent } from 'react';
import { addMonths } from '@itineo/shared';
import { api, openPdf, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { DueBadge } from '../components/DueBadge';
import { fmtDay } from '../format';
import type { CertificationMatrix, CertificationType, UserCertification } from '../types';
import { t } from '../i18n';

interface Editing { userId: string; name: string; type: CertificationType; cert: UserCertification | null }

/** Habilitations : qui a quoi, jusqu'à quand. Vert = valable, orange = expire dans 60 jours, rouge = expirée. */
export function CertificationsPage() {
  const { company, agency, has } = useAuth();
  const canWrite = has('certification.write');
  const { data: types, reload: reloadTypes } = useLoad(() => api<CertificationType[]>('/certification-types'), []);
  const { data: matrix, reload } = useLoad(
    () => (company ? api<CertificationMatrix>(`/certifications${qs({ companyId: company.id, agencyId: agency?.id })}`) : Promise.resolve(null)),
    [company?.id, agency?.id],
  );
  const [editing, setEditing] = useState<Editing | null>(null);
  const [addingType, setAddingType] = useState(false);
  const active = (types ?? []).filter((ct) => ct.active);

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Habilitations')}</h1>
        </div>
        <OrgPicker />
      </div>
      <p className="small muted" style={{ maxWidth: 760, margin: 0 }}>
        <span className="badge ok">{t('À jour')}</span> {t('valable')} · <span className="badge warn">{t('Bientôt')}</span> {t('expire dans moins de 60 jours')} ·{' '}
        <span className="badge danger">{t('Dépassé')}</span> {t('expirée.')} {t("Le planning prévient si une intervention exige une habilitation que le technicien n'a pas.")}
      </p>

      {editing && <CertificationForm editing={editing} onClose={() => setEditing(null)} onDone={async () => { setEditing(null); await reload(); }} />}

      <section className="card">
        <div className="table-wrap">
          <table className="matrix">
            <thead>
              <tr><th>{t('Technicien')}</th>{active.map((ct) => <th key={ct.id} title={ct.name}>{ct.code}</th>)}</tr>
            </thead>
            <tbody>
              {(matrix?.technicians ?? []).map((tech) => (
                <tr key={tech.id}>
                  <td><strong>{tech.firstName} {tech.lastName}</strong></td>
                  {active.map((type) => {
                    const cert = tech.certifications.find((c) => c.typeId === type.id) ?? null;
                    const open = () => setEditing({ userId: tech.id, name: `${tech.firstName} ${tech.lastName}`, type, cert });
                    return (
                      <td key={type.id}>
                        {cert ? (
                          <button type="button" className="cert-cell" onClick={open} disabled={!canWrite} title={type.name}>
                            <DueBadge state={cert.state} label={cert.expiresOn ? fmtDay(cert.expiresOn) : t('Sans limite')} />
                            {cert.hasDocument && <span className="small muted">{t('justificatif ✓')}</span>}
                          </button>
                        ) : canWrite ? <button type="button" className="ghost" aria-label={t('Ajouter {code} pour {name}', { code: type.code, name: `${tech.firstName} ${tech.lastName}` })} onClick={open}>+</button> : <span className="muted">—</span>}
                      </td>
                    );
                  })}
                </tr>
              ))}
              {matrix && !matrix.technicians.length && <tr><td colSpan={active.length + 1} className="muted">{t('Aucun technicien dans ce périmètre.')}</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card stack">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h2>{t("Types d'habilitation")}</h2>
          {canWrite && !addingType && <button type="button" className="secondary" onClick={() => setAddingType(true)}>{t('Nouveau type')}</button>}
        </div>
        {addingType && <TypeForm onDone={async () => { setAddingType(false); await reloadTypes(); }} />}
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('Code')}</th><th>{t('Nom')}</th><th>{t('Validité habituelle')}</th></tr></thead>
            <tbody>
              {(types ?? []).map((ct) => (
                <tr key={ct.id} style={{ opacity: ct.active ? 1 : 0.5 }}>
                  <td><strong>{ct.code}</strong></td><td>{ct.name}<div className="small muted">{ct.description ?? ''}</div></td>
                  <td>{ct.validityMonths ? t('{n} mois', { n: ct.validityMonths }) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(new Error(t('Fichier illisible')));
    r.readAsDataURL(file);
  });
}

function CertificationForm({ editing, onClose, onDone }: { editing: Editing; onClose: () => void; onDone: () => Promise<void> }) {
  const { type, cert } = editing;
  const [obtainedOn, setObtainedOn] = useState(cert?.obtainedOn ?? '');
  const [expiresOn, setExpiresOn] = useState(cert?.expiresOn ?? '');
  const [reference, setReference] = useState(cert?.reference ?? '');
  const [document, setDocument] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onObtained = (d: string) => {
    setObtainedOn(d);
    // Date d'expiration proposée selon la validité habituelle du type
    if (d && type.validityMonths && !expiresOn) setExpiresOn(addMonths(d, type.validityMonths));
  };
  const onFile = async (f: File | undefined) => {
    setError(null);
    if (!f) return setDocument(null);
    if (f.size > 5 * 1024 * 1024) return setError(t('Fichier trop lourd (5 Mo maximum)'));
    if (!['application/pdf', 'image/jpeg', 'image/png'].includes(f.type)) return setError(t('PDF, JPEG ou PNG uniquement'));
    setDocument(await readFile(f));
  };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const body = { obtainedOn: obtainedOn || null, expiresOn: expiresOn || null, reference: reference.trim() || null, ...(document ? { document } : {}) };
      if (cert) await api(`/certifications/${cert.id}`, { method: 'PATCH', body });
      else await api('/certifications', { method: 'POST', body: { ...body, userId: editing.userId, typeId: type.id } });
      await onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const remove = async () => {
    if (!cert || !window.confirm(t("Retirer l'habilitation {code} de {name} ?", { code: type.code, name: editing.name }))) return;
    await api(`/certifications/${cert.id}`, { method: 'DELETE' }).then(onDone).catch((e) => setError(e.message));
  };

  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{type.name} · {editing.name}</h2>
      <div className="row">
        <div className="field"><label htmlFor="c-obt">{t('Obtenue le')}</label><input id="c-obt" type="date" value={obtainedOn} onChange={(e) => onObtained(e.target.value)} /></div>
        <div className="field"><label htmlFor="c-exp">{t('Expire le (vide = sans limite)')}</label><input id="c-exp" type="date" value={expiresOn} onChange={(e) => setExpiresOn(e.target.value)} /></div>
        <div className="field grow"><label htmlFor="c-ref">{t('Référence du titre')}</label><input id="c-ref" value={reference} onChange={(e) => setReference(e.target.value)} /></div>
      </div>
      <div className="row" style={{ alignItems: 'flex-end' }}>
        <div className="field grow"><label htmlFor="c-doc">{t('Justificatif (PDF ou photo, 5 Mo maximum)')}{cert?.hasDocument ? ` ${t(': remplace le justificatif actuel')}` : ''}</label>
          <input id="c-doc" type="file" accept="application/pdf,image/jpeg,image/png" onChange={(e) => void onFile(e.target.files?.[0])} />
        </div>
        {cert?.hasDocument && <button type="button" className="secondary" onClick={() => openPdf(`/certifications/${cert.id}/document`).catch((e) => setError(e.message))}>{t('Voir le justificatif')}</button>}
      </div>
      {error && <p className="error">{error}</p>}
      <div className="row">
        <button type="submit">{t('Enregistrer')}</button>
        <button type="button" className="secondary" onClick={onClose}>{t('Annuler')}</button>
        {cert && <button type="button" className="ghost" onClick={() => void remove()}>{t("Retirer l'habilitation")}</button>}
      </div>
    </form>
  );
}

function TypeForm({ onDone }: { onDone: () => Promise<void> }) {
  const [f, setF] = useState({ code: '', name: '', validity: '' });
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const months = f.validity.trim() ? Number(f.validity) : null;
      await api('/certification-types', { method: 'POST', body: { code: f.code, name: f.name, validityMonths: months } });
      await onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="row" onSubmit={submit} style={{ alignItems: 'flex-end' }}>
      <div className="field" style={{ width: 140 }}><label htmlFor="t-code">{t('Code')}</label><input id="t-code" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} required /></div>
      <div className="field grow"><label htmlFor="t-name">{t('Nom')}</label><input id="t-name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required /></div>
      <div className="field" style={{ width: 150 }}><label htmlFor="t-val">{t('Validité (mois)')}</label><input id="t-val" inputMode="numeric" value={f.validity} onChange={(e) => setF({ ...f, validity: e.target.value })} /></div>
      <button type="submit">{t('Ajouter')}</button>
      {error && <p className="error" style={{ width: '100%' }}>{error}</p>}
    </form>
  );
}
