import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { addDays, CONTRACT_FREQUENCIES, QUOTE_KIND_LABELS, QUOTE_KINDS, vatRatesFor, type QuoteKind } from '@itineo/shared';
import { api, openPdf, qs } from '../api';
import { useAuth } from '../auth';
import { fmtDateTime, toDateInput } from '../format';
import type { Client, ClientDetail, InterventionDetail, QuoteDetail, ReportBundle } from '../types';
import { LinesEditor, lineProblems, linesPayload, newLine, toELines, useCatalog, type ELine } from '../components/LinesEditor';
import { QuoteStatusBadge } from './Quotes';
import { t, tl } from '../i18n';

interface Draft {
  clientId: string;
  siteId: string;
  kind: QuoteKind;
  title: string;
  intro: string;
  notes: string;
  validUntil: string;
  contractFrequencyMonths: number;
  lines: ELine[];
}

export function QuoteEditPage() {
  const { id = 'new' } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { me, company: currentCompany, has } = useAuth();
  const isNew = id === 'new';

  const [quote, setQuote] = useState<QuoteDetail | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const companyId = quote?.companyId ?? currentCompany?.id;
  const company = me?.org.find((c) => c.id === companyId) ?? currentCompany;
  const rates = vatRatesFor(company?.countryCode ?? 'FR');
  const editable = has('quote.write') && (isNew || quote?.status === 'DRAFT');
  const catalog = useCatalog(companyId, editable);

  // Chargement : devis existant, ou nouveau (éventuellement à partir d'une intervention)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!isNew) {
          const q = await api<QuoteDetail>(`/quotes/${id}`);
          if (cancelled) return;
          setQuote(q);
          setDraft(fromQuote(q));
          return;
        }
        const base: Draft = {
          clientId: '', siteId: '', kind: 'WORK', title: '', intro: '', notes: '',
          validUntil: addDays(toDateInput(new Date()), 30), contractFrequencyMonths: 12, lines: [newLine(rates[0])],
        };
        const ivId = params.get('interventionId');
        if (ivId) {
          const iv = await api<InterventionDetail>(`/interventions/${ivId}`);
          base.clientId = iv.clientId;
          base.siteId = iv.siteId;
          base.title = iv.reason;
          if (iv.report) {
            // Pièces notées sur la fiche : reprises comme lignes (prix à compléter)
            const r = await api<ReportBundle>(`/interventions/${ivId}/report`);
            const parts = r.parts.map((p) => newLine(rates[0], { description: [p.label, p.reference].filter(Boolean).join(' – '), qty: String(p.quantity).replace('.', ',') }));
            if (parts.length) base.lines = [...parts, newLine(rates[0], { description: "Main-d'œuvre", unit: 'h' })];
          }
        }
        if (!cancelled) setDraft(base);
      } catch (e) {
        if (!cancelled) setError((e as Error).message);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // Sites du client choisi
  useEffect(() => {
    if (!draft?.clientId) {
      setClient(null);
      return;
    }
    let cancelled = false;
    void api<ClientDetail>(`/clients/${draft.clientId}`).then((c) => !cancelled && setClient(c)).catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [draft?.clientId]);

  const currency = quote?.currency ?? company?.currency ?? 'EUR';

  if (error && !draft) return <p className="error">{error}</p>;
  if (!draft) return <p className="muted">{t('Chargement…')}</p>;

  const set = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));

  const problems = (): string[] => {
    const out: string[] = [];
    if (!draft.clientId) out.push(t('Choisissez le client.'));
    if (!draft.title.trim()) out.push(t("Indiquez l'objet du devis."));
    return [...out, ...lineProblems(draft.lines)];
  };

  const payload = () => ({
    clientId: draft.clientId,
    siteId: draft.siteId || null,
    kind: draft.kind,
    title: draft.title.trim(),
    intro: draft.intro.trim() || null,
    notes: draft.notes.trim() || null,
    validUntil: draft.validUntil || null,
    contractFrequencyMonths: draft.kind === 'CONTRACT' ? draft.contractFrequencyMonths : null,
    lines: linesPayload(draft.lines),
    ...(isNew && params.get('interventionId') ? { sourceInterventionId: params.get('interventionId') } : {}),
  });

  const run = async (fn: () => Promise<void>, okMsg?: string) => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      await fn();
      if (okMsg) setMsg(okMsg);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const save = () => run(async () => {
    const p = problems();
    if (p.length) throw new Error(p.join(' '));
    if (isNew) {
      const created = await api<QuoteDetail>('/quotes', { method: 'POST', body: payload() });
      navigate(`/quotes/${created.id}`, { replace: true });
      setQuote(created);
      setDraft(fromQuote(created));
    } else {
      const updated = await api<QuoteDetail>(`/quotes/${id}`, { method: 'PUT', body: payload() });
      setQuote(updated);
      setDraft(fromQuote(updated));
    }
  }, t('Devis enregistré.'));

  const reload = (q: QuoteDetail) => {
    setQuote(q);
    setDraft(fromQuote(q));
  };

  return (
    <div className="stack" style={{ maxWidth: 1000 }}>
      <div className="topbar">
        <div>
          <div className="eyebrow"><Link to="/quotes">{t('Devis')}</Link>{quote ? ` · ${quote.number}` : ''}</div>
          <h1>{isNew ? t('Nouveau devis') : draft.title || t('Devis')}</h1>
        </div>
        {quote && <QuoteStatusBadge status={quote.status} validUntil={quote.validUntil} />}
      </div>

      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error" role="alert">{error}</p>}

      <section className="card stack">
        <div className="row">
          {isNew ? (
            <ClientPicker companyId={companyId} value={draft.clientId} onChange={(clientId) => set({ clientId, siteId: '' })} />
          ) : (
            <div className="field grow"><label>{t('Client')}</label><div><Link to={`/clients/${quote!.clientId}`}><strong>{quote!.client.name}</strong></Link></div></div>
          )}
          <div className="field grow">
            <label htmlFor="q-site">{t("Lieu d'intervention")}</label>
            <select id="q-site" value={draft.siteId} disabled={!editable || !client} onChange={(e) => set({ siteId: e.target.value })}>
              <option value="">—</option>
              {client?.sites.map((s) => <option key={s.id} value={s.id}>{s.name}{s.city ? ` · ${s.city}` : ''}</option>)}
            </select>
          </div>
        </div>
        <div className="row">
          <div className="field grow"><label htmlFor="q-title">{t('Objet')}</label>
            <input id="q-title" value={draft.title} disabled={!editable} maxLength={300} onChange={(e) => set({ title: e.target.value })} placeholder={t('Ex. : Remplacement du compresseur')} />
          </div>
          <div className="field"><label htmlFor="q-kind">{t('Type')}</label>
            <select id="q-kind" value={draft.kind} disabled={!editable} onChange={(e) => set({ kind: e.target.value as QuoteKind })}>
              {QUOTE_KINDS.map((k) => <option key={k} value={k}>{tl(QUOTE_KIND_LABELS, k)}</option>)}
            </select>
          </div>
          {draft.kind === 'CONTRACT' && (
            <div className="field"><label htmlFor="q-freq">{t('Visites')}</label>
              <select id="q-freq" value={draft.contractFrequencyMonths} disabled={!editable} onChange={(e) => set({ contractFrequencyMonths: Number(e.target.value) })}>
                {CONTRACT_FREQUENCIES.map((f) => <option key={f.months} value={f.months}>{t(f.label)}</option>)}
              </select>
            </div>
          )}
          <div className="field"><label htmlFor="q-valid">{t("Valable jusqu'au")}</label>
            <input id="q-valid" type="date" value={draft.validUntil} disabled={!editable} onChange={(e) => set({ validUntil: e.target.value })} />
          </div>
        </div>
        <div className="field"><label htmlFor="q-intro">{t('Présentation (facultatif)')}</label>
          <textarea id="q-intro" rows={2} value={draft.intro} disabled={!editable} onChange={(e) => set({ intro: e.target.value })} />
        </div>
      </section>

      <section className="card stack">
        <h2>{t('Lignes')}</h2>
        <LinesEditor lines={draft.lines} onChange={(lines) => set({ lines })} editable={editable} rates={rates} currency={currency} locale={company?.locale} articles={catalog} />
      </section>

      <section className="card stack">
        <div className="field"><label htmlFor="q-notes">{t('Conditions (paiement, délais, garanties…)')}</label>
          <textarea id="q-notes" rows={3} value={draft.notes} disabled={!editable} onChange={(e) => set({ notes: e.target.value })} />
        </div>
      </section>

      <div className="row" style={{ gap: 8 }}>
        {editable && <button type="button" disabled={busy} onClick={() => void save()}>{isNew ? t('Créer le devis') : t('Enregistrer')}</button>}
        {quote && <button type="button" className="secondary" onClick={() => openPdf(`/quotes/${quote.id}/pdf`).catch((e) => setError(e.message))}>{t('Voir le PDF')}</button>}
        {quote && has('quote.write') && <QuoteActions quote={quote} busy={busy} run={run} onChange={reload} />}
      </div>

      {quote && (quote.sentAt || quote.interventions.length > 0 || quote.contracts.length > 0) && (
        <section className="card stack small">
          {quote.decidedByPortalUserId && quote.decidedAt && (
            <div><strong>{t(quote.status === 'ACCEPTED' ? 'Accepté en ligne par {name} le {date}' : 'Refusé en ligne par {name} le {date}', { name: quote.decisionName ?? '', date: fmtDateTime(quote.decidedAt, company?.timezone) })}</strong>
              {quote.decisionNote && <div>{t('Commentaire du client : {note}', { note: quote.decisionNote })}</div>}</div>
          )}
          {quote.sentAt && <div>{t('Envoyé le {date}', { date: fmtDateTime(quote.sentAt, company?.timezone) })}{quote.sentTo ? ' ' + t('à {to}', { to: quote.sentTo }) : ''}</div>}
          {quote.interventions.map((i) => <div key={i.id}>{t('Intervention créée :')} <Link to={`/interventions/${i.id}`}>{i.number}</Link></div>)}
          {quote.contracts.map((c) => <div key={c.id}>{t('Contrat créé :')} <Link to={`/contracts/${c.id}`}>{c.number}</Link></div>)}
        </section>
      )}
    </div>
  );
}

function fromQuote(q: QuoteDetail): Draft {
  return {
    clientId: q.clientId,
    siteId: q.siteId ?? '',
    kind: q.kind,
    title: q.title,
    intro: q.intro ?? '',
    notes: q.notes ?? '',
    validUntil: q.validUntil ?? '',
    contractFrequencyMonths: q.contractFrequencyMonths ?? 12,
    lines: toELines(q.lines),
  };
}

/** Choix du client, avec recherche */
export function ClientPicker({ companyId, value, onChange }: { companyId?: string; value: string; onChange: (id: string) => void }) {
  const { agency } = useAuth();
  const [q, setQ] = useState('');
  const [list, setList] = useState<Client[]>([]);
  useEffect(() => {
    if (!companyId) return;
    const timer = setTimeout(() => {
      void api<Client[]>(`/clients${qs({ companyId, agencyId: agency?.id, q, limit: 30 })}`).then(setList).catch(() => setList([]));
    }, 200);
    return () => clearTimeout(timer);
  }, [companyId, agency?.id, q]);
  return (
    <div className="field grow">
      <label htmlFor="q-client">{t('Client')}</label>
      <div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
        <input aria-label={t('Rechercher un client')} placeholder={t('Rechercher…')} value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 160 }} />
        <select id="q-client" className="grow" value={value} onChange={(e) => onChange(e.target.value)}>
          <option value="">{t('— Choisir —')}</option>
          {list.map((c) => <option key={c.id} value={c.id}>{c.name}{c.city ? ` · ${c.city}` : ''}</option>)}
        </select>
      </div>
    </div>
  );
}

/** Envoi, acceptation, refus, et suites d'un devis accepté */
function QuoteActions({ quote, busy, run, onChange }: {
  quote: QuoteDetail;
  busy: boolean;
  run: (fn: () => Promise<void>, ok?: string) => Promise<void>;
  onChange: (q: QuoteDetail) => void;
}) {
  const navigate = useNavigate();
  const { me, has } = useAuth();
  const company = me?.org.find((c) => c.id === quote.companyId);
  const [contractStart, setContractStart] = useState(toDateInput(new Date()));
  const [agencyId, setAgencyId] = useState(quote.agencyId ?? '');
  const [to, setTo] = useState(quote.sentTo ?? quote.client.email ?? '');
  const status = async (s: string, ok: string) => run(async () => onChange(await api<QuoteDetail>(`/quotes/${quote.id}/status`, { method: 'POST', body: { status: s } })), ok);
  const send = () => run(async () => {
    const list = to.split(/[;,\s]+/).filter(Boolean);
    if (!list.length) throw new Error(t("Indiquez l'adresse e-mail du client"));
    onChange(await api<QuoteDetail>(`/quotes/${quote.id}/send`, { method: 'POST', body: { to: list } }));
  }, t('Devis envoyé au client.'));
  const needsAgency = !quote.agencyId;
  const agencyPicker = needsAgency && (
    <select aria-label={t('Agence')} value={agencyId} onChange={(e) => setAgencyId(e.target.value)}>
      <option value="">{t('Agence…')}</option>
      {company?.agencies.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
    </select>
  );

  return (
    <>
      {(quote.status === 'DRAFT' || quote.status === 'SENT') && (
        <span className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
          <input type="email" multiple aria-label={t('Adresse e-mail du client')} placeholder={t('e-mail du client')} value={to}
            onChange={(e) => setTo(e.target.value)} style={{ width: 240 }} />
          <button type="button" className="accent" disabled={busy || !to.trim()} onClick={() => void send()}>{quote.status === 'SENT' ? t('Renvoyer') : t('Envoyer au client')}</button>
        </span>
      )}
      {quote.status === 'SENT' && (
        <>
          <button type="button" disabled={busy} onClick={() => void status('ACCEPTED', t('Devis accepté.'))}>{t('Accepté')}</button>
          <button type="button" className="secondary" disabled={busy} onClick={() => void status('REFUSED', t('Devis refusé.'))}>{t('Refusé')}</button>
          <button type="button" className="ghost" disabled={busy} onClick={() => void status('DRAFT', t('Devis repassé en brouillon : vous pouvez le modifier.'))}>{t('Modifier')}</button>
        </>
      )}
      {(quote.status === 'REFUSED' || quote.status === 'CANCELLED') && (
        <button type="button" className="secondary" disabled={busy} onClick={() => void status('DRAFT', t('Devis rouvert.'))}>{t('Rouvrir')}</button>
      )}
      {quote.status === 'DRAFT' && (
        <button type="button" className="ghost" disabled={busy} onClick={() => window.confirm(t('Annuler ce devis ?')) && void status('CANCELLED', t('Devis annulé.'))}>{t('Annuler le devis')}</button>
      )}
      {quote.status === 'ACCEPTED' && quote.kind === 'WORK' && !quote.interventions.length && (
        <>
          {agencyPicker}
          <button type="button" className="accent" disabled={busy || (needsAgency && !agencyId) || !quote.siteId} onClick={() => void run(async () => {
            const iv = await api<{ id: string }>(`/quotes/${quote.id}/intervention`, { method: 'POST', body: { kind: 'INSTALLATION', ...(agencyId ? { agencyId } : {}) } });
            navigate(`/interventions/${iv.id}`);
          })}>{t("Créer l'intervention à planifier")}</button>
        </>
      )}
      {quote.status === 'ACCEPTED' && quote.kind === 'CONTRACT' && !quote.contracts.length && (
        <>
          {agencyPicker}
          <label className="small" htmlFor="c-start">{t('Début du contrat')}</label>
          <input id="c-start" type="date" value={contractStart} onChange={(e) => setContractStart(e.target.value)} style={{ width: 160 }} />
          <button type="button" className="accent" disabled={busy || (needsAgency && !agencyId) || !quote.siteId} onClick={() => void run(async () => {
            const c = await api<{ id: string }>(`/quotes/${quote.id}/contract`, { method: 'POST', body: { startDate: contractStart, ...(agencyId ? { agencyId } : {}) } });
            navigate(`/contracts/${c.id}`);
          })}>{t("Créer le contrat d'entretien")}</button>
        </>
      )}
      {quote.status === 'ACCEPTED' && !quote.siteId && <span className="small muted">{t("Indiquez un lieu d'intervention pour continuer.")}</span>}
      {quote.status === 'ACCEPTED' && has('invoice.write') && (
        <button type="button" className="secondary" disabled={busy} onClick={() => void run(async () => {
          const inv = await api<{ id: string }>(`/invoices/from-quote/${quote.id}`, { method: 'POST' });
          navigate(`/invoices/${inv.id}`);
        })}>{t('Facturer le devis')}</button>
      )}
    </>
  );
}
