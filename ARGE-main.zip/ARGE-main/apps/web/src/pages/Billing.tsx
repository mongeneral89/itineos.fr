/**
 * Abonnements et prélèvements : facturer en une fois les contrats facturés en lot (télésurveillance, maintenance),
 * puis préparer le fichier de prélèvement SEPA à déposer à la banque, noter l'encaissement, et relancer les impayés.
 */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { formatMoney } from '@itineo/shared';
import { api, downloadFile, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { fmtDay, toDateInput } from '../format';
import { t, tp, tServer } from '../i18n';

interface SubscriptionPlan {
  clients: { clientId: string; clientName: string; directDebit: boolean; totalCents: number; lines: { contractId: string; number: string; title: string; start: string; end: string; amountCents: number }[] }[];
  totalCents: number;
  missingPrice: string[];
}
interface DebitPreview {
  ready: boolean;
  earliestDate: string;
  invoices: { id: string; number: string; issueDate: string; dueDate: string | null; clientName: string; remainingCents: number; mandate: string; sequence: 'FRST' | 'RCUR' }[];
}
interface ReminderList {
  enabled: boolean;
  days: number[];
  totalCents: number;
  invoices: {
    id: string; number: string; clientId: string; clientName: string; dueDate: string; daysLate: number; remainingCents: number;
    level: number; paused: boolean; inCollection: boolean; hasEmail: boolean; next: { level: 1 | 2 | 3; on: string } | null;
    reminders: { id: string; level: number; sentTo: string; sentAt: string; sentBy: string | null; sentByLast: string | null }[];
  }[];
}
interface Batch { id: string; messageId: string; collectionDate: string; status: 'SENT' | 'COLLECTED'; count: number; totalCents: number; createdAt: string }
interface BatchDetail extends Batch { invoices: { id: string; number: string; grossCents: number; clientName: string; sequence: string | null }[] }

/** Dernier jour du mois en cours : on facture d'habitude les abonnements du mois */
function endOfMonth(): string {
  const d = new Date();
  return toDateInput(new Date(d.getFullYear(), d.getMonth() + 1, 0));
}

export function BillingPage() {
  const { company } = useAuth();
  if (!company) return null;
  return (
    <div className="stack">
      <div className="topbar">
        <div>
          <div className="eyebrow">{company.name}</div>
          <h1>{t('Abonnements, prélèvements et relances')}</h1>
        </div>
        <OrgPicker />
      </div>
      <Subscriptions key={`s-${company.id}`} companyId={company.id} currency={company.currency} />
      <DirectDebits key={`d-${company.id}`} companyId={company.id} currency={company.currency} />
      <Reminders key={`r-${company.id}`} companyId={company.id} currency={company.currency} />
    </div>
  );
}

function Subscriptions({ companyId, currency }: { companyId: string; currency: string }) {
  const [until, setUntil] = useState(endOfMonth());
  const [issue, setIssue] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { data, reload } = useLoad(() => api<SubscriptionPlan>(`/billing/subscriptions${qs({ companyId, until })}`), [companyId, until]);
  const money = (c: number) => formatMoney(c, currency);

  const run = async () => {
    if (!data?.clients.length) return;
    if (!window.confirm(tp(data.clients.length, 'Créer {n} facture ?', 'Créer {n} factures ?'))) return;
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      const r = await api<{ created: number; issued: number; skipped: number; errors: string[] }>('/billing/subscriptions', { method: 'POST', body: { companyId, until, issue } });
      setMsg([
        tp(r.created, '{n} facture créée.', '{n} factures créées.'),
        issue ? tp(r.issued, '{n} émise (numéro et PDF).', '{n} émises (numéro et PDF).') : t('Elles sont en brouillon dans Factures.'),
        r.skipped ? tp(r.skipped, '{n} client ignoré (contrat facturé entre-temps).', '{n} clients ignorés (contrats facturés entre-temps).') : '',
      ].filter(Boolean).join(' '));
      if (r.errors.length) setError(r.errors.map(tServer).join(' · '));
      await reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card stack">
      <h2>{t('Facturer les abonnements')}</h2>
      <p className="small muted" style={{ margin: 0 }}>
        {t('Les contrats réglés en « Facturation automatique » sont facturés à terme à échoir : une facture par client, une ligne par contrat et par période. Une période n’est jamais facturée deux fois.')}
      </p>
      <div className="row" style={{ alignItems: 'flex-end' }}>
        <div className="field"><label htmlFor="sub-until">{t('Périodes qui commencent au plus tard le')}</label>
          <input id="sub-until" type="date" value={until} onChange={(e) => setUntil(e.target.value)} />
        </div>
        <label className="check"><input type="checkbox" checked={issue} onChange={(e) => setIssue(e.target.checked)} />{t('Émettre directement (numéro et PDF)')}</label>
      </div>
      {data && data.missingPrice.length > 0 && (
        <p className="small error">{t('Sans prix annuel, ces contrats ne peuvent pas être facturés : {list}', { list: data.missingPrice.join(', ') })}</p>
      )}
      {data && (data.clients.length ? (
        <>
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Client')}</th><th>{t('Contrats et périodes')}</th><th>{t('Règlement')}</th><th style={{ textAlign: 'right' }}>{t('Total HT')}</th></tr></thead>
              <tbody>
                {data.clients.map((c) => (
                  <tr key={c.clientId}>
                    <td><Link to={`/clients/${c.clientId}`}>{c.clientName}</Link></td>
                    <td className="small">
                      {c.lines.map((l, i) => (
                        <div key={i}><Link to={`/contracts/${l.contractId}`}>{l.number}</Link> · {l.title} · {fmtDay(l.start)} → {fmtDay(l.end)} · {money(l.amountCents)}</div>
                      ))}
                    </td>
                    <td className="small">{c.directDebit ? <span className="badge ok">{t('Prélèvement')}</span> : t('Virement ou autre')}</td>
                    <td style={{ textAlign: 'right' }}><strong>{money(c.totalCents)}</strong></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span>{t('Total à facturer : {amount} HT', { amount: money(data.totalCents) })}</span>
            <button type="button" className="accent" disabled={busy} onClick={() => void run()}>
              {busy ? t('Création…') : tp(data.clients.length, 'Créer {n} facture', 'Créer {n} factures')}
            </button>
          </div>
        </>
      ) : <p className="muted">{t('Rien à facturer jusqu’à cette date.')}</p>)}
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error">{error}</p>}
    </section>
  );
}

function DirectDebits({ companyId, currency }: { companyId: string; currency: string }) {
  const { data: preview, reload: reloadPreview } = useLoad(() => api<DebitPreview>(`/billing/direct-debits/preview${qs({ companyId })}`), [companyId]);
  const { data: batches, reload: reloadBatches } = useLoad(() => api<Batch[]>(`/billing/direct-debits${qs({ companyId })}`), [companyId]);
  const [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [date, setDate] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [open, setOpen] = useState<BatchDetail | null>(null);
  const [rejected, setRejected] = useState<Set<string>>(new Set());
  const money = (c: number) => formatMoney(c, currency);
  const chosen = (preview?.invoices ?? []).filter((i) => !excluded.has(i.id));
  const collectionDate = date || preview?.earliestDate || '';

  const create = async () => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      const r = await api<{ id: string; messageId: string; count: number; totalCents: number }>('/billing/direct-debits', {
        method: 'POST', body: { companyId, collectionDate, invoiceIds: chosen.map((i) => i.id) },
      });
      await downloadFile(`/billing/direct-debits/${r.id}/file`, `${r.messageId}.xml`);
      setMsg(t('Lot {ref} créé : {n} prélèvements, {amount}. Déposez le fichier sur le site de votre banque.', { ref: r.messageId, n: r.count, amount: money(r.totalCents) }));
      setExcluded(new Set());
      await Promise.all([reloadPreview(), reloadBatches()]);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const openBatch = async (b: Batch) => {
    setRejected(new Set());
    setOpen(open?.id === b.id ? null : await api<BatchDetail>(`/billing/direct-debits/${b.id}`));
  };
  const collected = async () => {
    if (!open) return;
    setError(null);
    try {
      const r = await api<{ payments: number; rejected: number }>(`/billing/direct-debits/${open.id}/collected`, { method: 'POST', body: { rejectedInvoiceIds: [...rejected] } });
      setMsg([
        tp(r.payments, '{n} paiement enregistré.', '{n} paiements enregistrés.'),
        r.rejected ? tp(r.rejected, '{n} rejet : la facture pourra être prélevée à nouveau.', '{n} rejets : les factures pourront être prélevées à nouveau.') : '',
      ].filter(Boolean).join(' '));
      setOpen(null);
      await Promise.all([reloadPreview(), reloadBatches()]);
    } catch (e) {
      setError((e as Error).message);
    }
  };

  return (
    <section className="card stack">
      <h2>{t('Prélèvements SEPA')}</h2>
      {preview && !preview.ready && (
        <p className="small error">{t('Indiquez d’abord l’identifiant créancier SEPA (ICS) et l’IBAN de la société dans Organisation → Réglages de facturation.')}</p>
      )}
      <p className="small muted" style={{ margin: 0 }}>
        {t('Factures émises et non payées des clients qui ont un mandat. Le fichier est au format SEPA (pain.008), accepté par toutes les banques.')}
      </p>
      {preview && (preview.invoices.length ? (
        <>
          <div className="table-wrap">
            <table>
              <thead><tr><th /><th>{t('Facture')}</th><th>{t('Client')}</th><th>{t('Échéance')}</th><th>{t('Mandat')}</th><th style={{ textAlign: 'right' }}>{t('À prélever')}</th></tr></thead>
              <tbody>
                {preview.invoices.map((i) => (
                  <tr key={i.id}>
                    <td><input type="checkbox" aria-label={t('Prélever {n}', { n: i.number })} checked={!excluded.has(i.id)}
                      onChange={(e) => setExcluded((s) => { const n = new Set(s); if (e.target.checked) n.delete(i.id); else n.add(i.id); return n; })} /></td>
                    <td><Link to={`/invoices/${i.id}`}>{i.number}</Link></td>
                    <td>{i.clientName}</td>
                    <td className="small">{fmtDay(i.dueDate)}</td>
                    <td className="small">{i.mandate}{i.sequence === 'FRST' && <> · <span className="badge neutral">{t('1er prélèvement')}</span></>}</td>
                    <td style={{ textAlign: 'right' }}>{money(i.remainingCents)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="row" style={{ alignItems: 'flex-end', justifyContent: 'space-between' }}>
            <div className="field"><label htmlFor="dd-date">{t('Date de prélèvement')}</label>
              <input id="dd-date" type="date" min={preview.earliestDate} value={collectionDate} onChange={(e) => setDate(e.target.value)} />
            </div>
            <button type="button" className="accent" disabled={busy || !preview.ready || !chosen.length} onClick={() => void create()}>
              {t('Créer le fichier : {n} prélèvements, {amount}', { n: chosen.length, amount: money(chosen.reduce((s, i) => s + i.remainingCents, 0)) })}
            </button>
          </div>
        </>
      ) : <p className="muted">{t('Aucune facture à prélever.')}</p>)}
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error">{error}</p>}

      {batches && batches.length > 0 && (
        <>
          <h3>{t('Lots remis à la banque')}</h3>
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Lot')}</th><th>{t('Prélevé le')}</th><th>{t('Prélèvements')}</th><th style={{ textAlign: 'right' }}>{t('Montant')}</th><th>{t('Statut')}</th><th /></tr></thead>
              <tbody>
                {batches.map((b) => (
                  <tr key={b.id}>
                    <td>{b.messageId}</td>
                    <td>{fmtDay(b.collectionDate)}</td>
                    <td>{b.count}</td>
                    <td style={{ textAlign: 'right' }}>{money(b.totalCents)}</td>
                    <td>{b.status === 'COLLECTED' ? <span className="badge ok">{t('Encaissé')}</span> : <span className="badge warn">{t('Remis à la banque')}</span>}</td>
                    <td className="row" style={{ gap: 6 }}>
                      <button type="button" className="ghost" onClick={() => void downloadFile(`/billing/direct-debits/${b.id}/file`, `${b.messageId}.xml`)}>{t('Fichier')}</button>
                      {b.status === 'SENT' && <button type="button" className="secondary" onClick={() => void openBatch(b)}>{t('Noter l’encaissement')}</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {open && (
        <div className="stack" style={{ borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
          <strong>{t('Encaissement du lot {ref}', { ref: open.messageId })}</strong>
          <p className="small muted" style={{ margin: 0 }}>{t('Cochez les prélèvements rejetés par la banque. Les autres sont notés payés à la date de prélèvement.')}</p>
          {open.invoices.map((i) => (
            <label key={i.id} className="check">
              <input type="checkbox" checked={rejected.has(i.id)} onChange={(e) => setRejected((s) => { const n = new Set(s); if (e.target.checked) n.add(i.id); else n.delete(i.id); return n; })} />
              {t('{number} · {client} : rejeté', { number: i.number, client: i.clientName })}
            </label>
          ))}
          <div className="row">
            <button type="button" onClick={() => void collected()}>{t('Enregistrer l’encaissement')}</button>
            <button type="button" className="secondary" onClick={() => setOpen(null)}>{t('Annuler')}</button>
          </div>
        </div>
      )}
    </section>
  );
}

/** Nom des niveaux de relance */
function levelLabel(level: number): string {
  return [t('Rappel'), t('Relance'), t('Mise en demeure')][level - 1] ?? '';
}

function Reminders({ companyId, currency }: { companyId: string; currency: string }) {
  const { data, reload } = useLoad(() => api<ReminderList>(`/billing/reminders${qs({ companyId })}`), [companyId]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const money = (c: number) => formatMoney(c, currency);

  const remind = async (i: ReminderList['invoices'][number]) => {
    const level = Math.min(3, i.level + 1);
    if (!window.confirm(t('Envoyer « {level} » pour la facture {number} à {client} ?', { level: levelLabel(level), number: i.number, client: i.clientName }))) return;
    setBusy(i.id);
    setError(null);
    setMsg(null);
    try {
      const r = await api<{ level: number; to: string }>(`/invoices/${i.id}/reminders`, { method: 'POST', body: {} });
      setMsg(t('« {level} » envoyé à {to}.', { level: levelLabel(r.level), to: r.to }));
      await reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(null);
    }
  };
  const pause = async (i: ReminderList['invoices'][number]) => {
    setError(null);
    try {
      await api(`/invoices/${i.id}/dunning`, { method: 'PATCH', body: { paused: !i.paused } });
      await reload();
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const status = (i: ReminderList['invoices'][number]) => {
    if (i.inCollection) return <span className="badge neutral">{t('Prélèvement en cours')}</span>;
    if (i.paused) return <span className="badge neutral">{t('Relances suspendues')}</span>;
    if (!i.hasEmail) return <span className="badge warn">{t('Pas d’adresse e-mail')}</span>;
    if (!i.next) return <span className="badge warn">{t('Mise en demeure envoyée')}</span>;
    return <>{levelLabel(i.next.level)} · {data!.enabled ? fmtDay(i.next.on) : t('à envoyer à la main')}</>;
  };

  return (
    <section className="card stack">
      <h2>{t('Relances des impayés')}</h2>
      <p className="small muted" style={{ margin: 0 }}>
        {data?.enabled
          ? t('Envoi automatique par e-mail, facture jointe : rappel {a} jours après l’échéance, relance à {b} jours, mise en demeure à {c} jours. En semaine, de 8 h à 18 h, au moins 7 jours entre deux relances.', { a: data.days[0], b: data.days[1], c: data.days[2] })
          : t('L’envoi automatique est désactivé : activez-le dans Organisation → Réglages de facturation, ou relancez à la main.')}
      </p>
      {data && (data.invoices.length ? (
        <>
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Facture')}</th><th>{t('Client')}</th><th>{t('Échéance')}</th><th style={{ textAlign: 'right' }}>{t('Reste à payer')}</th><th>{t('Déjà envoyé')}</th><th>{t('Prochaine relance')}</th><th /></tr></thead>
              <tbody>
                {data.invoices.map((i) => (
                  <tr key={i.id}>
                    <td><Link to={`/invoices/${i.id}`}>{i.number}</Link></td>
                    <td><Link to={`/clients/${i.clientId}`}>{i.clientName}</Link></td>
                    <td className="small">{fmtDay(i.dueDate)} · <span className="error">{tp(i.daysLate, '{n} jour de retard', '{n} jours de retard')}</span></td>
                    <td style={{ textAlign: 'right' }}>{money(i.remainingCents)}</td>
                    <td className="small">
                      {i.reminders.length ? i.reminders.map((r) => (
                        <div key={r.id}>{levelLabel(r.level)} · {fmtDay(r.sentAt.slice(0, 10))}{r.sentBy ? '' : ` · ${t('auto')}`}</div>
                      )) : <span className="muted">{t('Aucune')}</span>}
                    </td>
                    <td className="small">{status(i)}</td>
                    <td className="row" style={{ gap: 6 }}>
                      {!i.inCollection && i.hasEmail && (
                        <button type="button" className="secondary" disabled={busy === i.id} onClick={() => void remind(i)}>{t('Relancer maintenant')}</button>
                      )}
                      <button type="button" className="ghost" onClick={() => void pause(i)}>{i.paused ? t('Reprendre') : t('Suspendre')}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <span>{t('Total impayé : {amount}', { amount: money(data.totalCents) })}</span>
          <p className="small muted" style={{ margin: 0 }}>
            {t('Pour une mise en demeure incontestable devant un tribunal, envoyez-la aussi par lettre recommandée avec accusé de réception.')}
          </p>
        </>
      ) : <p className="muted">{t('Aucune facture en retard de paiement.')}</p>)}
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error">{error}</p>}
    </section>
  );
}
