import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { formatMoney, PAYMENT_METHOD_LABELS, PAYMENT_METHODS, vatRatesFor, type PaymentMethod } from '@itineo/shared';
import { api, downloadFile, openPdf } from '../api';
import { useAuth } from '../auth';
import { fmtDateTime, fmtDay, moneyInput, parseMoneyInput, toDateInput } from '../format';
import type { ClientDetail, InvoiceDetail, OperationType } from '../types';
import { LinesEditor, lineProblems, linesPayload, newLine, toELines, useCatalog, type ELine } from '../components/LinesEditor';
import { ClientPicker } from './QuoteEdit';
import { InvoiceStateBadge } from './Invoices';
import { t, tl } from '../i18n';

interface Draft { clientId: string; siteId: string; title: string; notes: string; serviceDate: string; paymentTermsDays: string; operationType: OperationType; lines: ELine[] }

/** Nature de l'opération : mention obligatoire des factures (réforme de la facture électronique) */
const OPERATIONS: { id: OperationType; label: string }[] = [
  { id: 'SERVICES', label: 'Prestation de services' },
  { id: 'GOODS', label: 'Livraison de biens' },
  { id: 'MIXED', label: 'Services et biens' },
];

const fromInvoice = (i: InvoiceDetail): Draft => ({
  clientId: i.clientId, siteId: i.siteId ?? '', title: i.title, notes: i.notes ?? '', serviceDate: i.serviceDate ?? '',
  paymentTermsDays: String(i.paymentTermsDays), operationType: i.operationType ?? 'SERVICES', lines: toELines(i.lines),
});

export function InvoiceEditPage() {
  const { id = 'new' } = useParams();
  const isNew = id === 'new';
  const navigate = useNavigate();
  const { me, company: currentCompany, has } = useAuth();
  const [invoice, setInvoice] = useState<InvoiceDetail | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const company = me?.org.find((c) => c.id === (invoice?.companyId ?? currentCompany?.id)) ?? currentCompany;
  const rates = vatRatesFor(company?.countryCode ?? 'FR');
  const currency = invoice?.currency ?? company?.currency ?? 'EUR';
  const money = (c: number) => formatMoney(c, currency, company?.locale);
  const canWrite = has('invoice.write');
  const editable = canWrite && (isNew || invoice?.status === 'DRAFT');
  const credit = invoice?.kind === 'CREDIT_NOTE';
  const catalog = useCatalog(company?.id, editable);

  const show = (i: InvoiceDetail) => {
    setInvoice(i);
    setDraft(fromInvoice(i));
  };

  useEffect(() => {
    setError(null);
    if (isNew) {
      setInvoice(null);
      setDraft({ clientId: '', siteId: '', title: '', notes: '', serviceDate: toDateInput(new Date()), paymentTermsDays: String(currentCompany?.paymentTermsDays ?? 30), operationType: 'SERVICES', lines: [newLine(rates[0])] });
      return;
    }
    api<InvoiceDetail>(`/invoices/${id}`).then(show).catch((e) => setError((e as Error).message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    if (!draft?.clientId) return setClient(null);
    void api<ClientDetail>(`/clients/${draft.clientId}`).then(setClient).catch(() => undefined);
  }, [draft?.clientId]);

  if (error && !draft) return <p className="error">{error}</p>;
  if (!draft || (!isNew && invoice?.id !== id)) return <p className="muted">{t('Chargement…')}</p>;
  const set = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));

  const run = async (fn: () => Promise<void>, ok?: string) => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      await fn();
      if (ok) setMsg(ok);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const payload = () => {
    const problems = [
      ...(!draft.clientId ? [t('Choisissez le client.')] : []),
      ...(!draft.title.trim() ? [t("Indiquez l'objet de la facture.")] : []),
      ...lineProblems(draft.lines),
    ];
    if (problems.length) throw new Error(problems.join(' '));
    const terms = Number(draft.paymentTermsDays);
    return {
      clientId: draft.clientId, siteId: draft.siteId || null, title: draft.title.trim(), notes: draft.notes.trim() || null,
      serviceDate: draft.serviceDate || null, paymentTermsDays: Number.isInteger(terms) ? terms : undefined, operationType: draft.operationType,
      lines: linesPayload(draft.lines),
    };
  };

  const save = () => run(async () => {
    if (isNew) {
      const created = await api<InvoiceDetail>('/invoices', { method: 'POST', body: payload() });
      navigate(`/invoices/${created.id}`, { replace: true });
    } else {
      show(await api<InvoiceDetail>(`/invoices/${id}`, { method: 'PUT', body: payload() }));
    }
  }, t('Brouillon enregistré.'));

  const issue = () => run(async () => {
    if (!window.confirm(credit
      ? t("Émettre l'avoir ? Il reçoit son numéro définitif et ne pourra plus être modifié.")
      : t('Émettre la facture ? Elle reçoit son numéro définitif et ne pourra plus être modifiée (une erreur se corrige ensuite par un avoir).'))) return;
    await api(`/invoices/${id}`, { method: 'PUT', body: payload() });
    show(await api<InvoiceDetail>(`/invoices/${id}/issue`, { method: 'POST' }));
  }, credit ? t('Avoir émis.') : t('Facture émise : numéro attribué, PDF archivé.'));

  const remove = () => run(async () => {
    if (!window.confirm(t('Supprimer ce brouillon ?'))) return;
    await api(`/invoices/${id}`, { method: 'DELETE' });
    navigate('/invoices');
  });

  const title = isNew ? t('Nouvelle facture') : invoice?.number
    ? t(credit ? 'Avoir {num}' : 'Facture {num}', { num: invoice.number })
    : t(credit ? 'Avoir (brouillon)' : 'Facture (brouillon)');

  return (
    <div className="stack" style={{ maxWidth: 1000 }}>
      <div className="topbar">
        <div>
          <div className="eyebrow"><Link to="/invoices">{t('Factures')}</Link></div>
          <h1>{title}</h1>
        </div>
        {invoice && <InvoiceStateBadge state={invoice.state} credit={credit} />}
      </div>
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error" role="alert">{error}</p>}
      {invoice?.creditedInvoice && (
        <p className="small">{t('Avoir sur la facture')} <Link to={`/invoices/${invoice.creditedInvoice.id}`}>{invoice.creditedInvoice.number}</Link>.</p>
      )}
      {invoice?.status === 'DRAFT' && <p className="small muted">{t('Brouillon : pas encore de numéro. Vérifiez les lignes puis émettez la facture.')}</p>}

      <section className="card stack">
        <div className="row">
          {isNew ? <ClientPicker companyId={currentCompany?.id} value={draft.clientId} onChange={(clientId) => set({ clientId, siteId: '' })} /> : (
            <div className="field grow"><label>{t('Client')}</label><div><Link to={`/clients/${invoice!.clientId}`}><strong>{invoice!.client.name}</strong></Link></div></div>
          )}
          <div className="field grow"><label htmlFor="i-site">{t("Lieu d'intervention")}</label>
            <select id="i-site" value={draft.siteId} disabled={!editable || !client} onChange={(e) => set({ siteId: e.target.value })}>
              <option value="">—</option>
              {client?.sites.map((s) => <option key={s.id} value={s.id}>{s.name}{s.city ? ` · ${s.city}` : ''}</option>)}
            </select>
          </div>
        </div>
        <div className="row">
          <div className="field grow"><label htmlFor="i-title">{t('Objet')}</label>
            <input id="i-title" value={draft.title} disabled={!editable} maxLength={300} onChange={(e) => set({ title: e.target.value })} />
          </div>
          <div className="field"><label htmlFor="i-service">{t('Date de la prestation')}</label>
            <input id="i-service" type="date" value={draft.serviceDate} disabled={!editable} onChange={(e) => set({ serviceDate: e.target.value })} />
          </div>
          <div className="field" style={{ width: 210 }}><label htmlFor="i-op">{t('Nature de l’opération')}</label>
            <select id="i-op" value={draft.operationType} disabled={!editable} onChange={(e) => set({ operationType: e.target.value as OperationType })}>
              {OPERATIONS.map((o) => <option key={o.id} value={o.id}>{t(o.label)}</option>)}
            </select>
          </div>
          {!credit && (
            <div className="field" style={{ width: 150 }}><label htmlFor="i-terms">{t('Paiement à (jours)')}</label>
              <input id="i-terms" inputMode="numeric" value={draft.paymentTermsDays} disabled={!editable} onChange={(e) => set({ paymentTermsDays: e.target.value })} />
            </div>
          )}
        </div>
        {invoice?.issueDate && (
          <div className="small">
            {t('Émise le {date}', { date: fmtDay(invoice.issueDate) })}
            {!credit && invoice.dueDate ? ' · ' + t('échéance le {date}', { date: fmtDay(invoice.dueDate) }) : ''}
            {invoice.sentAt ? ' · ' + t('envoyée le {date} à {to}', { date: fmtDateTime(invoice.sentAt, company?.timezone), to: invoice.sentTo ?? '' }) : ''}
          </div>
        )}
      </section>

      <section className="card stack">
        <h2>{t('Lignes')}</h2>
        <LinesEditor lines={draft.lines} onChange={(lines) => set({ lines })} editable={editable} rates={rates} currency={currency} locale={company?.locale} articles={catalog} />
      </section>

      <section className="card stack">
        <div className="field"><label htmlFor="i-notes">{t('Mention complémentaire (facultatif)')}</label>
          <textarea id="i-notes" rows={2} value={draft.notes} disabled={!editable} onChange={(e) => set({ notes: e.target.value })} />
        </div>
      </section>

      <div className="row" style={{ gap: 8 }}>
        {editable && <button type="button" disabled={busy} onClick={() => void save()}>{isNew ? t('Créer le brouillon') : t('Enregistrer')}</button>}
        {editable && !isNew && <button type="button" className="accent" disabled={busy} onClick={() => void issue()}>{credit ? t("Émettre l'avoir") : t('Émettre la facture')}</button>}
        {editable && !isNew && <button type="button" className="ghost" disabled={busy} onClick={() => void remove()}>{t('Supprimer le brouillon')}</button>}
        {invoice && <button type="button" className="secondary" onClick={() => openPdf(`/invoices/${invoice.id}/pdf`).catch((e) => setError(e.message))}>{invoice.status === 'DRAFT' ? t('Aperçu PDF') : t('Voir le PDF')}</button>}
        {invoice?.status === 'ISSUED' && canWrite && <SendInvoice invoice={invoice} busy={busy} run={run} onChange={show} />}
        {invoice?.status === 'ISSUED' && !credit && canWrite && invoice.remainingCents > 0 && (
          <button type="button" className="ghost" disabled={busy} onClick={() => void run(async () => {
            const res = await api<{ id: string }>(`/invoices/${invoice.id}/credit-note`, { method: 'POST' });
            navigate(`/invoices/${res.id}`);
          })}>{t('Faire un avoir')}</button>
        )}
      </div>

      {invoice && <EInvoice invoice={invoice} canWrite={canWrite} busy={busy} run={run} onChange={show} />}

      {invoice?.status === 'ISSUED' && !credit && (
        <Payments invoice={invoice} money={money} canWrite={canWrite} busy={busy} run={run} reload={async () => show(await api<InvoiceDetail>(`/invoices/${invoice.id}`))} />
      )}
    </div>
  );
}

/**
 * Facture électronique : ce qui manque, puis (facture émise) le dépôt sur la plateforme agréée et son statut.
 * Un particulier reçoit sa facture par e-mail, comme avant : elle ne passe pas par la plateforme.
 */
function EInvoice({ invoice, canWrite, busy, run, onChange }: {
  invoice: InvoiceDetail; canWrite: boolean; busy: boolean; run: (fn: () => Promise<void>, ok?: string) => Promise<void>; onChange: (i: InvoiceDetail) => void;
}) {
  if (!invoice.einvoiceB2B) {
    return <p className="small muted">{t('Client particulier : la facture lui est envoyée par e-mail ; elle ne passe pas par une plateforme de facture électronique.')}</p>;
  }
  const issued = invoice.status === 'ISSUED';
  const deposited = !!invoice.einvoiceFlowId && invoice.einvoiceStatus !== '213';
  return (
    <section className="card stack" style={{ gap: 8 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Facture électronique')}</h2>
        {issued && <span className={`badge ${invoice.einvoiceError ? 'warn' : deposited ? 'ok' : 'neutral'}`}>{invoice.einvoiceStatusLabel ? t(invoice.einvoiceStatusLabel) : t('Pas encore déposée')}</span>}
      </div>
      {invoice.einvoiceWarnings.length > 0 && (
        <ul className="small" style={{ margin: 0, color: 'var(--warn-fg)' }}>
          {invoice.einvoiceWarnings.map((w) => <li key={w}>{t(w)}</li>)}
        </ul>
      )}
      {invoice.einvoiceError && <p className="error small" role="alert">{invoice.einvoiceError}</p>}
      {issued && invoice.einvoiceStatusAt && deposited && <p className="small muted">{t('Statut au {date}', { date: fmtDateTime(invoice.einvoiceStatusAt) })}</p>}
      {issued && !invoice.einvoiceReady && (
        <p className="small muted">{t('Aucune plateforme réglée : déposez vous-même le PDF (au format Factur-X) sur votre plateforme, ou réglez-la dans Organisation → Facture électronique.')}</p>
      )}
      {!issued && <p className="small muted">{t('À l’émission, le PDF devient une facture électronique Factur-X.')}</p>}
      {issued && (
        <div className="row" style={{ gap: 8 }}>
          {canWrite && invoice.einvoiceReady && !deposited && (
            <button type="button" className="accent" disabled={busy} onClick={() => void run(async () => {
              onChange(await api<InvoiceDetail>(`/invoices/${invoice.id}/einvoice`, { method: 'POST' }));
            }, t('Facture déposée sur la plateforme.'))}>{t('Envoyer à la plateforme')}</button>
          )}
          {deposited && (
            <button type="button" className="secondary" disabled={busy} onClick={() => void run(async () => {
              onChange(await api<InvoiceDetail>(`/invoices/${invoice.id}/einvoice/refresh`, { method: 'POST' }));
            })}>{t('Actualiser le statut')}</button>
          )}
          <button type="button" className="ghost" onClick={() => void run(() => downloadFile(`/invoices/${invoice.id}/facturx.xml`, `${invoice.number}-factur-x.xml`))}>{t('Télécharger le XML Factur-X')}</button>
        </div>
      )}
    </section>
  );
}

function SendInvoice({ invoice, busy, run, onChange }: {
  invoice: InvoiceDetail; busy: boolean; run: (fn: () => Promise<void>, ok?: string) => Promise<void>; onChange: (i: InvoiceDetail) => void;
}) {
  const [to, setTo] = useState(invoice.sentTo ?? invoice.client.email ?? '');
  return (
    <span className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
      <input type="email" multiple aria-label={t('Adresse e-mail du client')} placeholder={t('e-mail du client')} value={to} onChange={(e) => setTo(e.target.value)} style={{ width: 240 }} />
      <button type="button" className="accent" disabled={busy || !to.trim()} onClick={() => void run(async () => {
        onChange(await api<InvoiceDetail>(`/invoices/${invoice.id}/send`, { method: 'POST', body: { to: to.split(/[;,\s]+/).filter(Boolean) } }));
      }, t('Envoyée au client.'))}>{invoice.sentAt ? t('Renvoyer') : t('Envoyer au client')}</button>
    </span>
  );
}

function Payments({ invoice, money, canWrite, busy, run, reload }: {
  invoice: InvoiceDetail; money: (c: number) => string; canWrite: boolean; busy: boolean;
  run: (fn: () => Promise<void>, ok?: string) => Promise<void>; reload: () => Promise<void>;
}) {
  const [paidOn, setPaidOn] = useState(toDateInput(new Date()));
  const [amount, setAmount] = useState(moneyInput(invoice.remainingCents));
  const [method, setMethod] = useState<PaymentMethod>('TRANSFER');
  const [reference, setReference] = useState('');
  useEffect(() => setAmount(moneyInput(invoice.remainingCents)), [invoice.remainingCents]);

  const add = () => run(async () => {
    const cents = parseMoneyInput(amount);
    if (!cents || cents <= 0) throw new Error(t('Montant invalide (ex. 250,00)'));
    await api(`/invoices/${invoice.id}/payments`, { method: 'POST', body: { paidOn, amountCents: cents, method, reference: reference.trim() || null } });
    setReference('');
    await reload();
  }, t('Paiement enregistré.'));

  return (
    <section className="card stack">
      <h2>{t('Règlements')}</h2>
      <div className="totals" style={{ marginLeft: 0 }}>
        <div><span>{t('Total TTC')}</span><strong>{money(invoice.grossCents)}</strong></div>
        <div className="small"><span>{t('Payé')}</span><span>{money(invoice.paidCents)}</span></div>
        {invoice.creditedCents > 0 && <div className="small"><span>{t('Avoirs')}</span><span>{money(invoice.creditedCents)}</span></div>}
        <div className="grand"><span>{t('Reste à payer')}</span><strong>{money(invoice.remainingCents)}</strong></div>
      </div>
      {invoice.payments.length > 0 && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('Date')}</th><th>{t('Mode')}</th><th>{t('Référence')}</th><th style={{ textAlign: 'right' }}>{t('Montant')}</th>{canWrite && <th />}</tr></thead>
            <tbody>
              {invoice.payments.map((p) => (
                <tr key={p.id}>
                  <td>{fmtDay(p.paidOn)}</td><td>{tl(PAYMENT_METHOD_LABELS, p.method)}</td><td>{p.reference ?? '—'}</td>
                  <td style={{ textAlign: 'right' }}>{money(p.amountCents)}</td>
                  {canWrite && <td><button type="button" className="ghost" disabled={busy} onClick={() => window.confirm(t('Annuler ce paiement ?')) && void run(async () => {
                    await api(`/invoices/${invoice.id}/payments/${p.id}`, { method: 'DELETE' });
                    await reload();
                  }, t('Paiement annulé.'))}>{t('Annuler')}</button></td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {invoice.creditNotes.length > 0 && (
        <div className="small">{t('Avoirs :')} {invoice.creditNotes.map((c) => <Link key={c.id} to={`/invoices/${c.id}`} style={{ marginRight: 8 }}>{c.number ?? t('brouillon')} ({money(c.grossCents)})</Link>)}</div>
      )}
      {canWrite && invoice.remainingCents > 0 && (
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div className="field"><label htmlFor="p-date">{t('Reçu le')}</label><input id="p-date" type="date" value={paidOn} onChange={(e) => setPaidOn(e.target.value)} /></div>
          <div className="field" style={{ width: 140 }}><label htmlFor="p-amount">{t('Montant')}</label><input id="p-amount" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} /></div>
          <div className="field"><label htmlFor="p-method">{t('Mode')}</label>
            <select id="p-method" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
              {PAYMENT_METHODS.map((m) => <option key={m} value={m}>{tl(PAYMENT_METHOD_LABELS, m)}</option>)}
            </select>
          </div>
          <div className="field grow"><label htmlFor="p-ref">{t('Référence (n° de chèque…)')}</label><input id="p-ref" value={reference} onChange={(e) => setReference(e.target.value)} /></div>
          <button type="button" disabled={busy} onClick={() => void add()}>{t('Enregistrer le paiement')}</button>
        </div>
      )}
    </section>
  );
}
