import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { INTERVENTION_STATUSES, STATUS_LABELS, type InterventionStatus, type PhotoKind } from '@itineo/shared';
import { api, openReportPdf, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { usePhotoUrl } from '../photos';
import type { CertificationType, InterventionDetail, ReportPhoto, UserRow } from '../types';
import { KindBadge, PriorityBadge, StatusBadge } from '../components/Badges';
import { fmtDateTime, fmtDay, fullName } from '../format';
import { t, tl } from '../i18n';
import { SuggestionPanel } from '../components/SuggestionPanel';
import { TemplateSelect } from '../components/TemplateSelect';
import { useSuggestionsEnabled } from '../components/AssignSuggestions';
import { PlanForm, techniciansFor } from '../components/PlanForm';
import { CancelIntervention } from '../components/CancelIntervention';

export function InterventionDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { company, has } = useAuth();
  const { data: iv, error, reload } = useLoad(() => api<InterventionDetail>(`/interventions/${id}`), [id]);
  const [msg, setMsg] = useState<string | null>(null);
  const suggest = useSuggestionsEnabled(iv?.companyId);

  if (error) return <p className="error">{error}</p>;
  if (!iv) return <p className="muted">{t('Chargement…')}</p>;

  const setStatus = async (status: InterventionStatus) => {
    setMsg(null);
    try {
      await api(`/interventions/${iv.id}`, { method: 'PATCH', body: { status } });
      await reload();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };

  return (
    <div className="stack" style={{ maxWidth: 900 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <div className="eyebrow">{iv.number}</div>
          <h1>{iv.clientName}</h1>
        </div>
        <div className="row"><KindBadge kind={iv.kind} /><PriorityBadge priority={iv.priority} /><StatusBadge status={iv.status} /></div>
      </div>

      <section className="card grid">
        <Info label={t('Motif')} value={iv.reason} />
        <Info label={t('Site')} value={`${iv.siteName}${iv.siteCity ? ` · ${iv.siteCity}` : ''}`} />
        <Info label={t('Prévue')} value={`${fmtDateTime(iv.scheduledStart, company?.timezone)} → ${fmtDateTime(iv.scheduledEnd, company?.timezone)}`} />
        <Info label={t('Technicien')} value={iv.technicianId ? fullName(iv.technicianFirstName, iv.technicianLastName) : t('Non affectée')} />
        <Info label={t('Origine')} value={iv.source ? t(iv.source) : '—'} />
        <div><div className="small muted">{t('Client')}</div><Link to={`/clients/${iv.clientId}`}>{t('Voir la fiche client')}</Link></div>
        {iv.dueDate && <Info label={t('Échéance')} value={fmtDay(iv.dueDate)} />}
        {iv.contractId && <div><div className="small muted">{t("Contrat d'entretien")}</div><Link to={`/contracts/${iv.contractId}`}>{t('Voir le contrat')}</Link></div>}
        {iv.quoteId && <div><div className="small muted">{t('Devis')}</div><Link to={`/quotes/${iv.quoteId}`}>{t('Voir le devis')}</Link></div>}
      </section>

      <PlanningActions iv={iv} onChanged={reload} />

      {(iv.requestedByPortalUserId || iv.clientNotes) && (
        <section className="card stack" style={{ gap: 4 }}>
          <strong>{t('Demande faite par le client sur son espace en ligne')}</strong>
          {iv.clientNotes && <div className="small">{t('Disponibilités / précisions : {notes}', { notes: iv.clientNotes })}</div>}
        </section>
      )}

      {has('intervention.write') && <RequiredCertifications iv={iv} onSaved={reload} />}
      {has('intervention.write') && !iv.report && <InterventionDocument iv={iv} onSaved={reload} />}

      {suggest && ['TO_PLAN', 'PLANNED', 'TO_RESUME'].includes(iv.status) && <SuggestionPanel iv={iv} onChanged={reload} />}

      {has('quote.write') && (
        <section className="card row" style={{ justifyContent: 'space-between' }}>
          <div>
            <strong>{iv.report?.outcome === 'QUOTE_NEEDED' ? t('Le technicien a indiqué « Devis à établir »') : t('Proposer des travaux au client')}</strong>
            <div className="small muted">{t('Le client, le lieu et les pièces notées sur la fiche sont repris.')}</div>
          </div>
          <Link className={`btn${iv.report?.outcome === 'QUOTE_NEEDED' ? ' accent' : ' secondary'}`} to={`/quotes/new?interventionId=${iv.id}`}>{t('Créer un devis')}</Link>
        </section>
      )}

      <section className="card stack">
        <h2>{t("Fiche d'intervention")}</h2>
        {!iv.report && <p className="muted">{t("La fiche n'a pas encore été commencée.")}</p>}
        {iv.report && (
          <p>
            {t('Statut :')} <strong>{iv.report.status === 'DRAFT' ? t('en cours de saisie') : iv.report.status === 'SIGNED' ? t('signée') : t('envoyée')}</strong>
            {iv.report.sentAt && <> {t('le {date}', { date: fmtDateTime(iv.report.sentAt, company?.timezone) })}</>}
          </p>
        )}
        {iv.report && iv.report.photos.length > 0 && (
          <div className="stack" style={{ gap: 8 }}>
            <h3>{t('Photos ({n})', { n: iv.report.photos.length })}</h3>
            <div className="photo-grid">
              {iv.report.photos.map((ph) => <OfficePhoto key={ph.id} interventionId={iv.id} photo={ph} />)}
            </div>
          </div>
        )}
        <div className="row">
          <Link className="btn" to={`/tech/${iv.id}`}>{t('Ouvrir la fiche')}</Link>
          {iv.report && iv.report.status !== 'DRAFT' && (
            <button type="button" className="secondary" onClick={() => openReportPdf(iv.id).catch((e) => setMsg(e.message))}>{t('Voir le PDF')}</button>
          )}
          {iv.report && iv.report.status !== 'DRAFT' && has('invoice.write') && (
            <button type="button" className="accent" onClick={() => api<{ id: string }>(`/invoices/from-intervention/${iv.id}`, { method: 'POST' })
              .then((r) => navigate(`/invoices/${r.id}`)).catch((e) => setMsg(e.message))}>{t('Facturer')}</button>
          )}
        </div>
      </section>

      {has('intervention.write') && (
        <section className="card stack">
          <h2>{t('Changer le statut')}</h2>
          <div className="chips">
            {/* Annuler : bouton « Annuler l'intervention » (motif demandé) ; une intervention annulée se rouvre ici */}
            {INTERVENTION_STATUSES.filter((s) => s !== 'CANCELLED' || iv.status === 'CANCELLED').map((s) => (
              <button key={s} type="button" className={`chip${iv.status === s ? ' on' : ''}`} onClick={() => setStatus(s)}>{tl(STATUS_LABELS, s)}</button>
            ))}
          </div>
        </section>
      )}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

/** Document à remplir : modifiable tant que la fiche n'est pas commencée */
function InterventionDocument({ iv, onSaved }: { iv: InterventionDetail; onSaved: () => Promise<void> }) {
  const [msg, setMsg] = useState<string | null>(null);
  const change = async (templateId: string) => {
    setMsg(null);
    try {
      await api(`/interventions/${iv.id}`, { method: 'PATCH', body: { templateId: templateId || null } });
      await onSaved();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  return (
    <section className="card stack" style={{ gap: 6 }}>
      <div className="field">
        <label htmlFor="iv-tpl">{t('Document à remplir')}</label>
        <TemplateSelect id="iv-tpl" companyId={iv.companyId} value={iv.templateId ?? ''} onChange={(v) => void change(v)} />
      </div>
      <span className="small muted">{t('Par exemple « Consignes de télésurveillance ». Modifiable tant que la fiche n’est pas commencée.')}</span>
      {msg && <p className="error small">{msg}</p>}
    </section>
  );
}

/** Habilitations que le technicien doit avoir pour cette intervention */
function RequiredCertifications({ iv, onSaved }: { iv: InterventionDetail; onSaved: () => Promise<void> }) {
  const { data: types } = useLoad(() => api<CertificationType[]>('/certification-types'), []);
  const [msg, setMsg] = useState<string | null>(null);
  const selected = new Set(iv.requiredCertificationIds ?? []);
  const toggle = async (id: string) => {
    const next = selected.has(id) ? [...selected].filter((x) => x !== id) : [...selected, id];
    setMsg(null);
    try {
      const res = await api<{ missingCertifications: { name: string }[] }>(`/interventions/${iv.id}`, { method: 'PATCH', body: { requiredCertificationIds: next } });
      if (res.missingCertifications?.length) setMsg(t("⚠ Le technicien prévu n'a pas : {list}.", { list: res.missingCertifications.map((m) => m.name).join(', ') }));
      await onSaved();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  if (!types?.length) return null;
  return (
    <section className="card stack">
      <h2>{t('Habilitations exigées')}</h2>
      <div className="chips">
        {types.filter((ct) => ct.active).map((ct) => (
          <button key={ct.id} type="button" role="checkbox" aria-checked={selected.has(ct.id)} className={`chip${selected.has(ct.id) ? ' on' : ''}`} title={ct.name} onClick={() => void toggle(ct.id)}>{ct.code}</button>
        ))}
      </div>
      {msg && <p className="small" role="alert">{msg}</p>}
    </section>
  );
}

const PHOTO_LABELS: Record<PhotoKind, string> = { BEFORE: 'Avant', AFTER: 'Après', OTHER: 'Autre' }; // traduits à l'affichage

/** Photo de la fiche : un clic l'ouvre en grand dans un nouvel onglet */
function OfficePhoto({ interventionId, photo }: { interventionId: string; photo: ReportPhoto }) {
  const url = usePhotoUrl(interventionId, photo);
  const label = tl(PHOTO_LABELS, photo.kind);
  return (
    <figure className="photo-tile">
      {url
        ? <a href={url} target="_blank" rel="noreferrer" title={t('Ouvrir en grand')}><img src={url} alt={photo.caption ? `${label} : ${photo.caption}` : label} /></a>
        : <div className="photo-placeholder" />}
      <figcaption className="small">
        <span className="badge neutral">{label}</span>
        {photo.caption && <> {photo.caption}</>}
      </figcaption>
    </figure>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="small muted">{label}</div>
      <div>{value}</div>
    </div>
  );
}

/**
 * Planification d'une intervention déjà créée : replanifier (technicien, jour, heure, durée), remettre à planifier,
 * ou annuler avec un motif. Le technicien concerné est prévenu sur son téléphone.
 */
function PlanningActions({ iv, onChanged }: { iv: InterventionDetail; onChanged: () => Promise<void> | void }) {
  const { has } = useAuth();
  const [mode, setMode] = useState<'replan' | 'cancel' | null>(null);
  const [techs, setTechs] = useState<UserRow[] | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const closed = ['DONE', 'TO_RESUME', 'CANCELLED'].includes(iv.status);
  const signed = !!iv.report && iv.report.status !== 'DRAFT';
  const canPlan = has('intervention.assign') && !closed && !signed;
  const canCancel = has('intervention.write') && !closed && !signed;

  if (iv.status === 'CANCELLED') {
    return (
      <section className="card stack" style={{ gap: 4, borderInlineStart: '4px solid var(--danger)' }}>
        <strong>{t('Intervention annulée')}{iv.cancelledAt ? ` · ${fmtDateTime(iv.cancelledAt)}` : ''}</strong>
        {iv.cancelReason && <div className="small">{t('Motif : {reason}', { reason: iv.cancelReason })}</div>}
      </section>
    );
  }
  if (!canPlan && !canCancel) return null;

  const openReplan = async () => {
    setMsg(null);
    setMode('replan');
    if (!techs) {
      const users = await api<UserRow[]>(`/users${qs({ companyId: iv.companyId, role: 'TECHNICIAN' })}`).catch(() => [] as UserRow[]);
      setTechs(techniciansFor(users, iv.agencyId));
    }
  };
  const unplan = async () => {
    setMsg(null);
    try {
      await api(`/interventions/${iv.id}`, { method: 'PATCH', body: { technicianId: null, scheduledStart: null, scheduledEnd: null } });
      await onChanged();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };

  return (
    <section className="card stack">
      <h2>{t('Planification')}</h2>
      {mode === null && (
        <div className="row">
          {canPlan && <button type="button" className="secondary" onClick={() => void openReplan()}>{iv.scheduledStart ? t('Replanifier') : t('Planifier')}</button>}
          {canPlan && iv.scheduledStart && <button type="button" className="secondary" onClick={() => void unplan()}>{t('Remettre à planifier')}</button>}
          {canCancel && <button type="button" className="danger-outline" onClick={() => setMode('cancel')}>{t('Annuler l’intervention')}</button>}
        </div>
      )}
      {mode === 'replan' && (techs ? (
        <PlanForm iv={iv} techs={techs} defaultStart={new Date(new Date().setHours(9, 0, 0, 0))}
          onCancel={() => setMode(null)}
          onSaved={async (res) => {
            setMode(null);
            setMsg(res.missingCertifications?.length ? t("⚠ Le technicien prévu n'a pas : {list}.", { list: res.missingCertifications.map((m) => m.name).join(', ') }) : null);
            await onChanged();
          }} />
      ) : <p className="muted small">{t('Chargement…')}</p>)}
      {mode === 'cancel' && <CancelIntervention id={iv.id} onCancel={() => setMode(null)} onDone={async () => { setMode(null); await onChanged(); }} />}
      {msg && <p className="small" role="alert">{msg}</p>}
    </section>
  );
}
