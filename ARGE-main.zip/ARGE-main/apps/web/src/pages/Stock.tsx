import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  formatMoney, formatVatRate, SLIP_STATUS_LABELS, STOCK_LOCATION_KIND_LABELS, STOCK_MOVEMENT_LABELS, vatRatesFor,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { fmtDateTime, moneyInput, parseMoneyInput } from '../format';
import type { Article, SlipRow, StockLevel, StockLocation, StockMovement, UserRow } from '../types';
import { t, tl, uiLocale } from '../i18n';

type Tab = 'levels' | 'alerts' | 'slips' | 'catalog';
// Libellés en français, traduits à l'affichage
const TABS: { id: Tab; label: string }[] = [
  { id: 'levels', label: 'Stocks' },
  { id: 'alerts', label: 'Alertes' },
  { id: 'slips', label: 'Bons de sortie' },
  { id: 'catalog', label: 'Catalogue' },
];
const fmtQty = (n: number) => new Intl.NumberFormat(uiLocale(), { maximumFractionDigits: 3 }).format(n);

export function StockPage() {
  const { company, agency } = useAuth();
  const [tab, setTab] = useState<Tab>(() => {
    try {
      return (sessionStorage.getItem('itineo.stockTab') as Tab | null) ?? 'levels';
    } catch {
      return 'levels';
    }
  });
  useEffect(() => {
    try {
      sessionStorage.setItem('itineo.stockTab', tab);
    } catch {
      /* ignore */
    }
  }, [tab]);

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{company?.name}{agency ? ` · ${agency.name}` : ''}</div>
          <h1>{t('Stock')}</h1>
        </div>
        <OrgPicker />
      </div>
      <div className="chips" role="tablist" aria-label={t('Rubriques du stock')}>
        {TABS.map((x) => (
          <button key={x.id} type="button" role="tab" aria-selected={tab === x.id} className={`chip${tab === x.id ? ' on' : ''}`} onClick={() => setTab(x.id)}>{t(x.label)}</button>
        ))}
      </div>
      {company && tab === 'levels' && <LevelsTab />}
      {company && tab === 'alerts' && <AlertsTab />}
      {company && tab === 'slips' && <SlipsTab />}
      {company && tab === 'catalog' && <CatalogTab />}
    </>
  );
}

// ─── Stocks par lieu ───

function LevelsTab() {
  const { company, agency, has } = useAuth();
  const canWrite = has('stock.write');
  const { data: locations, reload: reloadLocations } = useLoad(
    () => api<StockLocation[]>(`/stock/locations${qs({ companyId: company!.id, agencyId: agency?.id })}`),
    [company?.id, agency?.id],
  );
  const [locationId, setLocationId] = useState('');
  const [adding, setAdding] = useState(false);
  useEffect(() => {
    if (locations?.length && !locations.some((l) => l.id === locationId)) setLocationId(locations[0].id);
  }, [locations, locationId]);
  const { data: levels, reload } = useLoad(
    () => (locationId ? api<StockLevel[]>(`/stock/levels${qs({ locationId })}`) : Promise.resolve([])),
    [locationId],
  );
  const { data: moves, reload: reloadMoves } = useLoad(
    () => (locationId ? api<StockMovement[]>(`/stock/movements${qs({ locationId, limit: 30 })}`) : Promise.resolve([])),
    [locationId],
  );
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const refresh = async () => {
    await Promise.all([reload(), reloadMoves()]);
  };

  const setMin = async (l: StockLevel, value: string) => {
    const n = Number(value.replace(',', '.'));
    if (!Number.isFinite(n) || n < 0 || n === l.minQuantity) return;
    await api('/stock/levels', { method: 'PATCH', body: { locationId, articleId: l.articleId, minQuantity: n } }).catch((e) => setError(e.message));
    await reload();
  };
  const count = async (l: StockLevel, value: string) => {
    const n = Number(value.replace(',', '.'));
    if (!Number.isFinite(n) || n < 0) return setError(t('Quantité comptée invalide'));
    setError(null);
    try {
      const res = await api<{ delta: number }>('/stock/adjustments', { method: 'POST', body: { locationId, articleId: l.articleId, countedQuantity: n } });
      setMsg(res.delta
        ? t('Inventaire enregistré : écart de {delta} {unit} sur {ref}.', { delta: (res.delta > 0 ? '+' : '') + fmtQty(res.delta), unit: l.unit, ref: l.reference })
        : t('Stock conforme, rien à corriger.'));
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    }
  };

  const current = locations?.find((l) => l.id === locationId);
  return (
    <div className="stack">
      <div className="row">
        <div className="field"><label htmlFor="st-loc">{t('Lieu de stock')}</label>
          <select id="st-loc" value={locationId} onChange={(e) => setLocationId(e.target.value)}>
            {locations?.map((l) => <option key={l.id} value={l.id}>{tl(STOCK_LOCATION_KIND_LABELS, l.kind)} · {l.name}</option>)}
          </select>
        </div>
        <div className="grow" />
        {canWrite && !adding && <button type="button" className="secondary" onClick={() => setAdding(true)}>{t('Nouveau dépôt ou véhicule')}</button>}
      </div>
      {adding && <LocationForm onDone={async (created) => { setAdding(false); await reloadLocations(); if (created) setLocationId(created); }} />}
      {locations && !locations.length && <p className="muted">{t('Aucun lieu de stock : créez un dépôt, puis les véhicules des techniciens.')}</p>}
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error" role="alert">{error}</p>}

      {current && (
        <section className="card stack">
          <h2>{current.name}</h2>
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Réf.')}</th><th>{t('Article')}</th><th style={{ textAlign: 'right' }}>{t('En stock')}</th><th>{t("Seuil d'alerte")}</th>{canWrite && <th>{t('Inventaire : quantité comptée')}</th>}</tr></thead>
              <tbody>
                {(levels ?? []).map((l) => (
                  <tr key={l.articleId}>
                    <td>{l.reference}</td>
                    <td>{l.name}</td>
                    <td style={{ textAlign: 'right' }}>
                      <strong style={{ color: l.quantity < 0 ? 'var(--danger)' : undefined }}>{fmtQty(l.quantity)}</strong> {l.unit}{' '}
                      {l.low && <span className="badge warn">{t('bas')}</span>}
                    </td>
                    <td>
                      {canWrite
                        ? <input aria-label={t("Seuil d'alerte {ref}", { ref: l.reference })} defaultValue={fmtQty(l.minQuantity)} inputMode="decimal" style={{ width: 80 }} onBlur={(e) => void setMin(l, e.target.value)} />
                        : fmtQty(l.minQuantity)}
                    </td>
                    {canWrite && <td><CountInput level={l} onCount={(v) => void count(l, v)} /></td>}
                  </tr>
                ))}
                {levels && !levels.length && <tr><td colSpan={5} className="muted">{t('Ce lieu est vide.')}</td></tr>}
              </tbody>
            </table>
          </div>
          {canWrite && <ReceiptForm locationId={current.id} onDone={async (text) => { setMsg(text); await refresh(); }} />}
        </section>
      )}

      {current && (
        <section className="card stack">
          <h2>{t('Derniers mouvements')}</h2>
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Date')}</th><th>{t('Type')}</th><th>{t('Article')}</th><th style={{ textAlign: 'right' }}>{t('Quantité')}</th><th>{t('Origine')}</th></tr></thead>
              <tbody>
                {(moves ?? []).map((m) => {
                  const incoming = m.toLocationId === current.id;
                  return (
                    <tr key={m.id}>
                      <td className="small">{fmtDateTime(m.createdAt, company?.timezone)}</td>
                      <td>{tl(STOCK_MOVEMENT_LABELS, m.kind)}</td>
                      <td>{m.reference} – {m.name}</td>
                      <td style={{ textAlign: 'right', color: incoming ? 'var(--ok-fg)' : 'var(--danger)' }}>{incoming ? '+' : '−'}{fmtQty(m.quantity)} {m.unit}</td>
                      <td className="small">
                        {m.slipId && <Link to={`/stock/slips/${m.slipId}`}>{m.slipNumber ?? t('Bon')}</Link>}
                        {m.interventionId && <Link to={`/interventions/${m.interventionId}`}>{m.interventionNumber}</Link>}
                        {!m.slipId && !m.interventionId && (m.note ?? '—')}
                      </td>
                    </tr>
                  );
                })}
                {moves && !moves.length && <tr><td colSpan={5} className="muted">{t('Aucun mouvement.')}</td></tr>}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

function CountInput({ level, onCount }: { level: StockLevel; onCount: (value: string) => void }) {
  const [v, setV] = useState('');
  return (
    <span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
      <input aria-label={t('Quantité comptée {ref}', { ref: level.reference })} inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} style={{ width: 80 }} />
      <button type="button" className="ghost" disabled={!v.trim()} onClick={() => { onCount(v); setV(''); }}>{t('Corriger')}</button>
    </span>
  );
}

function ReceiptForm({ locationId, onDone }: { locationId: string; onDone: (msg: string) => void }) {
  const { company } = useAuth();
  const { data: articles } = useLoad(() => api<Article[]>(`/articles${qs({ companyId: company!.id })}`), [company?.id]);
  const [articleId, setArticleId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    const q = Number(quantity.replace(',', '.'));
    if (!articleId || !(q > 0)) return setError(t('Choisissez un article et une quantité'));
    try {
      await api('/stock/receipts', { method: 'POST', body: { locationId, lines: [{ articleId, quantity: q }], note: note.trim() || null } });
      const art = articles?.find((x) => x.id === articleId);
      setQuantity('');
      onDone(t('Réception enregistrée : +{qty} {unit} {ref}.', { qty: fmtQty(q), unit: art?.unit ?? '', ref: art?.reference ?? '' }));
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="row" style={{ alignItems: 'flex-end', borderTop: '1px solid var(--rule)', paddingTop: 10 }} onSubmit={submit}>
      <strong style={{ width: '100%' }}>{t('Réception de marchandise')}</strong>
      <div className="field grow"><label htmlFor="r-art">{t('Article')}</label>
        <select id="r-art" value={articleId} onChange={(e) => setArticleId(e.target.value)}>
          <option value="">{t('— Choisir —')}</option>
          {articles?.map((x) => <option key={x.id} value={x.id}>{x.reference} – {x.name}</option>)}
        </select>
      </div>
      <div className="field" style={{ width: 110 }}><label htmlFor="r-q">{t('Quantité')}</label><input id="r-q" inputMode="decimal" value={quantity} onChange={(e) => setQuantity(e.target.value)} /></div>
      <div className="field grow"><label htmlFor="r-note">{t('Bon de livraison / fournisseur')}</label><input id="r-note" value={note} onChange={(e) => setNote(e.target.value)} /></div>
      <button type="submit">{t('Ajouter au stock')}</button>
      {error && <p className="error" style={{ width: '100%' }}>{error}</p>}
    </form>
  );
}

function LocationForm({ onDone }: { onDone: (createdId: string | null) => void }) {
  const { company, agency } = useAuth();
  const [kind, setKind] = useState<'DEPOT' | 'VEHICLE'>('DEPOT');
  const [name, setName] = useState('');
  const [agencyId, setAgencyId] = useState(agency?.id ?? '');
  const [technicianId, setTechnicianId] = useState('');
  const [techs, setTechs] = useState<UserRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (kind !== 'VEHICLE' || !agencyId || !company) return;
    void api<UserRow[]>(`/users${qs({ companyId: company.id, agencyId, role: 'TECHNICIAN' })}`).then(setTechs).catch(() => setTechs([]));
  }, [kind, agencyId, company]);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const tech = techs.find((x) => x.id === technicianId);
      const created = await api<{ id: string }>('/stock/locations', {
        method: 'POST',
        body: { companyId: company!.id, agencyId: agencyId || null, kind, name: name.trim() || (tech ? t('Véhicule de {name}', { name: `${tech.firstName} ${tech.lastName}` }) : ''), technicianId: kind === 'VEHICLE' ? technicianId : null },
      });
      onDone(created.id);
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{t('Nouveau lieu de stock')}</h2>
      <div className="row">
        <div className="field"><label htmlFor="l-kind">{t('Type')}</label>
          <select id="l-kind" value={kind} onChange={(e) => setKind(e.target.value as 'DEPOT' | 'VEHICLE')}>
            <option value="DEPOT">{t('Dépôt')}</option><option value="VEHICLE">{t("Véhicule d'un technicien")}</option>
          </select>
        </div>
        <div className="field"><label htmlFor="l-agency">{t('Agence')}</label>
          <select id="l-agency" value={agencyId} onChange={(e) => setAgencyId(e.target.value)}>
            {kind === 'DEPOT' && <option value="">{t('Toute la société (dépôt central)')}</option>}
            {company?.agencies.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
        </div>
        {kind === 'VEHICLE' && (
          <div className="field"><label htmlFor="l-tech">{t('Technicien')}</label>
            <select id="l-tech" value={technicianId} onChange={(e) => setTechnicianId(e.target.value)}>
              <option value="">{t('— Choisir —')}</option>
              {techs.map((x) => <option key={x.id} value={x.id}>{x.firstName} {x.lastName}</option>)}
            </select>
          </div>
        )}
        <div className="field grow"><label htmlFor="l-name">{t('Nom')} {kind === 'VEHICLE' ? t('(facultatif)') : ''}</label><input id="l-name" value={name} onChange={(e) => setName(e.target.value)} placeholder={kind === 'DEPOT' ? t('Ex. : Dépôt Lille') : t('Ex. : Kangoo AB-123-CD')} /></div>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Créer')}</button><button type="button" className="secondary" onClick={() => onDone(null)}>{t('Annuler')}</button></div>
    </form>
  );
}

// ─── Alertes de stock bas ───

function AlertsTab() {
  const { company } = useAuth();
  const { data } = useLoad(() => api<StockLevel[]>(`/stock/levels${qs({ companyId: company!.id, low: true })}`), [company?.id]);
  return (
    <section className="card stack">
      <h2>{t('Stock bas')}</h2>
      <p className="small muted" style={{ margin: 0 }}>{t("Articles dont la quantité a atteint le seuil d'alerte fixé pour le lieu : à commander ou à réapprovisionner.")}</p>
      <div className="table-wrap">
        <table>
          <thead><tr><th>{t('Lieu')}</th><th>{t('Réf.')}</th><th>{t('Article')}</th><th style={{ textAlign: 'right' }}>{t('En stock')}</th><th style={{ textAlign: 'right' }}>{t('Seuil')}</th></tr></thead>
          <tbody>
            {(data ?? []).map((l) => (
              <tr key={`${l.locationId}-${l.articleId}`}>
                <td>{l.locationName}</td><td>{l.reference}</td><td>{l.name}</td>
                <td style={{ textAlign: 'right' }}><strong>{fmtQty(l.quantity)}</strong> {l.unit}</td>
                <td style={{ textAlign: 'right' }}>{fmtQty(l.minQuantity)}</td>
              </tr>
            ))}
            {data && !data.length && <tr><td colSpan={5} className="muted">{t('Aucune alerte : tout est au-dessus des seuils.')}</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// ─── Bons de sortie ───

function SlipsTab() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const { data } = useLoad(() => api<SlipRow[]>(`/stock/slips${qs({ companyId: company!.id, agencyId: agency?.id })}`), [company?.id, agency?.id]);
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{t('Bons de sortie')}</h2>
        {has('stock.write') && <button type="button" className="accent" onClick={() => navigate('/stock/slips/new')}>{t('Nouveau bon de sortie')}</button>}
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>{t('N°')}</th><th>{t('Depuis')}</th><th>{t('Articles')}</th><th>{t('Créé le')}</th><th>{t('Statut')}</th></tr></thead>
          <tbody>
            {(data ?? []).map((s) => (
              <tr key={s.id} className="clickable" onClick={() => navigate(`/stock/slips/${s.id}`)}>
                <td><Link to={`/stock/slips/${s.id}`} onClick={(e) => e.stopPropagation()}><strong>{s.number ?? t('Brouillon')}</strong></Link></td>
                <td>{s.fromName}</td>
                <td>{s.lineCount}</td>
                <td className="small">{fmtDateTime(s.createdAt, company?.timezone)}</td>
                <td><span className={`badge ${s.status === 'VALIDATED' ? 'ok' : 'neutral'}`}>{tl(SLIP_STATUS_LABELS, s.status)}</span></td>
              </tr>
            ))}
            {data && !data.length && <tr><td colSpan={5} className="muted">{t('Aucun bon de sortie.')}</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// ─── Catalogue ───

interface ArticleForm { reference: string; name: string; category: string; unit: string; purchase: string; sale: string; vatRateBp: number }
const emptyArticle = (vat: number): ArticleForm => ({ reference: '', name: '', category: '', unit: 'u', purchase: '', sale: '', vatRateBp: vat });

function CatalogTab() {
  const { company, has } = useAuth();
  const canWrite = has('stock.write');
  const rates = vatRatesFor(company?.countryCode ?? 'FR');
  const [q, setQ] = useState('');
  const { data, reload } = useLoad(() => api<Article[]>(`/articles${qs({ companyId: company!.id, q, all: true })}`), [company?.id, q]);
  const [editing, setEditing] = useState<{ id: string | null; form: ArticleForm } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const money = (c: number | null) => (c == null ? '—' : formatMoney(c, company!.currency, company!.locale));

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    setError(null);
    const f = editing.form;
    const price = (s: string) => {
      if (!s.trim()) return null;
      const c = parseMoneyInput(s);
      if (c === null) throw new Error(t('Prix invalide : {value}', { value: s }));
      return c;
    };
    try {
      const body = { reference: f.reference.trim(), name: f.name.trim(), category: f.category.trim() || null, unit: f.unit.trim() || 'u', purchasePriceCents: price(f.purchase), salePriceCents: price(f.sale), vatRateBp: f.vatRateBp };
      if (editing.id) await api(`/articles/${editing.id}`, { method: 'PATCH', body });
      else await api('/articles', { method: 'POST', body: { ...body, companyId: company!.id } });
      setEditing(null);
      await reload();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const toggle = async (x: Article) => {
    await api(`/articles/${x.id}`, { method: 'PATCH', body: { active: !x.active } }).catch((e) => setError(e.message));
    await reload();
  };
  const set = (patch: Partial<ArticleForm>) => setEditing((ed) => (ed ? { ...ed, form: { ...ed.form, ...patch } } : ed));

  return (
    <div className="stack">
      <div className="row">
        <input style={{ maxWidth: 320 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Rechercher : référence, nom, famille')} aria-label={t('Rechercher un article')} />
        <div className="grow" />
        {canWrite && !editing && <button type="button" className="accent" onClick={() => setEditing({ id: null, form: emptyArticle(rates[0]) })}>{t('Nouvel article')}</button>}
      </div>
      {editing && (
        <form className="card stack" onSubmit={save}>
          <h2>{editing.id ? t("Modifier l'article") : t('Nouvel article')}</h2>
          <div className="row">
            <div className="field" style={{ width: 160 }}><label htmlFor="a-ref">{t('Référence')}</label><input id="a-ref" value={editing.form.reference} onChange={(e) => set({ reference: e.target.value })} required /></div>
            <div className="field grow"><label htmlFor="a-name">{t('Désignation')}</label><input id="a-name" value={editing.form.name} onChange={(e) => set({ name: e.target.value })} required /></div>
            <div className="field"><label htmlFor="a-cat">{t('Famille')}</label><input id="a-cat" value={editing.form.category} onChange={(e) => set({ category: e.target.value })} /></div>
          </div>
          <div className="row">
            <div className="field" style={{ width: 90 }}><label htmlFor="a-unit">{t('Unité')}</label><input id="a-unit" value={editing.form.unit} onChange={(e) => set({ unit: e.target.value })} /></div>
            <div className="field" style={{ width: 140 }}><label htmlFor="a-buy">{t("Prix d'achat HT")}</label><input id="a-buy" inputMode="decimal" value={editing.form.purchase} onChange={(e) => set({ purchase: e.target.value })} /></div>
            <div className="field" style={{ width: 140 }}><label htmlFor="a-sell">{t('Prix de vente HT')}</label><input id="a-sell" inputMode="decimal" value={editing.form.sale} onChange={(e) => set({ sale: e.target.value })} /></div>
            <div className="field"><label htmlFor="a-vat">{t('TVA')}</label>
              <select id="a-vat" value={editing.form.vatRateBp} onChange={(e) => set({ vatRateBp: Number(e.target.value) })}>
                {rates.map((r) => <option key={r} value={r}>{formatVatRate(r)}</option>)}
              </select>
            </div>
          </div>
          {error && <p className="error">{error}</p>}
          <div className="row"><button type="submit">{t('Enregistrer')}</button><button type="button" className="secondary" onClick={() => setEditing(null)}>{t('Annuler')}</button></div>
        </form>
      )}
      <section className="card">
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('Réf.')}</th><th>{t('Désignation')}</th><th>{t('Famille')}</th><th>{t('Unité')}</th><th style={{ textAlign: 'right' }}>{t('Achat HT')}</th><th style={{ textAlign: 'right' }}>{t('Vente HT')}</th><th>{t('TVA')}</th>{canWrite && <th />}</tr></thead>
            <tbody>
              {(data ?? []).map((x) => (
                <tr key={x.id} style={{ opacity: x.active ? 1 : 0.5 }}>
                  <td><strong>{x.reference}</strong></td><td>{x.name}{!x.active && ` (${t('retiré')})`}</td><td>{x.category ?? '—'}</td><td>{x.unit}</td>
                  <td style={{ textAlign: 'right' }}>{money(x.purchasePriceCents)}</td><td style={{ textAlign: 'right' }}>{money(x.salePriceCents)}</td>
                  <td>{formatVatRate(x.vatRateBp)}</td>
                  {canWrite && (
                    <td className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
                      <button type="button" className="ghost" onClick={() => setEditing({ id: x.id, form: {
                        reference: x.reference, name: x.name, category: x.category ?? '', unit: x.unit, vatRateBp: x.vatRateBp,
                        purchase: x.purchasePriceCents != null ? moneyInput(x.purchasePriceCents) : '', sale: x.salePriceCents != null ? moneyInput(x.salePriceCents) : '',
                      } })}>{t('Modifier')}</button>
                      <button type="button" className="ghost" onClick={() => void toggle(x)}>{x.active ? t('Retirer') : t('Rétablir')}</button>
                    </td>
                  )}
                </tr>
              ))}
              {data && !data.length && <tr><td colSpan={8} className="muted">{t('Aucun article.')}</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
