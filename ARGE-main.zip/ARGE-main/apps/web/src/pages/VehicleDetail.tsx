import { useEffect, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  formatMoney, OWNERSHIP_LABELS, OWNERSHIPS, VEHICLE_DEADLINE_KINDS, VEHICLE_DEADLINE_LABELS, VEHICLE_EVENT_KINDS,
  VEHICLE_EVENT_LABELS, VEHICLE_STATUS_LABELS, VEHICLE_STATUSES, VEHICLE_TYPE_LABELS, VEHICLE_TYPES,
  type VehicleDeadlineKind, type VehicleEventKind,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { DueBadge } from '../components/DueBadge';
import { fmtDay, moneyInput, parseMoneyInput, toDateInput } from '../format';
import type { StockLocation, VehicleDeadline, VehicleDetail } from '../types';
import { t, tl } from '../i18n';
import { km } from './Fleet';
import { VehicleTrack } from './VehicleTrack';

const toInt = (s: string) => (s.trim() ? Number(s.replace(/\s/g, '')) : null);
/** L'événement qui solde naturellement une échéance */
const EVENT_FOR: Record<VehicleDeadlineKind, VehicleEventKind> = {
  SERVICE: 'SERVICE', TECH_INSPECTION: 'TECH_INSPECTION', INSURANCE: 'OTHER', TIRES: 'TIRES', LEASE_END: 'OTHER', OTHER: 'OTHER',
};

export function VehicleDetailPage() {
  const { id = '' } = useParams();
  const { has, company } = useAuth();
  const canWrite = has('fleet.write');
  const [v, setV] = useState<VehicleDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [eventFor, setEventFor] = useState<VehicleDeadline | null | 'free'>(null);
  const load = () => api<VehicleDetail>(`/fleet/vehicles/${id}`).then(setV).catch((e) => setError((e as Error).message));
  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  if (!v) return error ? <p className="error">{error}</p> : <p className="muted">{t('Chargement…')}</p>;
  const money = (c: number) => formatMoney(c, company?.currency ?? 'EUR', company?.locale);
  const done = async (text: string) => {
    setMsg(text);
    setError(null);
    await load();
  };

  return (
    <div className="stack" style={{ maxWidth: 1000 }}>
      <div className="topbar">
        <div>
          <div className="eyebrow"><Link to="/fleet">{t('Parc véhicules')}</Link></div>
          <h1>{v.plate} <span className="muted" style={{ fontWeight: 400 }}>{[v.make, v.model].filter(Boolean).join(' ')}</span></h1>
        </div>
        <span className="row" style={{ gap: 6 }}>
          <span className={`badge ${v.status === 'ACTIVE' ? 'ok' : 'warn'}`}>{tl(VEHICLE_STATUS_LABELS, v.status)}</span>
          <span className="badge neutral">{km(v.mileage)}</span>
          <span className="badge neutral">{t('Dépenses {year} : {amount}', { year: v.today.slice(0, 4), amount: money(v.costThisYear) })}</span>
        </span>
      </div>
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error" role="alert">{error}</p>}

      <MileageCard v={v} onDone={done} onError={setError} />

      <VehicleTrack vehicleId={v.id} timezone={company?.timezone} lastPositionAt={v.lastPositionAt ?? null} />

      <section className="card stack">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h2>{t('Échéances')}</h2>
          {canWrite && <button type="button" className="secondary" onClick={() => setEventFor('free')}>{t('Noter un entretien / une réparation')}</button>}
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('Échéance')}</th><th>{t('Pour le')}</th><th>{t('Puis tous les')}</th><th>{t('État')}</th><th>{t('Rendez-vous')}</th>{canWrite && <th />}</tr></thead>
            <tbody>
              {v.deadlines.filter((d) => d.active).map((d) => (
                <DeadlineRow key={d.id} d={d} canWrite={canWrite} onDone={done} onError={setError} onCompleted={() => setEventFor(d)} />
              ))}
              {!v.deadlines.some((d) => d.active) && <tr><td colSpan={6} className="muted">{t("Aucune échéance suivie : ajoutez l'entretien, le contrôle technique, l'assurance…")}</td></tr>}
            </tbody>
          </table>
        </div>
        {canWrite && <DeadlineForm vehicleId={v.id} onDone={done} />}
      </section>

      {eventFor && <EventForm v={v} deadline={eventFor === 'free' ? null : eventFor} onClose={() => setEventFor(null)} onDone={async (text) => { setEventFor(null); await done(text); }} />}

      <section className="card stack">
        <h2>{t("Carnet d'entretien")}</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th>{t('Date')}</th><th>{t('Type')}</th><th style={{ textAlign: 'right' }}>{t('Kilométrage')}</th><th>{t('Garage')}</th><th>{t('Détail')}</th><th style={{ textAlign: 'right' }}>{t('Coût')}</th>{canWrite && <th />}</tr></thead>
            <tbody>
              {v.events.map((e) => (
                <tr key={e.id}>
                  <td>{fmtDay(e.occurredOn)}</td><td>{tl(VEHICLE_EVENT_LABELS, e.kind)}</td><td style={{ textAlign: 'right' }}>{km(e.mileage)}</td>
                  <td>{e.provider ?? '—'}</td><td className="small">{e.description ?? ''}</td>
                  <td style={{ textAlign: 'right' }}>{e.costCents != null ? money(e.costCents) : '—'}</td>
                  {canWrite && <td><button type="button" className="ghost" aria-label={t('Supprimer')} onClick={() => window.confirm(t('Supprimer cette ligne du carnet ?')) &&
                    void api(`/fleet/events/${e.id}`, { method: 'DELETE' }).then(() => done(t('Ligne supprimée.'))).catch((err) => setError(err.message))}>✕</button></td>}
                </tr>
              ))}
              {!v.events.length && <tr><td colSpan={7} className="muted">{t('Carnet vide.')}</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <InfoForm v={v} canWrite={canWrite} onDone={done} onError={setError} />
    </div>
  );
}

function MileageCard({ v, onDone, onError }: { v: VehicleDetail; onDone: (t: string) => Promise<void>; onError: (e: string) => void }) {
  const [value, setValue] = useState('');
  return (
    <section className="card row" style={{ alignItems: 'flex-end' }}>
      <div className="grow">
        <div className="small muted">{t('Kilométrage')}</div>
        <strong>{km(v.mileage)}</strong> {v.mileageUpdatedOn && <span className="small muted">{t('relevé le {date}', { date: fmtDay(v.mileageUpdatedOn) })}</span>}
      </div>
      <div className="field" style={{ width: 160 }}><label htmlFor="km-new">{t('Nouveau relevé')}</label><input id="km-new" inputMode="numeric" value={value} onChange={(e) => setValue(e.target.value)} /></div>
      <button type="button" disabled={!value.trim()} onClick={() => {
        const n = toInt(value);
        if (n == null || !(n >= 0)) return onError(t('Kilométrage invalide'));
        void api(`/fleet/vehicles/${v.id}/mileage`, { method: 'POST', body: { mileage: n } })
          .then(() => { setValue(''); return onDone(t('Kilométrage mis à jour.')); }).catch((e) => onError(e.message));
      }}>{t('Enregistrer')}</button>
    </section>
  );
}

function DeadlineRow({ d, canWrite, onDone, onError, onCompleted }: {
  d: VehicleDeadline; canWrite: boolean; onDone: (t: string) => Promise<void>; onError: (e: string) => void; onCompleted: () => void;
}) {
  const [booking, setBooking] = useState(false);
  const [date, setDate] = useState(d.appointmentOn ?? '');
  const [garage, setGarage] = useState(d.appointmentWith ?? '');
  const every = [d.intervalMonths ? t('{n} mois', { n: d.intervalMonths }) : null, d.intervalKm ? km(d.intervalKm) : null].filter(Boolean).join(' / ');
  return (
    <tr>
      <td>{d.label || tl(VEHICLE_DEADLINE_LABELS, d.kind)}</td>
      <td className="small">{[d.dueDate ? fmtDay(d.dueDate) : null, d.dueMileage != null ? km(d.dueMileage) : null].filter(Boolean).join(` ${t('ou')} `)}</td>
      <td className="small">{every || t('une seule fois')}</td>
      <td><DueBadge state={d.state} /></td>
      <td className="small">
        {booking ? (
          <span className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
            <input type="date" aria-label={t('Date du rendez-vous')} value={date} onChange={(e) => setDate(e.target.value)} />
            <input aria-label={t('Garage')} placeholder={t('Garage')} value={garage} onChange={(e) => setGarage(e.target.value)} style={{ width: 130 }} />
            <button type="button" onClick={() => void api(`/fleet/deadlines/${d.id}`, { method: 'PATCH', body: { appointmentOn: date || null, appointmentWith: garage.trim() || null } })
              .then(() => { setBooking(false); return onDone(t('Rendez-vous enregistré.')); }).catch((e) => onError(e.message))}>OK</button>
          </span>
        ) : d.appointmentOn ? `${t('Le {date}', { date: fmtDay(d.appointmentOn) })}${d.appointmentWith ? ` · ${d.appointmentWith}` : ''}` : <span className="muted">—</span>}
      </td>
      {canWrite && (
        <td className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>
          {!booking && <button type="button" className="ghost" onClick={() => setBooking(true)}>{d.appointmentOn ? t('Modifier le RDV') : t('Prendre RDV')}</button>}
          <button type="button" className="ghost" onClick={onCompleted}>{t('Fait')}</button>
          <button type="button" className="ghost" aria-label={t("Supprimer l'échéance")} onClick={() => window.confirm(t('Ne plus suivre cette échéance ?')) &&
            void api(`/fleet/deadlines/${d.id}`, { method: 'DELETE' }).then(() => onDone(t('Échéance supprimée.'))).catch((e) => onError(e.message))}>✕</button>
        </td>
      )}
    </tr>
  );
}

function DeadlineForm({ vehicleId, onDone }: { vehicleId: string; onDone: (t: string) => Promise<void> }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ kind: 'SERVICE' as VehicleDeadlineKind, label: '', dueDate: '', dueMileage: '', intervalMonths: '', intervalKm: '' });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  if (!open) return <div><button type="button" className="secondary" onClick={() => setOpen(true)}>{t('+ Ajouter une échéance')}</button></div>;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api(`/fleet/vehicles/${vehicleId}/deadlines`, {
        method: 'POST',
        body: { kind: f.kind, label: f.label.trim() || null, dueDate: f.dueDate || null, dueMileage: toInt(f.dueMileage), intervalMonths: toInt(f.intervalMonths), intervalKm: toInt(f.intervalKm) },
      });
      setOpen(false);
      setF({ kind: 'SERVICE', label: '', dueDate: '', dueMileage: '', intervalMonths: '', intervalKm: '' });
      await onDone(t('Échéance ajoutée.'));
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="stack" onSubmit={submit} style={{ borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <div className="row">
        <div className="field"><label htmlFor="d-kind">{t('Type')}</label><select id="d-kind" value={f.kind} onChange={set('kind')}>{VEHICLE_DEADLINE_KINDS.map((x) => <option key={x} value={x}>{tl(VEHICLE_DEADLINE_LABELS, x)}</option>)}</select></div>
        <div className="field grow"><label htmlFor="d-label">{t('Précision (facultatif)')}</label><input id="d-label" value={f.label} onChange={set('label')} placeholder={t('Ex. : Pneus hiver')} /></div>
      </div>
      <div className="row">
        <div className="field"><label htmlFor="d-date">{t('Prochaine échéance le')}</label><input id="d-date" type="date" value={f.dueDate} onChange={set('dueDate')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor="d-km">{t('ou à (km)')}</label><input id="d-km" inputMode="numeric" value={f.dueMileage} onChange={set('dueMileage')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor="d-im">{t('Puis tous les (mois)')}</label><input id="d-im" inputMode="numeric" value={f.intervalMonths} onChange={set('intervalMonths')} /></div>
        <div className="field" style={{ width: 150 }}><label htmlFor="d-ik">{t('et/ou tous les (km)')}</label><input id="d-ik" inputMode="numeric" value={f.intervalKm} onChange={set('intervalKm')} /></div>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Ajouter')}</button><button type="button" className="secondary" onClick={() => setOpen(false)}>{t('Annuler')}</button></div>
    </form>
  );
}

function EventForm({ v, deadline, onClose, onDone }: { v: VehicleDetail; deadline: VehicleDeadline | null; onClose: () => void; onDone: (t: string) => Promise<void> }) {
  const [f, setF] = useState({
    kind: (deadline ? EVENT_FOR[deadline.kind] : 'SERVICE') as VehicleEventKind, occurredOn: toDateInput(new Date()),
    mileage: v.mileage != null ? String(v.mileage) : '', cost: '', provider: deadline?.appointmentWith ?? '', description: '',
  });
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const cost = f.cost.trim() ? parseMoneyInput(f.cost) : null;
      if (f.cost.trim() && cost === null) throw new Error(t('Coût invalide (ex. 320,00)'));
      await api(`/fleet/vehicles/${v.id}/events`, {
        method: 'POST',
        body: { kind: f.kind, occurredOn: f.occurredOn, mileage: toInt(f.mileage), costCents: cost, provider: f.provider.trim() || null, description: f.description.trim() || null, deadlineId: deadline?.id ?? null },
      });
      await onDone(deadline ? t('Enregistré : la prochaine échéance a été recalculée.') : t('Ajouté au carnet.'));
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{deadline ? t('{what} : fait', { what: deadline.label || tl(VEHICLE_DEADLINE_LABELS, deadline.kind) }) : t("Noter dans le carnet d'entretien")}</h2>
      <div className="row">
        <div className="field"><label htmlFor="e-kind">{t('Type')}</label><select id="e-kind" value={f.kind} onChange={set('kind')}>{VEHICLE_EVENT_KINDS.filter((x) => x !== 'MILEAGE').map((x) => <option key={x} value={x}>{tl(VEHICLE_EVENT_LABELS, x)}</option>)}</select></div>
        <div className="field"><label htmlFor="e-date">{t('Date')}</label><input id="e-date" type="date" value={f.occurredOn} onChange={set('occurredOn')} required /></div>
        <div className="field" style={{ width: 140 }}><label htmlFor="e-km">{t('Kilométrage')}</label><input id="e-km" inputMode="numeric" value={f.mileage} onChange={set('mileage')} /></div>
        <div className="field" style={{ width: 130 }}><label htmlFor="e-cost">{t('Coût TTC')}</label><input id="e-cost" inputMode="decimal" value={f.cost} onChange={set('cost')} placeholder={moneyInput(0)} /></div>
        <div className="field grow"><label htmlFor="e-garage">{t('Garage')}</label><input id="e-garage" value={f.provider} onChange={set('provider')} /></div>
      </div>
      <div className="field"><label htmlFor="e-desc">{t('Détail')}</label><input id="e-desc" value={f.description} onChange={set('description')} placeholder={t('Vidange, filtres, plaquettes…')} /></div>
      {error && <p className="error">{error}</p>}
      <div className="row"><button type="submit">{t('Enregistrer')}</button><button type="button" className="secondary" onClick={onClose}>{t('Annuler')}</button></div>
    </form>
  );
}

function InfoForm({ v, canWrite, onDone, onError }: { v: VehicleDetail; canWrite: boolean; onDone: (t: string) => Promise<void>; onError: (e: string) => void }) {
  const { company } = useAuth();
  const [f, setF] = useState({
    plate: v.plate, type: v.type, make: v.make ?? '', model: v.model ?? '', vin: v.vin ?? '', fuel: v.fuel ?? '', firstRegistration: v.firstRegistration ?? '',
    ownership: v.ownership, lessor: v.lessor ?? '', status: v.status, driverId: v.driverId ?? '', stockLocationId: v.stockLocationId ?? '', agencyId: v.agencyId ?? '', notes: v.notes ?? '',
  });
  const [drivers, setDrivers] = useState<{ id: string; firstName: string; lastName: string }[]>([]);
  const [locations, setLocations] = useState<StockLocation[]>([]);
  useEffect(() => {
    if (!company || !f.agencyId) return setDrivers([]);
    void api<{ id: string; firstName: string; lastName: string }[]>(`/fleet/drivers${qs({ companyId: company.id, agencyId: f.agencyId })}`).then(setDrivers).catch(() => setDrivers([]));
  }, [company, f.agencyId]);
  useEffect(() => {
    if (!company) return;
    void api<StockLocation[]>(`/stock/locations${qs({ companyId: company.id })}`).then((l) => setLocations(l.filter((x) => x.kind === 'VEHICLE'))).catch(() => setLocations([]));
  }, [company]);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api(`/fleet/vehicles/${v.id}`, {
        method: 'PATCH',
        body: {
          plate: f.plate, type: f.type, make: f.make || null, model: f.model || null, vin: f.vin || null, fuel: f.fuel || null,
          firstRegistration: f.firstRegistration || null, ownership: f.ownership, lessor: f.lessor || null, status: f.status,
          driverId: f.driverId || null, stockLocationId: f.stockLocationId || null, agencyId: f.agencyId || null, notes: f.notes || null,
        },
      });
      await onDone(t('Fiche du véhicule enregistrée.'));
    } catch (err) {
      onError((err as Error).message);
    }
  };
  return (
    <form className="card stack" onSubmit={submit}>
      <h2>{t('Informations')}</h2>
      <fieldset disabled={!canWrite} className="stack" style={{ border: 'none', padding: 0, margin: 0 }}>
        <div className="row">
          <div className="field" style={{ width: 150 }}><label htmlFor="i-plate">{t('Immatriculation')}</label><input id="i-plate" value={f.plate} onChange={set('plate')} /></div>
          <div className="field"><label htmlFor="i-type">{t('Type')}</label><select id="i-type" value={f.type} onChange={set('type')}>{VEHICLE_TYPES.map((x) => <option key={x} value={x}>{tl(VEHICLE_TYPE_LABELS, x)}</option>)}</select></div>
          <div className="field grow"><label htmlFor="i-make">{t('Marque')}</label><input id="i-make" value={f.make} onChange={set('make')} /></div>
          <div className="field grow"><label htmlFor="i-model">{t('Modèle|matériel')}</label><input id="i-model" value={f.model} onChange={set('model')} /></div>
        </div>
        <div className="row">
          <div className="field"><label htmlFor="i-first">{t('1re immatriculation')}</label><input id="i-first" type="date" value={f.firstRegistration} onChange={set('firstRegistration')} /></div>
          <div className="field grow"><label htmlFor="i-vin">{t('N° de série (VIN)')}</label><input id="i-vin" value={f.vin} onChange={set('vin')} /></div>
          <div className="field" style={{ width: 120 }}><label htmlFor="i-fuel">{t('Énergie')}</label><input id="i-fuel" value={f.fuel} onChange={set('fuel')} /></div>
          <div className="field"><label htmlFor="i-status">{t('État')}</label><select id="i-status" value={f.status} onChange={set('status')}>{VEHICLE_STATUSES.map((x) => <option key={x} value={x}>{tl(VEHICLE_STATUS_LABELS, x)}</option>)}</select></div>
        </div>
        <div className="row">
          <div className="field"><label htmlFor="i-own">{t('Propriété|statut')}</label><select id="i-own" value={f.ownership} onChange={set('ownership')}>{OWNERSHIPS.map((x) => <option key={x} value={x}>{tl(OWNERSHIP_LABELS, x)}</option>)}</select></div>
          {f.ownership !== 'OWNED' && <div className="field grow"><label htmlFor="i-lessor">{t('Loueur')}</label><input id="i-lessor" value={f.lessor} onChange={set('lessor')} /></div>}
          <div className="field"><label htmlFor="i-agency">{t('Agence')}</label>
            <select id="i-agency" value={f.agencyId} onChange={set('agencyId')}>
              <option value="">{t('Toute la société')}</option>
              {company?.agencies.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div className="field"><label htmlFor="i-driver">{t('Conducteur')}</label>
            <select id="i-driver" value={f.driverId} onChange={set('driverId')}>
              <option value="">{t('— Aucun —')}</option>
              {v.driver && !drivers.some((x) => x.id === v.driver!.id) && <option value={v.driver.id}>{v.driver.firstName} {v.driver.lastName}</option>}
              {drivers.map((x) => <option key={x.id} value={x.id}>{x.firstName} {x.lastName}</option>)}
            </select>
          </div>
          <div className="field"><label htmlFor="i-stock">{t('Stock embarqué')}</label>
            <select id="i-stock" value={f.stockLocationId} onChange={set('stockLocationId')}>
              <option value="">{t('— Aucun —')}</option>
              {locations.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
            </select>
          </div>
        </div>
        <div className="field"><label htmlFor="i-notes">{t('Notes')}</label><textarea id="i-notes" rows={2} value={f.notes} onChange={set('notes')} /></div>
        {canWrite && <div><button type="submit">{t('Enregistrer')}</button></div>}
      </fieldset>
      {v.stockLocation && <p className="small">{t('Stock du véhicule :')} <Link to="/stock">{v.stockLocation.name}</Link></p>}
    </form>
  );
}
