import { useMemo, useState } from 'react';
import {
  FIELD_TYPE_LABELS, FIELD_TYPES, fieldIdFromLabel, INTERVENTION_KINDS, PREFILL_SOURCES, TEMPLATE_LIMITS,
  type FieldType, type InterventionKind, type ReportData, type TemplateField, type TemplateSchema,
} from '@itineo/shared';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { OrgPicker } from '../components/Layout';
import { FormRenderer } from '../components/FormRenderer';
import { newId } from '../ids';
import type { FormTemplate } from '../types';
import { kindLabel, t, tl, tp } from '../i18n';

const SCOPE_LABELS: Record<FormTemplate['scope'], string> = {
  system: 'Modèle neutre Itinéos',
  group: 'Commun au groupe',
  company: 'Propre à la société',
};

/** Pack « installateur d'alarme et de vidéosurveillance » : fiches et documents du métier, ajoutés en un clic */
function SecurityPack({ companyId, companyName, onDone }: { companyId: string; companyName: string; onDone: (msg: string) => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const add = async () => {
    setBusy(true);
    setError(null);
    try {
      const { added } = await api<{ added: number }>('/templates/packs/security', { method: 'POST', body: { companyId } });
      onDone(added ? t('{n} modèles ajoutés à {name}. Vous pouvez les modifier comme les autres.', { n: added, name: companyName }) : t('Le pack est déjà installé.'));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="card stack">
      <h2>{t('Pack installateur d’alarme et de vidéosurveillance')}</h2>
      <p className="small muted" style={{ maxWidth: 760 }}>
        {t('Fiches de dépannage, de maintenance et d’installation du métier, utilisées pour les nouvelles fiches ; consignes de télésurveillance, dossiers techniques et procès-verbal de réception, à choisir sur l’intervention.')}
      </p>
      <div className="row">
        <button type="button" className="secondary" disabled={busy} onClick={() => void add()}>{t('Ajouter le pack à {name}', { name: companyName })}</button>
      </div>
      {error && <p className="error">{error}</p>}
    </section>
  );
}

/** Modèles de fiches : voir ceux utilisés par la société, les personnaliser */
export function TemplatesPage() {
  const { company, has } = useAuth();
  const canWrite = has('template.write');
  const { data, error, reload } = useLoad(
    () => (company ? api<FormTemplate[]>(`/templates${qs({ companyId: company.id })}`) : Promise.resolve([])),
    [company?.id],
  );
  const [editing, setEditing] = useState<{ base: FormTemplate; mode: 'copy' | 'edit' } | null>(null);
  const [preview, setPreview] = useState<FormTemplate | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  if (editing && company) {
    return (
      <TemplateEditor
        base={editing.base}
        mode={editing.mode}
        companyId={company.id}
        companyName={company.name}
        onClose={async (saved) => {
          setEditing(null);
          if (saved) {
            setMsg(t('Modèle enregistré : il sera utilisé pour les prochaines fiches. Les fiches déjà commencées ne changent pas.'));
            await reload();
          }
        }}
      />
    );
  }

  const archive = async (tpl: FormTemplate) => {
    if (!window.confirm(t('Retirer « {name} » ? Les prochaines fiches reprendront le modèle plus général.', { name: tpl.name }))) return;
    setMsg(null);
    try {
      await api(`/templates/${tpl.id}/archive`, { method: 'POST' });
      await reload();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{t("Fiches d'intervention")}</div>
          <h1>{t('Modèles de fiches')}</h1>
        </div>
        <OrgPicker />
      </div>
      <p className="muted" style={{ maxWidth: 760 }}>
        {t("Chaque type d'intervention utilise un modèle : celui de la société s'il existe, sinon celui du groupe, sinon le modèle neutre. Les horaires, pièces, photos, résultat et signatures font partie de toutes les fiches.")}
      </p>
      {!canWrite && <p className="muted small">{t('Vous pouvez consulter les modèles. Seul un administrateur peut les modifier.')}</p>}
      {msg && <p className="success" role="status">{msg}</p>}
      {error && <p className="error">{error}</p>}
      {canWrite && company && (company.sector ?? 'TECH') === 'TECH' && (
        <SecurityPack companyId={company.id} companyName={company.name} onDone={async (text) => { setMsg(text); await reload(); }} />
      )}

      <div className="stack">
        {INTERVENTION_KINDS.map((kind) => {
          const list = (data ?? []).filter((x) => x.kind === kind);
          const used = list.find((x) => x.inUse);
          return (
            <section key={kind} className="card stack">
              <h2>{kindLabel(kind)}</h2>
              {list.length === 0 && <p className="muted">{t('Aucun modèle.')}</p>}
              {list.map((tpl) => (
                <div key={tpl.id} className="row" style={{ justifyContent: 'space-between', borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
                  <div>
                    <strong>{tpl.name}</strong>{' '}
                    {tpl.inUse && <span className="badge ok">{t('Utilisé pour les nouvelles fiches')}</span>}
                    {!tpl.autoPick && <span className="badge neutral">{t('Document à choisir sur l’intervention')}</span>}
                    <div className="small muted">
                      {tl(SCOPE_LABELS, tpl.scope)} · {t('version {n}', { n: tpl.version })} · {tpl.schema.lang ?? 'fr'} ·{' '}
                      {tp(tpl.schema.sections.reduce((n, s) => n + s.fields.length, 0), '{n} champ', '{n} champs')}
                    </div>
                  </div>
                  <div className="row" style={{ gap: 6 }}>
                    <button type="button" className="secondary" onClick={() => setPreview(preview?.id === tpl.id ? null : tpl)}>
                      {preview?.id === tpl.id ? t("Fermer l'aperçu") : t('Aperçu')}
                    </button>
                    {canWrite && tpl.scope === 'company' && (
                      <>
                        <button type="button" onClick={() => setEditing({ base: tpl, mode: 'edit' })}>{t('Modifier')}</button>
                        <button type="button" className="ghost" onClick={() => void archive(tpl)}>{t('Retirer')}</button>
                      </>
                    )}
                    {canWrite && tpl.scope !== 'company' && (tpl.inUse || !tpl.autoPick) && (
                      <button type="button" className="accent" onClick={() => setEditing({ base: tpl, mode: 'copy' })}>
                        {t('Personnaliser pour {name}', { name: company?.name ?? '' })}
                      </button>
                    )}
                  </div>
                  {preview?.id === tpl.id && (
                    <div style={{ width: '100%' }}>
                      <Preview schema={tpl.schema} />
                    </div>
                  )}
                </div>
              ))}
              {!used && list.length > 0 && <p className="small muted">{t('Aucun modèle ne correspond à la langue de la société.')}</p>}
            </section>
          );
        })}
      </div>
    </>
  );
}

function Preview({ schema }: { schema: TemplateSchema }) {
  const [data, setData] = useState<ReportData>({});
  return (
    <div style={{ background: 'var(--ground)', borderRadius: 'var(--radius)', padding: 12, marginTop: 8 }}>
      <FormRenderer schema={schema} data={data} lang={schema.lang ?? 'fr'} onChange={(id, v) => setData((d) => ({ ...d, [id]: v }))} />
    </div>
  );
}

// ─── Éditeur ─────────────────────────────────────────────────────────────

/** Champ en cours d'édition : `key` sert à l'affichage, `id` n'existe qu'une fois le champ enregistré */
interface EField {
  key: string;
  id: string | null;
  label: string;
  type: FieldType;
  required: boolean;
  dictation: boolean;
  prefill: string;
  help: string;
  optionsText: string;
}
interface ESection { key: string; id: string | null; title: string; fields: EField[] }

const hasOptions = (ft: FieldType) => ft === 'select' || ft === 'checklist';
const isText = (ft: FieldType) => ft === 'text' || ft === 'textarea';

function toEditable(schema: TemplateSchema): ESection[] {
  return schema.sections.map((s) => ({
    key: newId(),
    id: s.id,
    title: s.title,
    fields: s.fields.map((f) => ({
      key: newId(),
      id: f.id,
      label: f.label,
      type: f.type,
      required: !!f.required,
      dictation: !!f.dictation,
      prefill: f.prefill ?? '',
      help: f.help ?? '',
      optionsText: (f.options ?? []).join('\n'),
    })),
  }));
}

/**
 * Construit le modèle à enregistrer. Les nouveaux champs reçoivent un identifiant tiré de leur libellé ;
 * les champs existants gardent le leur (c'est la clé des valeurs déjà saisies).
 * Pour l'aperçu (`forPreview`), les nouveaux champs utilisent leur clé temporaire.
 */
function toSchema(sections: ESection[], lang: string | undefined, forPreview = false): TemplateSchema {
  const taken = new Set(sections.flatMap((s) => s.fields.map((f) => f.id).filter((x): x is string => !!x)));
  const takenSections = new Set(sections.map((s) => s.id).filter((x): x is string => !!x));
  return {
    ...(lang ? { lang } : {}),
    sections: sections.map((s) => {
      let sid = s.id;
      if (!sid) {
        sid = forPreview ? s.key : fieldIdFromLabel(s.title, takenSections);
        takenSections.add(sid);
      }
      return {
        id: sid,
        title: s.title.trim(),
        fields: s.fields.map((f): TemplateField => {
          let id = f.id;
          if (!id) {
            id = forPreview ? `n${f.key.replace(/-/g, '')}` : fieldIdFromLabel(f.label, taken);
            taken.add(id);
          }
          const options = f.optionsText.split('\n').map((o) => o.trim()).filter(Boolean);
          return {
            id,
            label: f.label.trim(),
            type: f.type,
            ...(f.required ? { required: true } : {}),
            ...(isText(f.type) && f.dictation ? { dictation: true } : {}),
            ...(f.prefill && f.type !== 'checkbox' && !hasOptions(f.type) ? { prefill: f.prefill } : {}),
            ...(f.help.trim() ? { help: f.help.trim() } : {}),
            ...(hasOptions(f.type) ? { options } : {}),
          };
        }),
      };
    }),
  };
}

const blankField = (): EField => ({
  key: newId(), id: null, label: '', type: 'text', required: false, dictation: false, prefill: '', help: '', optionsText: '',
});

function move<T>(list: T[], from: number, to: number): T[] {
  if (to < 0 || to >= list.length) return list;
  const next = [...list];
  const [item] = next.splice(from, 1);
  next.splice(to, 0, item);
  return next;
}

function TemplateEditor({ base, mode, companyId, companyName, onClose }: {
  base: FormTemplate;
  mode: 'copy' | 'edit';
  companyId: string;
  companyName: string;
  onClose: (saved: boolean) => void;
}) {
  const [name, setName] = useState(mode === 'copy' ? `${base.name} – ${companyName}` : base.name);
  const [sections, setSections] = useState<ESection[]>(() => toEditable(base.schema));
  const [dirty, setDirty] = useState(mode === 'copy');
  const [errors, setErrors] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [previewData, setPreviewData] = useState<ReportData>({});
  const lang = base.schema.lang;

  const previewSchema = useMemo(() => toSchema(sections, lang, true), [sections, lang]);
  const fieldCount = sections.reduce((n, s) => n + s.fields.length, 0);

  const change = (next: ESection[]) => {
    setSections(next);
    setDirty(true);
  };
  const setSection = (si: number, patch: Partial<ESection>) => change(sections.map((s, i) => (i === si ? { ...s, ...patch } : s)));
  const setField = (si: number, fi: number, patch: Partial<EField>) =>
    setSection(si, { fields: sections[si].fields.map((f, i) => (i === fi ? { ...f, ...patch } : f)) });

  /** Contrôles avant envoi, avec des messages qui disent où regarder */
  const check = (): string[] => {
    const out: string[] = [];
    if (!name.trim()) out.push(t('Donnez un nom au modèle.'));
    if (!sections.length) out.push(t('Ajoutez au moins une section.'));
    sections.forEach((s, si) => {
      const where = s.title.trim() ? t('Section {n} « {title} »', { n: si + 1, title: s.title.trim() }) : t('Section {n}', { n: si + 1 });
      if (!s.title.trim()) out.push(t('{where} : titre manquant.', { where }));
      if (!s.fields.length) out.push(t('{where} : ajoutez au moins un champ.', { where }));
      s.fields.forEach((f, fi) => {
        const fw = t('{where}, champ {n}', { where, n: fi + 1 });
        if (!f.label.trim()) out.push(t('{where} : libellé manquant.', { where: fw }));
        if (hasOptions(f.type)) {
          const opts = f.optionsText.split('\n').map((o) => o.trim()).filter(Boolean);
          if (!opts.length) out.push(t('{where} : indiquez les choix possibles (un par ligne).', { where: fw }));
          if (new Set(opts).size !== opts.length) out.push(t('{where} : deux choix identiques.', { where: fw }));
        }
      });
    });
    return out;
  };

  const save = async () => {
    const problems = check();
    setErrors(problems);
    if (problems.length) return;
    setBusy(true);
    try {
      const schema = toSchema(sections, lang);
      if (mode === 'copy') {
        await api('/templates', { method: 'POST', body: { companyId, name: name.trim(), kind: base.kind, schema, autoPick: base.autoPick } });
      } else {
        await api(`/templates/${base.id}`, { method: 'PUT', body: { name: name.trim(), schema } });
      }
      onClose(true);
    } catch (e) {
      setErrors([(e as Error).message]);
    } finally {
      setBusy(false);
    }
  };

  const cancel = () => {
    if (dirty && !window.confirm(t('Abandonner les modifications ?'))) return;
    onClose(false);
  };

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{kindLabel(base.kind as InterventionKind)} · {mode === 'copy' ? t('nouveau modèle pour {name}', { name: companyName }) : t('version {a} → {b}', { a: base.version, b: base.version + 1 })}</div>
          <h1>{mode === 'copy' ? t('Personnaliser le modèle') : t('Modifier le modèle')}</h1>
        </div>
        <div className="row" style={{ gap: 8 }}>
          <button type="button" className="secondary" onClick={cancel}>{t('Annuler')}</button>
          <button type="button" className="accent" disabled={busy} onClick={() => void save()}>{busy ? t('Enregistrement…') : t('Enregistrer')}</button>
        </div>
      </div>

      {errors.length > 0 && (
        <div className="card" role="alert" style={{ background: 'var(--warn-bg)', color: 'var(--warn-fg)' }}>
          <strong>{t('À corriger :')}</strong>
          <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>{errors.map((e) => <li key={e}>{e}</li>)}</ul>
        </div>
      )}

      <div className="template-editor">
        <div className="stack">
          <section className="card stack">
            <div className="field"><label htmlFor="tpl-name">{t('Nom du modèle')}</label>
              <input id="tpl-name" value={name} maxLength={TEMPLATE_LIMITS.label} onChange={(e) => { setName(e.target.value); setDirty(true); }} />
            </div>
            <p className="small muted" style={{ margin: 0 }}>
              {t('Les horaires, pièces, photos, résultat et signatures sont ajoutés automatiquement à toutes les fiches. Les fiches déjà commencées gardent leur ancienne version.')}
            </p>
          </section>

          {sections.map((s, si) => (
            <section key={s.key} className="card stack">
              <div className="row" style={{ alignItems: 'flex-end' }}>
                <div className="field grow"><label htmlFor={`sec-${s.key}`}>{t('Titre de la section {n}', { n: si + 1 })}</label>
                  <input id={`sec-${s.key}`} value={s.title} maxLength={TEMPLATE_LIMITS.label} onChange={(e) => setSection(si, { title: e.target.value })} />
                </div>
                <IconButtons
                  label={t('section {n}', { n: si + 1 })}
                  onUp={si > 0 ? () => change(move(sections, si, si - 1)) : undefined}
                  onDown={si < sections.length - 1 ? () => change(move(sections, si, si + 1)) : undefined}
                  onRemove={() => {
                    if (s.fields.length && !window.confirm(tp(s.fields.length, 'Supprimer la section « {title} » et son champ ?', 'Supprimer la section « {title} » et ses {n} champs ?', { title: s.title || si + 1 }))) return;
                    change(sections.filter((_, i) => i !== si));
                  }}
                />
              </div>

              {s.fields.map((f, fi) => (
                <div key={f.key} className="field-editor">
                  <div className="row" style={{ alignItems: 'flex-end' }}>
                    <div className="field grow"><label htmlFor={`lbl-${f.key}`}>{t('Libellé du champ')}</label>
                      <input id={`lbl-${f.key}`} value={f.label} maxLength={TEMPLATE_LIMITS.label} placeholder={t('Ex. : Pression relevée (bar)')}
                        onChange={(e) => setField(si, fi, { label: e.target.value })} />
                    </div>
                    <div className="field"><label htmlFor={`type-${f.key}`}>{t('Type')}</label>
                      <select id={`type-${f.key}`} value={f.type} onChange={(e) => setField(si, fi, { type: e.target.value as FieldType })}>
                        {FIELD_TYPES.map((ft) => <option key={ft} value={ft}>{tl(FIELD_TYPE_LABELS, ft)}</option>)}
                      </select>
                    </div>
                    <IconButtons
                      label={t('champ {name}', { name: f.label || fi + 1 })}
                      onUp={fi > 0 ? () => setSection(si, { fields: move(s.fields, fi, fi - 1) }) : undefined}
                      onDown={fi < s.fields.length - 1 ? () => setSection(si, { fields: move(s.fields, fi, fi + 1) }) : undefined}
                      onRemove={() => setSection(si, { fields: s.fields.filter((_, i) => i !== fi) })}
                    />
                  </div>
                  {hasOptions(f.type) && (
                    <div className="field"><label htmlFor={`opt-${f.key}`}>{t('Choix possibles (un par ligne)')}</label>
                      <textarea id={`opt-${f.key}`} rows={3} value={f.optionsText} onChange={(e) => setField(si, fi, { optionsText: e.target.value })} />
                    </div>
                  )}
                  <div className="row" style={{ gap: 14 }}>
                    <label className="check"><input type="checkbox" checked={f.required} onChange={(e) => setField(si, fi, { required: e.target.checked })} />{t('Obligatoire')}</label>
                    {isText(f.type) && (
                      <label className="check"><input type="checkbox" checked={f.dictation} onChange={(e) => setField(si, fi, { dictation: e.target.checked })} />{t('Dictée vocale')}</label>
                    )}
                    {!hasOptions(f.type) && f.type !== 'checkbox' && (
                      <div className="field" style={{ minWidth: 220 }}>
                        <label htmlFor={`pre-${f.key}`}>{t('Pré-rempli avec')}</label>
                        <select id={`pre-${f.key}`} value={f.prefill} onChange={(e) => setField(si, fi, { prefill: e.target.value })}>
                          <option value="">{t('Rien (saisi sur place)')}</option>
                          {PREFILL_SOURCES.map((p) => <option key={p.path} value={p.path}>{t(p.label)}</option>)}
                        </select>
                      </div>
                    )}
                  </div>
                  <div className="field"><label htmlFor={`help-${f.key}`}>{t('Aide pour le technicien (facultatif)')}</label>
                    <input id={`help-${f.key}`} value={f.help} maxLength={500} onChange={(e) => setField(si, fi, { help: e.target.value })} />
                  </div>
                  {f.id && <div className="small muted">{t('Identifiant : {id}', { id: f.id })}</div>}
                </div>
              ))}

              <button type="button" className="secondary" disabled={s.fields.length >= TEMPLATE_LIMITS.fieldsPerSection}
                onClick={() => setSection(si, { fields: [...s.fields, blankField()] })}>
                {t('+ Ajouter un champ')}
              </button>
            </section>
          ))}

          <button type="button" className="secondary" disabled={sections.length >= TEMPLATE_LIMITS.sections}
            onClick={() => change([...sections, { key: newId(), id: null, title: '', fields: [blankField()] }])}>
            {t('+ Ajouter une section')}
          </button>
        </div>

        <aside className="template-preview">
          <div className="section-title" style={{ marginBottom: 8 }}>{tp(fieldCount, 'Aperçu ({n} champ) : la fiche vue par le technicien', 'Aperçu ({n} champs) : la fiche vue par le technicien')}</div>
          <FormRenderer schema={previewSchema} data={previewData} lang={lang ?? 'fr'}
            onChange={(id, v) => setPreviewData((d) => ({ ...d, [id]: v }))} />
        </aside>
      </div>
    </>
  );
}

function IconButtons({ label, onUp, onDown, onRemove }: { label: string; onUp?: () => void; onDown?: () => void; onRemove: () => void }) {
  return (
    <div className="row" style={{ gap: 4 }}>
      <button type="button" className="ghost" aria-label={t('Monter {what}', { what: label })} title={t('Monter')} disabled={!onUp} onClick={onUp}>↑</button>
      <button type="button" className="ghost" aria-label={t('Descendre {what}', { what: label })} title={t('Descendre')} disabled={!onDown} onClick={onDown}>↓</button>
      <button type="button" className="ghost" aria-label={t('Supprimer {what}', { what: label })} title={t('Supprimer')} onClick={onRemove}>✕</button>
    </div>
  );
}
