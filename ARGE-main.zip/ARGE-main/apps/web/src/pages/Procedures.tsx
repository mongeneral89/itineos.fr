/**
 * Notices et procédures : la bibliothèque de documents consultée sur le terrain.
 * Le bureau publie ; un technicien propose, et le bureau valide ou refuse avec un motif.
 * Un document déjà ouvert reste lisible sans réseau (copie gardée sur l'appareil).
 */
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { PROCEDURE_CATEGORIES, PROCEDURE_CATEGORY_LABELS, type ProcedureCategory, type ProcedureStatus } from '@itineo/shared';
import { api, getToken } from '../api';
import { useAuth } from '../auth';
import { fmtDate } from '../format';
import { FILE_ACCEPT, fmtSize, opensInBrowser, pickFile, type PickedFile } from '../files';
import { t, tl, tp } from '../i18n';
import { apiUrl, isNativeApp, openNativeFile } from '../native';

export interface Procedure {
  id: string; companyId: string | null; agencyId: string | null; category: ProcedureCategory; title: string;
  description: string | null; keywords: string | null; url: string | null;
  fileName: string | null; fileMime: string | null; fileSize: number | null; hasFile: boolean;
  status: ProcedureStatus; submittedBy: string | null; submittedByName: string | null;
  reviewedByName: string | null; reviewedAt: string | null; reviewNote: string | null;
  createdAt: string; updatedAt: string; canManage: boolean; mine: boolean;
}

type Tab = 'library' | 'review' | 'mine';
const LIST_KEY = 'itineo.procedures';
const CACHE = 'itineo-procedures';

/** Liste gardée sur l'appareil pour la consulter sans réseau */
function saveList(list: Procedure[]) {
  try {
    localStorage.setItem(LIST_KEY, JSON.stringify(list.filter((p) => p.status === 'APPROVED')));
  } catch {
    /* stockage plein ou indisponible */
  }
}
function savedList(): Procedure[] | null {
  try {
    const v = localStorage.getItem(LIST_KEY);
    return v ? (JSON.parse(v) as Procedure[]) : null;
  } catch {
    return null;
  }
}

/** Nombre de documents à valider (pastille du menu), relu toutes les minutes */
export function usePendingProcedures(enabled: boolean): number {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!enabled) return;
    let stop = false;
    const load = () => api<{ pending: number }>('/procedures/pending-count').then((r) => !stop && setN(r.pending)).catch(() => undefined);
    void load();
    const timer = window.setInterval(load, 60_000);
    window.addEventListener('itineo:procedures', load);
    return () => {
      stop = true;
      window.clearInterval(timer);
      window.removeEventListener('itineo:procedures', load);
    };
  }, [enabled]);
  return n;
}

/**
 * Ouvre le fichier d'un document : depuis le serveur (et en garde une copie sur l'appareil),
 * ou depuis la copie quand il n'y a pas de réseau.
 */
async function openProcedureFile(p: Procedure) {
  const key = `/api/procedures/${p.id}/file?v=${encodeURIComponent(p.updatedAt)}`;
  const inBrowser = opensInBrowser(p.fileMime ?? '');
  const win = inBrowser && !isNativeApp() ? window.open('', '_blank') : null;
  let blob: Blob | null = null;
  try {
    const res = await fetch(apiUrl(`/procedures/${p.id}/file`), { headers: { Authorization: `Bearer ${getToken() ?? ''}` } });
    if (res.ok) {
      blob = await res.blob();
      if ('caches' in window && p.status === 'APPROVED') {
        void caches.open(CACHE).then((c) => c.put(key, new Response(blob, { headers: { 'Content-Type': p.fileMime ?? '' } }))).catch(() => undefined);
      }
    }
  } catch {
    /* pas de réseau : on cherche la copie */
  }
  if (!blob && 'caches' in window) {
    const hit = await caches.open(CACHE).then((c) => c.match(key)).catch(() => undefined);
    if (hit) blob = await hit.blob();
  }
  if (!blob) {
    win?.close();
    throw new Error(t('Document indisponible sans réseau : ouvrez-le une fois avec du réseau pour le garder sur l’appareil.'));
  }
  if (isNativeApp()) return openNativeFile(blob, p.fileName ?? 'document');
  const url = URL.createObjectURL(blob);
  if (inBrowser) {
    if (win) win.location.href = url;
    else window.location.href = url;
  } else {
    const a = document.createElement('a');
    a.href = url;
    a.download = p.fileName ?? 'document';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

export function ProceduresPage() {
  const { me, has } = useAuth();
  const manager = has('procedure.manage');
  const [list, setList] = useState<Procedure[] | null>(null);
  const [offline, setOffline] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('library');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<ProcedureCategory | ''>('');
  const [editing, setEditing] = useState<Procedure | 'new' | null>(null);

  const load = async () => {
    try {
      const rows = await api<Procedure[]>('/procedures');
      setList(rows);
      setOffline(false);
      setError(null);
      saveList(rows);
    } catch (e) {
      const saved = savedList();
      if (saved) {
        setList(saved);
        setOffline(true);
      } else setError((e as Error).message);
    }
  };
  useEffect(() => {
    void load();
  }, []);

  const changed = () => {
    void load();
    window.dispatchEvent(new Event('itineo:procedures'));
  };

  const places = useMemo(() => {
    const m = new Map<string, string>();
    for (const c of me?.org ?? []) {
      m.set(c.id, c.name);
      for (const a of c.agencies) m.set(a.id, a.name);
    }
    return m;
  }, [me]);
  const scopeLabel = (p: Procedure) => (p.agencyId ? places.get(p.agencyId) : p.companyId ? places.get(p.companyId) : t('Tout le groupe')) ?? '';

  const all = list ?? [];
  const library = all.filter((p) => p.status === 'APPROVED');
  const toReview = all.filter((p) => p.status === 'PENDING' && p.canManage);
  const mine = all.filter((p) => p.mine && p.status !== 'APPROVED');
  const search = norm(q.trim());
  const filter = (rows: Procedure[]) => rows
    .filter((p) => !cat || p.category === cat)
    .filter((p) => !search || norm([p.title, p.description, p.keywords, p.fileName, tl(PROCEDURE_CATEGORY_LABELS, p.category)].filter(Boolean).join(' ')).includes(search));
  const shown = filter(tab === 'review' ? toReview : tab === 'mine' ? mine : library);

  const TABS: { id: Tab; label: string; n: number; show: boolean }[] = [
    { id: 'library', label: 'Documents', n: library.length, show: true },
    { id: 'review', label: 'À valider', n: toReview.length, show: manager },
    { id: 'mine', label: 'Mes propositions', n: mine.length, show: mine.length > 0 || !manager },
  ];

  return (
    <>
      <div className="topbar">
        <div>
          <div className="eyebrow">{t('Notices fabricants, procédures, schémas, consignes de sécurité')}</div>
          <h1>{t('Notices et procédures')}</h1>
        </div>
        {!editing && !offline && (
          <button type="button" className="accent" onClick={() => setEditing('new')}>{manager ? t('Ajouter un document') : t('Proposer un document')}</button>
        )}
      </div>
      {offline && <p className="muted small">{t('Pas de réseau : liste gardée sur l’appareil. Seuls les documents déjà ouverts sont lisibles.')}</p>}
      {!manager && !editing && <p className="small muted">{t('Un document que vous proposez est visible par le bureau, qui le valide avant de le partager à l’équipe.')}</p>}
      {editing && (
        <section className="card">
          <ProcedureForm initial={editing === 'new' ? null : editing} manager={editing === 'new' ? manager : editing.canManage}
            onCancel={() => setEditing(null)} onSaved={() => { setEditing(null); changed(); }} />
        </section>
      )}

      <div className="row">
        <div className="chips" role="tablist" aria-label={t('Rubriques')}>
          {TABS.filter((x) => x.show).map((x) => (
            <button key={x.id} type="button" role="tab" aria-selected={tab === x.id} className={`chip${tab === x.id ? ' on' : ''}`} onClick={() => setTab(x.id)}>
              {t(x.label)} <span className={x.id === 'review' && x.n ? 'nav-badge' : 'muted small'}>{x.id === 'review' && x.n ? x.n : `(${x.n})`}</span>
            </button>
          ))}
        </div>
        <input type="search" style={{ width: 260 }} placeholder={t('Rechercher : titre, marque, modèle…')} aria-label={t('Rechercher un document')} value={q} onChange={(e) => setQ(e.target.value)} />
        <select style={{ width: 'auto' }} value={cat} aria-label={t('Catégorie')} onChange={(e) => setCat(e.target.value as ProcedureCategory | '')}>
          <option value="">{t('Toutes les catégories')}</option>
          {PROCEDURE_CATEGORIES.map((c) => <option key={c} value={c}>{tl(PROCEDURE_CATEGORY_LABELS, c)}</option>)}
        </select>
      </div>
      {error && <p className="error">{error}</p>}
      {!list && !error && <p className="muted">{t('Chargement…')}</p>}

      {list && (
        <section className="card stack">
          {!shown.length && (
            <p className="muted">
              {tab === 'review' ? t('Aucun document à valider.') : tab === 'mine' ? t('Vous n’avez pas de proposition en cours.')
                : search || cat ? t('Aucun document ne correspond à la recherche.') : t('La bibliothèque est vide pour l’instant.')}
            </p>
          )}
          {tab === 'library' && shown.length > 0 && <p className="small muted">{tp(shown.length, '{n} document', '{n} documents')}</p>}
          <div className="dir-grid">
            {shown.map((p) => (
              <ProcedureCard key={p.id} p={p} scope={scopeLabel(p)} offline={offline} onEdit={() => setEditing(p)} onChanged={changed} />
            ))}
          </div>
        </section>
      )}
    </>
  );
}

function ProcedureCard({ p, scope, offline, onEdit, onChanged }: { p: Procedure; scope: string; offline: boolean; onEdit: () => void; onChanged: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const approve = () => run(() => api(`/procedures/${p.id}/review`, { method: 'POST', body: { decision: 'APPROVED' } }));
  const reject = () => {
    const note = window.prompt(t('Motif du refus (montré à la personne qui a proposé le document) :'));
    if (!note?.trim()) return;
    void run(() => api(`/procedures/${p.id}/review`, { method: 'POST', body: { decision: 'REJECTED', note } }));
  };
  const remove = () => {
    if (!window.confirm(t('Supprimer « {name} » ?', { name: p.title }))) return;
    void run(() => api(`/procedures/${p.id}`, { method: 'DELETE' }));
  };
  const editable = !offline && (p.canManage || (p.mine && p.status !== 'APPROVED'));

  return (
    <div className="dir-card">
      <span className="row" style={{ gap: 6 }}>
        <span className="badge neutral">{tl(PROCEDURE_CATEGORY_LABELS, p.category)}</span>
        {p.status === 'PENDING' && <span className="badge warn">{t('En attente de validation')}</span>}
        {p.status === 'REJECTED' && <span className="badge danger">{t('Refusé')}</span>}
      </span>
      <strong>{p.title}</strong>
      {p.description && <span className="small" style={{ whiteSpace: 'pre-wrap' }}>{p.description}</span>}
      {p.keywords && <span className="small muted">{p.keywords}</span>}
      <span className="small muted">
        {scope}
        {p.submittedByName && p.status !== 'APPROVED' ? ` · ${t('proposé par {name}', { name: p.submittedByName })}` : ''}
        {` · ${fmtDate(p.updatedAt)}`}
      </span>
      {p.status === 'REJECTED' && p.reviewNote && <span className="small error">{t('Motif : {note}', { note: p.reviewNote })}</span>}
      <span className="row" style={{ gap: 6 }}>
        {p.hasFile && (
          <button type="button" className="secondary" onClick={() => openProcedureFile(p).catch((e) => setError((e as Error).message))}>
            {opensInBrowser(p.fileMime ?? '') ? t('Ouvrir') : t('Télécharger')}{p.fileSize ? ` · ${fmtSize(p.fileSize)}` : ''}
          </button>
        )}
        {p.url && <a className="btn secondary" href={p.url} target="_blank" rel="noreferrer">{t('Ouvrir le lien')}</a>}
      </span>
      {p.status === 'PENDING' && p.canManage && !offline && (
        <span className="row" style={{ gap: 6 }}>
          <button type="button" disabled={busy} onClick={() => void approve()}>{t('Valider')}</button>
          <button type="button" className="secondary" disabled={busy} onClick={reject}>{t('Refuser')}</button>
        </span>
      )}
      {editable && (
        <span className="row" style={{ gap: 6 }}>
          <button type="button" className="ghost" onClick={onEdit}>{t('Modifier')}</button>
          <button type="button" className="ghost" disabled={busy} onClick={remove}>{t('Supprimer')}</button>
        </span>
      )}
      {error && <p className="error small">{error}</p>}
    </div>
  );
}

function ProcedureForm({ initial, manager, onCancel, onSaved }: { initial: Procedure | null; manager: boolean; onCancel: () => void; onSaved: () => void }) {
  const { me, company, agency } = useAuth();
  const [f, setF] = useState({
    title: initial?.title ?? '', category: initial?.category ?? ('PROCEDURE' as ProcedureCategory),
    description: initial?.description ?? '', keywords: initial?.keywords ?? '', url: initial?.url ?? '',
    scope: initial
      ? initial.agencyId ? `a:${initial.companyId}:${initial.agencyId}` : initial.companyId ? `c:${initial.companyId}` : 'g'
      : agency && company ? `a:${company.id}:${agency.id}` : company ? `c:${company.id}` : 'g',
  });
  const [file, setFile] = useState<PickedFile | null>(null);
  const [preparing, setPreparing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((x) => ({ ...x, [k]: e.target.value }));

  const choose = async (picked: File | undefined) => {
    if (!picked) return;
    setPreparing(true);
    setError(null);
    try {
      const prepared = await pickFile(picked);
      setFile(prepared);
      if (!f.title.trim()) setF((x) => ({ ...x, title: picked.name.replace(/\.[^.]+$/, '') }));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPreparing(false);
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!file && !initial?.hasFile && !f.url.trim()) return setError(t('Joignez un fichier ou indiquez un lien'));
    setBusy(true);
    setError(null);
    const [kind, companyId, agencyId] = f.scope.split(':');
    const body = {
      title: f.title, category: f.category, description: f.description, keywords: f.keywords, url: f.url,
      companyId: kind === 'g' ? null : companyId, agencyId: kind === 'a' ? agencyId : null,
      ...(file ? { file: { dataUrl: file.dataUrl, name: file.name } } : {}),
    };
    try {
      await api(initial ? `/procedures/${initial.id}` : '/procedures', { method: initial ? 'PATCH' : 'POST', body });
      onSaved();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="stack" onSubmit={submit}>
      <h2 style={{ fontSize: 17 }}>{initial ? t('Modifier le document') : manager ? t('Ajouter un document') : t('Proposer un document')}</h2>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div className="field grow">
          <label htmlFor="pr-title">{t('Titre')}</label>
          <input id="pr-title" value={f.title} onChange={set('title')} required maxLength={160} placeholder={t('Ex. : Notice centrale Ajax Hub 2')} />
        </div>
        <div className="field grow">
          <label htmlFor="pr-cat">{t('Catégorie')}</label>
          <select id="pr-cat" value={f.category} onChange={set('category')}>
            {PROCEDURE_CATEGORIES.map((c) => <option key={c} value={c}>{tl(PROCEDURE_CATEGORY_LABELS, c)}</option>)}
          </select>
        </div>
        {manager && (
          <div className="field grow">
            <label htmlFor="pr-scope">{t('Visible par')}</label>
            <select id="pr-scope" value={f.scope} onChange={set('scope')}>
              <option value="g">{t('Tout le groupe')}</option>
              {(me?.org ?? []).map((c) => (
                <optgroup key={c.id} label={c.name}>
                  <option value={`c:${c.id}`}>{t('Toute la société {name}', { name: c.name })}</option>
                  {c.agencies.map((a) => <option key={a.id} value={`a:${c.id}:${a.id}`}>{a.name}</option>)}
                </optgroup>
              ))}
            </select>
          </div>
        )}
      </div>
      <div className="field">
        <label htmlFor="pr-desc">{t('Description (facultatif)')}</label>
        <textarea id="pr-desc" rows={2} value={f.description} onChange={set('description')} maxLength={2000} />
      </div>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div className="field grow">
          <label htmlFor="pr-kw">{t('Mots-clés : marque, modèle, référence (pour la recherche)')}</label>
          <input id="pr-kw" value={f.keywords} onChange={set('keywords')} maxLength={300} />
        </div>
        <div className="field grow">
          <label htmlFor="pr-url">{t('Lien (facultatif)')}</label>
          <input id="pr-url" value={f.url} onChange={set('url')} maxLength={500} placeholder="https://…" />
        </div>
      </div>
      <div className="field">
        <label htmlFor="pr-file">
          {t('Fichier : PDF, photo, document bureautique, vidéo (10 Mo maximum)')}
          {initial?.hasFile ? ` ${t(': remplace le fichier actuel ({name})', { name: initial.fileName ?? '' })}` : ''}
        </label>
        <input id="pr-file" type="file" accept={FILE_ACCEPT} onChange={(e) => void choose(e.target.files?.[0])} />
        {preparing && <span className="small muted">{t('Préparation du fichier…')}</span>}
        {file && <span className="small">{file.name} · {fmtSize(file.size)}</span>}
      </div>
      {!manager && <p className="small muted">{t('Le bureau validera ce document avant qu’il soit visible par toute l’équipe.')}</p>}
      {error && <p className="error small">{error}</p>}
      <div className="row">
        <button type="submit" disabled={busy || preparing}>{initial ? t('Enregistrer') : manager ? t('Publier') : t('Envoyer au bureau')}</button>
        <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
      </div>
    </form>
  );
}
