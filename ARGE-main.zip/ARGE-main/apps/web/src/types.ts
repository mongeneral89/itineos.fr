import type {
  ContractStatus, InterventionKind, InterventionStatus, InvoiceKind, InvoiceStatus, PaymentMethod, PaymentState,
  Permission, PhotoKind, Priority, QuoteKind, QuoteStatus, SlipStatus, StockLocationKind, StockMovementKind,
  DueState, Ownership, VehicleDeadlineKind, VehicleEventKind, VehicleStatus, VehicleType,
  CheckpointScan, ReportData, ReportStatus, Role, Sector, TemplateSchema,
} from '@itineo/shared';

export interface Agency {
  id: string; companyId: string; name: string; code: string; city: string | null;
  teams: { id: string; name: string }[];
}

export interface Company {
  id: string; name: string; countryCode: string; currency: string; locale: string; timezone: string;
  documentPrefix: string; city: string | null; agencies: Agency[];
  legalMentions: string | null; paymentTermsDays: number; hourlyRateCents: number | null;
  travelFeeCents: number | null; bankDetails: string | null;
  /** Prélèvement SEPA : identifiant créancier, IBAN et BIC du compte qui reçoit les prélèvements */
  sepaCreditorId?: string | null; sepaIban?: string | null; sepaBic?: string | null;
  dunningEnabled?: boolean; dunningDays?: number[];
  /** Facture électronique : SIREN, n° de TVA, TVA sur les débits, plateforme agréée (le jeton n'est jamais renvoyé) */
  siren?: string | null; vatNumber?: string | null; vatOnDebits?: boolean;
  einvoiceApiUrl?: string | null; einvoiceTokenSet?: boolean; einvoiceAutoSend?: boolean;
  assignSuggestions?: boolean; geocodeSites?: boolean;
  /** Liens du menu vers les outils en ligne de la société (DocuSign…), ouverts dans un onglet à part */
  menuLinks?: { label: string; url: string }[];
  /** Secteur d'activité : vocabulaire, modules visibles et modèles fournis */
  sector?: Sector;
  /** Date du logo (vide : pas de logo) ; image à /api/logos/:id */
  logoUpdatedAt?: string | null;
}

export interface Me {
  user: { id: string; email: string; firstName: string; lastName: string; locale: string; skills: string[]; phone?: string | null };
  assignments: { role: Role; companyId: string | null; agencyId: string | null; label: string }[];
  permissions: Permission[];
  org: Company[];
}

export interface InterventionRow {
  id: string; number: string; companyId: string; agencyId: string; kind: InterventionKind;
  status: InterventionStatus; priority: Priority; source: string | null; reason: string;
  scheduledStart: string | null; scheduledEnd: string | null; technicianId: string | null;
  clientId: string; siteId: string; equipmentId: string | null; createdAt: string;
  clientName: string; siteName: string; siteCity: string | null;
  siteAddress?: string | null; sitePostalCode?: string | null; siteLat?: number | null; siteLng?: number | null;
  /** Document à remplir choisi pour l'intervention (sinon le modèle par défaut de son type) */
  templateId?: string | null;
  technicianFirstName: string | null; technicianLastName: string | null;
  /** Visite d'un contrat / travaux d'un devis, et échéance (AAAA-MM-JJ) */
  contractId: string | null; quoteId: string | null; dueDate: string | null;
  requiredCertificationIds: string[];
}

export interface InterventionDetail extends InterventionRow {
  technicianEmail: string | null;
  /** Demande faite par le client sur l'espace client */
  clientNotes?: string | null;
  requestedByPortalUserId?: string | null;
  /** Matériel à prévoir (suggestion d'attribution) */
  neededParts?: { articleId: string; quantity: number }[];
  /** Annulation : motif et date */
  cancelReason?: string | null;
  cancelledAt?: string | null;
  report: { id: string; status: ReportStatus; sentAt: string | null; outcome: string | null; photos: ReportPhoto[] } | null;
}

export interface QuoteLine { description: string; quantity: number; unit: string | null; unitPriceCents: number; vatRateBp: number }

export interface QuoteRow {
  id: string; number: string; companyId: string; agencyId: string | null; clientId: string; kind: QuoteKind;
  status: QuoteStatus; title: string; validUntil: string | null; currency: string; netCents: number; grossCents: number;
  sentAt: string | null; createdAt: string; clientName: string;
}

export interface QuoteDetail extends Omit<QuoteRow, 'clientName'> {
  siteId: string | null; intro: string | null; notes: string | null; contractFrequencyMonths: number | null;
  vatCents: number; sentTo: string | null; decidedAt: string | null;
  /** Réponse donnée par le client sur l'espace client */
  decidedByPortalUserId?: string | null; decisionName?: string | null; decisionNote?: string | null;
  lines: QuoteLine[]; client: Client; site: Site | null;
  interventions: { id: string; number: string; status: InterventionStatus }[];
  contracts: { id: string; number: string; status: ContractStatus }[];
}

export interface ContractRow {
  id: string; number: string; companyId: string; agencyId: string; clientId: string; siteId: string; title: string;
  status: ContractStatus; frequencyMonths: number; startDate: string; endDate: string | null;
  annualPriceCents: number | null; clientName: string; siteName: string; siteCity: string | null;
  /** Facturation en lot : tous les N mois (vide = non), déjà facturé jusqu'au */
  billingMonths: number | null; billedUntil: string | null;
}

export interface ContractDetail extends Omit<ContractRow, 'clientName' | 'siteName' | 'siteCity'> {
  equipmentIds: string[]; visitHours: number; notes: string | null;
  client: Client; site: Site; equipments: Equipment[];
  visits: { id: string; number: string; status: InterventionStatus; dueDate: string | null; scheduledStart: string | null; technicianId: string | null }[];
  quote: { id: string; number: string } | null;
}

export interface UserRow {
  id: string; email: string; firstName: string; lastName: string; phone: string | null;
  skills: string[]; locale?: string; active: boolean; roles: { role: Role; companyId: string | null; agencyId: string | null }[];
}

export interface Equipment {
  id: string; siteId: string; category: string; brand: string | null; model: string | null;
  serialNumber: string | null; location: string | null; installedAt: string | null; underContract: boolean;
  /** Où le trouver sur place (montré en évidence au technicien) */
  locateHint?: string | null;
}

export interface Site {
  id: string; clientId: string; name: string; address: string | null; postalCode: string | null;
  city: string | null; accessNotes: string | null; equipments?: Equipment[];
  latitude?: number | null; longitude?: number | null;
}

export interface Client {
  id: string; companyId: string; agencyId: string | null; type: 'COMPANY' | 'INDIVIDUAL'; name: string;
  email: string | null; phone: string | null; address: string | null; postalCode: string | null;
  city: string | null; notes: string | null;
  /** N° d'abonné (télésurveillance, contrat…) */
  subscriberNumber?: string | null;
  /** Entreprise cliente : SIREN et n° de TVA (factures électroniques) */
  siren?: string | null; vatNumber?: string | null;
  /** Langue des documents envoyés au client ; vide = langue de la société */
  locale?: string | null;
}

export interface ClientDetail extends Client {
  contacts: { id: string; name: string; email: string | null; phone: string | null; role: string | null }[];
  sites: (Site & { equipments: Equipment[] })[];
  history: { id: string; number: string; kind: InterventionKind; status: InterventionStatus; reason: string; scheduledStart: string | null }[];
}

export interface Report {
  id: string; status: ReportStatus; templateSchema: TemplateSchema; data: ReportData;
  arrivedAt: string | null; leftAt: string | null; laborMinutes: number | null; travelMinutes: number | null;
  outcome: string | null; clientAbsent: boolean; clientSignerName: string | null; signedAt: string | null;
  sentAt: string | null; sentTo: string | null;
  /** Envoi demandé hors ligne : partira au retour du réseau */
  sendQueued?: boolean;
  /** Itinéos Vigie : points de passage pointés */
  checkpointScans?: CheckpointScan[];
}

export interface ReportPart { id?: string; label: string; reference: string | null; quantity: number; articleId?: string | null }

export interface ReportPhoto {
  id: string; clientId: string; kind: PhotoKind; caption: string | null; createdAt: string;
  /** Photo prise hors ligne, pas encore envoyée : image gardée sur l'appareil */
  localImage?: string;
}

export interface ReportBundle {
  intervention: InterventionRow;
  report: Report | null;
  parts: ReportPart[];
  canEdit: boolean;
  context: {
    company: { id: string; name: string; locale: string; timezone: string; currency: string };
    agency: { id: string; name: string; officeEmail?: string | null };
    client: Client;
    site: Site;
    equipment: Equipment | null;
    technician: { id: string; firstName: string; lastName: string } | null;
    /** Matériel du site difficile à trouver */
    siteHints?: { id: string; category: string; location: string | null; locateHint: string | null }[];
  };
  history: { number: string; kind: InterventionKind; outcome: string | null; date: string | null; summary: string }[];
  photos: ReportPhoto[];
  /** Itinéos Vigie : points de passage du site, à pointer pendant la ronde */
  checkpoints?: Checkpoint[];
  /** Itinéos Clés : état des lieux d'entrée, pour comparer pendant la sortie */
  checkin?: { number: string; signedAt: string | null; data: ReportData; schema: TemplateSchema } | null;
}

export interface Checkpoint { id: string; name: string; code: string; position: number }

/** Itinéos Expertise : rapport à rendre avant une date limite */
export interface DeadlineRow {
  id: string; number: string; reason: string; status: InterventionStatus; dueDate: string;
  clientName: string; technicianFirstName: string | null; technicianLastName: string | null;
}

/** Itinéos Services : une ligne du registre des traitements */
export interface TreatmentRow {
  interventionId: string; number: string; signedAt: string; clientName: string; siteName: string; siteCity: string | null;
  technicianFirstName: string | null; technicianLastName: string | null;
  pest: string; zones: string; biocides: string; baitStations: number | null; reentry: string;
}

export interface InvoiceRow {
  id: string; kind: InvoiceKind; status: InvoiceStatus; number: string | null; companyId: string; agencyId: string | null;
  clientId: string; title: string; issueDate: string | null; dueDate: string | null; currency: string;
  netCents: number; grossCents: number; sentAt: string | null; createdAt: string; clientName: string;
  settledCents: number; remainingCents: number; state: PaymentState;
}

export interface Payment { id: string; paidOn: string; amountCents: number; method: PaymentMethod; reference: string | null }

export interface InvoiceDetail extends Omit<InvoiceRow, 'clientName' | 'settledCents'> {
  siteId: string | null; notes: string | null; serviceDate: string | null; paymentTermsDays: number; vatCents: number;
  sentTo: string | null; sourceInterventionId: string | null; sourceQuoteId: string | null; contractId: string | null;
  creditedInvoiceId: string | null;
  lines: QuoteLine[]; client: Client; site: Site | null; payments: Payment[];
  creditNotes: { id: string; number: string | null; status: InvoiceStatus; grossCents: number }[];
  creditedInvoice: { id: string; number: string | null } | null;
  paidCents: number; creditedCents: number;
  /** Nature de l'opération (mention obligatoire) */
  operationType: OperationType;
  /** Facture électronique : ce qui manque, plateforme réglée, client entreprise, dépôt et son statut */
  einvoiceWarnings: string[]; einvoiceReady: boolean; einvoiceB2B: boolean;
  einvoiceFlowId: string | null; einvoiceStatus: string | null; einvoiceStatusLabel: string | null;
  einvoiceStatusAt: string | null; einvoiceError: string | null;
}

export type OperationType = 'SERVICES' | 'GOODS' | 'MIXED';

export interface Article {
  id: string; companyId: string; reference: string; name: string; category: string | null; unit: string;
  purchasePriceCents: number | null; salePriceCents: number | null; vatRateBp: number; active: boolean;
}

export interface StockLocation {
  id: string; companyId: string; agencyId: string | null; kind: StockLocationKind; name: string; technicianId: string | null;
  active: boolean; technicianFirstName: string | null; technicianLastName: string | null;
}

export interface StockLevel {
  locationId: string; articleId: string; quantity: number; minQuantity: number; reference: string; name: string; unit: string;
  category: string | null; salePriceCents: number | null; vatRateBp: number; locationName: string; locationKind: StockLocationKind; low?: boolean;
}

export interface StockMovement {
  id: string; kind: StockMovementKind; quantity: number; fromLocationId: string | null; toLocationId: string | null;
  note: string | null; createdAt: string; reference: string; name: string; unit: string;
  slipId: string | null; slipNumber: string | null; interventionId: string | null; interventionNumber: string | null;
}

export interface SlipRow {
  id: string; number: string | null; status: SlipStatus; fromLocationId: string; toLocationId: string | null;
  interventionId: string | null; createdAt: string; validatedAt: string | null; fromName: string; lineCount: number;
}

export interface SlipDetail extends Omit<SlipRow, 'fromName' | 'lineCount'> {
  companyId: string; notes: string | null;
  lines: { id: string; articleId: string; quantity: number; reference: string; name: string; unit: string }[];
  from: { id: string; name: string; kind: StockLocationKind };
  to: { id: string; name: string; kind: StockLocationKind } | null;
  intervention: { id: string; number: string; reason: string; clientName: string } | null;
}

export interface CertificationType { id: string; code: string; name: string; description: string | null; validityMonths: number | null; active: boolean }

export interface UserCertification {
  id: string; userId: string; typeId: string; obtainedOn: string | null; expiresOn: string | null; reference: string | null;
  hasDocument: boolean; state: DueState;
}

export interface CertificationMatrix {
  today: string;
  technicians: { id: string; firstName: string; lastName: string; agencyId: string | null; certifications: UserCertification[] }[];
}

export interface VehicleDeadline {
  id: string; vehicleId: string; kind: VehicleDeadlineKind; label: string | null; dueDate: string | null; dueMileage: number | null;
  intervalMonths: number | null; intervalKm: number | null; appointmentOn: string | null; appointmentWith: string | null;
  active: boolean; state: DueState;
}

export interface VehicleEvent {
  id: string; kind: VehicleEventKind; occurredOn: string; mileage: number | null; costCents: number | null;
  provider: string | null; description: string | null; deadlineId: string | null;
}

export interface VehicleRow {
  id: string; companyId: string; agencyId: string | null; plate: string; type: VehicleType; make: string | null; model: string | null;
  vin: string | null; fuel: string | null; firstRegistration: string | null; ownership: Ownership; lessor: string | null;
  status: VehicleStatus; mileage: number | null; mileageUpdatedOn: string | null; driverId: string | null;
  stockLocationId: string | null; notes: string | null;
  driverFirstName?: string | null; driverLastName?: string | null;
  worstState?: DueState; nextDue?: { kind: VehicleDeadlineKind; label: string | null; dueDate: string | null } | null;
}

export interface VehicleDetail extends VehicleRow {
  driver: { id: string; firstName: string; lastName: string } | null;
  /** Dernière position envoyée par le téléphone du conducteur */
  lastLat?: number | null; lastLng?: number | null; lastPositionAt?: string | null;
  stockLocation: { id: string; name: string } | null;
  today: string; costThisYear: number;
  deadlines: VehicleDeadline[]; events: VehicleEvent[];
}

export interface DeadlinesOverview {
  today: string;
  vehicles: { id: string; vehicleId: string; plate: string; make: string | null; model: string | null; kind: VehicleDeadlineKind; label: string | null;
    dueDate: string | null; dueMileage: number | null; mileage: number | null; appointmentOn: string | null; appointmentWith: string | null; state: DueState }[];
  certifications: { id: string; userId: string; firstName: string; lastName: string; typeCode: string; typeName: string; expiresOn: string; state: DueState }[];
}

export interface FormTemplate {
  id: string; groupId: string | null; companyId: string | null; name: string; kind: InterventionKind;
  version: number; schema: TemplateSchema; active: boolean; createdAt: string;
  /** system = modèle neutre Itinéos, group = commun au groupe, company = propre à la société */
  scope: 'system' | 'group' | 'company';
  /** Utilisé pour les nouvelles fiches de la société */
  inUse: boolean;
  /** Faux = document à choisir sur l'intervention (jamais pris d'office) */
  autoPick: boolean;
}

export interface DashboardRow {
  id: string; name: string; companyId: string; companyName: string; total: number; done: number;
  toPlan: number; toResume: number; urgentOpen: number; reports: number;
  firstTimeFixRate: number | null; avgHoursToSend: number | null;
}
