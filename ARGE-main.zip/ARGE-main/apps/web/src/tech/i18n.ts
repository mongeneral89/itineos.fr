/** Textes de l'appli terrain, selon la langue du compte (français et anglais ici, autres langues dans i18n.more.ts) */
import { applySectorWords, BRAND, productName, SECTOR_VOCABULARY, type PhotoKind } from '@itineo/shared';
import { getSector, langFromLocale } from '../i18n';
import { moreTechText } from './i18n.more';

const fr = {
  tabDay: 'Journée', more: 'Plus', hello: (name: string) => `Bonjour ${name}`, next: 'Prochaine intervention', later: 'Ensuite', progress: (n: number, total: number) => `${n}/${total} terminée${n > 1 ? 's' : ''}`, refresh: 'Actualiser',
  myDay: 'Ma journée', interventions: (n: number) => `${n} intervention${n > 1 ? 's' : ''}`,
  done: 'Terminées', inProgress: 'En cours', upcoming: 'À venir', nothing: 'Aucune intervention prévue ce jour.',
  office: 'Bureau', messages: 'Messagerie', directory: 'Annuaire', procedures: 'Notices', account: 'Mon compte', logout: 'Déconnexion', back: 'Retour', enRoute: 'Je pars', onSite: 'Je suis sur place',
  openReport: 'Ouvrir la fiche', client: 'Client', equipment: 'Équipement', history: 'Historique du matériel',
  noHistory: 'Aucune intervention précédente.', access: 'Accès',
  times: 'Horaires et temps passé', arrival: 'Arrivée', departure: 'Départ', labor: "Main-d'œuvre (min)", travel: 'Déplacement (min)',
  parts: 'Pièces et fournitures', addPart: 'Ajouter une pièce', partLabel: 'Désignation', reference: 'Référence', qty: 'Qté', remove: 'Retirer',
  outcome: "Résultat de l'intervention", saved: 'Enregistré', saving: 'Enregistrement…', offlineSaved: 'Hors ligne : gardé sur l’appareil',
  toSign: 'Passer aux signatures', signatures: 'Signatures', techSign: 'Signature du technicien', clientSign: 'Signature du client',
  signerName: 'Nom du signataire', clientAbsent: 'Client absent ou ne pouvant pas signer', absentReason: 'Motif',
  sign: 'Valider et signer', sendTitle: 'Envoyer la fiche', sendTo: 'Adresse e-mail du client', send: 'Générer le PDF et envoyer',
  archiveOnly: 'Archiver sans envoyer', sent: 'Fiche envoyée', sentTo: 'Envoyée à', viewPdf: 'Voir le PDF', backToDay: 'Retour à ma journée',
  readOnly: 'Cette fiche est signée : elle ne peut plus être modifiée.', missing: 'À compléter :', required: '* obligatoire',
  editFields: 'Modifier la fiche',
  photos: 'Photos', photoKinds: { BEFORE: 'Avant', AFTER: 'Après', OTHER: 'Autre' } as Record<PhotoKind, string>,
  photoCaption: 'Légende (facultatif)', photoUploading: 'Envoi…', photoRetry: 'Échec : réessayer',
  photoDeleteConfirm: 'Supprimer cette photo ?', photoLimit: (n: number) => `${n} photos au maximum par fiche`,
  partsFromVehicle: 'Tapez le nom ou la référence : les pièces de votre véhicule sont proposées et seront déduites de votre stock à la signature.',
  inVehicle: (q: number, unit: string) => `${q} ${unit} dans le véhicule`, fromStock: 'stock véhicule',
  clientSignRequired: 'Signature et nom du client obligatoires, ou cochez « client absent »',
  absentReasonRequired: "Indiquez pourquoi le client n'a pas pu signer",
  offline: 'Hors ligne', allSent: 'Tout est envoyé', syncing: 'Envoi en cours…',
  waiting: (n: number) => `${n} modification${n > 1 ? 's' : ''} en attente`,
  refused: (n: number) => `${n} modification${n > 1 ? 's' : ''} refusée${n > 1 ? 's' : ''} par le serveur`,
  discard: 'Abandonner', retry: 'Réessayer', offlineReady: (n: number, total: number) => `Disponible hors ligne : ${n}/${total} fiches`,
  syncNow: 'Synchroniser', syncDone: (time: string) => `Synchronisé à ${time}`, syncUpdated: (time: string) => `Mis à jour par le bureau à ${time}`, syncOfflineDone: 'Hors ligne : vos modifications partiront au retour du réseau',
  offlineNoData: "Pas de réseau, et cette page n'a pas encore été ouverte sur cet appareil.",
  shownOffline: 'Hors ligne : dernière version gardée sur l’appareil',
  savedOnDevice: 'Gardé sur l’appareil', signedOffline: 'Fiche signée. Elle sera transmise au retour du réseau.',
  sendQueued: (to: string) => `Envoi demandé${to ? ` à ${to}` : ''} : il partira automatiquement au retour du réseau.`,
  pdfLater: 'Le PDF sera disponible une fois la fiche transmise.', sendPending: 'Envoi en attente du réseau',
  logoutPending: (n: number) => `${n} modification${n > 1 ? 's' : ''} pas encore envoyée${n > 1 ? 's' : ''}. Elle${n > 1 ? 's' : ''} partir${n > 1 ? 'ont' : 'a'} à votre prochaine connexion sur cet appareil. Se déconnecter quand même ?`,
  locTitle: 'Partage de ma position',
  locInfo: (days: number) => `Pour organiser les dépannages, le bureau peut voir où se trouve votre véhicule pendant que l'appli est ouverte. Vous pouvez arrêter à tout moment. L'historique est effacé après ${days} jours.`,
  locEnable: 'Activer le partage', locLater: 'Plus tard', locOn: (plate: string) => `Position partagée · ${plate}`, locStop: 'Arrêter',
  locDenied: 'Le téléphone refuse la position : autorisez-la pour Itinéos dans les réglages du navigateur.',
  locUnavailable: 'Position indisponible pour le moment (GPS, intérieur…).',
};

export type TechTexts = typeof fr;
export type TechOutcomes = (typeof OUTCOMES)['fr'];

const en: TechTexts = {
  tabDay: 'Today', more: 'More', hello: (name: string) => `Hello ${name}`, next: 'Next job', later: 'Later', progress: (n: number, total: number) => `${n}/${total} done`, refresh: 'Refresh',
  myDay: 'My day', interventions: (n: number) => `${n} job${n > 1 ? 's' : ''}`,
  done: 'Done', inProgress: 'In progress', upcoming: 'Upcoming', nothing: 'No jobs scheduled today.',
  office: 'Office', messages: 'Messages', directory: 'Directory', procedures: 'Manuals', account: 'My account', logout: 'Log out', back: 'Back', enRoute: 'On my way', onSite: "I'm on site",
  openReport: 'Open report', client: 'Customer', equipment: 'Equipment', history: 'Equipment history',
  noHistory: 'No previous jobs.', access: 'Access',
  times: 'Times', arrival: 'Arrival', departure: 'Departure', labor: 'Labour (min)', travel: 'Travel (min)',
  parts: 'Parts and supplies', addPart: 'Add a part', partLabel: 'Description', reference: 'Reference', qty: 'Qty', remove: 'Remove',
  outcome: 'Job outcome', saved: 'Saved', saving: 'Saving…', offlineSaved: 'Offline: kept on this device',
  toSign: 'Go to signatures', signatures: 'Signatures', techSign: 'Technician signature', clientSign: 'Customer signature',
  signerName: 'Signer name', clientAbsent: 'Customer absent or unable to sign', absentReason: 'Reason',
  sign: 'Confirm and sign', sendTitle: 'Send the report', sendTo: 'Customer e-mail', send: 'Create PDF and send',
  archiveOnly: 'Archive without sending', sent: 'Report sent', sentTo: 'Sent to', viewPdf: 'View PDF', backToDay: 'Back to my day',
  readOnly: 'This report is signed and can no longer be changed.', missing: 'Still to fill in:', required: '* required',
  editFields: 'Edit report',
  photos: 'Photos', photoKinds: { BEFORE: 'Before', AFTER: 'After', OTHER: 'Other' },
  photoCaption: 'Caption (optional)', photoUploading: 'Uploading…', photoRetry: 'Failed: retry',
  photoDeleteConfirm: 'Delete this photo?', photoLimit: (n: number) => `${n} photos maximum per report`,
  partsFromVehicle: 'Type a name or reference: parts from your van are suggested and will be deducted from your stock when the report is signed.',
  inVehicle: (q: number, unit: string) => `${q} ${unit} in the van`, fromStock: 'van stock',
  clientSignRequired: 'Customer signature and name are required, or tick "customer absent"',
  absentReasonRequired: 'Say why the customer could not sign',
  offline: 'Offline', allSent: 'Everything sent', syncing: 'Sending…',
  waiting: (n: number) => `${n} change${n > 1 ? 's' : ''} waiting`,
  refused: (n: number) => `${n} change${n > 1 ? 's' : ''} refused by the server`,
  discard: 'Discard', retry: 'Retry', offlineReady: (n: number, total: number) => `Available offline: ${n}/${total} reports`,
  syncNow: 'Sync', syncDone: (time: string) => `Synced at ${time}`, syncUpdated: (time: string) => `Updated by the office at ${time}`, syncOfflineDone: 'Offline: your changes will be sent when the network is back',
  offlineNoData: 'No network, and this page has not been opened on this device yet.',
  shownOffline: 'Offline: last version kept on this device',
  savedOnDevice: 'Kept on this device', signedOffline: 'Report signed. It will be uploaded when the network is back.',
  sendQueued: (to: string) => `Sending requested${to ? ` to ${to}` : ''}: it will go out automatically when the network is back.`,
  pdfLater: 'The PDF will be available once the report is uploaded.', sendPending: 'Waiting for network to send',
  logoutPending: (n: number) => `${n} change${n > 1 ? 's' : ''} not sent yet. ${n > 1 ? 'They' : 'It'} will be sent next time you sign in on this device. Log out anyway?`,
  locTitle: 'Share my location',
  locInfo: (days: number) => `To organise call-outs, the office can see where your van is while the app is open. You can stop at any time. History is deleted after ${days} days.`,
  locEnable: 'Turn on sharing', locLater: 'Later', locOn: (plate: string) => `Location shared · ${plate}`, locStop: 'Stop',
  locDenied: 'The phone is blocking location: allow it for Itinéos in the browser settings.',
  locUnavailable: 'Location unavailable right now (GPS, indoors…).',
};

const OUTCOMES = {
  fr: { DONE: 'Terminé / réparé', TEMPORARY: 'Solution provisoire', TO_RESUME: 'À reprendre', WAITING_PARTS: 'En attente de pièces', QUOTE_NEEDED: 'Devis à établir' },
  en: { DONE: 'Completed / repaired', TEMPORARY: 'Temporary fix', TO_RESUME: 'Follow-up needed', WAITING_PARTS: 'Waiting for parts', QUOTE_NEEDED: 'Quote required' },
};

/**
 * Textes à l'image de l'édition : son nom (« Itinéos Vigie ») et, en français et en anglais,
 * le vocabulaire du métier (« mission », « agent »…).
 */
function forEdition<T extends object>(texts: T, lang: string): T {
  const sector = getSector();
  const vocab = SECTOR_VOCABULARY[sector];
  const name = productName(sector);
  const fix = (s: string) => {
    const named = s.replaceAll(BRAND, name);
    return vocab && (lang === 'fr' || lang === 'en') ? applySectorWords(named, vocab[lang], lang) : named;
  };
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(texts)) {
    out[k] = typeof v === 'string' ? fix(v)
      : typeof v === 'function' ? (...args: unknown[]) => fix((v as (...a: unknown[]) => string)(...args))
      : v;
  }
  return out as T;
}

export function techText(locale: string | undefined) {
  const lang = langFromLocale(locale ?? 'fr');
  const more = moreTechText(lang);
  if (more) return { ...more, t: forEdition(more.t, lang), lang };
  const base = lang === 'en' ? 'en' : 'fr';
  return { t: forEdition(base === 'en' ? en : fr, base), outcomes: OUTCOMES[base], lang };
}
