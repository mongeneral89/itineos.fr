/**
 * Appli terrain : planning de l'équipe, en lecture seule. Le bureau choisit quels collègues chaque technicien
 * voit (par défaut, seulement lui-même). Son propre nom est surligné.
 */
import { useMemo, useState } from 'react';
import { type InterventionKind, type InterventionStatus } from '@itineo/shared';
import { api, qs } from '../api';
import { useLoad } from '../hooks';
import { fmtTime } from '../format';
import { kindLabel, t, tl, uiLocale } from '../i18n';

interface TeamJob {
  id: string; number: string; technicianId: string; kind: InterventionKind; status: InterventionStatus; priority: string;
  start: string; end: string | null; clientName: string; city: string | null;
}
interface TeamData { mode: 'OWN' | 'AGENCY' | 'CUSTOM'; technicians: { id: string; firstName: string; lastName: string; me: boolean }[]; jobs: TeamJob[] }

const dayKey = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
function mondayOf(d: Date): Date {
  const m = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  m.setDate(m.getDate() - ((m.getDay() + 6) % 7));
  return m;
}

export function TeamPlanningPage() {
  const [monday, setMonday] = useState(() => mondayOf(new Date()));
  const [day, setDay] = useState(() => new Date());
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + i)), [monday]);
  const to = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + 7);
  const { data, error, loading } = useLoad(
    () => api<TeamData>(`/team-planning${qs({ from: monday.toISOString(), to: to.toISOString() })}`),
    [monday.getTime()],
  );
  const shift = (n: number) => {
    const m = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + 7 * n);
    setMonday(m);
    setDay(m);
  };
  const jobsOf = (techId: string, d: Date) => (data?.jobs ?? []).filter((j) => j.technicianId === techId && dayKey(new Date(j.start)) === dayKey(d));
  const fmtDay = (d: Date, opts: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat(uiLocale(), opts).format(d);
  const today = dayKey(new Date());

  return (
    <>
      {/* Titre et retour : dans la barre de l'appli terrain (FieldShell) */}
      <header className="day-hero team-hero">
        <div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
          <button type="button" className="secondary" style={{ color: '#F4F2EE', borderColor: '#3A4150' }} onClick={() => shift(-1)} aria-label={t('Semaine précédente')}>←</button>
          <span className="grow small" style={{ textAlign: 'center' }}>
            {t('Semaine du {date}', { date: fmtDay(monday, { day: 'numeric', month: 'long' }) })}
          </span>
          <button type="button" className="secondary" style={{ color: '#F4F2EE', borderColor: '#3A4150' }} onClick={() => shift(1)} aria-label={t('Semaine suivante')}>→</button>
        </div>
        <div className="team-days" role="tablist">
          {days.map((d) => (
            <button key={dayKey(d)} type="button" role="tab" aria-selected={dayKey(d) === dayKey(day)}
              className={`team-day${dayKey(d) === dayKey(day) ? ' on' : ''}${dayKey(d) === today ? ' today' : ''}`} onClick={() => setDay(d)}>
              <span className="small">{fmtDay(d, { weekday: 'short' })}</span>
              <strong>{d.getDate()}</strong>
            </button>
          ))}
        </div>
      </header>

        {error && <p className="error">{error}</p>}
        {loading && !data && <p className="muted">{t('Chargement…')}</p>}
        {data?.mode === 'OWN' && (
          <p className="muted small">{t('Le bureau ne vous a pas encore donné accès au planning de vos collègues : seul le vôtre est affiché.')}</p>
        )}
        <h2 style={{ fontSize: 17, textTransform: 'capitalize' }}>{fmtDay(day, { weekday: 'long', day: 'numeric', month: 'long' })}</h2>
        {data?.technicians.map((tech) => {
          const jobs = jobsOf(tech.id, day);
          return (
            <section key={tech.id} className={`card stack team-tech${tech.me ? ' me' : ''}`} style={{ gap: 6 }}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <strong>{tech.firstName} {tech.lastName}{tech.me ? ` (${t('vous')})` : ''}</strong>
                <span className="small muted">{jobs.length ? t('{n} intervention(s)', { n: jobs.length }) : t('Rien de prévu')}</span>
              </div>
              {jobs.map((j) => (
                <div key={j.id} className="team-job">
                  <span className="team-time">{fmtTime(j.start)}{j.end ? `–${fmtTime(j.end)}` : ''}</span>
                  <span className="grow">
                    <strong>{j.clientName}</strong>{j.city ? ` · ${j.city}` : ''}
                    <span className="small muted"> · {kindLabel(j.kind)}{j.priority === 'URGENT' ? ` · ${t('Urgent')}` : ''}</span>
                  </span>
                </div>
              ))}
            </section>
          );
        })}
    </>
  );
}
