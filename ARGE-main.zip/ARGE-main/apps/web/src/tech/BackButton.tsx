/**
 * Retour d'Android (geste depuis le bord ou bouton) dans l'appli : il ne quitte plus l'appli.
 *  - un écran ouvert dans une page (nouvelle conversation, signatures…) se referme d'abord (useBackHandler) ;
 *  - une conversation, une fiche, une sous-page de « Plus » : retour à l'écran parent ;
 *  - un autre onglet : retour à « Ma journée » ;
 *  - « Ma journée » ou la connexion : l'appli passe en arrière-plan (comme le bouton d'accueil), sans se fermer.
 */
import { useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
import { isNativeApp } from '../native';

type Handler = () => void;
const handlers: Handler[] = [];

/** Tant que `active`, le retour d'Android appelle `onBack` au lieu de changer de page */
export function useBackHandler(active: boolean, onBack: Handler) {
  const ref = useRef(onBack);
  ref.current = onBack;
  useEffect(() => {
    if (!active) return;
    const h: Handler = () => ref.current();
    handlers.push(h);
    return () => {
      const i = handlers.lastIndexOf(h);
      if (i >= 0) handlers.splice(i, 1);
    };
  }, [active]);
}

const TABS = ['/messages', '/directory', '/procedures', '/tech/more'];
const UNDER_MORE = ['/tech/team', '/account'];

/** Où mène le retour depuis cette adresse ; null : mettre l'appli en arrière-plan ; 'history' : page précédente */
export function backTarget(pathname: string, search: string, loggedIn: boolean): string | null | 'history' {
  if (!loggedIn || pathname === '/tech' || pathname === '/') return null;
  if (pathname === '/messages' && new URLSearchParams(search).has('c')) return '/messages';
  if (TABS.includes(pathname)) return '/tech';
  if (UNDER_MORE.includes(pathname)) return '/tech/more';
  if (pathname.startsWith('/tech/')) return '/tech';
  return 'history';
}

/** À placer une fois sous le routeur */
export function AndroidBackButton() {
  const loggedIn = !!useAuth().me;
  const navigate = useNavigate();
  const location = useLocation();
  const where = useRef({ location, loggedIn });
  where.current = { location, loggedIn };

  useEffect(() => {
    if (!isNativeApp()) return;
    let stop = false;
    let remove: (() => void) | undefined;
    void import('@capacitor/app').then(async ({ App }) => {
      const handle = await App.addListener('backButton', ({ canGoBack }) => {
        const top = handlers[handlers.length - 1];
        if (top) return top();
        const { location: l, loggedIn: on } = where.current;
        const target = backTarget(l.pathname, l.search, on);
        if (target === null) void App.minimizeApp();
        else if (target === 'history') {
          if (canGoBack) window.history.back();
          else navigate('/', { replace: true });
        } else navigate(target, { replace: true });
      });
      if (stop) void handle.remove();
      else remove = () => void handle.remove();
    });
    return () => {
      stop = true;
      remove?.();
    };
  }, [navigate]);

  return null;
}
