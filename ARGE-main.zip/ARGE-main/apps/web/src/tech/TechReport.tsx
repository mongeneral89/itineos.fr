import { t as tr } from '../i18n';
import { GoButton } from '../components/GoButton';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { missingRequiredFields, OUTCOMES, type CheckpointScan, type Outcome, type ReportData } from '@itineo/shared';
import { ApiError, openReportPdf } from '../api';
import { useAuth } from '../auth';
import type { Checkpoint, ReportBundle, ReportPart } from '../types';
import { ScanButton } from '../components/ScanButton';
import { FormRenderer } from '../components/FormRenderer';
import { SignaturePad, type SignaturePadHandle } from '../components/SignaturePad';
import { fmtDate, fmtTime, toDateTimeInput } from '../format';
import {
  getCachedReport, loadMyVehicle, loadReport, NOT_AVAILABLE_OFFLINE, onReportChange, saveReport, sendReport, signReport,
  type MyVehicle, type ReportPayload,
} from '../offline/field';
import { useSync } from '../offline/sync';
import { techText } from './i18n';
import { PhotosSection } from './PhotosSection';
import { SyncStatus } from './SyncStatus';
import { useLocationSharing } from './location';
import { SosButton } from './SosButton';
import { hasFeature } from '../edition';
import { useBackHandler } from './BackButton';

type Step = 'fill' | 'sign' | 'send' | 'done';
type T = ReturnType<typeof techText>['t'];

interface Draft {
  data: ReportData;
  parts: ReportPart[];
  arrivedAt: string;
  leftAt: string;
  laborMinutes: string;
  travelMinutes: string;
  outcome: Outcome | '';
  checkpointScans: CheckpointScan[];
}

/** Ancienne sauvegarde locale (avant la file d'attente) : reprise une dernière fois si elle existe */
const legacyDraftKey = (id: string) => `itineo.draft.${id}`;

function fromBundle(b: ReportBundle): Draft {
  const r = b.report!;
  return {
    data: r.data,
    parts: b.parts.map((p) => ({ label: p.label, reference: p.reference, quantity: p.quantity, articleId: p.articleId ?? null })),
    arrivedAt: toDateTimeInput(r.arrivedAt),
    leftAt: toDateTimeInput(r.leftAt),
    laborMinutes: r.laborMinutes?.toString() ?? '',
    travelMinutes: r.travelMinutes?.toString() ?? '',
    outcome: (r.outcome as Outcome) ?? '',
    checkpointScans: r.checkpointScans ?? [],
  };
}

function toPayload(d: Draft): ReportPayload {
  const num = (s: string) => (s.trim() === '' ? null : Math.max(0, Math.round(Number(s))));
  return {
    data: d.data,
    parts: d.parts.filter((p) => p.label.trim()),
    arrivedAt: d.arrivedAt ? new Date(d.arrivedAt).toISOString() : null,
    leftAt: d.leftAt ? new Date(d.leftAt).toISOString() : null,
    laborMinutes: num(d.laborMinutes),
    travelMinutes: num(d.travelMinutes),
    outcome: d.outcome || null,
    checkpointScans: d.checkpointScans,
  };
}

/**
 * Saisie du nom d'une pièce : si le texte correspond à un article du véhicule (choisi dans la liste),
 * la pièce est reliée au stock ; si le technicien modifie le nom ensuite, elle redevient une pièce libre.
 */
function pickPart(part: ReportPart, text: string, vehicle: MyVehicle | null): ReportPart {
  const art = vehicle?.levels.find((l) => `${l.reference} – ${l.name}` === text);
  if (art) return { ...part, label: art.name, reference: art.reference, articleId: art.articleId };
  return { ...part, label: text, ...(part.articleId ? { articleId: null, reference: '' } : {}) };
}

const stepOf = (b: ReportBundle): Step =>
  b.report?.status === 'SENT' ? 'done' : b.report?.status === 'SIGNED' ? 'send' : 'fill';

export function TechReportPage() {
  const { id = '' } = useParams();
  const { me } = useAuth();
  const { t, outcomes } = techText(me?.user.locale);
  const sync = useSync();
  // Le partage de position continue pendant que la fiche est ouverte
  useLocationSharing();

  const [bundle, setBundle] = useState<ReportBundle | null>(null);
  const [fromCache, setFromCache] = useState(false);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [step, setStep] = useState<Step>('fill');
  // Appli Android : depuis les signatures, le retour revient à la fiche (pas à la journée)
  useBackHandler(step === 'sign', () => setStep('fill'));
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'device'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [missing, setMissing] = useState<string[]>([]);
  const [vehicle, setVehicle] = useState<MyVehicle | null>(null);
  const dirty = useRef(false);

  // Stock du véhicule (copie de l'appareil sans réseau) pour choisir les pièces posées
  useEffect(() => {
    void loadMyVehicle().then(setVehicle);
  }, []);

  // Chargement : serveur, ou copie de l'appareil sans réseau
  useEffect(() => {
    let cancelled = false;
    loadReport(id)
      .then(({ bundle: b, fromCache: cached }) => {
        if (cancelled) return;
        setBundle(b);
        setFromCache(cached);
        if (!b.report) return;
        let d = fromBundle(b);
        if (b.report.status === 'DRAFT') {
          try {
            const legacy = localStorage.getItem(legacyDraftKey(id));
            if (legacy) {
              d = { ...d, ...(JSON.parse(legacy) as Draft) };
              dirty.current = true;
              localStorage.removeItem(legacyDraftKey(id));
            }
          } catch {
            /* rien à reprendre */
          }
        }
        setDraft(d);
        setStep(stepOf(b));
      })
      .catch((e) => !cancelled && setError(e === NOT_AVAILABLE_OFFLINE ? t.offlineNoData : (e as Error).message));
    return () => {
      cancelled = true;
    };
  }, [id, t.offlineNoData]);

  // Copie locale modifiée (photo ajoutée, envoi terminé…) : on rafraîchit l'affichage, pas la saisie
  useEffect(() => onReportChange((changed) => {
    if (changed !== id) return;
    void getCachedReport(id).then((b) => b && setBundle(b));
  }), [id]);

  // Tout ce qui attendait pour cette fiche est parti : on reprend la version du serveur
  const waiting = sync.byIntervention[id] ?? 0;
  const prevWaiting = useRef(waiting);
  useEffect(() => {
    if (prevWaiting.current > 0 && waiting === 0) {
      void loadReport(id).then(({ bundle: b, fromCache: cached }) => {
        setBundle(b);
        setFromCache(cached);
      }).catch(() => undefined);
    }
    prevWaiting.current = waiting;
  }, [waiting, id]);

  const save = useCallback(async (d: Draft) => {
    setSaveState('saving');
    try {
      const where = await saveReport(id, toPayload(d));
      dirty.current = false;
      setSaveState(where === 'synced' ? 'saved' : 'device');
      return true;
    } catch (e) {
      setSaveState('idle');
      setError((e as Error).message);
      return false;
    }
  }, [id]);

  // Enregistrement automatique 1,2 s après la dernière modification
  useEffect(() => {
    if (!draft || !dirty.current || step !== 'fill' || !bundle?.canEdit) return;
    const timer = setTimeout(() => void save(draft), 1200);
    return () => clearTimeout(timer);
  }, [draft, save, step, bundle?.canEdit]);

  const update = (patch: Partial<Draft>) => {
    dirty.current = true;
    setDraft((d) => (d ? { ...d, ...patch } : d));
  };

  if (error && !bundle) return <div className="tech"><div className="tech-body"><p className="error">{error}</p><Link to="/tech">{t.back}</Link></div></div>;
  if (!bundle) return <div className="tech"><div className="tech-body"><p className="muted">…</p></div></div>;

  const { context: ctx, intervention: iv } = bundle;
  const formLang = ctx.company.locale;
  const editable = bundle.canEdit && step === 'fill';

  const goToSign = async () => {
    if (!draft || !bundle.report) return;
    // Vérifié sur l'appareil : on peut faire signer sans réseau
    const m = missingRequiredFields(bundle.report.templateSchema, draft.data);
    if (!draft.outcome) m.push(t.outcome);
    setMissing(m);
    if (m.length) return;
    if (await save(draft)) setStep('sign');
  };

  return (
    <div className="tech">
      <header className="tech-header">
        <div className="row">
          <Link to="/tech" className="btn secondary" style={{ color: '#F4F2EE', borderColor: '#3A4150', minHeight: 36 }}>← {t.back}</Link>
          <span className="small" style={{ opacity: 0.8 }}>
            {saveState === 'saving' ? t.saving : saveState === 'saved' ? t.saved : saveState === 'device' ? t.savedOnDevice : ''}
          </span>
        </div>
        <SyncStatus t={t} />
        <div className="small" style={{ opacity: 0.75, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{iv.number}</div>
        <h1 style={{ fontSize: 24 }}>{ctx.client.name}</h1>
        <div className="small" style={{ opacity: 0.85 }}>{iv.reason}</div>
      </header>

      <div className="tech-body">
        {error && <p className="error" role="alert">{error}</p>}
        {fromCache && <p className="muted small">{t.shownOffline}</p>}
        {hasFeature('sos') && step === 'fill' && <SosButton interventionId={id} />}

        {step === 'fill' && (
          <>
            <ContextCards bundle={bundle} t={t} />
            {!bundle.report && <p className="muted">{t.readOnly}</p>}
            {bundle.report && draft && (
              <>
                {!bundle.canEdit && <p className="muted">{t.readOnly}</p>}
                <FormRenderer
                  schema={bundle.report.templateSchema}
                  data={draft.data}
                  readOnly={!editable}
                  lang={formLang}
                  onChange={(fid, v) => update({ data: { ...draft.data, [fid]: v } })}
                  previous={bundle.checkin?.data}
                  previousLabel={tr('À l’entrée')}
                />

                {iv.kind === 'MAINTENANCE' && !!bundle.checkpoints?.length && (
                  <CheckpointsSection checkpoints={bundle.checkpoints} scans={draft.checkpointScans} editable={editable}
                    timezone={ctx.company.timezone} onScan={(scan) => update({ checkpointScans: [...draft.checkpointScans, scan] })} />
                )}

                <PhotosSection interventionId={id} photos={bundle.photos} editable={editable} t={t} />

                <section className="card stack">
                  <h2>{t.times}</h2>
                  <div className="row">
                    <div className="field grow"><label htmlFor="arr">{t.arrival}</label><input id="arr" type="datetime-local" value={draft.arrivedAt} disabled={!editable} onChange={(e) => update({ arrivedAt: e.target.value })} /></div>
                    <div className="field grow"><label htmlFor="dep">{t.departure}</label><input id="dep" type="datetime-local" value={draft.leftAt} disabled={!editable} onChange={(e) => update({ leftAt: e.target.value })} /></div>
                  </div>
                  <div className="row">
                    <div className="field grow"><label htmlFor="lab">{t.labor}</label><input id="lab" type="number" min="0" inputMode="numeric" value={draft.laborMinutes} disabled={!editable} onChange={(e) => update({ laborMinutes: e.target.value })} /></div>
                    <div className="field grow"><label htmlFor="trv">{t.travel}</label><input id="trv" type="number" min="0" inputMode="numeric" value={draft.travelMinutes} disabled={!editable} onChange={(e) => update({ travelMinutes: e.target.value })} /></div>
                  </div>
                </section>

                <section className="card stack">
                  <h2>{t.parts}</h2>
                  {vehicle?.levels.length ? <p className="small muted" style={{ margin: 0 }}>{t.partsFromVehicle}</p> : null}
                  <datalist id="vehicle-articles">
                    {vehicle?.levels.map((l) => <option key={l.articleId} value={`${l.reference} – ${l.name}`}>{t.inVehicle(l.quantity, l.unit)}</option>)}
                  </datalist>
                  {draft.parts.map((p, idx) => (
                    <div key={idx} className="row" style={{ alignItems: 'flex-end' }}>
                      {/* Au moins 200 px : sur un téléphone, référence et quantité passent à la ligne au lieu d'écraser la désignation */}
                      <div className="field grow" style={{ minWidth: 200 }}><label htmlFor={`pl-${idx}`}>{t.partLabel}{p.articleId && <span className="badge ok" style={{ marginLeft: 6 }}>{t.fromStock}</span>}</label>
                        <input id={`pl-${idx}`} value={p.label} disabled={!editable} list="vehicle-articles" autoComplete="off"
                          onChange={(e) => update({ parts: draft.parts.map((x, k) => (k === idx ? pickPart(x, e.target.value, vehicle) : x)) })} /></div>
                      <div className="field" style={{ width: 150 }}><label htmlFor={`pr-${idx}`}>{t.reference}</label><input id={`pr-${idx}`} value={p.reference ?? ''} disabled={!editable || !!p.articleId}
                        onChange={(e) => update({ parts: draft.parts.map((x, k) => (k === idx ? { ...x, reference: e.target.value } : x)) })} /></div>
                      <div className="field" style={{ width: 80 }}><label htmlFor={`pq-${idx}`}>{t.qty}</label><input id={`pq-${idx}`} type="number" min="0.01" step="any" value={p.quantity} disabled={!editable}
                        onChange={(e) => update({ parts: draft.parts.map((x, k) => (k === idx ? { ...x, quantity: Number(e.target.value) || 1 } : x)) })} /></div>
                      {editable && <button type="button" className="ghost" onClick={() => update({ parts: draft.parts.filter((_, k) => k !== idx) })}>{t.remove}</button>}
                    </div>
                  ))}
                  {editable && <button type="button" className="secondary" onClick={() => update({ parts: [...draft.parts, { label: '', reference: '', quantity: 1 }] })}>{t.addPart}</button>}
                </section>

                <section className="card stack">
                  <h2>{t.outcome} *</h2>
                  <div className="chips" role="radiogroup" aria-label={t.outcome}>
                    {OUTCOMES.map((o) => (
                      <button key={o} type="button" role="radio" aria-checked={draft.outcome === o} disabled={!editable}
                        className={`chip${draft.outcome === o ? ' on' : ''}`} onClick={() => update({ outcome: o })}>
                        {outcomes[o]}
                      </button>
                    ))}
                  </div>
                </section>

                {missing.length > 0 && (
                  <div className="card" role="alert" style={{ borderLeft: 'none', background: 'var(--warn-bg)', color: 'var(--warn-fg)' }}>
                    <strong>{t.missing}</strong> {missing.join(' · ')}
                  </div>
                )}

                {editable && (
                  <div className="sticky-actions">
                    <button type="button" className="big accent" onClick={() => void goToSign()}>
                      {t.toSign}
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}

        {step === 'sign' && draft && (
          <SignStep
            id={id}
            t={t}
            onBack={() => setStep('fill')}
            onSigned={() => setStep('send')}
            onMissing={(m) => { setMissing(m); setStep('fill'); }}
          />
        )}

        {step === 'send' && (
          <>
            {bundle.report?.status === 'SIGNED' && waiting > 0 && <p className="muted small">{t.signedOffline}</p>}
            <SendStep id={id} t={t} defaultEmail={ctx.client.email ?? ''} officeEmail={ctx.agency.officeEmail ?? null} onSent={async () => {
              const b = await getCachedReport(id);
              if (b) setBundle(b);
              setStep('done');
            }} />
          </>
        )}

        {step === 'done' && (
          <section className="card stack">
            <h2>{bundle.report?.sendQueued ? t.sendPending : t.sent}</h2>
            {bundle.report?.sendQueued
              ? <p>{t.sendQueued(bundle.report.sentTo ?? '')}</p>
              : bundle.report?.sentTo && <p>{t.sentTo} : {bundle.report.sentTo}</p>}
            <div className="row">
              {bundle.report?.sendQueued
                ? <span className="muted small">{t.pdfLater}</span>
                : <button type="button" className="secondary" onClick={() => openReportPdf(id).catch((e) => setError(e.message))}>{t.viewPdf}</button>}
              <Link className="btn" to="/tech">{t.backToDay}</Link>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function ContextCards({ bundle, t }: { bundle: ReportBundle; t: T }) {
  const { context: ctx, history } = bundle;
  return (
    <div className="grid">
      <section className="card stack" style={{ gap: 4 }}>
        <span className="section-title">{t.client}</span>
        <strong>{ctx.client.name}</strong>
        <span className="small">{[ctx.site.address, ctx.site.postalCode, ctx.site.city].filter(Boolean).join(', ')}</span>
        {ctx.client.phone && <a className="small" href={`tel:${ctx.client.phone}`}>{ctx.client.phone}</a>}
        {ctx.site.accessNotes && <span className="small">{t.access} : {ctx.site.accessNotes}</span>}
        <GoButton address={[ctx.site.address, ctx.site.postalCode, ctx.site.city].filter(Boolean).join(' ')} lat={ctx.site.latitude} lng={ctx.site.longitude} />
        {(ctx.siteHints ?? []).filter((h) => h.id !== ctx.equipment?.id).map((h) => (
          <span key={h.id} className="small locate-hint">⚠ {h.category}{h.location ? ` (${h.location})` : ''} : {h.locateHint}</span>
        ))}
      </section>
      {ctx.equipment && (
        <section className="card stack" style={{ gap: 4 }}>
          <span className="section-title">{t.equipment}</span>
          <strong>{ctx.equipment.category}</strong>
          <span className="small">{[ctx.equipment.brand, ctx.equipment.model].filter(Boolean).join(' ')}</span>
          <span className="small">{[ctx.equipment.serialNumber, ctx.equipment.location].filter(Boolean).join(' · ')}</span>
          {ctx.equipment.locateHint && <span className="small locate-hint">⚠ {ctx.equipment.locateHint}</span>}
        </section>
      )}
      <section className="card dark stack" style={{ gap: 6 }}>
        <span className="section-title" style={{ color: '#C9CCD2' }}>{t.history}</span>
        {history.length ? history.map((h) => (
          <div key={h.number} style={{ borderTop: '1px solid #2E3541', paddingTop: 6 }}>
            <div className="small" style={{ color: '#C9CCD2' }}>{fmtDate(h.date, ctx.company.timezone)} · {h.number}</div>
            <div className="small">{h.summary}</div>
          </div>
        )) : <span className="small" style={{ color: '#C9CCD2' }}>{t.noHistory}</span>}
      </section>
    </div>
  );
}

/**
 * Itinéos Vigie : la ronde. L'agent scanne le QR code collé à chaque point de passage ; l'heure est celle
 * du téléphone (pointage possible sans réseau, envoyé avec la fiche).
 */
function CheckpointsSection({ checkpoints, scans, editable, timezone, onScan }: {
  checkpoints: Checkpoint[];
  scans: CheckpointScan[];
  editable: boolean;
  timezone: string;
  onScan: (scan: CheckpointScan) => void;
}) {
  const [message, setMessage] = useState<{ text: string; ok: boolean } | null>(null);
  const done = checkpoints.filter((cp) => scans.some((s) => s.checkpointId === cp.id)).length;
  const scanned = (code: string) => {
    const cp = checkpoints.find((c) => c.code === code.trim());
    if (!cp) return setMessage({ text: tr('Ce QR code n’est pas un point de passage de ce site.'), ok: false });
    const already = scans.find((s) => s.checkpointId === cp.id);
    if (already) return setMessage({ text: tr('{name} : déjà pointé à {time}', { name: cp.name, time: fmtTime(already.at, timezone) }), ok: false });
    const at = new Date().toISOString();
    onScan({ checkpointId: cp.id, name: cp.name, at });
    setMessage({ text: tr('{name} : pointé à {time}', { name: cp.name, time: fmtTime(at, timezone) }), ok: true });
  };
  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2>{tr('Points de passage')}</h2>
        <span className={`badge ${done === checkpoints.length ? 'ok' : 'neutral'}`}>{done} / {checkpoints.length}</span>
      </div>
      <div>
        {checkpoints.map((cp) => {
          const scan = scans.find((s) => s.checkpointId === cp.id);
          return (
            <div key={cp.id} className={`checkpoint${scan ? ' done' : ''}`}>
              <strong>{cp.name}</strong>
              <span className="small muted">{scan ? fmtTime(scan.at, timezone) : tr('À pointer')}</span>
            </div>
          );
        })}
      </div>
      {message && <p className={message.ok ? 'success' : 'error'} role="status">{message.text}</p>}
      {editable && done < checkpoints.length && <ScanButton wide label={tr('Pointer un point de passage')} onResult={scanned} />}
    </section>
  );
}

function SignStep({ id, t, onBack, onSigned, onMissing }: {
  id: string;
  t: T;
  onBack: () => void;
  onSigned: () => void;
  onMissing: (fields: string[]) => void;
}) {
  const techPad = useRef<SignaturePadHandle>(null);
  const clientPad = useRef<SignaturePadHandle>(null);
  const [absent, setAbsent] = useState(false);
  const [name, setName] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(null);
    const technicianSignature = techPad.current?.toDataURL();
    const clientSignature = absent ? undefined : clientPad.current?.toDataURL() ?? undefined;
    // Contrôles faits sur l'appareil : la signature fonctionne aussi sans réseau
    if (!technicianSignature) return setError(t.techSign);
    if (!absent && (!clientSignature || !name.trim())) return setError(t.clientSignRequired);
    if (absent && !reason.trim()) return setError(t.absentReasonRequired);
    setBusy(true);
    try {
      await signReport(id, { technicianSignature, clientAbsent: absent, clientSignature, clientSignerName: name, clientAbsentReason: reason });
      onSigned();
    } catch (e) {
      const err = e as ApiError;
      const fields = (err.details as { missing?: string[] } | undefined)?.missing;
      if (fields?.length) onMissing(fields);
      else setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card stack">
      <h2>{t.signatures}</h2>
      <SignaturePad ref={techPad} label={t.techSign} />
      <label className="check">
        <input type="checkbox" checked={absent} onChange={(e) => setAbsent(e.target.checked)} />
        {t.clientAbsent}
      </label>
      {absent ? (
        <div className="field"><label htmlFor="absent-reason">{t.absentReason}</label><input id="absent-reason" value={reason} onChange={(e) => setReason(e.target.value)} /></div>
      ) : (
        <>
          <div className="field"><label htmlFor="signer">{t.signerName}</label><input id="signer" value={name} onChange={(e) => setName(e.target.value)} autoComplete="off" /></div>
          <SignaturePad ref={clientPad} label={t.clientSign} />
        </>
      )}
      {error && <p className="error" role="alert">{error}</p>}
      <div className="row">
        <button type="button" className="secondary" onClick={onBack}>{t.editFields}</button>
        <button type="button" className="accent grow" disabled={busy} onClick={submit}>{t.sign}</button>
      </div>
    </section>
  );
}

function SendStep({ id, t, defaultEmail, officeEmail, onSent }: {
  id: string;
  t: T;
  defaultEmail: string;
  officeEmail: string | null;
  onSent: () => void;
}) {
  const [email, setEmail] = useState(defaultEmail);
  // Copie au bureau : le dernier choix est retenu sur l'appareil
  const [copyOffice, setCopyOffice] = useState(() => {
    try {
      return localStorage.getItem('itineo.copyOffice') === '1';
    } catch {
      return false;
    }
  });
  const toggleCopy = (v: boolean) => {
    setCopyOffice(v);
    try {
      localStorage.setItem('itineo.copyOffice', v ? '1' : '0');
    } catch {
      /* choix non retenu */
    }
  };
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const send = async (sendEmail: boolean) => {
    setBusy(true);
    setError(null);
    try {
      const to = email.split(/[;,\s]+/).filter(Boolean);
      await sendReport(id, sendEmail ? { to, sendEmail: true, copyOffice: copyOffice && !!officeEmail } : { sendEmail: false });
      onSent();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card stack">
      <h2>{t.sendTitle}</h2>
      <div className="field"><label htmlFor="send-to">{t.sendTo}</label><input id="send-to" type="email" multiple value={email} onChange={(e) => setEmail(e.target.value)} /></div>
      {officeEmail && (
        <label className="check"><input type="checkbox" checked={copyOffice} onChange={(e) => toggleCopy(e.target.checked)} />{tr('Copie au bureau ({email})', { email: officeEmail })}</label>
      )}
      <p className="small muted">{tr('Vous recevez une copie ; si le client répond, sa réponse vous arrive directement.')}</p>
      {error && <p className="error" role="alert">{error}</p>}
      <button type="button" className="big accent" disabled={busy || !email.trim()} onClick={() => send(true)}>{t.send}</button>
      <button type="button" className="secondary" disabled={busy} onClick={() => send(false)}>{t.archiveOnly}</button>
    </section>
  );
}
