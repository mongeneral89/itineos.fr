/**
 * Partage de position du technicien (appli terrain).
 *
 * Seulement s'il l'a activé lui-même, et seulement pendant que l'appli est ouverte (un site web ne peut pas
 * suivre le téléphone en arrière-plan). Une position est retenue quand le véhicule a bougé de plus de 150 m
 * ou toutes les 3 minutes, plus une à chaque « Je pars » / « Je suis sur place ». Sans réseau, elles attendent
 * sur l'appareil (200 au plus) et partent au retour du réseau.
 */
import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../api';
import { currentUserId } from '../offline/sync';

const PENDING_KEY = 'itineo.positions.pending';
const ENABLED_KEY = 'itineo.location.enabled';
const MIN_MOVE_M = 150;
const MAX_GAP_MS = 3 * 60_000;
const MAX_PENDING = 200;

/** userId : la personne connectée quand la position a été prise (tablette partagée : chacun n'envoie que les siennes) */
interface Pending { userId?: string; lat: number; lng: number; accuracy: number | null; recordedAt: string; event: 'TRACK' | 'EN_ROUTE' | 'ON_SITE'; interventionId?: string | null }

let watchId: number | null = null;
let flushTimer: ReturnType<typeof setInterval> | null = null;
let current: GeolocationPosition | null = null;
let lastKept: { lat: number; lng: number; at: number } | null = null;
let flushing = false;
const errorListeners = new Set<(e: 'denied' | 'unavailable' | null) => void>();

function readPending(): Pending[] {
  try {
    return JSON.parse(localStorage.getItem(PENDING_KEY) ?? '[]') as Pending[];
  } catch {
    return [];
  }
}
function writePending(list: Pending[]) {
  try {
    localStorage.setItem(PENDING_KEY, JSON.stringify(list.slice(-MAX_PENDING)));
  } catch {
    /* stockage plein ou indisponible : la position est perdue, ce n'est pas grave */
  }
}
function cachedEnabled(): boolean {
  try {
    return localStorage.getItem(`${ENABLED_KEY}.${currentUserId()}`) === '1';
  } catch {
    return false;
  }
}
function setCachedEnabled(on: boolean) {
  try {
    // Par compte : sur un téléphone partagé, le choix d'un collègue ne vaut pas pour les autres
    if (on) localStorage.setItem(`${ENABLED_KEY}.${currentUserId()}`, '1');
    else localStorage.removeItem(`${ENABLED_KEY}.${currentUserId()}`);
  } catch {
    /* ignoré */
  }
}

/** Distance en mètres entre deux points (formule de haversine) */
export function distanceM(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const r = 6_371_000;
  const rad = (d: number) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * r * Math.asin(Math.sqrt(h));
}

function queue(pos: GeolocationPosition, event: Pending['event'], interventionId?: string | null) {
  const userId = currentUserId();
  if (!userId) return;
  const p: Pending = {
    userId,
    lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: Math.round(pos.coords.accuracy),
    recordedAt: new Date(pos.timestamp).toISOString(), event, interventionId: interventionId ?? null,
  };
  writePending([...readPending(), p]);
  lastKept = { lat: p.lat, lng: p.lng, at: pos.timestamp };
}

function onPosition(pos: GeolocationPosition) {
  current = pos;
  errorListeners.forEach((l) => l(null));
  const here = { lat: pos.coords.latitude, lng: pos.coords.longitude };
  if (!lastKept || distanceM(lastKept, here) >= MIN_MOVE_M || pos.timestamp - lastKept.at >= MAX_GAP_MS) {
    queue(pos, 'TRACK');
    void flushPositions();
  }
}

/** Une position en attente (relue depuis le stockage : comparée par son contenu) */
const pendingKey = (p: Pending) => `${p.userId}|${p.recordedAt}|${p.event}|${p.lat}|${p.lng}`;

/** Envoie les positions en attente ; garde celles qui n'ont pas pu partir */
export async function flushPositions(): Promise<void> {
  const userId = currentUserId();
  if (flushing || !navigator.onLine || !userId) return;
  // Seulement les positions de la personne connectée : celles d'un collègue (même téléphone) attendent son retour.
  const pending = readPending().filter((p) => p.userId === userId);
  if (!pending.length) return;
  const sent = new Set(pending.map(pendingKey));
  flushing = true;
  // Sans auteur (avant cette règle) : on ne sait pas à qui elles sont, elles sont abandonnées
  const keepOthers = () => writePending(readPending().filter((p) => p.userId && (p.userId !== userId || !sent.has(pendingKey(p)))));
  try {
    await api('/fleet/positions', { method: 'POST', body: { positions: pending.map(({ userId: _u, ...p }) => p) } });
    // D'autres positions ont pu arriver pendant l'envoi : on ne retire que celles envoyées
    keepOthers();
  } catch (e) {
    // Partage arrêté entre-temps (ou depuis un autre appareil) : on n'envoie plus les siennes
    if (e instanceof ApiError && (e.status === 409 || e.status === 400)) keepOthers();
  } finally {
    flushing = false;
  }
}

export function startTracking() {
  if (watchId !== null || !('geolocation' in navigator)) return;
  watchId = navigator.geolocation.watchPosition(onPosition, (err) => {
    errorListeners.forEach((l) => l(err.code === err.PERMISSION_DENIED ? 'denied' : 'unavailable'));
  }, { enableHighAccuracy: true, maximumAge: 30_000, timeout: 60_000 });
  flushTimer = setInterval(() => void flushPositions(), 60_000);
  window.addEventListener('online', onOnline);
}

export function stopTracking() {
  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  watchId = null;
  if (flushTimer) clearInterval(flushTimer);
  flushTimer = null;
  window.removeEventListener('online', onOnline);
  current = null;
  lastKept = null;
}

function onOnline() {
  void flushPositions();
}

/** « Je pars » / « Je suis sur place » : une position datée de ce moment, rattachée à l'intervention */
export function markLocationEvent(event: 'EN_ROUTE' | 'ON_SITE', interventionId: string) {
  if (watchId === null || !cachedEnabled()) return;
  const fresh = current && Date.now() - current.timestamp < 2 * 60_000 ? current : null;
  if (fresh) {
    queue(fresh, event, interventionId);
    void flushPositions();
    return;
  }
  navigator.geolocation.getCurrentPosition((pos) => {
    queue(pos, event, interventionId);
    void flushPositions();
  }, () => undefined, { enableHighAccuracy: true, maximumAge: 60_000, timeout: 30_000 });
}

export interface LocationSharing {
  supported: boolean;
  enabled: boolean;
  vehicle: { id: string; plate: string } | null;
  retentionDays: number;
  error: 'denied' | 'unavailable' | null;
  loaded: boolean;
}

/**
 * État du partage et suivi : le suivi tourne tant qu'une page qui utilise ce crochet est affichée
 * et que le partage est activé.
 */
export function useLocationSharing() {
  const supported = typeof navigator !== 'undefined' && 'geolocation' in navigator;
  const [state, setState] = useState<LocationSharing>({
    supported, enabled: cachedEnabled(), vehicle: null, retentionDays: 30, error: null, loaded: false,
  });

  useEffect(() => {
    let cancelled = false;
    api<{ enabled: boolean; vehicle: { id: string; plate: string } | null; retentionDays: number }>('/me/location-sharing')
      .then((r) => {
        if (cancelled) return;
        setCachedEnabled(r.enabled);
        setState((s) => ({ ...s, enabled: r.enabled, vehicle: r.vehicle, retentionDays: r.retentionDays, loaded: true }));
      })
      // Sans réseau : on se fie au dernier état connu sur l'appareil
      .catch(() => !cancelled && setState((s) => ({ ...s, loaded: true })));
    const onError = (error: 'denied' | 'unavailable' | null) => setState((s) => (s.error === error ? s : { ...s, error }));
    errorListeners.add(onError);
    return () => {
      cancelled = true;
      errorListeners.delete(onError);
    };
  }, []);

  useEffect(() => {
    if (!supported) return;
    if (state.enabled) startTracking();
    else stopTracking();
  }, [state.enabled, supported]);

  // La page se ferme : on arrête de suivre (le prochain écran qui en a besoin relance le suivi)
  useEffect(() => () => stopTracking(), []);

  const setEnabled = useCallback(async (enabled: boolean) => {
    await api('/me/location-sharing', { method: 'PUT', body: { enabled } });
    setCachedEnabled(enabled);
    if (!enabled) writePending(readPending().filter((p) => p.userId && p.userId !== currentUserId()));
    setState((s) => ({ ...s, enabled, error: null }));
  }, []);

  return { ...state, setEnabled };
}
