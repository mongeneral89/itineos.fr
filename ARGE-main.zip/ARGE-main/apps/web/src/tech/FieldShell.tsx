/**
 * Cadre de l'appli terrain (téléphone, tablette, appli Android) : barre de titre courte en haut, barre d'onglets
 * en bas, à portée de pouce. La messagerie, l'annuaire, les notices et le compte s'y affichent aussi pour les
 * techniciens, au lieu du menu latéral du bureau.
 */
import { createContext, useContext, type ReactNode } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../auth';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { t as tr } from '../i18n';
import { useUnreadMessages } from '../messaging';
import { useSync } from '../offline/sync';
import { usePendingProcedures } from '../pages/Procedures';
import { fmtLongDay } from '../format';
import { techText } from './i18n';
import { NotificationBell } from '../components/NotificationBell';

const FieldContext = createContext(false);
/** Vrai dans l'appli terrain : les pages partagées avec le bureau y cachent leur propre titre */
export const useInField = () => useContext(FieldContext);

/** Pages ouvertes depuis « Plus » : flèche de retour vers « Plus », onglet « Plus » allumé */
const SUB_PAGES = ['/tech/team', '/account'];

export function FieldShell() {
  const { me, has } = useAuth();
  const { t } = techText(me?.user.locale);
  const { pathname } = useLocation();
  const unread = useUnreadMessages();
  const pending = usePendingProcedures(has('procedure.manage'));

  const titles: Record<string, string> = {
    // Ma journée : la date sert de titre (l'onglet dit déjà « Journée »)
    '/tech': fmtLongDay(new Date(), me?.user.locale ?? 'fr-FR'), '/tech/team': tr('Planning de l’équipe'), '/tech/more': t.more,
    '/messages': t.messages, '/directory': t.directory, '/procedures': t.procedures, '/account': t.account,
  };
  const sub = SUB_PAGES.includes(pathname);

  return (
    <FieldContext.Provider value>
      <div className="terrain">
        <header className="field-bar">
          {sub && (
            <Link to="/tech/more" className="field-back" aria-label={t.back}>
              <Icon d="M15 5l-7 7 7 7" />
            </Link>
          )}
          <h1 className="field-title">{titles[pathname] ?? ''}</h1>
          <NotificationBell />
          <SyncDot />
        </header>
        <main className="field-main">
          <ErrorBoundary resetKey={pathname}>
            <Outlet />
          </ErrorBoundary>
        </main>
        <nav className="field-tabs" aria-label={tr('Menu principal')}>
          <Tab to="/tech" end label={t.tabDay} icon={<Icon d="M4 6h16M4 12h10M4 18h7M17 15l2 2 4-4" />} />
          <Tab to="/messages" label={t.messages} badge={unread}
            icon={<Icon d="M4 5h16v11H9l-5 4z" />} />
          <Tab to="/directory" label={t.directory}
            icon={<Icon d="M6 3h12v18H6zM10 8a2 2 0 104 0 2 2 0 00-4 0M8.5 15c.5-2 2-3 3.5-3s3 1 3.5 3" />} />
          <Tab to="/procedures" label={t.procedures} badge={pending}
            icon={<Icon d="M5 4h9l5 5v11H5zM14 4v5h5M8 13h8M8 17h6" />} />
          <Tab to="/tech/more" label={t.more} active={sub}
            icon={<Icon d="M5 12h.01M12 12h.01M19 12h.01" bold />} />
        </nav>
      </div>
    </FieldContext.Provider>
  );
}

function Tab({ to, label, icon, badge = 0, end, active }: { to: string; label: string; icon: ReactNode; badge?: number; end?: boolean; active?: boolean }) {
  return (
    <NavLink to={to} end={end} className={({ isActive }) => `field-tab${isActive || active ? ' active' : ''}`}>
      <span className="field-tab-icon">
        {icon}
        {badge > 0 && <span className="field-badge">{badge > 99 ? '99+' : badge}</span>}
      </span>
      <span className="field-tab-label">{label}</span>
    </NavLink>
  );
}

function Icon({ d, bold }: { d: string; bold?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={bold ? 3.2 : 1.9} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

/** État des envois en un coup d'œil (le détail et « Réessayer » sont sur « Ma journée ») */
function SyncDot() {
  const { me } = useAuth();
  const { t } = techText(me?.user.locale);
  const s = useSync();
  const waiting = s.pending - s.failed.length;
  if (s.online && !waiting && !s.failed.length && !s.syncing) return null;
  const label = !s.online ? t.offline : s.failed.length ? t.refused(s.failed.length) : s.syncing ? t.syncing : t.waiting(waiting);
  const tone = s.failed.length ? 'warn' : !s.online ? 'off' : 'busy';
  return (
    <Link to="/tech" className={`field-sync ${tone}`} role="status" aria-live="polite">
      <span className="field-sync-dot" aria-hidden="true" />
      <span className="field-sync-label">{label}</span>
    </Link>
  );
}
