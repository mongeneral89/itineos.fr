import { useRef, useState } from 'react';
import { MAX_PHOTOS_PER_REPORT, PHOTO_KINDS, type PhotoKind } from '@itineo/shared';
import { compressPhoto, usePhotoUrl } from '../photos';
import { addPhoto, captionPhoto, deletePhoto } from '../offline/field';
import { useSync } from '../offline/sync';
import type { ReportPhoto } from '../types';
import { newId } from '../ids';
import type { techText } from './i18n';

type T = ReturnType<typeof techText>['t'];

/**
 * Photos de la fiche. Chaque photo est gardée sur l'appareil puis envoyée par la file d'attente :
 * sans réseau, elle s'affiche quand même et partira au retour de la connexion.
 * La liste affichée vient de la copie locale de la fiche (mise à jour par offline/field.ts).
 */
export function PhotosSection({ interventionId, photos, editable, t }: {
  interventionId: string;
  photos: ReportPhoto[];
  editable: boolean;
  t: T;
}) {
  const sync = useSync();
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const kindRef = useRef<PhotoKind>('BEFORE');

  const pick = (kind: PhotoKind) => {
    kindRef.current = kind;
    input.current?.click();
  };

  const onFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setError(null);
    const room = MAX_PHOTOS_PER_REPORT - photos.length;
    const chosen = [...files].slice(0, Math.max(0, room));
    if (chosen.length < files.length) setError(t.photoLimit(MAX_PHOTOS_PER_REPORT));
    const kind = kindRef.current;
    if (input.current) input.current.value = '';
    for (const file of chosen) {
      setBusy((n) => n + 1);
      try {
        const image = await compressPhoto(file);
        await addPhoto(interventionId, { clientId: newId(), kind, image });
      } catch (e) {
        setError((e as Error).message);
      } finally {
        setBusy((n) => n - 1);
      }
    }
  };

  const remove = async (photo: ReportPhoto) => {
    if (!window.confirm(t.photoDeleteConfirm)) return;
    await deletePhoto(interventionId, photo).catch((e) => setError((e as Error).message));
  };

  const saveCaption = async (photo: ReportPhoto, caption: string) => {
    if ((photo.caption ?? '') === caption.trim()) return;
    await captionPhoto(interventionId, photo, caption.trim()).catch((e) => setError((e as Error).message));
  };

  if (!editable && !photos.length) return null;

  return (
    <section className="card stack">
      <h2>{t.photos}</h2>
      {editable && (
        <>
          <div className="row" style={{ gap: 8 }}>
            {PHOTO_KINDS.map((k) => (
              <button key={k} type="button" className="secondary grow" disabled={photos.length >= MAX_PHOTOS_PER_REPORT} onClick={() => pick(k)}>
                📷 {t.photoKinds[k]}
              </button>
            ))}
          </div>
          {/* Sans « capture » : le téléphone propose l'appareil photo ou la galerie */}
          <input ref={input} type="file" accept="image/*" multiple hidden onChange={(e) => void onFiles(e.target.files)} />
        </>
      )}
      {error && <p className="error" role="alert">{error}</p>}
      {busy > 0 && <p className="muted small">{t.photoUploading}</p>}
      {photos.length > 0 && (
        <div className="photo-grid">
          {photos.map((ph) => (
            <PhotoTile key={ph.clientId} interventionId={interventionId} photo={ph} editable={editable} t={t}
              status={ph.localImage ? (sync.online ? t.photoUploading : t.savedOnDevice) : null}
              onRemove={() => void remove(ph)} onCaption={(c) => void saveCaption(ph, c)} />
          ))}
        </div>
      )}
    </section>
  );
}

function PhotoTile({ interventionId, photo, editable, t, status, onRemove, onCaption }: {
  interventionId: string;
  photo: ReportPhoto;
  editable: boolean;
  t: T;
  status: string | null;
  onRemove: () => void;
  onCaption: (caption: string) => void;
}) {
  const url = usePhotoUrl(interventionId, photo);
  const [caption, setCaption] = useState(photo.caption ?? '');
  return (
    <figure className="photo-tile">
      {url ? <a href={url} target="_blank" rel="noreferrer"><img src={url} alt={photo.caption ?? t.photoKinds[photo.kind]} /></a> : <div className="photo-placeholder" />}
      <figcaption className="stack" style={{ gap: 4 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <span className="badge neutral">{t.photoKinds[photo.kind]}</span>
          {editable && <button type="button" className="ghost" onClick={onRemove}>{t.remove}</button>}
        </div>
        {status && <span className="small muted">{status}</span>}
        {editable
          ? <input aria-label={t.photoCaption} placeholder={t.photoCaption} maxLength={200} value={caption}
              onChange={(e) => setCaption(e.target.value)} onBlur={() => onCaption(caption)} />
          : photo.caption && <span className="small">{photo.caption}</span>}
      </figcaption>
    </figure>
  );
}
