/**
 * Notifications de l'appli Android, par Firebase (le Web Push des navigateurs ne marche pas dans l'appli installée) :
 * le téléphone donne son jeton au serveur (services/fcm.ts), et une notification touchée ouvre la bonne page.
 */
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import type { PushNotificationsPlugin } from '@capacitor/push-notifications';
import { api } from '../api';
import { useAuth } from '../auth';
import { isNativeApp } from '../native';

const TOKEN_KEY = 'arge.fcmToken';
/** Même canal que le serveur (FCM_CHANNEL) : notifications avec son, en haut de l'écran */
const CHANNEL = 'arge';

const readToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
const keepToken = (v: string | null) => {
  try {
    if (v) localStorage.setItem(TOKEN_KEY, v);
    else localStorage.removeItem(TOKEN_KEY);
  } catch { /* stockage indisponible : le jeton sera redemandé */ }
};

// Le module est rangé dans un objet : une extension Capacitor répond à n'importe quelle méthode, y compris « then »,
// et une promesse qui la renvoie directement ne se terminerait jamais
let plugin: Promise<{ P: PushNotificationsPlugin }> | null = null;
let waiting: ((token: string | null) => void) | null = null;
let opener: ((url: string) => void) | null = null;
/** Notification touchée avant que l'appli soit prête (appli fermée) : ouverte dès que possible */
let pendingUrl: string | null = null;

function load(): Promise<{ P: PushNotificationsPlugin }> {
  plugin ??= import('@capacitor/push-notifications').then(async ({ PushNotifications: P }) => {
    await P.createChannel({ id: CHANNEL, name: 'A.R.G.E.', importance: 4, visibility: 1, vibration: true }).catch(() => undefined);
    await P.addListener('registration', ({ value }) => { waiting?.(value); waiting = null; });
    await P.addListener('registrationError', ({ error }) => {
      console.warn('[notifications] enregistrement impossible', error);
      waiting?.(null);
      waiting = null;
    });
    await P.addListener('pushNotificationActionPerformed', ({ notification }) => {
      const url = (notification.data as { url?: unknown } | undefined)?.url;
      // Seulement une page de l'appli
      if (typeof url !== 'string' || !url.startsWith('/') || url.startsWith('//')) return;
      if (opener) opener(url);
      else pendingUrl = url;
    });
    return { P };
  });
  return plugin;
}

export async function nativePushActive(): Promise<boolean> {
  const { P } = await load();
  return (await P.checkPermissions()).receive === 'granted' && !!readToken();
}

/** Demande l'autorisation, puis donne le jeton du téléphone au serveur ; false si la personne refuse */
export async function enableNativePush(ask = true): Promise<boolean> {
  const { P } = await load();
  let perm = (await P.checkPermissions()).receive;
  if (perm !== 'granted' && ask && perm !== 'denied') perm = (await P.requestPermissions()).receive;
  if (perm !== 'granted') return false;
  const token = await new Promise<string | null>((resolve) => {
    waiting = resolve;
    setTimeout(() => { if (waiting === resolve) { waiting = null; resolve(null); } }, 20_000);
    void P.register().catch(() => resolve(null));
  });
  if (!token) throw new Error('Firebase');
  await api('/notifications/device', { method: 'POST', body: { token } });
  keepToken(token);
  return true;
}

export async function disableNativePush(): Promise<void> {
  const token = readToken();
  keepToken(null);
  if (token) await api('/notifications/device/remove', { method: 'POST', body: { token } }).catch(() => undefined);
  await (await load()).P.unregister().catch(() => undefined);
}

/**
 * À placer une fois sous le routeur : à la connexion, le téléphone s'inscrit (l'autorisation est demandée la
 * première fois) et redonne son jeton au serveur à chaque ouverture (il peut changer). Une notification touchée
 * ouvre sa page.
 */
export function NativePush() {
  const navigate = useNavigate();
  const userId = useAuth().me?.user.id;

  useEffect(() => {
    if (!isNativeApp() || import.meta.env.VITE_PUSH !== '1') return;
    opener = (url) => navigate(url);
    void load().then(() => {
      if (pendingUrl) { navigate(pendingUrl); pendingUrl = null; }
    });
    return () => { opener = null; };
  }, [navigate]);

  useEffect(() => {
    if (!isNativeApp() || import.meta.env.VITE_PUSH !== '1' || !userId) return;
    void enableNativePush().catch((e) => console.warn('[notifications]', (e as Error).message));
  }, [userId]);

  return null;
}
