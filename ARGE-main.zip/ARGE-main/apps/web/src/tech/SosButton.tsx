/**
 * Itinéos Vigie : alerte SOS de l'agent isolé. Ses responsables sont prévenus aussitôt (téléphone et e-mail),
 * avec sa position si le téléphone la donne. Sans réseau, l'agent est invité à appeler le 112.
 */
import { useState } from 'react';
import { api } from '../api';
import { t, tp } from '../i18n';

/** Position actuelle, sans attendre plus de 8 secondes (l'alerte part quand même sans) */
function currentPosition(): Promise<GeolocationPosition | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) return resolve(null);
    navigator.geolocation.getCurrentPosition(resolve, () => resolve(null), { enableHighAccuracy: true, timeout: 8000, maximumAge: 60_000 });
  });
}

export function SosButton({ interventionId }: { interventionId?: string | null }) {
  const [state, setState] = useState<'idle' | 'sending' | 'sent' | 'failed'>('idle');
  const [notified, setNotified] = useState(0);

  const raise = async () => {
    if (!window.confirm(t('Déclencher une alerte SOS ? Vos responsables seront prévenus immédiatement, avec votre position.'))) return;
    setState('sending');
    const pos = await currentPosition();
    try {
      const r = await api<{ notified: number }>('/alerts/sos', {
        method: 'POST',
        body: {
          ...(pos ? { lat: pos.coords.latitude, lng: pos.coords.longitude, accuracyM: pos.coords.accuracy } : {}),
          ...(interventionId ? { interventionId } : {}),
        },
      });
      setNotified(r.notified);
      setState('sent');
    } catch {
      setState('failed');
    }
  };

  return (
    <section className="card stack" style={{ gap: 8 }}>
      <button type="button" className="big sos-btn" disabled={state === 'sending'} onClick={() => void raise()}>
        {state === 'sending' ? t('Envoi de l’alerte…') : t('Alerte SOS')}
      </button>
      {state === 'sent' && <p className="success" role="status">{tp(notified, 'Alerte envoyée à {n} responsable. Restez joignable.', 'Alerte envoyée à {n} responsables. Restez joignable.')}</p>}
      {state === 'failed' && <p className="error" role="alert">{t('L’alerte n’a pas pu partir (pas de réseau ?). Appelez le 112.')}</p>}
      <a className="small" href="tel:112">{t('Urgence : appeler le 112')}</a>
    </section>
  );
}
