/**
 * Mises à jour de l'appli Android installée hors Play Store. Au lancement et à chaque retour dans l'appli, elle
 * lit la dernière version publiée (VITE_UPDATE_URL, sinon le serveur) ; si elle est plus récente que la sienne,
 * un bandeau propose de la télécharger et ouvre l'installation d'Android. Android n'accepte la mise à jour que si
 * elle est signée avec la même clé que l'appli installée.
 */
import { useCallback, useEffect, useState, useSyncExternalStore } from 'react';
import { t } from '../i18n';
import { getServer, isAndroidApp, LOCAL_HOST } from '../native';

/** Numéro de cette construction (lanceurs\construire-apk.ps1) ; 0 : construite à la main */
export const APP_VERSION_CODE = Number(import.meta.env.VITE_APP_VERSION_CODE ?? 0) || 0;
export const APP_VERSION_NAME: string = import.meta.env.VITE_APP_VERSION_NAME ?? '';

interface Release { versionCode: number; versionName: string; notes?: string; url: string; size?: number; sha256: string }

type State =
  | { kind: 'idle' | 'checking' | 'upToDate' | 'error' }
  | { kind: 'available'; release: Release }
  | { kind: 'downloading'; release: Release; percent: number }
  | { kind: 'failed'; release: Release };

/**
 * Où lire la dernière version : l'adresse fixée à la construction (https), sinon le serveur choisi à la connexion
 * (https, ou http seulement pour un PC du réseau local pendant les essais). L'APK ne vient que de la même origine.
 */
function sourceUrl(): { info: string; apk: (announced: string | undefined) => string | null } | null {
  const fixed = import.meta.env.VITE_UPDATE_URL as string | undefined;
  if (fixed) {
    const origin = new URL(fixed).origin;
    if (!origin.startsWith('https://')) return null;
    return {
      info: fixed,
      apk: (announced) => {
        try {
          const u = new URL(announced ?? '', fixed);
          return u.origin === origin ? u.href : null;
        } catch {
          return null;
        }
      },
    };
  }
  const server = getServer();
  if (!server) return null;
  const { protocol, host } = new URL(server);
  if (protocol !== 'https:' && !LOCAL_HOST.test(host)) return null;
  // Sur le serveur Itinéos, l'adresse annoncée est ignorée : toujours sa propre APK
  return { info: `${server}/api/app/android`, apk: () => `${server}/api/app/android.apk` };
}

const toHex = (buf: ArrayBuffer) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

/** Empreinte SHA-256 du fichier téléchargé (lu dans le cache de l'appli) */
async function sha256Of(path: string): Promise<string> {
  const { Filesystem } = await import('@capacitor/filesystem');
  const { data } = await Filesystem.readFile({ path });
  const bin = typeof data === 'string' ? Uint8Array.from(atob(data), (c) => c.charCodeAt(0)) : new Uint8Array(await data.arrayBuffer());
  return toHex(await crypto.subtle.digest('SHA-256', bin));
}

// État partagé : le bandeau et la page « Plus » montrent la même chose
let state: State = { kind: 'idle' };
const listeners = new Set<() => void>();
const set = (s: State) => {
  state = s;
  listeners.forEach((l) => l());
};
let lastCheck = 0;
const CHECK_EVERY = 10 * 60 * 1000;

export async function checkForUpdate(force = false) {
  if (!isAndroidApp() || state.kind === 'downloading') return;
  if (!force && Date.now() - lastCheck < CHECK_EVERY) return;
  const src = sourceUrl();
  if (!src) return;
  lastCheck = Date.now();
  if (force) set({ kind: 'checking' });
  try {
    const res = await fetch(`${src.info}${src.info.includes('?') ? '&' : '?'}t=${Date.now()}`, { cache: 'no-store', signal: AbortSignal.timeout(10_000) });
    if (!res.ok) throw new Error(String(res.status));
    const r = (await res.json()) as Partial<Release>;
    if (!r.versionCode || r.versionCode <= APP_VERSION_CODE) return set({ kind: force ? 'upToDate' : 'idle' });
    const url = src.apk(r.url);
    // Sans adresse sûre ni empreinte, pas de mise à jour proposée
    if (!url || !r.sha256 || !/^[0-9a-f]{64}$/i.test(r.sha256)) return set({ kind: force ? 'error' : 'idle' });
    // Recherche demandée à la main : le bandeau revient même après « Plus tard »
    if (force) {
      try {
        sessionStorage.removeItem(dismissKey(r.versionCode));
      } catch {
        /* stockage indisponible */
      }
    }
    set({ kind: 'available', release: { versionCode: r.versionCode, versionName: r.versionName ?? String(r.versionCode), notes: r.notes, url, size: r.size, sha256: r.sha256.toLowerCase() } });
  } catch {
    set({ kind: force ? 'error' : 'idle' });
  }
}

/** Télécharge l'APK dans le cache de l'appli, puis ouvre l'écran d'installation d'Android */
export async function installUpdate() {
  if (state.kind !== 'available' && state.kind !== 'failed') return;
  const release = state.release;
  set({ kind: 'downloading', release, percent: 0 });
  const [{ Filesystem, Directory }, { FileTransfer }, { FileOpener }] = await Promise.all([
    import('@capacitor/filesystem'),
    import('@capacitor/file-transfer'),
    import('@capacitor-community/file-opener'),
  ]);
  const progress = await FileTransfer.addListener('progress', (p) => {
    if (p.lengthComputable && p.contentLength > 0) set({ kind: 'downloading', release, percent: Math.round((p.bytes / p.contentLength) * 100) });
  });
  try {
    const { uri } = await Filesystem.getUri({ path: `maj-${release.versionCode}.apk`, directory: Directory.Cache });
    const { path } = await FileTransfer.downloadFile({ url: release.url, path: uri, progress: true });
    const file = path ?? uri;
    // Fichier abîmé ou remplacé en route : il n'est pas installé (Android vérifie aussi la signature de l'APK)
    if ((await sha256Of(file)) !== release.sha256) {
      await Filesystem.deleteFile({ path: file }).catch(() => undefined);
      throw new Error('sha256');
    }
    set({ kind: 'available', release });
    await FileOpener.open({ filePath: file, contentType: 'application/vnd.android.package-archive' });
  } catch {
    set({ kind: 'failed', release });
  } finally {
    void progress.remove();
  }
}

const dismissKey = (code: number) => `itineo.update.later.${code}`;

export function useAppUpdate() {
  const current = useSyncExternalStore((l) => {
    listeners.add(l);
    return () => listeners.delete(l);
  }, () => state);
  const check = useCallback((force?: boolean) => checkForUpdate(force), []);
  return { state: current, check, install: installUpdate };
}

/** Bandeau en haut de l'écran : nouvelle version, téléchargement, échec */
export function UpdateBanner() {
  const { state: s, install } = useAppUpdate();
  const [, redraw] = useState(0);

  // Au lancement, puis à chaque retour dans l'appli (au plus toutes les 10 minutes)
  useEffect(() => {
    if (!isAndroidApp()) return;
    void checkForUpdate(true).then(() => state.kind === 'upToDate' || state.kind === 'error' ? set({ kind: 'idle' }) : undefined);
    const onShow = () => document.visibilityState === 'visible' && void checkForUpdate();
    document.addEventListener('visibilitychange', onShow);
    return () => document.removeEventListener('visibilitychange', onShow);
  }, []);

  if (s.kind !== 'available' && s.kind !== 'downloading' && s.kind !== 'failed') return null;
  let later = false;
  try {
    later = sessionStorage.getItem(dismissKey(s.release.versionCode)) === '1';
  } catch {
    /* stockage indisponible */
  }
  if (later && s.kind === 'available') return null;

  const dismiss = () => {
    try {
      sessionStorage.setItem(dismissKey(s.release.versionCode), '1');
    } catch {
      /* stockage indisponible */
    }
    redraw((n) => n + 1);
  };

  return (
    <div className="update-banner" role="status" aria-live="polite">
      <div className="grow" style={{ minWidth: 0 }}>
        <strong>{t('Nouvelle version de l’appli : {version}', { version: s.release.versionName })}</strong>
        {s.release.notes && s.kind === 'available' && <div className="small update-notes">{s.release.notes}</div>}
        {s.kind === 'downloading' && (
          <div className="update-progress" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={s.percent}>
            <span style={{ width: `${s.percent}%` }} />
          </div>
        )}
        {s.kind === 'failed' && <div className="small">{t('Échec du téléchargement : vérifiez le réseau et réessayez.')}</div>}
      </div>
      {s.kind === 'downloading' ? (
        <span className="small" style={{ flexShrink: 0 }}>{s.percent} %</span>
      ) : (
        <div className="update-actions">
          <button type="button" className="accent" onClick={() => void install()}>{t('Mettre à jour')}</button>
          {s.kind === 'available' && <button type="button" className="ghost" onClick={dismiss}>{t('Plus tard')}</button>}
        </div>
      )}
    </div>
  );
}
