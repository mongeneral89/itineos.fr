/** Appli terrain, onglet « Plus » : le profil, puis ce qui sert moins souvent que les autres onglets */
import { Link } from 'react-router-dom';
import { useAuth } from '../auth';
import { t as tr } from '../i18n';
import { logoSrc } from '../logo';
import { getServer, isAndroidApp, isNativeApp } from '../native';
import { useSync } from '../offline/sync';
import { techText } from './i18n';
import { APP_VERSION_CODE, APP_VERSION_NAME, useAppUpdate } from './AppUpdate';

export function MorePage() {
  const { me, company, logout, isTechnicianOnly } = useAuth();
  const { t } = techText(me?.user.locale);
  const sync = useSync();
  const logo = logoSrc(company);
  const update = useAppUpdate();

  const onLogout = () => {
    if (sync.pending && !window.confirm(t.logoutPending(sync.pending))) return;
    logout();
  };

  return (
    <>
      <section className="card more-profile">
        {logo && <img className="company-logo" src={logo} alt={company?.name ?? ''} />}
        <div>
          <strong style={{ fontSize: 18 }}>{me?.user.firstName} {me?.user.lastName}</strong>
          <div className="small muted">{me?.assignments.map((a) => a.label).join(', ')}</div>
          <div className="small muted">{me?.user.email}</div>
        </div>
      </section>

      <nav className="more-list" aria-label={t.more}>
        <Link to="/tech/team">{tr('Planning de l’équipe')}<span aria-hidden="true">›</span></Link>
        <Link to="/account">{t.account}<span aria-hidden="true">›</span></Link>
        {!isTechnicianOnly && <Link to="/">{t.office}<span aria-hidden="true">›</span></Link>}
      </nav>

      {isNativeApp() && (
        <section className="card stack" style={{ gap: 8 }}>
          <div className="small muted">
            {tr('Version de l’appli')} : {APP_VERSION_NAME || APP_VERSION_CODE || '—'}
            <br />
            {tr('Adresse du serveur')} : {getServer().replace(/^https?:\/\//, '')}
          </div>
          {isAndroidApp() && (
            <button type="button" className="secondary" disabled={update.state.kind === 'checking' || update.state.kind === 'downloading'}
              onClick={() => void update.check(true)}>
              {update.state.kind === 'checking' ? tr('Recherche…') : tr('Rechercher une mise à jour')}
            </button>
          )}
          {update.state.kind === 'upToDate' && <p className="success small" role="status" style={{ margin: 0 }}>{tr('L’appli est à jour.')}</p>}
          {update.state.kind === 'error' && <p className="error small" role="alert" style={{ margin: 0 }}>{tr('Impossible de vérifier les mises à jour pour le moment.')}</p>}
        </section>
      )}

      <button type="button" className="secondary big more-logout" onClick={onLogout}>{t.logout}</button>
    </>
  );
}
