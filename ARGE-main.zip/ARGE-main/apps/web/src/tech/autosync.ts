/**
 * Changements faits au bureau, reçus par l'appli terrain sans rien toucher.
 *
 * L'appli relit l'empreinte /sync/stamp (ses interventions, leurs fiches, la dernière demande du bureau) :
 * à l'ouverture, toutes les minutes tant qu'elle est à l'écran, quand on y revient, et aussitôt quand le
 * bureau appuie sur « Synchroniser les téléphones » (message du service worker). Si l'empreinte a changé,
 * `onChange` recharge la journée et les fiches.
 */
import { useEffect, useRef } from 'react';
import { api } from '../api';

const keyFor = (userId: string) => `itineo-sync-stamp:${userId}`;

function readStamp(userId: string): string | null {
  try {
    return localStorage.getItem(keyFor(userId));
  } catch {
    return null;
  }
}

function writeStamp(userId: string, stamp: string) {
  try {
    localStorage.setItem(keyFor(userId), stamp);
  } catch {
    /* stockage indisponible : on resynchronisera simplement plus souvent */
  }
}

/** Mémorise l'état du serveur juste après une synchronisation (pour ne pas recharger deux fois) */
export async function rememberServerState(userId: string | undefined) {
  if (!userId || !navigator.onLine) return;
  const { stamp } = await api<{ stamp: string }>('/sync/stamp').catch(() => ({ stamp: '' }));
  if (stamp) writeStamp(userId, stamp);
}

export function useRemoteChanges(userId: string | undefined, onChange: () => void) {
  const latest = useRef(onChange);
  latest.current = onChange;

  useEffect(() => {
    if (!userId) return;
    let stopped = false;
    let checking = false;

    const check = async () => {
      if (checking || stopped || !navigator.onLine || document.visibilityState !== 'visible') return;
      checking = true;
      try {
        const { stamp } = await api<{ stamp: string }>('/sync/stamp');
        const before = readStamp(userId);
        writeStamp(userId, stamp);
        if (before && before !== stamp && !stopped) latest.current();
      } catch {
        /* pas de réseau : on réessaiera */
      } finally {
        checking = false;
      }
    };

    const onVisible = () => {
      if (document.visibilityState === 'visible') void check();
    };
    const onMessage = (e: MessageEvent) => {
      if (e.data?.type === 'itineo-sync') latest.current();
    };

    void check();
    const timer = window.setInterval(() => void check(), 60_000);
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    window.addEventListener('online', onVisible);
    navigator.serviceWorker?.addEventListener('message', onMessage);
    return () => {
      stopped = true;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
      window.removeEventListener('online', onVisible);
      navigator.serviceWorker?.removeEventListener('message', onMessage);
    };
  }, [userId]);
}
