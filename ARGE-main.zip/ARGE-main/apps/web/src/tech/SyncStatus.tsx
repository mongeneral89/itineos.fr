import { useState } from 'react';
import { discard, flush, useSync } from '../offline/sync';
import type { techText } from './i18n';

type T = ReturnType<typeof techText>['t'];

/** État du réseau et des envois, dans l'en-tête de l'appli terrain */
export function SyncStatus({ t }: { t: T }) {
  const s = useSync();
  const [open, setOpen] = useState(false);
  const waiting = s.pending - s.failed.length;

  const label = !s.online
    ? `${t.offline}${waiting ? ` · ${t.waiting(waiting)}` : ''}`
    : s.syncing
      ? t.syncing
      : waiting
        ? t.waiting(waiting)
        : t.allSent;
  const tone = s.failed.length ? 'warn' : !s.online || waiting ? 'neutral' : 'ok';

  return (
    <div className="stack" style={{ gap: 6 }}>
      <div className="row" style={{ gap: 6 }}>
        <span className={`badge ${tone}`} role="status" aria-live="polite">
          <span aria-hidden="true">{s.online ? '●' : '○'}</span> {label}
        </span>
        {s.online && waiting > 0 && !s.syncing && (
          <button type="button" className="ghost" style={{ color: '#F4F2EE' }} onClick={() => void flush()}>{t.retry}</button>
        )}
        {s.failed.length > 0 && (
          <button type="button" className="ghost" style={{ color: '#F4F2EE' }} onClick={() => setOpen((o) => !o)}>
            {t.refused(s.failed.length)}
          </button>
        )}
      </div>
      {open && s.failed.map((op) => (
        <div key={op.seq} className="card small" style={{ background: 'var(--warn-bg)', color: 'var(--warn-fg)', padding: 10 }}>
          <div>{op.error}</div>
          <button type="button" className="ghost" onClick={() => void discard(op)}>{t.discard}</button>
        </div>
      ))}
    </div>
  );
}
