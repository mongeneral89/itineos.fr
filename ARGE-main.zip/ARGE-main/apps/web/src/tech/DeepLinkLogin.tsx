/**
 * Appli Android : le bouton « Ouvrir l'appli » de la page d'invitation l'ouvre par un lien https vérifié par Android
 * (App Link : https://serveur/ouvrir?code=…, voir AndroidManifest.xml et .well-known/assetlinks.json) ; elle échange
 * le code (15 minutes, usage unique) contre une session.
 *  - le lien n'est accepté que s'il vient du serveur de l'appli : un lien piégé ne peut pas la faire parler ailleurs ;
 *  - jamais si une session est déjà ouverte : un lien ne peut pas remplacer le compte de quelqu'un.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, getToken } from '../api';
import { useAuth } from '../auth';
import { t } from '../i18n';
import { getServer, isNativeApp, normalizeServer } from '../native';
import type { Me } from '../types';

/** Code d'un lien https://<serveur de l'appli>/ouvrir?code=… ; rien pour tout autre lien */
export function codeFromLink(url: string, server: string): string | null {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    if (normalizeServer(u.origin) !== normalizeServer(server) || u.pathname !== '/ouvrir') return null;
    return u.searchParams.get('code');
  } catch {
    return null;
  }
}

export function DeepLinkLogin() {
  const { adopt } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isNativeApp()) return;
    let remove: (() => void) | undefined;
    let stop = false;
    const handle = async (url: string | undefined) => {
      const code = url ? codeFromLink(url, getServer()) : null;
      if (!code) return;
      // Session gardée sur l'appareil (même avant que le profil soit rechargé)
      if (getToken()) {
        setError(t('Vous êtes déjà connecté : ce lien d’invitation n’est pas utilisé. Déconnectez-vous d’abord pour changer de compte.'));
        return;
      }
      try {
        await adopt(await api<{ token: string; me: Me }>('/invitations/app-login', { method: 'POST', body: { code } }));
        navigate('/', { replace: true });
      } catch (e) {
        setError((e as Error).message);
      }
    };
    void import('@capacitor/app').then(async ({ App }) => {
      // Appli fermée : ouverte par le lien ; appli déjà ouverte : le lien arrive par l'événement
      const launch = await App.getLaunchUrl().catch(() => undefined);
      if (!stop) void handle(launch?.url);
      const h = await App.addListener('appUrlOpen', ({ url }) => void handle(url));
      if (stop) void h.remove();
      else remove = () => void h.remove();
    });
    return () => {
      stop = true;
      remove?.();
    };
  }, [adopt, navigate]);

  if (!error) return null;
  return (
    <div className="update-banner" role="alert">
      <span className="grow">{error}</span>
      <button type="button" className="ghost" onClick={() => setError(null)}>{t('Fermer')}</button>
    </div>
  );
}
