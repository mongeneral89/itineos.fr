/** « Ma journée » : proposer le partage de position (le technicien décide), ou rappeler qu'il est actif */
import { useState } from 'react';
import type { techText } from './i18n';
import { useLocationSharing } from './location';

type T = ReturnType<typeof techText>['t'];
const LATER_KEY = 'itineo.location.later';

export function LocationCard({ t }: { t: T }) {
  const loc = useLocationSharing();
  const [later, setLater] = useState(() => {
    try {
      return sessionStorage.getItem(LATER_KEY) === '1';
    } catch {
      return false;
    }
  });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Pas de véhicule attribué, ou téléphone sans géolocalisation : rien à proposer
  if (!loc.loaded || !loc.supported || !loc.vehicle) return null;

  const toggle = async (on: boolean) => {
    setBusy(true);
    setError(null);
    try {
      await loc.setEnabled(on);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (loc.enabled) {
    return (
      <div className="row small" style={{ justifyContent: 'space-between', gap: 8 }}>
        <span>
          <span aria-hidden="true" style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: loc.error ? '#9CA3AF' : '#0F4D41', marginRight: 6 }} />
          {t.locOn(loc.vehicle.plate)}
        </span>
        <button type="button" className="ghost" disabled={busy} onClick={() => void toggle(false)}>{t.locStop}</button>
        {loc.error && <span className="muted" style={{ width: '100%' }}>{loc.error === 'denied' ? t.locDenied : t.locUnavailable}</span>}
      </div>
    );
  }
  if (later) return null;
  return (
    <section className="card stack" style={{ gap: 8 }}>
      <strong>{t.locTitle}</strong>
      <span className="small">{t.locInfo(loc.retentionDays)}</span>
      {error && <span className="error small">{error}</span>}
      <div className="row" style={{ gap: 8 }}>
        <button type="button" className="accent" disabled={busy} onClick={() => void toggle(true)}>{t.locEnable}</button>
        <button type="button" className="ghost" onClick={() => {
          setLater(true);
          try {
            sessionStorage.setItem(LATER_KEY, '1');
          } catch {
            /* ignoré */
          }
        }}>{t.locLater}</button>
      </div>
    </section>
  );
}
