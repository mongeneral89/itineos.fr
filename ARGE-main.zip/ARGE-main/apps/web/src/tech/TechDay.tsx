import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth';
import { useLoad } from '../hooks';
import { loadDay, NOT_AVAILABLE_OFFLINE, prefetchDay, setStatus as setStatusOffline } from '../offline/field';
import { flush, useSync } from '../offline/sync';
import { rememberServerState, useRemoteChanges } from './autosync';
import type { InterventionRow } from '../types';
import { dayBounds, fmtTime } from '../format';
import { techText } from './i18n';
import { SyncStatus } from './SyncStatus';
import { LocationCard } from './LocationCard';
import { GoButton } from '../components/GoButton';
import { kindLabel } from '../i18n';
import { markLocationEvent } from './location';
import { SosButton } from './SosButton';
import { hasFeature } from '../edition';

type T = ReturnType<typeof techText>['t'];
type Status = InterventionRow['status'];

const isActive = (s: Status) => s === 'EN_ROUTE' || s === 'ON_SITE';
const isClosed = (s: Status) => s === 'DONE' || s === 'TO_RESUME' || s === 'CANCELLED';

/**
 * Appli terrain : la journée du technicien connecté (aussi sans réseau).
 * En haut l'intervention en cours (ou la prochaine) avec toutes ses actions, puis les suivantes, puis celles
 * déjà faites : ce qu'on cherche des yeux en arrivant au camion.
 */
export function TechDayPage() {
  const { me } = useAuth();
  const sync = useSync();
  const locale = me?.user.locale ?? 'fr-FR';
  const { t } = techText(locale);
  const today = new Date();
  const { from, to } = dayBounds(today);
  const { data, setData, error, loading, reload } = useLoad(() => loadDay(from, to), [from]);
  const [ready, setReady] = useState<{ done: number; total: number } | null>(null);

  // Avec du réseau : toutes les fiches du jour sont copiées sur l'appareil, pour la suite de la journée
  const prefetched = useRef(false);
  useEffect(() => {
    if (!data || data.fromCache || prefetched.current) return;
    prefetched.current = true;
    void prefetchDay(data.rows, (done, total) => setReady({ done, total }));
  }, [data]);

  // « Synchroniser » : envoie ce qui attend sur l'appareil, puis recharge la journée et toutes ses fiches
  const [syncBusy, setSyncBusy] = useState(false);
  const [syncInfo, setSyncInfo] = useState<{ at: Date; offline: boolean; fromOffice: boolean } | null>(null);
  const syncNow = async (fromOffice = false) => {
    if (syncBusy) return;
    setSyncBusy(true);
    try {
      await flush();
      const fresh = await loadDay(from, to).catch(() => null);
      if (fresh) {
        setData(fresh);
        if (!fresh.fromCache) {
          prefetched.current = true;
          await prefetchDay(fresh.rows, (done, total) => setReady({ done, total }));
          await rememberServerState(me?.user.id);
        }
      }
      setSyncInfo({ at: new Date(), offline: !fresh || fresh.fromCache, fromOffice });
    } finally {
      setSyncBusy(false);
    }
  };
  // Changements faits au bureau : reçus tout seuls
  useRemoteChanges(me?.user.id, () => void syncNow(true));

  // Le réseau revient : on recharge la journée
  useEffect(() => {
    if (sync.online && data?.fromCache) void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sync.online]);

  const jobs = data?.rows ?? [];
  const open = jobs.filter((j) => !isClosed(j.status));
  const closed = jobs.filter((j) => isClosed(j.status));
  // L'intervention commencée passe devant ; sinon la prochaine à l'heure
  const focus = open.find((j) => isActive(j.status)) ?? open[0] ?? null;
  const later = open.filter((j) => j !== focus);
  const finished = jobs.filter((j) => j.status === 'DONE' || j.status === 'TO_RESUME').length;

  const setStatus = async (id: string, status: 'EN_ROUTE' | 'ON_SITE') => {
    await setStatusOffline(id, status).catch(() => undefined);
    markLocationEvent(status, id);
    await reload();
  };

  const noData = error && !data;

  return (
    <>
      {/* Bandeau compact sous le titre (la date) : avancement et envoi des données, sans prendre la place des interventions */}
      <section className="day-hero">
        <div className="day-line">
          {jobs.length > 0 && (
            <>
              <div className="day-progress" role="progressbar" aria-valuemin={0} aria-valuemax={jobs.length} aria-valuenow={finished}>
                <span style={{ width: `${(finished / jobs.length) * 100}%` }} />
              </div>
              <span className="day-count">{t.progress(finished, jobs.length)}</span>
            </>
          )}
          {!jobs.length && <span className="day-count grow">{t.interventions(0)}</span>}
          {/* Synchroniser : envoie ce qui attend sur l'appareil, puis recharge la journée et toutes ses fiches */}
          <button type="button" className="secondary day-sync" onClick={() => void syncNow()} disabled={syncBusy}>
            <span aria-hidden="true">⟳</span> {syncBusy ? t.syncing : t.syncNow}
          </button>
        </div>
        <div className="day-line">
          <SyncStatus t={t} />
          {ready && !data?.fromCache && ready.done < ready.total && <span className="day-count">{t.offlineReady(ready.done, ready.total)}</span>}
          {syncInfo && !syncBusy && (
            <span className="day-count" role="status">
              {syncInfo.offline ? t.syncOfflineDone : syncInfo.fromOffice ? t.syncUpdated(fmtTime(syncInfo.at.toISOString(), undefined, locale)) : t.syncDone(fmtTime(syncInfo.at.toISOString(), undefined, locale))}
            </span>
          )}
        </div>
      </section>

      {hasFeature('sos') && <SosButton interventionId={jobs.find((j) => isActive(j.status))?.id} />}
      <LocationCard t={t} />
      {noData && <p className="error">{error === NOT_AVAILABLE_OFFLINE.message ? t.offlineNoData : error}</p>}
      {data?.fromCache && <p className="muted small">{t.shownOffline}</p>}
      {loading && !data && <p className="muted">…</p>}
      {data && !jobs.length && <p className="muted day-empty">{t.nothing}</p>}

      {focus && (
        <section className="stack" style={{ gap: 8 }}>
          <h2 className="day-section">{isActive(focus.status) ? t.inProgress : t.next}</h2>
          <FocusJob job={focus} t={t} locale={locale} waiting={sync.byIntervention[focus.id] ?? 0} onStatus={setStatus} />
        </section>
      )}

      {later.length > 0 && (
        <section className="stack" style={{ gap: 8 }}>
          <h2 className="day-section">{t.later}</h2>
          {later.map((j) => <JobRow key={j.id} job={j} t={t} locale={locale} waiting={sync.byIntervention[j.id] ?? 0} />)}
        </section>
      )}

      {closed.length > 0 && (
        <section className="stack" style={{ gap: 8 }}>
          <h2 className="day-section">{t.done}</h2>
          {closed.map((j) => <JobRow key={j.id} job={j} t={t} locale={locale} waiting={sync.byIntervention[j.id] ?? 0} done />)}
        </section>
      )}
    </>
  );
}

/** L'intervention à faire maintenant : grande carte avec toutes les actions */
function FocusJob({ job: j, t, locale, waiting, onStatus }: {
  job: InterventionRow; t: T; locale: string; waiting: number; onStatus: (id: string, s: 'EN_ROUTE' | 'ON_SITE') => void;
}) {
  const address = [j.siteAddress, j.sitePostalCode, j.siteCity].filter(Boolean).join(' ');
  return (
    <article className="job-focus">
      <div className="row" style={{ justifyContent: 'space-between', gap: 8, flexWrap: 'nowrap' }}>
        <span className="job-focus-time">{fmtTime(j.scheduledStart, undefined, locale)}</span>
        <span className="badge neutral">{kindLabel(j.kind)}</span>
      </div>
      <div>
        <div className="job-focus-client">{j.clientName}</div>
        <div>{j.reason}</div>
        <div className="small muted">
          {address || j.siteCity || ''}{(address || j.siteCity) ? ' · ' : ''}{j.number}
          {waiting > 0 && <> · <span className="badge warn">{t.waiting(waiting)}</span></>}
        </div>
      </div>
      <Link className="btn accent big job-focus-open" to={`/tech/${j.id}`}>{t.openReport}</Link>
      {!isActive(j.status) || j.status === 'EN_ROUTE' ? (
        <div className="job-focus-steps">
          {j.status === 'PLANNED' && <button type="button" className="secondary" onClick={() => onStatus(j.id, 'EN_ROUTE')}>{t.enRoute}</button>}
          {(j.status === 'PLANNED' || j.status === 'EN_ROUTE') && <button type="button" className="secondary" onClick={() => onStatus(j.id, 'ON_SITE')}>{t.onSite}</button>}
        </div>
      ) : null}
      {address && <GoButton address={address} lat={j.siteLat} lng={j.siteLng} />}
    </article>
  );
}

/** Les autres interventions : une ligne qu'on touche pour ouvrir la fiche */
function JobRow({ job: j, t, locale, waiting, done }: { job: InterventionRow; t: T; locale: string; waiting: number; done?: boolean }) {
  return (
    <Link to={`/tech/${j.id}`} className={`job-row${done ? ' done' : ''}`}>
      <span className="job-row-time">{fmtTime(j.scheduledStart, undefined, locale)}</span>
      <span className="grow" style={{ minWidth: 0 }}>
        <strong className="msg-ellipsis">{j.clientName}</strong>
        <span className="small muted msg-ellipsis">{j.reason}</span>
        <span className="small muted">
          {j.siteCity ? `${j.siteCity} · ` : ''}{kindLabel(j.kind)}
          {waiting > 0 && <> · <span className="badge warn">{t.waiting(waiting)}</span></>}
        </span>
      </span>
      <span className="job-row-go" aria-hidden="true">›</span>
    </Link>
  );
}
