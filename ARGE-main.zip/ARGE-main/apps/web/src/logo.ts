/** Logo de la société : adresse de l'image, et préparation du fichier choisi avant l'envoi */

import { apiUrl } from './native';

/** Adresse du logo (la date de mise à jour force le rechargement après un changement), ou null */
export function logoSrc(company: { id: string; logoUpdatedAt?: string | null } | null | undefined): string | null {
  return company?.logoUpdatedAt ? apiUrl(`/logos/${company.id}?v=${Date.parse(company.logoUpdatedAt)}`) : null;
}

/**
 * Prépare le fichier choisi (PNG, JPEG, SVG, WebP…) : réduit à 800 × 400 au plus et converti en PNG
 * (transparence gardée), le seul format que tous les documents PDF savent afficher.
 */
export async function logoToPng(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = () => reject(new Error('image illisible'));
      i.src = url;
    });
    const w0 = img.naturalWidth || 400;
    const h0 = img.naturalHeight || 200;
    const scale = Math.min(1, 800 / w0, 400 / h0);
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(w0 * scale));
    canvas.height = Math.max(1, Math.round(h0 * scale));
    canvas.getContext('2d')!.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/png');
  } finally {
    URL.revokeObjectURL(url);
  }
}
