/**
 * Édition de ce logiciel, fixée à la construction (variable EDITION, voir vite.config.ts) :
 * Itinéos (techniciens), Itinéos Vigie, Itinéos Constat, Itinéos Expertise, Itinéos Clés ou Itinéos Services.
 * Elle fixe le nom affiché, les couleurs, le vocabulaire et les menus.
 */
import {
  EDITION_THEMES, featureEnabled, isSector, moduleEnabled, productName, type Feature, type Module, type Sector,
} from '@itineo/shared';
import { setSector } from './i18n';

const raw: unknown = import.meta.env.VITE_EDITION;
export const EDITION: Sector = isSector(raw) ? raw : 'TECH';
export const PRODUCT_NAME = productName(EDITION);

/** Le module fait-il partie de cette édition ? (un commissaire de justice n'a pas de stock) */
export function hasModule(module: Module): boolean {
  return moduleEnabled(EDITION, module);
}

/** Fonction propre au métier de cette édition (points de passage, SOS, registre des traitements…) */
export function hasFeature(feature: Feature): boolean {
  return featureEnabled(EDITION, feature);
}

/** Couleurs et vocabulaire de l'édition : appelé une fois, avant le premier affichage */
export function applyEdition(): void {
  const theme = EDITION_THEMES[EDITION];
  const root = document.documentElement.style;
  root.setProperty('--accent', theme.accent);
  root.setProperty('--accent-text', theme.accentText);
  root.setProperty('--ink', theme.ink);
  root.setProperty('--ink-2', theme.ink2);
  setSector(EDITION);
}
