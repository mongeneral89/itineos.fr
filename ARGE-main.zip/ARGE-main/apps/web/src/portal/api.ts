/** Appels à l'API du portail client, avec la session du client (séparée de celle du bureau) */
import { ApiError } from '../api';
import { t, tServer } from '../i18n';
import { apiUrl } from '../native';

const KEY = 'itineo.portal.token';
export const PORTAL_SESSION_EXPIRED = 'itineo:portal-session-expired';

export function getPortalToken(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function setPortalToken(token: string | null) {
  try {
    if (token) localStorage.setItem(KEY, token);
    else localStorage.removeItem(KEY);
  } catch {
    /* stockage indisponible : la session ne survivra pas au rechargement */
  }
}

async function errorOf(res: Response): Promise<ApiError> {
  let payload: { error?: string; issues?: { message: string }[] } = {};
  try {
    payload = await res.json();
  } catch {
    /* réponse sans JSON */
  }
  const message = payload.issues?.length
    ? payload.issues.map((i) => tServer(i.message)).join(' · ')
    : payload.error ? tServer(payload.error) : t('Erreur {n}', { n: res.status });
  return new ApiError(res.status, message);
}

export async function portalApi<T>(path: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getPortalToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';
  let res: Response;
  try {
    res = await fetch(apiUrl(path), {
      method: options.method ?? 'GET',
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    throw new ApiError(0, t('Pas de connexion au serveur. Vérifiez le réseau.'));
  }
  if (res.status === 401 && token) {
    setPortalToken(null);
    window.dispatchEvent(new Event(PORTAL_SESSION_EXPIRED));
  }
  if (!res.ok) throw await errorOf(res);
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

/** Ouvre un PDF du portail dans un nouvel onglet (le téléchargement a besoin du jeton) */
export async function openPortalPdf(path: string) {
  const win = window.open('', '_blank');
  const res = await fetch(apiUrl(path), { headers: { Authorization: `Bearer ${getPortalToken() ?? ''}` } });
  if (!res.ok) {
    win?.close();
    throw await errorOf(res);
  }
  const url = URL.createObjectURL(await res.blob());
  if (win) win.location.href = url;
  else window.location.href = url;
}
