/** Pages de l'espace client */
import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  CONTRACT_FREQUENCIES, formatMoney, UI_LOCALE_LABELS, UI_LOCALES,
  type InterventionStatus, type PaymentState, type UiLocale,
} from '@itineo/shared';
import { useLoad } from '../hooks';
import { fmtDateTime, fmtDay } from '../format';
import { kindLabel, t, tl, tp } from '../i18n';
import { openPortalPdf, portalApi, setPortalToken } from './api';
import type { PortalContract, PortalIntervention, PortalInvoice, PortalMe, PortalQuote } from './types';

// Statuts dits du point de vue du client (traduits à l'affichage)
const STATUS_FOR_CLIENT: Record<InterventionStatus, string> = {
  TO_PLAN: 'Demande reçue', PLANNED: 'Rendez-vous fixé', EN_ROUTE: 'Technicien en route', ON_SITE: 'Technicien sur place',
  DONE: 'Terminée', TO_RESUME: 'Suite à prévoir', CANCELLED: 'Annulée',
};
const STATUS_TONE: Record<InterventionStatus, string> = {
  TO_PLAN: 'warn', PLANNED: 'info', EN_ROUTE: 'info', ON_SITE: 'dark', DONE: 'ok', TO_RESUME: 'warn', CANCELLED: 'neutral',
};
const INVOICE_STATE_FOR_CLIENT: Record<PaymentState, string> = {
  DRAFT: 'Brouillon', UNPAID: 'À régler', PARTIAL: 'Payée en partie', PAID: 'Payée', OVERDUE: 'En retard',
};
const INVOICE_TONE: Record<PaymentState, string> = { DRAFT: 'neutral', UNPAID: 'info', PARTIAL: 'info', PAID: 'ok', OVERDUE: 'warn' };

const money = (me: PortalMe, c: number, currency = me.company.currency) => formatMoney(c, currency, me.company.locale);

function Problem({ error }: { error: string | null }) {
  return error ? <p className="error" role="alert">{error}</p> : null;
}

function PdfButton({ path, label }: { path: string; label: string }) {
  const [error, setError] = useState<string | null>(null);
  return (
    <>
      <button type="button" className="secondary" onClick={() => { setError(null); openPortalPdf(path).catch((e) => setError((e as Error).message)); }}>{label}</button>
      {error && <span className="error small">{error}</span>}
    </>
  );
}

const frequency = (months: number) => {
  const f = CONTRACT_FREQUENCIES.find((x) => x.months === months);
  return f ? t(f.label) : t('Tous les {n} mois', { n: months });
};

// ─── Accueil ───

export function PortalHomePage({ me }: { me: PortalMe }) {
  const { data } = useLoad(async () => {
    const [ivs, quotes, invoices, contracts] = await Promise.all([
      portalApi<PortalIntervention[]>('/portal/interventions'),
      portalApi<PortalQuote[]>('/portal/quotes'),
      portalApi<PortalInvoice[]>('/portal/invoices'),
      portalApi<PortalContract[]>('/portal/contracts'),
    ]);
    return { ivs, quotes, invoices, contracts };
  }, []);
  const open = data?.ivs.filter((i) => i.status !== 'DONE') ?? [];
  const waiting = data?.quotes.filter((q) => q.status === 'SENT' && !q.expired) ?? [];
  const due = data?.invoices.reduce((s, i) => s + i.remainingCents, 0) ?? 0;
  const nextVisit = data?.contracts.map((c) => c.nextVisit).filter((d): d is string => !!d).sort()[0];

  return (
    <div className="stack">
      <div>
        <h1>{t('Bonjour {name}', { name: me.user.name })}</h1>
        <p className="muted" style={{ margin: '4px 0 0' }}>{t('Votre espace client chez {company}.', { company: me.company.name })}</p>
      </div>
      <div className="grid">
        <Link to="/portail/interventions" className="card portal-kpi">
          <span className="small muted">{t('Interventions en cours')}</span><strong>{open.length}</strong>
        </Link>
        <Link to="/portail/devis" className="card portal-kpi">
          <span className="small muted">{t('Devis en attente de réponse')}</span><strong>{waiting.length}</strong>
        </Link>
        <Link to="/portail/factures" className="card portal-kpi">
          <span className="small muted">{t('Reste à régler')}</span><strong>{money(me, due)}</strong>
        </Link>
        <Link to="/portail/contrats" className="card portal-kpi">
          <span className="small muted">{t("Prochaine visite d'entretien")}</span><strong>{nextVisit ? fmtDay(nextVisit) : '—'}</strong>
        </Link>
      </div>
      <section className="card row" style={{ justifyContent: 'space-between' }}>
        <div>
          <strong>{t('Un problème ? Une panne ?')}</strong>
          <div className="small muted">{t('Décrivez-le en ligne : votre demande arrive directement au planning.')}</div>
        </div>
        <Link className="btn accent" to="/portail/demande">{t('Demander une intervention')}</Link>
      </section>
      {open.length > 0 && (
        <section className="stack">
          <h2>{t('En cours')}</h2>
          {open.slice(0, 3).map((iv) => <InterventionCard key={iv.id} me={me} iv={iv} />)}
        </section>
      )}
    </div>
  );
}

// ─── Interventions ───

function InterventionCard({ me, iv }: { me: PortalMe; iv: PortalIntervention }) {
  return (
    <div className="card stack" style={{ gap: 6 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <strong>{iv.reason}</strong>
        <span className={`badge ${STATUS_TONE[iv.status]}`}>{tl(STATUS_FOR_CLIENT, iv.status)}</span>
      </div>
      <div className="small muted">
        {iv.number} · {kindLabel(iv.kind)} · {iv.siteName}{iv.siteCity ? `, ${iv.siteCity}` : ''}
      </div>
      <div className="small">
        {iv.scheduledStart
          ? t('Rendez-vous le {date}', { date: fmtDateTime(iv.scheduledStart, me.company.timezone) })
          : t('Demande du {date} : nous vous contactons pour fixer le rendez-vous.', { date: fmtDateTime(iv.createdAt, me.company.timezone) })}
        {iv.technicianFirstName && iv.status !== 'TO_PLAN' ? ` · ${t('Technicien : {name}', { name: iv.technicianFirstName })}` : ''}
      </div>
      {iv.hasReport && (
        <div className="row">
          <PdfButton path={`/portal/interventions/${iv.id}/report.pdf`} label={t("Fiche d'intervention signée (PDF)")} />
          {iv.signedAt && <span className="small muted">{t('Signée le {date}', { date: fmtDateTime(iv.signedAt, me.company.timezone) })}</span>}
        </div>
      )}
    </div>
  );
}

export function PortalInterventionsPage({ me }: { me: PortalMe }) {
  const { data, error } = useLoad(() => portalApi<PortalIntervention[]>('/portal/interventions'), []);
  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>{t('Vos interventions')}</h1>
        <Link className="btn accent" to="/portail/demande">{t('Demander une intervention')}</Link>
      </div>
      <Problem error={error} />
      {data && !data.length && <p className="muted">{t('Aucune intervention pour le moment.')}</p>}
      {data?.map((iv) => <InterventionCard key={iv.id} me={me} iv={iv} />)}
    </div>
  );
}

// ─── Devis ───

function QuoteDecision({ me, quote, onDone }: { me: PortalMe; quote: PortalQuote; onDone: () => void }) {
  const [decision, setDecision] = useState<'ACCEPTED' | 'REFUSED' | null>(null);
  const [name, setName] = useState(me.user.name);
  const [note, setNote] = useState('');
  const [agree, setAgree] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!decision) {
    return (
      <div className="row">
        <button type="button" className="accent" onClick={() => setDecision('ACCEPTED')}>{t('Accepter le devis')}</button>
        <button type="button" className="secondary" onClick={() => setDecision('REFUSED')}>{t('Refuser')}</button>
      </div>
    );
  }
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await portalApi(`/portal/quotes/${quote.id}/decision`, { method: 'POST', body: { decision, name, note: note || undefined } });
      onDone();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const accept = decision === 'ACCEPTED';
  return (
    <form className="stack portal-decision" onSubmit={submit}>
      <strong>{accept ? t('Accepter le devis {num}', { num: quote.number }) : t('Refuser le devis {num}', { num: quote.number })}</strong>
      <div className="field"><label htmlFor={`dn-${quote.id}`}>{t('Votre nom')}</label><input id={`dn-${quote.id}`} value={name} onChange={(e) => setName(e.target.value)} required /></div>
      <div className="field"><label htmlFor={`dc-${quote.id}`}>{accept ? t('Commentaire ou disponibilités (facultatif)') : t('Pouvez-vous nous dire pourquoi ? (facultatif)')}</label>
        <textarea id={`dc-${quote.id}`} rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></div>
      {accept && (
        <label className="check">
          <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
          {t('Bon pour accord : j’ai lu le devis de {amount} TTC et j’en accepte les conditions.', { amount: money(me, quote.grossCents, quote.currency) })}
        </label>
      )}
      <Problem error={error} />
      <div className="row">
        <button type="submit" className={accept ? 'accent' : ''} disabled={busy || !name.trim() || (accept && !agree)}>{accept ? t("Confirmer l'accord") : t('Confirmer le refus')}</button>
        <button type="button" className="ghost" onClick={() => setDecision(null)}>{t('Annuler')}</button>
      </div>
    </form>
  );
}

export function PortalQuotesPage({ me }: { me: PortalMe }) {
  const { data, error, reload } = useLoad(() => portalApi<PortalQuote[]>('/portal/quotes'), []);
  const [done, setDone] = useState<string | null>(null);
  const badge = (q: PortalQuote) => {
    if (q.status === 'SENT' && q.expired) return <span className="badge neutral">{t('Expiré')}</span>;
    if (q.status === 'SENT') return <span className="badge warn">{t('En attente de votre réponse')}</span>;
    return <span className={`badge ${q.status === 'ACCEPTED' ? 'ok' : 'neutral'}`}>{q.status === 'ACCEPTED' ? t('Accepté') : t('Refusé')}</span>;
  };
  return (
    <div className="stack">
      <h1>{t('Vos devis')}</h1>
      <Problem error={error} />
      {done && <p className="success" role="status">{done}</p>}
      {data && !data.length && <p className="muted">{t('Aucun devis pour le moment.')}</p>}
      {data?.map((q) => (
        <div key={q.id} className="card stack" style={{ gap: 8 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <strong>{q.title}</strong>
            {badge(q)}
          </div>
          <div className="small muted">
            {q.number}{q.siteName ? ` · ${q.siteName}` : ''} · {t('reçu le {date}', { date: fmtDay(q.sentAt?.slice(0, 10)) })}
            {q.validUntil ? ` · ${t("valable jusqu'au {date}", { date: fmtDay(q.validUntil) })}` : ''}
          </div>
          <div><strong>{money(me, q.grossCents, q.currency)}</strong> <span className="small muted">{t('TTC')} · {t('{amount} HT', { amount: money(me, q.netCents, q.currency) })}</span></div>
          {q.decidedAt && q.decisionName && (
            <div className="small">{t('Réponse de {name} le {date}', { name: q.decisionName, date: fmtDateTime(q.decidedAt, me.company.timezone) })}</div>
          )}
          <div className="row"><PdfButton path={`/portal/quotes/${q.id}/pdf`} label={t('Voir le devis (PDF)')} /></div>
          {q.status === 'SENT' && !q.expired && (
            <QuoteDecision me={me} quote={q} onDone={() => {
              setDone(t('Merci, votre réponse a été transmise à {company}.', { company: me.company.name }));
              void reload();
            }} />
          )}
          {q.status === 'SENT' && q.expired && <p className="small muted" style={{ margin: 0 }}>{t('Ce devis a expiré : contactez-nous pour en recevoir un nouveau.')}</p>}
        </div>
      ))}
    </div>
  );
}

// ─── Factures ───

export function PortalInvoicesPage({ me }: { me: PortalMe }) {
  const { data, error } = useLoad(() => portalApi<PortalInvoice[]>('/portal/invoices'), []);
  const due = data?.reduce((s, i) => s + i.remainingCents, 0) ?? 0;
  return (
    <div className="stack">
      <h1>{t('Vos factures')}</h1>
      <Problem error={error} />
      {data && data.length > 0 && <p style={{ margin: 0 }}>{t('Reste à régler :')} <strong>{money(me, due)}</strong></p>}
      {data && !data.length && <p className="muted">{t('Aucune facture pour le moment.')}</p>}
      {/* Sur téléphone : une fiche par facture (le tableau serait illisible) */}
      {data && data.length > 0 && (
        <div className="stack portal-cards">
          {data.map((i) => {
            const credit = i.kind === 'CREDIT_NOTE';
            return (
              <div key={i.id} className="card stack" style={{ gap: 6 }}>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <strong>{credit ? t('Avoir') : t('Facture')} {i.number}</strong>
                  {credit ? <span className="badge neutral">{t('Avoir')}</span> : <span className={`badge ${INVOICE_TONE[i.state]}`}>{tl(INVOICE_STATE_FOR_CLIENT, i.state)}</span>}
                </div>
                <div className="small">{i.title}</div>
                <div className="small muted">
                  {fmtDay(i.issueDate)}{!credit && i.dueDate ? ` · ${t('échéance le {date}', { date: fmtDay(i.dueDate) })}` : ''}
                </div>
                <div>
                  <strong>{credit ? '− ' : ''}{money(me, i.grossCents, i.currency)}</strong> <span className="small muted">{t('TTC')}</span>
                  {i.remainingCents > 0 && <span className="small"> · {t('Reste à régler :')} {money(me, i.remainingCents, i.currency)}</span>}
                </div>
                <div><PdfButton path={`/portal/invoices/${i.id}/pdf`} label={t('Voir la facture (PDF)')} /></div>
              </div>
            );
          })}
        </div>
      )}
      {data && data.length > 0 && (
        <section className="card portal-table">
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('N°')}</th><th>{t('Objet')}</th><th>{t('Date')}</th><th>{t('Échéance')}</th><th style={{ textAlign: 'right' }}>{t('Total TTC')}</th><th style={{ textAlign: 'right' }}>{t('Reste')}</th><th>{t('État')}</th><th /></tr></thead>
              <tbody>
                {data.map((i) => {
                  const credit = i.kind === 'CREDIT_NOTE';
                  return (
                    <tr key={i.id}>
                      <td><strong>{i.number}</strong>{credit && <div className="small muted">{t('Avoir')}</div>}</td>
                      <td>{i.title}</td>
                      <td className="small">{fmtDay(i.issueDate)}</td>
                      <td className="small">{credit ? '—' : fmtDay(i.dueDate)}</td>
                      <td style={{ textAlign: 'right' }}>{credit ? '− ' : ''}{money(me, i.grossCents, i.currency)}</td>
                      <td style={{ textAlign: 'right' }}>{i.remainingCents ? money(me, i.remainingCents, i.currency) : '—'}</td>
                      <td>{credit ? <span className="badge neutral">{t('Avoir')}</span> : <span className={`badge ${INVOICE_TONE[i.state]}`}>{tl(INVOICE_STATE_FOR_CLIENT, i.state)}</span>}</td>
                      <td><PdfButton path={`/portal/invoices/${i.id}/pdf`} label={t('PDF')} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}
      <p className="small muted">{t('Pour régler, utilisez les coordonnées bancaires indiquées sur chaque facture.')}</p>
    </div>
  );
}

// ─── Contrats ───

export function PortalContractsPage({ me }: { me: PortalMe }) {
  const { data, error } = useLoad(() => portalApi<PortalContract[]>('/portal/contracts'), []);
  return (
    <div className="stack">
      <h1>{t("Vos contrats d'entretien")}</h1>
      <Problem error={error} />
      {data && !data.length && <p className="muted">{t("Aucun contrat d'entretien en cours.")}</p>}
      {data?.map((c) => (
        <div key={c.id} className="card stack" style={{ gap: 6 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <strong>{c.title}</strong>
            <span className={`badge ${c.status === 'ACTIVE' ? 'ok' : 'warn'}`}>{c.status === 'ACTIVE' ? t('Actif') : t('Suspendu')}</span>
          </div>
          <div className="small muted">{c.number} · {c.siteName}{c.siteCity ? `, ${c.siteCity}` : ''} · {frequency(c.frequencyMonths)}</div>
          <div className="small">
            {c.nextVisit ? t('Prochaine visite prévue vers le {date} : nous vous contactons pour fixer le rendez-vous.', { date: fmtDay(c.nextVisit) }) : '—'}
          </div>
        </div>
      ))}
      <p className="small muted">{tp(me.sites.length, 'Votre matériel est suivi sur {n} site.', 'Votre matériel est suivi sur {n} sites.')}</p>
    </div>
  );
}

// ─── Demande d'intervention ───

export function PortalRequestPage({ me }: { me: PortalMe }) {
  const [siteId, setSiteId] = useState(me.sites[0]?.id ?? '');
  const [equipmentId, setEquipmentId] = useState('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [urgent, setUrgent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<{ number: string } | null>(null);
  const site = me.sites.find((s) => s.id === siteId);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await portalApi<{ number: string }>('/portal/requests', {
        method: 'POST', body: { siteId, equipmentId: equipmentId || null, reason, clientNotes: notes || undefined, urgent },
      });
      setSent(res);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    return (
      <section className="card stack" style={{ maxWidth: 640 }}>
        <h1>{t('Demande envoyée')}</h1>
        <p className="success" role="status">{t('Votre demande {num} a bien été reçue. Nous vous contactons pour fixer le rendez-vous ; un e-mail de confirmation vient de partir.', { num: sent.number })}</p>
        <div className="row">
          <Link className="btn" to="/portail/interventions">{t('Suivre mes interventions')}</Link>
          <button type="button" className="secondary" onClick={() => { setSent(null); setReason(''); setNotes(''); setUrgent(false); }}>{t('Faire une autre demande')}</button>
        </div>
      </section>
    );
  }

  return (
    <form className="card stack" style={{ maxWidth: 720 }} onSubmit={submit}>
      <h1>{t('Demander une intervention')}</h1>
      <div className="row">
        <div className="field grow" style={{ minWidth: 220 }}>
          <label htmlFor="r-site">{t('Lieu')}</label>
          <select id="r-site" value={siteId} onChange={(e) => { setSiteId(e.target.value); setEquipmentId(''); }} required>
            {me.sites.map((s) => <option key={s.id} value={s.id}>{s.name}{s.city ? ` · ${s.city}` : ''}</option>)}
          </select>
        </div>
        <div className="field grow" style={{ minWidth: 220 }}>
          <label htmlFor="r-eq">{t('Matériel concerné')}</label>
          <select id="r-eq" value={equipmentId} onChange={(e) => setEquipmentId(e.target.value)}>
            <option value="">{t('Je ne sais pas / autre')}</option>
            {site?.equipments.map((eq) => (
              <option key={eq.id} value={eq.id}>{[eq.category, eq.brand, eq.model].filter(Boolean).join(' ')}{eq.location ? ` · ${eq.location}` : ''}</option>
            ))}
          </select>
        </div>
      </div>
      <div className="field">
        <label htmlFor="r-reason">{t('Le problème')}</label>
        <textarea id="r-reason" rows={4} value={reason} onChange={(e) => setReason(e.target.value)} required
          placeholder={t('Ex. : la climatisation ne démarre plus, un voyant rouge clignote.')} />
      </div>
      <div className="field">
        <label htmlFor="r-notes">{t('Vos disponibilités, accès, personne à contacter (facultatif)')}</label>
        <textarea id="r-notes" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
      <label className="check"><input type="checkbox" checked={urgent} onChange={(e) => setUrgent(e.target.checked)} />{t("C'est urgent (sécurité, panne totale, fuite…)")}</label>
      <Problem error={error} />
      <div><button type="submit" className="accent big" disabled={busy || !siteId || reason.trim().length < 3}>{busy ? t('Envoi…') : t('Envoyer la demande')}</button></div>
    </form>
  );
}

// ─── Compte ───

export function PortalAccountPage({ me, onChanged }: { me: PortalMe; onChanged: () => Promise<void> }) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const lang = UI_LOCALES.find((l) => l.slice(0, 2) === me.user.locale.slice(0, 2)) ?? 'fr-FR';

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setDone(false);
    if (next !== confirm) return setError(t('Les deux mots de passe ne sont pas identiques'));
    setError(null);
    try {
      const res = await portalApi<{ token: string }>('/portal/auth/change-password', { method: 'POST', body: { currentPassword: current, newPassword: next } });
      setPortalToken(res.token);
      setCurrent('');
      setNext('');
      setConfirm('');
      setDone(true);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <div className="stack" style={{ maxWidth: 520 }}>
      <h1>{t('Mon compte')}</h1>
      <section className="card stack">
        <div><strong>{me.user.name}</strong><div className="small muted">{me.user.email}</div></div>
        <div className="small">{me.client.name}{me.client.city ? ` · ${me.client.city}` : ''}</div>
        <div className="field">
          <label htmlFor="pc-lang">{t('Langue')}</label>
          <select id="pc-lang" value={lang} onChange={(e) => {
            void portalApi('/portal/me', { method: 'PATCH', body: { locale: e.target.value as UiLocale } }).then(onChanged).catch((err) => setError((err as Error).message));
          }}>
            {UI_LOCALES.map((l) => <option key={l} value={l}>{UI_LOCALE_LABELS[l]}</option>)}
          </select>
        </div>
      </section>
      <form className="card stack" onSubmit={submit}>
        <h2 style={{ fontSize: 18 }}>{t('Changer mon mot de passe')}</h2>
        <div className="field"><label htmlFor="pc-cur">{t('Mot de passe actuel')}</label><input id="pc-cur" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required /></div>
        <div className="field"><label htmlFor="pc-new">{t('Nouveau mot de passe')}</label><input id="pc-new" type="password" autoComplete="new-password" minLength={8} value={next} onChange={(e) => setNext(e.target.value)} required /></div>
        <div className="field"><label htmlFor="pc-conf">{t('Confirmer le nouveau mot de passe')}</label><input id="pc-conf" type="password" autoComplete="new-password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required /></div>
        <Problem error={error} />
        {done && <p className="success" role="status">{t('Mot de passe changé.')}</p>}
        <div><button type="submit">{t('Enregistrer')}</button></div>
      </form>
      <p className="small muted">{tp(me.sites.length, '{n} site suivi', '{n} sites suivis')}</p>
    </div>
  );
}
