/**
 * Portail client : l'espace où chaque client de l'entreprise suit ses interventions, ses devis et ses factures,
 * et demande une intervention. Adresse : /portail. Session séparée de celle du bureau.
 */
import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { setLang, t } from '../i18n';
import { getPortalToken, portalApi, PORTAL_SESSION_EXPIRED, setPortalToken } from './api';
import type { PortalMe } from './types';
import {
  PortalAccountPage, PortalContractsPage, PortalHomePage, PortalInterventionsPage, PortalInvoicesPage, PortalQuotesPage, PortalRequestPage,
} from './PortalPages';

export function PortalApp() {
  const [me, setMe] = useState<PortalMe | null>(null);
  const [loading, setLoading] = useState(!!getPortalToken());
  const { pathname } = useLocation();
  const navigate = useNavigate();

  const load = useCallback(async () => {
    if (!getPortalToken()) {
      setMe(null);
      setLoading(false);
      return;
    }
    try {
      const m = await portalApi<PortalMe>('/portal/me');
      setLang(m.user.locale);
      setMe(m);
    } catch {
      setMe(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const onExpired = () => setMe(null);
    window.addEventListener(PORTAL_SESSION_EXPIRED, onExpired);
    return () => window.removeEventListener(PORTAL_SESSION_EXPIRED, onExpired);
  }, [load]);

  const signedIn = async (token: string) => {
    setPortalToken(token);
    setLoading(true);
    await load();
    navigate('/portail', { replace: true });
  };

  if (pathname === '/portail/activer') return <PortalActivate onDone={signedIn} />;
  if (loading) return <div className="login"><p className="muted">{t('Chargement…')}</p></div>;
  if (!me) return <PortalLogin onDone={signedIn} />;

  const logout = () => {
    setPortalToken(null);
    setMe(null);
    navigate('/portail', { replace: true });
  };

  return (
    <PortalLayout me={me} onLogout={logout}>
      <Routes>
        <Route path="/portail" element={<PortalHomePage me={me} />} />
        <Route path="/portail/interventions" element={<PortalInterventionsPage me={me} />} />
        <Route path="/portail/devis" element={<PortalQuotesPage me={me} />} />
        <Route path="/portail/factures" element={<PortalInvoicesPage me={me} />} />
        <Route path="/portail/contrats" element={<PortalContractsPage me={me} />} />
        <Route path="/portail/demande" element={<PortalRequestPage me={me} />} />
        <Route path="/portail/compte" element={<PortalAccountPage me={me} onChanged={load} />} />
        <Route path="*" element={<Navigate to="/portail" replace />} />
      </Routes>
    </PortalLayout>
  );
}

function PortalLayout({ me, onLogout, children }: { me: PortalMe; onLogout: () => void; children: ReactNode }) {
  const tabs: [string, string][] = [
    ['/portail', 'Accueil'], ['/portail/interventions', 'Interventions'], ['/portail/devis', 'Devis'],
    ['/portail/factures', 'Factures'], ['/portail/contrats', 'Contrats'], ['/portail/compte', 'Mon compte'],
  ];
  return (
    <div className="portal">
      <header className="portal-header">
        <div className="portal-wrap row" style={{ justifyContent: 'space-between' }}>
          <div className="row" style={{ gap: 12 }}>
            {me.company.logoUrl && <img className="company-logo" src={me.company.logoUrl} alt={me.company.name} />}
            <div>
            <div className="small" style={{ opacity: 0.75 }}>{t('Espace client')} · {me.company.name}</div>
            <div className="portal-brand">{me.client.name}</div>
            </div>
          </div>
          <div className="row" style={{ gap: 8 }}>
            <span className="small" style={{ opacity: 0.85 }}>{me.user.name}</span>
            <button type="button" className="secondary" style={{ color: '#F4F2EE', borderColor: '#3A4150', minHeight: 36 }} onClick={onLogout}>{t('Se déconnecter')}</button>
          </div>
        </div>
        <nav className="portal-wrap portal-tabs" aria-label={t('Menu principal')}>
          {tabs.map(([to, label]) => <NavLink key={to} to={to} end>{t(label)}</NavLink>)}
          <NavLink to="/portail/demande" className="portal-cta">{t('Demander une intervention')}</NavLink>
        </nav>
      </header>
      <main className="portal-wrap portal-main">{children}</main>
      <footer className="portal-wrap small muted portal-footer">
        {me.company.name}{me.company.phone ? ` · ${me.company.phone}` : ''}{me.company.email ? ` · ${me.company.email}` : ''}
      </footer>
    </div>
  );
}

// ─── Connexion ───

function PortalLogin({ onDone }: { onDone: (token: string) => Promise<void> }) {
  const [mode, setMode] = useState<'login' | 'forgot' | 'sent'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === 'forgot') {
        await portalApi('/portal/auth/forgot', { method: 'POST', body: { email } });
        setMode('sent');
      } else {
        const res = await portalApi<{ token: string }>('/portal/auth/login', { method: 'POST', body: { email, password } });
        await onDone(res.token);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (mode === 'sent') {
    return (
      <div className="login">
        <div className="card">
          <h1>{t('Espace client')}</h1>
          <p className="success" role="status">{t('Si un compte existe pour {email}, un e-mail vient de partir avec un lien pour choisir un nouveau mot de passe.', { email })}</p>
          <button type="button" className="secondary" onClick={() => setMode('login')}>{t('Retour à la connexion')}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        <h1>{t('Espace client')}</h1>
        <p className="muted">
          {mode === 'forgot'
            ? t('Indiquez votre e-mail : vous recevrez un lien pour choisir un nouveau mot de passe.')
            : t('Suivez vos interventions, vos devis et vos factures, et demandez une intervention.')}
        </p>
        <div className="field">
          <label htmlFor="p-email">{t('E-mail')}</label>
          <input id="p-email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        {mode === 'login' && (
          <div className="field">
            <label htmlFor="p-password">{t('Mot de passe')}</label>
            <input id="p-password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
        )}
        {error && <p className="error" role="alert">{error}</p>}
        <button type="submit" className="big" disabled={busy}>
          {mode === 'forgot' ? (busy ? t('Envoi…') : t('Recevoir le lien')) : (busy ? t('Connexion…') : t('Se connecter'))}
        </button>
        <button type="button" className="ghost" onClick={() => { setMode(mode === 'login' ? 'forgot' : 'login'); setError(null); }}>
          {mode === 'login' ? t('Mot de passe oublié ?') : t('Retour à la connexion')}
        </button>
        <p className="small muted" style={{ margin: 0 }}>{t("Pas encore d'accès ? Demandez une invitation à votre interlocuteur habituel.")}</p>
      </form>
    </div>
  );
}

/** Lien reçu par e-mail (invitation ou mot de passe oublié) : choix du mot de passe */
function PortalActivate({ onDone }: { onDone: (token: string) => Promise<void> }) {
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const [info, setInfo] = useState<{ purpose: 'invite' | 'reset'; name: string; email: string; clientName: string; companyName: string; logoUrl?: string | null } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!token) return setError(t("Ce lien est incomplet. Recopiez-le en entier depuis l'e-mail, ou demandez-en un nouveau."));
    portalApi<typeof info & { locale: string }>(`/portal/auth/link?token=${encodeURIComponent(token)}`)
      .then((i) => {
        setLang(i!.locale);
        setInfo(i);
      })
      .catch((e) => setError((e as Error).message));
  }, [token]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (password !== confirm) return setError(t('Les deux mots de passe ne sont pas identiques'));
    setBusy(true);
    setError(null);
    try {
      const res = await portalApi<{ token: string }>('/portal/auth/activate', { method: 'POST', body: { token, password } });
      await onDone(res.token);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        {info?.logoUrl && <img className="company-logo" src={info.logoUrl} alt={info.companyName} />}
        <h1>{t('Espace client')}</h1>
        {info && (
          <p className="muted">
            {info.purpose === 'invite'
              ? t('Bonjour {name}, {company} vous ouvre son espace client pour {client}. Choisissez votre mot de passe.', { name: info.name, company: info.companyName, client: info.clientName })
              : t('Bonjour {name}, choisissez votre nouveau mot de passe.', { name: info.name })}
            <br /><span className="small">{info.email}</span>
          </p>
        )}
        {error && <p className="error" role="alert">{error}</p>}
        {info && (
          <>
            <div className="field">
              <label htmlFor="pa-new">{t('Nouveau mot de passe')}</label>
              <input id="pa-new" type="password" autoComplete="new-password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <div className="field">
              <label htmlFor="pa-confirm">{t('Confirmer le mot de passe')}</label>
              <input id="pa-confirm" type="password" autoComplete="new-password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
            </div>
            <p className="small muted" style={{ margin: 0 }}>{t('Au moins 8 caractères.')}</p>
            <button type="submit" className="big" disabled={busy}>{busy ? t('Enregistrement…') : t('Accéder à mon espace')}</button>
          </>
        )}
        {!info && error && <a href="/portail" className="small">{t('Retour à la connexion')}</a>}
      </form>
    </div>
  );
}
