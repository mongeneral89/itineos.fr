import type { ContractStatus, InterventionKind, InterventionStatus, InvoiceKind, PaymentState, QuoteKind, QuoteStatus } from '@itineo/shared';

export interface PortalMe {
  user: { id: string; name: string; email: string; locale: string };
  client: { id: string; name: string; email: string | null; phone: string | null; address: string | null; postalCode: string | null; city: string | null };
  company: { name: string; email: string | null; phone: string | null; locale: string; currency: string; timezone: string; logoUrl?: string | null };
  sites: {
    id: string; name: string; address: string | null; postalCode: string | null; city: string | null;
    equipments: { id: string; category: string; brand: string | null; model: string | null; serialNumber: string | null; location: string | null; underContract: boolean }[];
  }[];
}

export interface PortalIntervention {
  id: string; number: string; kind: InterventionKind; status: InterventionStatus; reason: string; source: string | null;
  scheduledStart: string | null; scheduledEnd: string | null; createdAt: string; siteName: string; siteCity: string | null;
  technicianFirstName: string | null; reportStatus: string | null; signedAt: string | null; sentAt: string | null;
  outcome: string | null; hasReport: boolean;
}

export interface PortalQuote {
  id: string; number: string; kind: QuoteKind; status: QuoteStatus; title: string; validUntil: string | null;
  netCents: number; grossCents: number; currency: string; sentAt: string | null; decidedAt: string | null;
  decisionName: string | null; siteName: string | null; expired: boolean;
}

export interface PortalInvoice {
  id: string; kind: InvoiceKind; number: string; title: string; issueDate: string; dueDate: string | null;
  grossCents: number; currency: string; paidCents: number; remainingCents: number; state: PaymentState;
}

export interface PortalContract {
  id: string; number: string; title: string; status: ContractStatus; frequencyMonths: number; startDate: string;
  endDate: string | null; siteName: string; siteCity: string | null; nextVisit: string | null;
}
