import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from './auth';
import { t } from './i18n';
import { Layout } from './components/Layout';
import { LoginPage } from './pages/Login';
import { ResetPasswordPage } from './pages/ResetPassword';
import { InvitationPage, OpenAppPage } from './pages/Invitation';
import { AccountPage } from './pages/Account';
import { DashboardPage } from './pages/Dashboard';
import { PlanningPage } from './pages/Planning';
import { InterventionsPage } from './pages/Interventions';
import { InterventionNewPage } from './pages/InterventionNew';
import { InterventionDetailPage } from './pages/InterventionDetail';
import { ClientsPage } from './pages/Clients';
import { ClientDetailPage } from './pages/ClientDetail';
import { OrganisationPage } from './pages/Organisation';
import { TemplatesPage } from './pages/Templates';
import { QuotesPage } from './pages/Quotes';
import { QuoteEditPage } from './pages/QuoteEdit';
import { ContractEditPage, ContractsPage } from './pages/Contracts';
import { InvoicesPage } from './pages/Invoices';
import { BillingPage } from './pages/Billing';
import { InvoiceEditPage } from './pages/InvoiceEdit';
import { StockPage } from './pages/Stock';
import { SlipEditPage } from './pages/SlipEdit';
import { FleetPage } from './pages/Fleet';
import { VehicleDetailPage } from './pages/VehicleDetail';
import { CertificationsPage } from './pages/Certifications';
import { MessagesPage } from './pages/Messages';
import { DirectoryPage } from './pages/Directory';
import { ProceduresPage } from './pages/Procedures';
import { TeamPlanningPage } from './tech/TeamPlanning';
import { SimsPage } from './pages/Sims';
import { StatsPage } from './pages/Stats';
import { TechDayPage } from './tech/TechDay';
import { TechReportPage } from './tech/TechReport';
import { PortalApp } from './portal/PortalApp';
import { hasFeature, hasModule } from './edition';
import { TreatmentsPage } from './pages/Treatments';
import { FieldShell } from './tech/FieldShell';
import { MorePage } from './tech/MorePage';
import { isNativeApp } from './native';

export function App() {
  const { me, loading, isTechnicianOnly, has } = useAuth();
  const { pathname } = useLocation();

  // Espace client : application à part, avec sa propre session
  if (pathname === '/portail' || pathname.startsWith('/portail/')) return <PortalApp />;
  // Lien reçu par e-mail : accessible connecté ou non
  if (pathname === '/reset-password') return <ResetPasswordPage />;
  // Lien d'invitation : la page reste affichée une fois connecté (étapes pour installer l'appli)
  if (pathname === '/invitation') return <InvitationPage />;
  if (pathname === '/ouvrir') return <OpenAppPage />;
  if (loading) return <div className="login"><p className="muted">{t('Chargement…')}</p></div>;
  if (!me) return <LoginPage />;

  // Le bureau arrive sur « Aujourd'hui » (les chiffres du mois n'y sont montrés qu'à qui peut les voir)
  const home = isTechnicianOnly ? '/tech' : has('intervention.read') ? '/dashboard' : '/planning';
  // Messagerie, annuaire, notices et compte : dans l'appli terrain pour les techniciens et dans l'appli Android,
  // dans le bureau pour les autres
  const field = isTechnicianOnly || isNativeApp();
  const shared = (
    <>
      <Route path="/messages" element={<MessagesPage />} />
      <Route path="/directory" element={<DirectoryPage />} />
      <Route path="/procedures" element={<ProceduresPage />} />
    </>
  );

  return (
    <Routes>
      {/* Appli terrain : pensée pour téléphone et tablette, onglets en bas */}
      <Route element={<FieldShell />}>
        <Route path="/tech" element={<TechDayPage />} />
        <Route path="/tech/team" element={<TeamPlanningPage />} />
        <Route path="/tech/more" element={<MorePage />} />
        {field && shared}
        {field && <Route path="/account" element={<AccountPage />} />}
      </Route>
      {/* La fiche d'intervention : plein écran, sans les onglets, pour se concentrer dessus */}
      <Route path="/tech/:id" element={<TechReportPage />} />
      {!field && <Route path="/account" element={<AccountPage />} />}

      {/* Bureau (les modules absents de l'édition n'ont pas de page : retour à l'accueil) */}
      <Route element={<Layout />}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/planning" element={<PlanningPage />} />
        <Route path="/interventions" element={<InterventionsPage />} />
        <Route path="/interventions/new" element={<InterventionNewPage />} />
        <Route path="/interventions/:id" element={<InterventionDetailPage />} />
        <Route path="/clients" element={<ClientsPage />} />
        <Route path="/clients/:id" element={<ClientDetailPage />} />
        <Route path="/organisation" element={<OrganisationPage />} />
        <Route path="/templates" element={<TemplatesPage />} />
        {hasModule('quotes') && (
          <>
            <Route path="/quotes" element={<QuotesPage />} />
            <Route path="/quotes/:id" element={<QuoteEditPage />} />
          </>
        )}
        {hasModule('contracts') && (
          <>
            <Route path="/contracts" element={<ContractsPage />} />
            <Route path="/contracts/:id" element={<ContractEditPage />} />
          </>
        )}
        {hasModule('invoices') && (
          <>
            <Route path="/invoices" element={<InvoicesPage />} />
            <Route path="/billing" element={<BillingPage />} />
            <Route path="/invoices/:id" element={<InvoiceEditPage />} />
          </>
        )}
        {hasModule('stock') && (
          <>
            <Route path="/stock" element={<StockPage />} />
            <Route path="/stock/slips/:id" element={<SlipEditPage />} />
          </>
        )}
        {hasModule('fleet') && (
          <>
            <Route path="/fleet" element={<FleetPage />} />
            <Route path="/fleet/:id" element={<VehicleDetailPage />} />
          </>
        )}
        {hasModule('certifications') && <Route path="/certifications" element={<CertificationsPage />} />}
        {!field && shared}
        {hasModule('sims') && <Route path="/sims" element={<SimsPage />} />}
        <Route path="/stats" element={<StatsPage />} />
        {hasFeature('treatmentRegister') && <Route path="/treatments" element={<TreatmentsPage />} />}
      </Route>
      <Route path="*" element={<Navigate to={home} replace />} />
    </Routes>
  );
}
