import { StrictMode, useSyncExternalStore, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from './auth';
import { App } from './App';
import { langVersion, setLangLoader, subscribeLang } from './i18n';
import { applyEdition } from './edition';
import './styles.css';
import { isNativeApp } from './native';
import { CLIENT } from './client';
import { UpdateBanner } from './tech/AppUpdate';
import { AndroidBackButton } from './tech/BackButton';
import { NativePush } from './tech/push-native';
import { DeepLinkLogin } from './tech/DeepLinkLogin';

// Nom, couleurs et vocabulaire de cette édition (Itinéos Vigie, Itinéos Constat…)
applyEdition();

// Dictionnaires des langues autres que le français et l'anglais : chargés seulement pour qui en a besoin
const LOCALES = import.meta.glob<Record<string, string>>('./locales/*.json', { import: 'default' });
setLangLoader(async (lang) => {
  const load = LOCALES[`./locales/${lang}.json`];
  if (!load) throw new Error(`pas de dictionnaire pour ${lang}`);
  return load();
});

/** Quand un dictionnaire arrive (ou que la langue change), tout l'écran est redessiné dans la bonne langue */
function LangGate({ children }: { children: ReactNode }) {
  const v = useSyncExternalStore(subscribeLang, langVersion);
  return <div key={v} style={{ display: 'contents' }}>{children}</div>;
}

// Appli Android : pas de zoom à deux doigts ni au double appui, l'écran reste à la taille du téléphone
// (la taille du texte des réglages d'Android est aussi ignorée : voir MainActivity.java)
if (isNativeApp()) {
  document.querySelector('meta[name="viewport"]')?.setAttribute('content',
    'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');
}

// Version d'un client avec sa vraie appli (A.R.G.E.) : sur un téléphone, le navigateur ne propose pas d'installer
// la version web (« Installer l'application ») ; les techniciens passent par l'APK (page d'invitation)
if (CLIENT && !isNativeApp() && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) {
  document.querySelector('link[rel="manifest"]')?.remove();
  window.addEventListener('beforeinstallprompt', (e) => e.preventDefault());
}

// L'appli est gardée sur l'appareil pour s'ouvrir sans réseau (en production uniquement :
// en développement, Vite recharge les fichiers à chaque modification). Inutile dans l'appli Android,
// qui contient déjà tous ses fichiers.
if (import.meta.env.PROD && !isNativeApp() && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('[sw] enregistrement impossible', err));
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <LangGate>
          {/* Appli Android : nouvelle version disponible */}
          <UpdateBanner />
          {/* Appli Android : le retour (geste ou bouton) navigue dans l'appli au lieu de la quitter */}
          <AndroidBackButton />
          <NativePush />
          <DeepLinkLogin />
          <App />
        </LangGate>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>,
);
