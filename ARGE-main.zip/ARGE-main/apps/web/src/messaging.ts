/** Messagerie interne : types, nombre de messages non lus (pastille du menu), messages du système */
import { useEffect, useState } from 'react';
import { api } from './api';
import { t } from './i18n';

export interface Person { id: string; firstName: string; lastName: string; roles: string[]; places: string[] }
export interface Member { id: string; firstName: string; lastName: string; active: boolean }
export interface Conversation {
  id: string; kind: 'DIRECT' | 'GROUP'; title: string | null; createdAt: string; lastMessageAt: string;
  members: Member[];
  lastMessage: { id: string; senderId: string | null; body: string; attachmentName: string | null; deleted: boolean; createdAt: string } | null;
  unread: number;
}
export interface Attachment { name: string; mime: string; size: number }
export interface Message {
  id: string; conversationId: string; senderId: string | null; body: string;
  attachment: Attachment | null;
  createdAt: string; editedAt: string | null; deletedAt: string | null;
}

/** Nom affiché d'une conversation : son nom, ou la personne en face, ou la liste des membres */
export function conversationTitle(c: Conversation, meId: string): string {
  if (c.title) return c.title;
  const others = c.members.filter((m) => m.id !== meId);
  if (!others.length) return t('Conversation');
  return others.map((m) => `${m.firstName} ${m.lastName}`).join(', ');
}

/** Texte d'un message du système (« X a ajouté Y »), dans la langue de chacun */
export function systemText(body: string): string {
  try {
    const e = JSON.parse(body) as { e: string; by: string; names?: string; title?: string };
    if (e.e === 'created') return t('{by} a créé la conversation', { by: e.by });
    if (e.e === 'added') return t('{by} a ajouté {names}', { by: e.by, names: e.names ?? '' });
    if (e.e === 'left') return t('{by} a quitté la conversation', { by: e.by });
    if (e.e === 'renamed') return t('{by} a renommé la conversation « {title} »', { by: e.by, title: e.title ?? '' });
  } catch {
    /* texte libre */
  }
  return body;
}

/** Nombre de messages non lus, relu régulièrement (et tout de suite après une lecture : événement « itineo:read ») */
export function useUnreadMessages(intervalMs = 30_000): number {
  const [n, setN] = useState(0);
  useEffect(() => {
    let stop = false;
    const load = () => {
      if (document.visibilityState === 'hidden') return;
      api<{ unread: number }>('/messages/unread').then((r) => !stop && setN(r.unread)).catch(() => undefined);
    };
    load();
    const timer = window.setInterval(load, intervalMs);
    window.addEventListener('itineo:read', load);
    document.addEventListener('visibilitychange', load);
    return () => {
      stop = true;
      window.clearInterval(timer);
      window.removeEventListener('itineo:read', load);
      document.removeEventListener('visibilitychange', load);
    };
  }, [intervalMs]);
  return n;
}
