/**
 * Appli construite pour un client (VITE_CLIENT, voir .env.arge) : son nom et son logo sur l'écran de connexion,
 * avant que la société de la personne connectée soit connue. Sans VITE_CLIENT : l'édition seule.
 */
import argeLogo from '../brand/arge-logo.png';

const CLIENTS: Record<string, { name: string; logo: string }> = {
  ARGE: { name: 'Groupe A.R.G.E.', logo: argeLogo },
};

export const CLIENT = CLIENTS[import.meta.env.VITE_CLIENT ?? ''] ?? null;
