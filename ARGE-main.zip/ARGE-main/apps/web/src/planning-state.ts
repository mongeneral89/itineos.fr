/**
 * Où en est une intervention, et où en est un technicien dans sa journée : partagé par le planning et l'écran
 * « Aujourd'hui ». La couleur dit l'état ; le retard suit la même règle que le serveur (services/office-notify.ts).
 */
import { fmtTime } from './format';
import { t } from './i18n';
import type { InterventionRow } from './types';

export type State = 'planned' | 'late' | 'enroute' | 'onsite' | 'done' | 'resume';
export const STATES: { id: State; label: string; color: string }[] = [
  { id: 'planned', label: 'Planifiée', color: '#475569' },
  { id: 'enroute', label: 'En route', color: '#1D4ED8' },
  { id: 'onsite', label: 'Sur place', color: '#C2410C' },
  { id: 'done', label: 'Terminée', color: '#15803D' },
  { id: 'resume', label: 'À reprendre', color: '#7C3AED' },
  { id: 'late', label: 'En retard', color: '#B91C1C' },
];
export const STATE_COLOR = Object.fromEntries(STATES.map((x) => [x.id, x.color])) as Record<State, string>;
export const FREE_COLOR = '#9CA3AF';

/** Pas encore parti 15 minutes après l'heure prévue */
export const LATE_MIN = 15;

export function stateOf(iv: InterventionRow, now = Date.now()): State {
  switch (iv.status) {
    case 'EN_ROUTE': return 'enroute';
    case 'ON_SITE': return 'onsite';
    case 'DONE': return 'done';
    case 'TO_RESUME': return 'resume';
    default: return iv.scheduledStart && new Date(iv.scheduledStart).getTime() < now - LATE_MIN * 60_000 ? 'late' : 'planned';
  }
}
export const stateLabel = (iv: InterventionRow) => t(STATES.find((x) => x.id === stateOf(iv))!.label);

export const sameDay = (iso: string, d: Date) => {
  const x = new Date(iso);
  return x.getFullYear() === d.getFullYear() && x.getMonth() === d.getMonth() && x.getDate() === d.getDate();
};

/** Où en est le technicien maintenant, d'après ses interventions du jour */
export interface Live { state: State | 'free'; text: string; current?: InterventionRow }
export function liveOf(jobs: InterventionRow[]): Live | null {
  const today = jobs.filter((iv) => iv.scheduledStart && sameDay(iv.scheduledStart, new Date()));
  if (!today.length) return null;
  const onsite = today.find((iv) => iv.status === 'ON_SITE');
  if (onsite) return { state: 'onsite', text: `${t('Sur place')} · ${onsite.clientName}`, current: onsite };
  const enroute = today.find((iv) => iv.status === 'EN_ROUTE');
  if (enroute) return { state: 'enroute', text: `${t('En route')} · ${enroute.clientName}`, current: enroute };
  const late = today.find((iv) => stateOf(iv) === 'late');
  if (late) return { state: 'late', text: `${t('En retard')} · ${late.clientName}`, current: late };
  const next = today.filter((iv) => iv.status === 'PLANNED').sort((a, b) => a.scheduledStart!.localeCompare(b.scheduledStart!))[0];
  if (next) return { state: 'planned', text: t('Prochaine à {time}', { time: fmtTime(next.scheduledStart) }), current: next };
  return { state: 'free', text: t('Journée terminée') };
}
