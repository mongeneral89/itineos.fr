/**
 * « Document à remplir » d'une intervention : la fiche par défaut de son type, ou un autre modèle
 * (ex. « Consignes de télésurveillance »).
 */
import { useEffect, useState } from 'react';
import { api, qs } from '../api';
import { t } from '../i18n';

interface TemplateRow { id: string; name: string; kind: string; groupId: string | null }

export function TemplateSelect({ id, companyId, value, onChange, disabled }: {
  id: string; companyId: string | undefined; value: string; onChange: (v: string) => void; disabled?: boolean;
}) {
  const [list, setList] = useState<TemplateRow[]>([]);
  useEffect(() => {
    if (!companyId) return;
    api<TemplateRow[] | { templates: TemplateRow[] }>(`/templates${qs({ companyId })}`)
      .then((r) => setList(Array.isArray(r) ? r : r.templates))
      .catch(() => setList([]));
  }, [companyId]);
  return (
    <select id={id} value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
      <option value="">{t('Fiche par défaut (selon le type)')}</option>
      {list.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
    </select>
  );
}
