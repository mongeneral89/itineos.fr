/**
 * Invitation d'un collègue : le bureau crée son lien personnel (7 jours, usage unique) et l'envoie par WhatsApp,
 * par e-mail, en le copiant, ou en montrant un QR code à scanner. La personne choisit elle-même son mot de passe.
 */
import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { CLIENT } from '../client';
import { PRODUCT_NAME } from '../edition';
import { fmtDay } from '../format';
import { t } from '../i18n';

interface Invitation { url: string; expiresAt: string; firstName: string; phone: string | null; email: string }

/** « 06 12 34 56 78 » → « 33612345678 » (format attendu par WhatsApp) */
export function waNumber(phone: string | null): string {
  const digits = (phone ?? '').replace(/[^\d+]/g, '');
  if (digits.startsWith('+')) return digits.slice(1);
  if (digits.startsWith('00')) return digits.slice(2);
  if (digits.startsWith('0') && digits.length === 10) return `33${digits.slice(1)}`;
  return digits;
}

export function InvitePanel({ userId, onClose }: { userId: string; onClose: () => void }) {
  const [inv, setInv] = useState<Invitation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const qr = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api<Invitation>(`/users/${userId}/invitation`, { method: 'POST' }).then(setInv).catch((e) => setError((e as Error).message));
  }, [userId]);

  useEffect(() => {
    if (!showQr || !inv || !qr.current) return;
    const box = qr.current;
    void import('@zxing/browser').then(({ BrowserQRCodeSvgWriter }) => {
      box.replaceChildren(new BrowserQRCodeSvgWriter().write(inv.url, 240, 240));
    });
  }, [showQr, inv]);

  const app = CLIENT?.name ?? PRODUCT_NAME;
  const message = inv
    ? t('Bonjour {name}, voici votre accès à l’appli {app} : {url} (lien personnel, valable jusqu’au {date}). Ouvrez-le sur votre téléphone pour choisir votre mot de passe.', {
      name: inv.firstName, app, url: inv.url, date: fmtDay(inv.expiresAt.slice(0, 10)),
    })
    : '';
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(inv!.url);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="card stack invite-panel" role="region" aria-label={t('Invitation')}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h3>{t('Invitation')}{inv ? ` · ${inv.firstName}` : ''}</h3>
        <button type="button" className="ghost small" onClick={onClose}>{t('Fermer')}</button>
      </div>
      {error && <p className="error small">{error}</p>}
      {!inv && !error && <p className="muted small">{t('Chargement…')}</p>}
      {inv && (
        <>
          <p className="small muted">{t('Lien personnel, à usage unique, valable jusqu’au {date}. Il remplace les liens envoyés avant.', { date: fmtDay(inv.expiresAt.slice(0, 10)) })}</p>
          <input type="text" readOnly value={inv.url} onFocus={(e) => e.target.select()} aria-label={t('Lien d’invitation')} />
          <div className="row" style={{ gap: 8 }}>
            <a className="button accent" href={`https://wa.me/${waNumber(inv.phone)}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer">
              {t('Envoyer par WhatsApp')}
            </a>
            <a className="button secondary" href={`mailto:${inv.email}?subject=${encodeURIComponent(t('Votre accès à {app}', { app }))}&body=${encodeURIComponent(message)}`}>
              {t('Envoyer par e-mail')}
            </a>
            <button type="button" className="secondary" onClick={() => void copy()}>{copied ? t('Lien copié') : t('Copier le lien')}</button>
            <button type="button" className="secondary" onClick={() => setShowQr((v) => !v)}>{t('QR code')}</button>
          </div>
          {showQr && (
            <div className="stack" style={{ alignItems: 'flex-start', gap: 4 }}>
              <div ref={qr} className="invite-qr" />
              <p className="small muted">{t('À scanner avec l’appareil photo du téléphone du technicien.')}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
