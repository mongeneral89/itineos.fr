/**
 * Carte (Leaflet + fond OpenStreetMap) : véhicules sous forme d'étiquettes, et éventuellement un trajet.
 * Le fond de carte peut être changé avec VITE_MAP_TILES_URL (en production, un fournisseur de tuiles
 * adapté au volume : OpenStreetMap demande de ne pas utiliser ses serveurs pour un usage intensif).
 */
import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const TILES = (import.meta.env.VITE_MAP_TILES_URL as string | undefined) ?? 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>';
/** Centre par défaut (France) quand rien n'est à afficher */
const FRANCE: L.LatLngExpression = [46.6, 2.4];

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  label: string;
  /** Position récente, ancienne (grisée) ou point d'un trajet */
  tone: 'live' | 'stale' | 'point' | 'start' | 'end';
  title?: string;
}

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

function icon(m: MapMarker, selected: boolean): L.DivIcon {
  if (m.tone === 'point') return L.divIcon({ className: 'map-dot', html: '', iconSize: [10, 10], iconAnchor: [5, 5] });
  const cls = `map-pin map-pin-${m.tone}${selected ? ' map-pin-selected' : ''}`;
  return L.divIcon({ className: '', html: `<div class="${cls}">${esc(m.label)}</div>`, iconSize: undefined, iconAnchor: [0, 0] });
}

/** Cadre la carte sur les points (un seul : zoom de quartier) */
function fit(m: L.Map, points: L.LatLngExpression[]) {
  if (!points.length) return;
  if (points.length === 1) m.setView(points[0], 14);
  else m.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: 15 });
}

export function VehicleMap({ markers, path, selectedId, onSelect, height = 480, ariaLabel }: {
  markers: MapMarker[];
  /** Trajet à tracer, dans l'ordre */
  path?: [number, number][];
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  height?: number;
  ariaLabel: string;
}) {
  const box = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const layer = useRef<L.LayerGroup | null>(null);
  const fitted = useRef('');
  const lastFit = useRef<L.LatLngExpression[]>([]);

  useEffect(() => {
    if (!box.current || map.current) return;
    map.current = L.map(box.current, { zoomControl: true, attributionControl: true }).setView(FRANCE, 5);
    L.tileLayer(TILES, { maxZoom: 19, attribution: ATTRIBUTION }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    // La carte peut être créée avant que sa place soit connue (chargement, onglet) : on recadre quand elle a sa taille
    const observer = new ResizeObserver(() => {
      const m = map.current;
      if (!m || !box.current?.clientWidth) return;
      m.invalidateSize();
      fit(m, lastFit.current);
    });
    observer.observe(box.current);
    return () => {
      observer.disconnect();
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    const m = map.current;
    const g = layer.current;
    if (!m || !g) return;
    g.clearLayers();
    if (path && path.length > 1) L.polyline(path, { color: '#C2410C', weight: 4, opacity: 0.8 }).addTo(g);
    for (const mk of markers) {
      const marker = L.marker([mk.lat, mk.lng], { icon: icon(mk, mk.id === selectedId), title: mk.title ?? mk.label, keyboard: true, zIndexOffset: mk.id === selectedId ? 1000 : 0 });
      if (onSelect) marker.on('click', () => onSelect(mk.id));
      marker.addTo(g);
    }
    // Recadrage seulement quand l'ensemble affiché change (pas à chaque rafraîchissement)
    const key = [...markers.map((x) => x.id), path?.length ?? 0].join('|');
    const points: L.LatLngExpression[] = [...markers.map((x) => [x.lat, x.lng] as [number, number]), ...(path ?? [])];
    if (key !== fitted.current && points.length) {
      fitted.current = key;
      lastFit.current = points;
      m.invalidateSize();
      fit(m, points);
    }
  }, [markers, path, selectedId, onSelect]);

  // Véhicule choisi dans la liste : la carte se centre dessus
  useEffect(() => {
    const mk = markers.find((x) => x.id === selectedId);
    if (mk && map.current) map.current.panTo([mk.lat, mk.lng]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  return <div ref={box} role="region" aria-label={ariaLabel} style={{ height, width: '100%', borderRadius: 12, overflow: 'hidden', zIndex: 0 }} />;
}
