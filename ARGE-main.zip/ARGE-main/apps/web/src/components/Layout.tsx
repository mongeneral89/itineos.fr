import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { ErrorBoundary } from './ErrorBoundary';
import type { Feature, Module, Permission } from '@itineo/shared';
import { EDITION, hasFeature, hasModule, PRODUCT_NAME } from '../edition';
import longLogo from '../../brand/logo.svg';
import { logoSrc } from '../logo';
import { useAuth } from '../auth';
import { t, tp } from '../i18n';
import { useUnreadMessages } from '../messaging';
import { usePendingProcedures } from '../pages/Procedures';
import { ReportProblemButton, SupportBanner } from './Support';
import { CLIENT } from '../client';
import { NotificationBell } from './NotificationBell';
import { GlobalSearch } from './GlobalSearch';
import { PushPrompt } from './PushPrompt';

type NavItem = { to: string; label: string; perm?: Permission; module?: Module; feature?: Feature };
/** Menu rangé par rubriques ; les réglages, moins souvent utiles, sont repliés en bas */
const SECTIONS: { title: string; items: NavItem[] }[] = [
  { title: '', items: [{ to: '/dashboard', label: 'Aujourd’hui', perm: 'intervention.read' }] },
  {
    title: 'Activité',
    items: [
      { to: '/planning', label: 'Planning', perm: 'intervention.read' },
      { to: '/interventions', label: 'Interventions', perm: 'intervention.read' },
      { to: '/clients', label: 'Clients et sites', perm: 'client.read' },
      { to: '/stats', label: 'Statistiques', perm: 'stats.read' },
    ],
  },
  {
    title: 'Commercial',
    items: [
      { to: '/quotes', label: 'Devis', perm: 'quote.read', module: 'quotes' },
      { to: '/contracts', label: 'Contrats', perm: 'contract.read', module: 'contracts' },
      { to: '/invoices', label: 'Factures', perm: 'invoice.read', module: 'invoices' },
      { to: '/billing', label: 'Abonnements, prélèvements et relances', perm: 'invoice.write', module: 'invoices' },
    ],
  },
  {
    title: 'Ressources',
    items: [
      { to: '/stock', label: 'Stock', perm: 'stock.read', module: 'stock' },
      { to: '/fleet', label: 'Parc véhicules', perm: 'fleet.read', module: 'fleet' },
      { to: '/sims', label: 'Cartes SIM', perm: 'sim.read', module: 'sims' },
      { to: '/certifications', label: 'Habilitations', perm: 'certification.read', module: 'certifications' },
    ],
  },
  {
    title: 'Équipe',
    items: [
      { to: '/messages', label: 'Messagerie' },
      { to: '/directory', label: 'Annuaire' },
      { to: '/procedures', label: 'Notices et procédures' },
    ],
  },
];
const SETTINGS: NavItem[] = [
  { to: '/organisation', label: 'Organisation et comptes', perm: 'org.read' },
  { to: '/templates', label: 'Modèles de fiches', perm: 'template.read' },
  { to: '/treatments', label: 'Registre des traitements', perm: 'report.read', feature: 'treatmentRegister' },
];

/** Sélecteur de société et d'agence : tout le bureau travaille dans ce périmètre */
export function OrgPicker() {
  const { me, company, agency, select } = useAuth();
  if (!me || !company) return null;
  return (
    <div className="row">
      <div className="field">
        <label htmlFor="org-company">{t('Société')}</label>
        <select id="org-company" value={company.id} onChange={(e) => select(e.target.value, null)}>
          {me.org.map((c) => (
            <option key={c.id} value={c.id}>{c.name} ({c.countryCode})</option>
          ))}
        </select>
      </div>
      <div className="field">
        <label htmlFor="org-agency">{t('Agence')}</label>
        <select id="org-agency" value={agency?.id ?? ''} onChange={(e) => select(company.id, e.target.value || null)}>
          {company.agencies.length > 1 && <option value="">{t('Toutes les agences')}</option>}
          {company.agencies.map((a) => (
            <option key={a.id} value={a.id}>{a.name}</option>
          ))}
        </select>
      </div>
    </div>
  );
}

export function Layout() {
  const { me, has, logout, company } = useAuth();
  const logo = logoSrc(company);
  const { pathname } = useLocation();
  const unread = useUnreadMessages();
  const pending = usePendingProcedures(has('procedure.manage'));
  const shown = (n: NavItem) => (!n.perm || has(n.perm)) && (!n.module || hasModule(n.module)) && (!n.feature || hasFeature(n.feature));
  const link = (n: NavItem) => (
    <NavLink key={n.to} to={n.to}>
      {t(n.label)}
      {n.to === '/messages' && unread > 0 && <span className="nav-badge" aria-label={tp(unread, '{n} message non lu', '{n} messages non lus')}>{unread}</span>}
      {n.to === '/procedures' && pending > 0 && <span className="nav-badge" aria-label={tp(pending, '{n} document à valider', '{n} documents à valider')}>{pending}</span>}
    </NavLink>
  );
  const settings = SETTINGS.filter(shown);
  // Réglages ouverts quand on y est
  const inSettings = settings.some((n) => pathname.startsWith(n.to)) || pathname === '/account';
  return (
    <div className="shell">
      <nav className="sidebar" aria-label={t('Menu principal')}>
        {logo && <img className="company-logo sidebar-logo" src={logo} alt={company?.name ?? ''} />}
        {/* Itinéos : le logo en long sur toute la largeur (écran du bureau, nom souligné de la tournée, repère), la cloche à côté de la recherche */}
        {!CLIENT && EDITION === 'TECH' ? (
          <>
            <img className="brand-logo" src={longLogo} alt={PRODUCT_NAME} />
            <div className="search-row">
              <GlobalSearch />
              <NotificationBell className="bell-dark" />
            </div>
          </>
        ) : (
          <>
            <div className="brand-row">
              <div className="brand">{!CLIENT && <img className="brand-icon" src="/icon.svg" alt="" />}{CLIENT?.name ?? PRODUCT_NAME}</div>
              <NotificationBell className="bell-dark" />
            </div>
            <GlobalSearch />
          </>
        )}
        {SECTIONS.map((sec) => {
          const items = sec.items.filter(shown);
          if (!items.length) return null;
          return (
            <div key={sec.title || 'top'} className="nav-section">
              {sec.title && <div className="nav-title">{t(sec.title)}</div>}
              {items.map(link)}
            </div>
          );
        })}
        {has('report.write.own') && <div className="nav-section"><NavLink to="/tech">{t('Appli terrain')}</NavLink></div>}
        {company?.menuLinks?.length ? (
          <div className="nav-section">
          {/* Outils en ligne de la société (DocuSign…) : onglet à part, ces sites refusent d'être affichés dans Itinéos */}
          {company?.menuLinks?.map((l) => (
            <a key={l.url} href={l.url} target="_blank" rel="noopener noreferrer" title={t('s’ouvre dans un nouvel onglet')} aria-label={`${l.label} (${t('s’ouvre dans un nouvel onglet')})`}>
              {l.label} <span aria-hidden="true">↗</span>
            </a>
          ))}
          </div>
        ) : null}
        <div className="spacer" />
        <details className="nav-settings" open={inSettings}>
          <summary>{t('Réglages')}</summary>
          {settings.map(link)}
          <NavLink to="/account">{t('Mon compte')}</NavLink>
        </details>
        <div className="who">
          {me?.user.firstName} {me?.user.lastName}
          <br />
          <span className="small">{me?.assignments.map((a) => a.label).join(', ')}</span>
        </div>
        <ReportProblemButton />
        <button type="button" className="secondary" style={{ color: '#F4F2EE', borderColor: '#3A4150' }} onClick={logout}>
          {t('Se déconnecter')}
        </button>
      </nav>
      <main className="main">
        <SupportBanner />
        <PushPrompt />
        <ErrorBoundary resetKey={pathname}>
          <Outlet />
        </ErrorBoundary>
      </main>
    </div>
  );
}
