import type { ReportData, TemplateField, TemplateSchema } from '@itineo/shared';
import { DictationButton } from './DictationButton';
import { ScanButton } from './ScanButton';

const shown = (v: ReportData[string] | undefined) =>
  v === null || v === undefined || v === '' ? '' : Array.isArray(v) ? v.join(' · ') : typeof v === 'boolean' ? (v ? '✓' : '—') : String(v);

/**
 * Affiche les champs d'un modèle de fiche et renvoie les valeurs saisies.
 * `previous` : valeurs d'une fiche précédente (état des lieux d'entrée), rappelées sous chaque champ.
 */
export function FormRenderer({
  schema, data, onChange, readOnly, lang, previous, previousLabel,
}: {
  schema: TemplateSchema;
  data: ReportData;
  onChange: (id: string, value: ReportData[string]) => void;
  readOnly?: boolean;
  lang: string;
  previous?: ReportData | null;
  previousLabel?: string;
}) {
  return (
    <div className="stack">
      {schema.sections.map((section) => (
        <section key={section.id} className="card stack">
          <h2>{section.title}</h2>
          {section.fields.map((field) => {
            const before = previous ? shown(previous[field.id]) : '';
            return (
              <div key={field.id} className="stack" style={{ gap: 4 }}>
                <Field field={field} value={data[field.id]} onChange={(v) => onChange(field.id, v)} readOnly={readOnly} lang={lang} />
                {before && (
                  <span className={`small compare-hint${shown(data[field.id]) !== before ? ' changed' : ''}`}>
                    {previousLabel} : {before}
                  </span>
                )}
              </div>
            );
          })}
        </section>
      ))}
    </div>
  );
}

function Field({
  field, value, onChange, readOnly, lang,
}: {
  field: TemplateField;
  value: ReportData[string] | undefined;
  onChange: (v: ReportData[string]) => void;
  readOnly?: boolean;
  lang: string;
}) {
  const id = `f-${field.id}`;
  const label = (
    <>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <label htmlFor={id} style={{ margin: 0 }}>
          {field.label}
          {field.required && <span aria-hidden="true"> *</span>}
        </label>
        <span className="row" style={{ gap: 6 }}>
          {field.dictation && !readOnly && (
            <DictationButton lang={lang} onText={(t) => onChange([String(value ?? ''), t].filter(Boolean).join(' '))} />
          )}
          {/* Champ texte court : n° de série, référence… lisibles au scanner */}
          {field.type === 'text' && !readOnly && <ScanButton onResult={(v) => onChange(v)} />}
        </span>
      </div>
      {field.help && <span className="small muted">{field.help}</span>}
    </>
  );
  const str = value === null || value === undefined ? '' : String(value);

  switch (field.type) {
    case 'textarea':
      return (
        <div className="field" style={{ gap: 6 }}>
          {label}
          <textarea id={id} value={str} readOnly={readOnly} required={field.required} onChange={(e) => onChange(e.target.value)} />
        </div>
      );
    case 'select':
      return (
        <div className="field" style={{ gap: 6 }}>
          {label}
          <div className="chips" role="radiogroup" aria-labelledby={id}>
            <span id={id} hidden>{field.label}</span>
            {field.options?.map((o) => (
              <button
                key={o}
                type="button"
                role="radio"
                aria-checked={str === o}
                className={`chip${str === o ? ' on' : ''}`}
                disabled={readOnly}
                onClick={() => onChange(o)}
              >
                {o}
              </button>
            ))}
          </div>
        </div>
      );
    case 'checklist': {
      const list = Array.isArray(value) ? value : [];
      return (
        <fieldset className="field" style={{ border: 'none', padding: 0, margin: 0, gap: 4 }}>
          <legend className="section-title" style={{ marginBottom: 6 }}>{field.label}</legend>
          {field.options?.map((o) => (
            <label key={o} className="check">
              <input
                type="checkbox"
                checked={list.includes(o)}
                disabled={readOnly}
                onChange={(e) => onChange(e.target.checked ? [...list, o] : list.filter((x) => x !== o))}
              />
              {o}
            </label>
          ))}
        </fieldset>
      );
    }
    case 'checkbox':
      return (
        <label className="check">
          <input type="checkbox" checked={value === true} disabled={readOnly} onChange={(e) => onChange(e.target.checked)} />
          {field.label}
        </label>
      );
    default:
      return (
        <div className="field" style={{ gap: 6 }}>
          {label}
          <input
            id={id}
            type={field.type === 'number' ? 'number' : field.type === 'date' ? 'date' : field.type === 'time' ? 'time' : 'text'}
            value={str}
            readOnly={readOnly}
            onChange={(e) => onChange(field.type === 'number' && e.target.value !== '' ? Number(e.target.value) : e.target.value)}
          />
        </div>
      );
  }
}
