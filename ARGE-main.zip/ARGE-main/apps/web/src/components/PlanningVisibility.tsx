/**
 * Bureau : ce que chaque technicien voit du planning dans l'appli terrain
 * (son planning seulement, toute son agence, ou les collègues choisis).
 */
import { useState } from 'react';
import { api, qs } from '../api';
import { useLoad } from '../hooks';
import { t } from '../i18n';

type Mode = 'OWN' | 'AGENCY' | 'CUSTOM';
interface TechVisibility { id: string; firstName: string; lastName: string; mode: Mode; targetIds: string[]; agencies: string[] }

export function PlanningVisibility({ companyId, agencyId, onClose }: { companyId: string; agencyId?: string; onClose: () => void }) {
  const { data, error, reload } = useLoad(
    () => api<TechVisibility[]>(`/planning-visibility${qs({ companyId, agencyId })}`),
    [companyId, agencyId],
  );
  const [saving, setSaving] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const save = async (tech: TechVisibility, mode: Mode, targetIds: string[]) => {
    setSaving(tech.id);
    setMsg(null);
    try {
      await api(`/planning-visibility/${tech.id}`, { method: 'PUT', body: { mode, targetIds } });
      await reload();
    } catch (e) {
      setMsg((e as Error).message);
    } finally {
      setSaving(null);
    }
  };

  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h2 style={{ fontSize: 17 }}>{t('Planning visible par les techniciens')}</h2>
          <div className="small muted">{t('Dans l’appli terrain, bouton « Équipe ». Par défaut, chacun ne voit que son planning.')}</div>
        </div>
        <button type="button" className="secondary" onClick={onClose}>{t('Fermer')}</button>
      </div>
      {error && <p className="error">{error}</p>}
      {msg && <p className="error small">{msg}</p>}
      {data && !data.length && <p className="muted">{t('Aucun technicien dans ce périmètre.')}</p>}
      {data?.map((tech) => (
        <div key={tech.id} className="stack" style={{ gap: 6, borderTop: '1px solid var(--ground-2)', paddingTop: 8, opacity: saving === tech.id ? 0.6 : 1 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <strong>{tech.firstName} {tech.lastName} <span className="small muted">{tech.agencies.join(', ')}</span></strong>
            <select style={{ width: 'auto' }} value={tech.mode} aria-label={t('Planning visible par {name}', { name: `${tech.firstName} ${tech.lastName}` })}
              onChange={(e) => void save(tech, e.target.value as Mode, tech.targetIds)}>
              <option value="OWN">{t('Son planning seulement')}</option>
              <option value="AGENCY">{t('Toute son agence')}</option>
              <option value="CUSTOM">{t('Les collègues choisis')}</option>
            </select>
          </div>
          {tech.mode === 'CUSTOM' && (
            <div className="chips">
              {data.filter((o) => o.id !== tech.id).map((o) => {
                const on = tech.targetIds.includes(o.id);
                return (
                  <button key={o.id} type="button" role="checkbox" aria-checked={on} className={`chip${on ? ' on' : ''}`}
                    onClick={() => void save(tech, 'CUSTOM', on ? tech.targetIds.filter((x) => x !== o.id) : [...tech.targetIds, o.id])}>
                    {o.firstName} {o.lastName}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      ))}
    </section>
  );
}
