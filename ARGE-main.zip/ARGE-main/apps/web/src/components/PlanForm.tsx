import { useEffect, useState } from 'react';
import { api, qs } from '../api';
import type { UserRow } from '../types';
import { toDateTimeInput } from '../format';
import { t } from '../i18n';
import { AssignSuggestions, useSuggestionsEnabled } from './AssignSuggestions';

/** Ce qu'il faut savoir d'une intervention pour la planifier ou la replanifier */
export interface PlanTarget {
  id: string;
  companyId: string;
  technicianId: string | null;
  scheduledStart: string | null;
  scheduledEnd: string | null;
  requiredCertificationIds?: string[];
}

/** Durée prévue en heures (1 h par défaut) */
export function plannedHours(iv: Pick<PlanTarget, 'scheduledStart' | 'scheduledEnd'>): number {
  if (!iv.scheduledStart || !iv.scheduledEnd) return 1;
  return Math.max(0.25, Math.round(((new Date(iv.scheduledEnd).getTime() - new Date(iv.scheduledStart).getTime()) / 3600_000) * 4) / 4);
}

/**
 * Technicien, début et durée d'une intervention : pour la planifier (liste « À planifier ») ou la replanifier
 * (fiche de l'intervention, bloc du planning). Prévient si le technicien n'a pas l'habilitation exigée.
 */
export function PlanForm({ iv, techs, defaultStart, onSaved, onCancel }: {
  iv: PlanTarget;
  techs: UserRow[];
  /** Début proposé quand l'intervention n'a pas encore de date (ex. le jour affiché au planning, 9 h) */
  defaultStart: Date;
  onSaved: (res: { missingCertifications?: { name: string }[] }) => void;
  onCancel: () => void;
}) {
  const replan = !!iv.scheduledStart;
  const [technicianId, setTechnicianId] = useState(iv.technicianId && techs.some((u) => u.id === iv.technicianId) ? iv.technicianId : techs[0]?.id ?? '');
  const [start, setStart] = useState(() => toDateTimeInput((iv.scheduledStart ? new Date(iv.scheduledStart) : defaultStart).toISOString()));
  const [hours, setHours] = useState(() => String(plannedHours(iv)));
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [missing, setMissing] = useState<{ code: string; name: string }[]>([]);
  const suggest = useSuggestionsEnabled(iv.companyId);
  // Le technicien suggéré est présélectionné, tant que le planificateur n'a pas choisi lui-même (pas en replanification)
  const [touched, setTouched] = useState(replan);

  // Habilitations exigées : on vérifie que le technicien choisi les a, à la date prévue
  const needsCerts = (iv.requiredCertificationIds?.length ?? 0) > 0;
  useEffect(() => {
    if (!needsCerts || !technicianId || !start) return setMissing([]);
    let cancelled = false;
    void api<{ missing: { code: string; name: string }[] }>(`/certifications/check${qs({ interventionId: iv.id, technicianId, on: start.slice(0, 10) })}`)
      .then((r) => !cancelled && setMissing(r.missing)).catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [needsCerts, technicianId, start, iv.id]);

  const save = async () => {
    setError(null);
    setBusy(true);
    try {
      const s = new Date(start);
      const res = await api<{ missingCertifications?: { name: string }[] }>(`/interventions/${iv.id}`, {
        method: 'PATCH',
        body: { technicianId, scheduledStart: s.toISOString(), scheduledEnd: new Date(s.getTime() + Number(hours) * 3600_000).toISOString() },
      });
      onSaved(res);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      {suggest && (
        <div className="stack" style={{ gap: 4 }}>
          <strong className="small">{t('Suggestion d’attribution')}</strong>
          <AssignSuggestions interventionId={iv.id} day={start.slice(0, 10)} selected={technicianId} compact pickLabel={t('Choisir')}
            onPick={(c) => { setTouched(true); setTechnicianId(c.technicianId); }}
            onLoaded={(r) => {
              const best = r.candidates.find((c) => !c.missingCerts.length && !c.conflicts.length && techs.some((u) => u.id === c.technicianId));
              if (!touched && best) setTechnicianId(best.technicianId);
            }} />
        </div>
      )}
      <div className="field">
        <label htmlFor={`t-${iv.id}`}>{t('Technicien')}</label>
        <select id={`t-${iv.id}`} value={technicianId} onChange={(e) => { setTouched(true); setTechnicianId(e.target.value); }}>
          {techs.map((u) => <option key={u.id} value={u.id}>{u.firstName} {u.lastName}{u.skills.length ? ` (${u.skills.join(', ')})` : ''}</option>)}
        </select>
      </div>
      <div className="row">
        <div className="field grow">
          <label htmlFor={`s-${iv.id}`}>{t('Début')}</label>
          <input id={`s-${iv.id}`} type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} />
        </div>
        <div className="field" style={{ width: 100 }}>
          <label htmlFor={`h-${iv.id}`}>{t('Durée (h)')}</label>
          <input id={`h-${iv.id}`} type="number" min="0.25" step="0.25" value={hours} onChange={(e) => setHours(e.target.value)} />
        </div>
      </div>
      {missing.length > 0 && (
        <p className="small" role="alert" style={{ background: 'var(--warn-bg)', color: 'var(--warn-fg)', padding: 8, borderRadius: 8, margin: 0 }}>
          {t("⚠ Ce technicien n'aura pas l'habilitation exigée à cette date : {list}.", { list: missing.map((m) => m.name).join(', ') })}
        </p>
      )}
      {error && <p className="error small">{error}</p>}
      <div className="row">
        <button type="button" onClick={() => void save()} disabled={busy || !technicianId || !start}>
          {missing.length ? t('Planifier quand même') : replan ? t('Enregistrer') : t('Valider')}
        </button>
        <button type="button" className="secondary" onClick={onCancel}>{t('Annuler')}</button>
      </div>
    </div>
  );
}

/** Techniciens qui peuvent faire une intervention de cette agence (rattachés à l'agence, ou à toute la société) */
export function techniciansFor(users: UserRow[], agencyId: string): UserRow[] {
  return users.filter((u) => u.active && u.roles.some((r) => r.role === 'TECHNICIAN' && (r.agencyId === null || r.agencyId === agencyId)));
}
