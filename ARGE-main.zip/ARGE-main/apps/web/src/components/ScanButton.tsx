/**
 * Scanner : lit un code-barres ou un QR code (n° de série, référence, code P2P) avec l'appareil photo.
 * Le lecteur intégré au navigateur (Android, Chrome) est utilisé s'il existe ; sinon la bibliothèque ZXing
 * (iPhone, Firefox), chargée seulement au premier scan.
 */
import { useEffect, useRef, useState } from 'react';
import { t } from '../i18n';

interface DetectorLike { detect: (source: HTMLVideoElement) => Promise<{ rawValue: string }[]> }
declare global {
  interface Window { BarcodeDetector?: new (opts?: { formats?: string[] }) => DetectorLike }
}

const FORMATS = ['qr_code', 'code_128', 'code_39', 'code_93', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'itf', 'data_matrix', 'pdf417', 'codabar'];

/** `wide` : grand bouton avec son texte (pointage des points de passage), sinon une petite icône à côté d'un champ */
export function ScanButton({ onResult, label, wide }: { onResult: (value: string) => void; label?: string; wide?: boolean }) {
  const [open, setOpen] = useState(false);
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) return null;
  return (
    <>
      {wide ? (
        <button type="button" className="big accent" onClick={() => setOpen(true)}>▦ {label ?? t('Scanner un code')}</button>
      ) : (
        <button type="button" className="secondary scan-btn" onClick={() => setOpen(true)} title={label ?? t('Scanner un code')} aria-label={label ?? t('Scanner un code')}>
          ▦
        </button>
      )}
      {open && <Scanner onClose={() => setOpen(false)} onResult={(v) => { setOpen(false); onResult(v); }} />}
    </>
  );
}

function Scanner({ onClose, onResult }: { onClose: () => void; onResult: (value: string) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const resultRef = useRef(onResult);
  resultRef.current = onResult;

  useEffect(() => {
    let stream: MediaStream | null = null;
    let stopped = false;
    let timer = 0;
    let stopZxing: (() => void) | null = null;
    const done = (value: string) => {
      if (stopped || !value.trim()) return;
      stopped = true;
      navigator.vibrate?.(80);
      resultRef.current(value.trim());
    };
    (async () => {
      try {
        if (window.BarcodeDetector) {
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
          // Fenêtre déjà fermée pendant l'attente : la caméra est rendue tout de suite
          if (stopped || !video.current) return stream.getTracks().forEach((tr) => tr.stop());
          const v = video.current;
          v.srcObject = stream;
          await v.play();
          const detector = new window.BarcodeDetector({ formats: FORMATS });
          const tick = async () => {
            if (stopped) return;
            try {
              const found = await detector.detect(v);
              if (found[0]) return done(found[0].rawValue);
            } catch {
              /* image pas encore prête */
            }
            timer = window.setTimeout(() => void tick(), 200);
          };
          void tick();
        } else {
          const { BrowserMultiFormatReader } = await import('@zxing/browser');
          const reader = new BrowserMultiFormatReader();
          const controls = await reader.decodeFromConstraints({ video: { facingMode: 'environment' } }, video.current!, (result) => {
            if (result) done(result.getText());
          });
          if (stopped) controls.stop();
          else stopZxing = () => controls.stop();
        }
      } catch (e) {
        if (stopped) return;
        const name = (e as { name?: string }).name;
        setError(name === 'NotAllowedError' ? t('Accès à l’appareil photo refusé : autorisez-le dans les réglages du navigateur.') : t('Appareil photo indisponible sur cet appareil.'));
      }
    })();
    return () => {
      stopped = true;
      window.clearTimeout(timer);
      stopZxing?.();
      stream?.getTracks().forEach((tr) => tr.stop());
    };
  }, []);

  return (
    <div className="scan-overlay" role="dialog" aria-modal="true" aria-label={t('Scanner un code')}>
      <div className="scan-box">
        <video ref={video} playsInline muted />
        <div className="scan-frame" aria-hidden="true" />
      </div>
      <p className="small" style={{ color: '#fff', textAlign: 'center' }}>{error ?? t('Visez le code-barres ou le QR code')}</p>
      <button type="button" className="secondary" style={{ background: '#fff' }} onClick={onClose}>{t('Annuler')}</button>
    </div>
  );
}
