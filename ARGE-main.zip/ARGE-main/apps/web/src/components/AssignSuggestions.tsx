/**
 * Suggestion d'attribution : techniciens classés pour une intervention, avec les raisons
 * (distance, charge de la journée, matériel dans le véhicule, habilitations). Le planificateur décide.
 */
import { useEffect, useState } from 'react';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { fmtTime } from '../format';
import { t, tp, uiLocale } from '../i18n';

export interface Suggestion {
  technicianId: string; name: string; score: number; distanceKm: number | null; driveMinutes: number | null;
  distanceFrom: { kind: 'LIVE'; minutesAgo: number } | { kind: 'JOB'; number: string; clientName: string; time: string | null } | null;
  loadMinutes: number; jobs: number; conflicts: { number: string; start: string; end: string | null }[];
  missingCerts: string[]; stock: { needed: number; covered: number; missing: { name: string; quantity: number; available: number }[] } | null;
  current: boolean;
}
export interface SuggestionResult {
  day: string; slot: { start: string; end: string } | null; siteLocated: boolean;
  neededParts: { articleId: string; reference: string; name: string; quantity: number }[];
  candidates: Suggestion[];
}

/** La suggestion est-elle activée pour la société de l'intervention ? */
export function useSuggestionsEnabled(companyId: string | undefined): boolean {
  const { me, has } = useAuth();
  const c = me?.org.find((x) => x.id === companyId);
  return !!c?.assignSuggestions && has('intervention.assign');
}

const hours = (min: number) => (min >= 60 ? t('{h} h {m}', { h: Math.floor(min / 60), m: String(min % 60).padStart(2, '0') }) : t('{n} min', { n: min }));

export function AssignSuggestions({ interventionId, day, selected, onPick, onLoaded, pickLabel, refreshKey, compact }: {
  interventionId: string; day?: string; selected?: string; onPick: (s: Suggestion, result: SuggestionResult) => void;
  pickLabel: string; refreshKey?: unknown; compact?: boolean;
  /** Appelé à chaque nouveau calcul (pour présélectionner le technicien suggéré) */
  onLoaded?: (result: SuggestionResult) => void;
}) {
  const [data, setData] = useState<SuggestionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<SuggestionResult>(`/interventions/${interventionId}/suggestions${qs({ day })}`)
      .then((r) => { if (!cancelled) { setData(r); setError(null); onLoaded?.(r); } })
      .catch((e) => !cancelled && setError((e as Error).message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [interventionId, day, refreshKey]);

  if (error) return <p className="error small">{error}</p>;
  if (!data) return <p className="muted small">{t('Recherche du meilleur technicien…')}</p>;
  if (!data.candidates.length) return <p className="muted small">{t('Aucun technicien rattaché à cette agence.')}</p>;

  const list = showAll ? data.candidates : data.candidates.slice(0, compact ? 3 : 5);
  return (
    <div className="stack" style={{ gap: 6, opacity: loading ? 0.6 : 1 }}>
      <div className="small muted">
        {t('Suggestion pour le {date}', { date: new Date(`${data.day}T12:00:00`).toLocaleDateString(uiLocale(), { weekday: 'long', day: 'numeric', month: 'long' }) })}
        {data.slot ? ` · ${fmtTime(data.slot.start)}–${fmtTime(data.slot.end)}` : ''}
        {!data.siteLocated && ` · ${t('adresse du site pas encore localisée : distance non prise en compte')}`}
        {data.neededParts.length > 0 && ` · ${tp(data.neededParts.length, '{n} article à prévoir', '{n} articles à prévoir')}`}
      </div>
      {list.map((c, idx) => {
        const blocked = c.missingCerts.length > 0 || c.conflicts.length > 0;
        return (
          <div key={c.technicianId} className={`suggest${idx === 0 && !blocked ? ' best' : ''}${selected === c.technicianId ? ' on' : ''}`}>
            <div className="row" style={{ justifyContent: 'space-between', gap: 6, flexWrap: 'nowrap' }}>
              <span className="row" style={{ gap: 6 }}>
                <span className={`suggest-score${blocked ? ' low' : ''}`} title={t('Note sur 100')}>{c.score}</span>
                <strong>{c.name}</strong>
                {idx === 0 && !blocked && <span className="badge ok">{t('Suggéré')}</span>}
                {c.current && <span className="badge neutral">{t('Actuel')}</span>}
              </span>
              <button type="button" className={selected === c.technicianId ? '' : 'secondary'} onClick={() => onPick(c, data)}>{pickLabel}</button>
            </div>
            <ul className="suggest-reasons small">
              {c.distanceKm != null && c.distanceFrom && (
                <li>
                  📍 {t('{km} km, environ {min} min de route', { km: c.distanceKm.toLocaleString(), min: c.driveMinutes ?? 0 })}{' '}
                  <span className="muted">
                    {c.distanceFrom.kind === 'LIVE'
                      ? t('(position en direct, il y a {n} min)', { n: c.distanceFrom.minutesAgo })
                      : t('(depuis son intervention chez {client}{time})', { client: c.distanceFrom.clientName, time: c.distanceFrom.time ? ` ${t('à {time}', { time: fmtTime(c.distanceFrom.time) })}` : '' })}
                  </span>
                </li>
              )}
              {c.distanceKm == null && data.siteLocated && <li className="muted">📍 {t('Position inconnue ce jour-là')}</li>}
              <li>🗓 {c.jobs ? t('{n} intervention(s), {h} planifiées ce jour-là', { n: c.jobs, h: hours(c.loadMinutes) }) : t('Journée libre')}</li>
              {c.stock && (
                c.stock.missing.length
                  ? <li className="warn-text">📦 {t('Manque dans son véhicule : {list}', { list: c.stock.missing.map((m) => `${m.quantity} × ${m.name}${m.available ? ` (${t('{n} en stock', { n: m.available })})` : ''}`).join(', ') })}</li>
                  : <li className="ok-text">📦 {t('Tout le matériel est dans son véhicule')}</li>
              )}
              {c.conflicts.map((x) => (
                <li key={x.number} className="warn-text">⚠ {t('Déjà occupé : {number} de {from} à {to}', { number: x.number, from: fmtTime(x.start), to: x.end ? fmtTime(x.end) : '?' })}</li>
              ))}
              {c.missingCerts.length > 0 && <li className="warn-text">⚠ {t('Habilitation manquante : {list}', { list: c.missingCerts.join(', ') })}</li>}
            </ul>
          </div>
        );
      })}
      {data.candidates.length > list.length && (
        <button type="button" className="ghost small" onClick={() => setShowAll(true)}>{t('Voir les {n} techniciens', { n: data.candidates.length })}</button>
      )}
    </div>
  );
}
