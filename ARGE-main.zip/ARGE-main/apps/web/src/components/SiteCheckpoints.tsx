/**
 * Itinéos Vigie : points de passage d'un site. Chaque point a un QR code à imprimer et coller sur place ;
 * l'agent le scanne pendant sa ronde (appli terrain).
 */
import { useState, type FormEvent } from 'react';
import { api } from '../api';
import { useLoad } from '../hooks';
import { t, tp } from '../i18n';
import type { Checkpoint } from '../types';

/** QR code en SVG (bibliothèque chargée seulement quand on imprime) */
async function qrSvg(text: string): Promise<string> {
  const { BrowserQRCodeSvgWriter } = await import('@zxing/browser');
  return new BrowserQRCodeSvgWriter().write(text, 220, 220).outerHTML;
}

const escapeHtml = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);

/** Planche à imprimer : un QR code par point, avec son nom et celui du site */
async function printSheet(siteName: string, points: Checkpoint[]) {
  const win = window.open('', '_blank');
  if (!win) return;
  const cards = await Promise.all(points.map(async (cp, k) => `
    <div class="card">${await qrSvg(cp.code)}<strong>${k + 1}. ${escapeHtml(cp.name)}</strong><span>${escapeHtml(siteName)}</span></div>`));
  win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(t('Points de passage'))} – ${escapeHtml(siteName)}</title>
    <style>
      body { font-family: system-ui, sans-serif; margin: 16px; }
      h1 { font-size: 18px; }
      .sheet { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
      .card { border: 1px dashed #999; border-radius: 8px; padding: 10px; text-align: center; display: flex; flex-direction: column; gap: 4px; break-inside: avoid; }
      .card svg { width: 100%; height: auto; }
      .card span { font-size: 11px; color: #555; }
    </style></head><body>
    <h1>${escapeHtml(t('Points de passage'))} – ${escapeHtml(siteName)}</h1>
    <div class="sheet">${cards.join('')}</div>
    </body></html>`);
  win.document.close();
  // Impression lancée d'ici : la politique de sécurité (CSP) interdit les scripts écrits dans la page
  win.focus();
  win.print();
}

export function SiteCheckpoints({ siteId, siteName, canWrite }: { siteId: string; siteName: string; canWrite: boolean }) {
  const { data, error, reload } = useLoad(() => api<Checkpoint[]>(`/sites/${siteId}/checkpoints`), [siteId]);
  const [name, setName] = useState('');
  const [problem, setProblem] = useState<string | null>(null);
  const points = data ?? [];

  const add = async (e: FormEvent) => {
    e.preventDefault();
    setProblem(null);
    try {
      await api(`/sites/${siteId}/checkpoints`, { method: 'POST', body: { name } });
      setName('');
      await reload();
    } catch (err) {
      setProblem((err as Error).message);
    }
  };
  const remove = async (cp: Checkpoint) => {
    if (!window.confirm(t('Retirer le point « {name} » des rondes ?', { name: cp.name }))) return;
    try {
      await api(`/checkpoints/${cp.id}`, { method: 'PATCH', body: { active: false } });
      await reload();
    } catch (err) {
      setProblem((err as Error).message);
    }
  };

  return (
    <div className="stack" style={{ gap: 6, borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <strong>{t('Points de passage')} <span className="small muted">· {tp(points.length, '{n} point', '{n} points')}</span></strong>
        {points.length > 0 && <button type="button" className="ghost" onClick={() => void printSheet(siteName, points)}>{t('Imprimer les QR codes')}</button>}
      </div>
      {error && <p className="error small">{error}</p>}
      {points.length ? (
        <ol style={{ margin: 0, paddingLeft: 20 }}>
          {points.map((cp) => (
            <li key={cp.id} className="small">
              {cp.name}
              {canWrite && <button type="button" className="ghost" style={{ minHeight: 0, padding: '0 6px' }} onClick={() => void remove(cp)}>{t('Retirer')}</button>}
            </li>
          ))}
        </ol>
      ) : <p className="small muted">{t('Aucun point de passage : ajoutez ceux que l’agent doit pointer pendant sa ronde.')}</p>}
      {canWrite && (
        <form className="row" onSubmit={add}>
          <div className="field grow"><label htmlFor={`cp-${siteId}`}>{t('Nouveau point de passage')}</label>
            <input id={`cp-${siteId}`} value={name} onChange={(e) => setName(e.target.value)} placeholder={t('Ex. : porte du parking, local technique')} required /></div>
          <button type="submit" className="secondary" style={{ alignSelf: 'flex-end' }}>{t('Ajouter')}</button>
        </form>
      )}
      {problem && <p className="error small">{problem}</p>}
    </div>
  );
}
