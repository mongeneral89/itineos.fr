import { useState } from 'react';
import { api } from '../api';
import { t } from '../i18n';

/**
 * Annuler une intervention : le motif est demandé, gardé sur la fiche et dans le journal,
 * et le technicien qui devait la faire est prévenu.
 */
export function CancelIntervention({ id, onDone, onCancel }: { id: string; onDone: () => void; onCancel: () => void }) {
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setError(null);
    setBusy(true);
    try {
      await api(`/interventions/${id}/cancel`, { method: 'POST', body: { reason } });
      onDone();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="stack">
      <div className="field">
        <label htmlFor={`cancel-${id}`}>{t('Motif de l’annulation')}</label>
        <textarea id={`cancel-${id}`} rows={2} value={reason} maxLength={500} autoFocus onChange={(e) => setReason(e.target.value)}
          placeholder={t('Ex. : le client a reporté, doublon, matériel pas encore livré…')} />
      </div>
      <p className="small muted">{t('Le technicien prévu est prévenu sur son téléphone.')}</p>
      {error && <p className="error small">{error}</p>}
      <div className="row">
        <button type="button" className="danger" onClick={() => void submit()} disabled={busy || reason.trim().length < 3}>{t('Annuler l’intervention')}</button>
        <button type="button" className="secondary" onClick={onCancel}>{t('Retour')}</button>
      </div>
    </div>
  );
}
