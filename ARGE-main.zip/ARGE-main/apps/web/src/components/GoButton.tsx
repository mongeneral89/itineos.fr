/**
 * « Y aller » : ouvre l'itinéraire vers le site dans l'appli GPS du téléphone.
 * Waze par défaut ; la flèche ▾ permet de choisir Google Maps, Plans (iPhone) ou une autre appli (Android),
 * et le choix est retenu sur l'appareil.
 */
import { useState } from 'react';
import { t } from '../i18n';

type App = 'waze' | 'google' | 'apple' | 'other';
const KEY = 'itineo.gps';

const isApple = () => /iPhone|iPad|iPod|Macintosh/.test(navigator.userAgent);

function readChoice(): App {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'waze' || v === 'google' || v === 'apple' || v === 'other') return v;
  } catch {
    /* stockage indisponible */
  }
  return 'waze';
}

/** Adresse de l'itinéraire dans chaque appli (coordonnées si connues, sinon l'adresse) */
export function routeUrl(app: App, dest: { address: string; lat?: number | null; lng?: number | null }): string {
  const ll = dest.lat != null && dest.lng != null ? `${dest.lat},${dest.lng}` : null;
  const q = encodeURIComponent(dest.address);
  switch (app) {
    case 'waze': return ll ? `https://waze.com/ul?ll=${ll}&navigate=yes` : `https://waze.com/ul?q=${q}&navigate=yes`;
    case 'google': return `https://www.google.com/maps/dir/?api=1&destination=${ll ?? q}`;
    case 'apple': return `https://maps.apple.com/?daddr=${ll ?? q}`;
    default: return ll ? `geo:${ll}?q=${ll}` : `geo:0,0?q=${q}`;
  }
}

export function GoButton({ address, lat, lng, className }: { address: string; lat?: number | null; lng?: number | null; className?: string }) {
  const [app, setApp] = useState<App>(readChoice);
  const [open, setOpen] = useState(false);
  if (!address.trim() && (lat == null || lng == null)) return null;
  const apps: { id: App; label: string }[] = [
    { id: 'waze', label: 'Waze' },
    { id: 'google', label: 'Google Maps' },
    ...(isApple() ? [{ id: 'apple' as const, label: t('Plans (iPhone)') }] : [{ id: 'other' as const, label: t('Autre appli GPS') }]),
  ];
  const choose = (a: App) => {
    setApp(a);
    setOpen(false);
    try {
      localStorage.setItem(KEY, a);
    } catch {
      /* choix non retenu */
    }
  };
  const label = apps.find((a) => a.id === app)?.label ?? 'Waze';
  return (
    <span className={`go-btn ${className ?? ''}`}>
      <a className="btn accent" href={routeUrl(app, { address, lat, lng })} target="_blank" rel="noreferrer">
        🧭 {t('Y aller')} <span className="small" style={{ opacity: 0.85 }}>· {label}</span>
      </a>
      <button type="button" className="secondary" aria-label={t('Choisir l’appli GPS')} aria-expanded={open} onClick={() => setOpen(!open)}>▾</button>
      {open && (
        <span className="go-menu" role="menu">
          {apps.map((a) => (
            <button key={a.id} type="button" role="menuitemradio" aria-checked={a.id === app} className={a.id === app ? '' : 'ghost'} onClick={() => choose(a.id)}>{a.label}</button>
          ))}
        </span>
      )}
    </span>
  );
}
