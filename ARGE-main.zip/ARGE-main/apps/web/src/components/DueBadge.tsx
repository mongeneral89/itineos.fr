import { DUE_STATE_LABELS, type DueState } from '@itineo/shared';
import { tl } from '../i18n';

const TONES: Record<DueState, string> = { OK: 'ok', SOON: 'warn', OVERDUE: 'danger', NONE: 'neutral' };

/** État d'une échéance : à jour (vert), bientôt (orange), dépassée (rouge) */
export function DueBadge({ state, label }: { state: DueState; label?: string }) {
  return <span className={`badge ${TONES[state]}`}>{label ?? tl(DUE_STATE_LABELS, state)}</span>;
}
