import { forwardRef, useEffect, useImperativeHandle, useRef, type PointerEvent } from 'react';
import { t } from '../i18n';

export interface SignaturePadHandle {
  clear: () => void;
  isEmpty: () => boolean;
  /** Image PNG de la signature, ou null si rien n'a été dessiné */
  toDataURL: () => string | null;
}

/** Zone de signature au doigt ou au stylet (fonctionne aussi à la souris) */
export const SignaturePad = forwardRef<SignaturePadHandle, { label: string; onChange?: (empty: boolean) => void }>(
  function SignaturePad({ label, onChange }, ref) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const drawing = useRef(false);
    const empty = useRef(true);

    const setup = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ratio = Math.max(window.devicePixelRatio || 1, 1);
      const { width, height } = canvas.getBoundingClientRect();
      canvas.width = width * ratio;
      canvas.height = height * ratio;
      const ctx = canvas.getContext('2d')!;
      ctx.scale(ratio, ratio);
      ctx.lineWidth = 2.4;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = '#14181F';
      empty.current = true;
      onChange?.(true);
    };

    useEffect(() => {
      setup();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useImperativeHandle(ref, () => ({
      clear: setup,
      isEmpty: () => empty.current,
      toDataURL: () => (empty.current ? null : canvasRef.current!.toDataURL('image/png')),
    }));

    const point = (e: PointerEvent<HTMLCanvasElement>) => {
      const r = e.currentTarget.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    };

    return (
      <div className="stack" style={{ gap: 6 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <span className="section-title">{label}</span>
          <button type="button" className="ghost" onClick={setup}>{t('Effacer')}</button>
        </div>
        <canvas
          ref={canvasRef}
          className="signature"
          role="img"
          aria-label={label}
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            drawing.current = true;
            const ctx = e.currentTarget.getContext('2d')!;
            const { x, y } = point(e);
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + 0.1, y + 0.1);
            ctx.stroke();
            if (empty.current) {
              empty.current = false;
              onChange?.(false);
            }
          }}
          onPointerMove={(e) => {
            if (!drawing.current) return;
            const ctx = e.currentTarget.getContext('2d')!;
            const { x, y } = point(e);
            ctx.lineTo(x, y);
            ctx.stroke();
          }}
          onPointerUp={() => (drawing.current = false)}
          onPointerCancel={() => (drawing.current = false)}
        />
      </div>
    );
  },
);
