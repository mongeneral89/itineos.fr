/**
 * Sur la fiche d'une intervention : le matériel à prévoir et la suggestion d'attribution,
 * avec de quoi planifier d'un clic avec le technicien choisi.
 */
import { useEffect, useState } from 'react';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import type { InterventionDetail } from '../types';
import { t } from '../i18n';
import { AssignSuggestions, type Suggestion } from './AssignSuggestions';

interface Article { id: string; reference: string; name: string; unit: string }

const toLocalInput = (d: Date) => {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export function SuggestionPanel({ iv, onChanged }: { iv: InterventionDetail; onChanged: () => Promise<void> | void }) {
  const { has } = useAuth();
  const [day, setDay] = useState<string>('');
  const [refresh, setRefresh] = useState(0);
  const [picked, setPicked] = useState<Suggestion | null>(null);
  const [start, setStart] = useState('');
  const [hours, setHours] = useState('1');
  const [error, setError] = useState<string | null>(null);
  const planned = !!iv.scheduledStart;

  const plan = async () => {
    if (!picked) return;
    setError(null);
    try {
      const body: Record<string, unknown> = { technicianId: picked.technicianId };
      if (!planned || start) {
        const s = new Date(start);
        if (Number.isNaN(s.getTime())) return setError(t('Indiquez l’heure de début'));
        body.scheduledStart = s.toISOString();
        body.scheduledEnd = new Date(s.getTime() + Number(hours) * 3600_000).toISOString();
      }
      await api(`/interventions/${iv.id}`, { method: 'PATCH', body });
      setPicked(null);
      setRefresh((n) => n + 1);
      await onChanged();
    } catch (e) {
      setError((e as Error).message);
    }
  };

  return (
    <section className="card stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h2>{t('Suggestion d’attribution')}</h2>
          <div className="small muted">{t('Selon la distance, la charge de la journée, le matériel dans les véhicules et les habilitations. Vous décidez.')}</div>
        </div>
        <div className="field">
          <label htmlFor="sg-day">{t('Pour le')}</label>
          <input id="sg-day" type="date" value={day} onChange={(e) => setDay(e.target.value)} />
        </div>
      </div>
      {has('intervention.write') && <NeededParts iv={iv} onSaved={async () => { setRefresh((n) => n + 1); await onChanged(); }} />}
      <AssignSuggestions interventionId={iv.id} day={day || undefined} refreshKey={refresh} selected={picked?.technicianId ?? iv.technicianId ?? undefined}
        pickLabel={t('Choisir')} onPick={(c, r) => {
          setPicked(c);
          if (!start) setStart(r.slot ? toLocalInput(new Date(r.slot.start)) : `${r.day}T09:00`);
        }} />
      {picked && (
        <div className="row" style={{ alignItems: 'flex-end', background: 'var(--ground)', padding: 10, borderRadius: 10 }}>
          <strong className="grow">{t('Planifier avec {name}', { name: picked.name })}</strong>
          <div className="field"><label htmlFor="sg-start">{t('Début')}</label><input id="sg-start" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} /></div>
          <div className="field" style={{ width: 100 }}><label htmlFor="sg-h">{t('Durée (h)')}</label><input id="sg-h" type="number" min="0.25" step="0.25" value={hours} onChange={(e) => setHours(e.target.value)} /></div>
          <button type="button" onClick={() => void plan()}>{t('Valider')}</button>
          <button type="button" className="secondary" onClick={() => setPicked(null)}>{t('Annuler')}</button>
        </div>
      )}
      {error && <p className="error small">{error}</p>}
    </section>
  );
}

/** Matériel à prévoir : articles du catalogue et quantités (le stock des véhicules est comparé à cette liste) */
function NeededParts({ iv, onSaved }: { iv: InterventionDetail; onSaved: () => Promise<void> }) {
  const [parts, setParts] = useState(iv.neededParts ?? []);
  const [articles, setArticles] = useState<Article[]>([]);
  const [q, setQ] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [names, setNames] = useState<Map<string, string>>(new Map());

  useEffect(() => setParts(iv.neededParts ?? []), [iv.neededParts]);
  // Noms des articles déjà prévus
  useEffect(() => {
    if (!(iv.neededParts ?? []).length) return;
    api<Article[]>(`/articles${qs({ companyId: iv.companyId, all: true })}`)
      .then((list) => setNames(new Map(list.map((a) => [a.id, `${a.reference} · ${a.name}`])))).catch(() => undefined);
  }, [iv.companyId, iv.neededParts]);
  useEffect(() => {
    if (!q.trim()) return setArticles([]);
    const timer = window.setTimeout(() => {
      api<Article[]>(`/articles${qs({ companyId: iv.companyId, q })}`).then((r) => setArticles(r.slice(0, 8))).catch(() => setArticles([]));
    }, 250);
    return () => window.clearTimeout(timer);
  }, [q, iv.companyId]);

  const save = async (next: { articleId: string; quantity: number }[]) => {
    setError(null);
    try {
      await api(`/interventions/${iv.id}/needed-parts`, { method: 'PUT', body: { parts: next } });
      setParts(next);
      await onSaved();
    } catch (e) {
      setError((e as Error).message);
    }
  };
  const add = (a: Article) => {
    setNames((m) => new Map(m).set(a.id, `${a.reference} · ${a.name}`));
    setQ('');
    setArticles([]);
    const existing = parts.find((p) => p.articleId === a.id);
    void save(existing ? parts.map((p) => (p.articleId === a.id ? { ...p, quantity: p.quantity + 1 } : p)) : [...parts, { articleId: a.id, quantity: 1 }]);
  };

  return (
    <div className="stack" style={{ gap: 6 }}>
      <strong className="small">{t('Matériel à prévoir')}</strong>
      {parts.length === 0 && <span className="small muted">{t('Rien de prévu. Ajoutez les articles à emporter : la suggestion vérifie le stock de chaque véhicule (les bons de sortie en préparation pour cette intervention comptent aussi).')}</span>}
      {parts.map((p) => (
        <div key={p.articleId} className="row" style={{ gap: 6 }}>
          <input type="number" min="1" step="1" value={p.quantity} style={{ width: 80 }} aria-label={t('Quantité')}
            onChange={(e) => setParts(parts.map((x) => (x.articleId === p.articleId ? { ...x, quantity: Number(e.target.value) || 1 } : x)))}
            onBlur={() => void save(parts)} />
          <span className="grow small">{names.get(p.articleId) ?? '…'}</span>
          <button type="button" className="ghost" onClick={() => void save(parts.filter((x) => x.articleId !== p.articleId))} aria-label={t('Retirer')}>✕</button>
        </div>
      ))}
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Ajouter un article : référence ou nom')} aria-label={t('Ajouter un article')} />
      {articles.length > 0 && (
        <div className="msg-people" style={{ maxHeight: 200 }}>
          {articles.map((a) => <button key={a.id} type="button" className="ghost" style={{ justifyContent: 'flex-start' }} onClick={() => add(a)}>{a.reference} · {a.name}</button>)}
        </div>
      )}
      {error && <p className="error small">{error}</p>}
    </div>
  );
}
