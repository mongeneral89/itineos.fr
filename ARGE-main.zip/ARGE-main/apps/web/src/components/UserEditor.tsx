/**
 * Fiche d'un compte (Organisation et comptes) : identité, téléphone, compétences, langue, rôles avec leur périmètre
 * (tout le groupe, une société ou une agence), blocage, et nouveau lien d'invitation (mot de passe oublié, nouveau
 * téléphone). Le serveur vérifie les droits : on ne donne que ce qu'on peut soi-même attribuer.
 */
import { useEffect, useState, type FormEvent } from 'react';
import { ROLE_LABELS, ROLES, UI_LOCALE_LABELS, UI_LOCALES, type Role } from '@itineo/shared';
import { api } from '../api';
import { useAuth } from '../auth';
import { t, tl } from '../i18n';
import { InvitePanel } from './InvitePanel';

interface Assignment { role: Role; companyId: string | null; agencyId: string | null }
interface Account {
  id: string; email: string; firstName: string; lastName: string; phone: string | null; skills: string[]; locale: string;
  active: boolean; roles: Assignment[]; canEdit: boolean; self: boolean;
}

/** « société|agence » ↔ périmètre ; vide = tout le groupe */
const scopeKey = (a: Assignment) => (a.companyId ? `${a.companyId}|${a.agencyId ?? ''}` : '');
const fromKey = (key: string): Pick<Assignment, 'companyId' | 'agencyId'> => {
  if (!key) return { companyId: null, agencyId: null };
  const [companyId, agencyId] = key.split('|');
  return { companyId, agencyId: agencyId || null };
};

export function UserEditor({ userId, onDone }: { userId: string; onDone: () => void }) {
  const { me } = useAuth();
  const [acc, setAcc] = useState<Account | null>(null);
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', skills: '', locale: 'fr-FR' });
  const [roles, setRoles] = useState<Assignment[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [inviting, setInviting] = useState(false);

  const load = () => api<Account>(`/users/${userId}`).then((a) => {
    setAcc(a);
    setForm({ firstName: a.firstName, lastName: a.lastName, email: a.email, phone: a.phone ?? '', skills: a.skills.join(', '), locale: a.locale });
    setRoles(a.roles);
  }).catch((e) => setError((e as Error).message));
  useEffect(() => { void load(); }, [userId]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => { setSaved(false); setForm((f) => ({ ...f, [k]: e.target.value })); };
  const scopes = [
    { key: '', label: t('Tout le groupe') },
    ...(me?.org ?? []).flatMap((c) => [
      { key: `${c.id}|`, label: t('Toute la société {name}', { name: c.name }) },
      ...c.agencies.map((a) => ({ key: `${c.id}|${a.id}`, label: `${c.name} · ${a.name}` })),
    ]),
  ];

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api(`/users/${userId}`, {
        method: 'PATCH',
        body: {
          firstName: form.firstName, lastName: form.lastName, email: form.email, phone: form.phone || null, locale: form.locale,
          skills: form.skills.split(',').map((s) => s.trim()).filter(Boolean),
          ...(acc?.self ? {} : { assignments: roles }),
        },
      });
      setSaved(true);
      await load();
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };
  const setActive = async (active: boolean) => {
    if (!active && !window.confirm(t('Bloquer {name} ? Il ne pourra plus se connecter, et son appli sera déconnectée tout de suite.', { name: `${acc?.firstName} ${acc?.lastName}` }))) return;
    setError(null);
    try {
      await api(`/users/${userId}`, { method: 'PATCH', body: { active } });
      await load();
      onDone();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  if (!acc) return <div className="card">{error ? <p className="error">{error}</p> : <p className="muted">{t('Chargement…')}</p>}</div>;
  const ro = !acc.canEdit;
  return (
    <form className="card stack user-editor" onSubmit={save}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h3>{acc.firstName} {acc.lastName} {!acc.active && <span className="badge danger">{t('Bloqué')}</span>}</h3>
        <button type="button" className="ghost small" onClick={onDone}>{t('Fermer')}</button>
      </div>
      {ro && <p className="small muted">{t('Vous pouvez consulter ce compte, mais pas le modifier : il a des droits que vous ne pouvez pas attribuer.')}</p>}
      <fieldset disabled={ro} className="stack" style={{ border: 0, padding: 0, margin: 0 }}>
        <div className="row">
          <div className="field grow"><label htmlFor="ue-first">{t('Prénom')}</label><input id="ue-first" value={form.firstName} onChange={set('firstName')} required /></div>
          <div className="field grow"><label htmlFor="ue-last">{t('Nom')}</label><input id="ue-last" value={form.lastName} onChange={set('lastName')} required /></div>
        </div>
        <div className="row">
          <div className="field grow"><label htmlFor="ue-email">{t('E-mail')}</label><input id="ue-email" type="email" value={form.email} onChange={set('email')} required /></div>
          <div className="field grow"><label htmlFor="ue-phone">{t('Téléphone (pour WhatsApp)')}</label><input id="ue-phone" type="tel" value={form.phone} onChange={set('phone')} /></div>
        </div>
        <div className="row">
          <div className="field grow"><label htmlFor="ue-skills">{t('Compétences (séparées par des virgules)')}</label><input id="ue-skills" value={form.skills} onChange={set('skills')} /></div>
          <div className="field">
            <label htmlFor="ue-locale">{t('Langue')}</label>
            <select id="ue-locale" value={UI_LOCALES.find((l) => l.slice(0, 2) === form.locale.slice(0, 2)) ?? 'fr-FR'} onChange={set('locale')}>
              {UI_LOCALES.map((l) => <option key={l} value={l}>{UI_LOCALE_LABELS[l]}</option>)}
            </select>
          </div>
        </div>

        <div className="stack" style={{ gap: 6 }}>
          <strong>{t('Rôles et périmètre')}</strong>
          {acc.self && <p className="small muted">{t('Vos propres rôles se changent par un autre responsable.')}</p>}
          {roles.map((r, k) => (
            <div key={k} className="row" style={{ gap: 6 }}>
              <select aria-label={t('Rôle')} value={r.role} disabled={acc.self}
                onChange={(e) => { setSaved(false); setRoles((list) => list.map((x, i) => (i === k ? { ...x, role: e.target.value as Role } : x))); }}>
                {ROLES.map((role) => <option key={role} value={role}>{tl(ROLE_LABELS, role)}</option>)}
              </select>
              <select aria-label={t('Périmètre')} className="grow" value={scopeKey(r)} disabled={acc.self}
                onChange={(e) => { setSaved(false); setRoles((list) => list.map((x, i) => (i === k ? { ...x, ...fromKey(e.target.value) } : x))); }}>
                {scopes.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
              {!acc.self && roles.length > 1 && (
                <button type="button" className="ghost" aria-label={t('Retirer ce rôle')} onClick={() => setRoles((list) => list.filter((_, i) => i !== k))}>✕</button>
              )}
            </div>
          ))}
          {!acc.self && (
            <button type="button" className="ghost small" style={{ alignSelf: 'flex-start' }}
              onClick={() => setRoles((list) => [...list, { role: 'TECHNICIAN', companyId: list[0]?.companyId ?? me?.org[0]?.id ?? null, agencyId: null }])}>
              {t('+ Ajouter un rôle')}
            </button>
          )}
        </div>
      </fieldset>

      {error && <p className="error" role="alert">{error}</p>}
      {saved && <p className="success small" role="status">{t('Compte enregistré.')}</p>}
      {!ro && (
        <div className="row">
          <button type="submit">{t('Enregistrer')}</button>
          <button type="button" className="secondary" onClick={() => setInviting((v) => !v)}>{t('Nouveau lien d’accès')}</button>
          <div className="grow" />
          {!acc.self && (acc.active
            ? <button type="button" className="secondary danger-text" onClick={() => void setActive(false)}>{t('Bloquer le compte')}</button>
            : <button type="button" className="accent" onClick={() => void setActive(true)}>{t('Débloquer le compte')}</button>)}
        </div>
      )}
      {inviting && <InvitePanel userId={userId} onClose={() => setInviting(false)} />}
    </form>
  );
}
