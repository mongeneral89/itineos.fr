/**
 * Logiciel du bureau : propose d'activer les notifications sur cet ordinateur dès la connexion, au lieu de les
 * laisser cachées dans « Mon compte ». « Plus tard » la fait disparaître une semaine.
 */
import { useEffect, useState } from 'react';
import { api } from '../api';
import { t } from '../i18n';
import { isNativeApp } from '../native';
import { enablePush, isPushActive, needsHomeScreen, pushSupported } from '../push';

const KEY = 'itineo.pushPrompt';
const WEEK = 7 * 86400_000;

function dismissedRecently(): boolean {
  try { return Date.now() - Number(localStorage.getItem(KEY) ?? 0) < WEEK; } catch { return true; }
}

export function PushPrompt() {
  const [show, setShow] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isNativeApp() || !pushSupported() || needsHomeScreen() || dismissedRecently()) return;
    // Déjà refusées dans le navigateur : inutile de redemander (le réglage se fait dans le navigateur)
    if (Notification.permission === 'denied') return;
    void isPushActive().then((on) => setShow(!on)).catch(() => undefined);
  }, []);

  if (!show) return null;
  const later = () => {
    try { localStorage.setItem(KEY, String(Date.now())); } catch { /* pas de stockage : affiché de nouveau */ }
    setShow(false);
  };
  const enable = async () => {
    try {
      const { publicKey } = await api<{ publicKey: string }>('/notifications/config');
      if (await enablePush(publicKey)) setShow(false);
      else setMsg(t('Notifications refusées : autorisez-les dans les réglages du navigateur pour ce site.'));
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  return (
    <div className="push-prompt" role="region" aria-label={t('Notifications')}>
      <span aria-hidden="true">🔔</span>
      <span className="grow">{t('Être prévenu sur cet ordinateur quand une intervention est terminée, en retard, ou qu’un message arrive ?')}</span>
      <button type="button" className="accent" onClick={() => void enable()}>{t('Activer')}</button>
      <button type="button" className="ghost" onClick={later}>{t('Plus tard')}</button>
      {msg && <p className="error small" role="alert" style={{ width: '100%' }}>{msg}</p>}
    </div>
  );
}
