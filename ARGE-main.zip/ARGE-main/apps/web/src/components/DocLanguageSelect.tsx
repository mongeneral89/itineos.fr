﻿/** Choix de la langue des documents d'un client : celle de la société, ou l'une des langues de l'interface */
import { UI_LOCALE_LABELS, UI_LOCALES } from '@itineo/shared';
import { t } from '../i18n';

export function DocLanguageSelect({ id, value, onChange, disabled }: { id: string; value: string; onChange: (v: string) => void; disabled?: boolean }) {
  return (
    <select id={id} value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
      <option value="">{t('Langue de la société')}</option>
      {UI_LOCALES.map((l) => <option key={l} value={l}>{UI_LOCALE_LABELS[l]}</option>)}
    </select>
  );
}
