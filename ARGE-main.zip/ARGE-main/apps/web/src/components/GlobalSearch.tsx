/**
 * Recherche du logiciel (en haut du menu) : un client ou une intervention par son nom, son numéro ou sa ville,
 * sans passer par chaque page. Entrée ouvre le premier résultat.
 */
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, qs } from '../api';
import { useAuth } from '../auth';
import { t } from '../i18n';
import type { InterventionRow } from '../types';
import { fmtDay } from '../format';

interface ClientHit { id: string; name: string; city?: string | null }
interface Hit { key: string; label: string; sub: string; to: string }

export function GlobalSearch() {
  const { company, agency, has } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<Hit[] | null>(null);
  const [active, setActive] = useState(0);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const text = q.trim();
    if (text.length < 2 || !company) return setHits(null);
    let cancelled = false;
    // Attente courte : pas une requête par lettre tapée
    const timer = window.setTimeout(async () => {
      const scope = { companyId: company.id, agencyId: agency?.id };
      const [clients, jobs] = await Promise.all([
        has('client.read') ? api<ClientHit[]>(`/clients${qs({ ...scope, q: text, limit: 5 })}`).catch(() => []) : Promise.resolve([] as ClientHit[]),
        has('intervention.read') ? api<InterventionRow[]>(`/interventions${qs({ ...scope, q: text, limit: 6 })}`).catch(() => []) : Promise.resolve([] as InterventionRow[]),
      ]);
      if (cancelled) return;
      setActive(0);
      setHits([
        ...clients.map((c) => ({ key: `c-${c.id}`, label: c.name, sub: [t('Client'), c.city].filter(Boolean).join(' · '), to: `/clients/${c.id}` })),
        ...jobs.map((iv) => ({
          key: `i-${iv.id}`, label: `${iv.number} · ${iv.clientName}`,
          sub: [iv.siteCity, iv.scheduledStart ? fmtDay(iv.scheduledStart.slice(0, 10)) : t('à planifier')].filter(Boolean).join(' · '),
          to: `/interventions/${iv.id}`,
        })),
      ]);
    }, 250);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [q, company, agency, has]);

  // Fermée par un clic ailleurs
  useEffect(() => {
    if (!hits) return;
    const outside = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setHits(null); };
    document.addEventListener('mousedown', outside);
    return () => document.removeEventListener('mousedown', outside);
  }, [hits]);

  const open = (h: Hit) => {
    setQ('');
    setHits(null);
    navigate(h.to);
  };
  const onKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!hits?.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive((a) => Math.min(hits.length - 1, a + 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(0, a - 1)); }
    if (e.key === 'Enter') { e.preventDefault(); open(hits[active]); }
    if (e.key === 'Escape') setHits(null);
  };

  return (
    <div className="gsearch" ref={box}>
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={onKey}
        placeholder={t('Rechercher : client, n°, ville…')} aria-label={t('Rechercher un client ou une intervention')} />
      {hits && (
        <div className="gsearch-panel" role="listbox">
          {!hits.length && <p className="small muted gsearch-empty">{t('Aucun résultat.')}</p>}
          {hits.map((h, k) => (
            <button key={h.key} type="button" role="option" aria-selected={k === active} className={`gsearch-hit${k === active ? ' on' : ''}`}
              onMouseEnter={() => setActive(k)} onClick={() => open(h)}>
              <strong>{h.label}</strong>
              <span className="small muted">{h.sub}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
