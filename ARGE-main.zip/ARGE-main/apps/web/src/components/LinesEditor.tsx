/**
 * Tableau de lignes d'un devis ou d'une facture : désignation, quantité, unité, prix HT, TVA,
 * avec les totaux par taux calculés en direct.
 */
import { useEffect, useState } from 'react';
import { documentTotals, formatMoney, formatVatRate, lineNetCents } from '@itineo/shared';
import { api } from '../api';
import { moneyInput, parseMoneyInput } from '../format';
import type { Article, QuoteLine } from '../types';
import { t } from '../i18n';

/** Ligne en cours de saisie : quantité et prix gardés en texte tant que l'utilisateur tape */
export interface ELine { key: number; description: string; qty: string; unit: string; price: string; vatRateBp: number }

let lineKey = 0;
export const newLine = (vat: number, l: Partial<ELine> = {}): ELine =>
  ({ key: ++lineKey, description: '', qty: '1', unit: '', price: '', vatRateBp: vat, ...l });

export const toELines = (lines: QuoteLine[]): ELine[] => lines.map((l) => newLine(l.vatRateBp, {
  description: l.description, qty: String(l.quantity).replace('.', ','), unit: l.unit ?? '', price: moneyInput(l.unitPriceCents),
}));

const parseQty = (s: string) => {
  const n = Number(s.replace(',', '.'));
  return Number.isFinite(n) && n > 0 ? n : null;
};

export interface ParsedLine { description: string; quantity: number | null; unit: string | null; unitPriceCents: number | null; vatRateBp: number }

export const parseLines = (lines: ELine[]): ParsedLine[] => lines.map((l) => ({
  description: l.description.trim(),
  quantity: parseQty(l.qty),
  unit: l.unit.trim() || null,
  unitPriceCents: parseMoneyInput(l.price),
  vatRateBp: l.vatRateBp,
}));

const isBlank = (l: ELine) => !l.description.trim() && !l.price.trim();

/** Catalogue d'articles de la société, pour remplir les lignes (vide si l'utilisateur n'y a pas accès) */
export function useCatalog(companyId: string | undefined, enabled: boolean): Article[] | undefined {
  const [list, setList] = useState<Article[] | undefined>(undefined);
  useEffect(() => {
    if (!companyId || !enabled) return;
    let cancelled = false;
    api<Article[]>(`/articles?companyId=${companyId}`).then((a) => !cancelled && setList(a)).catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [companyId, enabled]);
  return list;
}

/** Problèmes de saisie, ligne par ligne (les lignes vides sont ignorées) */
export function lineProblems(lines: ELine[]): string[] {
  const out: string[] = [];
  parseLines(lines).forEach((p, i) => {
    if (isBlank(lines[i])) return;
    if (!p.description) out.push(t('Ligne {n} : désignation manquante.', { n: i + 1 }));
    if (p.quantity === null) out.push(t('Ligne {n} : quantité invalide.', { n: i + 1 }));
    if (p.unitPriceCents === null) out.push(t('Ligne {n} : prix invalide (ex. 125,50).', { n: i + 1 }));
  });
  return out;
}

/** Lignes prêtes à envoyer au serveur (à appeler après lineProblems) */
export const linesPayload = (lines: ELine[]): QuoteLine[] =>
  parseLines(lines).filter((_, i) => !isBlank(lines[i])) as QuoteLine[];

export function LinesEditor({ lines, onChange, editable, rates, currency, locale, articles }: {
  lines: ELine[];
  onChange: (lines: ELine[]) => void;
  editable: boolean;
  rates: number[];
  currency: string;
  locale?: string;
  /** Catalogue : choisir un article remplit la ligne (désignation, unité, prix, TVA) */
  articles?: Article[];
}) {
  const parsed = parseLines(lines);
  const valid = parsed.filter((l) => l.quantity !== null && l.unitPriceCents !== null) as QuoteLine[];
  const totals = documentTotals(valid);
  const money = (c: number) => formatMoney(c, currency, locale);
  const setLine = (key: number, patch: Partial<ELine>) => onChange(lines.map((l) => (l.key === key ? { ...l, ...patch } : l)));
  const setDescription = (key: number, text: string) => {
    const art = articles?.find((a) => `${a.reference} – ${a.name}` === text);
    if (!art) return setLine(key, { description: text });
    setLine(key, {
      description: art.name, unit: art.unit, vatRateBp: art.vatRateBp,
      ...(art.salePriceCents != null ? { price: moneyInput(art.salePriceCents) } : {}),
    });
  };

  return (
    <>
      {articles && editable && (
        <datalist id="catalog-articles">
          {articles.map((a) => <option key={a.id} value={`${a.reference} – ${a.name}`}>{a.salePriceCents != null ? t('{amount} HT / {unit}', { amount: money(a.salePriceCents), unit: a.unit }) : ''}</option>)}
        </datalist>
      )}
      <div className="table-wrap">
        <table className="lines">
          <thead><tr><th>{t('Désignation')}</th><th style={{ width: 80 }}>{t('Qté')}</th><th style={{ width: 70 }}>{t('Unité')}</th><th style={{ width: 120 }}>{t('PU HT')}</th><th style={{ width: 100 }}>{t('TVA')}</th><th style={{ width: 120, textAlign: 'right' }}>{t('Total HT')}</th>{editable && <th style={{ width: 40 }} />}</tr></thead>
          <tbody>
            {lines.map((l, i) => {
              const p = parsed[i];
              const net = p.quantity !== null && p.unitPriceCents !== null ? lineNetCents(p as QuoteLine) : null;
              return (
                <tr key={l.key}>
                  <td><input aria-label={t('Désignation ligne {n}', { n: i + 1 })} value={l.description} disabled={!editable} list={articles ? 'catalog-articles' : undefined}
                    autoComplete="off" onChange={(e) => setDescription(l.key, e.target.value)} /></td>
                  <td><input aria-label={t('Quantité ligne {n}', { n: i + 1 })} inputMode="decimal" value={l.qty} disabled={!editable} onChange={(e) => setLine(l.key, { qty: e.target.value })} aria-invalid={p.quantity === null} /></td>
                  <td><input aria-label={t('Unité ligne {n}', { n: i + 1 })} value={l.unit} disabled={!editable} maxLength={20} placeholder={t('u, h, m…')} onChange={(e) => setLine(l.key, { unit: e.target.value })} /></td>
                  <td><input aria-label={t('Prix unitaire ligne {n}', { n: i + 1 })} inputMode="decimal" value={l.price} disabled={!editable} placeholder="0,00" onChange={(e) => setLine(l.key, { price: e.target.value })} aria-invalid={!!l.price.trim() && p.unitPriceCents === null} /></td>
                  <td>
                    <select aria-label={t('TVA ligne {n}', { n: i + 1 })} value={l.vatRateBp} disabled={!editable} onChange={(e) => setLine(l.key, { vatRateBp: Number(e.target.value) })}>
                      {[...new Set([...rates, l.vatRateBp])].map((r) => <option key={r} value={r}>{formatVatRate(r)}</option>)}
                    </select>
                  </td>
                  <td style={{ textAlign: 'right' }}>{net === null ? '—' : money(net)}</td>
                  {editable && <td><button type="button" className="ghost" aria-label={t('Supprimer la ligne {n}', { n: i + 1 })} onClick={() => onChange(lines.filter((x) => x.key !== l.key))}>✕</button></td>}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {editable && <div><button type="button" className="secondary" onClick={() => onChange([...lines, newLine(rates[0])])}>{t('+ Ajouter une ligne')}</button></div>}
      <div className="totals">
        <div><span>{t('Total HT')}</span><strong>{money(totals.netCents)}</strong></div>
        {totals.byRate.map((r) => (
          <div key={r.vatRateBp} className="small"><span>{t('TVA {rate} sur {base}', { rate: formatVatRate(r.vatRateBp), base: money(r.baseCents) })}</span><span>{money(r.vatCents)}</span></div>
        ))}
        <div className="grand"><span>{t('Total TTC')}</span><strong>{money(totals.grossCents)}</strong></div>
      </div>
    </>
  );
}
