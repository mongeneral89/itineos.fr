/**
 * Lien avec le support de l'éditeur (console de supervision) :
 *  - « Signaler un problème » : la description part au support avec la page en cours ;
 *  - bandeau des administrateurs : le support demande l'accès (accepter / refuser), ou un accès est en cours.
 * Rien ne s'affiche si l'installation n'est pas reliée à une console.
 */
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useLocation } from 'react-router-dom';
import { api } from '../api';
import { fmtDateTime } from '../format';
import { t } from '../i18n';

interface SupportStatus { enabled: boolean; canDecide: boolean }
interface Access { id: string; reason: string; hours: number; status: 'PENDING' | 'APPROVED'; expiresAt: string | null }

function useSupportStatus() {
  const [s, setS] = useState<SupportStatus | null>(null);
  useEffect(() => { api<SupportStatus>('/support/status').then(setS).catch(() => setS(null)); }, []);
  return s;
}

export function ReportProblemButton() {
  const status = useSupportStatus();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [state, setState] = useState<'idle' | 'sending' | 'sent'>('idle');
  const [error, setError] = useState<string | null>(null);
  if (!status?.enabled) return null;
  const send = async (e: FormEvent) => {
    e.preventDefault();
    setState('sending');
    setError(null);
    try {
      await api('/support/report', { method: 'POST', body: { message, page: pathname } });
      setState('sent');
      setMessage('');
    } catch (err) {
      setError((err as Error).message);
      setState('idle');
    }
  };
  return (
    <>
      <button type="button" className="secondary" style={{ color: '#F4F2EE', borderColor: '#3A4150' }} onClick={() => { setOpen(true); setState('idle'); }}>
        {t('Signaler un problème')}
      </button>
      {open && (
        <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={t('Signaler un problème')}
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)', display: 'grid', placeItems: 'center', zIndex: 50, padding: 16 }}>
          <form className="card" onSubmit={send} style={{ maxWidth: 480, width: '100%', display: 'flex', flexDirection: 'column', gap: 12 }}>
            <h2>{t('Signaler un problème')}</h2>
            {state === 'sent' ? (
              <p>{t('Merci : votre message est parti au support, avec la page où vous étiez.')}</p>
            ) : (
              <>
                <p className="muted small">{t('Décrivez ce qui ne va pas : ce que vous faisiez, ce qui s’est passé. La page en cours est jointe automatiquement.')}</p>
                <textarea rows={5} value={message} onChange={(e) => setMessage(e.target.value)} required minLength={5} aria-label={t('Description du problème')} />
                {error && <p className="error">{error}</p>}
              </>
            )}
            <div className="row">
              {state !== 'sent' && <button type="submit" className="accent" disabled={state === 'sending'}>{t('Envoyer au support')}</button>}
              <button type="button" className="secondary" onClick={() => setOpen(false)}>{t('Fermer')}</button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}

export function SupportBanner() {
  const status = useSupportStatus();
  const [list, setList] = useState<Access[]>([]);
  const load = useCallback(() => { api<Access[]>('/support/access').then(setList).catch(() => setList([])); }, []);
  useEffect(() => {
    if (!status?.enabled || !status.canDecide) return;
    load();
    const timer = setInterval(load, 60_000);
    return () => clearInterval(timer);
  }, [status, load]);
  if (!status?.enabled || !status.canDecide || !list.length) return null;
  const act = async (id: string, path: string, body?: unknown) => {
    await api(`/support/access/${id}/${path}`, { method: 'POST', body });
    load();
  };
  return (
    <>
      {list.map((a) => (
        <div key={a.id} className="card" role="status" style={{ borderColor: 'var(--accent)', display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
          {a.status === 'PENDING' ? (
            <>
              <div>
                <strong>{t('Le support demande l’accès à votre logiciel pendant {n} h', { n: a.hours })}</strong>
                <div className="small">{t('Motif : {reason}', { reason: a.reason })}</div>
                <div className="small muted">{t('Un compte « Support » sera ouvert pour cette durée, puis fermé automatiquement. Tout ce qu’il fait est tracé.')}</div>
              </div>
              <div className="row">
                <button type="button" className="accent" onClick={() => act(a.id, 'decide', { approve: true })}>{t('Autoriser')}</button>
                <button type="button" className="secondary" onClick={() => act(a.id, 'decide', { approve: false })}>{t('Refuser')}</button>
              </div>
            </>
          ) : (
            <>
              <div><strong>{t('Accès du support ouvert jusqu’à {date}', { date: fmtDateTime(a.expiresAt) })}</strong></div>
              <button type="button" className="secondary" onClick={() => act(a.id, 'close')}>{t('Fermer l’accès maintenant')}</button>
            </>
          )}
        </div>
      ))}
    </>
  );
}
