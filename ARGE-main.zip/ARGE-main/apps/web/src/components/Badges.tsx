import {
  PRIORITY_LABELS, STATUS_LABELS,
  type InterventionKind, type InterventionStatus, type Priority,
} from '@itineo/shared';
import { kindLabel, tl } from '../i18n';

const statusTone: Record<InterventionStatus, string> = {
  TO_PLAN: 'warn', PLANNED: 'neutral', EN_ROUTE: 'info', ON_SITE: 'dark', DONE: 'ok', TO_RESUME: 'warn', CANCELLED: 'neutral',
};
const kindTone: Record<InterventionKind, string> = {
  SAV: 'warn', INSTALLATION: 'info', MAINTENANCE: 'ok', OTHER: 'neutral',
};

export function StatusBadge({ status }: { status: InterventionStatus }) {
  return <span className={`badge ${statusTone[status]}`}>{tl(STATUS_LABELS, status)}</span>;
}

export function KindBadge({ kind }: { kind: InterventionKind }) {
  return <span className={`badge ${kindTone[kind]}`}>{kindLabel(kind)}</span>;
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  if (priority === 'NORMAL' || priority === 'LOW') return null;
  return <span className={`badge ${priority === 'URGENT' ? 'warn' : 'neutral'}`}>{tl(PRIORITY_LABELS, priority)}</span>;
}
