/**
 * Cloche des notifications (logiciel du bureau et appli terrain) : nombre de non-lues, liste des dernières, une
 * notification touchée ouvre sa page. Tout y est gardé, même ce que l'appareil n'a pas affiché.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { t, tp, uiLocale } from '../i18n';

interface Item { id: string; kind: string; title: string; body: string; url: string; createdAt: string; readAt: string | null }

const ICONS: Record<string, string> = {
  message: '💬', assignment: '📅', procedure: '📄', completed: '✅', followup: '⚠️', late: '🕐', request: '📩', quote: '📝', alert: '🆘',
};

/** « il y a 5 min », « hier »… dans la langue de l'interface */
function ago(iso: string): string {
  const s = (new Date(iso).getTime() - Date.now()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(uiLocale(), { numeric: 'auto' });
  if (s > -60) return rtf.format(0, 'second');
  if (s > -3600) return rtf.format(Math.round(s / 60), 'minute');
  if (s > -86400) return rtf.format(Math.round(s / 3600), 'hour');
  return rtf.format(Math.round(s / 86400), 'day');
}

export function NotificationBell({ className = '' }: { className?: string }) {
  const navigate = useNavigate();
  const [count, setCount] = useState(0);
  const [items, setItems] = useState<Item[] | null>(null);
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);

  const refresh = useCallback(() => {
    if (document.visibilityState === 'hidden') return;
    api<{ count: number }>('/notifications/unread').then((r) => setCount(r.count)).catch(() => undefined);
  }, []);
  useEffect(() => {
    refresh();
    const timer = window.setInterval(refresh, 30_000);
    document.addEventListener('visibilitychange', refresh);
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', refresh); };
  }, [refresh]);

  const toggle = async () => {
    if (open) return setOpen(false);
    setOpen(true);
    const r = await api<{ items: Item[]; unread: number }>('/notifications/inbox').catch(() => null);
    if (r) { setItems(r.items); setCount(r.unread); }
  };
  // Fermée par un clic ailleurs ou Échap
  useEffect(() => {
    if (!open) return;
    const outside = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', outside);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', outside); document.removeEventListener('keydown', esc); };
  }, [open]);

  const go = (n: Item) => {
    setOpen(false);
    if (!n.readAt) {
      setCount((c) => Math.max(0, c - 1));
      void api('/notifications/read', { method: 'POST', body: { ids: [n.id] } }).catch(() => undefined);
    }
    navigate(n.url);
  };
  const readAll = async () => {
    await api('/notifications/read', { method: 'POST', body: {} }).catch(() => undefined);
    setCount(0);
    setItems((list) => list?.map((n) => ({ ...n, readAt: n.readAt ?? new Date().toISOString() })) ?? null);
  };

  return (
    <div className={`bell ${className}`} ref={box}>
      <button type="button" className="bell-button" onClick={() => void toggle()} aria-expanded={open}
        aria-label={count ? tp(count, '{n} notification non lue', '{n} notifications non lues') : t('Notifications')} title={t('Notifications')}>
        <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4a1.5 1.5 0 0 0-3 0v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" /></svg>
        {count > 0 && <span className="bell-count">{count > 99 ? '99+' : count}</span>}
      </button>
      {open && (
        <div className="bell-panel" role="dialog" aria-label={t('Notifications')}>
          <div className="bell-head">
            <strong>{t('Notifications')}</strong>
            {count > 0 && <button type="button" className="ghost small" onClick={() => void readAll()}>{t('Tout marquer comme lu')}</button>}
          </div>
          {!items && <p className="muted small bell-empty">{t('Chargement…')}</p>}
          {items && !items.length && <p className="muted small bell-empty">{t('Aucune notification pour le moment.')}</p>}
          {items && items.length > 0 && (
            <ul className="bell-list">
              {items.map((n) => (
                <li key={n.id}>
                  <button type="button" className={`bell-item${n.readAt ? '' : ' unread'}`} onClick={() => go(n)}>
                    <span className="bell-icon" aria-hidden="true">{ICONS[n.kind] ?? '🔔'}</span>
                    <span className="bell-text">
                      <strong>{n.title}</strong>
                      <span className="small">{n.body}</span>
                      <span className="small muted">{ago(n.createdAt)}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
