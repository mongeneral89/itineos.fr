import { useEffect, useRef, useState } from 'react';
import { t } from '../i18n';

// La reconnaissance vocale du navigateur (Chrome, Edge, Safari). Pas de type officiel dans TypeScript.
type Recognition = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
};

function getRecognitionClass(): (new () => Recognition) | null {
  const w = window as unknown as { SpeechRecognition?: new () => Recognition; webkitSpeechRecognition?: new () => Recognition };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export const dictationSupported = () => !!getRecognitionClass();

/**
 * Bouton micro : le texte dicté est ajouté à la suite du champ.
 * Le navigateur peut demander l'autorisation d'utiliser le micro.
 */
export function DictationButton({ lang, onText }: { lang: string; onText: (text: string) => void }) {
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const rec = useRef<Recognition | null>(null);

  useEffect(() => () => rec.current?.stop(), []);

  const Klass = getRecognitionClass();
  if (!Klass) return null;

  const toggle = () => {
    if (listening) {
      rec.current?.stop();
      return;
    }
    setError(null);
    const r = new Klass();
    r.lang = lang;
    r.continuous = true;
    r.interimResults = false;
    r.onresult = (e) => {
      let text = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) text += e.results[i][0].transcript;
      }
      if (text.trim()) onText(text.trim());
    };
    r.onerror = (e) => setError(e.error === 'not-allowed' ? t('Micro refusé') : t('Dictée interrompue'));
    r.onend = () => setListening(false);
    rec.current = r;
    r.start();
    setListening(true);
  };

  return (
    <span className="row" style={{ gap: 6 }}>
      <button type="button" className={`mic accent${listening ? ' listening' : ''}`} onClick={toggle} aria-pressed={listening}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
          <rect x="9" y="3" width="6" height="11" rx="3" />
          <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
        </svg>
        {listening ? t('Arrêter') : t('Dicter')}
      </button>
      {error && <span className="small error">{error}</span>}
    </span>
  );
}
