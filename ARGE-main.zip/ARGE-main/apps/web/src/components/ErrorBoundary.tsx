import { Component, type ReactNode } from 'react';
import { t } from '../i18n';

/**
 * Si une page plante, on affiche un message et un bouton pour recharger, plutôt qu'un écran blanc.
 * `resetKey` (l'adresse de la page) permet de repartir à zéro quand on change de page.
 */
export class ErrorBoundary extends Component<{ children: ReactNode; resetKey?: string }, { error: Error | null; key?: string }> {
  state: { error: Error | null; key?: string } = { error: null, key: this.props.resetKey };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  static getDerivedStateFromProps(props: { resetKey?: string }, state: { error: Error | null; key?: string }) {
    return props.resetKey !== state.key ? { error: null, key: props.resetKey } : null;
  }

  componentDidCatch(error: Error) {
    console.error('[page]', error);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <section className="card stack" role="alert" style={{ maxWidth: 560 }}>
        <h2>{t('Cette page a rencontré un problème')}</h2>
        <p className="muted">{t('Vos données enregistrées ne sont pas perdues. Rechargez la page pour continuer.')}</p>
        <div><button type="button" onClick={() => window.location.reload()}>{t('Recharger la page')}</button></div>
      </section>
    );
  }
}
