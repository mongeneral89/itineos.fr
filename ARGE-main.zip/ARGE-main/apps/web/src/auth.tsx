import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Permission } from '@itineo/shared';
import { api, ApiError, getToken, SESSION_EXPIRED, setToken } from './api';
import type { Agency, Company, Me } from './types';
import { CACHE, idb } from './offline/idb';
import { clearDeviceCopies } from './offline/field';
import { setSyncUser } from './offline/sync';
import { setLang } from './i18n';
import { disablePush } from './push';

const SELECTION_KEY = 'itineo.selection';
const ME_KEY = 'me';
const RENEWED_KEY = 'itineo.session.renewed';

/** « Rester connecté » : la session repart pour un an, au plus une fois par jour */
async function renewSession() {
  try {
    const last = Number(localStorage.getItem(RENEWED_KEY) ?? 0);
    if (Date.now() - last < 24 * 3600_000) return;
    const r = await api<{ token: string | null }>('/auth/refresh', { method: 'POST' });
    if (r.token) setToken(r.token);
    localStorage.setItem(RENEWED_KEY, String(Date.now()));
  } catch {
    /* sans réseau : on réessaiera à la prochaine ouverture */
  }
}

interface Selection { companyId: string | null; agencyId: string | null }

interface AuthState {
  me: Me | null;
  loading: boolean;
  login: (email: string, password: string, remember?: boolean) => Promise<void>;
  /** Session ouverte autrement que par le mot de passe (lien d'invitation, code de l'appli) */
  adopt: (res: { token: string; me: Me }) => Promise<void>;
  logout: () => void;
  refresh: () => Promise<void>;
  has: (perm: Permission) => boolean;
  /** Vrai si la personne n'a QUE le rôle technicien : elle arrive sur l'appli terrain */
  isTechnicianOnly: boolean;
  company: Company | null;
  agency: Agency | null;
  select: (companyId: string | null, agencyId: string | null) => void;
}

const Ctx = createContext<AuthState | null>(null);

function readSelection(): Selection {
  try {
    return JSON.parse(localStorage.getItem(SELECTION_KEY) ?? '') as Selection;
  } catch {
    return { companyId: null, agencyId: null };
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMeState] = useState<Me | null>(null);
  const [loading, setLoading] = useState(!!getToken());
  const [selection, setSelection] = useState<Selection>(readSelection);

  // Le compte est donné à la couche hors ligne AVANT l'affichage des pages :
  // elles lisent les copies de l'appareil rangées sous ce compte dès leur premier rendu
  const setMe = useCallback((next: Me | null) => {
    setSyncUser(next?.user.id ?? null);
    // L'espace client a sa propre langue (celle de la personne du client)
    if (next && !window.location.pathname.startsWith('/portail')) setLang(next.user.locale);
    setMeState(next);
  }, []);

  const refresh = useCallback(async () => {
    if (!getToken()) {
      setMe(null);
      setLoading(false);
      return;
    }
    try {
      const fresh = await api<Me>('/me');
      setMe(fresh);
      void renewSession();
      void idb.put(CACHE, fresh, ME_KEY).catch(() => undefined);
    } catch (e) {
      // Sans réseau, on reprend le profil gardé sur l'appareil : l'appli terrain reste utilisable
      const cached = e instanceof ApiError && e.status === 0
        ? await idb.get<Me>(CACHE, ME_KEY).catch(() => undefined)
        : undefined;
      setMe(cached ?? null);
    } finally {
      setLoading(false);
    }
  }, [setMe]);

  useEffect(() => {
    void refresh();
    const onExpired = () => setMe(null);
    window.addEventListener(SESSION_EXPIRED, onExpired);
    return () => window.removeEventListener(SESSION_EXPIRED, onExpired);
  }, [refresh, setMe]);

  const adopt = useCallback(async (res: { token: string; me: Me }) => {
    try {
      localStorage.setItem(RENEWED_KEY, String(Date.now()));
    } catch {
      /* ignoré */
    }
    // Autre compte sur la même tablette : les copies du précédent ne doivent pas rester visibles
    const previous = await idb.get<Me>(CACHE, ME_KEY).catch(() => undefined);
    if (previous && previous.user.id !== res.me.user.id) await clearDeviceCopies();
    setToken(res.token);
    setMe(res.me);
    void idb.put(CACHE, res.me, ME_KEY).catch(() => undefined);
  }, [setMe]);

  const login = useCallback(async (email: string, password: string, remember = false) => {
    await adopt(await api<{ token: string; me: Me }>('/auth/login', { method: 'POST', body: { email, password, remember } }));
  }, [adopt]);

  const logout = useCallback(() => {
    // Cet appareil ne reçoit plus les notifications de ce compte (tablette partagée…)
    void disablePush().catch(() => undefined).finally(() => setToken(null));
    setMe(null);
    // Les copies sont effacées ; les actions pas encore envoyées restent et partiront à la prochaine connexion
    void clearDeviceCopies();
  }, [setMe]);

  const select = useCallback((companyId: string | null, agencyId: string | null) => {
    const next = { companyId, agencyId };
    setSelection(next);
    try {
      localStorage.setItem(SELECTION_KEY, JSON.stringify(next));
    } catch {
      /* sans stockage, le choix ne sera pas retenu */
    }
  }, []);

  const value = useMemo<AuthState>(() => {
    const org = me?.org ?? [];
    // Société et agence courantes : le dernier choix s'il est encore valable, sinon la première visible
    const company = org.find((c) => c.id === selection.companyId) ?? org[0] ?? null;
    const agency = company
      ? company.agencies.find((a) => a.id === selection.agencyId) ??
        (company.agencies.length === 1 ? company.agencies[0] : null)
      : null;
    const roles = new Set(me?.assignments.map((a) => a.role) ?? []);
    return {
      me,
      loading,
      login,
      adopt,
      logout,
      refresh,
      has: (perm) => !!me?.permissions.includes(perm),
      isTechnicianOnly: roles.size === 1 && roles.has('TECHNICIAN'),
      company,
      agency,
      select,
    };
  }, [me, loading, login, adopt, logout, refresh, selection, select]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth doit être utilisé dans <AuthProvider>');
  return v;
}
