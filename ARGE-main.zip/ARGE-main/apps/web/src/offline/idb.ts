/**
 * Stockage sur l'appareil (IndexedDB), pour l'appli terrain hors connexion :
 *  - « cache » : la journée, les fiches et les photos, pour les rouvrir sans réseau
 *  - « outbox » : les modifications faites hors ligne, renvoyées dans l'ordre au retour du réseau
 */

const DB_NAME = 'itineo';
const VERSION = 1;
export const CACHE = 'cache';
export const OUTBOX = 'outbox';

let dbPromise: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(CACHE)) db.createObjectStore(CACHE);
        if (!db.objectStoreNames.contains(OUTBOX)) db.createObjectStore(OUTBOX, { keyPath: 'seq', autoIncrement: true });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => {
        dbPromise = null;
        reject(req.error ?? new Error('Stockage de l’appareil indisponible'));
      };
    });
  }
  return dbPromise;
}

function run<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest): Promise<T> {
  return open().then((db) => new Promise<T>((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const req = fn(tx.objectStore(store));
    tx.oncomplete = () => resolve(req.result as T);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  }));
}

export const idb = {
  get: <T>(store: string, key: IDBValidKey) => run<T | undefined>(store, 'readonly', (s) => s.get(key)),
  put: (store: string, value: unknown, key?: IDBValidKey) => run<IDBValidKey>(store, 'readwrite', (s) => s.put(value, key)),
  add: (store: string, value: unknown) => run<IDBValidKey>(store, 'readwrite', (s) => s.add(value)),
  delete: (store: string, key: IDBValidKey) => run<undefined>(store, 'readwrite', (s) => s.delete(key)),
  all: <T>(store: string) => run<T[]>(store, 'readonly', (s) => s.getAll()),
  keys: (store: string) => run<IDBValidKey[]>(store, 'readonly', (s) => s.getAllKeys()),
  clear: (store: string) => run<undefined>(store, 'readwrite', (s) => s.clear()),
};
