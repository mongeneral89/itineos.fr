/**
 * File d'attente des modifications de l'appli terrain.
 *
 * Chaque action du technicien (enregistrer la fiche, photo, signature, envoi…) est rangée ici,
 * puis envoyée au serveur dans l'ordre. Sans réseau, elle attend et repart toute seule
 * dès que la connexion revient (événement « online », toutes les 30 s, au démarrage).
 *
 * Réponses du serveur :
 *  - 2xx  → fait, retiré de la file
 *  - 409  → déjà fait ou plus faisable (fiche déjà signée, intervention clôturée) : retiré
 *  - réseau coupé, 401, 5xx → on s'arrête et on réessaiera plus tard, rien n'est perdu
 *  - autre 4xx → refusé : gardé avec le message, et la suite de CETTE intervention est bloquée
 */
import { useEffect, useState } from 'react';
import { api, ApiError, getToken } from '../api';
import { idb, OUTBOX } from './idb';

export type OpKind = 'save' | 'status' | 'photo.add' | 'photo.caption' | 'photo.delete' | 'sign' | 'send';

export interface Op {
  seq?: number;
  userId: string;
  interventionId: string;
  kind: OpKind;
  method: 'PUT' | 'POST' | 'PATCH' | 'DELETE';
  path: string;
  body?: Record<string, unknown>;
  createdAt: string;
  /** Refusé par le serveur : message à montrer au technicien */
  error?: string;
  errorDetails?: unknown;
}

export interface SyncState {
  online: boolean;
  syncing: boolean;
  pending: number;
  failed: Op[];
  /** Nombre d'actions en attente par intervention */
  byIntervention: Record<string, number>;
}

let userId: string | null = null;
let state: SyncState = { online: navigator.onLine, syncing: false, pending: 0, failed: [], byIntervention: {} };
const listeners = new Set<(s: SyncState) => void>();
/** Appelé après chaque action envoyée avec succès (pour mettre à jour les copies locales) */
const successHooks = new Set<(op: Op, result: unknown) => Promise<void> | void>();

function setState(patch: Partial<SyncState>) {
  state = { ...state, ...patch };
  for (const l of listeners) l(state);
}

export function onSynced(hook: (op: Op, result: unknown) => Promise<void> | void) {
  successHooks.add(hook);
  return () => successHooks.delete(hook);
}

export function setOnline(online: boolean) {
  if (state.online !== online) setState({ online });
}

/** Le compte connecté : seules ses modifications sont envoyées (tablette partagée) */
export function setSyncUser(id: string | null) {
  userId = id;
  void refreshCounts();
  if (id) void flush();
}

export function currentUserId() {
  return userId;
}

export async function opsFor(interventionId?: string): Promise<Op[]> {
  const all = await idb.all<Op>(OUTBOX);
  return all
    .filter((o) => o.userId === userId && (!interventionId || o.interventionId === interventionId))
    .sort((a, b) => (a.seq ?? 0) - (b.seq ?? 0));
}

async function refreshCounts() {
  const ops = await opsFor().catch(() => [] as Op[]);
  const byIntervention: Record<string, number> = {};
  for (const o of ops) byIntervention[o.interventionId] = (byIntervention[o.interventionId] ?? 0) + 1;
  setState({ pending: ops.length, failed: ops.filter((o) => o.error), byIntervention });
}

export async function enqueue(op: Omit<Op, 'userId' | 'createdAt'>): Promise<void> {
  if (!userId) throw new ApiError(401, 'Session expirée, reconnectez-vous');
  const full: Op = { ...op, userId, createdAt: new Date().toISOString() };
  // Enregistrements successifs de la même fiche : seul le dernier compte
  if (op.kind === 'save') {
    const prev = (await opsFor(op.interventionId)).find((o) => o.kind === 'save' && !o.error);
    if (prev) {
      await idb.put(OUTBOX, { ...prev, body: op.body, createdAt: full.createdAt });
      await refreshCounts();
      return;
    }
  }
  await idb.add(OUTBOX, full);
  await refreshCounts();
}

/** Modifie ou retire une action encore en attente (ex. photo supprimée avant d'avoir été envoyée) */
export async function updateQueued(match: (o: Op) => boolean, change: (o: Op) => Op | null): Promise<boolean> {
  const op = (await opsFor()).find((o) => !o.error && match(o));
  if (!op) return false;
  const next = change(op);
  if (next) await idb.put(OUTBOX, next);
  else await idb.delete(OUTBOX, op.seq!);
  await refreshCounts();
  return true;
}

export async function discard(op: Op) {
  if (op.seq !== undefined) await idb.delete(OUTBOX, op.seq);
  await refreshCounts();
}

let running: Promise<void> | null = null;
let again = false;

/** Envoie tout ce qui attend. Plusieurs appels simultanés partagent le même envoi. */
export function flush(): Promise<void> {
  if (!running) {
    running = (async () => {
      // Un envoi a peut-être été demandé pendant le précédent : on refait un tour
      do {
        again = false;
        await runOnce();
      } while (again);
    })().finally(() => {
      running = null;
    });
  } else {
    again = true;
  }
  return running;
}

async function runOnce() {
  if (!userId || !getToken()) return;
  const ops = await opsFor();
  if (!ops.length) return;
  setState({ syncing: true });
  const blocked = new Set<string>();
  try {
    for (const op of ops) {
      if (op.error) {
        blocked.add(op.interventionId);
        continue;
      }
      if (blocked.has(op.interventionId)) continue;
      try {
        const result = await api(op.path, { method: op.method, body: op.body });
        setOnline(true);
        await idb.delete(OUTBOX, op.seq!);
        for (const h of successHooks) await h(op, result);
      } catch (e) {
        const err = e instanceof ApiError ? e : new ApiError(0, (e as Error).message);
        if (err.status === 0) {
          setOnline(false);
          return;
        }
        if (err.status === 401 || err.status >= 500) return;
        if (err.status === 409) {
          await idb.delete(OUTBOX, op.seq!);
          continue;
        }
        await idb.put(OUTBOX, { ...op, error: err.message, errorDetails: err.details });
        blocked.add(op.interventionId);
      }
    }
  } finally {
    setState({ syncing: false });
    await refreshCounts();
  }
}

/**
 * Envoie les actions d'une intervention et dit où elles en sont :
 * 'synced' (tout est sur le serveur) ou 'queued' (gardé sur l'appareil, partira plus tard).
 * Une action refusée par le serveur est retirée de la file et l'erreur est renvoyée.
 */
export async function flushFor(interventionId: string, kind?: OpKind): Promise<'synced' | 'queued'> {
  await flush();
  const ops = await opsFor(interventionId);
  const refused = ops.find((o) => o.error && (!kind || o.kind === kind));
  if (refused) {
    await discard(refused);
    throw new ApiError(400, refused.error!, refused.errorDetails);
  }
  return ops.length ? 'queued' : 'synced';
}

export function useSync(): SyncState {
  const [s, setS] = useState(state);
  useEffect(() => {
    listeners.add(setS);
    setS(state);
    return () => {
      listeners.delete(setS);
    };
  }, []);
  return s;
}

// Relances automatiques
window.addEventListener('online', () => {
  setOnline(true);
  void flush();
});
window.addEventListener('offline', () => setOnline(false));
setInterval(() => {
  if (state.pending > state.failed.length) void flush();
}, 30_000);
