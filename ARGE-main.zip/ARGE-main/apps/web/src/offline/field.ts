/**
 * Données de l'appli terrain, avec ou sans réseau.
 *
 * Lecture : on demande au serveur et on garde une copie sur l'appareil ; sans réseau, on rouvre la copie.
 * Écriture : la copie locale est mise à jour tout de suite (le technicien voit son travail),
 * puis l'action part dans la file d'attente (offline/sync.ts) qui l'envoie dès que possible.
 *
 * Tant qu'une intervention a des actions en attente, sa copie locale fait foi :
 * elle contient des choses que le serveur n'a pas encore reçues.
 */
import type { CheckpointScan, ReportData } from '@itineo/shared';
import { api, ApiError, getToken, qs } from '../api';
import type { InterventionRow, ReportBundle, ReportPhoto, StockLevel } from '../types';
import { CACHE, idb } from './idb';
import { currentUserId, enqueue, flush, flushFor, onSynced, opsFor, setOnline, updateQueued, type Op } from './sync';
import { apiUrl } from '../native';

const uid = () => currentUserId() ?? 'anon';
const key = {
  vehicle: () => `${uid()}:vehicle`,
  day: (from: string) => `${uid()}:day:${from}`,
  dayPrefix: () => `${uid()}:day:`,
  report: (id: string) => `${uid()}:report:${id}`,
  photo: (photoId: string) => `${uid()}:photo:${photoId}`,
};

const isNetworkError = (e: unknown) => e instanceof ApiError && e.status === 0;
/** Ni réseau, ni copie sur l'appareil */
export const NOT_AVAILABLE_OFFLINE = new ApiError(0, 'offline');

async function hasPending(interventionId?: string) {
  return (await opsFor(interventionId)).length > 0;
}

// ─── Journée ─────────────────────────────────────────────────────────────

export async function loadDay(from: string, to: string): Promise<{ rows: InterventionRow[]; fromCache: boolean }> {
  const cached = await idb.get<InterventionRow[]>(CACHE, key.day(from)).catch(() => undefined);
  try {
    let rows = await api<InterventionRow[]>(`/interventions${qs({ mine: true, from, to })}`);
    setOnline(true);
    // Statut changé hors ligne et pas encore envoyé : on garde celui de l'appareil
    const pendingIds = new Set((await opsFor()).map((o) => o.interventionId));
    if (cached && pendingIds.size) {
      rows = rows.map((r) => (pendingIds.has(r.id) ? { ...r, status: cached.find((c) => c.id === r.id)?.status ?? r.status } : r));
    }
    await idb.put(CACHE, rows, key.day(from));
    return { rows, fromCache: false };
  } catch (e) {
    if (!isNetworkError(e)) throw e;
    setOnline(false);
    if (cached) return { rows: cached, fromCache: true };
    throw NOT_AVAILABLE_OFFLINE;
  }
}

export interface MyVehicle { vehicle: { id: string; name: string } | null; levels: StockLevel[] }

/** Stock du véhicule du technicien (pour choisir les pièces posées), gardé sur l'appareil */
export async function loadMyVehicle(): Promise<MyVehicle | null> {
  try {
    const v = await api<MyVehicle>('/stock/my-vehicle');
    await idb.put(CACHE, v, key.vehicle()).catch(() => undefined);
    return v;
  } catch {
    return (await idb.get<MyVehicle>(CACHE, key.vehicle()).catch(() => undefined)) ?? null;
  }
}

/** Copie sur l'appareil toutes les fiches du jour (et leurs photos), pour pouvoir travailler sans réseau */
export async function prefetchDay(rows: InterventionRow[], onProgress?: (done: number, total: number) => void) {
  void loadMyVehicle();
  const todo = rows.filter((r) => r.status !== 'CANCELLED');
  let done = 0;
  for (const r of todo) {
    try {
      if (!(await hasPending(r.id))) {
        const b = await api<ReportBundle>(`/interventions/${r.id}/report`);
        await idb.put(CACHE, b, key.report(r.id));
        await cachePhotos(r.id, b.photos);
      }
      done++;
      onProgress?.(done, todo.length);
    } catch (e) {
      if (isNetworkError(e)) return done;
    }
  }
  return done;
}

async function patchDay(id: string, patch: Partial<InterventionRow>) {
  const keys = (await idb.keys(CACHE)).filter((k) => String(k).startsWith(key.dayPrefix()));
  for (const k of keys) {
    const rows = await idb.get<InterventionRow[]>(CACHE, k);
    if (rows?.some((r) => r.id === id)) await idb.put(CACHE, rows.map((r) => (r.id === id ? { ...r, ...patch } : r)), k);
  }
}

/** « Je pars » / « Je suis sur place », avec l'heure réelle même si c'est envoyé plus tard */
export async function setStatus(id: string, status: 'EN_ROUTE' | 'ON_SITE') {
  const at = new Date().toISOString();
  await patchDay(id, { status });
  await patchReport(id, (b) => ({
    ...b,
    intervention: { ...b.intervention, status },
    report: status === 'ON_SITE' && b.report && !b.report.arrivedAt ? { ...b.report, arrivedAt: at } : b.report,
  }));
  await enqueue({ interventionId: id, kind: 'status', method: 'POST', path: `/interventions/${id}/status`, body: { status, at } });
  return flushFor(id, 'status');
}

// ─── Fiche ───────────────────────────────────────────────────────────────

export async function getCachedReport(id: string) {
  return idb.get<ReportBundle>(CACHE, key.report(id)).catch(() => undefined);
}

const reportListeners = new Set<(id: string) => void>();

/** Prévient quand la copie locale d'une fiche change (photo ajoutée, envoi terminé…) */
export function onReportChange(cb: (id: string) => void) {
  reportListeners.add(cb);
  return () => {
    reportListeners.delete(cb);
  };
}

async function patchReport(id: string, fn: (b: ReportBundle) => ReportBundle) {
  const b = await getCachedReport(id);
  if (!b) return;
  await idb.put(CACHE, fn(b), key.report(id));
  for (const cb of reportListeners) cb(id);
}

export async function loadReport(id: string): Promise<{ bundle: ReportBundle; fromCache: boolean }> {
  if (!(await hasPending(id))) {
    try {
      const bundle = await api<ReportBundle>(`/interventions/${id}/report`);
      setOnline(true);
      await idb.put(CACHE, bundle, key.report(id));
      void cachePhotos(id, bundle.photos);
      return { bundle, fromCache: false };
    } catch (e) {
      if (!isNetworkError(e)) throw e;
      setOnline(false);
    }
  } else {
    void flush();
  }
  const cached = await getCachedReport(id);
  if (cached) return { bundle: cached, fromCache: true };
  throw NOT_AVAILABLE_OFFLINE;
}

export interface ReportPayload {
  data: ReportData;
  parts: { label: string; reference: string | null; quantity: number; articleId?: string | null }[];
  arrivedAt: string | null;
  leftAt: string | null;
  laborMinutes: number | null;
  travelMinutes: number | null;
  outcome: string | null;
  /** Itinéos Vigie : points de passage pointés */
  checkpointScans?: CheckpointScan[];
}

export async function saveReport(id: string, payload: ReportPayload) {
  await patchReport(id, (b) => (b.report ? {
    ...b,
    report: {
      ...b.report,
      data: payload.data,
      arrivedAt: payload.arrivedAt,
      leftAt: payload.leftAt,
      laborMinutes: payload.laborMinutes,
      travelMinutes: payload.travelMinutes,
      outcome: payload.outcome,
      ...(payload.checkpointScans ? { checkpointScans: payload.checkpointScans } : {}),
    },
    parts: payload.parts,
  } : b));
  await enqueue({ interventionId: id, kind: 'save', method: 'PUT', path: `/interventions/${id}/report`, body: { ...payload } });
  return flushFor(id, 'save');
}

export async function signReport(id: string, body: Record<string, unknown>) {
  const signedAt = new Date().toISOString();
  const before = await getCachedReport(id);
  await patchReport(id, (b) => (b.report ? {
    ...b,
    canEdit: false,
    report: { ...b.report, status: 'SIGNED', signedAt, leftAt: b.report.leftAt ?? signedAt },
  } : b));
  await enqueue({ interventionId: id, kind: 'sign', method: 'POST', path: `/interventions/${id}/report/sign`, body: { ...body, signedAt } });
  try {
    return await flushFor(id, 'sign');
  } catch (e) {
    if (before) await patchReport(id, () => before);
    throw e;
  }
}

export async function sendReport(id: string, body: { to?: string[]; sendEmail: boolean; copyOffice?: boolean }) {
  const before = await getCachedReport(id);
  const followUp = before?.report?.outcome === 'TO_RESUME' || before?.report?.outcome === 'WAITING_PARTS';
  await patchReport(id, (b) => (b.report ? {
    ...b,
    report: { ...b.report, status: 'SENT', sentTo: body.sendEmail ? (body.to ?? []).join(', ') : null, sendQueued: true },
  } : b));
  await patchDay(id, { status: followUp ? 'TO_RESUME' : 'DONE' });
  await enqueue({ interventionId: id, kind: 'send', method: 'POST', path: `/interventions/${id}/report/send`, body });
  try {
    return await flushFor(id, 'send');
  } catch (e) {
    if (before) await patchReport(id, () => before);
    await patchDay(id, { status: before?.intervention.status ?? 'ON_SITE' });
    throw e;
  }
}

// ─── Photos ──────────────────────────────────────────────────────────────

const photosPath = (id: string) => `/interventions/${id}/report/photos`;
const isLocal = (p: ReportPhoto) => !!p.localImage;

export async function addPhoto(id: string, p: { clientId: string; kind: ReportPhoto['kind']; image: string }) {
  const local: ReportPhoto = { id: p.clientId, clientId: p.clientId, kind: p.kind, caption: null, createdAt: new Date().toISOString(), localImage: p.image };
  await patchReport(id, (b) => ({ ...b, photos: [...b.photos, local] }));
  // Heure de prise de vue : celle de l'appareil, même si la photo part plus tard
  await enqueue({ interventionId: id, kind: 'photo.add', method: 'POST', path: photosPath(id), body: { ...p, takenAt: local.createdAt } });
  try {
    return await flushFor(id, 'photo.add');
  } catch (e) {
    await patchReport(id, (b) => ({ ...b, photos: b.photos.filter((x) => x.clientId !== p.clientId) }));
    throw e;
  }
}

/** Identifiant serveur d'une photo (une photo prise hors ligne n'en a pas encore) */
async function serverPhotoId(id: string, photo: ReportPhoto): Promise<string | null> {
  if (!isLocal(photo)) return photo.id;
  await flush();
  const b = await getCachedReport(id);
  return b?.photos.find((x) => x.clientId === photo.clientId && !isLocal(x))?.id ?? null;
}

export async function captionPhoto(id: string, photo: ReportPhoto, caption: string) {
  if (isLocal(photo)) {
    // Pas encore envoyée : la légende part avec la photo
    const queued = await updateQueued(
      (o) => o.kind === 'photo.add' && o.body?.clientId === photo.clientId,
      (o) => ({ ...o, body: { ...o.body, caption } }),
    );
    if (queued) {
      await patchReport(id, (b) => ({ ...b, photos: b.photos.map((x) => (x.clientId === photo.clientId ? { ...x, caption } : x)) }));
      return 'queued' as const;
    }
  }
  const photoId = await serverPhotoId(id, photo);
  if (!photoId) return 'queued' as const;
  await patchReport(id, (b) => ({ ...b, photos: b.photos.map((x) => (x.id === photoId ? { ...x, caption } : x)) }));
  await enqueue({ interventionId: id, kind: 'photo.caption', method: 'PATCH', path: `${photosPath(id)}/${photoId}`, body: { caption } });
  return flushFor(id, 'photo.caption');
}

export async function deletePhoto(id: string, photo: ReportPhoto) {
  if (isLocal(photo)) {
    // Pas encore envoyée : il suffit de ne pas l'envoyer
    const queued = await updateQueued((o) => o.kind === 'photo.add' && o.body?.clientId === photo.clientId, () => null);
    if (queued) {
      await patchReport(id, (b) => ({ ...b, photos: b.photos.filter((x) => x.clientId !== photo.clientId) }));
      return 'synced' as const;
    }
  }
  const photoId = await serverPhotoId(id, photo);
  await patchReport(id, (b) => ({ ...b, photos: b.photos.filter((x) => x.clientId !== photo.clientId) }));
  if (!photoId) return 'synced' as const;
  await idb.delete(CACHE, key.photo(photoId)).catch(() => undefined);
  await enqueue({ interventionId: id, kind: 'photo.delete', method: 'DELETE', path: `${photosPath(id)}/${photoId}` });
  return flushFor(id, 'photo.delete');
}

async function fetchPhotoBlob(interventionId: string, photoId: string): Promise<Blob | null> {
  try {
    const r = await fetch(apiUrl(`${photosPath(interventionId)}/${photoId}`), { headers: { Authorization: `Bearer ${getToken() ?? ''}` } });
    return r.ok ? await r.blob() : null;
  } catch {
    return null;
  }
}

async function cachePhotos(interventionId: string, photos: ReportPhoto[]) {
  for (const p of photos) {
    if (isLocal(p)) continue;
    if (await idb.get(CACHE, key.photo(p.id)).catch(() => undefined)) continue;
    const blob = await fetchPhotoBlob(interventionId, p.id);
    if (!blob) return;
    await idb.put(CACHE, blob, key.photo(p.id)).catch(() => undefined);
  }
}

/** Image d'une photo : copie de l'appareil si on l'a, sinon téléchargée (et gardée) */
export async function photoBlob(interventionId: string, photoId: string): Promise<Blob | null> {
  const cached = await idb.get<Blob>(CACHE, key.photo(photoId)).catch(() => undefined);
  if (cached) return cached;
  const blob = await fetchPhotoBlob(interventionId, photoId);
  if (blob) await idb.put(CACHE, blob, key.photo(photoId)).catch(() => undefined);
  return blob;
}

// ─── Après envoi réussi : la copie locale reçoit les infos du serveur ────

onSynced(async (op: Op, result: unknown) => {
  if (op.kind === 'photo.add') {
    const photo = result as ReportPhoto;
    const clientId = op.body?.clientId as string;
    const image = op.body?.image as string;
    // La photo prise sur l'appareil est gardée sous son identifiant serveur : pas besoin de la retélécharger
    const blob = await fetch(image).then((r) => r.blob()).catch(() => null);
    if (blob) await idb.put(CACHE, blob, key.photo(photo.id)).catch(() => undefined);
    await patchReport(op.interventionId, (b) => ({
      ...b,
      photos: b.photos.map((x) => (x.clientId === clientId ? { ...photo, caption: x.caption ?? photo.caption } : x)),
    }));
  }
  if (op.kind === 'send') {
    const res = result as { sentTo: string[] };
    await patchReport(op.interventionId, (b) => (b.report ? {
      ...b,
      report: { ...b.report, sendQueued: false, sentTo: res.sentTo.length ? res.sentTo.join(', ') : b.report.sentTo },
    } : b));
  }
});

/** Déconnexion : les copies sont effacées de l'appareil (les actions en attente, elles, sont gardées) */
export async function clearDeviceCopies() {
  await idb.clear(CACHE).catch(() => undefined);
}
