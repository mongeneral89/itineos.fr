/** Fichiers joints (messagerie, notices) : choix sur l'appareil, envoi en data URL, affichage avec le jeton */
import { useEffect, useState } from 'react';
import { getToken } from './api';
import { compressPhoto } from './photos';
import { t } from './i18n';
import { apiUrl } from './native';

/** Même limite que le serveur */
export const MAX_FILE_BYTES = 10 * 1024 * 1024;

/** Types acceptés (le serveur vérifie aussi le contenu) */
export const FILE_ACCEPT = [
  'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf',
  '.docx', '.xlsx', '.pptx', '.odt', '.ods', '.doc', '.xls', '.zip', '.mp4', '.mov', '.txt', '.csv',
].join(',');

const BY_EXT: Record<string, string> = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  odt: 'application/vnd.oasis.opendocument.text',
  ods: 'application/vnd.oasis.opendocument.spreadsheet',
  doc: 'application/msword',
  xls: 'application/vnd.ms-excel',
  zip: 'application/zip',
  mp4: 'video/mp4',
  mov: 'video/quicktime',
  txt: 'text/plain',
  csv: 'text/csv',
  pdf: 'application/pdf',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  gif: 'image/gif',
  webp: 'image/webp',
};

export interface PickedFile { name: string; dataUrl: string; size: number; mime: string }

function readAsDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(new Error(t('Ce fichier ne peut pas être lu')));
    r.readAsDataURL(blob);
  });
}

/**
 * Prépare un fichier choisi sur l'appareil. Les photos (JPEG, PNG, HEIC…) sont réduites comme sur les fiches ;
 * le type est déduit de l'extension quand le téléphone ne le donne pas (fréquent pour les documents bureautiques).
 */
export async function pickFile(file: File): Promise<PickedFile> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  const mime = BY_EXT[ext] ?? file.type;
  const photo = file.type.startsWith('image/') && !['image/gif', 'image/webp'].includes(file.type);
  if (photo) {
    try {
      const dataUrl = await compressPhoto(file);
      const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
      return { name, dataUrl, size: Math.round((dataUrl.length * 3) / 4), mime: 'image/jpeg' };
    } catch (e) {
      // Image illisible par le navigateur : envoyée telle quelle si c'est un JPEG ou un PNG, sinon refusée
      if (!['image/jpeg', 'image/png'].includes(file.type)) throw e;
    }
  }
  if (file.size > MAX_FILE_BYTES) throw new Error(t('Fichier trop lourd : 10 Mo au maximum'));
  if (!mime || !Object.values(BY_EXT).includes(mime)) throw new Error(t('Format non accepté : photos, PDF, documents bureautiques, vidéos MP4, texte'));
  const raw = await readAsDataUrl(file);
  // Remet le bon type dans la data URL (certains téléphones envoient application/octet-stream)
  const dataUrl = raw.replace(/^data:[^;]*;/, `data:${mime};`);
  return { name: file.name, dataUrl, size: file.size, mime };
}

export function fmtSize(bytes: number): string {
  if (bytes < 1024) return t('{n} o', { n: bytes });
  if (bytes < 1024 * 1024) return t('{n} Ko', { n: Math.round(bytes / 1024) });
  return t('{n} Mo', { n: (bytes / 1024 / 1024).toFixed(1) });
}

export const isImage = (mime: string) => mime.startsWith('image/');
/** Formats que le navigateur sait afficher ; les autres se téléchargent */
export const opensInBrowser = (mime: string) => isImage(mime) || mime === 'application/pdf' || mime.startsWith('video/');

/** Adresse locale (blob) d'un fichier de l'API, chargé avec le jeton ; libérée quand l'affichage disparaît */
export function useApiBlobUrl(path: string | null): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!path) return;
    let objectUrl: string | null = null;
    let cancelled = false;
    void fetch(apiUrl(path), { headers: { Authorization: `Bearer ${getToken() ?? ''}` } })
      .then((res) => (res.ok ? res.blob() : null))
      .then((blob) => {
        if (!blob || cancelled) return;
        objectUrl = URL.createObjectURL(blob);
        setUrl(objectUrl);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [path]);
  return url;
}
