/**
 * Appli Android (Capacitor) : les écrans sont rangés dans l'appli, l'API est sur un serveur dont l'adresse
 * est choisie à la connexion (le PC sur le Wi-Fi pour les essais, puis la version en ligne).
 * Dans le navigateur, rien ne change : l'API est sur la même adresse que le site.
 */

const SERVER_KEY = 'itineo.server';

type CapacitorGlobal = { isNativePlatform?: () => boolean };

/** Vrai dans l'appli installée (Android ou iPhone), faux dans le navigateur */
export const isNativeApp = (): boolean =>
  !!(window as unknown as { Capacitor?: CapacitorGlobal }).Capacitor?.isNativePlatform?.();

/** Appli Android : mises à jour par APK (sur iPhone, l'installation passe par Apple) */
export const isAndroidApp = (): boolean =>
  isNativeApp() && (window as unknown as { Capacitor?: { getPlatform?: () => string } }).Capacitor?.getPlatform?.() === 'android';

/** Adresse du serveur choisie dans l'appli (vide dans le navigateur) */
export function getServer(): string {
  if (!isNativeApp()) return '';
  try {
    return localStorage.getItem(SERVER_KEY) ?? import.meta.env.VITE_DEFAULT_SERVER ?? '';
  } catch {
    return import.meta.env.VITE_DEFAULT_SERVER ?? '';
  }
}

/** PC de test sur le réseau local (ou l'émulateur Android) : seules adresses autorisées en http */
export const LOCAL_HOST = /^(localhost|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)(:\d+)?$/i;

/**
 * « 192.168.1.20:3000 » ou « https://itineo.exemple.fr/ » → adresse complète, sans « / » final.
 * Hors réseau local, toujours https : le mot de passe ne doit jamais passer en clair sur Internet.
 */
export function normalizeServer(input: string): string {
  const s = input.trim().replace(/\/+$/, '').replace(/\/api$/, '');
  if (!s) return '';
  const host = s.replace(/^https?:\/\//i, '');
  if (LOCAL_HOST.test(host.split('/')[0])) return /^https:\/\//i.test(s) ? s : `http://${host}`;
  return `https://${host}`;
}

export function setServer(url: string) {
  try {
    localStorage.setItem(SERVER_KEY, normalizeServer(url));
  } catch {
    /* stockage indisponible */
  }
}

/** Adresse d'un chemin de l'API : « /api/… » dans le navigateur, « https://serveur/api/… » dans l'appli */
export const apiUrl = (path: string): string => `${getServer()}/api${path}`;

/** Le serveur répond-il ? (écran de connexion de l'appli) */
export async function checkServer(url: string): Promise<boolean> {
  try {
    const res = await fetch(`${normalizeServer(url)}/api/health`, { signal: AbortSignal.timeout(8000) });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Ouvre un fichier (PDF, image…) dans l'appli du téléphone prévue pour : la WebView d'Android ne sait pas
 * afficher un PDF ni ouvrir un nouvel onglet. Le fichier est copié dans le cache de l'appli.
 */
export async function openNativeFile(blob: Blob, name: string) {
  const [{ Filesystem, Directory }, { FileOpener }] = await Promise.all([
    import('@capacitor/filesystem'),
    import('@capacitor-community/file-opener'),
  ]);
  const data = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] ?? '');
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
  const safe = name.replace(/[\\/:*?"<>|]+/g, '_') || 'document';
  const { uri } = await Filesystem.writeFile({ path: safe, data, directory: Directory.Cache });
  await FileOpener.open({ filePath: uri, contentType: blob.type || 'application/octet-stream' });
}

/** Nom de fichier donné par le serveur, sinon celui proposé */
export const fileNameOf = (res: Response, fallback: string) =>
  /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') ?? '')?.[1] ?? fallback;
