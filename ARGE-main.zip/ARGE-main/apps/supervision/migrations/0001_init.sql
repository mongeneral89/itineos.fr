-- Console de supervision : les installations d'Itinéos chez les clients, leur état, leurs bugs, les ordres envoyés
-- et les versions publiées.

CREATE TABLE operators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  name text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_name text,
  email text,
  phone text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Versions publiées : « standard » pour tous, ou propres à un client (ex. « arge »)
CREATE TABLE releases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version text NOT NULL,
  channel text NOT NULL DEFAULT 'standard',
  notes text,
  file_name text NOT NULL,
  size_bytes bigint NOT NULL,
  sha256 text NOT NULL,
  signature text NOT NULL,
  created_by uuid REFERENCES operators(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (version, channel)
);

CREATE TABLE installations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id),
  name text NOT NULL,
  channel text NOT NULL DEFAULT 'standard',
  -- Code d'inscription (une fois, 7 jours), puis secret de l'agent : seules leurs empreintes sont gardées
  enroll_code_hash text,
  enroll_expires_at timestamptz,
  secret_hash text,
  enrolled_at timestamptz,
  hostname text,
  edition text,
  version text,
  public_url text,
  target_release_id uuid REFERENCES releases(id),
  last_seen_at timestamptz,
  last_status jsonb,
  remote_id text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX installations_client_idx ON installations(client_id);

-- Historique de l'état (un point par minute environ, 30 jours gardés)
CREATE TABLE heartbeats (
  id bigserial PRIMARY KEY,
  installation_id uuid NOT NULL REFERENCES installations(id) ON DELETE CASCADE,
  at timestamptz NOT NULL DEFAULT now(),
  health text NOT NULL,
  status jsonb NOT NULL
);
CREATE INDEX heartbeats_installation_at_idx ON heartbeats(installation_id, at DESC);

-- Bugs : regroupés par empreinte (même erreur au même endroit), avec le nombre d'occurrences
CREATE TABLE bug_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  installation_id uuid NOT NULL REFERENCES installations(id) ON DELETE CASCADE,
  fingerprint text NOT NULL,
  source text NOT NULL CHECK (source IN ('auto', 'user')),
  title text NOT NULL,
  message text,
  detail jsonb,
  version text,
  occurrences integer NOT NULL DEFAULT 1,
  first_at timestamptz NOT NULL DEFAULT now(),
  last_at timestamptz NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'RESOLVED', 'IGNORED')),
  note text,
  UNIQUE (installation_id, fingerprint)
);
CREATE INDEX bug_reports_status_idx ON bug_reports(status, last_at DESC);

-- Ordres envoyés aux installations : redémarrer, journaux, mise à jour, réglages, accès support, prise en main
CREATE TABLE commands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  installation_id uuid NOT NULL REFERENCES installations(id) ON DELETE CASCADE,
  kind text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'QUEUED' CHECK (status IN ('QUEUED', 'SENT', 'DONE', 'FAILED', 'CANCELLED')),
  result jsonb,
  created_by uuid REFERENCES operators(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  done_at timestamptz
);
CREATE INDEX commands_installation_idx ON commands(installation_id, created_at DESC);

CREATE TABLE audit_logs (
  id bigserial PRIMARY KEY,
  operator_id uuid REFERENCES operators(id),
  action text NOT NULL,
  target text,
  detail jsonb,
  at timestamptz NOT NULL DEFAULT now()
);
