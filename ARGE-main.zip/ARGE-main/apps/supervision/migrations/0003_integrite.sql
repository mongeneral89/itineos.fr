-- Intégrité des installations : empreinte de référence de chaque version (lue dans le paquet publié), et, à défaut,
-- celle relevée la première fois sur l'installation pour sa version ; alerte envoyée une fois par changement
ALTER TABLE releases ADD COLUMN fingerprint text;
ALTER TABLE installations ADD COLUMN integrity_ref text;
ALTER TABLE installations ADD COLUMN integrity_ref_version text;
ALTER TABLE installations ADD COLUMN integrity_alerted boolean NOT NULL DEFAULT false;
