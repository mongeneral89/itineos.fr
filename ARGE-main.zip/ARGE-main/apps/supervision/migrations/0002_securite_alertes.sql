-- Double authentification des opérateurs (code à 6 chiffres d'une application d'authentification)
ALTER TABLE operators ADD COLUMN totp_secret text;
ALTER TABLE operators ADD COLUMN totp_enabled boolean NOT NULL DEFAULT false;
-- Dernier pas de temps accepté : un code ne sert qu'une fois
ALTER TABLE operators ADD COLUMN totp_last_step bigint;
-- Alertes par e-mail (pannes, retours en service, nouveaux bugs, mises à jour ratées) et résumé du matin
ALTER TABLE operators ADD COLUMN alerts boolean NOT NULL DEFAULT true;
ALTER TABLE operators ADD COLUMN daily_summary boolean NOT NULL DEFAULT true;

-- Dernier état signalé par alerte : une alerte part seulement quand l'état change
ALTER TABLE installations ADD COLUMN alert_health text;
ALTER TABLE installations ADD COLUMN alert_changed_at timestamptz;

-- Alertes envoyées (pour la console : ce qui est parti, à qui, quand)
CREATE TABLE alerts (
  id bigserial PRIMARY KEY,
  installation_id uuid REFERENCES installations(id) ON DELETE CASCADE,
  kind text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  sent_to text[] NOT NULL DEFAULT '{}',
  error text,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX alerts_at_idx ON alerts(at DESC);

-- Réglages de la console (serveur RustDesk, dernier résumé envoyé…)
CREATE TABLE settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
