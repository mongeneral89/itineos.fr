/**
 * Intégrité des installations : chaque installation envoie l'empreinte de ses fichiers (serveur compilé,
 * migrations, polices, appli web). La console la compare à l'empreinte de référence de la version :
 *  - celle du paquet publié (empreinte.txt dans le .zip, voir installeur/empreinte.mts) ;
 *  - à défaut (version installée sans paquet publié), la première relevée sur l'installation pour cette version.
 * Une différence = des fichiers du logiciel ont été modifiés chez le client : alerte, et l'installation passe à surveiller.
 */
import { inflateRawSync } from 'node:zlib';
import { one, query } from './db.js';

/** Lit un fichier d'une archive .zip (sans dépendance) ; null s'il n'y est pas */
export function readZipEntry(zip: Buffer, name: string): Buffer | null {
  // Fin du répertoire central (signature 0x06054b50), cherchée depuis la fin (commentaire éventuel)
  let end = -1;
  for (let i = zip.length - 22; i >= Math.max(0, zip.length - 65_557); i--) {
    if (zip.readUInt32LE(i) === 0x06054b50) { end = i; break; }
  }
  if (end < 0) return null;
  const count = zip.readUInt16LE(end + 10);
  let p = zip.readUInt32LE(end + 16);
  for (let k = 0; k < count && p + 46 <= zip.length; k++) {
    if (zip.readUInt32LE(p) !== 0x02014b50) return null;
    const method = zip.readUInt16LE(p + 10);
    const size = zip.readUInt32LE(p + 20);
    const nameLen = zip.readUInt16LE(p + 28);
    const extraLen = zip.readUInt16LE(p + 30);
    const commentLen = zip.readUInt16LE(p + 32);
    const local = zip.readUInt32LE(p + 42);
    const entry = zip.toString('utf8', p + 46, p + 46 + nameLen).replace(/\\/g, '/');
    if (entry === name || entry === `./${name}`) {
      const start = local + 30 + zip.readUInt16LE(local + 26) + zip.readUInt16LE(local + 28);
      const data = zip.subarray(start, start + size);
      return method === 0 ? Buffer.from(data) : method === 8 ? inflateRawSync(data) : null;
    }
    p += 46 + nameLen + extraLen + commentLen;
  }
  return null;
}

/** Empreinte de référence contenue dans un paquet (64 caractères hexadécimaux), ou null */
export function releaseFingerprint(zip: Buffer): string | null {
  const raw = readZipEntry(zip, 'empreinte.txt')?.toString('utf8').trim() ?? '';
  return /^[0-9a-f]{64}$/.test(raw) ? raw : null;
}

export type IntegrityVerdict = 'ok' | 'modified' | 'reference' | 'unchecked';

/**
 * Compare l'empreinte envoyée par une installation à la référence de sa version, et garde la référence relevée
 * quand aucun paquet publié n'en donne. Renvoie le verdict, et s'il faut alerter (première détection).
 */
export async function checkIntegrity(installationId: string, channel: string, version: string | undefined, reported: string | undefined | null) {
  if (!version || !reported) return { verdict: 'unchecked' as IntegrityVerdict, alert: false };
  const rel = await one<{ fingerprint: string | null }>(
    `SELECT fingerprint FROM releases WHERE version = $1 AND channel IN ($2, 'standard') AND fingerprint IS NOT NULL
     ORDER BY (channel = $2) DESC LIMIT 1`, [version, channel]);
  const inst = await one<{ integrity_ref: string | null; integrity_ref_version: string | null; integrity_alerted: boolean }>(
    'SELECT integrity_ref, integrity_ref_version, integrity_alerted FROM installations WHERE id = $1', [installationId]);
  let expected = rel?.fingerprint ?? (inst?.integrity_ref_version === version ? inst.integrity_ref : null);
  let verdict: IntegrityVerdict;
  if (!expected) {
    // Première fois pour cette version, sans paquet publié : cette empreinte devient la référence
    await query('UPDATE installations SET integrity_ref = $2, integrity_ref_version = $3 WHERE id = $1', [installationId, reported, version]);
    expected = reported;
    verdict = 'reference';
  } else {
    verdict = expected === reported ? 'ok' : 'modified';
  }
  const alert = verdict === 'modified' && !inst?.integrity_alerted;
  if (verdict === 'modified' && !inst?.integrity_alerted) await query('UPDATE installations SET integrity_alerted = true WHERE id = $1', [installationId]);
  if (verdict !== 'modified' && inst?.integrity_alerted) await query('UPDATE installations SET integrity_alerted = false WHERE id = $1', [installationId]);
  return { verdict, alert };
}
