/**
 * API des agents : chaque Itinéos installé chez un client appelle la console (jamais l'inverse, donc rien à ouvrir
 * sur la box du client).
 *
 *   POST /agent/enroll        code d'inscription (donné une fois) → identifiant, secret, clé publique de signature
 *   POST /agent/heartbeat     chaque minute : état, bugs, résultats des ordres → ordres en attente
 *   GET  /agent/releases/:id  paquet de mise à jour (signé)
 */
import type { FastifyInstance, FastifyRequest } from 'fastify';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
import { env } from './env.js';
import { audit, one, query } from './db.js';
import { evaluateHealth, type AgentStatus } from './health.js';
import { loadSigningKeys } from './signing.js';
import { HttpError } from './http.js';
import { alertIntegrity, alertNewBugs, alertUpdateFailed } from './alerts.js';
import { checkIntegrity } from './integrity.js';

export const hashToken = (s: string) => createHash('sha256').update(s).digest('hex');
export const HEARTBEAT_SECONDS = 60;
const HEARTBEAT_RETENTION_DAYS = 30;

interface InstallationRow { id: string; secret_hash: string | null; channel: string }

/** L'agent s'authentifie par « Agent <id>:<secret> » */
async function agentOf(req: FastifyRequest): Promise<InstallationRow> {
  const m = /^Agent ([0-9a-f-]{36}):([A-Za-z0-9_-]{20,})$/.exec(req.headers.authorization ?? '');
  if (!m) throw new HttpError(401, 'Agent non identifié');
  const row = await one<InstallationRow>('SELECT id, secret_hash, channel FROM installations WHERE id = $1', [m[1]]);
  const given = Buffer.from(hashToken(m[2]));
  if (!row?.secret_hash || given.length !== row.secret_hash.length || !timingSafeEqual(given, Buffer.from(row.secret_hash))) {
    throw new HttpError(401, 'Agent non identifié');
  }
  return row;
}

const bugSchema = z.object({
  fingerprint: z.string().min(1).max(100),
  source: z.enum(['auto', 'user']),
  title: z.string().min(1).max(300),
  message: z.string().max(5000).nullable().optional(),
  detail: z.record(z.unknown()).optional(),
  occurrences: z.number().int().min(1).max(1_000_000).default(1),
  at: z.coerce.date().optional(),
});

const resultSchema = z.object({
  commandId: z.string().uuid(),
  ok: z.boolean(),
  /** false : étape intermédiaire (ex. mise à jour programmée), l'ordre reste « envoyé » */
  final: z.boolean().default(true),
  result: z.record(z.unknown()).optional(),
});

/**
 * Ce que chaque agent reçoit à chaque passage : les clés de signature (la principale, et la clé de secours recommandée
 * par elle) et le serveur RustDesk à utiliser pour la prise en main.
 */
export async function agentConfig() {
  const keys = await loadSigningKeys(env.DATA_DIR);
  const remote = await one<{ value: { server: string; key: string } }>("SELECT value FROM settings WHERE key = 'rustdesk'");
  return {
    keys: { signing: keys.publicKeyPem, backup: keys.backup },
    remoteServer: remote?.value?.server ? remote.value : null,
  };
}

export async function agentRoutes(app: FastifyInstance) {
  app.post('/agent/enroll', async (req) => {
    const body = z.object({
      code: z.string().min(6).max(100),
      hostname: z.string().max(200).optional(),
      version: z.string().max(50).optional(),
      edition: z.string().max(30).optional(),
      publicUrl: z.string().max(300).optional(),
    }).parse(req.body);
    const row = await one<{ id: string; enroll_expires_at: Date }>(
      'SELECT id, enroll_expires_at FROM installations WHERE enroll_code_hash = $1', [hashToken(body.code.trim().toUpperCase())],
    );
    if (!row || row.enroll_expires_at < new Date()) throw new HttpError(400, 'Code d’inscription invalide ou expiré');
    const secret = randomBytes(32).toString('base64url');
    await query(
      `UPDATE installations SET secret_hash = $2, enroll_code_hash = NULL, enroll_expires_at = NULL, enrolled_at = now(),
         hostname = $3, version = $4, edition = $5, public_url = $6 WHERE id = $1`,
      [row.id, hashToken(secret), body.hostname ?? null, body.version ?? null, body.edition ?? null, body.publicUrl ?? null],
    );
    await audit(null, 'installation.enroll', row.id, { hostname: body.hostname, ip: req.ip });
    const keys = await loadSigningKeys(env.DATA_DIR);
    return { installationId: row.id, secret, publicKey: keys.publicKeyPem, ...(await agentConfig()), heartbeatSeconds: HEARTBEAT_SECONDS };
  });

  app.post('/agent/heartbeat', { bodyLimit: 2 * 1024 * 1024 }, async (req) => {
    const inst = await agentOf(req);
    const body = z.object({
      hostname: z.string().max(200).optional(),
      publicUrl: z.string().max(300).optional(),
      status: z.record(z.unknown()),
      bugs: z.array(bugSchema).max(200).default([]),
      results: z.array(resultSchema).max(100).default([]),
      /** Accès support ou prises en main terminés (fermés par le client, ou durée écoulée) */
      closed: z.array(z.string().uuid()).max(100).default([]),
    }).parse(req.body);
    const status = body.status as AgentStatus;
    // L'agent ne décide pas de son verdict : c'est la console qui compare son empreinte à la référence
    const check = await checkIntegrity(inst.id, inst.channel, status.version, status.integrity?.fingerprint);
    status.integrityVerdict = check.verdict;
    if (check.alert) void alertIntegrity(inst.id, status.version, (m) => req.log.info(m)).catch((err) => req.log.error(err));
    const now = new Date();
    const { health } = evaluateHealth(now, status, now);

    await query(
      `UPDATE installations SET last_seen_at = $2, last_status = $3, version = COALESCE($4, version), edition = COALESCE($5, edition),
         hostname = COALESCE($6, hostname), public_url = COALESCE($7, public_url), remote_id = COALESCE($8, remote_id) WHERE id = $1`,
      [inst.id, now, status, status.version ?? null, status.edition ?? null, body.hostname ?? null, body.publicUrl ?? null, status.remote?.id ?? null],
    );
    await query('INSERT INTO heartbeats (installation_id, at, health, status) VALUES ($1, $2, $3, $4)', [inst.id, now, health, status]);

    // Bugs : même empreinte = même bug (occurrences ajoutées) ; un bug résolu qui revient est rouvert
    const fresh: typeof body.bugs = [];
    for (const b of body.bugs) {
      // Nouveau bug, ou bug résolu qui revient : alerte
      const before = await one<{ status: string }>('SELECT status FROM bug_reports WHERE installation_id = $1 AND fingerprint = $2', [inst.id, b.fingerprint]);
      if (!before || before.status === 'RESOLVED') fresh.push(b);
      await query(
        `INSERT INTO bug_reports (installation_id, fingerprint, source, title, message, detail, version, occurrences, first_at, last_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $9)
         ON CONFLICT (installation_id, fingerprint) DO UPDATE SET
           occurrences = bug_reports.occurrences + EXCLUDED.occurrences, last_at = EXCLUDED.last_at,
           message = EXCLUDED.message, detail = EXCLUDED.detail, version = EXCLUDED.version,
           status = CASE WHEN bug_reports.status = 'RESOLVED' THEN 'OPEN' ELSE bug_reports.status END`,
        [inst.id, b.fingerprint, b.source, b.title, b.message ?? null, b.detail ?? null, status.version ?? null, b.occurrences, b.at ?? now],
      );
    }

    if (fresh.length) void alertNewBugs(inst.id, fresh, (m) => req.log.info(m)).catch((err) => req.log.error(err));

    // Résultats des ordres exécutés
    for (const r of body.results) {
      if (!r.final) {
        await query(`UPDATE commands SET result = $3 WHERE id = $1 AND installation_id = $2 AND status = 'SENT'`, [r.commandId, inst.id, r.result ?? null]);
        continue;
      }
      await query(
        `UPDATE commands SET status = $3, result = $4, done_at = now() WHERE id = $1 AND installation_id = $2 AND status IN ('SENT', 'QUEUED')`,
        [r.commandId, inst.id, r.ok ? 'DONE' : 'FAILED', r.result ?? null],
      );
      if (!r.ok && (await one("SELECT 1 FROM commands WHERE id = $1 AND kind = 'update'", [r.commandId]))) {
        void alertUpdateFailed(inst.id, r.result, (m) => req.log.info(m)).catch((err) => req.log.error(err));
      }
    }

    // Fin d'un accès : le mot de passe n'a plus à être affiché (ni gardé) dans la console
    if (body.closed.length) {
      await query(`UPDATE commands SET result = (result - 'password') || jsonb_build_object('closedAt', now())
        WHERE installation_id = $1 AND id = ANY($2::uuid[]) AND kind IN ('support', 'remote') AND result IS NOT NULL`, [inst.id, body.closed]);
    }

    // Ordres en attente : passés à « envoyé » ; une mise à jour reçoit de quoi vérifier le paquet
    const pending = await query<{ id: string; kind: string; payload: Record<string, unknown> }>(
      `UPDATE commands SET status = 'SENT', sent_at = now() WHERE installation_id = $1 AND status = 'QUEUED'
       RETURNING id, kind, payload`, [inst.id],
    );
    const commands = [];
    for (const c of pending) {
      if (c.kind === 'update') {
        const rel = await one<{ id: string; version: string; channel: string; sha256: string; signature: string; size_bytes: string }>(
          'SELECT id, version, channel, sha256, signature, size_bytes FROM releases WHERE id = $1', [c.payload.releaseId],
        );
        if (!rel) {
          await query(`UPDATE commands SET status = 'FAILED', result = $2, done_at = now() WHERE id = $1`, [c.id, { error: 'Version supprimée' }]);
          continue;
        }
        commands.push({ id: c.id, kind: c.kind, payload: { ...c.payload, version: rel.version, channel: rel.channel, sha256: rel.sha256, signature: rel.signature, sizeBytes: Number(rel.size_bytes), download: `/agent/releases/${rel.id}` } });
      } else {
        commands.push(c);
      }
    }

    // Historique : au-delà de 30 jours, effacé (de temps en temps)
    if (Math.random() < 0.01) {
      await query(`DELETE FROM heartbeats WHERE at < now() - make_interval(days => $1)`, [HEARTBEAT_RETENTION_DAYS]);
    }
    return { commands, ...(await agentConfig()), heartbeatSeconds: HEARTBEAT_SECONDS };
  });

  app.get('/agent/releases/:id', async (req, reply) => {
    const inst = await agentOf(req);
    const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
    // Seulement une version qu'un ordre de mise à jour a désignée pour cette installation
    const allowed = await one(
      `SELECT 1 FROM commands WHERE installation_id = $1 AND kind = 'update' AND payload->>'releaseId' = $2`, [inst.id, id],
    );
    const rel = allowed ? await one<{ file_name: string; sha256: string }>('SELECT file_name, sha256 FROM releases WHERE id = $1', [id]) : undefined;
    if (!rel) throw new HttpError(404, 'Version introuvable');
    return reply.type('application/zip').header('X-Sha256', rel.sha256)
      .send(createReadStream(path.join(env.DATA_DIR, 'versions', rel.file_name)));
  });
}
