/**
 * API de la console (vous et votre équipe) : clients, installations et leur état, ordres à distance, bugs, versions.
 * Toutes les routes demandent une session d'opérateur, sauf la connexion.
 */
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import bcrypt from 'bcryptjs';
import { randomBytes, randomInt } from 'node:crypto';
import { mkdir, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import { env } from './env.js';
import { audit, one, query } from './db.js';
import { evaluateHealth, type AgentStatus } from './health.js';
import { releaseFingerprint } from './integrity.js';
import { loadSigningKeys, sha256, signRelease } from './signing.js';
import { AttemptLimiter, HttpError } from './http.js';
import { hashToken } from './agent-routes.js';
import { newTotpSecret, otpauthUri, verifyTotp } from './totp.js';

declare module '@fastify/jwt' {
  interface FastifyJWT {
    /** mfa : connecté avec le code de double authentification (exigé pour les actions sensibles) */
    payload: { sub: string; kind: 'operator'; mfa: boolean };
    user: { sub: string; kind: 'operator'; mfa: boolean };
  }
}

/** Actions qui touchent les PC ou les données des clients : double authentification obligatoire */
const SENSITIVE_COMMANDS = new Set(['remote', 'support', 'update', 'settings', 'restart']);

function requireMfa(req: FastifyRequest) {
  if (!req.user.mfa) throw new HttpError(403, 'Activez la double authentification (« Mon compte ») pour cette action');
}

const loginByAccountIp = new AttemptLimiter(5, 15 * 60_000);
const loginByIp = new AttemptLimiter(30, 15 * 60_000);
const DUMMY_HASH = bcrypt.hashSync(randomBytes(12).toString('hex'), 10);

/** Ordres possibles et ce qu'ils attendent */
export const COMMANDS = {
  restart: z.object({}),
  logs: z.object({ lines: z.number().int().min(10).max(2000).default(300) }),
  update: z.object({ releaseId: z.string().uuid(), when: z.enum(['night', 'now']).default('night') }),
  // Réglages du serveur du client (écrits dans itineo.env, puis le serveur est reconfiguré et redémarré)
  settings: z.object({ env: z.record(z.enum(['SMTP_URL', 'MAIL_FROM', 'DOMAIN']), z.string().max(500)) }),
  // Accès « support » dans Itinéos : l'administrateur du client doit l'accepter ; limité dans le temps
  support: z.object({ hours: z.number().int().min(1).max(8).default(2), reason: z.string().trim().min(3).max(300) }),
  // Prise en main du PC (RustDesk) : mot de passe à usage unique, changé à la fin
  remote: z.object({ minutes: z.number().int().min(15).max(240).default(60) }),
} as const;
export type CommandKind = keyof typeof COMMANDS;

/** Accès support ou prise en main terminés : le mot de passe ne s'affiche plus (même si l'agent ne l'a pas encore signalé) */
export function hideExpiredPassword<T extends { result?: unknown }>(c: T, now = new Date()): T {
  const r = c.result as Record<string, unknown> | null | undefined;
  if (!r || !('password' in r)) return c;
  const ended = r.closedAt || (typeof r.until === 'string' && new Date(r.until) < now);
  if (!ended) return c;
  const { password: _p, ...rest } = r;
  return { ...c, result: { ...rest, ended: true } };
}

/** Code d'inscription lisible au téléphone : 12 caractères sans 0/O ni 1/I */
export function newEnrollCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const chars = Array.from({ length: 12 }, () => alphabet[randomInt(alphabet.length)]);
  return `${chars.slice(0, 4).join('')}-${chars.slice(4, 8).join('')}-${chars.slice(8).join('')}`;
}

async function requireOperator(req: FastifyRequest) {
  try {
    await req.jwtVerify();
  } catch {
    throw new HttpError(401, 'Session expirée, reconnectez-vous');
  }
  const op = await one<{ id: string }>('SELECT id FROM operators WHERE id = $1', [req.user.sub]);
  if (!op) throw new HttpError(401, 'Session expirée, reconnectez-vous');
}

interface InstallationListRow {
  id: string; name: string; channel: string; client_id: string; client_name: string; hostname: string | null;
  version: string | null; edition: string | null; public_url: string | null; last_seen_at: Date | null;
  last_status: AgentStatus | null; enrolled_at: Date | null; open_bugs: number; remote_id: string | null;
}

/**
 * Code complet à coller dans l'installateur d'Itinéos : adresse de la console + code d'inscription
 * (ex. https://supervision.editeur.fr/ABCD-EFGH-JKLM), pour n'avoir qu'un champ à remplir chez le client
 */
function enrollKey(req: FastifyRequest, code: string) {
  const base = (env.CONSOLE_URL || `${req.protocol}://${req.host}`).replace(/\/+$/, '');
  return `${base}/${code}`;
}

function withHealth(r: InstallationListRow) {
  const { health, problems } = evaluateHealth(r.last_seen_at, r.last_status);
  return { ...r, health, problems };
}

export async function consoleRoutes(app: FastifyInstance) {
  // ─── Connexion ───
  app.post('/api/auth/login', async (req, reply: FastifyReply) => {
    const body = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1), code: z.string().trim().max(10).optional() }).parse(req.body);
    const key = `${body.email}|${req.ip}`;
    if (loginByAccountIp.blocked(key) || loginByIp.blocked(req.ip)) throw new HttpError(429, 'Trop de tentatives. Réessayez dans 15 minutes.');
    const op = await one<{ id: string; name: string; password_hash: string; totp_enabled: boolean; totp_secret: string | null; totp_last_step: string | null }>(
      'SELECT id, name, password_hash, totp_enabled, totp_secret, totp_last_step FROM operators WHERE email = $1', [body.email]);
    const ok = await bcrypt.compare(body.password, op?.password_hash ?? DUMMY_HASH);
    if (!ok || !op) {
      loginByAccountIp.hit(key);
      loginByIp.hit(req.ip);
      throw new HttpError(401, 'E-mail ou mot de passe incorrect');
    }
    // Double authentification : le mot de passe ne suffit pas, il faut aussi le code du téléphone
    if (op.totp_enabled && op.totp_secret) {
      if (!body.code) return reply.send({ needCode: true });
      const step = verifyTotp(op.totp_secret, body.code, op.totp_last_step === null ? null : Number(op.totp_last_step));
      if (step === null) {
        loginByAccountIp.hit(key);
        loginByIp.hit(req.ip);
        throw new HttpError(401, 'Code de double authentification incorrect');
      }
      await query('UPDATE operators SET totp_last_step = $2 WHERE id = $1', [op.id, step]);
    }
    loginByAccountIp.reset(key);
    await audit(op.id, 'login', null, { ip: req.ip, mfa: op.totp_enabled });
    return reply.send({ token: app.jwt.sign({ sub: op.id, kind: 'operator', mfa: op.totp_enabled }, { expiresIn: '12h' }), name: op.name });
  });

  await app.register(async (api) => {
    api.addHook('preHandler', requireOperator);
    const me = (req: FastifyRequest) => req.user.sub;

    api.get('/api/me', async (req) => ({
      ...(await one('SELECT id, email, name, totp_enabled, alerts, daily_summary FROM operators WHERE id = $1', [me(req)])),
      mfa: req.user.mfa,
    }));

    api.patch('/api/me', async (req) => {
      const b = z.object({ alerts: z.boolean().optional(), dailySummary: z.boolean().optional() }).parse(req.body);
      await query('UPDATE operators SET alerts = COALESCE($2, alerts), daily_summary = COALESCE($3, daily_summary) WHERE id = $1',
        [me(req), b.alerts ?? null, b.dailySummary ?? null]);
      return { ok: true };
    });

    // ─── Double authentification : mise en place (secret à scanner), activation (premier code), retrait ───
    api.post('/api/me/totp/setup', async (req) => {
      const op = await one<{ email: string; totp_enabled: boolean }>('SELECT email, totp_enabled FROM operators WHERE id = $1', [me(req)]);
      if (op!.totp_enabled) throw new HttpError(409, 'La double authentification est déjà active');
      const secret = newTotpSecret();
      await query('UPDATE operators SET totp_secret = $2 WHERE id = $1', [me(req), secret]);
      return { secret, uri: otpauthUri(secret, op!.email) };
    });

    api.post('/api/me/totp/enable', async (req, reply) => {
      const { code } = z.object({ code: z.string().trim() }).parse(req.body);
      const op = await one<{ totp_secret: string | null; totp_enabled: boolean }>('SELECT totp_secret, totp_enabled FROM operators WHERE id = $1', [me(req)]);
      if (!op?.totp_secret || op.totp_enabled) throw new HttpError(409, 'Commencez par afficher le code à scanner');
      const step = verifyTotp(op.totp_secret, code, null);
      if (step === null) throw new HttpError(400, 'Code incorrect : vérifiez l’heure du téléphone et réessayez');
      await query('UPDATE operators SET totp_enabled = true, totp_last_step = $2 WHERE id = $1', [me(req), step]);
      await audit(me(req), 'mfa.enable', me(req));
      // Nouvelle session, reconnue comme protégée par la double authentification
      return reply.send({ token: app.jwt.sign({ sub: me(req), kind: 'operator', mfa: true }, { expiresIn: '12h' }) });
    });

    api.post('/api/me/totp/disable', async (req) => {
      requireMfa(req);
      const { code } = z.object({ code: z.string().trim() }).parse(req.body);
      const op = await one<{ totp_secret: string | null; totp_last_step: string | null }>('SELECT totp_secret, totp_last_step FROM operators WHERE id = $1', [me(req)]);
      if (!op?.totp_secret || verifyTotp(op.totp_secret, code, op.totp_last_step === null ? null : Number(op.totp_last_step)) === null) {
        throw new HttpError(400, 'Code incorrect');
      }
      await query('UPDATE operators SET totp_enabled = false, totp_secret = NULL, totp_last_step = NULL WHERE id = $1', [me(req)]);
      await audit(me(req), 'mfa.disable', me(req));
      return { ok: true };
    });

    // ─── Vue d'ensemble : toutes les installations et leur état ───
    api.get('/api/overview', async () => {
      const rows = await query<InstallationListRow>(`
        SELECT i.id, i.name, i.channel, i.client_id, c.name AS client_name, i.hostname, i.version, i.edition, i.public_url,
               i.last_seen_at, i.last_status, i.enrolled_at, i.remote_id,
               (SELECT count(*)::int FROM bug_reports b WHERE b.installation_id = i.id AND b.status = 'OPEN') AS open_bugs
        FROM installations i JOIN clients c ON c.id = i.client_id
        ORDER BY c.name, i.name`);
      const installations = rows.map(withHealth);
      const count = (h: string) => installations.filter((i) => i.health === h).length;
      return {
        installations,
        totals: { all: installations.length, ok: count('ok'), warning: count('warning'), down: count('down'), never: count('never'),
          openBugs: installations.reduce((n, i) => n + i.open_bugs, 0) },
      };
    });

    // ─── Clients ───
    const clientBody = z.object({
      name: z.string().trim().min(1).max(200),
      contactName: z.string().trim().max(200).nullable().optional(),
      email: z.string().trim().max(200).nullable().optional(),
      phone: z.string().trim().max(50).nullable().optional(),
      notes: z.string().max(5000).nullable().optional(),
    });
    api.get('/api/clients', async () => query(`
      SELECT c.*, (SELECT count(*)::int FROM installations i WHERE i.client_id = c.id) AS installations
      FROM clients c ORDER BY c.name`));
    api.post('/api/clients', async (req, reply) => {
      const b = clientBody.parse(req.body);
      const row = await one('INSERT INTO clients (name, contact_name, email, phone, notes) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [b.name, b.contactName ?? null, b.email ?? null, b.phone ?? null, b.notes ?? null]);
      await audit(me(req), 'client.create', (row as { id: string }).id, { name: b.name });
      return reply.code(201).send(row);
    });
    api.patch('/api/clients/:id', async (req) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const b = clientBody.partial().parse(req.body);
      const row = await one(`UPDATE clients SET name = COALESCE($2, name), contact_name = COALESCE($3, contact_name), email = COALESCE($4, email),
        phone = COALESCE($5, phone), notes = COALESCE($6, notes) WHERE id = $1 RETURNING *`,
        [id, b.name ?? null, b.contactName ?? null, b.email ?? null, b.phone ?? null, b.notes ?? null]);
      if (!row) throw new HttpError(404, 'Client introuvable');
      return row;
    });

    // ─── Installations ───
    api.post('/api/installations', async (req, reply) => {
      const b = z.object({
        clientId: z.string().uuid(),
        name: z.string().trim().min(1).max(200),
        channel: z.string().trim().toLowerCase().regex(/^[a-z0-9-]{1,40}$/, 'Canal : lettres, chiffres et tirets').default('standard'),
      }).parse(req.body);
      const code = newEnrollCode();
      const row = await one<{ id: string }>(
        `INSERT INTO installations (client_id, name, channel, enroll_code_hash, enroll_expires_at)
         VALUES ($1, $2, $3, $4, now() + interval '7 days') RETURNING id`, [b.clientId, b.name, b.channel, hashToken(code)],
      );
      await audit(me(req), 'installation.create', row!.id, { name: b.name, channel: b.channel });
      // Le code n'est montré qu'une fois : il se saisit dans l'installateur d'Itinéos chez le client
      return reply.code(201).send({ id: row!.id, enrollCode: code, enrollKey: enrollKey(req, code) });
    });

    api.post('/api/installations/:id/enroll-code', async (req) => {
      requireMfa(req);
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const code = newEnrollCode();
      // Nouveau code = l'ancien secret de l'agent ne vaut plus (réinstallation, PC remplacé)
      const row = await one(`UPDATE installations SET enroll_code_hash = $2, enroll_expires_at = now() + interval '7 days', secret_hash = NULL
        WHERE id = $1 RETURNING id`, [id, hashToken(code)]);
      if (!row) throw new HttpError(404, 'Installation introuvable');
      await audit(me(req), 'installation.enroll-code', id);
      return { enrollCode: code, enrollKey: enrollKey(req, code) };
    });

    api.get('/api/installations/:id', async (req) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const [row] = await query<InstallationListRow & { notes: string | null }>(`
        SELECT i.*, c.name AS client_name,
          (SELECT count(*)::int FROM bug_reports b WHERE b.installation_id = i.id AND b.status = 'OPEN') AS open_bugs
        FROM installations i JOIN clients c ON c.id = i.client_id WHERE i.id = $1`, [id]);
      if (!row) throw new HttpError(404, 'Installation introuvable');
      const { secret_hash: _s, enroll_code_hash: _e, ...safe } = row as unknown as Record<string, unknown>;
      // Disponibilité sur 24 h : un point par heure (vert si au moins un passage sans panne)
      // Une heure est « en panne » si un passage signalait une panne, ou si l'agent s'est tu plus de 5 minutes
      const timeline = await query(`
        WITH b AS (
          SELECT at, health, lag(at) OVER (ORDER BY at) AS prev FROM heartbeats
          WHERE installation_id = $1 AND at > now() - interval '25 hours'
        )
        SELECT date_trunc('hour', at) AS hour, count(*)::int AS beats,
               bool_or(health = 'down' OR (prev IS NOT NULL AND at - prev > interval '5 minutes')) AS had_down,
               bool_or(health = 'warning') AS had_warning
        FROM b WHERE at > now() - interval '24 hours'
        GROUP BY 1 ORDER BY 1`, [id]);
      const commands = await query(`SELECT c.*, o.name AS created_by_name FROM commands c LEFT JOIN operators o ON o.id = c.created_by
        WHERE installation_id = $1 ORDER BY created_at DESC LIMIT 30`, [id]);
      const bugs = await query(`SELECT * FROM bug_reports WHERE installation_id = $1 ORDER BY (status = 'OPEN') DESC, last_at DESC LIMIT 100`, [id]);
      const releases = await query(`SELECT id, version, channel, notes, created_at FROM releases WHERE channel IN ('standard', $1) ORDER BY created_at DESC`, [row.channel]);
      return { ...withHealth(row), ...safe, timeline, commands: commands.map((c) => hideExpiredPassword(c)), bugs, releases };
    });

    api.patch('/api/installations/:id', async (req) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const b = z.object({
        name: z.string().trim().min(1).max(200).optional(),
        channel: z.string().trim().toLowerCase().regex(/^[a-z0-9-]{1,40}$/).optional(),
        notes: z.string().max(5000).nullable().optional(),
      }).parse(req.body);
      const row = await one(`UPDATE installations SET name = COALESCE($2, name), channel = COALESCE($3, channel), notes = COALESCE($4, notes)
        WHERE id = $1 RETURNING id`, [id, b.name ?? null, b.channel ?? null, b.notes ?? null]);
      if (!row) throw new HttpError(404, 'Installation introuvable');
      await audit(me(req), 'installation.update', id, b);
      return { ok: true };
    });

    // ─── Ordres à distance ───
    api.post('/api/installations/:id/commands', async (req, reply) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const { kind, payload } = z.object({ kind: z.enum(Object.keys(COMMANDS) as [CommandKind, ...CommandKind[]]), payload: z.unknown().default({}) }).parse(req.body);
      if (SENSITIVE_COMMANDS.has(kind)) requireMfa(req);
      const data = COMMANDS[kind].parse(payload) as Record<string, unknown>;
      const inst = await one<{ id: string; channel: string; secret_hash: string | null }>('SELECT id, channel, secret_hash FROM installations WHERE id = $1', [id]);
      if (!inst) throw new HttpError(404, 'Installation introuvable');
      if (!inst.secret_hash) throw new HttpError(409, 'Cette installation n’est pas encore inscrite');
      if (kind === 'update') {
        const rel = await one<{ channel: string }>('SELECT channel FROM releases WHERE id = $1', [data.releaseId]);
        if (!rel) throw new HttpError(404, 'Version introuvable');
        if (rel.channel !== 'standard' && rel.channel !== inst.channel) throw new HttpError(409, `Cette version est celle du canal « ${rel.channel} »`);
        await query('UPDATE installations SET target_release_id = $2 WHERE id = $1', [id, data.releaseId]);
        // Une seule mise à jour à la fois : la nouvelle remplace celles qui n'ont pas encore été installées
        // (l'agent ne garde que la dernière ; un résultat tardif d'une ancienne est ignoré, voir agent-routes)
        await query(
          `UPDATE commands SET status = 'CANCELLED', result = $2, done_at = now()
           WHERE installation_id = $1 AND kind = 'update' AND status IN ('QUEUED', 'SENT')`,
          [id, { message: 'Remplacée par un ordre plus récent' }],
        );
      }
      const row = await one('INSERT INTO commands (installation_id, kind, payload, created_by) VALUES ($1, $2, $3, $4) RETURNING *', [id, kind, data, me(req)]);
      await audit(me(req), `command.${kind}`, id, data);
      return reply.code(201).send(row);
    });

    api.post('/api/commands/:id/cancel', async (req) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const row = await one(`UPDATE commands SET status = 'CANCELLED', done_at = now() WHERE id = $1 AND status = 'QUEUED' RETURNING id`, [id]);
      if (!row) throw new HttpError(409, 'Ordre déjà envoyé : il ne peut plus être annulé');
      await audit(me(req), 'command.cancel', id);
      return { ok: true };
    });

    // ─── Bugs ───
    api.get('/api/bugs', async (req) => {
      const q = z.object({ status: z.enum(['OPEN', 'RESOLVED', 'IGNORED', 'ALL']).default('OPEN') }).parse(req.query);
      return query(`
        SELECT b.*, i.name AS installation_name, c.name AS client_name
        FROM bug_reports b JOIN installations i ON i.id = b.installation_id JOIN clients c ON c.id = i.client_id
        WHERE ($1 = 'ALL' OR b.status = $1) ORDER BY b.last_at DESC LIMIT 500`, [q.status]);
    });
    api.patch('/api/bugs/:id', async (req) => {
      const { id } = z.object({ id: z.string().uuid() }).parse(req.params);
      const b = z.object({ status: z.enum(['OPEN', 'RESOLVED', 'IGNORED']).optional(), note: z.string().max(5000).nullable().optional() }).parse(req.body);
      const row = await one('UPDATE bug_reports SET status = COALESCE($2, status), note = COALESCE($3, note) WHERE id = $1 RETURNING *', [id, b.status ?? null, b.note ?? null]);
      if (!row) throw new HttpError(404, 'Bug introuvable');
      await audit(me(req), 'bug.update', id, b);
      return row;
    });

    // ─── Versions (paquets de mise à jour, construits par installeur\construire.ps1 -Paquet) ───
    api.get('/api/releases', async () => query(`
      SELECT r.id, r.version, r.channel, r.notes, r.size_bytes, r.sha256, r.created_at, o.name AS created_by_name,
        (SELECT count(*)::int FROM installations i WHERE i.version = r.version AND (r.channel = 'standard' OR i.channel = r.channel)) AS installed
      FROM releases r LEFT JOIN operators o ON o.id = r.created_by ORDER BY r.created_at DESC`));

    api.addContentTypeParser('application/zip', { parseAs: 'buffer', bodyLimit: 500 * 1024 * 1024 }, (_req, body, done) => done(null, body));
    api.post('/api/releases', { bodyLimit: 500 * 1024 * 1024 }, async (req, reply) => {
      requireMfa(req);
      const q = z.object({
        version: z.string().trim().regex(/^\d+\.\d+\.\d+([-.][A-Za-z0-9.]+)?$/, 'Version : 1.2.3'),
        channel: z.string().trim().toLowerCase().regex(/^[a-z0-9-]{1,40}$/).default('standard'),
        notes: z.string().max(5000).optional(),
      }).parse(req.query);
      const data = req.body as Buffer;
      if (!Buffer.isBuffer(data) || data.length < 100 || data[0] !== 0x50 || data[1] !== 0x4b) throw new HttpError(400, 'Envoyez le paquet .zip construit par construire.ps1 -Paquet');
      if (await one('SELECT 1 FROM releases WHERE version = $1 AND channel = $2', [q.version, q.channel])) {
        throw new HttpError(409, `La version ${q.version} du canal « ${q.channel} » existe déjà`);
      }
      const digest = sha256(data);
      const { privateKey } = await loadSigningKeys(env.DATA_DIR);
      const signature = signRelease(privateKey, q.version, q.channel, digest);
      const dir = path.join(env.DATA_DIR, 'versions');
      await mkdir(dir, { recursive: true });
      const fileName = `itineo-${q.channel}-${q.version}.zip`;
      await writeFile(path.join(dir, fileName), data);
      try {
        // Empreinte de référence des fichiers (empreinte.txt, mise par construire.ps1) : sert à vérifier l'intégrité
        const fingerprint = releaseFingerprint(data);
        const row = await one(`INSERT INTO releases (version, channel, notes, file_name, size_bytes, sha256, signature, created_by, fingerprint)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id, version, channel`, [q.version, q.channel, q.notes ?? null, fileName, data.length, digest, signature, me(req), fingerprint]);
        await audit(me(req), 'release.publish', (row as { id: string }).id, { version: q.version, channel: q.channel, bytes: data.length });
        return reply.code(201).send(row);
      } catch (err) {
        await unlink(path.join(dir, fileName)).catch(() => undefined);
        throw err;
      }
    });

    // ─── Réglages : serveur RustDesk de l'éditeur (envoyé aux agents, qui configurent la prise en main) ───
    api.get('/api/settings/rustdesk', async () => (await one<{ value: unknown }>("SELECT value FROM settings WHERE key = 'rustdesk'"))?.value ?? null);
    api.put('/api/settings/rustdesk', async (req) => {
      requireMfa(req);
      const b = z.object({
        server: z.string().trim().regex(/^[a-z0-9.-]+(:\d+)?$/i, 'Nom ou adresse du serveur, sans http://').max(200),
        key: z.string().trim().regex(/^[A-Za-z0-9+/=]{20,100}$/, 'Clé publique du serveur RustDesk (fichier id_ed25519.pub)'),
      }).nullable().parse(req.body);
      if (b) await query(`INSERT INTO settings (key, value) VALUES ('rustdesk', $1) ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = now()`, [b]);
      else await query("DELETE FROM settings WHERE key = 'rustdesk'");
      await audit(me(req), 'settings.rustdesk', null, b);
      return { ok: true };
    });

    api.get('/api/alerts', async () => query(`SELECT a.id, a.kind, a.subject, a.body, a.sent_to, a.error, a.at, a.installation_id
      FROM alerts a ORDER BY a.at DESC LIMIT 200`));

    api.get('/api/audit', async () => query(`SELECT a.*, o.name AS operator_name FROM audit_logs a LEFT JOIN operators o ON o.id = a.operator_id
      ORDER BY a.at DESC LIMIT 300`));
  });
}
