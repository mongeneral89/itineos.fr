/**
 * Crée un compte de la console (vous, ou un collègue du support).
 *   npm run operator:create -w @itineo/supervision -- --email vous@exemple.fr --name "Prénom Nom"
 * Le mot de passe provisoire est affiché une seule fois.
 */
import { randomBytes } from 'node:crypto';
import { parseArgs } from 'node:util';
import bcrypt from 'bcryptjs';
import { migrate, one, pool } from './db.js';

const { values } = parseArgs({ options: { email: { type: 'string' }, name: { type: 'string' }, password: { type: 'string' } } });
try {
  if (!values.email || !values.name) throw new Error('Usage : npm run operator:create -w @itineo/supervision -- --email vous@exemple.fr --name "Prénom Nom"');
  await migrate();
  const email = values.email.trim().toLowerCase();
  if (await one('SELECT 1 FROM operators WHERE email = $1', [email])) throw new Error(`Un compte existe déjà pour ${email}`);
  const password = values.password ?? randomBytes(12).toString('base64url');
  await one('INSERT INTO operators (email, name, password_hash) VALUES ($1, $2, $3) RETURNING id', [email, values.name, await bcrypt.hash(password, 12)]);
  console.log(`\nCompte de la console créé.\n\n  E-mail       : ${email}\n  Mot de passe : ${password}\n`);
} catch (err) {
  console.error((err as Error).message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
