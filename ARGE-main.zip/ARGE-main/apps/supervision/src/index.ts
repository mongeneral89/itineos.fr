import { buildApp } from './app.js';
import { env } from './env.js';
import { migrate } from './db.js';
import { loadSigningKeys } from './signing.js';
import { startMonitor } from './alerts.js';

const applied = await migrate();
if (applied.length) console.log(`Migrations appliquées : ${applied.join(', ')}`);
// Clé de signature des mises à jour : créée au premier démarrage
await loadSigningKeys(env.DATA_DIR);
const app = await buildApp();
await app.listen({ port: env.PORT, host: env.HOST });
// Pannes, retours en service, résumé du matin : e-mails aux opérateurs
startMonitor((m) => app.log.info(m));
