/**
 * Alertes par e-mail aux opérateurs (ceux qui les ont gardées dans « Mon compte ») :
 *  - une installation tombe en panne, puis revient en service (seulement quand l'état change : pas de répétition) ;
 *  - un nouveau bug apparaît (ou un bug résolu revient) ;
 *  - une mise à jour a échoué ;
 *  - chaque matin à 8 h : le résumé (états, bugs ouverts, mises à jour de la nuit).
 * Sans SMTP_URL, les e-mails sont seulement écrits dans le journal de la console (et gardés dans « Alertes »).
 */
import nodemailer, { type Transporter } from 'nodemailer';
import { env } from './env.js';
import { one, query } from './db.js';
import { evaluateHealth, type AgentStatus, type Health } from './health.js';

let transport: Transporter | null = null;
function mailer(): Transporter {
  transport ??= env.SMTP_URL ? nodemailer.createTransport(env.SMTP_URL) : nodemailer.createTransport({ jsonTransport: true });
  return transport;
}

const link = (path: string) => (env.CONSOLE_URL ? `${env.CONSOLE_URL.replace(/\/$/, '')}/#${path}` : null);

export async function sendAlert(kind: string, installationId: string | null, subject: string, lines: string[], audience: 'alerts' | 'daily_summary' = 'alerts', log?: (m: string) => void) {
  const to = (await query<{ email: string }>(`SELECT email FROM operators WHERE ${audience === 'alerts' ? 'alerts' : 'daily_summary'} = true`)).map((r) => r.email);
  const body = lines.filter(Boolean).join('\n');
  let error: string | null = null;
  if (to.length) {
    try {
      await mailer().sendMail({ from: env.MAIL_FROM, to, subject: `[Itinéos Supervision] ${subject}`, text: body });
    } catch (err) {
      error = (err as Error).message.slice(0, 300);
    }
  }
  await query('INSERT INTO alerts (installation_id, kind, subject, body, sent_to, error) VALUES ($1, $2, $3, $4, $5, $6)', [installationId, kind, subject, body, to, error]);
  log?.(`Alerte « ${subject} » → ${to.join(', ') || 'personne'}${error ? ` (échec : ${error})` : env.SMTP_URL ? '' : ' (sans SMTP : non envoyée)'}`);
}

interface Row { id: string; name: string; client_name: string; last_seen_at: Date | null; last_status: AgentStatus | null; alert_health: Health | null; enrolled_at: Date | null }

/**
 * Compare l'état de chaque installation au dernier état signalé. Alerte quand une installation passe en panne, et
 * quand elle en sort. « À surveiller » ne déclenche pas d'e-mail (il figure dans le résumé du matin).
 */
export async function checkInstallations(log?: (m: string) => void, now = new Date()) {
  const rows = await query<Row>(`SELECT i.id, i.name, c.name AS client_name, i.last_seen_at, i.last_status, i.alert_health, i.enrolled_at
    FROM installations i JOIN clients c ON c.id = i.client_id WHERE i.enrolled_at IS NOT NULL`);
  for (const r of rows) {
    const { health, problems } = evaluateHealth(r.last_seen_at, r.last_status, now);
    if (health === r.alert_health) continue;
    await query('UPDATE installations SET alert_health = $2, alert_changed_at = $3 WHERE id = $1', [r.id, health, now]);
    const who = `${r.client_name} · ${r.name}`;
    if (health === 'down') {
      await sendAlert('down', r.id, `EN PANNE : ${who}`, [`${who} est en panne.`, '', ...problems.map((p) => `- ${p}`), '', link(`/installations/${r.id}`) ?? ''], 'alerts', log);
    } else if (r.alert_health === 'down') {
      await sendAlert('up', r.id, `De nouveau en service : ${who}`, [`${who} fonctionne de nouveau.`, link(`/installations/${r.id}`) ?? ''], 'alerts', log);
    }
  }
}

export async function alertNewBugs(installationId: string, bugs: { title: string; source: string; message?: string | null }[], log?: (m: string) => void) {
  if (!bugs.length) return;
  const inst = await one<{ name: string; client_name: string }>('SELECT i.name, c.name AS client_name FROM installations i JOIN clients c ON c.id = i.client_id WHERE i.id = $1', [installationId]);
  const who = `${inst?.client_name} · ${inst?.name}`;
  await sendAlert('bug', installationId, bugs.length === 1 ? `Nouveau bug : ${who}` : `${bugs.length} nouveaux bugs : ${who}`, [
    ...bugs.map((b) => `- ${b.source === 'user' ? 'Signalé par le client' : 'Erreur du serveur'} : ${b.title}${b.message && b.source === 'user' ? `\n  ${b.message}` : ''}`),
    '', link(`/installations/${installationId}`) ?? '',
  ], 'alerts', log);
}

export async function alertUpdateFailed(installationId: string, result: Record<string, unknown> | undefined, log?: (m: string) => void) {
  const inst = await one<{ name: string; client_name: string }>('SELECT i.name, c.name AS client_name FROM installations i JOIN clients c ON c.id = i.client_id WHERE i.id = $1', [installationId]);
  await sendAlert('update-failed', installationId, `Mise à jour ratée : ${inst?.client_name} · ${inst?.name}`, [
    `La mise à jour${result?.version ? ` vers ${String(result.version)}` : ''} a échoué : ${String(result?.message ?? result?.error ?? 'raison inconnue')}.`,
    result?.rolledBack ? 'Le retour à la version précédente a été fait.' : '',
    link(`/installations/${installationId}`) ?? '',
  ], 'alerts', log);
}

/** Fichiers du logiciel modifiés chez un client (empreinte différente de celle de sa version) */
export async function alertIntegrity(installationId: string, version: string | undefined, log?: (m: string) => void) {
  const inst = await one<{ name: string; client_name: string }>('SELECT i.name, c.name AS client_name FROM installations i JOIN clients c ON c.id = i.client_id WHERE i.id = $1', [installationId]);
  await sendAlert('integrity', installationId, `Fichiers modifiés : ${inst?.client_name} · ${inst?.name}`, [
    `Les fichiers d'Itinéos${version ? ` ${version}` : ''} installés chez ${inst?.client_name} ne correspondent plus à la version livrée.`,
    'Quelqu’un les a modifiés sur le PC (ou un antivirus, une copie partielle). Vérifiez, puis réinstallez la version ou envoyez une mise à jour.',
    link(`/installations/${installationId}`) ?? '',
  ], 'alerts', log);
}

/** Résumé du matin (une fois par jour, à partir de 8 h) */
export async function dailySummary(log?: (m: string) => void, now = new Date()) {
  if (now.getHours() < 8) return;
  const today = now.toISOString().slice(0, 10);
  const last = await one<{ value: string }>("SELECT value FROM settings WHERE key = 'last_summary'");
  if (last?.value === today) return;
  await query(`INSERT INTO settings (key, value) VALUES ('last_summary', $1) ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = now()`, [JSON.stringify(today)]);
  const rows = await query<Row & { open_bugs: number }>(`SELECT i.id, i.name, c.name AS client_name, i.last_seen_at, i.last_status, i.alert_health, i.enrolled_at,
      (SELECT count(*)::int FROM bug_reports b WHERE b.installation_id = i.id AND b.status = 'OPEN') AS open_bugs
    FROM installations i JOIN clients c ON c.id = i.client_id ORDER BY c.name, i.name`);
  const lines: string[] = [];
  const label: Record<Health, string> = { ok: 'en service', warning: 'à surveiller', down: 'EN PANNE', never: 'jamais connectée' };
  const counts: Record<string, number> = {};
  for (const r of rows) {
    const { health, problems } = evaluateHealth(r.last_seen_at, r.last_status, now);
    counts[health] = (counts[health] ?? 0) + 1;
    if (health !== 'ok') lines.push(`- ${r.client_name} · ${r.name} : ${label[health]}${problems[0] ? ` (${problems[0]})` : ''}`);
  }
  const updates = await query<{ client_name: string; name: string; status: string; result: Record<string, unknown> | null }>(`
    SELECT c.name AS client_name, i.name, cm.status, cm.result FROM commands cm JOIN installations i ON i.id = cm.installation_id JOIN clients c ON c.id = i.client_id
    WHERE cm.kind = 'update' AND cm.done_at > now() - interval '24 hours'`);
  const bugs = (await one<{ n: number }>("SELECT count(*)::int AS n FROM bug_reports WHERE status = 'OPEN'"))?.n ?? 0;
  const newBugs = (await one<{ n: number }>("SELECT count(*)::int AS n FROM bug_reports WHERE first_at > now() - interval '24 hours'"))?.n ?? 0;
  await sendAlert('summary', null, `Résumé du ${now.toLocaleDateString('fr-FR')} : ${counts.ok ?? 0}/${rows.length} en service`, [
    `${rows.length} installation(s) : ${counts.ok ?? 0} en service, ${counts.warning ?? 0} à surveiller, ${counts.down ?? 0} en panne, ${counts.never ?? 0} jamais connectée(s).`,
    '', lines.length ? 'À regarder :' : 'Rien à signaler.', ...lines,
    '', `Bugs ouverts : ${bugs} (dont ${newBugs} nouveau(x) depuis hier).`,
    updates.length ? '' : '', ...(updates.length ? ['Mises à jour des dernières 24 h :', ...updates.map((u) => `- ${u.client_name} · ${u.name} : ${u.status === 'DONE' ? `version ${String(u.result?.version ?? '')} installée` : 'ÉCHEC'}`)] : []),
    '', link('/') ?? '',
  ], 'daily_summary', log);
}

/** Surveillance : chaque minute, états et résumé du matin */
export function startMonitor(log: (m: string) => void) {
  const tick = async () => {
    try {
      await checkInstallations(log);
      await dailySummary(log);
      // Mots de passe des accès support et prises en main terminés : effacés de la base
      await query(`UPDATE commands SET result = (result - 'password') || jsonb_build_object('ended', true)
        WHERE kind IN ('support', 'remote') AND result ? 'password' AND (result->>'until')::timestamptz < now()`);
    } catch (err) {
      log(`Surveillance : ${(err as Error).message}`);
    }
  };
  setTimeout(tick, 15_000);
  return setInterval(tick, 60_000);
}
