/**
 * État d'une installation à partir de ce que son agent envoie : vert (ok), orange (attention), rouge (en panne),
 * gris (jamais vue). Chaque problème est expliqué en une phrase, affichée dans la console.
 */

/** Ce que l'agent d'Itinéos envoie à chaque passage (voir apps/api/src/services/supervision.ts) */
export interface AgentStatus {
  version?: string;
  edition?: string;
  uptimeSeconds?: number;
  database?: { ok: boolean; sizeBytes?: number; error?: string };
  disk?: { freeBytes: number; totalBytes: number } | null;
  lastBackupAt?: string | null;
  errorsLastHour?: number;
  memoryBytes?: number;
  activity?: { users?: number; interventionsToday?: number; reportsSignedToday?: number };
  pendingUpdate?: string | null;
  remote?: { available: boolean; id?: string | null } | null;
  /** Empreinte des fichiers du logiciel (envoyée par l'agent) */
  integrity?: { fingerprint: string; files: number } | null;
  /** Verdict de la console : ok, modified (fichiers modifiés), reference (première empreinte relevée), unchecked */
  integrityVerdict?: 'ok' | 'modified' | 'reference' | 'unchecked';
}

export type Health = 'ok' | 'warning' | 'down' | 'never';

/** Sans nouvelles depuis 5 minutes (l'agent passe chaque minute) : l'installation est considérée en panne */
export const SILENCE_MS = 5 * 60_000;
const GB = 1024 ** 3;

export function evaluateHealth(lastSeenAt: Date | null, s: AgentStatus | null, now = new Date()): { health: Health; problems: string[] } {
  if (!lastSeenAt || !s) return { health: 'never', problems: ['Jamais connectée : l’installation n’a pas encore été inscrite.'] };
  const down: string[] = [];
  const warn: string[] = [];
  const silentMin = Math.round((now.getTime() - lastSeenAt.getTime()) / 60_000);
  if (now.getTime() - lastSeenAt.getTime() > SILENCE_MS) down.push(`Plus de nouvelles depuis ${silentMin} min (PC éteint, réseau coupé ou serveur arrêté).`);
  if (s.database && !s.database.ok) down.push(`Base de données inaccessible${s.database.error ? ` : ${s.database.error}` : ''}.`);
  if (s.disk) {
    const free = s.disk.freeBytes / GB;
    if (free < 2) down.push(`Disque presque plein : ${free.toFixed(1)} Go libres.`);
    else if (free < 10 || s.disk.freeBytes / s.disk.totalBytes < 0.1) warn.push(`Peu d’espace disque : ${free.toFixed(1)} Go libres.`);
  }
  if (s.lastBackupAt === null) warn.push('Aucune sauvegarde trouvée.');
  else if (s.lastBackupAt) {
    const hours = (now.getTime() - new Date(s.lastBackupAt).getTime()) / 3_600_000;
    if (hours > 36) warn.push(`Dernière sauvegarde il y a ${Math.round(hours / 24 * 10) / 10} jours.`);
  }
  if (s.integrityVerdict === 'modified') warn.push('Fichiers du logiciel modifiés sur ce PC (différents de la version installée).');
  if ((s.errorsLastHour ?? 0) > 0) warn.push(`${s.errorsLastHour} erreur(s) du serveur dans la dernière heure.`);
  if (down.length) return { health: 'down', problems: [...down, ...warn] };
  if (warn.length) return { health: 'warning', problems: warn };
  return { health: 'ok', problems: [] };
}
