import Fastify, { type FastifyRequest } from 'fastify';
import jwt from '@fastify/jwt';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { ZodError } from 'zod';
import { env } from './env.js';
import { HttpError } from './http.js';
import { agentRoutes } from './agent-routes.js';
import { consoleRoutes } from './console-routes.js';

const TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json',
};

export async function buildApp(opts: { logger?: boolean } = {}) {
  const app = Fastify({
    logger: (opts.logger ?? true) && { serializers: { req: (req: FastifyRequest) => ({ method: req.method, url: req.url, remoteAddress: req.ip }) } },
    trustProxy: env.TRUST_PROXY,
    bodyLimit: 2 * 1024 * 1024,
  });
  await app.register(jwt, { secret: env.JWT_SECRET });

  app.setErrorHandler((err, req, reply) => {
    if (err instanceof ZodError) {
      return reply.code(400).send({ error: 'Données invalides', issues: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })) });
    }
    if (err instanceof HttpError) return reply.code(err.statusCode).send({ error: err.message });
    const status = (err as { statusCode?: number }).statusCode;
    if (status && status < 500) return reply.code(status).send({ error: (err as Error).message });
    req.log.error(err);
    return reply.code(500).send({ error: 'Erreur interne de la console' });
  });

  // Sécurité de l'interface (servie par ce serveur en production)
  app.addHook('onSend', async (_req, reply) => {
    reply.header('X-Content-Type-Options', 'nosniff');
    reply.header('X-Frame-Options', 'DENY');
    reply.header('Referrer-Policy', 'no-referrer');
    reply.header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  });

  app.get('/api/health', async () => ({ ok: true }));
  await app.register(agentRoutes);
  await app.register(consoleRoutes);

  // Interface construite (production) : fichiers de WEB_DIR, et index.html pour les pages de l'appli
  if (env.WEB_DIR) {
    const root = path.resolve(env.WEB_DIR);
    app.setNotFoundHandler(async (req, reply) => {
      const url = new URL(req.url, 'http://x').pathname;
      if (req.method !== 'GET' || url.startsWith('/api/') || url.startsWith('/agent/')) return reply.code(404).send({ error: 'Introuvable' });
      const file = path.resolve(root, `.${decodeURIComponent(url)}`);
      const inside = file.startsWith(root + path.sep);
      try {
        if (!inside) throw new Error('hors du dossier');
        const data = await readFile(file);
        const cache = url.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache';
        return reply.type(TYPES[path.extname(file)] ?? 'application/octet-stream').header('Cache-Control', cache).send(data);
      } catch {
        return reply.type(TYPES['.html']).header('Cache-Control', 'no-cache').send(await readFile(path.join(root, 'index.html')));
      }
    });
  }
  return app;
}
