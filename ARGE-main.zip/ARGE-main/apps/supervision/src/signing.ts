/**
 * Signature des mises à jour (Ed25519). Chaque installation n'accepte qu'un paquet signé par une clé qu'elle connaît.
 *
 *  - Clé principale : DATA_DIR/cle-signature.pem, sur la console, signe les versions publiées.
 *  - Clé de secours : seule sa partie publique est sur la console (cle-secours.pub.pem) ; la partie privée est chiffrée
 *    par un mot de passe et gardée HORS de la console (clé USB, coffre-fort de mots de passe). Les installations la
 *    connaissent d'avance : si la clé principale est perdue ou volée, la clé de secours prend le relais.
 *    Une installation n'accepte une nouvelle clé de secours que si elle est « recommandée » par la clé principale.
 *
 * Ce qui est signé pour une version : « version|canal|sha256 du paquet ».
 */
import {
  createCipheriv, createDecipheriv, createHash, createPrivateKey, createPublicKey, generateKeyPairSync, randomBytes, scryptSync,
  sign, verify, type KeyObject,
} from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

export interface SigningKeys {
  privateKey: KeyObject;
  publicKeyPem: string;
  /** Clé de secours connue des installations, et sa recommandation signée par la clé principale */
  backup: { publicKeyPem: string; endorsement: string } | null;
}

let cache: { dir: string; keys: SigningKeys } | null = null;

export const keyFiles = (dataDir: string) => ({
  main: path.join(dataDir, 'cle-signature.pem'),
  backupPublic: path.join(dataDir, 'cle-secours.pub.pem'),
});

export async function loadSigningKeys(dataDir: string, reload = false): Promise<SigningKeys> {
  if (cache && cache.dir === dataDir && !reload) return cache.keys;
  const files = keyFiles(dataDir);
  if (!existsSync(files.main)) {
    await mkdir(dataDir, { recursive: true });
    const { privateKey } = generateKeyPairSync('ed25519');
    await writeFile(files.main, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  }
  const privateKey = createPrivateKey(await readFile(files.main));
  const publicKeyPem = createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }).toString();
  let backup: SigningKeys['backup'] = null;
  if (existsSync(files.backupPublic)) {
    const pem = (await readFile(files.backupPublic, 'utf8')).trim() + '\n';
    if (pem !== publicKeyPem) backup = { publicKeyPem: pem, endorsement: endorse(privateKey, pem) };
  }
  cache = { dir: dataDir, keys: { privateKey, publicKeyPem, backup } };
  return cache.keys;
}

export const sha256 = (data: Buffer) => createHash('sha256').update(data).digest('hex');

export function signedMessage(version: string, channel: string, digest: string): Buffer {
  return Buffer.from(`${version}|${channel}|${digest}`, 'utf8');
}

export function signRelease(privateKey: KeyObject, version: string, channel: string, digest: string): string {
  return sign(null, signedMessage(version, channel, digest), privateKey).toString('base64');
}

export function verifyRelease(publicKeyPem: string, version: string, channel: string, digest: string, signature: string): boolean {
  try {
    return verify(null, signedMessage(version, channel, digest), createPublicKey(publicKeyPem), Buffer.from(signature, 'base64'));
  } catch {
    return false;
  }
}

/** La clé principale « recommande » une clé de secours : les installations l'ajoutent seulement avec cette preuve */
export function endorse(privateKey: KeyObject, backupPublicKeyPem: string): string {
  return sign(null, Buffer.from(`cle-secours|${backupPublicKeyPem.trim()}`, 'utf8'), privateKey).toString('base64');
}

export function verifyEndorsement(trustedPem: string, backupPublicKeyPem: string, endorsement: string): boolean {
  try {
    return verify(null, Buffer.from(`cle-secours|${backupPublicKeyPem.trim()}`, 'utf8'), createPublicKey(trustedPem), Buffer.from(endorsement, 'base64'));
  } catch {
    return false;
  }
}

// ─── Clés chiffrées par mot de passe (copie de sauvegarde, clé de secours) ───

export interface EncryptedKey { format: 'itineo-cle-1'; kdf: 'scrypt'; salt: string; iv: string; tag: string; data: string; publicKey: string; createdAt: string }

export function encryptKey(privateKeyPem: string, passphrase: string): EncryptedKey {
  if (passphrase.length < 12) throw new Error('Mot de passe trop court : 12 caractères au moins');
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const key = scryptSync(passphrase, salt, 32, { N: 2 ** 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const data = Buffer.concat([cipher.update(privateKeyPem, 'utf8'), cipher.final()]);
  return {
    format: 'itineo-cle-1', kdf: 'scrypt', salt: salt.toString('base64'), iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'),
    data: data.toString('base64'),
    publicKey: createPublicKey(createPrivateKey(privateKeyPem)).export({ type: 'spki', format: 'pem' }).toString(),
    createdAt: new Date().toISOString(),
  };
}

export function decryptKey(file: EncryptedKey, passphrase: string): string {
  if (file.format !== 'itineo-cle-1') throw new Error('Fichier de clé inconnu');
  const key = scryptSync(passphrase, Buffer.from(file.salt, 'base64'), 32, { N: 2 ** 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(file.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(file.tag, 'base64'));
  try {
    return Buffer.concat([decipher.update(Buffer.from(file.data, 'base64')), decipher.final()]).toString('utf8');
  } catch {
    throw new Error('Mot de passe incorrect, ou fichier abîmé');
  }
}
