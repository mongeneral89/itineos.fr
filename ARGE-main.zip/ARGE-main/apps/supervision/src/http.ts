export class HttpError extends Error {
  constructor(public statusCode: number, message: string) {
    super(message);
  }
}

/** Tentatives de connexion à la console : 5 échecs par compte et adresse, 30 par adresse, sur 15 minutes */
export class AttemptLimiter {
  private readonly hits = new Map<string, number[]>();
  constructor(private readonly max: number, private readonly windowMs: number) {}
  blocked(key: string, now = Date.now()): boolean {
    const list = (this.hits.get(key) ?? []).filter((t) => now - t < this.windowMs);
    this.hits.set(key, list);
    return list.length >= this.max;
  }
  hit(key: string, now = Date.now()) {
    this.hits.set(key, [...(this.hits.get(key) ?? []), now]);
    if (this.hits.size > 10_000) for (const k of this.hits.keys()) this.blocked(k, now);
  }
  reset(key: string) {
    this.hits.delete(key);
  }
}
