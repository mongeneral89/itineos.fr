import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  DATABASE_URL: z.string().default('postgres://itineo:itineo@localhost:5432/supervision'),
  JWT_SECRET: z.string().min(16, 'JWT_SECRET doit faire au moins 16 caractères'),
  PORT: z.coerce.number().default(4000),
  HOST: z.string().default('0.0.0.0'),
  /** Dossier des données de la console : clés de signature, paquets de mise à jour */
  DATA_DIR: z.string().default('./donnees'),
  /** Dossier de l'interface construite (vite build) servie par le serveur ; vide en développement */
  WEB_DIR: z.string().optional(),
  TRUST_PROXY: z.enum(['true', 'false']).default('false').transform((v) => v === 'true'),
  /** Alertes par e-mail (vide : écrites seulement dans le journal) ; adresse de la console pour les liens */
  SMTP_URL: z.string().optional(),
  MAIL_FROM: z.string().default('Itinéos Supervision <no-reply@itineos.local>'),
  CONSOLE_URL: z.string().optional(),
});

const production = process.env.NODE_ENV === 'production';
const parsed = schema.parse({
  ...process.env,
  JWT_SECRET: process.env.JWT_SECRET ?? (production ? undefined : 'dev-secret-supervision-a-changer'),
});
if (production && parsed.JWT_SECRET.length < 32) throw new Error('JWT_SECRET doit faire au moins 32 caractères en production');

export const env = parsed;
