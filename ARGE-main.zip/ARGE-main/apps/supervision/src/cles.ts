/**
 * Clés de signature des mises à jour : copie de sauvegarde, clé de secours, restauration.
 *
 *   npm run cles -w @itineo/supervision -- secours [fichier]     crée la clé de secours (à garder HORS de la console)
 *   npm run cles -w @itineo/supervision -- sauvegarde [fichier]  copie chiffrée de la clé principale
 *   npm run cles -w @itineo/supervision -- restaurer <fichier>   remet une clé (copie de sauvegarde ou clé de secours)
 *
 * Les fichiers produits sont chiffrés par un mot de passe (12 caractères au moins) : sans lui, ils sont inutilisables.
 */
import { generateKeyPairSync } from 'node:crypto';
import { existsSync } from 'node:fs';
import { readFile, rename, writeFile } from 'node:fs/promises';
import readline from 'node:readline';
import { env } from './env.js';
import { decryptKey, encryptKey, keyFiles, loadSigningKeys, type EncryptedKey } from './signing.js';

/** Saisie du mot de passe sans l'afficher */
function askHidden(question: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    const out = rl as unknown as { _writeToOutput: (s: string) => void; output: NodeJS.WriteStream };
    let asked = false;
    out._writeToOutput = (s: string) => {
      if (!asked) { process.stdout.write(s); asked = true; } else if (s.includes('\n')) process.stdout.write('\n');
    };
    rl.question(question, (answer) => { rl.close(); resolve(answer); });
  });
}

async function newPassphrase(): Promise<string> {
  const a = process.env.CLE_MOT_DE_PASSE ?? await askHidden('  Mot de passe de protection (12 caractères au moins) : ');
  const b = process.env.CLE_MOT_DE_PASSE ?? await askHidden('  Encore une fois : ');
  if (a !== b) throw new Error('Les deux mots de passe sont différents');
  if (a.length < 12) throw new Error('Mot de passe trop court : 12 caractères au moins');
  return a;
}

const [, , action, fileArg] = process.argv;
const files = keyFiles(env.DATA_DIR);
try {
  if (action === 'secours') {
    const file = fileArg ?? 'cle-secours-CHIFFREE.json';
    if (existsSync(file)) throw new Error(`${file} existe déjà`);
    const pass = await newPassphrase();
    const { privateKey, publicKey } = generateKeyPairSync('ed25519');
    await writeFile(file, JSON.stringify(encryptKey(privateKey.export({ type: 'pkcs8', format: 'pem' }).toString(), pass), null, 2));
    await writeFile(files.backupPublic, publicKey.export({ type: 'spki', format: 'pem' }).toString());
    console.log(`
  Clé de secours créée : ${file}

  1. Mettez ce fichier HORS de la console (clé USB rangée, coffre-fort de mots de passe) et effacez-le d'ici.
  2. Gardez le mot de passe à part du fichier.
  Les installations apprennent cette clé à leur prochain passage (recommandée par la clé principale).
  Si la clé principale est un jour perdue : npm run cles -w @itineo/supervision -- restaurer ${file}
`);
  } else if (action === 'sauvegarde') {
    const file = fileArg ?? `cle-principale-CHIFFREE-${new Date().toISOString().slice(0, 10)}.json`;
    await loadSigningKeys(env.DATA_DIR);
    const pass = await newPassphrase();
    await writeFile(file, JSON.stringify(encryptKey(await readFile(files.main, 'utf8'), pass), null, 2));
    console.log(`\n  Copie chiffrée de la clé principale : ${file}\n  Rangez-la hors de la console, le mot de passe à part.\n`);
  } else if (action === 'restaurer') {
    if (!fileArg) throw new Error('Indiquez le fichier : restaurer <fichier>');
    const enc = JSON.parse(await readFile(fileArg, 'utf8')) as EncryptedKey;
    const pass = process.env.CLE_MOT_DE_PASSE ?? await askHidden('  Mot de passe du fichier : ');
    const pem = decryptKey(enc, pass);
    if (existsSync(files.main)) await rename(files.main, `${files.main}.remplacee-${Date.now()}`);
    await writeFile(files.main, pem, { mode: 0o600 });
    const keys = await loadSigningKeys(env.DATA_DIR, true);
    console.log(`\n  Clé restaurée : elle signe désormais les versions.${keys.backup ? '' : `
  C'était la clé de secours : créez-en une nouvelle tout de suite (npm run cles -w @itineo/supervision -- secours).`}\n`);
  } else {
    console.log('Usage : npm run cles -w @itineo/supervision -- secours [fichier] | sauvegarde [fichier] | restaurer <fichier>');
    process.exitCode = 1;
  }
} catch (err) {
  console.error(`  ${(err as Error).message}`);
  process.exitCode = 1;
}
