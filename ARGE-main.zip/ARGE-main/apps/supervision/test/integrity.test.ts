import { test } from 'node:test';
import assert from 'node:assert/strict';
import { deflateRawSync } from 'node:zlib';
import { readZipEntry, releaseFingerprint } from '../src/integrity.js';

/** Petit .zip (fichiers compressés, comme tar -a) pour le test */
function zip(files: Record<string, string>): Buffer {
  const locals: Buffer[] = [];
  const centrals: Buffer[] = [];
  let offset = 0;
  for (const [name, text] of Object.entries(files)) {
    const data = deflateRawSync(Buffer.from(text));
    const n = Buffer.from(name);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(8, 8); local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(text.length, 22); local.writeUInt16LE(n.length, 26);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(8, 10); central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(text.length, 24); central.writeUInt16LE(n.length, 28); central.writeUInt32LE(offset, 42);
    locals.push(local, n, data);
    centrals.push(central, n);
    offset += 30 + n.length + data.length;
  }
  const dir = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(Object.keys(files).length, 8); end.writeUInt16LE(Object.keys(files).length, 10);
  end.writeUInt32LE(dir.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, dir, end]);
}

test('paquet : l’empreinte de référence est lue dans empreinte.txt', () => {
  const fp = 'a'.repeat(64);
  const z = zip({ 'app/package.json': '{}', 'empreinte.txt': `${fp}\n` });
  assert.equal(readZipEntry(z, 'app/package.json')?.toString(), '{}');
  assert.equal(releaseFingerprint(z), fp);
  assert.equal(releaseFingerprint(zip({ 'app/package.json': '{}' })), null);
  assert.equal(releaseFingerprint(zip({ 'empreinte.txt': 'pas une empreinte' })), null);
});
