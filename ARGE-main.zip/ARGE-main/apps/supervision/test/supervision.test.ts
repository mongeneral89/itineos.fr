import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync } from 'node:crypto';
import { evaluateHealth } from '../src/health.js';
import { sha256, signRelease, verifyRelease } from '../src/signing.js';
import { newEnrollCode } from '../src/console-routes.js';

const now = new Date('2026-10-15T12:00:00Z');
const GB = 1024 ** 3;
const okStatus = { database: { ok: true }, disk: { freeBytes: 100 * GB, totalBytes: 500 * GB }, lastBackupAt: '2026-10-15T02:00:00Z', errorsLastHour: 0 };

test('état : en service, à surveiller, en panne, jamais vue', () => {
  assert.equal(evaluateHealth(new Date(now.getTime() - 30_000), okStatus, now).health, 'ok');
  assert.equal(evaluateHealth(null, null, now).health, 'never');
  const silent = evaluateHealth(new Date(now.getTime() - 20 * 60_000), okStatus, now);
  assert.equal(silent.health, 'down');
  assert.match(silent.problems[0], /20 min/);
  assert.equal(evaluateHealth(now, { ...okStatus, database: { ok: false, error: 'refusée' } }, now).health, 'down');
  const old = evaluateHealth(now, { ...okStatus, lastBackupAt: '2026-10-12T02:00:00Z' }, now);
  assert.equal(old.health, 'warning');
  assert.match(old.problems[0], /sauvegarde/);
  assert.equal(evaluateHealth(now, { ...okStatus, disk: { freeBytes: 1 * GB, totalBytes: 500 * GB } }, now).health, 'down');
  assert.equal(evaluateHealth(now, { ...okStatus, errorsLastHour: 3 }, now).health, 'warning');
});

test('signature : un paquet modifié, une autre version ou une autre clé sont refusés', () => {
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  const pem = publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const digest = sha256(Buffer.from('paquet'));
  const sig = signRelease(privateKey, '1.2.3', 'arge', digest);
  assert.equal(verifyRelease(pem, '1.2.3', 'arge', digest, sig), true);
  assert.equal(verifyRelease(pem, '1.2.3', 'arge', sha256(Buffer.from('paquet modifié')), sig), false);
  assert.equal(verifyRelease(pem, '1.2.4', 'arge', digest, sig), false);
  assert.equal(verifyRelease(pem, '1.2.3', 'standard', digest, sig), false);
  const other = generateKeyPairSync('ed25519').publicKey.export({ type: 'spki', format: 'pem' }).toString();
  assert.equal(verifyRelease(other, '1.2.3', 'arge', digest, sig), false);
});

test('code d’inscription : lisible, sans caractères ambigus', () => {
  for (let i = 0; i < 50; i++) assert.match(newEnrollCode(), /^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/);
});

test('double authentification : code de la RFC 6238, marge d’un pas, code déjà utilisé refusé', async () => {
  const { base32Encode, totpCode, verifyTotp, stepAt } = await import('../src/totp.js');
  // Vecteur de test de la RFC 6238 (SHA1) : secret « 12345678901234567890 », t = 59 s → 94287082 (8 chiffres) → 287082
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  assert.equal(totpCode(secret, stepAt(59_000)), '287082');
  const now = 1_800_000_000_000;
  const code = totpCode(secret, stepAt(now));
  const step = verifyTotp(secret, code, null, now);
  assert.equal(step, stepAt(now));
  assert.equal(verifyTotp(secret, code, step, now), null, 'un code ne sert qu’une fois');
  assert.equal(verifyTotp(secret, totpCode(secret, stepAt(now) - 1), null, now), stepAt(now) - 1, 'horloge en retard de 30 s');
  assert.equal(verifyTotp(secret, totpCode(secret, stepAt(now) - 3), null, now), null, 'trop ancien');
  assert.equal(verifyTotp(secret, 'abcdef', null, now), null);
});

test('clé chiffrée : retrouvée avec le bon mot de passe, refusée sinon', async () => {
  const { encryptKey, decryptKey } = await import('../src/signing.js');
  const pem = generateKeyPairSync('ed25519').privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
  const file = encryptKey(pem, 'un-mot-de-passe-long');
  assert.equal(decryptKey(file, 'un-mot-de-passe-long'), pem);
  assert.throws(() => decryptKey(file, 'mauvais mot de passe'), /incorrect/);
  assert.throws(() => encryptKey(pem, 'court'), /trop court/);
});

test('clé de secours : recommandée par la clé principale, sinon refusée', async () => {
  const { endorse, verifyEndorsement } = await import('../src/signing.js');
  const main = generateKeyPairSync('ed25519');
  const backup = generateKeyPairSync('ed25519').publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const mainPem = main.publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const proof = endorse(main.privateKey, backup);
  assert.equal(verifyEndorsement(mainPem, backup, proof), true);
  const intruder = generateKeyPairSync('ed25519');
  assert.equal(verifyEndorsement(mainPem, backup, endorse(intruder.privateKey, backup)), false);
});

test('mot de passe d’un accès terminé : plus affiché', async () => {
  const { hideExpiredPassword } = await import('../src/console-routes.js');
  const now = new Date('2026-10-16T12:00:00Z');
  const open = { result: { password: 'x', until: '2026-10-16T13:00:00Z' } };
  assert.equal((hideExpiredPassword(open, now).result as Record<string, unknown>).password, 'x');
  const expired = hideExpiredPassword({ result: { password: 'x', until: '2026-10-16T11:00:00Z' } }, now).result as Record<string, unknown>;
  assert.equal(expired.password, undefined);
  assert.equal(expired.ended, true);
  const closed = hideExpiredPassword({ result: { password: 'x', until: '2026-10-16T13:00:00Z', closedAt: '2026-10-16T11:30:00Z' } }, now).result as Record<string, unknown>;
  assert.equal(closed.password, undefined);
  assert.deepEqual(hideExpiredPassword({ result: null }, now), { result: null });
});
