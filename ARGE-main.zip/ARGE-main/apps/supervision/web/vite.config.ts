import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Interface de la console. En développement, /api est envoyé au serveur de la console (port 4000).
export default defineConfig({
  root: fileURLToPath(new URL('.', import.meta.url)),
  plugins: [react()],
  build: { outDir: fileURLToPath(new URL('../dist', import.meta.url)), emptyOutDir: true },
  server: {
    port: Number(process.env.SUPERVISION_WEB_PORT ?? 5180),
    proxy: { '/api': process.env.SUPERVISION_API_URL ?? 'http://localhost:4000' },
  },
});
