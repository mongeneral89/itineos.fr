/** Appels à l'API de la console, avec la session de l'opérateur */
const KEY = 'supervision.token';

export function getToken(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}
export function setToken(t: string | null) {
  try {
    if (t) localStorage.setItem(KEY, t);
    else localStorage.removeItem(KEY);
  } catch {
    /* stockage indisponible */
  }
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export const SESSION_EXPIRED = 'supervision:expired';

export async function api<T = unknown>(path: string, opts: { method?: string; body?: unknown; file?: { data: Blob; type: string } } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let body: BodyInit | undefined;
  if (opts.file) {
    headers['Content-Type'] = opts.file.type;
    body = opts.file.data;
  } else if (opts.body !== undefined) {
    headers['Content-Type'] = 'application/json';
    body = JSON.stringify(opts.body);
  }
  const res = await fetch(`/api${path}`, { method: opts.method ?? 'GET', headers, body });
  if (res.status === 401 && token) {
    setToken(null);
    window.dispatchEvent(new Event(SESSION_EXPIRED));
  }
  const data = res.headers.get('content-type')?.includes('json') ? await res.json() : null;
  if (!res.ok) {
    const issues = (data?.issues as { message: string }[] | undefined)?.map((i) => i.message).join(' · ');
    throw new ApiError(res.status, issues || data?.error || `Erreur ${res.status}`);
  }
  return data as T;
}

export const fmtDate = (d: string | null | undefined) =>
  d ? new Intl.DateTimeFormat('fr-FR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(d)) : '—';

export function ago(d: string | null | undefined): string {
  if (!d) return 'jamais';
  const s = Math.round((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 60) return 'à l’instant';
  if (s < 3600) return `il y a ${Math.round(s / 60)} min`;
  if (s < 86400) return `il y a ${Math.round(s / 3600)} h`;
  return `il y a ${Math.round(s / 86400)} j`;
}

export const bytes = (n: number | null | undefined) => {
  if (n == null) return '—';
  const u = ['o', 'Ko', 'Mo', 'Go', 'To'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(v < 10 && i ? 1 : 0)} ${u[i]}`;
};

export const HEALTH_LABEL: Record<string, string> = { ok: 'En service', warning: 'À surveiller', down: 'En panne', never: 'Jamais connectée' };
