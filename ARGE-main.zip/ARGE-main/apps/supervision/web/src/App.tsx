import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { ago, api, ApiError, bytes, fmtDate, getToken, HEALTH_LABEL, SESSION_EXPIRED, setToken } from './api';
import { InstallationPage } from './Installation';
import { AccountPage, AlertsPage, SettingsPage, type Me } from './Account';

/** Navigation par l'adresse (#/bugs, #/installations/…) : pas de bibliothèque de routage */
function useRoute(): [string, (to: string) => void] {
  const [route, setRoute] = useState(() => location.hash.slice(1) || '/');
  useEffect(() => {
    const on = () => setRoute(location.hash.slice(1) || '/');
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return [route, (to) => { location.hash = to; }];
}

/** Charge une ressource, et la recharge régulièrement (l'état des installations change seul) */
export function useLoad<T>(path: string, refreshMs = 0): { data: T | null; error: string | null; reload: () => void } {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const reload = useCallback(() => {
    api<T>(path).then((d) => { setData(d); setError(null); }).catch((e: Error) => setError(e.message));
  }, [path]);
  useEffect(() => {
    reload();
    if (!refreshMs) return;
    const t = setInterval(reload, refreshMs);
    return () => clearInterval(t);
  }, [reload, refreshMs]);
  return { data, error, reload };
}

/** Code complet d'inscription (adresse de la console + code) : un seul champ à coller dans l'installateur d'Itinéos */
export function EnrollKey({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const code = value.slice(value.lastIndexOf('/') + 1);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Presse-papiers refusé (page en http sur le réseau) : le texte reste sélectionnable à la main
    }
  };
  return (
    <div style={{ marginTop: 8 }}>
      <div className="row">
        <span className="code" style={{ userSelect: 'all', wordBreak: 'break-all' }}>{value}</span>
        <button type="button" onClick={copy}>{copied ? 'Copié' : 'Copier'}</button>
      </div>
      <p className="small muted" style={{ marginTop: 6 }}>
        À coller tel quel dans l’installateur d’Itinéos chez le client (champ « Code d’inscription »). Valable 7 jours, une seule fois.
        Installation sans l’installateur : <code>SUPERVISION_URL</code> = l’adresse, <code>SUPERVISION_CODE={code}</code> dans <code>itineo.env</code>.
      </p>
    </div>
  );
}

export function Health({ health }: { health: string }) {
  return <span className={`badge h-${health}`}><span className={`dot h-${health}`} />{HEALTH_LABEL[health] ?? health}</span>;
}

export function App() {
  const [token, setTok] = useState(getToken());
  const [route, go] = useRoute();
  useEffect(() => {
    const on = () => setTok(null);
    window.addEventListener(SESSION_EXPIRED, on);
    return () => window.removeEventListener(SESSION_EXPIRED, on);
  }, []);
  if (!token) return <Login onDone={(t) => { setToken(t); setTok(t); }} />;
  return <Shell route={route} go={go} onLogout={() => { setToken(null); setTok(null); }} />;
}

function Shell({ route, go, onLogout }: { route: string; go: (to: string) => void; onLogout: () => void }) {
  const { data: me, reload: reloadMe } = useLoad<Me>('/me');

  const inst = /^\/installations\/([0-9a-f-]{36})$/.exec(route);
  let page: ReactNode;
  if (inst) page = <InstallationPage id={inst[1]} go={go} />;
  else if (route === '/bugs') page = <Bugs go={go} />;
  else if (route === '/clients') page = <Clients go={go} />;
  else if (route === '/versions') page = <Releases />;
  else if (route === '/journal') page = <Journal />;
  else if (route === '/alertes') page = <AlertsPage />;
  else if (route === '/reglages') page = <SettingsPage mfa={!!me?.mfa} />;
  else if (route === '/compte') page = me ? <AccountPage me={me} onChanged={reloadMe} /> : null;
  else page = <Overview go={go} />;

  const link = (to: string, label: string) => <a href={`#${to}`} className={route === to || (to === '/' && !!inst) ? 'on' : ''}>{label}</a>;
  return (
    <div className="shell">
      <nav className="side">
        <div className="brand">Itinéos<small>Supervision</small></div>
        {link('/', 'Installations')}
        {link('/bugs', 'Bugs')}
        {link('/clients', 'Clients')}
        {link('/versions', 'Versions')}
        {link('/alertes', 'Alertes')}
        {link('/journal', 'Journal')}
        {link('/reglages', 'Réglages')}
        <div className="spacer" />
        {link('/compte', 'Mon compte')}
        <div className="who">{me?.name}</div>
        <button type="button" onClick={onLogout}>Se déconnecter</button>
      </nav>
      <main className="main">
        {me && !me.mfa && route !== '/compte' && (
          <div className="card" style={{ borderColor: 'var(--warn)', background: 'var(--warn-bg)' }}>
            <strong>{me.totp_enabled ? 'Reconnectez-vous avec votre code' : 'Activez la double authentification'}</strong>
            <span className="small"> : la prise en main, l’accès support, les mises à jour, les réglages et la publication de versions sont bloqués sans elle. </span>
            <a href="#/compte">Mon compte</a>
          </div>
        )}
        {page}
      </main>
    </div>
  );
}

function Login({ onDone }: { onDone: (token: string) => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [needCode, setNeedCode] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const r = await api<{ token?: string; needCode?: boolean }>('/auth/login', { method: 'POST', body: { email, password, ...(needCode ? { code } : {}) } });
      if (r.needCode) { setNeedCode(true); return; }
      onDone(r.token!);
    } catch (err) {
      setError((err as Error).message);
    }
  };
  return (
    <div className="login">
      <form className="card form" onSubmit={submit}>
        <h1>Itinéos Supervision</h1>
        <p className="muted small">Toutes les installations d’Itinéos chez vos clients.</p>
        <label>E-mail<input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
        <label>Mot de passe<input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
        {needCode && <label>Code de l’application d’authentification<input inputMode="numeric" autoComplete="one-time-code" autoFocus value={code} onChange={(e) => setCode(e.target.value)} required /></label>}
        {error && <p className="error">{error}</p>}
        <button className="primary" type="submit">Se connecter</button>
      </form>
    </div>
  );
}

interface OverviewRow {
  id: string; name: string; client_name: string; channel: string; version: string | null; hostname: string | null;
  last_seen_at: string | null; health: string; problems: string[]; open_bugs: number;
}

function Overview({ go }: { go: (to: string) => void }) {
  const { data, error } = useLoad<{ installations: OverviewRow[]; totals: Record<string, number> }>('/overview', 20_000);
  const [filter, setFilter] = useState('all');
  if (error) return <p className="error">{error}</p>;
  if (!data) return <p className="muted">Chargement…</p>;
  const t = data.totals;
  const rows = data.installations.filter((i) => filter === 'all' || i.health === filter);
  const tile = (key: string, n: number, label: string) => (
    <button type="button" className="tile" style={{ textAlign: 'left', outline: filter === key ? '2px solid var(--accent)' : undefined }} onClick={() => setFilter(key)}>
      <div className="n">{n}</div><div className="l">{label}</div>
    </button>
  );
  return (
    <>
      <div className="row spread"><h1>Installations</h1><span className="muted small">Mis à jour toutes les 20 s</span></div>
      <div className="grid">
        {tile('all', t.all, 'Installations')}
        {tile('ok', t.ok, 'En service')}
        {tile('warning', t.warning, 'À surveiller')}
        {tile('down', t.down, 'En panne')}
        {tile('never', t.never, 'Jamais connectées')}
        <a className="tile" href="#/bugs" style={{ textDecoration: 'none', color: 'inherit' }}><div className="n">{t.openBugs}</div><div className="l">Bugs ouverts</div></a>
      </div>
      <div className="card table-wrap">
        {!rows.length && <p className="muted">{data.installations.length ? 'Aucune installation dans cet état.' : 'Aucune installation : commencez par créer un client dans « Clients ».'}</p>}
        {!!rows.length && (
          <table>
            <thead><tr><th>Client</th><th>Installation</th><th>État</th><th>Version</th><th>Dernières nouvelles</th><th>Bugs</th></tr></thead>
            <tbody>
              {rows.map((i) => (
                <tr key={i.id} className="click" onClick={() => go(`/installations/${i.id}`)}>
                  <td><strong>{i.client_name}</strong></td>
                  <td>{i.name}<div className="muted small">{i.hostname ?? '—'}{i.channel !== 'standard' ? ` · canal ${i.channel}` : ''}</div></td>
                  <td><Health health={i.health} />{i.problems.slice(0, 2).map((p) => <div key={p} className="small muted">{p}</div>)}</td>
                  <td>{i.version ?? '—'}</td>
                  <td>{ago(i.last_seen_at)}</td>
                  <td>{i.open_bugs || ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

interface BugRow {
  id: string; installation_id: string; installation_name: string; client_name: string; source: string; title: string;
  message: string | null; occurrences: number; last_at: string; first_at: string; status: string; version: string | null; detail: Record<string, unknown> | null;
}

export function BugList({ bugs, onChange, showClient }: { bugs: BugRow[]; onChange: () => void; showClient?: boolean }) {
  const [open, setOpen] = useState<string | null>(null);
  const set = async (id: string, status: string) => { await api(`/bugs/${id}`, { method: 'PATCH', body: { status } }); onChange(); };
  if (!bugs.length) return <p className="muted">Aucun bug.</p>;
  return (
    <div className="table-wrap">
      <table>
        <thead><tr>{showClient && <th>Client</th>}<th>Bug</th><th>Fois</th><th>Dernière fois</th><th>Version</th><th /></tr></thead>
        <tbody>
          {bugs.map((b) => (
            <tr key={b.id}>
              {showClient && <td><a href={`#/installations/${b.installation_id}`}>{b.client_name}</a><div className="muted small">{b.installation_name}</div></td>}
              <td>
                <span className="badge" style={{ background: b.source === 'user' ? '#DBEAFE' : '#F3F4F6' }}>{b.source === 'user' ? 'Signalé par le client' : 'Erreur serveur'}</span>{' '}
                {b.status !== 'OPEN' && <span className="badge h-never">{b.status === 'RESOLVED' ? 'Résolu' : 'Ignoré'}</span>}
                <div><strong>{b.title}</strong></div>
                {b.message && <div className="small">{b.message}</div>}
                {b.detail && <button type="button" className="small" style={{ marginTop: 6 }} onClick={() => setOpen(open === b.id ? null : b.id)}>{open === b.id ? 'Masquer le détail' : 'Détail'}</button>}
                {open === b.id && <pre>{JSON.stringify(b.detail, null, 2)}</pre>}
              </td>
              <td>{b.occurrences}</td>
              <td>{ago(b.last_at)}</td>
              <td>{b.version ?? '—'}</td>
              <td>
                <div className="row">
                  {b.status === 'OPEN' ? (
                    <>
                      <button type="button" onClick={() => set(b.id, 'RESOLVED')}>Résolu</button>
                      <button type="button" onClick={() => set(b.id, 'IGNORED')}>Ignorer</button>
                    </>
                  ) : <button type="button" onClick={() => set(b.id, 'OPEN')}>Rouvrir</button>}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Bugs({ go: _go }: { go: (to: string) => void }) {
  const [status, setStatus] = useState('OPEN');
  const { data, error, reload } = useLoad<BugRow[]>(`/bugs?status=${status}`, 30_000);
  return (
    <>
      <div className="row spread">
        <h1>Bugs</h1>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="OPEN">Ouverts</option><option value="RESOLVED">Résolus</option><option value="IGNORED">Ignorés</option><option value="ALL">Tous</option>
        </select>
      </div>
      <p className="muted small">Erreurs du serveur remontées automatiquement, et problèmes signalés par les utilisateurs (« Signaler un problème » dans Itinéos). Une même erreur est regroupée ; un bug résolu qui revient est rouvert.</p>
      <div className="card">{error ? <p className="error">{error}</p> : data ? <BugList bugs={data} onChange={reload} showClient /> : <p className="muted">Chargement…</p>}</div>
    </>
  );
}

interface ClientRow { id: string; name: string; contact_name: string | null; email: string | null; phone: string | null; installations: number }

function Clients({ go }: { go: (to: string) => void }) {
  const { data, error, reload } = useLoad<ClientRow[]>('/clients');
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [newInst, setNewInst] = useState<{ clientId: string; name: string; channel: string } | null>(null);
  const [code, setCode] = useState<{ id: string; code: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const addClient = async (e: FormEvent) => {
    e.preventDefault();
    setErr(null);
    try {
      await api('/clients', { method: 'POST', body: { name, contactName: contact || null, email: email || null, phone: phone || null } });
      setName(''); setContact(''); setEmail(''); setPhone('');
      reload();
    } catch (x) { setErr((x as Error).message); }
  };
  const addInstallation = async (e: FormEvent) => {
    e.preventDefault();
    if (!newInst) return;
    setErr(null);
    try {
      const r = await api<{ id: string; enrollKey: string }>('/installations', { method: 'POST', body: newInst });
      setCode({ id: r.id, code: r.enrollKey });
      setNewInst(null);
      reload();
    } catch (x) { setErr((x as Error).message); }
  };

  return (
    <>
      <h1>Clients</h1>
      {code && (
        <div className="card" style={{ borderColor: 'var(--accent)' }}>
          <h2>Code d’inscription de la nouvelle installation</h2>
          <EnrollKey value={code.code} />
          <p className="small muted" style={{ marginTop: 8 }}>Il ne sera plus affiché : un nouveau code peut être créé depuis la page de l’installation.</p>
          <div className="row" style={{ marginTop: 8 }}><button type="button" onClick={() => go(`/installations/${code.id}`)}>Voir l’installation</button><button type="button" onClick={() => setCode(null)}>Fermer</button></div>
        </div>
      )}
      {err && <p className="error">{err}</p>}
      <div className="card table-wrap">
        {error && <p className="error">{error}</p>}
        {data && !data.length && <p className="muted">Aucun client pour l’instant.</p>}
        {!!data?.length && (
          <table>
            <thead><tr><th>Client</th><th>Contact</th><th>Installations</th><th /></tr></thead>
            <tbody>
              {data.map((c) => (
                <tr key={c.id}>
                  <td><strong>{c.name}</strong></td>
                  <td>{c.contact_name ?? '—'}<div className="muted small">{[c.email, c.phone].filter(Boolean).join(' · ')}</div></td>
                  <td>{c.installations}</td>
                  <td><button type="button" onClick={() => setNewInst({ clientId: c.id, name: 'Serveur du bureau', channel: 'standard' })}>Nouvelle installation</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {newInst && (
        <form className="card form" onSubmit={addInstallation}>
          <h2>Nouvelle installation pour {data?.find((c) => c.id === newInst.clientId)?.name}</h2>
          <label>Nom<input value={newInst.name} onChange={(e) => setNewInst({ ...newInst, name: e.target.value })} required /></label>
          <label>Canal des mises à jour (« standard », ou le nom d’une version propre à ce client, ex. arge)
            <input value={newInst.channel} onChange={(e) => setNewInst({ ...newInst, channel: e.target.value })} required />
          </label>
          <div className="row"><button className="primary" type="submit">Créer et obtenir le code</button><button type="button" onClick={() => setNewInst(null)}>Annuler</button></div>
        </form>
      )}
      <form className="card form" onSubmit={addClient}>
        <h2>Nouveau client</h2>
        <label>Entreprise<input value={name} onChange={(e) => setName(e.target.value)} required /></label>
        <label>Contact<input value={contact} onChange={(e) => setContact(e.target.value)} /></label>
        <div className="row">
          <label style={{ flex: 1 }}>E-mail<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
          <label style={{ flex: 1 }}>Téléphone<input value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
        </div>
        <div><button className="primary" type="submit">Ajouter le client</button></div>
      </form>
    </>
  );
}

interface ReleaseRow { id: string; version: string; channel: string; notes: string | null; size_bytes: string; sha256: string; created_at: string; created_by_name: string | null; installed: number }

function Releases() {
  const { data, error, reload } = useLoad<ReleaseRow[]>('/releases');
  return (
    <>
      <h1>Versions</h1>
      <div className="card">
        <p className="small">
          Une version est un paquet du logiciel (serveur et appli), construit sur votre PC puis publié ici. La console le <strong>signe</strong> :
          une installation n’accepte que les paquets signés par cette console. Canal « standard » : pour tous les clients ;
          autre canal (ex. « arge ») : version propre à un client.
        </p>
        <pre>{'powershell -ExecutionPolicy Bypass -File installeur\\construire.ps1 -Paquet -Canal standard -Publier http://localhost:4000'}</pre>
      </div>
      <PublishRelease onPublished={reload} />
      <div className="card table-wrap">
        {error && <p className="error">{error}</p>}
        {data && !data.length && <p className="muted">Aucune version publiée.</p>}
        {!!data?.length && (
          <table>
            <thead><tr><th>Version</th><th>Canal</th><th>Notes</th><th>Taille</th><th>Installée chez</th><th>Publiée</th></tr></thead>
            <tbody>
              {data.map((r) => (
                <tr key={r.id}>
                  <td><strong>{r.version}</strong><div className="muted small" title={r.sha256}>sha256 {r.sha256.slice(0, 12)}…</div></td>
                  <td>{r.channel}</td>
                  <td className="small">{r.notes ?? '—'}</td>
                  <td>{bytes(Number(r.size_bytes))}</td>
                  <td>{r.installed}</td>
                  <td>{fmtDate(r.created_at)}<div className="muted small">{r.created_by_name}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

/** Publier un paquet depuis le navigateur (le fichier itineo-<canal>-<version>.zip de construire.ps1 -Paquet) */
function PublishRelease({ onPublished }: { onPublished: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [version, setVersion] = useState('');
  const [channel, setChannel] = useState('standard');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  function pick(f: File | null) {
    setFile(f);
    setMsg(null);
    // Version et canal lus dans le nom du paquet quand il suit le modèle de construire.ps1
    const m = f?.name.match(/^itineo-([a-z0-9-]+)-(\d+\.\d+\.\d+(?:[-.][A-Za-z0-9.]+)?)\.zip$/i);
    if (m) { setChannel(m[1].toLowerCase()); setVersion(m[2]); }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true);
    setMsg(null);
    try {
      const q = new URLSearchParams({ version: version.trim(), channel: channel.trim() });
      if (notes.trim()) q.set('notes', notes.trim());
      await api(`/releases?${q}`, { method: 'POST', file: { data: file, type: 'application/zip' } });
      setMsg({ ok: true, text: `Version ${version.trim()} publiée et signée.` });
      setFile(null);
      setNotes('');
      onPublished();
    } catch (err) {
      setMsg({ ok: false, text: (err as Error).message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <h2>Publier un paquet</h2>
      <label>Paquet (.zip)<input type="file" accept=".zip,application/zip" onChange={(e) => pick(e.target.files?.[0] ?? null)} /></label>
      <div className="row">
        <label>Version<input value={version} onChange={(e) => setVersion(e.target.value)} placeholder="0.1.1" required /></label>
        <label>Canal<input value={channel} onChange={(e) => setChannel(e.target.value)} required /></label>
      </div>
      <label>Notes (facultatif)<input value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
      {msg && <p className={msg.ok ? 'small' : 'error'}>{msg.text}</p>}
      <button type="submit" disabled={!file || busy}>{busy ? 'Envoi…' : 'Publier'}</button>
    </form>
  );
}

const ACTIONS: Record<string, string> = {
  login: 'Connexion', 'client.create': 'Client créé', 'installation.create': 'Installation créée', 'installation.enroll': 'Installation inscrite',
  'installation.enroll-code': 'Nouveau code d’inscription', 'installation.update': 'Installation modifiée', 'command.restart': 'Redémarrage demandé',
  'command.logs': 'Journaux demandés', 'command.update': 'Mise à jour demandée', 'command.settings': 'Réglages envoyés',
  'command.support': 'Accès support demandé', 'command.remote': 'Prise en main demandée', 'command.cancel': 'Ordre annulé',
  'bug.update': 'Bug mis à jour', 'release.publish': 'Version publiée',
};

function Journal() {
  const { data, error } = useLoad<{ id: number; at: string; action: string; target: string | null; operator_name: string | null; detail: unknown }[]>('/audit');
  return (
    <>
      <h1>Journal</h1>
      <p className="muted small">Tout ce qui est fait depuis la console : qui, quoi, quand.</p>
      <div className="card table-wrap">
        {error && <p className="error">{error}</p>}
        {data && (
          <table>
            <thead><tr><th>Quand</th><th>Qui</th><th>Action</th><th>Détail</th></tr></thead>
            <tbody>
              {data.map((a) => (
                <tr key={a.id}>
                  <td>{fmtDate(a.at)}</td>
                  <td>{a.operator_name ?? 'Agent'}</td>
                  <td>{ACTIONS[a.action] ?? a.action}</td>
                  <td className="small muted">{a.detail ? JSON.stringify(a.detail) : ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

export type { BugRow };
export { ApiError };
