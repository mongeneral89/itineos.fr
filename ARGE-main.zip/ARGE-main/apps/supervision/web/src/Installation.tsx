/** Une installation : son état, son historique, les actions à distance et leurs résultats, ses bugs */
import { useState, type FormEvent } from 'react';
import { ago, api, bytes, fmtDate } from './api';
import { BugList, EnrollKey, Health, useLoad, type BugRow } from './App';

interface Status {
  version?: string; edition?: string; uptimeSeconds?: number;
  database?: { ok: boolean; sizeBytes?: number; error?: string };
  disk?: { freeBytes: number; totalBytes: number } | null;
  lastBackupAt?: string | null; errorsLastHour?: number; memoryBytes?: number;
  activity?: { users?: number; interventionsToday?: number; reportsSignedToday?: number };
  pendingUpdate?: string | null; remote?: { available: boolean; id?: string | null } | null;
  /** Empreinte des fichiers (agent) et verdict de la console */
  integrity?: { fingerprint: string; files: number } | null;
  integrityVerdict?: 'ok' | 'modified' | 'reference' | 'unchecked';
}
interface Command {
  id: string; kind: string; payload: Record<string, unknown>; status: string; result: Record<string, unknown> | null;
  created_at: string; done_at: string | null; created_by_name: string | null;
}
interface Detail {
  id: string; name: string; client_name: string; channel: string; hostname: string | null; version: string | null; edition: string | null;
  public_url: string | null; last_seen_at: string | null; last_status: Status | null; enrolled_at: string | null; notes: string | null;
  health: string; problems: string[]; timeline: { hour: string; beats: number; had_down: boolean; had_warning: boolean }[];
  commands: Command[]; bugs: BugRow[]; releases: { id: string; version: string; channel: string; notes: string | null }[];
}

const KIND: Record<string, string> = {
  restart: 'Redémarrage', logs: 'Journaux', update: 'Mise à jour', settings: 'Réglages', support: 'Accès support', remote: 'Prise en main du PC',
};
const STATUS: Record<string, string> = { QUEUED: 'En attente', SENT: 'Envoyé', DONE: 'Fait', FAILED: 'Échec', CANCELLED: 'Annulé' };

const plural = (n: number, one: string, many: string) => `${n} ${n > 1 ? many : one}`;

function duration(s?: number) {
  if (!s) return '—';
  const d = Math.floor(s / 86400); const h = Math.floor((s % 86400) / 3600); const m = Math.floor((s % 3600) / 60);
  return d ? `${d} j ${h} h` : h ? `${h} h ${m} min` : `${m} min`;
}

export function InstallationPage({ id, go }: { id: string; go: (to: string) => void }) {
  const { data, error, reload } = useLoad<Detail>(`/installations/${id}`, 15_000);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [code, setCode] = useState<string | null>(null);

  const [busy, setBusy] = useState(false);
  const send = async (kind: string, payload: Record<string, unknown> = {}, confirmText?: string) => {
    if (busy || (confirmText && !window.confirm(confirmText))) return;
    setMsg(null);
    setBusy(true);
    try {
      await api(`/installations/${id}/commands`, { method: 'POST', body: { kind, payload } });
      setMsg({ ok: true, text: `${KIND[kind]} : ordre envoyé. Il part au prochain passage de l’agent (moins d’une minute).` });
      reload();
    } catch (e) { setMsg({ ok: false, text: (e as Error).message }); } finally { setBusy(false); }
  };

  if (error) return <p className="error">{error}</p>;
  if (!data) return <p className="muted">Chargement…</p>;
  const s = data.last_status ?? {};
  const enrolled = !!data.enrolled_at;

  // 24 cases (une par heure), de la plus ancienne à maintenant
  // Heures sans aucun passage, après le premier passage de ces 24 h : l'installation s'est tue (en panne)
  const first = data.timeline.length ? Math.min(...data.timeline.map((x) => new Date(x.hour).getTime())) : null;
  const hours = Array.from({ length: 24 }, (_, k) => {
    const h = new Date(); h.setMinutes(0, 0, 0); h.setHours(h.getHours() - 23 + k);
    const t = data.timeline.find((x) => new Date(x.hour).getTime() === h.getTime());
    const seenBefore = first !== null && h.getTime() >= first;
    return { h, cls: !t ? (seenBefore ? 'down' : '') : t.had_down ? 'down' : t.had_warning ? 'warning' : 'ok', silent: !t && seenBefore };
  });

  return (
    <>
      <div className="row spread">
        <div>
          <a href="#/" className="small">← Installations</a>
          <h1>{data.client_name} · {data.name}</h1>
          <div className="muted small">{data.hostname ?? 'PC inconnu'} · édition {data.edition ?? '—'} · canal {data.channel}{data.public_url ? <> · <a href={data.public_url} target="_blank" rel="noreferrer">{data.public_url}</a></> : null}</div>
        </div>
        <Health health={data.health} />
      </div>

      {msg && <p className={msg.ok ? 'small' : 'error'}>{msg.text}</p>}

      {!enrolled && (
        <div className="card">
          <h2>En attente d’inscription</h2>
          <p className="small">Saisissez le code d’inscription dans l’installateur d’Itinéos chez le client. Code perdu ou expiré :</p>
          {code ? <EnrollKey value={code} /> : (
            <button type="button" style={{ marginTop: 8 }} onClick={async () => setCode((await api<{ enrollKey: string }>(`/installations/${id}/enroll-code`, { method: 'POST' })).enrollKey)}>Créer un nouveau code</button>
          )}
        </div>
      )}

      {!!data.problems.length && enrolled && (
        <div className="card" style={{ borderColor: data.health === 'down' ? 'var(--down)' : 'var(--warn)' }}>
          <h2>À regarder</h2>
          <ul style={{ margin: 0, paddingLeft: 18 }}>{data.problems.map((p) => <li key={p}>{p}</li>)}</ul>
        </div>
      )}

      {enrolled && (
        <div className="card">
          <div className="row spread"><h2>Dernières 24 heures</h2><span className="muted small">Dernières nouvelles : {ago(data.last_seen_at)}</span></div>
          <div className="timeline">{hours.map((x) => <span key={x.h.toISOString()} className={x.cls} title={`${x.h.getHours()} h${x.cls === 'down' ? (x.silent ? ' : aucune nouvelle' : ' : panne ou silence de plus de 5 min') : x.cls === 'warning' ? ' : à surveiller' : ''}`} />)}</div>
          <div className="row spread small muted" style={{ marginTop: 4 }}><span>il y a 24 h</span><span>maintenant</span></div>
          <dl className="kv" style={{ marginTop: 14 }}>
            <dt>Version</dt><dd>{data.version ?? '—'}{s.pendingUpdate ? ` (mise à jour ${s.pendingUpdate} programmée)` : ''}</dd>
            <dt>En marche depuis</dt><dd>{duration(s.uptimeSeconds)}</dd>
            <dt>Base de données</dt><dd>{s.database ? (s.database.ok ? `OK · ${bytes(s.database.sizeBytes)}` : `En panne : ${s.database.error ?? ''}`) : '—'}</dd>
            <dt>Disque</dt><dd>{s.disk ? `${bytes(s.disk.freeBytes)} libres sur ${bytes(s.disk.totalBytes)}` : '—'}</dd>
            <dt>Dernière sauvegarde</dt><dd>{s.lastBackupAt === null ? 'aucune' : s.lastBackupAt ? `${fmtDate(s.lastBackupAt)} (${ago(s.lastBackupAt)})` : '—'}</dd>
            <dt>Erreurs (1 h)</dt><dd>{s.errorsLastHour ?? 0}</dd>
            <dt>Activité aujourd’hui</dt><dd>{s.activity ? [
              plural(s.activity.users ?? 0, 'utilisateur actif', 'utilisateurs actifs'),
              plural(s.activity.interventionsToday ?? 0, 'intervention prévue', 'interventions prévues'),
              plural(s.activity.reportsSignedToday ?? 0, 'fiche signée', 'fiches signées'),
            ].join(' · ') : '—'}</dd>
            <dt>Mémoire du serveur</dt><dd>{bytes(s.memoryBytes)}</dd>
            <dt>Prise en main du PC</dt><dd>{s.remote?.available ? `RustDesk installé${s.remote.id ? ` (ID ${s.remote.id})` : ''}` : 'RustDesk non installé'}</dd>
            <dt>Fichiers du logiciel</dt><dd>{{
              ok: `Conformes à la version ${data.version ?? ''}`,
              modified: '⚠ Modifiés sur ce PC : différents de la version livrée',
              reference: 'Empreinte relevée (version non publiée sur la console : elle sert de référence)',
              unchecked: 'Non vérifiés (installation sans serveur compilé)',
            }[s.integrityVerdict ?? 'unchecked'] ?? '—'}{s.integrity?.files ? ` · ${s.integrity.files} fichiers` : ''}</dd>
          </dl>
        </div>
      )}

      {enrolled && <Actions data={data} send={send} busy={busy} />}

      {enrolled && (
        <div className="card table-wrap">
          <h2>Ordres envoyés</h2>
          {!data.commands.length && <p className="muted">Aucun ordre pour l’instant.</p>}
          {!!data.commands.length && (
            <table>
              <thead><tr><th>Quand</th><th>Ordre</th><th>État</th><th>Résultat</th></tr></thead>
              <tbody>
                {data.commands.map((c) => (
                  <tr key={c.id}>
                    <td>{fmtDate(c.created_at)}<div className="muted small">{c.created_by_name}</div></td>
                    <td>{KIND[c.kind] ?? c.kind}{c.kind === 'update' ? ` · ${data.releases.find((r) => r.id === c.payload.releaseId)?.version ?? ''} (${c.payload.when === 'now' ? 'tout de suite' : 'la nuit'})` : ''}</td>
                    <td>
                      <span className={`badge ${c.status === 'DONE' ? 'h-ok' : c.status === 'FAILED' ? 'h-down' : 'h-never'}`}>{STATUS[c.status]}</span>
                      {c.status === 'QUEUED' && <div><button type="button" className="small" style={{ marginTop: 4 }} onClick={async () => { await api(`/commands/${c.id}/cancel`, { method: 'POST' }); reload(); }}>Annuler</button></div>}
                    </td>
                    <td style={{ maxWidth: 520 }}><CommandResult c={c} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      <div className="card">
        <h2>Bugs</h2>
        <BugList bugs={data.bugs} onChange={reload} />
      </div>

      <Settings data={data} onSaved={reload} go={go} />
    </>
  );
}

function Actions({ data, send, busy }: { data: Detail; send: (kind: string, payload?: Record<string, unknown>, confirm?: string) => Promise<void>; busy: boolean }) {
  const [release, setRelease] = useState(data.releases[0]?.id ?? '');
  const [when, setWhen] = useState<'night' | 'now'>('night');
  const [reason, setReason] = useState('');
  const [hours, setHours] = useState(2);
  const [smtp, setSmtp] = useState('');
  const [from, setFrom] = useState('');
  const remote = data.last_status?.remote?.available;
  const submit = (fn: () => void) => (e: FormEvent) => { e.preventDefault(); fn(); };
  return (
    <fieldset className="actions" disabled={busy}>
      <div className="card">
        <h2>Prise en main du PC</h2>
        <p className="small muted">Ouvre une session RustDesk sur le PC serveur du client, avec un mot de passe à usage unique valable 1 heure.</p>
        <button type="button" className="primary" disabled={!remote} onClick={() => send('remote', { minutes: 60 }, 'Demander la prise en main du PC du client ? Le client voit la session RustDesk à l’écran.')}>Prendre la main</button>
        {!remote && <p className="small muted">RustDesk n’est pas installé sur ce PC (option de l’installateur).</p>}
      </div>
      <form className="card" onSubmit={submit(() => send('support', { hours, reason }))}>
        <h2>Accès support dans Itinéos</h2>
        <p className="small muted">L’administrateur du client voit la demande dans Itinéos et doit l’accepter. Un compte « Support » est alors ouvert pour la durée choisie, puis fermé.</p>
        <label>Raison (montrée au client)<input value={reason} onChange={(e) => setReason(e.target.value)} required minLength={3} placeholder="Ex. : vérifier le modèle de fiche signalé" /></label>
        <label>Durée<select value={hours} onChange={(e) => setHours(Number(e.target.value))}>{[1, 2, 4, 8].map((h) => <option key={h} value={h}>{h} h</option>)}</select></label>
        <button type="submit">Demander l’accès</button>
      </form>
      <form className="card" onSubmit={submit(() => send('update', { releaseId: release, when }, when === 'now' ? 'Installer la mise à jour tout de suite ? Itinéos sera coupé quelques minutes chez le client.' : undefined))}>
        <h2>Mise à jour</h2>
        {!data.releases.length ? <p className="small muted">Aucune version publiée pour le canal « {data.channel} » (voir Versions).</p> : (
          <>
            <label>Version<select value={release} onChange={(e) => setRelease(e.target.value)}>{data.releases.map((r) => <option key={r.id} value={r.id}>{r.version} · {r.channel}{r.version === data.version ? ' (installée)' : ''}</option>)}</select></label>
            <label>Quand<select value={when} onChange={(e) => setWhen(e.target.value as 'night' | 'now')}><option value="night">Cette nuit (entre 3 h et 5 h)</option><option value="now">Tout de suite</option></select></label>
            <p className="small muted">Sauvegarde d’abord ; retour automatique à la version actuelle si le logiciel ne redémarre pas.</p>
            <button type="submit">Programmer la mise à jour</button>
          </>
        )}
      </form>
      <div className="card">
        <h2>Maintenance</h2>
        <button type="button" onClick={() => send('logs', { lines: 300 })}>Récupérer les journaux</button>
        <button type="button" onClick={() => send('restart', {}, 'Redémarrer le serveur Itinéos du client ? Coupure de quelques secondes.')}>Redémarrer le serveur</button>
      </div>
      <form className="card" onSubmit={submit(() => send('settings', { env: { ...(smtp ? { SMTP_URL: smtp } : {}), ...(from ? { MAIL_FROM: from } : {}) } }))}>
        <h2>Envoi des e-mails</h2>
        <p className="small muted">Réglage du serveur d’envoi chez le client (le serveur Itinéos redémarre).</p>
        <label>SMTP_URL<input value={smtp} onChange={(e) => setSmtp(e.target.value)} placeholder="smtps://utilisateur:motdepasse@smtp.fournisseur.fr:465" /></label>
        <label>Expéditeur<input value={from} onChange={(e) => setFrom(e.target.value)} placeholder="Itinéos <no-reply@client.fr>" /></label>
        <button type="submit" disabled={!smtp && !from}>Envoyer le réglage</button>
      </form>
    </fieldset>
  );
}

function CommandResult({ c }: { c: Command }) {
  const r = c.result ?? {};
  if (c.status === 'SENT') {
    if (c.kind === 'support') return <span className="small">En attente de l’accord de l’administrateur du client…</span>;
    if (c.kind === 'update') return <span className="small">{r.phase === 'scheduled' ? `Programmée pour ${fmtDate(String(r.at))}` : 'Reçue, en préparation…'}</span>;
    return <span className="small muted">En cours…</span>;
  }
  if (c.status === 'CANCELLED') return r.message ? <span className="small muted">{String(r.message)}</span> : null;
  if (c.status !== 'DONE' && c.status !== 'FAILED') return null;
  if (r.error) return <span className="error small">{String(r.error)}</span>;
  if (c.kind === 'logs' && Array.isArray(r.files)) {
    return <details><summary className="small">{(r.files as unknown[]).length} fichier(s) de journal</summary>{(r.files as { name: string; text: string }[]).map((f) => <div key={f.name}><strong className="small">{f.name}</strong><pre>{f.text}</pre></div>)}</details>;
  }
  if ((c.kind === 'remote' || c.kind === 'support') && r.ended) {
    return <span className="small muted">{c.kind === 'remote' ? 'Session de prise en main terminée' : 'Accès support terminé'}{r.closedAt ? ` le ${fmtDate(String(r.closedAt))}` : ''} : mot de passe effacé.</span>;
  }
  if (c.kind === 'remote' && r.id) {
    const link = `rustdesk://connection/new/${r.id}?password=${encodeURIComponent(String(r.password))}`;
    const open = !!r.until && new Date(String(r.until)) > new Date();
    return (
      <div className="small">
        ID <strong>{String(r.id)}</strong> · mot de passe <strong>{String(r.password)}</strong> · valable jusqu’à {fmtDate(String(r.until))}
        {open && <div><a href={link}>Ouvrir dans RustDesk</a></div>}
      </div>
    );
  }
  if (c.kind === 'support') {
    if (r.decision === 'REFUSED') return <span className="small">Refusé par {String(r.by ?? 'le client')}.</span>;
    if (r.decision === 'APPROVED') {
      return (
        <div className="small">
          Accepté par {String(r.by)} · jusqu’à {fmtDate(String(r.until))}<br />
          Compte <strong>{String(r.email)}</strong> · mot de passe <strong>{String(r.password)}</strong>
          {r.url ? <div><a href={String(r.url)} target="_blank" rel="noreferrer">{String(r.url)}</a></div> : <div className="muted">Sans adresse internet : connexion via la prise en main du PC (http://localhost).</div>}
        </div>
      );
    }
    return <span className="small">{String(r.decision ?? '')}</span>;
  }
  if (c.kind === 'update') return <span className="small">{c.status === 'DONE' ? `Version ${String(r.version)} installée.` : `Échec : ${String(r.message ?? '')}${r.rolledBack ? ' — retour à la version précédente fait.' : ''}`}</span>;
  if (c.kind === 'restart') return <span className="small">Serveur redémarré.</span>;
  if (c.kind === 'settings') return <span className="small">Réglages appliqués : {(r.keys as string[] | undefined)?.join(', ')}</span>;
  return <span className="small muted">{JSON.stringify(r)}</span>;
}

function Settings({ data, onSaved, go: _go }: { data: Detail; onSaved: () => void; go: (to: string) => void }) {
  const [name, setName] = useState(data.name);
  const [channel, setChannel] = useState(data.channel);
  const [notes, setNotes] = useState(data.notes ?? '');
  const [code, setCode] = useState<string | null>(null);
  const save = async (e: FormEvent) => {
    e.preventDefault();
    await api(`/installations/${data.id}`, { method: 'PATCH', body: { name, channel, notes } });
    onSaved();
  };
  return (
    <form className="card form" onSubmit={save}>
      <h2>Fiche de l’installation</h2>
      <label>Nom<input value={name} onChange={(e) => setName(e.target.value)} /></label>
      <label>Canal des mises à jour<input value={channel} onChange={(e) => setChannel(e.target.value)} /></label>
      <label>Notes (modifications propres à ce client, accès, contacts…)<textarea rows={4} value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
      <div className="row">
        <button className="primary" type="submit">Enregistrer</button>
        {data.enrolled_at && !code && (
          <button type="button" className="danger" onClick={async () => {
            if (!window.confirm('Réinscrire ce PC (réinstallation, PC remplacé) ? L’agent actuel ne pourra plus se connecter.')) return;
            setCode((await api<{ enrollKey: string }>(`/installations/${data.id}/enroll-code`, { method: 'POST' })).enrollKey);
          }}>Réinscrire (nouveau code)</button>
        )}
      </div>
      {code && <EnrollKey value={code} />}
    </form>
  );
}
