/** Mon compte (double authentification, alertes), réglages de la console (serveur RustDesk), alertes envoyées */
import { useEffect, useState, type FormEvent } from 'react';
import { api, fmtDate, setToken } from './api';
import { useLoad } from './App';

export interface Me { id: string; email: string; name: string; totp_enabled: boolean; alerts: boolean; daily_summary: boolean; mfa: boolean }

/** QR code du secret (bibliothèque chargée seulement à l'affichage) */
function Qr({ text }: { text: string }) {
  const [svg, setSvg] = useState('');
  useEffect(() => {
    void import('@zxing/browser').then(({ BrowserQRCodeSvgWriter }) => setSvg(new BrowserQRCodeSvgWriter().write(text, 220, 220).outerHTML));
  }, [text]);
  // Le SVG vient de la bibliothèque, à partir du secret (aucun texte saisi par quelqu'un d'autre)
  return <div style={{ width: 220, height: 220, background: '#fff' }} dangerouslySetInnerHTML={{ __html: svg }} />;
}

export function AccountPage({ me, onChanged }: { me: Me; onChanged: () => void }) {
  const [setup, setSetup] = useState<{ secret: string; uri: string } | null>(null);
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const start = async () => setSetup(await api<{ secret: string; uri: string }>('/me/totp/setup', { method: 'POST' }));
  const enable = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const r = await api<{ token: string }>('/me/totp/enable', { method: 'POST', body: { code } });
      setToken(r.token);
      setSetup(null);
      setCode('');
      setMsg({ ok: true, text: 'Double authentification activée : elle sera demandée à chaque connexion.' });
      onChanged();
    } catch (err) { setMsg({ ok: false, text: (err as Error).message }); }
  };
  const disable = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api('/me/totp/disable', { method: 'POST', body: { code } });
      setCode('');
      setMsg({ ok: true, text: 'Double authentification retirée.' });
      onChanged();
    } catch (err) { setMsg({ ok: false, text: (err as Error).message }); }
  };
  const pref = async (key: 'alerts' | 'dailySummary', value: boolean) => {
    await api('/me', { method: 'PATCH', body: { [key]: value } });
    onChanged();
  };

  return (
    <>
      <h1>Mon compte</h1>
      <p className="muted">{me.name} · {me.email}</p>
      {msg && <p className={msg.ok ? '' : 'error'}>{msg.text}</p>}
      <div className="card form">
        <h2>Double authentification</h2>
        {me.totp_enabled ? (
          <>
            <p><span className="badge h-ok">Active</span> Un code de votre téléphone est demandé à chaque connexion.</p>
            {!me.mfa && <p className="small error">Cette session a été ouverte avant l’activation : reconnectez-vous pour les actions sensibles.</p>}
            <form className="row" onSubmit={disable}>
              <input inputMode="numeric" autoComplete="one-time-code" placeholder="Code à 6 chiffres" value={code} onChange={(e) => setCode(e.target.value)} required />
              <button type="submit" className="danger">Retirer</button>
            </form>
          </>
        ) : setup ? (
          <form className="form" onSubmit={enable}>
            <p className="small">1. Dans une application d’authentification (Google Authenticator, Microsoft Authenticator, 2FAS…), ajoutez un compte en scannant ce code :</p>
            <Qr text={setup.uri} />
            <p className="small muted">ou saisissez la clé : <code>{setup.secret.match(/.{1,4}/g)?.join(' ')}</code></p>
            <label>2. Code affiché par l’application<input inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value)} required /></label>
            <div><button className="primary" type="submit">Activer</button></div>
          </form>
        ) : (
          <>
            <p className="small">Sans elle, le mot de passe suffit pour entrer dans la console, qui peut agir chez tous vos clients. Les actions sensibles
              (prise en main, accès support, mises à jour, réglages, redémarrage, publication de versions) sont <strong>bloquées</strong> tant qu’elle n’est pas active.</p>
            <div><button className="primary" type="button" onClick={start}>Activer la double authentification</button></div>
          </>
        )}
      </div>
      <div className="card form">
        <h2>Alertes par e-mail</h2>
        <label style={{ flexDirection: 'row', alignItems: 'center', gap: 8, color: 'inherit' }}>
          <input type="checkbox" checked={me.alerts} onChange={(e) => pref('alerts', e.target.checked)} /> Pannes, retours en service, nouveaux bugs, mises à jour ratées
        </label>
        <label style={{ flexDirection: 'row', alignItems: 'center', gap: 8, color: 'inherit' }}>
          <input type="checkbox" checked={me.daily_summary} onChange={(e) => pref('dailySummary', e.target.checked)} /> Résumé chaque matin à 8 h
        </label>
      </div>
    </>
  );
}

export function SettingsPage({ mfa }: { mfa: boolean }) {
  const { data, reload } = useLoad<{ server: string; key: string } | null>('/settings/rustdesk');
  const [server, setServer] = useState('');
  const [key, setKey] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (data) { setServer(data.server); setKey(data.key); } }, [data]);
  const save = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api('/settings/rustdesk', { method: 'PUT', body: server ? { server, key } : null });
      setMsg({ ok: true, text: 'Enregistré : les installations l’appliquent à leur prochain passage.' });
      reload();
    } catch (err) { setMsg({ ok: false, text: (err as Error).message }); }
  };
  return (
    <>
      <h1>Réglages</h1>
      <form className="card form" onSubmit={save}>
        <h2>Serveur de prise en main (RustDesk)</h2>
        <p className="small">Sans serveur à vous, les sessions passent par les serveurs publics de RustDesk. Avec votre serveur (installé avec la console,
          voir <code>deploy/supervision</code>), elles passent par chez vous. Les installations reçoivent ce réglage automatiquement.</p>
        <label>Serveur (nom ou adresse, sans http://)<input value={server} onChange={(e) => setServer(e.target.value)} placeholder="supervision.mon-domaine.fr" /></label>
        <label>Clé publique du serveur (contenu de id_ed25519.pub)<input value={key} onChange={(e) => setKey(e.target.value)} placeholder="AbCd…=" /></label>
        {msg && <p className={msg.ok ? 'small' : 'error'}>{msg.text}</p>}
        <div className="row">
          <button className="primary" type="submit" disabled={!mfa}>Enregistrer</button>
          {!mfa && <span className="small muted">Double authentification nécessaire</span>}
        </div>
      </form>
    </>
  );
}

export function AlertsPage() {
  const { data, error } = useLoad<{ id: number; kind: string; subject: string; body: string; sent_to: string[]; error: string | null; at: string; installation_id: string | null }[]>('/alerts', 60_000);
  const [open, setOpen] = useState<number | null>(null);
  return (
    <>
      <h1>Alertes</h1>
      <p className="muted small">Ce qui a été envoyé par e-mail (ou aurait été envoyé, si l’envoi d’e-mails n’est pas réglé : SMTP_URL).</p>
      <div className="card table-wrap">
        {error && <p className="error">{error}</p>}
        {data && !data.length && <p className="muted">Aucune alerte pour l’instant.</p>}
        {!!data?.length && (
          <table>
            <thead><tr><th>Quand</th><th>Alerte</th><th>Envoyée à</th></tr></thead>
            <tbody>
              {data.map((a) => (
                <tr key={a.id} className="click" onClick={() => setOpen(open === a.id ? null : a.id)}>
                  <td>{fmtDate(a.at)}</td>
                  <td><strong>{a.subject}</strong>{open === a.id && <pre>{a.body}</pre>}</td>
                  <td className="small">{a.sent_to.join(', ') || '—'}{a.error && <div className="error">{a.error}</div>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
