﻿; Installateur Windows d'Itinéos (Inno Setup 6). Construit par installeur\construire.ps1, ne pas compiler à la main :
; le dossier sortie\fichiers (programme, Node.js, PostgreSQL, Caddy, WinSW) est préparé par ce script.

#define AppName "Itinéos"
#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif

[Setup]
AppId={{6F0E3B1A-5D0B-4C59-9E8C-1B7A2D3C4E51}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppName}
DefaultDirName={autopf}\Itineo
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=sortie
OutputBaseFilename=Itineos-Setup-{#AppVersion}
SetupIconFile=sortie\itineo.ico
; Licence d'utilisation : à accepter pour installer
LicenseFile=LICENCE.txt
UninstallDisplayIcon={app}\installation\itineo.ico
UninstallDisplayName={#AppName}
Compression=lzma2/max
SolidCompression=yes
LZMAUseSeparateProcess=yes
WizardStyle=modern
CloseApplications=no

[Languages]
Name: "fr"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "telemaintenance"; Description: "Autoriser le support à prendre la main sur ce PC à distance (RustDesk, sur demande du support, mot de passe à usage unique)"

[Files]
Source: "sortie\fichiers\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "sortie\itineo.ico"; DestDir: "{app}\installation"; Flags: ignoreversion

[InstallDelete]
; Ancien nom du programme des postes et de ses raccourcis (avant Itinéos)
Type: files; Name: "{app}\poste\Itineo.exe"
Type: files; Name: "{autoprograms}\Itinéo.lnk"
Type: files; Name: "{autodesktop}\Itinéo.lnk"
Type: files; Name: "{autoprograms}\Itinéo – lisez-moi.lnk"
Type: files; Name: "{autoprograms}\Itinéo – sauvegarder maintenant.lnk"
; Anciens raccourcis vers le navigateur, remplacés par le programme Windows Itinéos
Type: files; Name: "{autoprograms}\Itinéo.url"
Type: files; Name: "{autodesktop}\Itinéo.url"

[Icons]
; Itinéos s'ouvre dans le programme Windows Itinéos (poste\ : sa fenêtre, ses menus, les notifications Windows)
Name: "{autoprograms}\Itinéos"; Filename: "{app}\poste\Itineos.exe"; AppUserModelID: "fr.itineo.poste"; Comment: "Itinéos"
Name: "{autodesktop}\Itinéos"; Filename: "{app}\poste\Itineos.exe"; AppUserModelID: "fr.itineo.poste"; Comment: "Itinéos"
Name: "{autoprograms}\Itinéos – lisez-moi"; Filename: "{app}\installation\LISEZ-MOI.txt"
Name: "{autoprograms}\Itinéos – sauvegarder maintenant"; Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\sauvegarder.ps1"""; IconFilename: "{sys}\shell32.dll"; IconIndex: 238

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\configurer.ps1"" -App ""{app}"" -Data ""{commonappdata}\Itineo"" -Reponses ""{tmp}\reponses.txt"""; StatusMsg: "Configuration d'Itinéos (base de données, services, pare-feu)…"; Flags: waituntilterminated
Filename: "{app}\poste\Itineos.exe"; Description: "Ouvrir Itinéos"; Flags: postinstall nowait skipifsilent runasoriginaluser

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\arreter.ps1"" -App ""{app}"" -Retirer"; RunOnceId: "RetirerServices"; Flags: runhidden waituntilterminated

[UninstallDelete]
Type: files; Name: "{autoprograms}\Itinéos.url"
Type: files; Name: "{autodesktop}\Itinéos.url"
Type: filesandordirs; Name: "{app}\runtime"
Type: filesandordirs; Name: "{app}\app"

[Messages]
fr.FinishedLabel=Itinéos est installé. Les données (base, fichiers, sauvegardes) sont dans C:\ProgramData\Itineo.%n%nPour les techniciens sur la route : voir « Itinéos – lisez-moi » dans le menu Démarrer.

[Code]
var
  AnswersPage: TInputQueryWizardPage;
  SupervisionPage: TInputQueryWizardPage;
  Upgrade: Boolean;

function InitializeSetup(): Boolean;
begin
  { Mise à jour : la base et le compte administrateur existent déjà, on ne repose pas les questions }
  Upgrade := FileExists(ExpandConstant('{commonappdata}\Itineo\base\PG_VERSION'));
  Result := True;
end;

procedure InitializeWizard();
begin
  AnswersPage := CreateInputQueryPage(wpSelectDir,
    'Votre entreprise', 'Premier compte et adresse du logiciel',
    'Le compte administrateur reçoit un mot de passe provisoire, affiché une seule fois à la fin de l''installation.' + #13#10 +
    'L''adresse internet est facultative : sans elle, Itinéos est utilisable sur le réseau du bureau seulement.');
  AnswersPage.Add('Nom de l''entreprise :', False);
  AnswersPage.Add('Prénom de l''administrateur :', False);
  AnswersPage.Add('Nom de l''administrateur :', False);
  AnswersPage.Add('E-mail de l''administrateur (sert d''identifiant) :', False);
  AnswersPage.Add('Adresse internet, ex. itineo.mon-entreprise.fr (facultatif) :', False);

  SupervisionPage := CreateInputQueryPage(AnswersPage.ID,
    'Suivi par l''éditeur', 'Supervision, mises à jour et support (facultatif)',
    'Si votre prestataire vous a donné un code d''inscription, Itinéos lui envoie son état (sans les données de vos clients), ' +
    'les erreurs rencontrées et reçoit les mises à jour. Laissez vide pour ne pas être suivi.');
  { Un seul champ : le code complet affiché par la console contient son adresse (https://console/ABCD-EFGH-JKLM) }
  SupervisionPage.Add('Code d''inscription complet, ex. https://supervision.editeur.fr/ABCD-EFGH-JKLM :', False);
end;

{ Sépare le code complet : tout ce qui précède le dernier « / » est l'adresse de la console }
procedure SplitEnrollKey(const Key: String; var Url, Code: String);
var
  I: Integer;
begin
  Url := '';
  Code := '';
  if Key = '' then Exit;
  I := Length(Key);
  while (I > 0) and (Key[I] <> '/') do I := I - 1;
  Code := Uppercase(Copy(Key, I + 1, Length(Key)));
  if I > 0 then Url := Copy(Key, 1, I - 1);
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := Upgrade and (PageID = AnswersPage.ID);
end;

function Clean(const S: String): String;
begin
  Result := Trim(S);
  StringChangeEx(Result, #13, ' ', True);
  StringChangeEx(Result, #10, ' ', True);
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Email, Domain, Url, Code: String;
  I: Integer;
begin
  Result := True;
  if CurPageID = SupervisionPage.ID then
  begin
    SplitEnrollKey(Clean(SupervisionPage.Values[0]), Url, Code);
    if (Code <> '') and ((Pos('http://', Lowercase(Url)) <> 1) and (Pos('https://', Lowercase(Url)) <> 1) or (Length(Code) < 8)) then
    begin
      MsgBox('Collez le code complet affiché par la console, adresse comprise, par exemple :' + #13#10 +
        'https://supervision.editeur.fr/ABCD-EFGH-JKLM' + #13#10#13#10 + 'Ou laissez le champ vide pour ne pas être suivi.', mbError, MB_OK);
      Result := False;
    end;
    Exit;
  end;
  if CurPageID <> AnswersPage.ID then Exit;
  for I := 0 to 3 do
    if Clean(AnswersPage.Values[I]) = '' then
    begin
      MsgBox('Merci de remplir l''entreprise, le prénom, le nom et l''e-mail.', mbError, MB_OK);
      Result := False;
      Exit;
    end;
  Email := Clean(AnswersPage.Values[3]);
  if (Pos('@', Email) < 2) or (Pos('.', Copy(Email, Pos('@', Email), Length(Email))) = 0) or (Pos(' ', Email) > 0) then
  begin
    MsgBox('L''adresse e-mail ne semble pas valide.', mbError, MB_OK);
    Result := False;
    Exit;
  end;
  Domain := Lowercase(Clean(AnswersPage.Values[4]));
  if (Domain <> '') and ((Pos('/', Domain) > 0) or (Pos(':', Domain) > 0) or (Pos(' ', Domain) > 0) or (Pos('.', Domain) = 0)) then
  begin
    MsgBox('Indiquez seulement le nom, sans https:// ni chemin, par exemple : itineo.mon-entreprise.fr', mbError, MB_OK);
    Result := False;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
  Stop: String;
begin
  Result := '';
  { Mise à jour : les services sont arrêtés avant de remplacer les fichiers }
  Stop := ExpandConstant('{app}\installation\arreter.ps1');
  if FileExists(Stop) then
    Exec('powershell.exe', '-NoProfile -ExecutionPolicy Bypass -File "' + Stop + '" -App "' + ExpandConstant('{app}') + '"', '', SW_HIDE, ewWaitUntilTerminated, Code);
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Lines: TArrayOfString;
  Url, Code: String;
begin
  { Écrit avant la copie des fichiers : la configuration, lancée ensuite par [Run], lit ces réponses }
  if CurStep <> ssInstall then Exit;
  SetArrayLength(Lines, 9);
  Lines[0] := 'edition=TECH';
  SplitEnrollKey(Clean(SupervisionPage.Values[0]), Url, Code);
  Lines[6] := 'supervision=' + Url;
  Lines[7] := 'code=' + Code;
  if WizardIsTaskSelected('telemaintenance') then Lines[8] := 'telemaintenance=1' else Lines[8] := 'telemaintenance=0';
  if not Upgrade then
  begin
    Lines[1] := 'societe=' + Clean(AnswersPage.Values[0]);
    Lines[2] := 'prenom=' + Clean(AnswersPage.Values[1]);
    Lines[3] := 'nom=' + Clean(AnswersPage.Values[2]);
    Lines[4] := 'email=' + Lowercase(Clean(AnswersPage.Values[3]));
    Lines[5] := 'domaine=' + Lowercase(Clean(AnswersPage.Values[4]));
  end;
  SaveStringsToUTF8File(ExpandConstant('{tmp}\reponses.txt'), Lines, False);
end;
