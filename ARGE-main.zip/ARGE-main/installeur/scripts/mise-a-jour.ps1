﻿<#
  Mise à jour d'Itinéos, lancée par l'agent de supervision (tâche planifiée « Itinéo – mise à jour », en SYSTEM).
  Le paquet a déjà été vérifié par l'agent (signature de la console et empreinte).

    1. sauvegarde de la base ;
    2. arrêt du serveur et de l'appli ;
    3. remplacement du programme (app, web, scripts) ; l'ancien est gardé à côté ;
    4. redémarrage : le serveur met la base à jour tout seul ;
    5. s'il ne répond pas dans les 3 minutes : retour à l'ancien programme ET à la base sauvegardée.

  Le résultat est écrit dans mises-a-jour\mise-a-jour-resultat.json, lu par l'agent à son démarrage suivant.
#>
param(
  [string]$App = 'C:\Program Files\Itineo',
  [string]$Data = (Join-Path $env:ProgramData 'Itineo')
)
$ErrorActionPreference = 'Stop'
$dir = Join-Path $Data 'mises-a-jour'
$log = Join-Path $Data 'journaux\mises-a-jour.log'
function Log([string]$text) { Add-Content -LiteralPath $log -Encoding UTF8 -Value "$(Get-Date -Format s)  $text" }
function Result([bool]$ok, [string]$message, [bool]$rolledBack = $false) {
  $r = [ordered]@{ commandId = $job.commandId; ok = $ok; version = $job.version; message = $message; rolledBack = $rolledBack }
  [IO.File]::WriteAllText((Join-Path $dir 'mise-a-jour-resultat.json'), ($r | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))
}
function Healthy([string]$expected) {
  for ($i = 0; $i -lt 90; $i++) {
    try {
      $res = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:3000/api/health' -TimeoutSec 3
      if ($res.StatusCode -eq 200) { return $true }
    } catch { }
    Start-Sleep -Seconds 2
  }
  return $false
}
# Ancien format (code source) : lien vers packages\shared ; le serveur compilé n'en a plus besoin
function Junction {
  $shared = Join-Path $App 'app\node_modules\@itineo\shared'
  if (-not (Test-Path $shared) -and (Test-Path (Join-Path $App 'app\packages\shared'))) {
    New-Item -ItemType Directory -Force (Split-Path $shared) | Out-Null
    New-Item -ItemType Junction -Path $shared -Target (Join-Path $App 'app\packages\shared') | Out-Null
  }
}
function Swap([string]$from, [string]$to) {
  # Les liens (junctions) se retirent avec rmdir : Remove-Item effacerait aussi le dossier pointé
  foreach ($d in 'app', 'web', 'installation') {
    $src = Join-Path $App "$d.$from"
    $dst = Join-Path $App $d
    if (Test-Path $dst) {
      $link = Join-Path $dst 'node_modules\@itineo\shared'
      if (Test-Path $link) { cmd /c rmdir "$link" | Out-Null }
      Rename-Item $dst "$d.$to"
    }
    if (Test-Path $src) { Rename-Item $src $d }
  }
}

$jobFile = Join-Path $dir 'mise-a-jour.json'
if (-not (Test-Path $jobFile)) { exit 0 }
$job = Get-Content -LiteralPath $jobFile -Raw -Encoding UTF8 | ConvertFrom-Json
Remove-Item $jobFile -Force
Log "Mise à jour vers $($job.version)"

$cfg = @{}
foreach ($line in Get-Content -LiteralPath (Join-Path $Data 'services\itineo.env') -Encoding UTF8) {
  $i = $line.IndexOf('=')
  if ($i -gt 0) { $cfg[$line.Substring(0, $i)] = $line.Substring($i + 1) }
}
$pg = Join-Path $App 'runtime\pgsql\bin'

try {
  # 1. Sauvegarde de la base, juste avant
  $dump = Join-Path $Data "sauvegardes\itineo-base-avant-$($job.version)-$(Get-Date -Format 'yyyy-MM-dd_HHmm').dump"
  & "$pg\pg_dump.exe" --format=custom --file=$dump --dbname=$($cfg.DATABASE_URL)
  if ($LASTEXITCODE -ne 0) { throw 'Sauvegarde impossible : mise à jour annulée' }

  # 2. Le paquet est décompressé à côté, avant tout arrêt
  $new = Join-Path $App 'maj'
  if (Test-Path $new) { Remove-Item $new -Recurse -Force }
  # Zip intégré à .NET : le module Archive de PowerShell ne se charge pas toujours (tâche planifiée, Windows allégés)
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [IO.Compression.ZipFile]::ExtractToDirectory($job.zip, $new)
  foreach ($d in 'app', 'web', 'installation') {
    if (-not (Test-Path (Join-Path $new $d))) { throw "Paquet incomplet : dossier $d absent" }
  }
  foreach ($d in 'app', 'web', 'installation') {
    $old = Join-Path $App "$d.ancien"
    if (Test-Path $old) { Remove-Item $old -Recurse -Force }
    Move-Item (Join-Path $new $d) (Join-Path $App "$d.nouveau")
  }
  Remove-Item $new -Recurse -Force
} catch {
  Log "ÉCHEC avant l'arrêt : $($_.Exception.Message)"
  Result $false $_.Exception.Message
  exit 1
}

# 3. Arrêt, remplacement, redémarrage
Stop-Service ItineoWeb, ItineoServeur -Force
Swap 'nouveau' 'ancien'
Junction
Copy-Item (Join-Path $App 'installation\mise-a-jour.ps1') (Join-Path $Data 'services\mise-a-jour.ps1') -Force
Start-Service ItineoServeur
Start-Service ItineoWeb

if (Healthy $job.version) {
  foreach ($d in 'app', 'web', 'installation') {
    $old = Join-Path $App "$d.ancien"
    if (Test-Path $old) {
      $link = Join-Path $old 'node_modules\@itineo\shared'
      if (Test-Path $link) { cmd /c rmdir "$link" | Out-Null }
      Remove-Item $old -Recurse -Force
    }
  }
  Remove-Item $job.zip -Force -ErrorAction SilentlyContinue
  Log "Version $($job.version) installée"
  Result $true "Version $($job.version) installée"
  exit 0
}

# 5. Échec : ancien programme et base d'avant la mise à jour
Log "ÉCHEC : le serveur ne répond pas après la mise à jour, retour en arrière"
Stop-Service ItineoWeb, ItineoServeur -Force
foreach ($d in 'app', 'web', 'installation') {
  $bad = Join-Path $App $d
  if (Test-Path $bad) {
    $link = Join-Path $bad 'node_modules\@itineo\shared'
    if (Test-Path $link) { cmd /c rmdir "$link" | Out-Null }
    Remove-Item $bad -Recurse -Force
  }
  Rename-Item (Join-Path $App "$d.ancien") $d
}
Junction
& "$pg\pg_restore.exe" --clean --if-exists --no-owner --dbname=$($cfg.DATABASE_URL) $dump
Start-Service ItineoServeur
Start-Service ItineoWeb
$back = Healthy ''
Log "Retour en arrière terminé (serveur $(if ($back) { 'reparti' } else { 'TOUJOURS ARRÊTÉ' }))"
Result $false 'Le serveur ne répondait pas avec la nouvelle version' $true
exit 1
