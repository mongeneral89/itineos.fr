﻿<#
  Sauvegarde d'Itinéos : la base de données et les fichiers (PDF des fiches, photos, pièces jointes, logos),
  dans Data\sauvegardes. Lancée chaque nuit à 2 h par la tâche planifiée « Itinéo – sauvegarde » ; peut aussi
  être lancée à la main (clic droit → Exécuter avec PowerShell, en administrateur).
  Les sauvegardes de plus de 14 jours sont supprimées : COPIEZ-LES AUSSI AILLEURS (disque externe, cloud).

  Restaurer : voir LISEZ-MOI.txt dans le dossier du programme.
#>
param(
  [string]$App = (Split-Path -Parent $PSScriptRoot),
  [string]$Data = (Join-Path $env:ProgramData 'Itineo'),
  [int]$KeepDays = 14
)
$ErrorActionPreference = 'Stop'
$dest = Join-Path $Data 'sauvegardes'
$log = Join-Path $Data 'journaux\sauvegardes.log'
$stamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
function Log([string]$text) { Add-Content -LiteralPath $log -Encoding UTF8 -Value "$(Get-Date -Format s)  $text" }

try {
  $cfg = @{}
  foreach ($line in Get-Content -LiteralPath (Join-Path $Data 'services\itineo.env') -Encoding UTF8) {
    $i = $line.IndexOf('=')
    if ($i -gt 0) { $cfg[$line.Substring(0, $i)] = $line.Substring($i + 1) }
  }
  New-Item -ItemType Directory -Force $dest | Out-Null
  $dump = Join-Path $dest "itineo-base-$stamp.dump"
  # Messages de pg_dump gardés pour le journal (la tâche tourne sans fenêtre)
  $ErrorActionPreference = 'Continue'
  $out = & (Join-Path $App 'runtime\pgsql\bin\pg_dump.exe') --format=custom --file=$dump --dbname=$($cfg.DATABASE_URL) 2>&1 | ForEach-Object { "$_" }
  $code = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  if ($code -ne 0) { throw "pg_dump a échoué : $($out -join ' ')" }
  $files = Join-Path $Data 'fichiers'
  if (Test-Path $files) {
    # Zip intégré à .NET : le module Archive de PowerShell ne se charge pas toujours (tâche planifiée, Windows allégés)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = Join-Path $dest "itineo-fichiers-$stamp.zip"
    if (Test-Path $zip) { Remove-Item $zip -Force }
    [IO.Compression.ZipFile]::CreateFromDirectory($files, $zip)
  }
  Get-ChildItem $dest -File | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$KeepDays) } | Remove-Item -Force
  Log "sauvegarde $stamp terminée"
} catch {
  Log "ÉCHEC de la sauvegarde $stamp : $($_.Exception.Message)"
  throw
}
