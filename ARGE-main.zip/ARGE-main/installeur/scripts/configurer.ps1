﻿<#
  Configuration d'Itinéos sur le PC du client, lancée par l'installateur (en administrateur), à la fin de la copie
  des fichiers. Relancée par une mise à jour : ce qui existe déjà (base, compte administrateur, secrets) est gardé.

    -App     dossier du programme (C:\Program Files\Itineo)
    -Data    dossier des données (C:\ProgramData\Itineo) : base, fichiers, sauvegardes, journaux, réglages
    -Reponses  fichier des réponses de l'assistant (société, administrateur, adresse internet, supervision)
    -Silencieux  sans fenêtre ni attente : reconfiguration lancée à distance (tâche « Itinéo – reconfigurer »)

  Services Windows créés (démarrage automatique, redémarrage en cas d'arrêt) :
    ItineoBase     la base de données PostgreSQL (127.0.0.1:5544, jamais ouverte au réseau)
    ItineoServeur  le serveur Itinéos (127.0.0.1:3000, joint seulement par Caddy)
    ItineoWeb      Caddy : l'appli sur le port 80 (et 443 en https avec une adresse internet)
#>
param(
  [Parameter(Mandatory = $true)] [string]$App,
  [Parameter(Mandatory = $true)] [string]$Data,
  [string]$Reponses,
  [switch]$Silencieux
)
$ErrorActionPreference = 'Stop'
if (-not $Silencieux) { $Host.UI.RawUI.WindowTitle = 'Itinéos – configuration' }
function Say([string]$text, [string]$color = 'Gray') { if (-not $Silencieux) { Write-Host $text -ForegroundColor $color } }
function Journal([string]$text) {
  try {
    New-Item -ItemType Directory -Force (Join-Path $Data 'journaux') | Out-Null
    Add-Content -LiteralPath (Join-Path $Data 'journaux\configuration.log') -Value "$(Get-Date -Format s)  $text" -Encoding UTF8
  } catch {}
}
function Step([string]$text) { Say "  • $text"; Journal $text }
# Une erreur ne doit pas fermer la fenêtre sans rien dire : message, trace dans le journal, puis attente
trap {
  Journal "ÉCHEC : $($_.Exception.Message) $($_.InvocationInfo.PositionMessage)"
  if (-not $Silencieux) {
    Write-Host ''
    Write-Host "  ÉCHEC : $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Détails : $(Join-Path $Data 'journaux\configuration.log')" -ForegroundColor Red
    Read-Host '  Appuyez sur Entrée pour fermer'
  }
  exit 1
}

# Réponses de l'assistant (clé=valeur, UTF-8) ; aucune en reconfiguration
$r = @{}
if ($Reponses -and (Test-Path -LiteralPath $Reponses)) {
  foreach ($line in Get-Content -LiteralPath $Reponses -Encoding UTF8) {
    $i = $line.IndexOf('=')
    if ($i -gt 0) { $r[$line.Substring(0, $i)] = $line.Substring($i + 1).Trim() }
  }
  Remove-Item -LiteralPath $Reponses -Force
}

$node = Join-Path $App 'runtime\node\node.exe'
$pgBin = Join-Path $App 'runtime\pgsql\bin'
$api = Join-Path $App 'app\apps\api'
$services = Join-Path $Data 'services'
$base = Join-Path $Data 'base'
$journaux = Join-Path $Data 'journaux'
$secrets = Join-Path $services 'itineo.env'
$PgPort = 5544

Say ''
Say '  Itinéos : configuration' 'Cyan'
Say '  ─────────────────────────────────────────'


# ─── Dossiers et droits : seuls le système et les administrateurs lisent les données ───
Step 'Dossier des données'
foreach ($d in @($Data, $services, $journaux, (Join-Path $Data 'fichiers'), (Join-Path $Data 'sauvegardes'), (Join-Path $Data 'caddy'))) {
  New-Item -ItemType Directory -Force $d | Out-Null
}
# SID plutôt que noms (Windows en français : « Administrateurs ») : Système, Administrateurs
icacls $Data /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null

# ─── Secrets : créés une seule fois, gardés pour les mises à jour ───
function NewSecret([int]$bytes) {
  $b = New-Object byte[] $bytes
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
  return [Convert]::ToBase64String($b).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}
$cfg = @{}
if (Test-Path $secrets) {
  foreach ($line in Get-Content -LiteralPath $secrets -Encoding UTF8) {
    $i = $line.IndexOf('=')
    if ($i -gt 0) { $cfg[$line.Substring(0, $i)] = $line.Substring($i + 1) }
  }
}
if (-not $cfg.PG_SUPER_PASSWORD) { $cfg.PG_SUPER_PASSWORD = NewSecret 24 }
if (-not $cfg.PG_PASSWORD) { $cfg.PG_PASSWORD = NewSecret 24 }
if (-not $cfg.JWT_SECRET) { $cfg.JWT_SECRET = NewSecret 48 }
# Adresse internet : gardée d'une installation à l'autre, sauf si l'assistant en donne une nouvelle
if ($r.domaine) { $cfg.DOMAIN = $r.domaine.ToLower() }
# Console de supervision de l'éditeur (facultatif) et prise en main à distance du PC (RustDesk)
if ($r.supervision) { $cfg.SUPERVISION_URL = $r.supervision.TrimEnd('/') }
if ($r.code) { $cfg.SUPERVISION_CODE = $r.code.ToUpper() }
if ($r.ContainsKey('telemaintenance')) { $cfg.REMOTE = $r.telemaintenance }
$domain = $cfg.DOMAIN
$cfg.WEB_ORIGIN = if ($domain) { "https://$domain" } else { "http://$($env:COMPUTERNAME.ToLower())" }
$cfg.DATABASE_URL = "postgres://itineo:$($cfg.PG_PASSWORD)@127.0.0.1:$PgPort/itineo"
($cfg.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) | Set-Content -LiteralPath $secrets -Encoding UTF8

# ─── Bibliothèques Visual C++ (PostgreSQL ne démarre pas sans elles ; absentes d'un Windows neuf) ───
$vcDlls = 'vcruntime140.dll', 'vcruntime140_1.dll', 'msvcp140.dll' | ForEach-Object { Join-Path "$env:SystemRoot\System32" $_ }
if ($vcDlls | Where-Object { -not (Test-Path $_) }) {
  Step 'Bibliothèques Microsoft Visual C++'
  $vc = Start-Process (Join-Path $App 'runtime\vcredist\vc_redist.x64.exe') -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru
  # 1638 : une version plus récente est déjà là ; 3010 : installé, redémarrage conseillé
  if ($vc.ExitCode -notin 0, 1638, 3010) { throw "Les bibliothèques Visual C++ n'ont pas pu être installées (code $($vc.ExitCode))." }
}


# Nom affiché, description et redémarrage automatique d'un service (sans sc.exe, absent de certains Windows allégés)
function ConfigureService([string]$id, [string]$name, [string]$description) {
  Set-Service -Name $id -DisplayName $name -Description $description
  # SERVICE_FAILURE_ACTIONS : remise à zéro après 1 jour ; redémarrer après 5 s, 30 s, puis 60 s
  $actions = [byte[]]@()
  foreach ($v in 86400, 0, 0, 3, 0x14, 1, 5000, 1, 30000, 1, 60000) { $actions += [BitConverter]::GetBytes([uint32]$v) }
  Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$id" -Name FailureActions -Value $actions -Type Binary
}

# ─── Base de données ───
$env:PGPASSWORD = $cfg.PG_SUPER_PASSWORD
$firstInstall = -not (Test-Path (Join-Path $base 'PG_VERSION'))
if ($firstInstall) {
  Step 'Création de la base de données'
  # Sans PG_VERSION, le dossier ne contient pas de base valide (essai précédent interrompu) : on repart de zéro
  if (Test-Path $base) { Remove-Item $base -Recurse -Force }
  New-Item -ItemType Directory -Force $base | Out-Null
  # Le service tourne sous le compte « Service réseau » : il doit pouvoir écrire dans la base
  icacls $base /grant '*S-1-5-20:(OI)(CI)F' | Out-Null
  # initdb se relance avec des droits réduits (sans le groupe Administrateurs) : l'utilisateur qui installe reçoit
  # un accès à la base le temps de la créer, retiré juste après ; le mot de passe passe par son dossier temporaire
  $me = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  icacls $base /grant "*${me}:(OI)(CI)F" | Out-Null
  $pwfile = Join-Path $env:TEMP "pg-init-$([guid]::NewGuid()).tmp"
  [IO.File]::WriteAllText($pwfile, $cfg.PG_SUPER_PASSWORD)
  $ErrorActionPreference = 'Continue'
  & "$pgBin\initdb.exe" -D $base -U postgres --pwfile=$pwfile -E UTF8 --locale=C --auth=scram-sha-256 2>&1 | ForEach-Object { "$_" } | Out-File (Join-Path $journaux 'initdb.log') -Encoding UTF8
  $initdbCode = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  Remove-Item $pwfile -Force
  icacls $base /remove "*$me" /T /Q | Out-Null
  if ($initdbCode -ne 0) { throw "La base de données n'a pas pu être créée (voir $journaux\initdb.log)." }
  # Joignable seulement depuis ce PC, sur un port à part (pas de conflit avec un autre PostgreSQL)
  Add-Content -LiteralPath (Join-Path $base 'postgresql.conf') -Encoding UTF8 -Value @(
    '', '# Itinéos', "listen_addresses = '127.0.0.1'", "port = $PgPort", "log_destination = 'stderr'", 'logging_collector = on',
    "log_directory = '$($journaux.Replace('\', '/'))'", "log_filename = 'base-%a.log'", 'log_truncate_on_rotation = on'
  )
}
# Le service tourne sous le compte « Service réseau » : il doit pouvoir écrire dans la base et les journaux
icacls $base /grant '*S-1-5-20:(OI)(CI)F' | Out-Null
icacls $journaux /grant '*S-1-5-20:(OI)(CI)M' | Out-Null

if (-not (Get-Service ItineoBase -ErrorAction SilentlyContinue)) {
  Step 'Service de la base de données'
  & "$pgBin\pg_ctl.exe" register -N ItineoBase -U 'NT AUTHORITY\NetworkService' -D $base -S auto -w | Out-Null
  ConfigureService ItineoBase 'Itinéos – base de données' 'Itinéos : base de données (PostgreSQL)'
}
Start-Service ItineoBase
for ($i = 0; $i -lt 60; $i++) {
  & "$pgBin\pg_isready.exe" -h 127.0.0.1 -p $PgPort -U postgres -q
  if ($LASTEXITCODE -eq 0) { break }
  Start-Sleep -Seconds 1
}
if ($firstInstall) {
  $pw = $cfg.PG_PASSWORD
  & "$pgBin\psql.exe" -h 127.0.0.1 -p $PgPort -U postgres -d postgres -v ON_ERROR_STOP=1 -q -c "CREATE ROLE itineo LOGIN PASSWORD '$pw'" | Out-Null
  & "$pgBin\psql.exe" -h 127.0.0.1 -p $PgPort -U postgres -d postgres -v ON_ERROR_STOP=1 -q -c "CREATE DATABASE itineo OWNER itineo ENCODING 'UTF8' TEMPLATE template0" | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'La base « itineo » n''a pas pu être créée.' }
}
Remove-Item Env:PGPASSWORD

# ─── Variables du serveur Itinéos ───
$apiEnv = [ordered]@{
  NODE_ENV = 'production'
  EDITION = $(if ($r.edition) { $r.edition } else { 'TECH' })
  DATABASE_URL = $cfg.DATABASE_URL
  JWT_SECRET = $cfg.JWT_SECRET
  HOST = '127.0.0.1'
  PORT = '3000'
  WEB_ORIGIN = $cfg.WEB_ORIGIN
  TRUST_PROXY = 'true'
  STORAGE_DIR = (Join-Path $Data 'fichiers')
}
# Envoi des e-mails : à ajouter plus tard dans itineo.env (SMTP_URL, MAIL_FROM), puis redémarrer ItineoServeur
foreach ($k in 'SMTP_URL', 'MAIL_FROM') { if ($cfg[$k]) { $apiEnv[$k] = $cfg[$k] } }
# Agent de supervision : état, bugs, mises à jour, réglages et prise en main à distance (voir services/supervision.ts)
$updates = Join-Path $Data 'mises-a-jour'
New-Item -ItemType Directory -Force $updates | Out-Null
$apiEnv.LOG_DIR = $journaux
$apiEnv.BACKUP_DIR = (Join-Path $Data 'sauvegardes')
$apiEnv.UPDATE_DIR = $updates
$apiEnv.ITINEO_ENV_FILE = $secrets
$apiEnv.SUPERVISION_STATE = (Join-Path $services 'supervision.json')
if ($cfg.SUPERVISION_URL) {
  $apiEnv.SUPERVISION_URL = $cfg.SUPERVISION_URL
  if ($cfg.SUPERVISION_CODE) { $apiEnv.SUPERVISION_CODE = $cfg.SUPERVISION_CODE }
}

# ─── Prise en main à distance du PC (RustDesk), si le client l'a acceptée à l'installation ───
$rustdesk = 'C:\Program Files\RustDesk\rustdesk.exe'
if ($cfg.REMOTE -eq '1') {
  if (-not (Test-Path $rustdesk)) {
    Step 'Prise en main à distance (RustDesk)'
    $msi = Get-ChildItem (Join-Path $App 'runtime\rustdesk') -Filter '*.msi' | Select-Object -First 1
    if ($msi) { Start-Process msiexec.exe -ArgumentList '/i', "`"$($msi.FullName)`"", '/qn', '/norestart' -Wait }
  }
  # Mot de passe permanent inconnu de tous : la console en pose un temporaire à chaque prise en main
  if (Test-Path $rustdesk) {
    & $rustdesk --password (NewSecret 24) | Out-Null
    $apiEnv.RUSTDESK_PATH = $rustdesk
  }
}

# ─── Compte administrateur (première installation seulement) ───
$password = $null
if ($firstInstall) {
  Step 'Compte administrateur'
  foreach ($k in $apiEnv.Keys) { Set-Item "Env:$k" $apiEnv[$k] }
  Push-Location $api
  # node écrit en UTF-8 : sans cela, les accents du journal deviennent illisibles
  [Console]::OutputEncoding = [Text.Encoding]::UTF8
  $out = & $node dist/create-admin.mjs --email $r.email --first $r.prenom --last $r.nom --group $r.societe 2>&1 | Out-String
  Pop-Location
  $out | Out-File (Join-Path $journaux 'premier-compte.log') -Encoding UTF8
  $m = [regex]::Match($out, 'Mot de passe provisoire\s*:\s*(\S+)')
  if (-not $m.Success) { throw "Le compte administrateur n'a pas pu être créé :`n$out" }
  $password = $m.Groups[1].Value
  # Le journal ne garde pas le mot de passe
  (Get-Content (Join-Path $journaux 'premier-compte.log')) -replace [regex]::Escape($password), '********' | Set-Content (Join-Path $journaux 'premier-compte.log') -Encoding UTF8
}

# ─── Services Windows du serveur et de l'appli (WinSW) ───
function XmlText([string]$s) { return [Security.SecurityElement]::Escape($s) }
function InstallService([string]$id, [string]$name, [string]$description, [string]$exe, [string]$arguments, [string]$workdir, $envVars, [string[]]$depends) {
  $wrapper = Join-Path $services "$id.exe"
  Copy-Item (Join-Path $App 'runtime\winsw\WinSW-x64.exe') $wrapper -Force
  $envXml = ($envVars.GetEnumerator() | ForEach-Object { "  <env name=`"$($_.Key)`" value=`"$(XmlText $_.Value)`" />" }) -join "`r`n"
  $depXml = ($depends | ForEach-Object { "  <depend>$_</depend>" }) -join "`r`n"
  $xml = @"
<service>
  <id>$id</id>
  <name>$(XmlText $name)</name>
  <description>$(XmlText $description)</description>
  <executable>$(XmlText $exe)</executable>
  <arguments>$(XmlText $arguments)</arguments>
  <workingdirectory>$(XmlText $workdir)</workingdirectory>
  <startmode>Automatic</startmode>
  <delayedAutoStart>true</delayedAutoStart>
$depXml
  <onfailure action="restart" delay="10 sec" />
  <onfailure action="restart" delay="30 sec" />
  <resetfailure>1 hour</resetfailure>
  <logpath>$(XmlText $journaux)</logpath>
  <log mode="roll-by-size"><sizeThreshold>10240</sizeThreshold><keepFiles>5</keepFiles></log>
$envXml
</service>
"@
  Set-Content -LiteralPath (Join-Path $services "$id.xml") -Value $xml -Encoding UTF8
  if (Get-Service $id -ErrorAction SilentlyContinue) {
    & $wrapper stop | Out-Null
    & $wrapper uninstall | Out-Null
  }
  & $wrapper install | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "Le service $id n'a pas pu être installé." }
}

Step 'Service du serveur Itinéos'
InstallService 'ItineoServeur' 'Itinéos – serveur' 'Itinéos : serveur (interventions, fiches, PDF, e-mails)' $node 'dist/index.mjs' $api $apiEnv @('ItineoBase')

Step 'Service de l''appli (Caddy)'
$web = (Join-Path $App 'web').Replace('\', '/')
$site = if ($domain) { $domain } else { ':80' }
$hsts = if ($domain) { "		Strict-Transport-Security `"max-age=31536000; includeSubDomains`"`r`n" } else { '' }
$caddyfile = @"
# Créé par l'installateur d'Itinéos (relancer l'installation pour le refaire)
{
	admin off
}

$site {
	encode zstd gzip
	header {
$hsts		X-Content-Type-Options "nosniff"
		X-Frame-Options "DENY"
		Referrer-Policy "strict-origin-when-cross-origin"
		Permissions-Policy "camera=(self), microphone=(self), geolocation=(self)"
		Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob: https://tile.openstreetmap.org https://*.tile.openstreetmap.org; media-src 'self' data: blob:; connect-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com; worker-src 'self'; manifest-src 'self'; object-src 'self' blob:; frame-src 'self' blob:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
		-Server
	}
	handle /api/* {
		request_body {
			max_size 15MB
		}
		reverse_proxy 127.0.0.1:3000
	}
	handle {
		root * "$web"
		@assets path /assets/*
		header @assets Cache-Control "public, max-age=31536000, immutable"
		@other not path /assets/*
		header @other Cache-Control "no-cache"
		try_files {path} /index.html
		file_server
	}
}
"@
$caddyConfig = Join-Path $services 'Caddyfile'
Set-Content -LiteralPath $caddyConfig -Value $caddyfile -Encoding UTF8
$caddyEnv = [ordered]@{ XDG_DATA_HOME = (Join-Path $Data 'caddy'); XDG_CONFIG_HOME = (Join-Path $Data 'caddy') }
InstallService 'ItineoWeb' 'Itinéos – appli web' 'Itinéos : appli web et https (Caddy)' (Join-Path $App 'runtime\caddy\caddy.exe') "run --config `"$caddyConfig`" --adapter caddyfile" $services $caddyEnv @('ItineoServeur')

# ─── Pare-feu : l'appli seulement (80, et 443 pour le https) ───
Step 'Pare-feu Windows'
Remove-NetFirewallRule -DisplayName "Itinéos (appli web)" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Itinéos (appli web)" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80,443 | Out-Null

# ─── Sauvegarde quotidienne à 2 h (base et fichiers, 14 jours gardés) ───
Step 'Sauvegarde quotidienne'
$backup = Join-Path $App 'installation\sauvegarder.ps1'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$backup`" -App `"$App`" -Data `"$Data`""
$trigger = New-ScheduledTaskTrigger -Daily -At 2am
$principal = New-ScheduledTaskPrincipal -UserId 'S-1-5-18' -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2)
Register-ScheduledTask -TaskName 'Itinéo – sauvegarde' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null

# ─── Tâches lancées par l'agent de supervision (hors du service, qu'elles arrêtent et redémarrent) ───
# Le script de mise à jour est copié dans les données : il remplace le dossier du programme pendant qu'il tourne
Copy-Item (Join-Path $App 'installation\mise-a-jour.ps1') (Join-Path $services 'mise-a-jour.ps1') -Force
$onDemand = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 1)
$updateAction = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $services 'mise-a-jour.ps1')`" -App `"$App`" -Data `"$Data`""
Register-ScheduledTask -TaskName 'Itinéo – mise à jour' -Action $updateAction -Principal $principal -Settings $onDemand -Force | Out-Null
$reconfAction = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $App 'installation\configurer.ps1')`" -App `"$App`" -Data `"$Data`" -Silencieux"
Register-ScheduledTask -TaskName 'Itinéo – reconfigurer' -Action $reconfAction -Principal $principal -Settings $onDemand -Force | Out-Null

# ─── Démarrage ───
Step 'Démarrage'
Start-Service ItineoServeur
Start-Service ItineoWeb
$ok = $false
for ($i = 0; $i -lt 90; $i++) {
  try {
    $res = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:3000/api/health' -TimeoutSec 2
    if ($res.StatusCode -eq 200) { $ok = $true; break }
  } catch { Start-Sleep -Seconds 1 }
}
# Première sauvegarde tout de suite : sinon la console affiche « aucune sauvegarde » jusqu'à la nuit
if ($ok -and $firstInstall) { Start-ScheduledTask -TaskName 'Itinéo – sauvegarde' }

Say ''
if ($ok) { Say '  Itinéos est installé et démarré.' 'Green' } else { Say "  Le serveur met du temps à démarrer : voir les journaux dans $journaux" 'Yellow' }
Say ''
Say "  Sur ce PC                 : http://localhost"
Say "  Depuis le réseau du bureau : http://$($env:COMPUTERNAME.ToLower())"
if ($domain) { Say "  Depuis internet           : https://$domain   (la box doit rediriger les ports 80 et 443 vers ce PC)" }
if ($password) {
  Say ''
  Say '  Compte administrateur' 'Cyan'
  Say "    E-mail                  : $($r.email)"
  Say "    Mot de passe provisoire : $password" 'Yellow'
  Say ''
  Say '  Notez-le : il ne sera plus affiché. Changez-le à la première connexion (« Mon compte »),' 'Yellow'
  Say '  puis créez la société et ses agences dans « Organisation ».' 'Yellow'
}
Say ''
Say "  Données, sauvegardes et journaux : $Data"
Say ''
if (-not $Silencieux) { Read-Host '  Appuyez sur Entrée pour terminer' }
