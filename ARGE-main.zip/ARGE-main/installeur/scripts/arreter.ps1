﻿<#
  Arrête les services d'Itinéos (avant une mise à jour ou une désinstallation).
  -Retirer : les retire aussi de Windows (désinstallation), avec la règle du pare-feu et la sauvegarde planifiée.
  Les données (Data : base, fichiers, sauvegardes) ne sont jamais effacées.
#>
param(
  [string]$App = (Split-Path -Parent $PSScriptRoot),
  [string]$Data = (Join-Path $env:ProgramData 'Itineo'),
  [switch]$Retirer
)
$ErrorActionPreference = 'Continue'
$services = Join-Path $Data 'services'
foreach ($id in 'ItineoWeb', 'ItineoServeur') {
  $wrapper = Join-Path $services "$id.exe"
  if (Get-Service $id -ErrorAction SilentlyContinue) {
    Stop-Service $id -Force -ErrorAction SilentlyContinue
    if ($Retirer -and (Test-Path $wrapper)) { & $wrapper uninstall | Out-Null }
  }
}
if (Get-Service ItineoBase -ErrorAction SilentlyContinue) {
  Stop-Service ItineoBase -Force -ErrorAction SilentlyContinue
  if ($Retirer) { & (Join-Path $App 'runtime\pgsql\bin\pg_ctl.exe') unregister -N ItineoBase | Out-Null }
}
if ($Retirer) {
  Remove-NetFirewallRule -DisplayName "Itinéos (appli web)" -ErrorAction SilentlyContinue
  foreach ($task in 'Itinéo – sauvegarde', 'Itinéo – mise à jour', 'Itinéo – reconfigurer') {
    Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
  }
}
