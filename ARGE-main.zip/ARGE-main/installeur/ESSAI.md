# Essayer l'installateur sur une machine de test (avant un vrai client)

Ce qui n'a pas pu être vérifié sur le PC de développement : les services Windows, le pare-feu, les tâches planifiées,
la mise à jour réelle avec retour en arrière, et la prise en main RustDesk. À faire une fois sur une machine vierge.

## La machine

Au choix : un vieux PC remis à zéro, une machine virtuelle (Hyper-V, inclus dans Windows 10/11 Pro ; VirtualBox) avec
Windows 10 ou 11, ou **Windows Sandbox** (Windows Pro : « Activer ou désactiver des fonctionnalités Windows » →
« Bac à sable Windows » ; tout est effacé à la fermeture, pratique pour recommencer).

**Le plus simple** : `installeur\essai\lancer-essai.ps1` ouvre le bac à sable avec les deux installateurs et ce guide sur
le Bureau ; « Collecter les résultats » rapatrie journaux et état des services dans `installeur\essai\resultats`.
La console et Itinéos s’installent dans le même bac à sable : le code complet de la console suffit.

## 1. Installation

- [ ] Copier `installeur\sortie\Itineos-Setup-<version>.exe` sur la machine, le lancer (« Exécuter quand même »).
- [ ] Remplir l'entreprise et l'administrateur ; adresse internet vide.
- [ ] Page « Suivi par l'éditeur » : coller le code complet créé dans la console (Clients → Nouvelle installation, bouton
      « Copier » ; il contient l'adresse de la console). Cocher la prise en main à distance.
- [ ] La fenêtre de configuration affiche « installé et démarré » et le mot de passe provisoire.
- [ ] `services.msc` : « Itinéos – base de données », « Itinéos – serveur », « Itinéos – appli web » en cours d'exécution.
- [ ] http://localhost s'ouvre, connexion, changement du mot de passe, création de la société.
- [ ] Depuis un autre PC du réseau : `http://NOM-DE-LA-MACHINE`.

## 2. Console

- [ ] L'installation apparaît « En service » en moins de 2 minutes, avec RustDesk installé.
- [ ] Récupérer les journaux ; redémarrer le serveur (il revient seul).
- [ ] Accès support : la demande apparaît dans Itinéos, l'accepter, se connecter avec le compte reçu, puis le fermer.
- [ ] Prendre la main : la session RustDesk s'ouvre avec le mot de passe affiché ; une heure plus tard, il ne marche plus.
- [ ] « Signaler un problème » dans Itinéos : le bug arrive dans la console (et l'alerte par e-mail si SMTP est réglé).
- [ ] Arrêter le service « Itinéos – serveur » 6 minutes : l'installation passe « En panne » et l'alerte part ; la relancer.

## 3. Mise à jour

- [ ] Changer la version dans `package.json` (ex. 0.1.1), puis
      `installeur\construire.ps1 -Paquet -Publier http://localhost:4000` (code de double authentification demandé).
- [ ] Console → Mise à jour → cette version, « Tout de suite » : Itinéos est coupé quelques minutes puis revient en 0.1.1 ;
      `C:\ProgramData\Itineo\journaux\mises-a-jour.log` le raconte.
- [ ] Retour en arrière : publier un paquet volontairement cassé (ex. supprimer `app\apps\api\src\index.ts` du zip),
      le lancer : l'échec est signalé dans la console (« retour à la version précédente fait ») et Itinéos marche toujours.

## 4. Désinstallation

- [ ] Paramètres → Applications → Itinéos → Désinstaller : services, pare-feu et tâches retirés ; `C:\ProgramData\Itineo` gardé.
- [ ] Réinstaller : les données, le compte et l'inscription à la console sont retrouvés.
