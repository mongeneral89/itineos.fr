/**
 * Empreinte de référence d'une version, calculée sur les fichiers prêts à installer (même calcul que l'agent,
 * voir apps/api/src/services/integrity.ts), écrite dans <dossier>/empreinte.txt :
 *   npx tsx installeur/empreinte.mts installeur\sortie\fichiers
 * Elle part avec le paquet de mise à jour : la console la garde et la compare à celle envoyée par chaque installation.
 */
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { computeFingerprint, integrityRoots } from '../apps/api/src/services/integrity.js';

const stage = path.resolve(process.argv[2] ?? '');
const { fingerprint, files } = await computeFingerprint(integrityRoots(path.join(stage, 'app', 'apps', 'api'), path.join(stage, 'web')));
writeFileSync(path.join(stage, 'empreinte.txt'), fingerprint);
console.log(`  Empreinte de référence : ${fingerprint.slice(0, 16)}… (${files} fichiers)`);
