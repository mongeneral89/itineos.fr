﻿<#
  Construit l'installateur Windows de la console de supervision :
  installeur\supervision\sortie\Itineos-Supervision-Setup-<version>.exe

    powershell -ExecutionPolicy Bypass -File installeur\supervision\construire.ps1

  Mêmes programmes intégrés que l'installateur d'Itinéos (Node.js, PostgreSQL, Caddy, WinSW), téléchargés par
  installeur\telecharger.mjs. Il faut Inno Setup 6.
#>
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$installeur = Split-Path -Parent $here
$root = Split-Path -Parent $installeur
$dl = Join-Path $installeur 'telechargements'
$out = Join-Path $here 'sortie'
$stage = Join-Path $out 'fichiers'
function Say([string]$text) { Write-Host "  $text" -ForegroundColor Cyan }
function Check([string]$what) { if ($LASTEXITCODE -ne 0) { throw "$what a échoué" } }
# Le tar de Windows (celui de Git Bash ne lit pas les chemins C:\…)
$tar = "$env:SystemRoot\System32\tar.exe"

$version = (Get-Content (Join-Path $root 'apps\supervision\package.json') -Raw | ConvertFrom-Json).version
$iscc = @("$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") |
  Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6 introuvable : winget install JRSoftware.InnoSetup' }

Say "Itinéos Supervision $version"
node (Join-Path $installeur 'telecharger.mjs'); Check 'Le téléchargement'
$v = @{}
(Get-Content (Join-Path $installeur 'telecharger.mjs') -Raw | Select-String "(\w+): '([^']+)'" -AllMatches).Matches | ForEach-Object { $v[$_.Groups[1].Value] = $_.Groups[2].Value }

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force $stage | Out-Null
$tmp = Join-Path $out 'extraction'
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Force $tmp | Out-Null

Say 'Node.js, PostgreSQL, Caddy, WinSW'
& $tar -xf (Join-Path $dl "node-v$($v.node)-win-x64.zip") -C $tmp "node-v$($v.node)-win-x64/node.exe"; Check 'Extraction de Node.js'
New-Item -ItemType Directory -Force "$stage\runtime\node", "$stage\runtime\pgsql", "$stage\runtime\caddy", "$stage\runtime\winsw" | Out-Null
Move-Item "$tmp\node-v$($v.node)-win-x64\node.exe" "$stage\runtime\node\node.exe"
& $tar -xf (Join-Path $dl "postgresql-$($v.postgres)-windows-x64-binaries.zip") -C $tmp pgsql/bin pgsql/lib pgsql/share; Check 'Extraction de PostgreSQL'
foreach ($d in 'bin', 'lib', 'share') { Move-Item "$tmp\pgsql\$d" "$stage\runtime\pgsql\$d" }
Get-ChildItem "$stage\runtime\pgsql\bin" -Filter 'pgAdmin*' | Remove-Item -Recurse -Force
Get-ChildItem "$stage\runtime\pgsql\lib" -Include '*.lib', '*.a' -Recurse | Remove-Item -Force
& $tar -xf (Join-Path $dl "caddy_$($v.caddy)_windows_amd64.zip") -C "$stage\runtime\caddy" caddy.exe; Check 'Extraction de Caddy'
Copy-Item (Join-Path $dl 'WinSW-x64.exe') "$stage\runtime\winsw\WinSW-x64.exe"
# Bibliothèques Visual C++ pour PostgreSQL (installées par configurer.ps1 si elles manquent)
$vcRedist = Join-Path $dl 'vc_redist.x64.exe'
$sig = Get-AuthenticodeSignature $vcRedist
if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') { throw 'vc_redist.x64.exe : signature Microsoft absente ou invalide' }
New-Item -ItemType Directory -Force "$stage\runtime\vcredist" | Out-Null
Copy-Item $vcRedist "$stage\runtime\vcredist\"

# ─── La console : sources, dépendances, interface construite (jamais de données ni de clé du développement) ───
Say 'Console'
$app = "$stage\app"
New-Item -ItemType Directory -Force "$app\apps\supervision", "$app\apps\api", "$app\apps\web", "$app\packages\shared" | Out-Null
Copy-Item "$root\package.json", "$root\package-lock.json" $app
foreach ($p in 'apps\api', 'apps\web', 'packages\shared') { Copy-Item "$root\$p\package.json" "$app\$p\" }
Copy-Item "$root\apps\supervision\package.json", "$root\apps\supervision\tsconfig.json" "$app\apps\supervision\"
foreach ($d in 'src', 'migrations', 'web') { Copy-Item "$root\apps\supervision\$d" "$app\apps\supervision\$d" -Recurse }
Get-ChildItem $app -Recurse -Force -Filter '.env*' | Remove-Item -Force
Push-Location $app
npm ci -w @itineo/supervision --no-audit --no-fund --loglevel=error; Check 'npm ci'
npm run build -w @itineo/supervision --silent; Check 'La construction de l''interface'
Pop-Location
# Liens des espaces de travail : inutiles ici (rmdir retire le lien seul, sans toucher au dossier pointé)
if (Test-Path "$app\node_modules\@itineo") {
  Get-ChildItem "$app\node_modules\@itineo" -Force | ForEach-Object { cmd /c rmdir "$($_.FullName)" }
  Remove-Item "$app\node_modules\@itineo" -Force
}
foreach ($p in 'apps\api', 'apps\web', 'packages') { Remove-Item "$app\$p" -Recurse -Force }
Remove-Item "$app\apps\supervision\web" -Recurse -Force

New-Item -ItemType Directory -Force "$stage\installation" | Out-Null
Copy-Item "$here\scripts\*" "$stage\installation\"

# ─── Icône : fond bleu nuit, ligne de pouls ───
Add-Type -AssemblyName System.Drawing
$size = 256
$bmp = New-Object System.Drawing.Bitmap $size, $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = 'AntiAlias'
$g.Clear([System.Drawing.Color]::Transparent)
$rect = New-Object System.Drawing.Drawing2D.GraphicsPath
$r = 56; $rect.AddArc(0, 0, $r, $r, 180, 90); $rect.AddArc($size - $r, 0, $r, $r, 270, 90)
$rect.AddArc($size - $r, $size - $r, $r, $r, 0, 90); $rect.AddArc(0, $size - $r, $r, $r, 90, 90); $rect.CloseFigure()
$g.FillPath((New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#111827'))), $rect)
$pen = New-Object System.Drawing.Pen ([System.Drawing.ColorTranslator]::FromHtml('#3B82F6')), 18
$pen.LineJoin = 'Round'; $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
$pts = [System.Drawing.PointF[]]@((New-Object System.Drawing.PointF 40, 140), (New-Object System.Drawing.PointF 92, 140), (New-Object System.Drawing.PointF 116, 84),
  (New-Object System.Drawing.PointF 146, 184), (New-Object System.Drawing.PointF 170, 128), (New-Object System.Drawing.PointF 216, 128))
$g.DrawLines($pen, $pts); $g.Dispose()
$ms = New-Object System.IO.MemoryStream
$bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $png = $ms.ToArray(); $bmp.Dispose()
$ico = New-Object System.IO.MemoryStream
$w = New-Object System.IO.BinaryWriter $ico
$w.Write([UInt16]0); $w.Write([UInt16]1); $w.Write([UInt16]1)
$w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0)
$w.Write([UInt16]1); $w.Write([UInt16]32); $w.Write([UInt32]$png.Length); $w.Write([UInt32]22); $w.Write($png)
[IO.File]::WriteAllBytes((Join-Path $out 'supervision.ico'), $ico.ToArray())
Remove-Item $tmp -Recurse -Force

Say 'Installateur (compression : quelques minutes)'
& $iscc /Q "/DAppVersion=$version" (Join-Path $here 'supervision.iss'); Check 'Inno Setup'
$exe = Join-Path $out "Itineos-Supervision-Setup-$version.exe"
Say "Terminé : $exe ($([math]::Round((Get-Item $exe).Length / 1MB)) Mo)"
