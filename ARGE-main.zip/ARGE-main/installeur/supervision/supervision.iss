﻿; Installateur Windows de la console de supervision (Inno Setup 6). Construit par installeur\supervision\construire.ps1.

#define AppName "Itinéos Supervision"
#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif

[Setup]
AppId={{9B3C2E77-4A1D-4E0B-8F6A-2C5D7E9A1B34}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher=Itinéos
DefaultDirName={autopf}\Itineo Supervision
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=sortie
OutputBaseFilename=Itineos-Supervision-Setup-{#AppVersion}
SetupIconFile=sortie\supervision.ico
UninstallDisplayIcon={app}\installation\supervision.ico
UninstallDisplayName={#AppName}
Compression=lzma2/max
SolidCompression=yes
LZMAUseSeparateProcess=yes
WizardStyle=modern
CloseApplications=no

[Languages]
Name: "fr"; MessagesFile: "compiler:Languages\French.isl"

[Files]
Source: "sortie\fichiers\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "sortie\supervision.ico"; DestDir: "{app}\installation"; Flags: ignoreversion

[InstallDelete]
; Anciens raccourcis vers le navigateur, remplacés par la fenêtre d'application
Type: files; Name: "{autoprograms}\Itinéos Supervision.url"; Check: HasEdge
Type: files; Name: "{autodesktop}\Itinéos Supervision.url"; Check: HasEdge
; Raccourcis de l'ancien nom (avant Itinéos)
Type: files; Name: "{autoprograms}\Itinéo Supervision.url"
Type: files; Name: "{autodesktop}\Itinéo Supervision.url"
Type: files; Name: "{autoprograms}\Itinéo Supervision.lnk"
Type: files; Name: "{autodesktop}\Itinéo Supervision.lnk"
Type: files; Name: "{autoprograms}\Itinéo Supervision – lisez-moi.lnk"
Type: files; Name: "{autoprograms}\Itinéo Supervision – créer la clé de secours.lnk"
Type: files; Name: "{autoprograms}\Itinéo Supervision – sauvegarder la clé principale.lnk"
Type: files; Name: "{autoprograms}\Itinéo Supervision – sauvegarder maintenant.lnk"

[INI]
; Sans Edge (rare) : raccourcis vers le navigateur par défaut
Filename: "{autoprograms}\Itinéos Supervision.url"; Section: "InternetShortcut"; Key: "URL"; String: "http://localhost:4000"; Check: not HasEdge
Filename: "{autoprograms}\Itinéos Supervision.url"; Section: "InternetShortcut"; Key: "IconFile"; String: "{app}\installation\supervision.ico"; Check: not HasEdge
Filename: "{autoprograms}\Itinéos Supervision.url"; Section: "InternetShortcut"; Key: "IconIndex"; String: "0"; Check: not HasEdge
Filename: "{autodesktop}\Itinéos Supervision.url"; Section: "InternetShortcut"; Key: "URL"; String: "http://localhost:4000"; Check: not HasEdge
Filename: "{autodesktop}\Itinéos Supervision.url"; Section: "InternetShortcut"; Key: "IconFile"; String: "{app}\installation\supervision.ico"; Check: not HasEdge
Filename: "{autodesktop}\Itinéos Supervision.url"; Section: "InternetShortcut"; Key: "IconIndex"; String: "0"; Check: not HasEdge

[Icons]
; La console s'ouvre dans sa propre fenêtre, comme un logiciel (Edge en mode application)
Name: "{autoprograms}\Itinéos Supervision"; Filename: "{code:EdgePath}"; Parameters: "--app=http://localhost:4000"; IconFilename: "{app}\installation\supervision.ico"; Comment: "Itinéos Supervision"; Check: HasEdge
Name: "{autodesktop}\Itinéos Supervision"; Filename: "{code:EdgePath}"; Parameters: "--app=http://localhost:4000"; IconFilename: "{app}\installation\supervision.ico"; Comment: "Itinéos Supervision"; Check: HasEdge
Name: "{autoprograms}\Itinéos Supervision – lisez-moi"; Filename: "{app}\installation\LISEZ-MOI.txt"
Name: "{autoprograms}\Itinéos Supervision – créer la clé de secours"; Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\cles.ps1"" -Action secours"; IconFilename: "{sys}\shell32.dll"; IconIndex: 47
Name: "{autoprograms}\Itinéos Supervision – sauvegarder la clé principale"; Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\cles.ps1"" -Action sauvegarde"; IconFilename: "{sys}\shell32.dll"; IconIndex: 47
Name: "{autoprograms}\Itinéos Supervision – sauvegarder maintenant"; Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\sauvegarder.ps1"""; IconFilename: "{sys}\shell32.dll"; IconIndex: 238

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\configurer.ps1"" -App ""{app}"" -Data ""{commonappdata}\ItineoSupervision"" -Reponses ""{tmp}\reponses.txt"""; StatusMsg: "Configuration de la console (base de données, services, pare-feu)…"; Flags: waituntilterminated
Filename: "{code:EdgePath}"; Parameters: "--app=http://localhost:4000"; Description: "Ouvrir la console"; Flags: postinstall nowait skipifsilent runasoriginaluser; Check: HasEdge
Filename: "http://localhost:4000"; Description: "Ouvrir la console"; Flags: shellexec postinstall nowait skipifsilent runasoriginaluser; Check: not HasEdge

[UninstallRun]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installation\arreter.ps1"" -App ""{app}"" -Retirer"; RunOnceId: "RetirerServices"; Flags: runhidden waituntilterminated

[UninstallDelete]
Type: files; Name: "{autoprograms}\Itinéos Supervision.url"
Type: files; Name: "{autodesktop}\Itinéos Supervision.url"
Type: filesandordirs; Name: "{app}\runtime"
Type: filesandordirs; Name: "{app}\app"

[Messages]
fr.FinishedLabel=Itinéos Supervision est installé. Les données (base, clé de signature, sauvegardes) sont dans C:\ProgramData\ItineoSupervision.%n%nÀ faire tout de suite : double authentification (Mon compte) et clé de secours (menu Démarrer).

[Code]
var
  AnswersPage: TInputQueryWizardPage;
  Upgrade: Boolean;

function InitializeSetup(): Boolean;
begin
  Upgrade := FileExists(ExpandConstant('{commonappdata}\ItineoSupervision\base\PG_VERSION'));
  Result := True;
end;

procedure InitializeWizard();
begin
  AnswersPage := CreateInputQueryPage(wpSelectDir,
    'Votre compte', 'Premier compte de la console et adresse',
    'Un mot de passe provisoire est affiché une seule fois à la fin de l''installation.' + #13#10 +
    'L''adresse internet est facultative : sans elle, seules les installations de votre réseau joignent la console.');
  AnswersPage.Add('Votre nom :', False);
  AnswersPage.Add('Votre e-mail (identifiant de la console) :', False);
  AnswersPage.Add('Adresse internet, ex. supervision.mon-domaine.fr (facultatif) :', False);
end;

{ Edge en mode application : la console dans sa propre fenêtre }
function EdgePath(Param: String): String;
begin
  Result := ExpandConstant('{commonpf32}\Microsoft\Edge\Application\msedge.exe');
  if not FileExists(Result) then Result := ExpandConstant('{commonpf64}\Microsoft\Edge\Application\msedge.exe');
  if not FileExists(Result) then Result := '';
end;

function HasEdge(): Boolean;
begin
  Result := EdgePath('') <> '';
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := Upgrade and (PageID = AnswersPage.ID);
end;

function Clean(const S: String): String;
begin
  Result := Trim(S);
  StringChangeEx(Result, #13, ' ', True);
  StringChangeEx(Result, #10, ' ', True);
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Email, Domain: String;
begin
  Result := True;
  if CurPageID <> AnswersPage.ID then Exit;
  Email := Clean(AnswersPage.Values[1]);
  if (Clean(AnswersPage.Values[0]) = '') or (Pos('@', Email) < 2) or (Pos(' ', Email) > 0) then
  begin
    MsgBox('Indiquez votre nom et une adresse e-mail valide.', mbError, MB_OK);
    Result := False;
    Exit;
  end;
  Domain := Lowercase(Clean(AnswersPage.Values[2]));
  if (Domain <> '') and ((Pos('/', Domain) > 0) or (Pos(':', Domain) > 0) or (Pos(' ', Domain) > 0) or (Pos('.', Domain) = 0)) then
  begin
    MsgBox('Indiquez seulement le nom, sans https:// ni chemin, par exemple : supervision.mon-domaine.fr', mbError, MB_OK);
    Result := False;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
  Stop: String;
begin
  Result := '';
  Stop := ExpandConstant('{app}\installation\arreter.ps1');
  if FileExists(Stop) then
    Exec('powershell.exe', '-NoProfile -ExecutionPolicy Bypass -File "' + Stop + '" -App "' + ExpandConstant('{app}') + '"', '', SW_HIDE, ewWaitUntilTerminated, Code);
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Lines: TArrayOfString;
begin
  if CurStep <> ssInstall then Exit;
  SetArrayLength(Lines, 3);
  if not Upgrade then
  begin
    Lines[0] := 'nom=' + Clean(AnswersPage.Values[0]);
    Lines[1] := 'email=' + Lowercase(Clean(AnswersPage.Values[1]));
    Lines[2] := 'domaine=' + Lowercase(Clean(AnswersPage.Values[2]));
  end;
  SaveStringsToUTF8File(ExpandConstant('{tmp}\reponses.txt'), Lines, False);
end;
