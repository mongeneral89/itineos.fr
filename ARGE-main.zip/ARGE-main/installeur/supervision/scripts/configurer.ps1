﻿<#
  Configuration de la console de supervision sur ce PC, lancée par l'installateur (en administrateur).
  Relancée par une mise à jour : la base, le compte, les secrets et la clé de signature sont gardés.

    -App       dossier du programme (C:\Program Files\Itineo Supervision)
    -Data      dossier des données (C:\ProgramData\ItineoSupervision) : base, clé de signature, versions, sauvegardes
    -Reponses  réponses de l'assistant (votre compte, adresse internet facultative)
    -Silencieux  sans fenêtre ni attente

  Services Windows :
    ItineoSupervisionBase     base de données PostgreSQL (127.0.0.1:5545)
    ItineoSupervision         la console (port 4000)
    ItineoSupervisionWeb      https devant la console (Caddy, seulement avec une adresse internet)
#>
param(
  [Parameter(Mandatory = $true)] [string]$App,
  [Parameter(Mandatory = $true)] [string]$Data,
  [string]$Reponses,
  [switch]$Silencieux
)
$ErrorActionPreference = 'Stop'
if (-not $Silencieux) { $Host.UI.RawUI.WindowTitle = 'Itinéos Supervision – configuration' }
function Say([string]$text, [string]$color = 'Gray') { if (-not $Silencieux) { Write-Host $text -ForegroundColor $color } }
function Journal([string]$text) {
  try {
    New-Item -ItemType Directory -Force (Join-Path $Data 'journaux') | Out-Null
    Add-Content -LiteralPath (Join-Path $Data 'journaux\configuration.log') -Value "$(Get-Date -Format s)  $text" -Encoding UTF8
  } catch {}
}
function Step([string]$text) { Say "  • $text"; Journal $text }
# Une erreur ne doit pas fermer la fenêtre sans rien dire : message, trace dans le journal, puis attente
trap {
  Journal "ÉCHEC : $($_.Exception.Message) $($_.InvocationInfo.PositionMessage)"
  if (-not $Silencieux) {
    Write-Host ''
    Write-Host "  ÉCHEC : $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Détails : $(Join-Path $Data 'journaux\configuration.log')" -ForegroundColor Red
    Read-Host '  Appuyez sur Entrée pour fermer'
  }
  exit 1
}

$r = @{}
if ($Reponses -and (Test-Path -LiteralPath $Reponses)) {
  foreach ($line in Get-Content -LiteralPath $Reponses -Encoding UTF8) {
    $i = $line.IndexOf('=')
    if ($i -gt 0) { $r[$line.Substring(0, $i)] = $line.Substring($i + 1).Trim() }
  }
  Remove-Item -LiteralPath $Reponses -Force
}

$node = Join-Path $App 'runtime\node\node.exe'
$pgBin = Join-Path $App 'runtime\pgsql\bin'
$console = Join-Path $App 'app\apps\supervision'
$services = Join-Path $Data 'services'
$base = Join-Path $Data 'base'
$donnees = Join-Path $Data 'donnees'
$journaux = Join-Path $Data 'journaux'
$secrets = Join-Path $services 'supervision.env'
$PgPort = 5545

Say ''
Say '  Itinéos Supervision : configuration' 'Cyan'
Say '  ─────────────────────────────────────────'

# ─── Dossiers : seuls le système et les administrateurs lisent les données (la clé de signature y est) ───
Step 'Dossier des données'
foreach ($d in @($Data, $services, $journaux, $donnees, (Join-Path $Data 'sauvegardes'), (Join-Path $Data 'caddy'))) {
  New-Item -ItemType Directory -Force $d | Out-Null
}
icacls $Data /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null

function NewSecret([int]$bytes) {
  $b = New-Object byte[] $bytes
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
  return [Convert]::ToBase64String($b).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}
$cfg = @{}
if (Test-Path $secrets) {
  foreach ($line in Get-Content -LiteralPath $secrets -Encoding UTF8) {
    $i = $line.IndexOf('=')
    if ($i -gt 0) { $cfg[$line.Substring(0, $i)] = $line.Substring($i + 1) }
  }
}
if (-not $cfg.PG_SUPER_PASSWORD) { $cfg.PG_SUPER_PASSWORD = NewSecret 24 }
if (-not $cfg.PG_PASSWORD) { $cfg.PG_PASSWORD = NewSecret 24 }
if (-not $cfg.JWT_SECRET) { $cfg.JWT_SECRET = NewSecret 48 }
if ($r.domaine) { $cfg.DOMAIN = $r.domaine.ToLower() }
$domain = $cfg.DOMAIN
$cfg.DATABASE_URL = "postgres://supervision:$($cfg.PG_PASSWORD)@127.0.0.1:$PgPort/supervision"
($cfg.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) | Set-Content -LiteralPath $secrets -Encoding UTF8

# ─── Bibliothèques Visual C++ (PostgreSQL ne démarre pas sans elles ; absentes d'un Windows neuf) ───
$vcDlls = 'vcruntime140.dll', 'vcruntime140_1.dll', 'msvcp140.dll' | ForEach-Object { Join-Path "$env:SystemRoot\System32" $_ }
if ($vcDlls | Where-Object { -not (Test-Path $_) }) {
  Step 'Bibliothèques Microsoft Visual C++'
  $vc = Start-Process (Join-Path $App 'runtime\vcredist\vc_redist.x64.exe') -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru
  # 1638 : une version plus récente est déjà là ; 3010 : installé, redémarrage conseillé
  if ($vc.ExitCode -notin 0, 1638, 3010) { throw "Les bibliothèques Visual C++ n'ont pas pu être installées (code $($vc.ExitCode))." }
}


# Nom affiché, description et redémarrage automatique d'un service (sans sc.exe, absent de certains Windows allégés)
function ConfigureService([string]$id, [string]$name, [string]$description) {
  Set-Service -Name $id -DisplayName $name -Description $description
  # SERVICE_FAILURE_ACTIONS : remise à zéro après 1 jour ; redémarrer après 5 s, 30 s, puis 60 s
  $actions = [byte[]]@()
  foreach ($v in 86400, 0, 0, 3, 0x14, 1, 5000, 1, 30000, 1, 60000) { $actions += [BitConverter]::GetBytes([uint32]$v) }
  Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$id" -Name FailureActions -Value $actions -Type Binary
}

# ─── Base de données ───
$env:PGPASSWORD = $cfg.PG_SUPER_PASSWORD
$firstInstall = -not (Test-Path (Join-Path $base 'PG_VERSION'))
if ($firstInstall) {
  Step 'Création de la base de données'
  # Sans PG_VERSION, le dossier ne contient pas de base valide (essai précédent interrompu) : on repart de zéro
  if (Test-Path $base) { Remove-Item $base -Recurse -Force }
  New-Item -ItemType Directory -Force $base | Out-Null
  icacls $base /grant '*S-1-5-20:(OI)(CI)F' | Out-Null
  # initdb se relance avec des droits réduits (sans le groupe Administrateurs) : l'utilisateur qui installe reçoit
  # un accès à la base le temps de la créer, retiré juste après ; le mot de passe passe par son dossier temporaire
  $me = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  icacls $base /grant "*${me}:(OI)(CI)F" | Out-Null
  $pwfile = Join-Path $env:TEMP "pg-init-$([guid]::NewGuid()).tmp"
  [IO.File]::WriteAllText($pwfile, $cfg.PG_SUPER_PASSWORD)
  $ErrorActionPreference = 'Continue'
  & "$pgBin\initdb.exe" -D $base -U postgres --pwfile=$pwfile -E UTF8 --locale=C --auth=scram-sha-256 2>&1 | ForEach-Object { "$_" } | Out-File (Join-Path $journaux 'initdb.log') -Encoding UTF8
  $initdbCode = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  Remove-Item $pwfile -Force
  icacls $base /remove "*$me" /T /Q | Out-Null
  if ($initdbCode -ne 0) { throw "La base de données n'a pas pu être créée (voir $journaux\initdb.log)." }
  Add-Content -LiteralPath (Join-Path $base 'postgresql.conf') -Encoding UTF8 -Value @(
    '', '# Itinéos Supervision', "listen_addresses = '127.0.0.1'", "port = $PgPort", "log_destination = 'stderr'", 'logging_collector = on',
    "log_directory = '$($journaux.Replace('\', '/'))'", "log_filename = 'base-%a.log'", 'log_truncate_on_rotation = on'
  )
}
icacls $base /grant '*S-1-5-20:(OI)(CI)F' /T /Q | Out-Null
icacls $journaux /grant '*S-1-5-20:(OI)(CI)M' | Out-Null
if (-not (Get-Service ItineoSupervisionBase -ErrorAction SilentlyContinue)) {
  Step 'Service de la base de données'
  & "$pgBin\pg_ctl.exe" register -N ItineoSupervisionBase -U 'NT AUTHORITY\NetworkService' -D $base -S auto -w | Out-Null
  ConfigureService ItineoSupervisionBase 'Itinéos Supervision – base de données' 'Itinéos Supervision : base de données (PostgreSQL)'
}
Start-Service ItineoSupervisionBase
for ($i = 0; $i -lt 60; $i++) {
  & "$pgBin\pg_isready.exe" -h 127.0.0.1 -p $PgPort -U postgres -q
  if ($LASTEXITCODE -eq 0) { break }
  Start-Sleep -Seconds 1
}
if ($firstInstall) {
  & "$pgBin\psql.exe" -h 127.0.0.1 -p $PgPort -U postgres -d postgres -v ON_ERROR_STOP=1 -q -c "CREATE ROLE supervision LOGIN PASSWORD '$($cfg.PG_PASSWORD)'" | Out-Null
  & "$pgBin\psql.exe" -h 127.0.0.1 -p $PgPort -U postgres -d postgres -v ON_ERROR_STOP=1 -q -c "CREATE DATABASE supervision OWNER supervision ENCODING 'UTF8' TEMPLATE template0" | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'La base « supervision » n''a pas pu être créée.' }
}
Remove-Item Env:PGPASSWORD

# ─── Variables de la console ───
$consoleEnv = [ordered]@{
  NODE_ENV = 'production'
  DATABASE_URL = $cfg.DATABASE_URL
  JWT_SECRET = $cfg.JWT_SECRET
  PORT = '4000'
  # Avec une adresse internet, seul Caddy (https) joint la console ; sinon, les PC du réseau la joignent directement
  HOST = $(if ($domain) { '127.0.0.1' } else { '0.0.0.0' })
  TRUST_PROXY = $(if ($domain) { 'true' } else { 'false' })
  DATA_DIR = $donnees
  WEB_DIR = (Join-Path $console 'dist')
  CONSOLE_URL = $(if ($domain) { "https://$domain" } else { "http://$($env:COMPUTERNAME.ToLower()):4000" })
}
foreach ($k in 'SMTP_URL', 'MAIL_FROM') { if ($cfg[$k]) { $consoleEnv[$k] = $cfg[$k] } }

# ─── Votre compte (première installation) ───
$password = $null
if ($firstInstall -and $r.email) {
  Step 'Votre compte'
  foreach ($k in $consoleEnv.Keys) { Set-Item "Env:$k" $consoleEnv[$k] }
  Push-Location $console
  # node écrit en UTF-8 : sans cela, les accents du journal deviennent illisibles
  [Console]::OutputEncoding = [Text.Encoding]::UTF8
  $out = & $node --import tsx src/create-operator.ts --email $r.email --name $r.nom 2>&1 | Out-String
  Pop-Location
  $m = [regex]::Match($out, 'Mot de passe\s*:\s*(\S+)')
  if (-not $m.Success) { throw "Le compte n'a pas pu être créé :`n$out" }
  $password = $m.Groups[1].Value
}

# ─── Services Windows (WinSW) ───
function XmlText([string]$s) { return [Security.SecurityElement]::Escape($s) }
function InstallService([string]$id, [string]$name, [string]$description, [string]$exe, [string]$arguments, [string]$workdir, $envVars, [string[]]$depends) {
  $wrapper = Join-Path $services "$id.exe"
  Copy-Item (Join-Path $App 'runtime\winsw\WinSW-x64.exe') $wrapper -Force
  $envXml = ($envVars.GetEnumerator() | ForEach-Object { "  <env name=`"$($_.Key)`" value=`"$(XmlText $_.Value)`" />" }) -join "`r`n"
  $depXml = ($depends | ForEach-Object { "  <depend>$_</depend>" }) -join "`r`n"
  $xml = @"
<service>
  <id>$id</id>
  <name>$(XmlText $name)</name>
  <description>$(XmlText $description)</description>
  <executable>$(XmlText $exe)</executable>
  <arguments>$(XmlText $arguments)</arguments>
  <workingdirectory>$(XmlText $workdir)</workingdirectory>
  <startmode>Automatic</startmode>
  <delayedAutoStart>true</delayedAutoStart>
$depXml
  <onfailure action="restart" delay="10 sec" />
  <onfailure action="restart" delay="30 sec" />
  <resetfailure>1 hour</resetfailure>
  <logpath>$(XmlText $journaux)</logpath>
  <log mode="roll-by-size"><sizeThreshold>10240</sizeThreshold><keepFiles>5</keepFiles></log>
$envXml
</service>
"@
  Set-Content -LiteralPath (Join-Path $services "$id.xml") -Value $xml -Encoding UTF8
  if (Get-Service $id -ErrorAction SilentlyContinue) {
    & $wrapper stop | Out-Null
    & $wrapper uninstall | Out-Null
  }
  & $wrapper install | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "Le service $id n'a pas pu être installé." }
}

Step 'Service de la console'
InstallService 'ItineoSupervision' 'Itinéos Supervision' 'Console de supervision des installations d''Itinéos' $node '--import tsx src/index.ts' $console $consoleEnv @('ItineoSupervisionBase')

Remove-NetFirewallRule -DisplayName "Itinéos Supervision" -ErrorAction SilentlyContinue
if ($domain) {
  Step 'Adresse internet (https)'
  $caddyfile = @"
# Créé par l'installateur d'Itinéos Supervision
{
	admin off
}

$domain {
	encode zstd gzip
	header {
		Strict-Transport-Security "max-age=31536000; includeSubDomains"
		-Server
	}
	request_body {
		max_size 500MB
	}
	reverse_proxy 127.0.0.1:4000
}
"@
  $caddyConfig = Join-Path $services 'Caddyfile'
  Set-Content -LiteralPath $caddyConfig -Value $caddyfile -Encoding UTF8
  $caddyEnv = [ordered]@{ XDG_DATA_HOME = (Join-Path $Data 'caddy'); XDG_CONFIG_HOME = (Join-Path $Data 'caddy') }
  InstallService 'ItineoSupervisionWeb' 'Itinéos Supervision – https' 'Itinéos Supervision : https (Caddy)' (Join-Path $App 'runtime\caddy\caddy.exe') "run --config `"$caddyConfig`" --adapter caddyfile" $services $caddyEnv @('ItineoSupervision')
  New-NetFirewallRule -DisplayName "Itinéos Supervision" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80,443 | Out-Null
} else {
  # Sans adresse internet : les Itinéos du même réseau (bureau, essais) joignent la console sur le port 4000
  New-NetFirewallRule -DisplayName "Itinéos Supervision" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 4000 -Profile Private,Domain | Out-Null
}

# ─── Sauvegarde quotidienne à 2 h 30 ───
Step 'Sauvegarde quotidienne'
$principal = New-ScheduledTaskPrincipal -UserId 'S-1-5-18' -LogonType ServiceAccount -RunLevel Highest
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $App 'installation\sauvegarder.ps1')`" -App `"$App`" -Data `"$Data`""
Register-ScheduledTask -TaskName 'Itinéo Supervision – sauvegarde' -Action $action -Trigger (New-ScheduledTaskTrigger -Daily -At '2:30am') -Principal $principal `
  -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2)) -Force | Out-Null

# ─── Démarrage ───
Step 'Démarrage'
Start-Service ItineoSupervision
if ($domain) { Start-Service ItineoSupervisionWeb }
$ok = $false
for ($i = 0; $i -lt 90; $i++) {
  try {
    $res = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4000/api/health' -TimeoutSec 2
    if ($res.StatusCode -eq 200) { $ok = $true; break }
  } catch { Start-Sleep -Seconds 1 }
}
# Première sauvegarde tout de suite : sinon la console affiche « aucune sauvegarde » jusqu'à la nuit
if ($ok -and $firstInstall) { Start-ScheduledTask -TaskName 'Itinéo Supervision – sauvegarde' }

Say ''
if ($ok) { Say '  La console est installée et démarrée.' 'Green' } else { Say "  La console met du temps à démarrer : voir les journaux dans $journaux" 'Yellow' }
Say ''
Say '  Sur ce PC                    : http://localhost:4000'
if ($domain) { Say "  Adresse pour les installations : https://$domain   (la box doit rediriger les ports 80 et 443 vers ce PC)" }
else { Say "  Adresse pour les installations du réseau : http://$($env:COMPUTERNAME.ToLower()):4000" }
if ($password) {
  Say ''
  Say '  Votre compte' 'Cyan'
  Say "    E-mail                  : $($r.email)"
  Say "    Mot de passe provisoire : $password" 'Yellow'
  Say ''
  Say '  Notez-le : il ne sera plus affiché.' 'Yellow'
  Say '  Puis, dans la console : Mon compte → Activer la double authentification,' 'Yellow'
  Say '  et menu Démarrer → « Itinéos Supervision – créer la clé de secours ».' 'Yellow'
}
Say ''
Say "  Données, sauvegardes et journaux : $Data"
Say ''
if (-not $Silencieux) { Read-Host '  Appuyez sur Entrée pour terminer' }
