﻿<#
  Sauvegarde de la console de supervision : la base (installations, bugs, historique) et les données (clé de signature,
  versions publiées), dans Data\sauvegardes. Chaque nuit à 2 h 30 (tâche « Itinéo Supervision – sauvegarde »).
  Les sauvegardes de plus de 30 jours sont supprimées : COPIEZ-LES AUSSI AILLEURS.
#>
param(
  [string]$App = (Split-Path -Parent $PSScriptRoot),
  [string]$Data = (Join-Path $env:ProgramData 'ItineoSupervision'),
  [int]$KeepDays = 30
)
$ErrorActionPreference = 'Stop'
$dest = Join-Path $Data 'sauvegardes'
$log = Join-Path $Data 'journaux\sauvegardes.log'
$stamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
function Log([string]$text) { Add-Content -LiteralPath $log -Encoding UTF8 -Value "$(Get-Date -Format s)  $text" }
try {
  $cfg = @{}
  foreach ($line in Get-Content -LiteralPath (Join-Path $Data 'services\supervision.env') -Encoding UTF8) {
    $i = $line.IndexOf('=')
    if ($i -gt 0) { $cfg[$line.Substring(0, $i)] = $line.Substring($i + 1) }
  }
  New-Item -ItemType Directory -Force $dest | Out-Null
  # Chemin calculé à part : « --file=(Join-Path …) » serait découpé en deux arguments par PowerShell
  $dump = Join-Path $dest "supervision-base-$stamp.dump"
  # Messages de pg_dump gardés pour le journal (la tâche tourne sans fenêtre)
  $ErrorActionPreference = 'Continue'
  $out = & (Join-Path $App 'runtime\pgsql\bin\pg_dump.exe') --format=custom --file=$dump --dbname=$($cfg.DATABASE_URL) 2>&1 | ForEach-Object { "$_" }
  $code = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  if ($code -ne 0) { throw "pg_dump a échoué : $($out -join ' ')" }
  # Zip intégré à .NET : le module Archive de PowerShell ne se charge pas toujours (tâche planifiée, Windows allégés)
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $zip = Join-Path $dest "supervision-donnees-$stamp.zip"
  if (Test-Path $zip) { Remove-Item $zip -Force }
  [IO.Compression.ZipFile]::CreateFromDirectory((Join-Path $Data 'donnees'), $zip)
  Get-ChildItem $dest -File | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$KeepDays) } | Remove-Item -Force
  Log "sauvegarde $stamp terminée"
} catch {
  Log "ÉCHEC de la sauvegarde $stamp : $($_.Exception.Message)"
  throw
}
