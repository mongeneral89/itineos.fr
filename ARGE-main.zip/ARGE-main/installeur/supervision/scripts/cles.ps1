﻿<#
  Clés de signature des mises à jour (raccourcis du menu Démarrer) :
    -Action secours     crée la clé de secours, enregistrée chiffrée sur le Bureau, à ranger ensuite HORS de ce PC
    -Action sauvegarde  copie chiffrée de la clé principale, sur le Bureau
  Se relance en administrateur si besoin (la clé est dans un dossier réservé aux administrateurs).
#>
param(
  [ValidateSet('secours', 'sauvegarde')] [string]$Action = 'secours',
  [string]$App = (Split-Path -Parent $PSScriptRoot),
  [string]$Data = (Join-Path $env:ProgramData 'ItineoSupervision'),
  [string]$Desktop = [Environment]::GetFolderPath('Desktop')
)
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
  Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"", '-Action', $Action, '-App', "`"$App`"", '-Data', "`"$Data`"", '-Desktop', "`"$Desktop`""
  exit
}
$Host.UI.RawUI.WindowTitle = 'Itinéos Supervision – clés de signature'
$name = if ($Action -eq 'secours') { 'cle-secours-CHIFFREE.json' } else { "cle-principale-CHIFFREE-$(Get-Date -Format 'yyyy-MM-dd').json" }
$env:DATA_DIR = Join-Path $Data 'donnees'
Write-Host ''
Write-Host '  Choisissez un mot de passe (12 caractères au moins) et notez-le À PART du fichier.' -ForegroundColor Cyan
Push-Location (Join-Path $App 'app\apps\supervision')
& (Join-Path $App 'runtime\node\node.exe') --import tsx src/cles.ts $Action (Join-Path $Desktop $name)
Pop-Location
if ($Action -eq 'secours' -and (Test-Path (Join-Path $Desktop $name))) {
  # La console relit ses clés au démarrage : les installations apprennent la clé de secours au passage suivant
  Restart-Service ItineoSupervision -ErrorAction SilentlyContinue
  Write-Host "  Rangez maintenant $name HORS de ce PC (clé USB, coffre-fort de mots de passe) et effacez-le du Bureau." -ForegroundColor Yellow
}
Read-Host '  Entrée pour fermer'
