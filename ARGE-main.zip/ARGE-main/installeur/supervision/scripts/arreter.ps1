﻿<#
  Arrête les services de la console (avant une mise à jour ou une désinstallation).
  -Retirer : les retire aussi de Windows, avec la règle du pare-feu et la sauvegarde planifiée.
  Les données (base, clé de signature, sauvegardes) ne sont jamais effacées.
#>
param(
  [string]$App = (Split-Path -Parent $PSScriptRoot),
  [string]$Data = (Join-Path $env:ProgramData 'ItineoSupervision'),
  [switch]$Retirer
)
$ErrorActionPreference = 'Continue'
$services = Join-Path $Data 'services'
foreach ($id in 'ItineoSupervisionWeb', 'ItineoSupervision') {
  if (Get-Service $id -ErrorAction SilentlyContinue) {
    Stop-Service $id -Force -ErrorAction SilentlyContinue
    $wrapper = Join-Path $services "$id.exe"
    if ($Retirer -and (Test-Path $wrapper)) { & $wrapper uninstall | Out-Null }
  }
}
if (Get-Service ItineoSupervisionBase -ErrorAction SilentlyContinue) {
  Stop-Service ItineoSupervisionBase -Force -ErrorAction SilentlyContinue
  if ($Retirer) { & (Join-Path $App 'runtime\pgsql\bin\pg_ctl.exe') unregister -N ItineoSupervisionBase | Out-Null }
}
if ($Retirer) {
  Remove-NetFirewallRule -DisplayName "Itinéos Supervision" -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName 'Itinéo Supervision – sauvegarde' -Confirm:$false -ErrorAction SilentlyContinue
}
