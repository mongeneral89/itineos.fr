/**
 * Télécharge les programmes intégrés à l'installateur Windows (dans installeur/telechargements, hors Git),
 * en vérifiant leur empreinte quand l'éditeur la publie. Ne retélécharge pas ce qui est déjà là.
 *
 *   node installeur/telecharger.mjs
 */
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const VERSIONS = {
  node: '22.23.3',
  postgres: '16.14-1',
  caddy: '2.11.7',
  winsw: '2.12.0',
  // Prise en main à distance du PC serveur (option de l'installateur)
  rustdesk: '1.5.0',
};

const DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'telechargements');

const FILES = [
  {
    name: `node-v${VERSIONS.node}-win-x64.zip`,
    url: `https://nodejs.org/dist/v${VERSIONS.node}/node-v${VERSIONS.node}-win-x64.zip`,
    sums: `https://nodejs.org/dist/v${VERSIONS.node}/SHASUMS256.txt`,
  },
  {
    name: `postgresql-${VERSIONS.postgres}-windows-x64-binaries.zip`,
    url: `https://get.enterprisedb.com/postgresql/postgresql-${VERSIONS.postgres}-windows-x64-binaries.zip`,
  },
  {
    name: `caddy_${VERSIONS.caddy}_windows_amd64.zip`,
    url: `https://github.com/caddyserver/caddy/releases/download/v${VERSIONS.caddy}/caddy_${VERSIONS.caddy}_windows_amd64.zip`,
    sums: `https://github.com/caddyserver/caddy/releases/download/v${VERSIONS.caddy}/caddy_${VERSIONS.caddy}_checksums.txt`,
    algo: 'sha512',
  },
  {
    name: 'WinSW-x64.exe',
    url: `https://github.com/winsw/winsw/releases/download/v${VERSIONS.winsw}/WinSW-x64.exe`,
  },
  {
    name: `rustdesk-${VERSIONS.rustdesk}-x86_64.msi`,
    url: `https://github.com/rustdesk/rustdesk/releases/download/${VERSIONS.rustdesk}/rustdesk-${VERSIONS.rustdesk}-x86_64.msi`,
  },
  {
    // Bibliothèques Visual C++ dont PostgreSQL a besoin (absentes d'un Windows neuf) ;
    // pas d'empreinte publiée : construire.ps1 vérifie la signature Microsoft du fichier
    name: 'vc_redist.x64.exe',
    url: 'https://aka.ms/vs/17/release/vc_redist.x64.exe',
  },
];

async function expectedSum(f) {
  if (!f.sums) return null;
  const text = await (await fetch(f.sums)).text();
  const line = text.split('\n').find((l) => l.trim().endsWith(f.name));
  if (!line) throw new Error(`Empreinte introuvable pour ${f.name}`);
  return line.trim().split(/\s+/)[0].toLowerCase();
}

await mkdir(DIR, { recursive: true });
for (const f of FILES) {
  const file = path.join(DIR, f.name);
  const expected = await expectedSum(f);
  let data;
  if (existsSync(file)) {
    data = await readFile(file);
    console.log(`déjà là   ${f.name}`);
  } else {
    process.stdout.write(`télécharge ${f.name}… `);
    const res = await fetch(f.url);
    if (!res.ok) throw new Error(`${f.url} : ${res.status}`);
    data = Buffer.from(await res.arrayBuffer());
    console.log(`${(data.length / 1e6).toFixed(1)} Mo`);
  }
  if (expected) {
    const got = createHash(f.algo ?? 'sha256').update(data).digest('hex');
    if (got !== expected) throw new Error(`Empreinte incorrecte pour ${f.name} : fichier corrompu ou modifié`);
    console.log(`           empreinte vérifiée (${f.algo ?? 'sha256'})`);
  }
  if (!existsSync(file)) await writeFile(file, data);
}
