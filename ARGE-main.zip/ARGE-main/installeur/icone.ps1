﻿<#
  Icône d'Itinéos (écran du bureau, tournée, repère validé), en .ico de 16 à 256 px :
    powershell -File installeur\icone.ps1 -Sortie chemin\itineo.ico
  Utilisée par l'installateur (construire.ps1) et par le programme du poste (poste\construire.ps1).
  installeur\itineos.ico est tiré de apps\web\brand\icon.svg (mêmes dessin et couleurs que l'appli).
#>
param([Parameter(Mandatory = $true)] [string]$Sortie)
$ErrorActionPreference = 'Stop'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'itineos.ico') -Destination $Sortie -Force
