﻿# Lancé à l'ouverture du bac à sable : raccourcis sur le Bureau et liste des essais.
$bureau = [Environment]::GetFolderPath('Desktop')
$src = 'C:\Essai\installeur'
$shell = New-Object -ComObject WScript.Shell
function Raccourci([string]$nom, [string]$cible, [string]$arguments = '') {
  $l = $shell.CreateShortcut((Join-Path $bureau "$nom.lnk"))
  $l.TargetPath = $cible; $l.Arguments = $arguments; $l.Save()
}
$console = Get-ChildItem "$src\supervision\sortie\Itineos-Supervision-Setup-*.exe" | Sort-Object LastWriteTime | Select-Object -Last 1
$itineo = Get-ChildItem "$src\sortie\Itineos-Setup-*.exe" | Sort-Object LastWriteTime | Select-Object -Last 1
Raccourci '1 - Installer la console' $console.FullName
Raccourci '2 - Installer Itinéos' $itineo.FullName
Raccourci '3 - Collecter les résultats' 'powershell.exe' "-NoProfile -ExecutionPolicy Bypass -File `"$src\essai\collecter.ps1`""
Copy-Item "$src\ESSAI.md" (Join-Path $bureau 'Liste des essais.txt')

@'
ESSAI DANS LE BAC À SABLE
=========================

1. « 1 - Installer la console » : votre nom, votre e-mail, adresse internet vide.
   Notez le mot de passe provisoire affiché à la fin.
2. Dans la console (http://localhost:4000) : connexion, Mon compte → double authentification,
   puis Clients → Nouvelle installation → « Copier » le code complet.
3. « 2 - Installer Itinéos » : page « Suivi par l'éditeur » → collez le code complet (il contient l'adresse).
   Cochez la prise en main à distance.
4. Suivez « Liste des essais » (Bureau), en notant ce qui ne va pas.
5. AVANT DE FERMER : « 3 - Collecter les résultats ». Le bac à sable efface tout à la fermeture ;
   les journaux sont copiés sur votre PC dans installeur\essai\resultats.
'@ | Set-Content (Join-Path $bureau 'LISEZ-MOI ESSAI.txt') -Encoding UTF8
Start-Process notepad.exe (Join-Path $bureau 'LISEZ-MOI ESSAI.txt')
