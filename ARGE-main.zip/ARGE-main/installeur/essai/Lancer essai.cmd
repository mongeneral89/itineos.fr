@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lancer-essai.ps1"
pause
