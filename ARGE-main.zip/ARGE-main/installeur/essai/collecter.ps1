﻿# Copie les journaux et l'état de la machine vers le PC hôte (C:\Essai\resultats = installeur\essai\resultats).
$dest = Join-Path 'C:\Essai\resultats' (Get-Date -Format 'yyyy-MM-dd_HH-mm')
New-Item -ItemType Directory -Force $dest | Out-Null

foreach ($nom in 'Itineo', 'ItineoSupervision') {
  $journaux = "C:\ProgramData\$nom\journaux"
  if (Test-Path $journaux) { Copy-Item $journaux (Join-Path $dest "journaux-$nom") -Recurse }
}

& {
  '=== Services ==='
  Get-Service Itineo* -ErrorAction SilentlyContinue | Format-Table Name, Status, StartType, DisplayName -AutoSize | Out-String -Width 200
  '=== Tâches planifiées ==='
  Get-ScheduledTask -TaskName 'Itin*' -ErrorAction SilentlyContinue | ForEach-Object {
    $i = $_ | Get-ScheduledTaskInfo
    '{0,-40} {1,-8} dernier lancement : {2}  résultat : {3}' -f $_.TaskName, $_.State, $i.LastRunTime, $i.LastTaskResult
  }
  '=== Ports à l''écoute ==='
  Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 80, 443, 3000, 4000, 5544, 5545 |
    Sort-Object LocalPort | Format-Table LocalAddress, LocalPort, OwningProcess -AutoSize | Out-String
  '=== Pare-feu ==='
  Get-NetFirewallRule -DisplayName 'Itin*' -ErrorAction SilentlyContinue | Format-Table DisplayName, Enabled, Profile -AutoSize | Out-String -Width 200
  '=== Réponses HTTP ==='
  foreach ($u in 'http://localhost', 'http://localhost:4000') {
    try { "$u : $((Invoke-WebRequest $u -UseBasicParsing -TimeoutSec 10).StatusCode)" } catch { "$u : $($_.Exception.Message)" }
  }
  '=== RustDesk ==='
  (Get-Service RustDesk -ErrorAction SilentlyContinue | Select-Object Name, Status | Out-String)
} | Out-File (Join-Path $dest 'etat.txt') -Encoding UTF8

# Les journaux d'installation masquent déjà les mots de passe ; on retire en plus les fichiers de réglages par sécurité
Get-ChildItem $dest -Recurse -Include '*.env', '*.pem', 'secret*' | Remove-Item -Force

Write-Host ''
Write-Host "  Résultats copiés : installeur\essai\resultats\$(Split-Path $dest -Leaf) sur votre PC." -ForegroundColor Green
Write-Host '  Vous pouvez fermer le bac à sable.'
Read-Host '  Entrée pour fermer'
