﻿<#
  Essai complet des deux installateurs dans Windows Sandbox (une machine Windows vierge, effacée à la fermeture).

    powershell -ExecutionPolicy Bypass -File installeur\essai\lancer-essai.ps1

  Dans le bac à sable : installer la console, puis Itinéos relié à cette console (http://localhost:4000), suivre
  installeur\ESSAI.md, puis « Collecter les résultats » : journaux et état des services arrivent dans
  installeur\essai\resultats sur ce PC (le reste disparaît à la fermeture).

  Il faut Windows 10/11 Pro avec le bac à sable activé (une fois, en administrateur, puis redémarrer) :
    Enable-WindowsOptionalFeature -Online -FeatureName Containers-DisposableClientVM -All
#>
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$installeur = Split-Path -Parent $here
$sandbox = "$env:SystemRoot\System32\WindowsSandbox.exe"

if (-not (Test-Path $sandbox)) {
  Write-Host ''
  Write-Host '  Windows Sandbox n''est pas activé sur ce PC.' -ForegroundColor Yellow
  Write-Host '  Ouvrez PowerShell en administrateur, lancez la commande ci-dessous, puis redémarrez :'
  Write-Host '    Enable-WindowsOptionalFeature -Online -FeatureName Containers-DisposableClientVM -All' -ForegroundColor Cyan
  Write-Host '  (ou : « Activer ou désactiver des fonctionnalités Windows » → « Bac à sable Windows »)'
  exit 1
}
$manque = @('sortie\Itineos-Setup-*.exe', 'supervision\sortie\Itineos-Supervision-Setup-*.exe') |
  Where-Object { -not (Get-ChildItem (Join-Path $installeur $_) -ErrorAction SilentlyContinue) }
if ($manque) { throw "Installateur manquant ($($manque -join ', ')) : lancez d'abord installeur\construire.ps1 et installeur\supervision\construire.ps1" }

$resultats = Join-Path $here 'resultats'
New-Item -ItemType Directory -Force $resultats | Out-Null
function XmlText([string]$s) { [Security.SecurityElement]::Escape($s) }

# Le dossier installeur en lecture seule, les résultats en écriture : rien d'autre du PC n'est visible
$wsb = Join-Path $env:TEMP 'itineo-essai.wsb'
@"
<Configuration>
  <MemoryInMB>6144</MemoryInMB>
  <Networking>Enable</Networking>
  <ClipboardRedirection>Enable</ClipboardRedirection>
  <MappedFolders>
    <MappedFolder>
      <HostFolder>$(XmlText $installeur)</HostFolder>
      <SandboxFolder>C:\Essai\installeur</SandboxFolder>
      <ReadOnly>true</ReadOnly>
    </MappedFolder>
    <MappedFolder>
      <HostFolder>$(XmlText $resultats)</HostFolder>
      <SandboxFolder>C:\Essai\resultats</SandboxFolder>
      <ReadOnly>false</ReadOnly>
    </MappedFolder>
  </MappedFolders>
  <LogonCommand>
    <Command>powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Essai\installeur\essai\accueil.ps1</Command>
  </LogonCommand>
</Configuration>
"@ | Set-Content $wsb -Encoding UTF8

Write-Host '  Ouverture du bac à sable (une minute environ)…' -ForegroundColor Cyan
Start-Process $wsb
