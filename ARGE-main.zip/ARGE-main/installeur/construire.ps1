﻿<#
  Construit l'installateur Windows d'Itinéos : installeur\sortie\Itineos-Setup-<version>.exe

    powershell -ExecutionPolicy Bypass -File installeur\construire.ps1

  Paquet de mise à jour pour la console de supervision, au lieu de l'installateur :

    powershell -ExecutionPolicy Bypass -File installeur\construire.ps1 -Paquet [-Canal arge] [-Publier http://localhost:4000] [-Notes "…"]

  -Version 0.1.1 : numéro du paquet (par défaut celui de package.json), pour un essai de mise à jour.
  -Publier envoie le paquet à la console (vos identifiants de la console sont demandés) ; c'est elle qui le signe.

  Il faut : Node.js et npm (pour construire), Inno Setup 6 (winget install JRSoftware.InnoSetup).
  Les programmes intégrés (Node.js, PostgreSQL, Caddy, WinSW) sont téléchargés par telecharger.mjs.
#>
param(
  [string]$Edition = 'TECH',
  [switch]$Paquet,
  [string]$Canal = 'standard',
  [string]$Publier,
  [string]$Notes,
  # (les variables PowerShell ignorent la casse : $Version écraserait $version)
  [Alias('Version')] [string]$NumeroPaquet
)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$root = Split-Path -Parent $here
$dl = Join-Path $here 'telechargements'
$out = Join-Path $here 'sortie'
$stage = Join-Path $out 'fichiers'
function Say([string]$text) { Write-Host "  $text" -ForegroundColor Cyan }
function Check([string]$what) { if ($LASTEXITCODE -ne 0) { throw "$what a échoué" } }
# Le tar de Windows (celui de Git Bash ne lit pas les chemins C:\…)
$tar = "$env:SystemRoot\System32\tar.exe"

$version = (Get-Content (Join-Path $root 'package.json') -Raw | ConvertFrom-Json).version
if ($NumeroPaquet) {
  if (-not $Paquet) { throw '-Version ne sert qu''avec -Paquet' }
  if ($NumeroPaquet -notmatch '^\d+\.\d+\.\d+([-.][A-Za-z0-9.]+)?$') { throw '-Version : format 1.2.3' }
  $version = $NumeroPaquet
}
$iscc = @("$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") |
  Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6 introuvable : winget install JRSoftware.InnoSetup' }

Say "Itinéos $version, édition $Edition"
Say 'Programmes intégrés'
node (Join-Path $here 'telecharger.mjs'); Check 'Le téléchargement'
$v = @{}
(Get-Content (Join-Path $here 'telecharger.mjs') -Raw | Select-String "(\w+): '([^']+)'" -AllMatches).Matches | ForEach-Object { $v[$_.Groups[1].Value] = $_.Groups[2].Value }

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force $stage | Out-Null
$tmp = Join-Path $out 'extraction'
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Force $tmp | Out-Null

# ─── Node.js : node.exe seulement ───
Say 'Node.js'
& $tar -xf (Join-Path $dl "node-v$($v.node)-win-x64.zip") -C $tmp "node-v$($v.node)-win-x64/node.exe"; Check 'Extraction de Node.js'
New-Item -ItemType Directory -Force "$stage\runtime\node" | Out-Null
Move-Item "$tmp\node-v$($v.node)-win-x64\node.exe" "$stage\runtime\node\node.exe"

# ─── PostgreSQL : le serveur et ses outils, sans pgAdmin, documentation ni fichiers de développement ───
Say 'PostgreSQL'
& $tar -xf (Join-Path $dl "postgresql-$($v.postgres)-windows-x64-binaries.zip") -C $tmp pgsql/bin pgsql/lib pgsql/share; Check 'Extraction de PostgreSQL'
New-Item -ItemType Directory -Force "$stage\runtime\pgsql" | Out-Null
foreach ($d in 'bin', 'lib', 'share') { Move-Item "$tmp\pgsql\$d" "$stage\runtime\pgsql\$d" }
Get-ChildItem "$stage\runtime\pgsql\bin" -Filter 'pgAdmin*' | Remove-Item -Recurse -Force
Get-ChildItem "$stage\runtime\pgsql\lib" -Include '*.lib', '*.a' -Recurse | Remove-Item -Force

# ─── Caddy et WinSW ───
Say 'Caddy, WinSW'
New-Item -ItemType Directory -Force "$stage\runtime\caddy", "$stage\runtime\winsw" | Out-Null
& $tar -xf (Join-Path $dl "caddy_$($v.caddy)_windows_amd64.zip") -C "$stage\runtime\caddy" caddy.exe; Check 'Extraction de Caddy'
Copy-Item (Join-Path $dl 'WinSW-x64.exe') "$stage\runtime\winsw\WinSW-x64.exe"
$vcRedist = Join-Path $dl 'vc_redist.x64.exe'
$sig = Get-AuthenticodeSignature $vcRedist
if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') { throw 'vc_redist.x64.exe : signature Microsoft absente ou invalide' }
New-Item -ItemType Directory -Force "$stage\runtime\vcredist" | Out-Null
Copy-Item $vcRedist "$stage\runtime\vcredist\"
New-Item -ItemType Directory -Force "$stage\runtime\rustdesk" | Out-Null
Copy-Item (Join-Path $dl "rustdesk-$($v.rustdesk)-x86_64.msi") "$stage\runtime\rustdesk\"

# ─── Serveur Itinéos : sources et dépendances (sans données ni réglages du développement) ───
Say 'Serveur Itinéos'
$app = "$stage\app"
# Le serveur est livré compilé et compacté (apps\api\dist) : jamais le code source lisible chez le client
Push-Location $root
npm run build -w @itineo/api --silent; Check 'La compilation du serveur'
Pop-Location
New-Item -ItemType Directory -Force "$app\apps\api", "$app\apps\web", "$app\packages\shared" | Out-Null
Copy-Item "$root\package.json", "$root\package-lock.json" $app
# package.json seuls : npm en a besoin pour lire les espaces de travail ; @itineo/shared est déjà dans dist
Copy-Item "$root\apps\web\package.json" "$app\apps\web\"
Copy-Item "$root\packages\shared\package.json" "$app\packages\shared\"
Copy-Item "$root\apps\api\package.json" "$app\apps\api\"
foreach ($d in 'dist', 'migrations', 'assets') { Copy-Item "$root\apps\api\$d" "$app\apps\api\$d" -Recurse }
# Jamais de .env ni de fichiers de démonstration dans l'installateur
Get-ChildItem $app -Recurse -Force -Filter '.env*' | Remove-Item -Force
Push-Location $app
# Sans les outils de développement (tsx, TypeScript) : le serveur compilé n'en a pas besoin
npm ci -w @itineo/api --omit=dev --no-audit --no-fund --loglevel=error; Check 'npm ci'
Pop-Location
# Liens des espaces de travail : inutiles, @itineo/shared est dans le serveur compilé
# (rmdir retire le lien seul ; Remove-Item -Recurse effacerait aussi le dossier pointé)
if (Test-Path "$app\node_modules\@itineo") {
  Get-ChildItem "$app\node_modules\@itineo" -Force | ForEach-Object { cmd /c rmdir "$($_.FullName)" }
  Remove-Item "$app\node_modules\@itineo" -Force
}
Remove-Item "$app\apps\web", "$app\packages" -Recurse -Force
# Le serveur annonce la version écrite dans package.json : celle du paquet
if ($NumeroPaquet) {
  $pkg = Join-Path $app 'package.json'
  [IO.File]::WriteAllText($pkg, ((Get-Content $pkg -Raw -Encoding UTF8) -replace '("version"\s*:\s*")[^"]+', "`${1}$NumeroPaquet"), (New-Object Text.UTF8Encoding $false))
}

# ─── Appli web ───
Say 'Appli web'
$env:EDITION = $Edition
Push-Location $root
npm run build -w @itineo/web --silent; Check 'La construction de l''appli web'
Pop-Location
Copy-Item "$root\apps\web\dist" "$stage\web" -Recurse

# ─── Scripts d'installation ───
New-Item -ItemType Directory -Force "$stage\installation" | Out-Null
Copy-Item "$here\scripts\*" "$stage\installation\"

# ─── Icône (repère de lieu, comme l'appli) ───
& (Join-Path $here 'icone.ps1') -Sortie (Join-Path $out 'itineo.ico')

# ─── Programme Windows « Itinéos » (poste\) : les raccourcis du PC serveur ouvrent Itinéos dans sa fenêtre ───
# (pas dans les paquets de mise à jour : il affiche le serveur, il n'a pas à changer avec lui)
if (-not $Paquet) {
  Say 'Programme Windows Itinéos'
  & (Join-Path $root 'poste\construire.ps1')
  Copy-Item (Join-Path $root 'poste\sortie\Itineos-win32-x64') "$stage\poste" -Recurse
  # Sur le PC serveur, Itinéos est sur ce PC lui-même
  [IO.File]::WriteAllText("$stage\poste\serveur.txt", 'http://localhost')
}

Remove-Item $tmp -Recurse -Force

# ─── Empreinte de référence des fichiers (serveur compilé, migrations, polices, appli web) ───
# La console la garde avec la version et alerte si une installation envoie autre chose (fichiers modifiés)
Push-Location $root
npx tsx installeur/empreinte.mts $stage; Check 'Le calcul de l''empreinte'
Pop-Location
Copy-Item (Join-Path $stage 'empreinte.txt') (Join-Path $out "empreinte-$version.txt") -Force

# ─── Paquet de mise à jour : programme, appli et scripts (les programmes intégrés ne changent pas) ───
if ($Paquet) {
  $zip = Join-Path $out "itineo-$Canal-$version.zip"
  if (Test-Path $zip) { Remove-Item $zip -Force }
  Say "Paquet $version (canal $Canal)"
  Push-Location $stage
  & $tar -a -cf $zip app web installation empreinte.txt; Check 'La création du paquet'
  Pop-Location
  Say "Paquet : $zip ($([math]::Round((Get-Item $zip).Length / 1MB)) Mo)"
  if ($Publier) {
    $console = $Publier.TrimEnd('/')
    $email = Read-Host '  E-mail de la console'
    $secure = Read-Host '  Mot de passe' -AsSecureString
    $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
    $login = Invoke-RestMethod -Method Post -Uri "$console/api/auth/login" -ContentType 'application/json' -Body (@{ email = $email; password = $password } | ConvertTo-Json)
    # Publier une version demande la double authentification
    if ($login.needCode) {
      $code = Read-Host '  Code de l''application d''authentification'
      $login = Invoke-RestMethod -Method Post -Uri "$console/api/auth/login" -ContentType 'application/json' -Body (@{ email = $email; password = $password; code = $code } | ConvertTo-Json)
    }
    $query = "version=$([uri]::EscapeDataString($version))&channel=$([uri]::EscapeDataString($Canal))"
    if ($Notes) { $query += "&notes=$([uri]::EscapeDataString($Notes))" }
    $rel = Invoke-RestMethod -Method Post -Uri "$console/api/releases?$query" -Headers @{ Authorization = "Bearer $($login.token)" } -ContentType 'application/zip' -InFile $zip
    Say "Publié sur la console : version $($rel.version), canal $($rel.channel)"
  }
  exit 0
}

# ─── Installateur ───
Say 'Installateur (compression : quelques minutes)'
& $iscc /Q "/DAppVersion=$version" (Join-Path $here 'itineo.iss'); Check 'Inno Setup'
$exe = Join-Path $out "Itineos-Setup-$version.exe"
Say "Terminé : $exe ($([math]::Round((Get-Item $exe).Length / 1MB)) Mo)"
