# Comparaison : « App technicien admin » et l'appli mobile d'Itinéos

Source : `Downloads\Condense - App technicien admin.md` (état du 04/10/2026), comparée à l'appli terrain d'Itinéos
(11/10/2026). Rien de la liste « à valider » n'est fait : chaque point attend votre accord.

## Points communs (déjà dans Itinéos)

| App technicien admin | Itinéos |
| --- | --- |
| Comptes e-mail + mot de passe, admin qui gère les utilisateurs | Oui, avec rôles et droits par agence |
| Mot de passe oublié par e-mail | Oui (lien par e-mail) |
| Fiche client, matériel installé (réf., modèle, n° de série) | Oui (parc matériel du client) |
| Bouton Appeler sur la fiche | Oui (touche le numéro) |
| Fiche d'intervention PDF, signatures technicien + client | Oui, modèles de fiches personnalisables |
| Dictée vocale | Oui, dans les champs des fiches |
| Photos avec légendes dans le PDF | Oui (avant / après / autre) |
| Bons de sortie de matériel | Oui, reliés au stock (dépôt et véhicules) |
| Envoi du PDF au client par e-mail | Oui, dans la langue du client |
| Fonctionne sans réseau | Oui (journée copiée sur l'appareil, envoi au retour du réseau) |
| Messagerie : privée + groupes, photos et fichiers | Oui |
| Notices & procédures | Oui (le bureau publie, les techniciens proposent, le bureau valide) |
| Annuaire : équipe, numéros utiles par catégorie, agences | Oui |
| Planning de l'équipe | Oui (jour / semaine / mois) côté bureau |
| Téléphone de chaque utilisateur | Oui (un numéro) |

Itinéos a en plus : devis, contrats, factures, stock, parc véhicules, habilitations, géolocalisation, espace client,
16 langues, statistiques à la carte, cartes SIM, suggestion d'attribution.

## Ce qui existe seulement dans « App technicien admin »

**Validé et fait le 12/10/2026 : 1, 2, 4, 5, 6, 9, 13 (le bureau choisit ce que voit chaque technicien), 14 et 16.**
Non retenus pour l'instant : 3, 7, 8, 10, 11, 12, 15, 17.

Numérotés pour que vous puissiez répondre simplement, par exemple « oui pour 1, 2, 5 ».

1. **Bouton « Y aller »** sur l'intervention : ouvre Waze par défaut, ou Google Maps / Plans / autre, choix retenu.
2. **Scanner** de n° de série, QR code, code-barres avec l'appareil photo (pour remplir la fiche ou le matériel).
3. **Coller-trier** : coller un mail ou un SMS, l'app range les infos dans la fiche client.
4. **Recherche client avancée** : sans accents ni format de téléphone, par n° d'abonné, n° de série, matériel,
   filtre par département.
5. **Note « dispositif difficile à repérer »** sur chaque matériel installé, bien visible pour le technicien.
6. **Document « Consignes »** (télésurveillance) : responsables à prévenir, ordre d'appel, rondes, plages horaires,
   signé par le client. Faisable avec l'éditeur de modèles + un modèle prêt à l'emploi.
7. **Messagerie : messages vocaux et vidéos** (les photos et fichiers sont déjà prévus).
8. **Appels et visio** depuis la messagerie (Jitsi, gratuit).
9. **Notifications sur le téléphone même appli fermée** (et/ou par e-mail) pour les messages et les nouvelles
   interventions.
10. **Filtre anti-photos inappropriées** analysé sur le téléphone, refus signalés à l'admin.
11. **Annuaire : services** Technique / Administratif / Commercial, et **fiches de personnes sans compte**.
12. **Deux numéros** par personne (pro et perso).
13. **Le technicien voit le planning de toute l'équipe** (lecture seule) avec son nom surligné.
14. **Rester connecté longtemps** + « Déconnecter tous mes appareils » dans Mon compte.
15. **Inscription libre validée par l'admin** (aujourd'hui dans Itinéos, c'est le bureau qui crée les comptes).
16. **Copie au bureau en option** à l'envoi d'une fiche, et réponse du client directement au technicien.
17. **Supprimer un brouillon** de fiche directement depuis la liste.

Mon avis : 1, 2, 4, 5, 9, 13, 14 et 16 apportent le plus au quotidien d'un technicien. 6 dépend de votre métier
(télésurveillance). 8 et 10 sont plus lourds et moins sûrs. 15 est peu utile pour un logiciel vendu aux entreprises.
