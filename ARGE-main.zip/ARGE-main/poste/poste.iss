﻿; Installateur d'Itinéos pour les postes du bureau (Inno Setup 6). Construit par poste\construire.ps1.
; Sans droits d'administrateur : chaque utilisateur l'installe pour lui (ou pour tous, en administrateur).

#define AppName "Itinéos"
#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif

[Setup]
AppId={{5E2B9C41-7D3A-4F18-9B6E-2A4C8D1F7E93}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher=Itinéos
DefaultDirName={autopf}\Itineo Poste
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=sortie
OutputBaseFilename=Itineos-Poste-Setup-{#AppVersion}
SetupIconFile=itineo.ico
; Licence d'utilisation : à accepter pour installer
LicenseFile=..\installeur\LICENCE.txt
UninstallDisplayIcon={app}\Itineos.exe
UninstallDisplayName={#AppName} (poste)
Compression=lzma2/max
SolidCompression=yes
LZMAUseSeparateProcess=yes
WizardStyle=modern
CloseApplications=yes

[Languages]
Name: "fr"; MessagesFile: "compiler:Languages\French.isl"

[Files]
Source: "sortie\Itineos-win32-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[InstallDelete]
; Ancien nom du programme et de ses raccourcis (avant Itinéos)
Type: files; Name: "{app}\Itineo.exe"
Type: files; Name: "{autoprograms}\Itinéo.lnk"
Type: files; Name: "{autodesktop}\Itinéo.lnk"

[Icons]
; AppUserModelID : le même que le programme, pour que ses notifications et son icône soient bien rattachées
Name: "{autoprograms}\Itinéos"; Filename: "{app}\Itineos.exe"; AppUserModelID: "fr.itineo.poste"; Comment: "Itinéos"
Name: "{autodesktop}\Itinéos"; Filename: "{app}\Itineos.exe"; AppUserModelID: "fr.itineo.poste"; Comment: "Itinéos"; Tasks: bureau

[Tasks]
Name: "bureau"; Description: "Créer un raccourci sur le Bureau"

[Run]
Filename: "{app}\Itineos.exe"; Description: "Ouvrir Itinéos"; Flags: postinstall nowait skipifsilent

[Code]
var
  ServerPage: TInputQueryWizardPage;

function ServerFile(): String;
begin
  Result := ExpandConstant('{app}\serveur.txt');
end;

procedure InitializeWizard();
begin
  ServerPage := CreateInputQueryPage(wpSelectDir,
    'Serveur Itinéos', 'Où Itinéos est-il installé ?',
    'L''adresse du PC où Itinéos est installé, ou son adresse internet. Votre responsable informatique la connaît.' + #13#10#13#10 +
    'Sur le PC serveur lui-même : http://localhost' + #13#10 +
    'Sur un autre PC du bureau : http://NOM-DU-PC-SERVEUR' + #13#10 +
    'Avec une adresse internet : https://itineo.mon-entreprise.fr');
  ServerPage.Add('Adresse du serveur :', False);
  ServerPage.Values[0] := 'http://localhost';
end;

procedure CurPageChanged(CurPageID: Integer);
var
  Existing: AnsiString;
begin
  { Réinstallation : on reprend l'adresse déjà choisie }
  if (CurPageID = ServerPage.ID) and FileExists(ServerFile()) and LoadStringFromFile(ServerFile(), Existing) and (Trim(String(Existing)) <> '') then
    ServerPage.Values[0] := Trim(String(Existing));
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Url: String;
begin
  Result := True;
  if CurPageID <> ServerPage.ID then Exit;
  Url := Trim(ServerPage.Values[0]);
  if (Url = '') or (Pos(' ', Url) > 0) then
  begin
    MsgBox('Indiquez l''adresse du serveur, par exemple http://localhost', mbError, MB_OK);
    Result := False;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  { Lue par le programme au premier lancement ; ensuite, menu Itinéos → Adresse du serveur }
  if CurStep = ssPostInstall then
    SaveStringToFile(ServerFile(), Trim(ServerPage.Values[0]), False);
end;
