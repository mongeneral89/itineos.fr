﻿<#
  Construit l'installateur d'Itinéos pour les postes du bureau : poste\sortie\Itineos-Poste-Setup-<version>.exe

    powershell -ExecutionPolicy Bypass -File poste\construire.ps1

  Le programme (Electron) affiche le serveur Itinéos de l'entreprise dans sa propre fenêtre : il s'installe sur
  chaque PC du bureau (et sur le PC serveur), sans droits d'administrateur. Il faut Node.js et Inno Setup 6.
#>
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$root = Split-Path -Parent $here
$out = Join-Path $here 'sortie'
function Say([string]$text) { Write-Host "  $text" -ForegroundColor Cyan }
function Check([string]$what) { if ($LASTEXITCODE -ne 0) { throw "$what a échoué" } }

$version = (Get-Content (Join-Path $here 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version
$iscc = @("$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") |
  Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6 introuvable : winget install JRSoftware.InnoSetup' }

Say "Itinéos (poste) $version"
Push-Location $here
try {
  npm ci --no-audit --no-fund --loglevel=error; Check 'npm ci'
  # npm ne lance plus les scripts d'installation : le programme Electron se télécharge ici (empreinte vérifiée)
  if (-not (Test-Path 'node_modules\electron\dist\electron.exe')) { node node_modules\electron\install.js; Check 'Le téléchargement d''Electron' }

  & (Join-Path $root 'installeur\icone.ps1') -Sortie (Join-Path $here 'itineo.ico')

  Say 'Programme'
  if (Test-Path $out) { Remove-Item $out -Recurse -Force }
  npx --no-install electron-packager . Itineos --platform=win32 --arch=x64 --out=sortie --overwrite --asar `
    --icon=itineo.ico --executable-name=Itineos --app-version=$version --build-version=$version `
    --win32metadata.CompanyName=Itinéos --win32metadata.ProductName=Itinéos --win32metadata.FileDescription=Itinéos `
    --win32metadata.OriginalFilename=Itineos.exe `
    --ignore='^/(sortie|node_modules|construire\.ps1|poste\.iss|package-lock\.json|\.gitignore)' --quiet
  Check 'L''empaquetage'
} finally {
  Pop-Location
}

Say 'Installateur'
& $iscc /Q "/DAppVersion=$version" (Join-Path $here 'poste.iss'); Check 'Inno Setup'
$exe = Join-Path $out "Itineos-Poste-Setup-$version.exe"
Say "Terminé : $exe ($([math]::Round((Get-Item $exe).Length / 1MB)) Mo)"
