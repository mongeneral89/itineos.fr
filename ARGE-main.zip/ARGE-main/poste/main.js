/**
 * Itinéos sur un poste du bureau : le logiciel dans sa propre fenêtre (Electron).
 * Le programme ne contient pas Itinéos lui-même : il affiche le serveur Itinéos de l'entreprise
 * (http://localhost sur le PC serveur, http://NOM-DU-SERVEUR ou https://itineo.entreprise.fr ailleurs).
 *
 *   npm start                 essai sur le PC de développement
 *   npm run construire        installateur Itineos-Poste-Setup-<version>.exe (voir construire.ps1)
 */
'use strict';
const { app, BrowserWindow, Menu, Notification, dialog, session, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

// Réglages et connexion gardés dans le dossier d'avant le changement de nom (Itinéo → Itinéos) : les postes
// déjà installés restent connectés et gardent l'adresse du serveur
app.setPath('userData', path.join(app.getPath('appData'), 'Itinéo'));

const APP_ID = 'fr.itineo.poste';

// ─── Réglages : adresse du serveur, taille de la fenêtre ─────────────────────────
const configFile = () => path.join(app.getPath('userData'), 'reglages.json');

function readConfig() {
  try {
    return JSON.parse(fs.readFileSync(configFile(), 'utf8'));
  } catch {
    return {};
  }
}

function writeConfig(patch) {
  const next = { ...readConfig(), ...patch };
  fs.mkdirSync(path.dirname(configFile()), { recursive: true });
  fs.writeFileSync(configFile(), JSON.stringify(next, null, 2), 'utf8');
  return next;
}

/** Adresse proposée par l'installateur (serveur.txt à côté du programme), sinon le PC lui-même */
function defaultServer() {
  try {
    const f = path.join(path.dirname(process.execPath), 'serveur.txt');
    const url = fs.readFileSync(f, 'utf8').replace(/^﻿/, '').trim();
    if (url) return url;
  } catch { /* pas d'installateur : essai */ }
  return 'http://localhost';
}

/** Adresse nettoyée (http(s)://hôte[:port], sans chemin) ; null si elle ne ressemble pas à une adresse */
function normalizeServer(input) {
  let s = String(input ?? '').trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = `http://${s}`;
  try {
    const u = new URL(s);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    return u.origin;
  } catch {
    return null;
  }
}

// Ordre : --serveur=… sur la ligne de commande (raccourci préparé par l'informatique), réglage choisi, installateur
const argServer = process.argv.find((a) => a.startsWith('--serveur='))?.slice('--serveur='.length);
const server = normalizeServer(argServer) ?? normalizeServer(readConfig().server) ?? normalizeServer(defaultServer()) ?? 'http://localhost';
const serverOrigin = new URL(server).origin;

// Sur le réseau du bureau, Itinéos est souvent en http (sans nom de domaine). Le navigateur y refuse alors la
// caméra (scanner), la position et l'appli hors ligne. Le serveur de l'entreprise, et lui seul, est traité comme sûr.
if (new URL(server).protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(new URL(server).hostname)) {
  app.commandLine.appendSwitch('unsafely-treat-insecure-origin-as-secure', serverOrigin);
}

app.setAppUserModelId(APP_ID); // notifications Windows au nom d'Itinéos
app.setName('Itinéos');

// Ancien programme (Itineo.exe) lancé au démarrage de Windows : l'option passe au nouveau (Itineos.exe)
if (process.platform === 'win32' && app.isPackaged) {
  const oldExe = path.join(path.dirname(process.execPath), 'Itineo.exe');
  if (app.getLoginItemSettings({ path: oldExe }).openAtLogin) {
    app.setLoginItemSettings({ openAtLogin: false, path: oldExe });
    app.setLoginItemSettings({ openAtLogin: true });
  }
}

// ─── Une seule fenêtre : relancer le raccourci ramène la fenêtre ouverte ───────────
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
  });
  app.whenReady().then(start);
  app.on('window-all-closed', () => app.quit());
}

let win = null;
let retryTimer = null;

const sameOrigin = (url) => {
  try {
    return new URL(url).origin === serverOrigin;
  } catch {
    return false;
  }
};

const webPreferences = {
  contextIsolation: true,
  nodeIntegration: false,
  sandbox: true,
  spellcheck: true,
};

function openExternal(url) {
  // Seuls les liens web, e-mail et téléphone sortent vers Windows ; jamais un fichier ni un programme
  if (/^(https?:|mailto:|tel:)/i.test(url)) void shell.openExternal(url);
}

function start() {
  const ses = session.defaultSession;
  ses.setSpellCheckerLanguages(['fr']);

  // Position (suivi, SOS), caméra (scanner, photos), micro, notifications : pour le serveur Itinéos seulement
  const allowed = new Set(['geolocation', 'media', 'notifications', 'clipboard-sanitized-write', 'fullscreen']);
  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    callback(allowed.has(permission) && sameOrigin(details.requestingUrl ?? wc.getURL()));
  });
  // (Electron donne l'origine avec une barre finale : « http://serveur/ »)
  ses.setPermissionCheckHandler((_wc, permission, requestingOrigin) => allowed.has(permission) && sameOrigin(requestingOrigin));

  const cfg = readConfig();
  win = new BrowserWindow({
    width: cfg.width ?? 1280,
    height: cfg.height ?? 820,
    minWidth: 900,
    minHeight: 600,
    title: 'Itinéos',
    icon: path.join(__dirname, 'itineo.ico'),
    backgroundColor: '#F4F2EE',
    show: false,
    webPreferences,
  });
  if (cfg.maximized) win.maximize();
  win.once('ready-to-show', () => win.show());
  win.on('close', () => {
    const b = win.getNormalBounds();
    writeConfig({ width: b.width, height: b.height, maximized: win.isMaximized() });
  });

  const wc = win.webContents;
  // Hors du serveur Itinéos : dans le navigateur de Windows, jamais dans la fenêtre du logiciel
  wc.on('will-navigate', (e, url) => {
    // Pages locales (hors ligne, adresse du serveur) : leurs boutons rechargent la page avec ?action=…, sans accès à Node
    if (url.startsWith('file:') && new URL(url).searchParams.has('action')) {
      e.preventDefault();
      handleLocal(url);
    } else if (!sameOrigin(url) && !url.startsWith('file:')) {
      e.preventDefault();
      openExternal(url);
    }
  });
  // Fenêtres ouvertes par l'appli (PDF, impression) : dans le logiciel si elles viennent du serveur
  wc.setWindowOpenHandler(({ url }) => {
    if (sameOrigin(url) || url.startsWith('blob:') || url === 'about:blank') {
      return { action: 'allow', overrideBrowserWindowOptions: { icon: path.join(__dirname, 'itineo.ico'), autoHideMenuBar: true, webPreferences } };
    }
    openExternal(url);
    return { action: 'deny' };
  });
  // Serveur injoignable (PC serveur éteint, réseau coupé) : page claire et nouvel essai automatique
  wc.on('did-fail-load', (_e, code, description, url, isMainFrame) => {
    if (!isMainFrame || code === -3 /* navigation annulée */ || url.startsWith('file:')) return;
    showOffline(description);
  });
  wc.on('page-title-updated', (e) => {
    e.preventDefault();
    win.setTitle('Itinéos');
  });

  Menu.setApplicationMenu(buildMenu());
  void win.loadURL(server);
}

function showOffline(reason) {
  void win.loadFile(path.join(__dirname, 'pages', 'hors-ligne.html'), { query: { serveur: server, raison: reason ?? '' } });
  clearTimeout(retryTimer);
  retryTimer = setTimeout(() => void win.loadURL(server), 15_000);
}

function askServer() {
  clearTimeout(retryTimer);
  void win.loadFile(path.join(__dirname, 'pages', 'adresse.html'), { query: { serveur: server } });
}

function handleLocal(url) {
  const u = new URL(url);
  const action = u.searchParams.get('action');
  if (action === 'reessayer') {
    clearTimeout(retryTimer);
    void win.loadURL(server);
  } else if (action === 'adresse') {
    askServer();
  } else if (action === 'enregistrer') {
    const next = normalizeServer(u.searchParams.get('url'));
    if (!next) {
      void dialog.showMessageBox(win, { type: 'warning', title: 'Itinéos', message: 'Adresse non reconnue', detail: 'Exemples : http://localhost, http://serveur-bureau, https://itineo.mon-entreprise.fr' });
      return;
    }
    writeConfig({ server: next });
    // L'adresse est lue au démarrage (réglages de sécurité du réseau) : on relance le logiciel
    // (sans --serveur=…, qui l'emporterait sur l'adresse qui vient d'être choisie)
    app.relaunch({ args: process.argv.slice(1).filter((a) => !a.startsWith('--serveur=')) });
    app.exit(0);
  } else if (action === 'annuler') {
    void win.loadURL(server);
  }
}

function buildMenu() {
  const login = app.getLoginItemSettings();
  return Menu.buildFromTemplate([
    {
      label: 'Itinéos',
      submenu: [
        { label: 'Accueil', accelerator: 'Alt+Home', click: () => void win.loadURL(server) },
        { label: 'Recharger', accelerator: 'F5', click: () => win.webContents.reload() },
        { label: 'Recharger', accelerator: 'CmdOrCtrl+R', visible: false, click: () => win.webContents.reload() },
        { type: 'separator' },
        { label: 'Adresse du serveur…', click: askServer },
        {
          label: 'Lancer Itinéos au démarrage de Windows',
          type: 'checkbox',
          checked: login.openAtLogin,
          click: (item) => app.setLoginItemSettings({ openAtLogin: item.checked }),
        },
        { type: 'separator' },
        { label: 'Imprimer…', accelerator: 'CmdOrCtrl+P', click: () => win.webContents.print() },
        { type: 'separator' },
        { label: 'Quitter', accelerator: 'Alt+F4', role: 'quit' },
      ],
    },
    {
      label: 'Édition',
      submenu: [
        { label: 'Annuler', role: 'undo' },
        { label: 'Rétablir', role: 'redo' },
        { type: 'separator' },
        { label: 'Couper', role: 'cut' },
        { label: 'Copier', role: 'copy' },
        { label: 'Coller', role: 'paste' },
        { label: 'Tout sélectionner', role: 'selectAll' },
      ],
    },
    {
      label: 'Affichage',
      submenu: [
        { label: 'Zoom avant', role: 'zoomIn', accelerator: 'CmdOrCtrl+=' },
        { label: 'Zoom arrière', role: 'zoomOut' },
        { label: 'Taille normale', role: 'resetZoom' },
        { type: 'separator' },
        { label: 'Plein écran', role: 'togglefullscreen', accelerator: 'F11' },
      ],
    },
    {
      label: 'Aide',
      submenu: [
        {
          label: 'Tester les notifications',
          click: () => new Notification({ title: 'Itinéos', body: 'Les notifications Windows fonctionnent.' }).show(),
        },
        {
          label: 'À propos d’Itinéos',
          click: () => void dialog.showMessageBox(win, {
            type: 'info',
            title: 'À propos d’Itinéos',
            message: `Itinéos ${app.getVersion()}`,
            detail: `Serveur : ${server}\nLogiciel de gestion pour entreprises de techniciens itinérants.`,
          }),
        },
      ],
    },
  ]);
}
