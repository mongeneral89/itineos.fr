# Itinéos

Logiciel de gestion pour entreprises de techniciens itinérants : **multi-sociétés, multi-pays, multi-agences**.
Décliné en **six éditions**, une par métier (Itinéos, Vigie, Constat, Expertise, Clés, Services) : voir
« Six éditions » plus bas.
Un seul logiciel pour le bureau (planning, interventions, clients, organisation, pilotage) et une **appli terrain**
pour les techniciens (journée, fiche d'intervention pré-remplie, dictée vocale, double signature, PDF envoyé au client).

Cette version est le **socle** : l'organisation, les droits, les clients, les interventions et les fiches fonctionnent
de bout en bout. Les autres modules (devis, facturation, stock…) viendront se brancher dessus.

---

## 1. Ce qu'il y a dedans

| Partie | Rôle | Technologies |
|---|---|---|
| `apps/api` | Le serveur : données, droits, PDF, e-mails | Node.js, Fastify, PostgreSQL, Drizzle ORM, Zod |
| `apps/web` | Le bureau **et** l'appli terrain (installable sur tablette et téléphone) | React, Vite |
| `packages/shared` | Ce qui est commun aux deux : rôles, permissions, statuts, format des fiches | TypeScript |

### L'organisation

```
Groupe
 └── Société (une par pays ou entité juridique : langue, devise, fuseau horaire, numérotation)
      └── Agence
           └── Équipe
                └── Utilisateurs
```

Chaque donnée (client, intervention, fiche) appartient à une société, et le plus souvent à une agence.

### Les droits : un rôle **et** un périmètre

Un utilisateur reçoit un ou plusieurs rôles, chacun sur un périmètre :

| Périmètre | Exemple |
|---|---|
| Tout le groupe | L'administrateur voit toutes les sociétés de tous les pays |
| Une société | La direction France voit toutes les agences françaises, pas le Royaume-Uni |
| Une agence | Le chef de l'agence Est ne voit que l'agence Est (et les clients partagés de la société) |

Rôles disponibles : administrateur du groupe, direction, chef d'agence, planificateur, commercial, comptabilité,
technicien, lecture seule. Ce que chaque rôle peut faire est défini dans `packages/shared/src/index.ts`
(`ROLE_PERMISSIONS`). Le contrôle est fait **côté serveur** dans `apps/api/src/auth/access.ts`.

Un technicien ne voit que **ses** interventions. Un utilisateur ne peut jamais donner plus de droits qu'il n'en a.

**Protection des comptes :**
- Après 5 mauvais mots de passe en 15 minutes, le compte est bloqué 15 minutes, même si le bon mot de passe est
  ensuite saisi. Le blocage est tracé dans le journal.
- Une même adresse réseau est bloquée au-delà de 30 échecs en 15 minutes, et « mot de passe oublié » est limité à
  5 demandes. Les compteurs sont dans `apps/api/src/services/rate-limit.ts`.
- Changer de mot de passe ferme les sessions ouvertes sur les autres appareils.

### Les fiches d'intervention

- Chaque fiche suit un **modèle** (sections et champs, en JSON). Des modèles **neutres** sont fournis en français
  et en anglais pour l'installation, le SAV, l'entretien et les autres interventions (`apps/api/src/services/default-templates.ts`).
- Chaque société peut créer **ses propres modèles** depuis l'écran **Modèles de fiches** : on part d'une copie du
  modèle neutre, puis on ajoute, retire ou réordonne sections et champs (texte, nombre, date, choix, cases à cocher…).
  On peut aussi rendre un champ obligatoire, y activer la dictée, le pré-remplir et ajouter une aide, avec un aperçu en
  direct de la fiche du technicien. Modifier un modèle crée une nouvelle version : les fiches déjà faites ne changent
  jamais. « Retirer » rend la main au modèle neutre.
- La fiche est **pré-remplie** (motif, matériel, numéro de série…), le technicien complète au clavier ou en **dictée**,
  ajoute pièces et temps passé, puis technicien et client **signent au doigt**.
- À l'envoi, le **PDF** est généré dans la langue de la société, archivé, et envoyé par e-mail au client.
- Cycle : `brouillon → signée (figée) → envoyée`.
- **Photos** avant / après / autre, avec légende : réduites sur l'appareil (1600 px, ~300 Ko), 20 au maximum
  par fiche, reprises dans le PDF et visibles au bureau sur la page de l'intervention.
  Elles sont verrouillées une fois la fiche signée.

### Devis

- Lignes avec quantité, unité, prix HT et TVA. Les taux proposés dépendent du pays : France 20 / 10 / 5,5 / 2,1 %,
  Belgique 21 / 12 / 6 %, Royaume-Uni 20 / 5 %. Les totaux sont calculés en centimes, avec la TVA par taux comme sur une
  facture.
- Numéros par société et par année : `FR-DEV-2026-00001` (`UK-QUO-…` en anglais).
- Cycle : `brouillon → envoyé (PDF par e-mail, archivé) → accepté / refusé`. Un devis envoyé peut repasser en brouillon
  pour être corrigé, puis renvoyé. Un devis envoyé dont la validité est passée apparaît comme « Expiré ».
- Accepté : un clic crée **l'intervention à planifier** (devis de travaux) ou **le contrat d'entretien** (devis de contrat).
- Depuis une intervention dont la fiche indique « Devis à établir », le bouton **Créer un devis** reprend le client, le
  lieu et les pièces notées par le technicien.

### Contrats d'entretien

- Client, site, matériel couvert, agence, fréquence (mensuelle à tous les 2 ans), date de première visite, fin éventuelle
  et prix annuel.
- **Les visites se créent toutes seules** : chaque échéance devient une intervention « À planifier » 60 jours avant,
  avec sa date d'échéance, visible dans le planning. La génération tourne au démarrage du serveur puis toutes les 6 h,
  sans jamais créer de doublon.
- Changer la fréquence ou les dates, suspendre ou terminer un contrat retire les visites futures qui ne sont pas encore
  planifiées. Celles déjà planifiées ne bougent jamais.

### Facturation

- **Créer une facture** depuis une fiche signée (main-d'œuvre au taux horaire, forfait de déplacement, pièces posées),
  depuis un devis accepté (mêmes lignes), depuis un contrat (une période au prorata du prix annuel), ou à partir de rien.
- **Brouillon → émise.** Une facture ne reçoit son numéro qu'à l'émission (`FR-FAC-2026-00001`), avec une
  numérotation continue et sans trou : le numéro et la facture sont enregistrés ensemble. Une fois émise, elle n'est
  plus modifiable ni supprimable, et son PDF est archivé tel quel. Une erreur se corrige par un **avoir**
  (`FR-AVO-…`), qui ne peut jamais dépasser le montant de la facture.
- PDF avec date de prestation, échéance, pénalités de retard, indemnité forfaitaire de 40 € et coordonnées bancaires.
  Envoi par e-mail au client.
- **Encaissements** : paiements partiels ou complets (virement, chèque, carte…), reste à payer et retards. La liste
  affiche « Reste à encaisser » et « En retard ».
- **Export comptable** (CSV pour Excel ou un logiciel comptable) : journal des ventes équilibré (comptes 411 / 706 /
  44571, auxiliaire client = référence externe du client) et liste des factures, sur la période choisie.
- **Réglages par société** (écran Organisation) : délai de paiement, taux horaire, forfait de déplacement,
  coordonnées bancaires, mentions légales.
- **Droits** : direction, chef d'agence et comptabilité facturent. Le commercial consulte. L'export et les réglages
  sont réservés à qui voit toute la société.

### Facture électronique (réforme française)

- **Factur-X** : à l'émission, le PDF de la facture (ou de l'avoir) devient un PDF/A-3 qui contient le XML de la
  facture (CII, profil EN 16931 : SIREN, n° de TVA, TVA par taux, échéance, IBAN, nature de l'opération, mentions
  de pénalités). `services/facturx.ts` ; téléchargeable seul (« Télécharger le XML Factur-X ») et par période
  (Factures → export « Factur-X, .zip »).
- **Mentions** : SIREN et n° de TVA de la société (Organisation → Facture électronique) et du client entreprise
  (fiche client), nature de l'opération (services, biens, mixte) sur chaque facture, option TVA sur les débits. Ce
  qui manque est affiché sur la facture.
- **Plateforme agréée** : adresse de son API et jeton (jamais renvoyé au navigateur), « Tester la connexion », dépôt
  manuel ou automatique à l'émission, suivi du cycle de vie (déposée, approuvée, refusée, encaissée…).
  `services/einvoice.ts` suit l'API de dépôt de flux normalisée (`POST /v1/flows`, `GET /v1/flows/{id}`) : à valider
  sur l'environnement de test de la plateforme choisie.
- **Particuliers** : rien ne change, la facture leur est envoyée par e-mail ; elle n'est jamais déposée sur la
  plateforme.

### Stock et bons de sortie

- **Catalogue d'articles** par société : référence unique, désignation, famille, unité, prix d'achat et de vente HT,
  TVA. Un article retiré reste dans l'historique.
- **Lieux de stock** : dépôts (d'une agence ou central) et un véhicule par technicien.
- **Réceptions** (livraisons fournisseur), **inventaire** (on saisit la quantité comptée, l'écart est enregistré),
  **seuils d'alerte** par lieu et onglet « Alertes » pour le stock bas.
- **Bons de sortie** (`FR-BS-2026-00001`), du dépôt vers un véhicule ou vers un chantier. Le numéro est attribué à la
  validation, et la sortie est refusée si le dépôt n'a pas assez : dans ce cas, rien ne bouge. Le PDF comporte les
  cadres « Remis par » et « Reçu par ».
- **Pièces posées** : sur la fiche, le technicien choisit dans le stock de son véhicule, y compris hors connexion. Les
  pièces sont déduites de son véhicule à la signature, puis facturées au prix du catalogue.
- Dans les **devis et factures**, taper un article du catalogue remplit la ligne (désignation, unité, prix, TVA).
- Chaque mouvement est tracé (qui, quand, d'où, vers où, avec quel bon ou quelle intervention), et les quantités sont
  toujours la somme exacte des mouvements.

### Parc véhicules

- Tous les véhicules : immatriculation (unique, quelle que soit l'écriture), marque, modèle, type, énergie, propriété
  ou location (loueur), état (en service, immobilisé, sorti du parc), conducteur, kilométrage et stock embarqué.
- **Échéances** par véhicule : entretien (à une date et/ou à un kilométrage), contrôle technique, assurance, pneus,
  fin de location… avec leur périodicité (tous les 12 mois / 20 000 km).
- **À programmer** : tout ce qui est dépassé ou arrive dans 30 jours (ou 1 500 km), le dépassé en premier. On y prend
  rendez-vous (date et garage).
- **Carnet d'entretien** : entretiens, réparations, contrôles, pneus, sinistres, avec kilométrage, garage et coût, et
  le total des dépenses de l'année. Noter une échéance « faite » recalcule automatiquement la suivante et met à jour
  le kilométrage.
- Le conducteur relève son kilométrage depuis « Mon compte » (le compteur ne peut pas reculer).

### Habilitations

- Types d'habilitation communs au groupe (B1V, BR, fluides frigorigènes, CACES, travail en hauteur, SST…), avec leur
  durée de validité habituelle. La date d'expiration est proposée automatiquement.
- Tableau « techniciens × habilitations » : vert = valable, orange = expire dans moins de 60 jours, rouge = expirée.
  On y ajoute un justificatif (PDF ou photo, contenu vérifié).
- Une intervention peut **exiger des habilitations**. Au planning, choisir un technicien qui ne les aura pas à la date
  prévue affiche un avertissement : on peut planifier quand même, en connaissance de cause.
- Le technicien voit ses habilitations dans « Mon compte ».

### Échéances : tableau de bord et e-mail du matin

- Le tableau de bord affiche les échéances véhicules et habilitations à traiter.
- Chaque matin à partir de 7 h, un récapitulatif par e-mail part vers la direction (toute la société) et vers chaque
  chef d'agence (son agence). L'envoi n'a lieu que s'il y a quelque chose à signaler, et une seule fois par jour, même
  si le serveur redémarre.

### Géolocalisation des véhicules

- La position vient du **téléphone du conducteur** (le technicien à qui le véhicule est attribué), pendant que l'appli
  terrain est ouverte : une position quand il a bougé de plus de 150 m ou toutes les 3 minutes, plus une à chaque
  « Je pars » / « Je suis sur place » (rattachée à l'intervention). Sans réseau, elles attendent sur l'appareil.
- **C'est le technicien qui active le partage** (carte d'information dans « Ma journée », interrupteur dans
  « Mon compte ») et il peut l'arrêter à tout moment. Aucune position antérieure à son accord n'est acceptée.
  L'historique est **effacé après 30 jours** (tâche automatique). Ces choix suivent les règles de la CNIL sur la
  géolocalisation des salariés : informez aussi vos équipes par écrit avant la mise en service.
- Au bureau : **Parc véhicules → Carte** (dernière position, conducteur, intervention en cours ; en gris au-delà de
  30 minutes) et, sur la fiche du véhicule, le **trajet de la journée** choisie.
- Fond de carte : OpenStreetMap par défaut. En production, utilisez un fournisseur de tuiles adapté
  (`VITE_MAP_TILES_URL`, voir DEPLOIEMENT.md).
### Espace client (portail)

- Adresse : `/portail` (même site que le bureau, session à part). Le client y retrouve ses interventions (statut en
  direct, fiche signée en PDF), ses devis (consulter, **accepter ou refuser en ligne**), ses factures (payé, reste à
  régler, PDF), ses contrats d'entretien avec la prochaine visite, et **demande une intervention** (lieu, matériel,
  problème, disponibilités, urgence).
- Accès sur invitation : depuis la fiche client, « Espace client en ligne » → « Inviter une personne ». La personne
  reçoit un lien (valable 7 jours) pour choisir son mot de passe. Le bureau peut renvoyer l'invitation ou couper
  l'accès à tout moment (la session en cours est refusée aussitôt). Mot de passe oublié : lien d'une heure.
- Une demande en ligne crée une intervention « à planifier » (origine « Portail client »), avec accusé de réception
  au client et e-mail à l'agence. Une réponse à un devis est notée sur le devis (qui, quand, commentaire) et
  l'agence ainsi que l'auteur du devis sont prévenus.
- Cloisonnement : chaque requête est filtrée sur le client de la personne connectée ; un jeton du portail est refusé
  sur les routes du bureau et inversement (`apps/api/src/routes/portal.ts`, tests `portal.test.ts`).
### L'appli terrain hors connexion

- Le matin, avec du réseau, « Ma journée » copie sur l'appareil toutes les fiches du jour et leurs photos
  (« Disponible hors ligne : 5/5 fiches »).
- Sans réseau, le technicien peut tout faire : je pars / je suis sur place, remplir la fiche, photos,
  signatures, demande d'envoi. Tout est rangé dans une **file d'attente** sur l'appareil (`apps/web/src/offline/`)
  et part tout seul, dans l'ordre, au retour du réseau. L'en-tête indique l'état (hors ligne, en attente, envoyé).
- **Synchroniser** : le bouton de l'appli envoie ce qui attend sur l'appareil, puis recharge la journée et toutes ses
  fiches. Les changements du bureau arrivent aussi tout seuls : l'appli relit `GET /sync/stamp` (ses interventions,
  leurs fiches, la dernière demande du bureau) à l'ouverture, chaque minute et quand on y revient. Au bureau,
  « Synchroniser les téléphones » (Planning) prévient les techniciens de l'agence (`POST /sync/request`) : leur appli
  ouverte se met à jour aussitôt (notification + message du service worker).
- Les heures (arrivée, signature) sont celles du moment réel sur l'appareil, pas celles de l'envoi.
- Un envoi rejoué après une coupure ne crée ni doublon de photo, ni second e-mail au client.
- L'appli elle-même est gardée sur l'appareil par un service worker (`apps/web/public/sw.js`, version de
  production uniquement). Les navigateurs ne l'autorisent qu'en **HTTPS** (ou sur `localhost`) : sur une tablette
  qui ouvre `http://ADRESSE-IP:5173`, les fiches marchent hors ligne une fois ouvertes, mais l'appli ne peut pas
  démarrer sans réseau. En production (HTTPS), tout fonctionne.
- À la déconnexion, les copies sont effacées de l'appareil ; les modifications pas encore envoyées sont gardées
  et partent à la prochaine connexion du même compte.

### Logo de la société

Dans **Organisation**, chaque société peut déposer son logo (PNG, JPEG, SVG ou WebP ; l'appli le réduit à
800 × 400 au plus et le convertit en PNG). Il apparaît en haut du menu du bureau, dans l'appli terrain, dans
l'espace client (y compris sur la page d'invitation) et en tête des PDF : fiches, devis, factures, bons de sortie.
Le fichier est rangé dans `STORAGE_DIR/logos` (sauvegardé avec le reste) ; l'image est publique à
`/api/logos/:idSociété` (c'est l'image de marque de l'entreprise). Les e-mails envoyés au nom d'une société (fiches,
devis, factures, espace client, récapitulatif du matin) partent aussi en version mise en forme, avec le logo en tête
(image jointe, affichée sans téléchargement) ; la version texte reste jointe. Les e-mails personnels (mot de passe
oublié, notifications) restent en texte.

### Imprévus au planning : replanifier, déplacer, annuler

- Un clic sur une intervention du planning ouvre un panneau : **Ouvrir la fiche**, **Replanifier** (technicien, début,
  durée, avec l'alerte d'habilitation manquante) ou **Annuler l'intervention** (motif obligatoire, gardé sur la fiche
  et dans le journal). Les mêmes boutons, plus « Remettre à planifier », sont sur la fiche de l'intervention.
- **Glisser-déposer** : vue Jour, vers une autre heure (au quart d'heure) et/ou un autre technicien ; vue Semaine,
  vers un autre jour et/ou un autre technicien (même heure). Seules les interventions « Planifiée » se déplacent ;
  « Annuler le déplacement » remet tout comme avant.
- Le **technicien est prévenu** (téléphone et/ou e-mail selon ses préférences) : nouvelle intervention, déplacée,
  retirée (confiée à un autre ou remise à planifier), annulée avec son motif ; jamais celui qui fait le changement
  (`planningNotices`, testé). Une intervention terminée ou dont la fiche est signée ne s'annule plus.

### Liens dans le menu (DocuSign, banque…)

Dans **Organisation → Liens dans le menu**, chaque société ajoute jusqu'à 10 liens vers ses outils en ligne
(nom + adresse en https). Ils apparaissent en bas du menu, avec ↗, et s'ouvrent dans un onglet à part (dans le
programme Windows : dans le navigateur) : ces sites refusent d'être affichés à l'intérieur d'un autre (DocuSign :
`frame-ancestors 'self'`). La version A.R.G.E. a d'office le lien DocuSign.

### Six éditions : un logiciel par secteur

Le même code donne six logiciels distincts. Chacun est construit et installé à part (son adresse, sa base de
données, ses clients) : un client de l'un ne voit jamais les autres métiers.

| `EDITION` | Logiciel | Pour qui | Couleur | Modules masqués |
|---|---|---|---|---|
| `TECH` | Itinéos | Techniciens itinérants (installation, SAV, entretien) | orange | — |
| `SECURITY` | Itinéos Vigie | Sécurité privée : rondes, levées de doute, main courante | bleu | stock, cartes SIM |
| `BAILIFF` | Itinéos Constat | Commissaires de justice : constats sur place | bordeaux | stock, véhicules, SIM, contrats |
| `EXPERTISE` | Itinéos Expertise | Experts d'assurance, diagnostiqueurs, géomètres | vert-bleu | stock, SIM, contrats |
| `RENTAL` | Itinéos Clés | États des lieux d'entrée et de sortie, inventaires | violet | stock, véhicules, SIM, habilitations |
| `SERVICES` | Itinéos Services | Nettoyage, anti-nuisibles, espaces verts, ascenseurs | vert | cartes SIM |

Ce qui change d'une édition à l'autre :

- **Le nom et l'apparence** : nom affiché, couleurs, icône et appli installable (`apps/web/vite.config.ts`,
  `EDITION_THEMES` dans `packages/shared`), nom dans les e-mails et les notifications.
- **Le vocabulaire**, en français et en anglais : « intervention » devient « mission », « visite » ou « prestation »,
  « technicien » devient « agent », « commissaire », « expert »… (`SECTOR_VOCABULARY`). Les types d'intervention
  prennent le nom du métier : Ronde, Levée de doute, Constat d'affichage, État des lieux d'entrée…
  (`SECTOR_KINDS`). Dans les autres langues, le vocabulaire des techniciens reste affiché.
- **Les modèles de fiches fournis** : quatre par métier, en français et en anglais
  (`apps/api/src/services/sector-templates.ts`), modifiables comme les autres depuis « Modèles de fiches ».
- **Les menus** : les modules inutiles au métier sont retirés du menu et leurs pages n'existent pas dans cette
  édition (`SECTOR_HIDDEN_MODULES`).

Le reste (organisation, droits, planning, fiches signées, PDF, portail client, appli terrain hors connexion) est
commun : une correction profite aux six logiciels. Toutes les sociétés d'une installation sont de son édition
(alignées au démarrage du serveur). Le nom de base (« Itinéos ») est défini à un seul endroit : `BRAND`.

**Lancer une autre édition en local**, à côté de celle des techniciens, sur sa propre base (PowerShell) :

```powershell
docker exec itineo-db-1 psql -U itineo -d postgres -c "CREATE DATABASE itineo_vigie"
cd apps/api
$env:EDITION='SECURITY'; $env:DATABASE_URL='postgres://itineo:itineo@localhost:5432/itineo_vigie'
npm run db:seed
$env:PORT='3001'; $env:WEB_ORIGIN='http://localhost:5174'; npx tsx watch src/index.ts
# Dans un autre terminal :
cd apps/web
$env:EDITION='SECURITY'; $env:WEB_PORT='5174'; $env:API_URL='http://localhost:3001'; npx vite
```

Puis http://localhost:5174. **En production** : `EDITION=SECURITY` dans `.env.production` (voir DEPLOIEMENT.md).

**Les fonctions propres à chaque métier** (`SECTOR_FEATURES` dans `packages/shared`, routes dans
`apps/api/src/routes/sector.ts`) :

| Édition | Fonction | Où |
|---|---|---|
| Vigie | **Points de passage** : chaque site a ses points, avec un QR code à imprimer et coller sur place. Pendant la ronde, l'agent les scanne ; l'heure est celle du téléphone (pointage possible sans réseau). Le rapport PDF liste chaque point, pointé ou non. | Fiche client (bureau), fiche de ronde (appli terrain) |
| Vigie | **Alerte SOS** de l'agent isolé : chef d'agence, planificateurs, direction et administrateurs sont prévenus aussitôt (téléphone et e-mail, quelles que soient leurs préférences), avec sa position et la mission en cours. Sans réseau : appel du 112. | Appli terrain |
| Constat, Expertise | **Photos probantes** : heure de prise de vue et empreinte SHA-256 de chaque photo, photos numérotées dans le procès-verbal, annexe des empreintes, « Fait à …, le … ». | PDF |
| Expertise | **Délais de l'assureur** : date limite de remise du rapport à la création, badge dans la liste, encart « Rapports à rendre » au tableau de bord. | Bureau |
| Clés | **Comparaison entrée / sortie** : pendant la sortie, chaque champ rappelle la valeur de l'état des lieux d'entrée du même logement (en orange si elle a changé) ; le PDF de sortie liste les différences. | Appli terrain, PDF |
| Services | **Registre des traitements** : produits biocides utilisés, repris des fiches anti-nuisibles signées, exportable en CSV. | Menu « Registre des traitements » |

Les textes de ces fonctions dans les PDF sont en français et en anglais (les autres langues reçoivent l'anglais).

**Données d'exemple** : `npm run db:seed` habille les données pour le métier de l'édition (`EDITION`) : clients,
motifs, devis, habilitations (cartes CNAPS, Certibiocide…), points de passage, dates limites, état des lieux
d'entrée déjà signé, traitements déjà faits (`apps/api/src/db/seed-sectors.ts`).

**Essayer les six logiciels sans terminal** : dossier `lanceurs` (voir `lanceurs/LISEZ-MOI.txt`). Un
double-clic sur un raccourci du dossier « Itinéos – essais » du Bureau démarre la base, le serveur et l'appli
de l'édition, sur sa propre base de démonstration et ses propres ports (5190 à 5195), puis ouvre le navigateur.

**Les cinq éditions en local (développement)** : une base par édition (`itineo_vigie`, `itineo_constat`, `itineo_expertise`,
`itineo_cles`, `itineo_services`) et une configuration de lancement par édition dans `.claude/launch.json`
(Vigie sur http://localhost:5174, Constat 5175, Expertise 5176, Clés 5177, Services 5178).

### Installateur Windows (chez le client)

`installeur\construire.ps1` fabrique `installeur\sortie\Itineos-Setup-<version>.exe` (environ 86 Mo) : Node.js,
PostgreSQL 16, Caddy et WinSW sont téléchargés (`installeur\telecharger.mjs`, empreintes vérifiées) et intégrés.
Il faut Inno Setup 6 (`winget install JRSoftware.InnoSetup`). Sur le PC du client, l'installateur :

- demande l'entreprise, le premier administrateur et, en option, l'adresse internet (https automatique) ;
- crée la base (127.0.0.1:5544, mots de passe et secret des sessions tirés au hasard) et le compte administrateur
  (mot de passe provisoire affiché une fois) ;
- installe trois services Windows : `ItineoBase` (PostgreSQL), `ItineoServeur` (Itinéos, 127.0.0.1:3000),
  `ItineoWeb` (Caddy, ports 80 et 443), ouvre ces ports dans le pare-feu et planifie une sauvegarde chaque nuit ;
- garde tout dans `C:\ProgramData\Itineo` (base, fichiers, sauvegardes, journaux, `services\itineo.env`) ;
- fait accepter la licence d'utilisation (`installeur\LICENCE.txt`, aussi pour le programme des postes).

Le serveur est livré **compilé** (`npm run build -w @itineo/api` : esbuild, `dist/index.mjs` et `dist/create-admin.mjs`,
compactés) : ni code source ni outils de développement chez le client. Chaque installateur et paquet contient
l'**empreinte** de ses fichiers (`installeur\empreinte.mts`, copiée aussi dans `installeur\sortie\empreinte-<version>.txt`) ;
l'agent de supervision envoie celle de l'installation et la console alerte si elle diffère (fichiers modifiés).

Relancer un installateur plus récent fait la mise à jour (données et réglages gardés). La désinstallation retire
les services mais garde les données. Mode d'emploi pour le client : `installeur\scripts\LISEZ-MOI.txt`.
Sans certificat de signature de code, Windows affiche un avertissement au lancement (« Exécuter quand même »).

### Itinéos sur les postes du bureau (poste/)

Un vrai programme Windows (`Itineos.exe`, Electron) qui affiche le serveur Itinéos de l'entreprise dans sa propre
fenêtre : menus en français, notifications Windows, lancement au démarrage de Windows (menu Itinéos), page claire
quand le serveur ne répond pas, liens extérieurs ouverts dans le navigateur, position / caméra / notifications
autorisées pour le serveur Itinéos seulement. Il ne contient pas Itinéos lui-même : les mises à jour du serveur
s'y voient aussitôt.

`poste\construire.ps1` fabrique `poste\sortie\Itineos-Poste-Setup-<version>.exe` (environ 110 Mo). L'installateur
s'installe sans droits d'administrateur et demande l'adresse du serveur (`http://localhost` sur le PC serveur,
`http://NOM-DU-PC-SERVEUR` ailleurs, ou l'adresse internet) ; elle se change ensuite par le menu Itinéos →
Adresse du serveur, ou par `Itineos.exe --serveur=…`. Dossier à part (hors des espaces de travail npm) : Electron
n'est téléchargé que pour lui. Essai sur le PC de développement : `cd poste`, `npm install`, `npm start`.

### Console de supervision (apps/supervision)

Un logiciel à part, pour l'éditeur : toutes les installations d'Itinéos vendues, leur état et les actions à distance.
Chaque Itinéos contient un **agent** (`apps/api/src/services/supervision.ts`), actif seulement si `SUPERVISION_URL`
est réglé. C'est toujours l'agent qui appelle la console (chaque minute), donc rien à ouvrir chez le client.

- **État** : en service / à surveiller / en panne / jamais connectée, avec la raison (plus de nouvelles depuis 5 min,
  base inaccessible, disque presque plein, sauvegarde de plus de 36 h, erreurs), historique des 24 dernières heures,
  version, activité du jour. Aucune donnée des clients du client n'est envoyée.
- **Bugs** : chaque erreur 500 du serveur (regroupée par endroit du code, sans le contenu de la requête) et chaque
  « Signaler un problème » d'un utilisateur (bouton dans le menu d'Itinéos). Un bug résolu qui revient est rouvert.
- **Actions** : récupérer les journaux, redémarrer, régler l'envoi des e-mails, **accès support** (l'administrateur du
  client accepte ou refuse dans Itinéos ; compte « Support » ouvert pour 1 à 8 h puis fermé), **prise en main du PC**
  (RustDesk, mot de passe à usage unique d'une heure, changé ensuite).
- **Mises à jour** : `installeur\construire.ps1 -Paquet [-Canal arge] -Publier <console>` construit le paquet et
  l'envoie ; la console le **signe** (Ed25519). Chaque installation suit un canal (`standard`, ou propre à un client,
  ex. `arge`) ; on choisit sa version, installée la nuit (3 h – 5 h) ou tout de suite : sauvegarde, remplacement,
  retour automatique à l'ancienne version et à la base d'avant si le serveur ne repart pas.
- **Inscription** : la console donne un code (7 jours, une fois) à saisir dans l'installateur d'Itinéos.

- **Sécurité** : double authentification des opérateurs (code à 6 chiffres d'une application d'authentification),
  **obligatoire** pour la prise en main, l'accès support, les mises à jour, les réglages, le redémarrage et la
  publication de versions. Clé de secours de signature (`npm run cles -w @itineo/supervision -- secours`), gardée hors
  de la console : les installations l'apprennent seules, et oublient l'ancienne clé principale si on la restaure.
- **Alertes par e-mail** (`SMTP_URL`) : panne, retour en service, nouveau bug, mise à jour ratée, résumé à 8 h.
  Historique dans « Alertes ». Choix par opérateur dans « Mon compte ».
- **Serveur RustDesk** de l'éditeur (Réglages) : envoyé aux installations, qui s'y règlent seules.
- **Mise en ligne** : `deploy/supervision` (Docker : console, https, serveur RustDesk, sauvegardes), mode d'emploi
  dans `deploy/supervision/LISEZ-MOI.md`. Essai de l'installateur sur une machine de test : `installeur/ESSAI.md`.

**Installateur Windows de la console** : `installeur/supervision/construire.ps1` fabrique
`Itineos-Supervision-Setup-<version>.exe` (base, console en service Windows sur le port 4000, https facultatif, sauvegarde
chaque nuit, raccourcis pour la clé de secours ; mode d'emploi : `installeur/supervision/scripts/LISEZ-MOI.txt`).

Lancement sur ce PC : raccourci « Itinéos Supervision » (http://localhost:4000, base `supervision` dans Docker).
Premier compte : `npm run operator:create -w @itineo/supervision -- --email … --name "…"`.
**La clé de signature** (`apps/supervision/donnees/cle-signature.pem`) est à sauvegarder : sans elle, les installations
refuseront toute nouvelle version. Pour suivre de vrais clients, la console doit être mise en ligne (adresse https).

### Version A.R.G.E.

L'édition Itinéos (`TECH`) préparée pour A.R.G.E. (alarme, vidéoprotection, télésurveillance, défibrillateurs), à
partir de ses documents papier (dossier `app tech\docs viere arge`) :

- **la société** : adresse du siège (Quetigny), SIRET, capital, agréments CNAPS des quatre établissements et mention
  de l'article L 612-14 du CSI en pied de chaque document (le pied de page passe sur plusieurs lignes s'il le faut) ;
- **le logo** (`apps/api/assets/arge/logo.png`, extrait de la fiche d'intervention 2025) : menu, appli terrain,
  espace client, en-tête des PDF ;
- **les quatre agences** et leur dépôt : Dijon – Quetigny (21), Nancy (54), Lille (59), Fontainebleau (77) ;
- **ses documents** (`apps/api/src/db/arge/templates.ts`) : la « Fiche d'intervention technique » pour toutes les
  interventions ; à choisir sur l'intervention, « Consignes de télésurveillance (Teles) » et les deux « Dossier
  technique – bon de sortie » (télésurveillance, vidéoprotection). Un document choisi ainsi porte son nom en titre du PDF ;
- **le catalogue** des deux bons de sortie (`apps/api/src/db/arge/catalogue.ts`) : 131 références classées par
  famille (centrales Zeus / Hestia, SPC, RSI, contrôle d'accès, générateurs de brouillard, vidéo HDCVI et IP,
  consommables, défibrillateur). Les prix ne figurent pas sur les bons : à compléter dans Stock → Articles.

Les personnes, les clients, les interventions et le stock sont **fictifs** (comptes `@arge.test`, mot de passe
`demo1234`) : ils servent à essayer. Lancement : raccourci « Itinéos ARGE » (http://localhost:5196), ou
`npm run db:seed-arge -- --reset -w @itineo/api` sur une base vide.

---

## 2. Installer et lancer (sur ton ordinateur)

### Prérequis

- [Node.js](https://nodejs.org) version 20 ou plus
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (pour la base de données et la boîte mail de test)

### Étapes

```bash
# 1. Installer les dépendances
npm install

# 2. Démarrer PostgreSQL et Mailpit
docker compose up -d

# 3. Configuration
cp .env.example apps/api/.env

# 4. Créer les tables et les données d'exemple
npm run db:seed

# 5. Lancer l'API (terminal 1)
npm run dev:api

# 6. Lancer l'appli web (terminal 2)
npm run dev:web
```

Ouvre ensuite **http://localhost:5173**.

- Les e-mails envoyés (fiches PDF, liens « mot de passe oublié ») arrivent dans **Mailpit** : http://localhost:8025
- Les liens « mot de passe oublié » pointent vers la première adresse de `WEB_ORIGIN` (dans `apps/api/.env`) :
  en production, mettez-y l'adresse publique de l'appli
- Pour tester sur une tablette du même réseau Wi-Fi : http://ADRESSE-IP-DE-TON-PC:5173

### Comptes d'exemple (mot de passe : `demo1234`)

| Compte | Rôle | Ce qu'il voit |
|---|---|---|
| `admin@exemple.test` | Administrateur du groupe | Tout : France, Belgique, Royaume-Uni |
| `direction.fr@exemple.test` | Direction France | Les 4 agences françaises, tableau de bord |
| `chef.est@exemple.test` | Chef d'agence Est | Agence Est uniquement |
| `planning.est@exemple.test` | Planificateur Est | Planning de l'agence Est |
| `tech1.est@exemple.test` | Technicien Est | Sa journée : 4 interventions aujourd'hui |
| `tech.uk@exemple.test` | Technician UK | Appli et fiches en anglais |
| `contact.durand@client.test` | Client « Cabinet Durand » | **Espace client** : http://localhost:5173/portail |

**Parcours à essayer :**
1. Connecte-toi en `planning.est@…`, va dans **Planning**, planifie une intervention « À planifier ».
2. Connecte-toi en `tech1.est@…` (idéalement sur tablette), ouvre la fiche du Cabinet Durand, remplis, dicte, signe, envoie.
3. Regarde l'e-mail et le PDF dans Mailpit.
4. Connecte-toi en `direction.fr@…` et ouvre le **Tableau de bord**.

### Tests

```bash
npm test                  # règles : droits, modèles de fiches, pré-remplissage, photos, mots de passe (sans base)
npm run test:integration  # le vrai serveur sur une base de test séparée « itineo_test » (docker compose doit tourner)
npm run typecheck
```

Les tests d'intégration recréent entièrement la base `itineo_test` à chaque lancement. Ils ne touchent jamais à la base
de développement `itineo`.

### Mettre en ligne

Voir **[DEPLOIEMENT.md](DEPLOIEMENT.md)** : serveur en Europe, HTTPS automatique, sauvegardes quotidiennes, création
du premier compte administrateur, mises à jour et restauration.

---

## 3. Faire évoluer le logiciel

### Ajouter une colonne ou une table

1. Modifie `apps/api/src/db/schema.ts` (la description utilisée par le code).
2. Crée un **nouveau** fichier `apps/api/migrations/0002_ce_que_tu_fais.sql` avec le SQL correspondant.
   Ne modifie jamais un fichier de migration déjà appliqué.
3. `npm run db:migrate` (c'est aussi fait automatiquement au démarrage de l'API).

### Ajouter une route à l'API

Inspire-toi de `apps/api/src/routes/clients.ts` : valider l'entrée avec Zod, charger la ressource,
vérifier le droit avec `can(...)`, écrire, tracer avec `audit(...)`.

### Ajouter une permission ou un rôle

`packages/shared/src/index.ts` : ajoute la permission à `PERMISSIONS` et aux rôles concernés dans `ROLE_PERMISSIONS`.
Pour un nouveau rôle, il faut aussi une migration SQL (`ALTER TYPE role ADD VALUE '...'`).

### Ajouter un pays

Depuis l'écran **Organisation** (compte administrateur) : nouvelle société avec son code pays, sa devise, sa langue,
son fuseau horaire et son préfixe de numérotation. Les fiches anglaises sont utilisées automatiquement si la langue
commence par `en`.

### Langues de l'interface

16 langues : français, anglais, espagnol, allemand, italien, portugais, néerlandais, polonais, roumain, turc, russe,
arabe (écran de droite à gauche), hindi, chinois, japonais et coréen. Chacun choisit la sienne dans **Mon compte**
(bureau, appli terrain et espace client) ; la liste est `UI_LOCALES` dans `packages/shared`.

Les documents envoyés aux clients (devis, factures, avoirs, fiches d'intervention, e-mails, e-mails de l'espace client)
sont aussi rédigés dans ces 16 langues : celle choisie sur la fiche du client (« Langue des documents »), sinon celle
de la société. Textes : `apps/api/src/services/doc-i18n.ts`. Les PDF utilisent les polices Noto
(`apps/api/assets/fonts`, voir son LISEZ-MOI) pour écrire toutes les écritures ; l'arabe s'écrit de droite à gauche
(`services/pdf-text.ts`). Les mentions de pénalités de retard suivent le pays de la société (texte légal français
traduit pour une société française). Les champs des modèles de fiches restent tels que la société les a écrits.
L'e-mail de mot de passe oublié des salariés part en anglais pour les langues autres que le français.

## Messagerie interne

Menu **Messagerie** (bureau et appli terrain) : conversations à deux ou de groupe entre toutes les personnes du groupe
d'entreprises. Une conversation à deux est unique pour une paire ; un groupe se nomme, s'agrandit, se quitte
(avec un message « X a ajouté Y » visible de tous). On peut corriger ou retirer ses propres messages.
Les nouveaux messages arrivent en quelques secondes (l'écran relit le serveur) et une pastille indique les messages
non lus. Depuis l'annuaire, « Écrire » ouvre la conversation avec la personne.

**Photos et fichiers** : le trombone joint une photo (réduite comme sur les fiches), un PDF, un document bureautique
(Word, Excel, PowerPoint, LibreOffice), une vidéo MP4/MOV, un texte ou un zip, 10 Mo au plus. On peut aussi coller une
image. Le contenu est vérifié par le serveur (pas de HTML ni de SVG) ; seuls les membres de la conversation y ont
accès ; un message retiré efface son fichier. Fichiers rangés dans `STORAGE_DIR/messages`.

## Notices et procédures

Menu **Notices et procédures** (bouton **Notices** dans l'appli terrain) : notices fabricants, procédures internes,
schémas, consignes de sécurité, formulaires. Un document est un fichier (PDF, photo, bureautique, vidéo) et/ou un
lien, avec des mots-clés (marque, modèle) pour le retrouver sur le terrain.

- Le bureau (droit « procedure.manage » : direction, chefs d'agence, planificateurs) **publie** directement, pour tout
  le groupe, une société ou une agence.
- Un technicien **propose** un document : il reste « en attente » ; le bureau le **valide** ou le **refuse** avec un
  motif (le technicien le corrige et le renvoie). Une pastille dans le menu compte les documents à valider.
- Un document déjà ouvert reste lisible **sans réseau** (copie gardée sur l'appareil).

## Cartes SIM

Menu **Cartes SIM** (bureau ; droits « sim.read » / « sim.write ») : inventaire des cartes (ICCID, numéro, opérateur,
forfait, appareil, client et site) et suivi de l'activation : en stock → à activer → activation demandée → active
(→ suspendue, résiliée). L'activation se fait **sur le site du prestataire** : son adresse se règle par société
(direction) ; le bouton « Activer chez le prestataire » copie le numéro de carte et ouvre ce site. Ajout en lot :
une carte par ligne (on peut coller une colonne d'Excel), doublons ignorés. Aucun identifiant du prestataire n'est
enregistré. Une liaison automatique avec le prestataire pourra venir plus tard.

## Statistiques

Menu **Statistiques** (droit « stats.read ») : jusqu'à 6 indicateurs à la fois, regroupés par technicien, agence,
société, client, ville, type, priorité, statut, origine, auteur, année, mois, semaine, jour, jour de la semaine ou
heure ; un second critère donne un tableau croisé. Période au choix, filtres technicien / type / priorité, toutes
les sociétés du groupe. Graphique + tableau triable, export CSV, rapports tout prêts, et « Enregistrer ce rapport »
(gardé sur l'appareil).

Indicateurs : interventions (terminées, à reprendre, annulées, sans technicien, urgentes), clients différents, pièces
posées, heures de travail et de trajet, durée moyenne sur place, délai d'intervention, arrivées à l'heure (15 min de
tolérance), retard moyen, réglé au premier passage, fiches signées par le client, chiffre d'affaires HT (avoirs
déduits), factures, devis envoyés / acceptés / taux / montant. Chacun suit les droits de lecture de sa source :
sans accès aux factures, pas de chiffre d'affaires. Calcul : `apps/api/src/services/stats.ts`.

## Suggestion d'attribution

À activer société par société (**Organisation → Planification**, désactivée par défaut). Pour une intervention à
planifier, Itinéos classe les techniciens de l'agence (note sur 100, avec les raisons) :

- **distance** : position en direct du véhicule (si le technicien partage sa position, pour aujourd'hui), sinon ses
  autres interventions de la journée ;
- **charge** de la journée et **chevauchement** avec le créneau prévu ;
- **matériel à prévoir** (sur la page de l'intervention, plus les bons de sortie en préparation) comparé au **stock
  de son véhicule** ;
- **habilitations** exigées (un technicien non habilité passe derrière).

Une urgence privilégie le plus proche, une intervention ordinaire le moins chargé. Ce n'est qu'une suggestion :
le planificateur choisit (dans le planning, « Planifier », ou sur la page de l'intervention).

Coordonnées des sites : prises la première fois qu'un technicien signale « Je suis sur place » avec une position
précise, ou (option) trouvées par le service public d'adresses de l'IGN (France, gratuit) — l'adresse du site est
alors envoyée à ce service. Calcul : `apps/api/src/services/assign.ts`.

## Annuaire

Menu **Annuaire** :

- **Équipe** : toutes les personnes, avec leur rôle, leur agence et leur numéro (chacun le saisit dans **Mon compte**) ;
- **Contacts utiles** : fournisseurs, sous-traitants, assistance des fabricants, urgences, administrations…, visibles
  par tout le groupe, une société ou une agence. Le droit « directory.write » (direction, chefs d'agence,
  planificateurs, commerciaux, comptabilité) permet de les gérer dans son périmètre ; les techniciens consultent ;
- **Sociétés et agences** : standards, e-mails et adresses.

Recherche par nom, numéro ou métier, filtre par société ou agence ; un numéro s'appelle d'un toucher sur téléphone.

## Sur le terrain : GPS, scanner, matériel difficile à trouver, planning de l'équipe

- **« Y aller »** (journée du technicien et fiche) : ouvre l'itinéraire vers le site dans **Waze** par défaut ; la flèche ▾
  permet de choisir Google Maps, Plans (iPhone) ou une autre appli (Android). Le choix est retenu sur l'appareil.
- **Scanner** (bouton ▦) : lit un code-barres ou un QR code avec l'appareil photo, dans les champs texte des fiches, le
  n° de série d'un matériel, la recherche client (retrouver un client par le n° de série scanné). Lecteur du navigateur
  quand il existe (Android), sinon la bibliothèque ZXing (iPhone).
- **Matériel difficile à repérer** : sur la fiche client, chaque matériel peut porter une indication (« dans le faux
  plafond du couloir ») montrée en évidence au technicien, avec tout le matériel du site qui en a une.
- **Planning de l'équipe** (bouton **Équipe** de l'appli terrain, lecture seule) : le bureau choisit pour chaque
  technicien (Planning → **Ce que voient les techniciens**) : son planning seulement (par défaut), toute son agence, ou
  les collègues choisis. Seuls l'heure, le client, la ville et le type sont montrés ; son propre nom est surligné.
- **Copie au bureau** à l'envoi d'une fiche (case retenue sur l'appareil, adresse de l'agence sinon de la société) ; le
  technicien reçoit toujours une copie et **le client qui répond écrit au technicien** (copies cachées au client).

## Recherche client avancée

Sans tenir compte des accents ni des majuscules ; téléphone écrit de n'importe quelle façon (06 12…, 06.12…,
+33 6 12…) ; dans les contacts, les sites et le matériel installé. Critère au choix (nom, ville, code postal,
téléphone, e-mail, n° d'abonné, n° de série, matériel, notes), **filtre par département** (54, 2A, 974…) et tri par
nom, ville, code postal ou plus récents. Le **n° d'abonné** se saisit sur la fiche client.

## Document « Consignes de télésurveillance »

Modèle fourni avec Itinéos (français et anglais) : site, type de site, transmetteur, disjoncteur, 6 responsables à
prévenir (jour, nuit, week-end, clés), ordre d'appel, rondes, horaires, mot de passe de levée de doute, commentaires, et
signature du client. Il n'est jamais choisi automatiquement : sur l'intervention (création ou page), **Document à
remplir** permet de prendre ce modèle ou n'importe quel autre, tant que la fiche n'est pas commencée. Le PDF porte
alors le titre du document.

## Rester connecté et notifications

- **Rester connecté sur cet appareil** (coché par défaut) : la session dure un an et repart à chaque ouverture ; sinon
  12 h. **Mon compte → Déconnecter tous mes autres appareils** ferme les sessions des autres appareils.
- **Notifications** (Mon compte) : sur le téléphone ou l'ordinateur, même Itinéos fermé (Web Push, gratuit), et/ou par
  e-mail, au choix pour : nouveaux messages, intervention attribuée ou déplacée (technicien), document à valider
  (bureau). Sur iPhone, il faut d'abord ajouter Itinéos à l'écran d'accueil. Une déconnexion désabonne l'appareil.
  Clés du serveur : `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY`, sinon créées et gardées dans `STORAGE_DIR/vapid.json`.

### Ajouter ou modifier un texte

Les écrans sont écrits en français, chaque texte passant par `t('…')` (`apps/web/src/i18n.ts`), avec le texte
français comme clé :

- anglais : `apps/web/src/i18n.en.ts` (inclus dans l'appli) ;
- autres langues : `apps/web/src/locales/<langue>.json`, chargé seulement pour qui utilise cette langue ;
- appli terrain : `apps/web/src/tech/i18n.ts` (français, anglais) et `tech/i18n.more.ts` (autres langues), inclus dans
  l'appli pour fonctionner sans réseau.

`npm test` signale tout texte (ou message d'erreur du serveur) qui manque dans une langue ou dont les variables
(`{n}`, `{date}`…) ne correspondent pas. Un texte manquant s'affiche en français, jamais vide.

## Planning

Trois vues, choisies en haut de la page (la dernière est retenue) :

- **Jour** : ligne de temps de 7 h à 19 h par technicien ;
- **Semaine** : du lundi au dimanche, les interventions de chaque technicien jour par jour ;
- **Mois** : une case par jour et par technicien, avec le nombre d'interventions et une couleur selon la charge
  (moins de 4 h, 4 à 8 h, plus de 8 h). Un clic sur une case ou sur un jour ouvre la journée.

Avec **Toutes les agences**, les techniciens sont regroupés par agence. Les heures et le nombre d'interventions
de chacun sont totalisés sur la période ; une ligne « Sans technicien » montre ce qui est planifié sans être
attribué. Un filtre retrouve un technicien par son nom ou sa compétence.

---

## 4. API (résumé)

| Méthode | Route | Usage |
|---|---|---|
| POST | `/api/auth/login` | Connexion, renvoie un jeton |
| POST | `/api/auth/forgot` | Mot de passe oublié : envoie un lien par e-mail (valable 1 h, une seule fois) |
| POST | `/api/auth/reset` | Nouveau mot de passe à partir du lien reçu |
| POST | `/api/auth/change-password` | Changement par l'utilisateur connecté (ferme ses autres sessions) |
| GET | `/api/me` | Profil, rôles, sociétés et agences visibles |
| PATCH | `/api/me` | Langue de l'interface choisie par l'utilisateur |
| GET/POST | `/api/org`, `/api/org/companies`, `/api/org/companies/:id/agencies` | Organisation |
| GET/POST | `/api/users` | Comptes et rôles |
| GET/POST/PATCH | `/api/clients`, `/api/clients/:id` | Clients |
| POST | `/api/clients/:id/sites`, `/api/sites/:id/equipments` | Sites et équipements |
| GET/POST/PATCH | `/api/interventions`, `/api/interventions/:id` | Interventions et planning |
| POST | `/api/interventions/:id/status` | Le technicien part / arrive |
| GET/PUT | `/api/interventions/:id/report` | Ouvrir (pré-remplie) / enregistrer la fiche |
| POST | `/api/interventions/:id/report/sign` | Signatures (heure de l'appareil acceptée si plausible) |
| POST/PATCH/DELETE | `/api/interventions/:id/report/photos[/:photoId]` | Photos : ajout (sans doublon), légende, suppression |
| GET | `/api/interventions/:id/report/photos/:photoId` | Image d'une photo |
| POST | `/api/interventions/:id/report/send` | PDF, archivage, e-mail, clôture |
| GET | `/api/interventions/:id/report/pdf` | Télécharger le PDF |
| GET/POST/PUT | `/api/templates` | Modèles de fiches |
| GET | `/api/dashboard` | Indicateurs par agence |
| GET/POST | `/api/clients/:id/portal-users` | Accès d'un client à son espace : liste, invitation (ou renvoi) |
| PATCH | `/api/portal-users/:id` | Couper ou rétablir un accès |
| GET/PUT | `/api/me/location-sharing` | Partage de position du technicien (activer, arrêter) |
| POST | `/api/fleet/positions` | Positions envoyées par le téléphone du conducteur (par lots) |
| GET | `/api/fleet/map`, `/api/fleet/vehicles/:id/track` | Carte du parc, trajet d'un véhicule sur une journée |
| POST | `/api/portal/auth/login`, `/activate`, `/forgot` | Espace client : connexion, choix du mot de passe, oubli |
| GET | `/api/portal/me`, `/interventions`, `/quotes`, `/invoices`, `/contracts` | Espace client : ses données (et les PDF) |
| POST | `/api/portal/quotes/:id/decision`, `/api/portal/requests` | Espace client : réponse à un devis, demande d'intervention |
| POST | `/api/conversations/:id/messages` | Message (texte, et/ou fichier en data URL, 10 Mo) |
| GET | `/api/messages/:id/attachment` | Fichier joint d'un message |
| GET/POST/PATCH/DELETE | `/api/procedures[/:id]` | Notices et procédures (publier, proposer, modifier) |
| POST | `/api/procedures/:id/review` | Valider ou refuser une proposition |
| GET | `/api/procedures/:id/file`, `/api/procedures/pending-count` | Fichier d'un document ; nombre à valider |
| GET/POST/PATCH/DELETE | `/api/sims[/:id]`, `/api/sims/import`, `/api/sims/:id/status`, `/api/sims/settings` | Cartes SIM |
| GET | `/api/stats/options`, `/api/stats` | Statistiques à la carte |
| PATCH | `/api/org/companies/:id/planning` | Activer la suggestion d'attribution, la localisation des adresses |
| PUT | `/api/interventions/:id/needed-parts` | Matériel à prévoir |
| GET | `/api/interventions/:id/suggestions` | Techniciens classés pour une intervention |
| POST | `/api/auth/refresh`, `/api/auth/logout-all` | Prolonger la session (« Rester connecté »), déconnecter les autres appareils |
| GET | `/api/clients?q=&field=&dept=&sort=` | Recherche client avancée |
| GET | `/api/team-planning` | Planning de l'équipe vu par le technicien |
| GET/PUT | `/api/planning-visibility[/:userId]` | Ce que chaque technicien voit du planning (bureau) |
| GET/POST/PATCH | `/api/notifications/config`, `/subscribe`, `/unsubscribe`, `/prefs`, `/test` | Notifications |

---

## 5. Ce qui reste à faire (dans l'ordre que je conseille)

**Avant un premier client**
- Mise en ligne réelle : choisir le serveur et le domaine, puis suivre [DEPLOIEMENT.md](DEPLOIEMENT.md)
  (tout est prêt et testé)
- Tester l'appli terrain sur les vraies tablettes : appareil photo, dictée, journée sans réseau

**Ensuite, module par module**
- Espace client : photos jointes à une demande, paiement des factures en ligne
- Connexion unique (SSO) pour les grands comptes
