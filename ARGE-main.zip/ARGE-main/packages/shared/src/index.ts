/**
 * Code partagé entre l'API et l'appli web :
 * rôles, permissions, statuts et format des modèles de fiches.
 */

// ─── Rôles et permissions ────────────────────────────────────────────────

export const ROLES = [
  'GROUP_ADMIN',
  'DIRECTOR',
  'AGENCY_MANAGER',
  'PLANNER',
  'SALES',
  'ACCOUNTANT',
  'TECHNICIAN',
  'VIEWER',
] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABELS: Record<Role, string> = {
  GROUP_ADMIN: 'Administrateur du groupe',
  DIRECTOR: 'Direction',
  AGENCY_MANAGER: "Chef d'agence",
  PLANNER: 'Planificateur',
  SALES: 'Commercial',
  ACCOUNTANT: 'Comptabilité',
  TECHNICIAN: 'Technicien',
  VIEWER: 'Lecture seule',
};

export const PERMISSIONS = [
  'org.read',
  'org.write',
  'user.read',
  'user.write',
  'client.read',
  'client.write',
  'intervention.read',
  'intervention.read.own',
  'intervention.write',
  'intervention.assign',
  'report.read',
  'report.write.own',
  'template.read',
  'template.write',
  'dashboard.read',
  'quote.read',
  'quote.write',
  'contract.read',
  'contract.write',
  'invoice.read',
  'invoice.write',
  'stock.read',
  'stock.read.own',
  'stock.write',
  'certification.read',
  'certification.read.own',
  'certification.write',
  'fleet.read',
  'fleet.read.own',
  'fleet.write',
  'directory.write',
  'procedure.manage',
  'stats.read',
  'sim.read',
  'sim.write',
] as const;
export type Permission = (typeof PERMISSIONS)[number];

/**
 * Ce que chaque rôle a le droit de faire.
 * Le PÉRIMÈTRE (tout le groupe, une société ou une agence) est porté par
 * l'affectation du rôle à l'utilisateur, pas par le rôle lui-même.
 */
export const ROLE_PERMISSIONS: Record<Role, readonly Permission[]> = {
  GROUP_ADMIN: PERMISSIONS,
  DIRECTOR: [
    'org.read', 'user.read', 'client.read', 'client.write', 'intervention.read',
    'intervention.write', 'intervention.assign', 'report.read', 'template.read', 'dashboard.read',
    'quote.read', 'quote.write', 'contract.read', 'contract.write', 'invoice.read', 'invoice.write',
    'stock.read', 'stock.write', 'certification.read', 'certification.write', 'fleet.read', 'fleet.write', 'directory.write',
    'procedure.manage', 'stats.read', 'sim.read', 'sim.write',
  ],
  AGENCY_MANAGER: [
    'org.read', 'user.read', 'user.write', 'client.read', 'client.write', 'intervention.read',
    'intervention.write', 'intervention.assign', 'report.read', 'template.read', 'dashboard.read',
    'quote.read', 'quote.write', 'contract.read', 'contract.write', 'invoice.read', 'invoice.write',
    'stock.read', 'stock.write', 'certification.read', 'certification.write', 'fleet.read', 'fleet.write', 'directory.write',
    'procedure.manage', 'stats.read', 'sim.read', 'sim.write',
  ],
  PLANNER: [
    'org.read', 'client.read', 'client.write', 'intervention.read', 'intervention.write',
    'intervention.assign', 'report.read', 'template.read', 'quote.read', 'contract.read',
    'stock.read', 'stock.write', 'certification.read', 'fleet.read', 'fleet.write', 'directory.write',
    'procedure.manage', 'stats.read', 'sim.read', 'sim.write',
  ],
  SALES: [
    'org.read', 'client.read', 'client.write', 'intervention.read', 'template.read',
    'quote.read', 'quote.write', 'contract.read', 'contract.write', 'invoice.read', 'stock.read', 'directory.write',
    'sim.read', 'sim.write',
  ],
  ACCOUNTANT: [
    'org.read', 'client.read', 'intervention.read', 'report.read', 'dashboard.read', 'quote.read', 'contract.read',
    'invoice.read', 'invoice.write', 'stock.read', 'directory.write', 'stats.read', 'sim.read',
  ],
  // Le technicien voit le stock de SON véhicule (pour choisir les pièces posées)
  TECHNICIAN: [
    'org.read', 'client.read', 'intervention.read.own', 'report.write.own', 'template.read', 'stock.read.own',
    'certification.read.own', 'fleet.read.own',
  ],
  VIEWER: [
    'org.read', 'client.read', 'intervention.read', 'report.read', 'dashboard.read', 'quote.read', 'contract.read',
    'invoice.read', 'stock.read', 'certification.read', 'fleet.read', 'stats.read', 'sim.read',
  ],
};

// ─── Secteurs d'activité (déclinaisons du logiciel) ──────────────────────
// Chaque société choisit son secteur : il fixe le nom affiché, le vocabulaire (« mission » au lieu
// d'« intervention »…), les modules visibles et les modèles de fiches fournis. Les données ne changent pas :
// changer de secteur ne fait que changer l'habillage.

/** Nom de base du logiciel (un seul endroit à modifier en cas de changement de nom) */
export const BRAND = 'Itinéos';

export const SECTORS = ['TECH', 'SECURITY', 'BAILIFF', 'EXPERTISE', 'RENTAL', 'SERVICES'] as const;
export type Sector = (typeof SECTORS)[number];

export const SECTOR_LABELS: Record<Sector, string> = {
  TECH: 'Techniciens itinérants',
  SECURITY: 'Sécurité privée',
  BAILIFF: 'Commissaires de justice',
  EXPERTISE: 'Expertise et diagnostic',
  RENTAL: 'États des lieux',
  SERVICES: 'Multiservices',
};

/** Nom de la déclinaison, ajouté au nom de base : « Itinéos Vigie » */
export const SECTOR_EDITIONS: Record<Sector, string> = {
  TECH: '',
  SECURITY: 'Vigie',
  BAILIFF: 'Constat',
  EXPERTISE: 'Expertise',
  RENTAL: 'Clés',
  SERVICES: 'Services',
};

export function productName(sector: Sector | null | undefined): string {
  const edition = SECTOR_EDITIONS[sector ?? 'TECH'] ?? '';
  return edition ? `${BRAND} ${edition}` : BRAND;
}

/**
 * Identité de chaque édition : couleurs de l'interface et de l'icône, description de l'appli installée.
 * Chaque édition est un logiciel à part (sa propre installation, son adresse, sa base) construit
 * à partir du même code : voir EDITION dans README.md.
 */
export const EDITION_THEMES: Record<Sector, { accent: string; accentText: string; ink: string; ink2: string; description: string }> = {
  TECH: { accent: '#C2410C', accentText: '#9A3412', ink: '#14181F', ink2: '#232934', description: 'Interventions, planning et fiches pour techniciens itinérants' },
  SECURITY: { accent: '#2563EB', accentText: '#1D4ED8', ink: '#0F1A2E', ink2: '#1B2A44', description: 'Rondes, levées de doute et rapports pour la sécurité privée' },
  BAILIFF: { accent: '#9F1239', accentText: '#881337', ink: '#1F1418', ink2: '#2E1F25', description: 'Constats sur place, photos et procès-verbaux pour commissaires de justice' },
  EXPERTISE: { accent: '#0F766E', accentText: '#115E59', ink: '#0E1F1D', ink2: '#1A2E2B', description: 'Missions d’expertise, diagnostics et rapports' },
  RENTAL: { accent: '#7C3AED', accentText: '#6D28D9', ink: '#17132A', ink2: '#251F3D', description: 'États des lieux d’entrée et de sortie, signés sur place' },
  SERVICES: { accent: '#15803D', accentText: '#166534', ink: '#10201A', ink2: '#1B2F26', description: 'Passages, prestations et traitements pour les entreprises de services' },
};

export function isSector(s: unknown): s is Sector {
  return typeof s === 'string' && (SECTORS as readonly string[]).includes(s);
}

/** Modules qu'on peut masquer selon le métier (le reste est commun à tous) */
export const MODULES = ['quotes', 'contracts', 'invoices', 'stock', 'fleet', 'sims', 'certifications'] as const;
export type Module = (typeof MODULES)[number];

/** Modules masqués par secteur : un commissaire de justice n'a ni stock ni cartes SIM */
export const SECTOR_HIDDEN_MODULES: Record<Sector, readonly Module[]> = {
  TECH: [],
  SECURITY: ['stock', 'sims'],
  BAILIFF: ['stock', 'fleet', 'sims', 'contracts'],
  EXPERTISE: ['stock', 'sims', 'contracts'],
  RENTAL: ['stock', 'fleet', 'sims', 'certifications'],
  SERVICES: ['sims'],
};

export function moduleEnabled(sector: Sector | null | undefined, module: Module): boolean {
  return !SECTOR_HIDDEN_MODULES[sector ?? 'TECH']?.includes(module);
}

/**
 * Fonctions propres à un métier (en plus du socle commun) :
 *  - checkpoints : points de passage à pointer par QR code pendant les rondes
 *  - sos : bouton d'alerte de l'agent isolé, qui prévient aussitôt ses responsables
 *  - photoProof : photos horodatées avec leur empreinte numérique (SHA-256) dans le procès-verbal
 *  - deadlines : date limite de remise du rapport (délais de l'assureur), suivie au tableau de bord
 *  - checkinComparison : l'état des lieux de sortie reprend celui d'entrée et signale les différences
 *  - treatmentRegister : registre des produits biocides utilisés, exportable
 */
export const FEATURES = ['checkpoints', 'sos', 'photoProof', 'deadlines', 'checkinComparison', 'treatmentRegister'] as const;
export type Feature = (typeof FEATURES)[number];

export const SECTOR_FEATURES: Record<Sector, readonly Feature[]> = {
  TECH: [],
  SECURITY: ['checkpoints', 'sos'],
  BAILIFF: ['photoProof'],
  EXPERTISE: ['deadlines', 'photoProof'],
  RENTAL: ['checkinComparison'],
  SERVICES: ['treatmentRegister'],
};

export function featureEnabled(sector: Sector | null | undefined, feature: Feature): boolean {
  return SECTOR_FEATURES[sector ?? 'TECH']?.includes(feature) ?? false;
}

/** Passage d'un agent à un point de contrôle (QR code scanné), heure de l'appareil */
export interface CheckpointScan { checkpointId: string; name: string; at: string }

/** Date limite : bientôt (7 jours) ou dépassée */
export const DEADLINE_WARNING_DAYS = 7;
export function deadlineState(dueDate: string | null | undefined, today: string, done = false): DueState {
  if (!dueDate || done) return 'NONE';
  if (dueDate < today) return 'OVERDUE';
  return daysBetween(today, dueDate) <= DEADLINE_WARNING_DAYS ? 'SOON' : 'OK';
}

/**
 * Mots du métier. L'interface est écrite avec « intervention » et « technicien » ; pour un autre secteur,
 * ces mots sont remplacés à l'affichage (français et anglais) par ceux du métier.
 * Les mots de remplacement français sont du même genre (féminin pour l'intervention, masculin pour le
 * technicien) : les accords de la phrase restent justes. L'élision (« l'agent ») est gérée au remplacement.
 */
export interface SectorWords {
  /** Remplace « intervention » : [singulier, pluriel] */
  job: [string, string];
  /** Remplace « technicien » : [singulier, pluriel] */
  worker: [string, string];
}

export const SECTOR_VOCABULARY: Record<Sector, { fr: SectorWords; en: SectorWords } | null> = {
  TECH: null,
  SECURITY: { fr: { job: ['mission', 'missions'], worker: ['agent', 'agents'] }, en: { job: ['assignment', 'assignments'], worker: ['officer', 'officers'] } },
  BAILIFF: { fr: { job: ['mission', 'missions'], worker: ['commissaire', 'commissaires'] }, en: { job: ['assignment', 'assignments'], worker: ['bailiff', 'bailiffs'] } },
  EXPERTISE: { fr: { job: ['mission', 'missions'], worker: ['expert', 'experts'] }, en: { job: ['assignment', 'assignments'], worker: ['surveyor', 'surveyors'] } },
  RENTAL: { fr: { job: ['visite', 'visites'], worker: ['chargé d’EDL', 'chargés d’EDL'] }, en: { job: ['visit', 'visits'], worker: ['inventory clerk', 'inventory clerks'] } },
  SERVICES: { fr: { job: ['prestation', 'prestations'], worker: ['intervenant', 'intervenants'] }, en: { job: ['service visit', 'service visits'], worker: ['operative', 'operatives'] } },
};

/** Types d'intervention vus par chaque métier (en français et en anglais) */
export const SECTOR_KINDS: Record<Sector, Record<'fr' | 'en', Record<InterventionKind, string>> | null> = {
  TECH: null,
  SECURITY: {
    fr: { INSTALLATION: 'Mise en place / audit de site', SAV: 'Levée de doute', MAINTENANCE: 'Ronde', OTHER: 'Incident / main courante' },
    en: { INSTALLATION: 'Site setup / audit', SAV: 'Alarm response', MAINTENANCE: 'Patrol', OTHER: 'Incident / logbook' },
  },
  BAILIFF: {
    fr: { INSTALLATION: 'Constat de travaux', SAV: 'Constat de dégâts', MAINTENANCE: 'Constat d’affichage', OTHER: 'Autre constat' },
    en: { INSTALLATION: 'Works report', SAV: 'Damage report', MAINTENANCE: 'Notice posting report', OTHER: 'Other report' },
  },
  EXPERTISE: {
    fr: { INSTALLATION: 'Diagnostic immobilier', SAV: 'Expertise sinistre', MAINTENANCE: 'Visite de contrôle', OTHER: 'Autre mission' },
    en: { INSTALLATION: 'Property survey', SAV: 'Claim inspection', MAINTENANCE: 'Inspection visit', OTHER: 'Other assignment' },
  },
  RENTAL: {
    fr: { INSTALLATION: 'État des lieux d’entrée', SAV: 'État des lieux de sortie', MAINTENANCE: 'Pré-état des lieux', OTHER: 'Inventaire du mobilier' },
    en: { INSTALLATION: 'Check-in inventory', SAV: 'Check-out inventory', MAINTENANCE: 'Pre-check-out visit', OTHER: 'Furniture inventory' },
  },
  SERVICES: {
    fr: { INSTALLATION: 'Démarrage de prestation', SAV: 'Intervention ponctuelle', MAINTENANCE: 'Passage régulier', OTHER: 'Traitement anti-nuisibles' },
    en: { INSTALLATION: 'Service start-up', SAV: 'Call-out', MAINTENANCE: 'Scheduled visit', OTHER: 'Pest control treatment' },
  },
};

const capitalize = (s: string) => (s ? s[0].toUpperCase() + s.slice(1) : s);
const startsWithVowel = (s: string) => /^[aeiouyéèêàâîôûh]/i.test(s);

/**
 * Remplace « intervention » et « technicien » par les mots du métier dans un texte de l'interface.
 * Gère majuscule initiale, pluriel et élision (« le technicien » → « l'agent », « l'intervention » → « la visite »).
 */
export function applySectorWords(text: string, words: SectorWords, lang: 'fr' | 'en'): string {
  if (lang === 'en') {
    const rules: [RegExp, string, string][] = [
      [/\b(jobs|interventions)\b/gi, words.job[1], ''],
      [/\b(job|intervention)\b/gi, words.job[0], ''],
      [/\btechnicians\b/gi, words.worker[1], ''],
      [/\btechnician\b/gi, words.worker[0], ''],
    ];
    let out = text;
    for (const [re, rep] of rules) out = out.replace(re, (m) => (m[0] === m[0].toUpperCase() ? capitalize(rep) : rep));
    // « a officer » → « an officer », « an visit » → « a visit »
    for (const w of [words.job[0], words.worker[0]]) {
      out = out.replace(new RegExp(String.raw`\b([Aa])n? (${w})\b`, 'gi'), (_m, a: string, word: string) =>
        `${a}${/^[aeiou]/i.test(word) ? 'n' : ''} ${word}`);
    }
    return out;
  }
  let out = text;
  const swap = (singular: string, plural: string, [one, many]: [string, string]) => {
    const vowel = startsWithVowel(one);
    const art = (before: string, cap: boolean) => {
      // Article ou préposition devant le mot remplacé, selon que le nouveau mot commence par une voyelle
      const map: Record<string, [string, string]> = {
        'l’': ['l’', 'le '], "l'": ["l'", 'le '], 'le ': ['l’', 'le '], 'la ': ['l’', 'la '],
        'd’': ['d’', 'de '], "d'": ["d'", 'de '], 'de ': ['d’', 'de '], 'du ': ['de l’', 'du '],
        'ce ': ['cet ', 'ce '], 'cet ': ['cet ', 'ce '], 'au ': ['à l’', 'au '],
      };
      const key = before.toLowerCase();
      const pair = map[key];
      if (!pair) return before;
      let r = vowel ? pair[0] : pair[1];
      // « l’intervention » (féminin) devient « la visite », pas « le visite »
      if (!vowel && (key === 'l’' || key === "l'") && singular === 'intervention') r = 'la ';
      return cap ? capitalize(r) : r;
    };
    const re = new RegExp(String.raw`(\b(?:[Ll]’|[Ll]'|[Dd]’|[Dd]'|[Ll]e |[Ll]a |[Dd]e |[Dd]u |[Cc]et? |[Aa]u ))?\b(${singular}s?)\b`, 'gi');
    out = out.replace(re, (_m, before: string | undefined, word: string) => {
      const isPlural = word.toLowerCase() === plural;
      const rep = isPlural ? many : one;
      const capWord = word[0] === word[0].toUpperCase();
      if (!before) return capWord ? capitalize(rep) : rep;
      const capBefore = before[0] === before[0].toUpperCase();
      const prefix = isPlural ? before : art(before, capBefore);
      return prefix + (capWord ? capitalize(rep) : rep);
    });
  };
  swap('intervention', 'interventions', words.job);
  swap('technicien', 'techniciens', words.worker);
  return out;
}

// ─── Annuaire ────────────────────────────────────────────────────────────

/** Catégories des contacts extérieurs de l'annuaire (fournisseurs, sous-traitants, numéros utiles…) */
export const DIRECTORY_CATEGORIES = ['SUPPLIER', 'SUBCONTRACTOR', 'MANUFACTURER', 'EMERGENCY', 'ADMINISTRATION', 'OTHER'] as const;
export type DirectoryCategory = (typeof DIRECTORY_CATEGORIES)[number];
export const DIRECTORY_CATEGORY_LABELS: Record<DirectoryCategory, string> = {
  SUPPLIER: 'Fournisseur',
  SUBCONTRACTOR: 'Sous-traitant',
  MANUFACTURER: 'Fabricant / assistance technique',
  EMERGENCY: 'Urgence / dépannage',
  ADMINISTRATION: 'Administration',
  OTHER: 'Autre',
};

// ─── Notices et procédures ───────────────────────────────────────────────

/** Rubriques de la bibliothèque de documents de l'appli terrain */
export const PROCEDURE_CATEGORIES = ['PROCEDURE', 'MANUAL', 'TECHNICAL', 'SAFETY', 'FORM', 'OTHER'] as const;
export type ProcedureCategory = (typeof PROCEDURE_CATEGORIES)[number];
export const PROCEDURE_CATEGORY_LABELS: Record<ProcedureCategory, string> = {
  PROCEDURE: 'Procédure interne',
  MANUAL: 'Notice fabricant',
  TECHNICAL: 'Fiche technique / schéma',
  SAFETY: 'Sécurité',
  FORM: 'Formulaire / modèle',
  OTHER: 'Autre',
};
/** Un document proposé par un technicien attend la validation du bureau */
export const PROCEDURE_STATUSES = ['PENDING', 'APPROVED', 'REJECTED'] as const;
export type ProcedureStatus = (typeof PROCEDURE_STATUSES)[number];

// ─── Cartes SIM ──────────────────────────────────────────────────────────

/** Vie d'une carte SIM : en stock → à activer → activation demandée (sur le site du prestataire) → active */
export const SIM_STATUSES = ['STOCK', 'TO_ACTIVATE', 'REQUESTED', 'ACTIVE', 'SUSPENDED', 'TERMINATED'] as const;
export type SimStatus = (typeof SIM_STATUSES)[number];
export const SIM_STATUS_LABELS: Record<SimStatus, string> = {
  STOCK: 'En stock',
  TO_ACTIVATE: 'À activer',
  REQUESTED: 'Activation demandée',
  ACTIVE: 'Active',
  SUSPENDED: 'Suspendue',
  TERMINATED: 'Résiliée',
};

// ─── Langues de l'interface ──────────────────────────────────────────────

export const UI_LOCALES = [
  'fr-FR', 'en-GB', 'es-ES', 'de-DE', 'it-IT', 'pt-PT', 'nl-NL', 'pl-PL', 'ro-RO', 'tr-TR', 'ru-RU', 'ar-MA', 'hi-IN', 'zh-CN', 'ja-JP', 'ko-KR',
] as const;
export type UiLocale = (typeof UI_LOCALES)[number];
/** Chaque langue s'affiche dans sa propre langue dans le sélecteur */
export const UI_LOCALE_LABELS: Record<UiLocale, string> = {
  'fr-FR': 'Français', 'en-GB': 'English', 'es-ES': 'Español', 'de-DE': 'Deutsch', 'it-IT': 'Italiano', 'pt-PT': 'Português',
  'nl-NL': 'Nederlands', 'pl-PL': 'Polski', 'ro-RO': 'Română', 'tr-TR': 'Türkçe', 'ru-RU': 'Русский', 'ar-MA': 'العربية',
  'hi-IN': 'हिन्दी', 'zh-CN': '中文（简体）', 'ja-JP': '日本語', 'ko-KR': '한국어',
};

// ─── Interventions ───────────────────────────────────────────────────────

export const INTERVENTION_KINDS = ['INSTALLATION', 'SAV', 'MAINTENANCE', 'OTHER'] as const;
export type InterventionKind = (typeof INTERVENTION_KINDS)[number];
export const KIND_LABELS: Record<InterventionKind, string> = {
  INSTALLATION: 'Installation',
  SAV: 'SAV / Dépannage',
  MAINTENANCE: 'Entretien',
  OTHER: 'Autre',
};

export const INTERVENTION_STATUSES = [
  'TO_PLAN', 'PLANNED', 'EN_ROUTE', 'ON_SITE', 'DONE', 'TO_RESUME', 'CANCELLED',
] as const;
export type InterventionStatus = (typeof INTERVENTION_STATUSES)[number];
export const STATUS_LABELS: Record<InterventionStatus, string> = {
  TO_PLAN: 'À planifier',
  PLANNED: 'Planifiée',
  EN_ROUTE: 'En route',
  ON_SITE: 'Sur site',
  DONE: 'Terminée',
  TO_RESUME: 'À reprendre',
  CANCELLED: 'Annulée',
};

export const PRIORITIES = ['LOW', 'NORMAL', 'HIGH', 'URGENT'] as const;
export type Priority = (typeof PRIORITIES)[number];
export const PRIORITY_LABELS: Record<Priority, string> = {
  LOW: 'Basse',
  NORMAL: 'Normale',
  HIGH: 'Haute',
  URGENT: 'Urgente',
};

export const REPORT_STATUSES = ['DRAFT', 'SIGNED', 'SENT'] as const;
export type ReportStatus = (typeof REPORT_STATUSES)[number];

export const OUTCOMES = ['DONE', 'TEMPORARY', 'TO_RESUME', 'WAITING_PARTS', 'QUOTE_NEEDED'] as const;
export type Outcome = (typeof OUTCOMES)[number];
export const OUTCOME_LABELS: Record<Outcome, string> = {
  DONE: 'Terminé / réparé',
  TEMPORARY: 'Solution provisoire',
  TO_RESUME: 'À reprendre',
  WAITING_PARTS: 'En attente de pièces',
  QUOTE_NEEDED: 'Devis à établir',
};

// ─── Montants et TVA ─────────────────────────────────────────────────────
// Les montants sont en CENTIMES (entiers) et les taux de TVA en POINTS DE BASE (2000 = 20 %) :
// aucun arrondi flottant ne peut fausser un total.

/** Taux de TVA proposés par pays (le premier est le taux normal) */
export const VAT_RATES: Record<string, number[]> = {
  FR: [2000, 1000, 550, 210, 0],
  BE: [2100, 1200, 600, 0],
  GB: [2000, 500, 0],
};
export function vatRatesFor(countryCode: string): number[] {
  return VAT_RATES[countryCode] ?? [2000, 1000, 0];
}

export interface PricedLine {
  quantity: number;
  unitPriceCents: number;
  vatRateBp: number;
}

/** Montant HT d'une ligne, arrondi au centime */
export function lineNetCents(l: PricedLine): number {
  return Math.round(l.quantity * l.unitPriceCents);
}

export interface DocumentTotals {
  netCents: number;
  vatCents: number;
  grossCents: number;
  /** Détail par taux (bases et TVA), comme sur une facture */
  byRate: { vatRateBp: number; baseCents: number; vatCents: number }[];
}

/** Totaux d'un devis ou d'une facture : la TVA est calculée par taux, sur la somme des lignes */
export function documentTotals(lines: PricedLine[]): DocumentTotals {
  const bases = new Map<number, number>();
  for (const l of lines) bases.set(l.vatRateBp, (bases.get(l.vatRateBp) ?? 0) + lineNetCents(l));
  const byRate = [...bases.entries()]
    .sort((a, b) => b[0] - a[0])
    .map(([vatRateBp, baseCents]) => ({ vatRateBp, baseCents, vatCents: Math.round((baseCents * vatRateBp) / 10_000) }));
  const netCents = byRate.reduce((s, r) => s + r.baseCents, 0);
  const vatCents = byRate.reduce((s, r) => s + r.vatCents, 0);
  return { netCents, vatCents, grossCents: netCents + vatCents, byRate };
}

export function formatMoney(cents: number, currency: string, locale = 'fr-FR'): string {
  return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(cents / 100);
}

export function formatVatRate(bp: number, locale = 'fr-FR'): string {
  return `${new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(bp / 100)} %`;
}

// ─── Devis ───────────────────────────────────────────────────────────────

export const QUOTE_STATUSES = ['DRAFT', 'SENT', 'ACCEPTED', 'REFUSED', 'CANCELLED'] as const;
export type QuoteStatus = (typeof QUOTE_STATUSES)[number];
export const QUOTE_STATUS_LABELS: Record<QuoteStatus, string> = {
  DRAFT: 'Brouillon',
  SENT: 'Envoyé',
  ACCEPTED: 'Accepté',
  REFUSED: 'Refusé',
  CANCELLED: 'Annulé',
};
/** Travaux ponctuels (→ une intervention) ou contrat d'entretien (→ des visites régulières) */
export const QUOTE_KINDS = ['WORK', 'CONTRACT'] as const;
export type QuoteKind = (typeof QUOTE_KINDS)[number];
export const QUOTE_KIND_LABELS: Record<QuoteKind, string> = { WORK: 'Travaux', CONTRACT: "Contrat d'entretien" };

/** Un devis envoyé dont la date de validité est passée */
export function isQuoteExpired(q: { status: QuoteStatus; validUntil: string | null }, today: string): boolean {
  return q.status === 'SENT' && !!q.validUntil && q.validUntil < today;
}

// ─── Contrats d'entretien ────────────────────────────────────────────────

export const CONTRACT_STATUSES = ['ACTIVE', 'SUSPENDED', 'ENDED'] as const;
export type ContractStatus = (typeof CONTRACT_STATUSES)[number];
export const CONTRACT_STATUS_LABELS: Record<ContractStatus, string> = {
  ACTIVE: 'Actif',
  SUSPENDED: 'Suspendu',
  ENDED: 'Terminé',
};
/** Fréquences de visite proposées, en mois */
export const CONTRACT_FREQUENCIES: { months: number; label: string }[] = [
  { months: 1, label: 'Mensuelle' },
  { months: 2, label: 'Tous les 2 mois' },
  { months: 3, label: 'Trimestrielle' },
  { months: 4, label: 'Tous les 4 mois' },
  { months: 6, label: 'Semestrielle' },
  { months: 12, label: 'Annuelle' },
  { months: 24, label: 'Tous les 2 ans' },
];
/** Les visites sont créées « à planifier » ce nombre de jours avant leur échéance */
export const VISIT_HORIZON_DAYS = 60;

/** Ajoute des mois à une date AAAA-MM-JJ (le 31 janvier + 1 mois = le 28 ou 29 février) */
export function addMonths(isoDate: string, months: number): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const total = y * 12 + (m - 1) + months;
  const year = Math.floor(total / 12);
  const month = total % 12;
  const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  return `${year}-${String(month + 1).padStart(2, '0')}-${String(Math.min(d, lastDay)).padStart(2, '0')}`;
}

export function addDays(isoDate: string, days: number): string {
  const t = Date.parse(`${isoDate}T00:00:00Z`) + days * 86_400_000;
  return new Date(t).toISOString().slice(0, 10);
}

/**
 * Échéances des visites d'un contrat comprises entre `from` et `until` (inclus).
 * Toujours calculées depuis la date de début (pas de dérive au fil des mois courts).
 */
export function visitDueDates(
  c: { startDate: string; endDate: string | null; frequencyMonths: number },
  from: string,
  until: string,
): string[] {
  const out: string[] = [];
  if (c.frequencyMonths < 1) return out;
  for (let k = 0; k < 1000; k++) {
    const due = addMonths(c.startDate, k * c.frequencyMonths);
    if (due > until || (c.endDate && due > c.endDate)) break;
    if (due >= from) out.push(due);
  }
  return out;
}

// ─── Factures et avoirs ──────────────────────────────────────────────────
// Une facture reçoit son numéro à l'ÉMISSION (numérotation continue, sans trou) et ne change plus ensuite :
// une erreur se corrige par un avoir.

export const INVOICE_KINDS = ['INVOICE', 'CREDIT_NOTE'] as const;
export type InvoiceKind = (typeof INVOICE_KINDS)[number];
export const INVOICE_KIND_LABELS: Record<InvoiceKind, string> = { INVOICE: 'Facture', CREDIT_NOTE: 'Avoir' };

export const INVOICE_STATUSES = ['DRAFT', 'ISSUED'] as const;
export type InvoiceStatus = (typeof INVOICE_STATUSES)[number];

export const PAYMENT_METHODS = ['TRANSFER', 'CHECK', 'CARD', 'CASH', 'DIRECT_DEBIT', 'OTHER'] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];
export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
  TRANSFER: 'Virement',
  CHECK: 'Chèque',
  CARD: 'Carte bancaire',
  CASH: 'Espèces',
  DIRECT_DEBIT: 'Prélèvement',
  OTHER: 'Autre',
};

export type PaymentState = 'DRAFT' | 'UNPAID' | 'PARTIAL' | 'PAID' | 'OVERDUE';
export const PAYMENT_STATE_LABELS: Record<PaymentState, string> = {
  DRAFT: 'Brouillon',
  UNPAID: 'À encaisser',
  PARTIAL: 'Payée en partie',
  PAID: 'Payée',
  OVERDUE: 'En retard',
};

/** Où en est le paiement d'une facture émise (un avoir est considéré comme réglé) */
export function paymentState(
  inv: { status: InvoiceStatus; kind: InvoiceKind; grossCents: number; paidCents: number; dueDate: string | null },
  today: string,
): PaymentState {
  if (inv.status === 'DRAFT') return 'DRAFT';
  if (inv.kind === 'CREDIT_NOTE' || inv.paidCents >= inv.grossCents) return 'PAID';
  if (inv.dueDate && inv.dueDate < today) return 'OVERDUE';
  return inv.paidCents > 0 ? 'PARTIAL' : 'UNPAID';
}

// ─── Stock ───────────────────────────────────────────────────────────────

export const STOCK_LOCATION_KINDS = ['DEPOT', 'VEHICLE'] as const;
export type StockLocationKind = (typeof STOCK_LOCATION_KINDS)[number];
export const STOCK_LOCATION_KIND_LABELS: Record<StockLocationKind, string> = { DEPOT: 'Dépôt', VEHICLE: 'Véhicule' };

/**
 * Mouvements de stock :
 *  - RECEIPT     : entrée (livraison fournisseur) dans un lieu
 *  - TRANSFER    : d'un lieu à un autre (bon de sortie du dépôt vers un véhicule)
 *  - ISSUE       : sortie vers un chantier (bon de sortie vers une intervention)
 *  - CONSUMPTION : pièce posée par le technicien, déduite de son véhicule à la signature de la fiche
 *  - ADJUSTMENT  : correction après inventaire (+ ou −)
 */
export const STOCK_MOVEMENT_KINDS = ['RECEIPT', 'TRANSFER', 'ISSUE', 'CONSUMPTION', 'ADJUSTMENT'] as const;
export type StockMovementKind = (typeof STOCK_MOVEMENT_KINDS)[number];
export const STOCK_MOVEMENT_LABELS: Record<StockMovementKind, string> = {
  RECEIPT: 'Réception',
  TRANSFER: 'Transfert',
  ISSUE: 'Sortie chantier',
  CONSUMPTION: 'Posé en intervention',
  ADJUSTMENT: 'Inventaire',
};

export const SLIP_STATUSES = ['DRAFT', 'VALIDATED', 'CANCELLED'] as const;
export type SlipStatus = (typeof SLIP_STATUSES)[number];
export const SLIP_STATUS_LABELS: Record<SlipStatus, string> = { DRAFT: 'Brouillon', VALIDATED: 'Validé', CANCELLED: 'Annulé' };

/** Stock bas : à commander ou à réapprovisionner */
export function isLowStock(level: { quantity: number; minQuantity: number }): boolean {
  return level.minQuantity > 0 && level.quantity <= level.minQuantity;
}

// ─── Échéances (habilitations, véhicules) ────────────────────────────────

export type DueState = 'OK' | 'SOON' | 'OVERDUE' | 'NONE';
export const DUE_STATE_LABELS: Record<DueState, string> = { OK: 'À jour', SOON: 'Bientôt', OVERDUE: 'Dépassé', NONE: '—' };

/** Nombre de jours entre deux dates AAAA-MM-JJ */
export function daysBetween(from: string, to: string): number {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000);
}

/** Habilitations : alerte 60 jours avant l'expiration (le temps de programmer un recyclage) */
export const CERT_WARNING_DAYS = 60;

export function certificationState(expiresOn: string | null | undefined, today: string): DueState {
  if (!expiresOn) return 'OK'; // sans date d'expiration : valable
  if (expiresOn < today) return 'OVERDUE';
  return daysBetween(today, expiresOn) <= CERT_WARNING_DAYS ? 'SOON' : 'OK';
}

// ─── Parc véhicules ──────────────────────────────────────────────────────

export const VEHICLE_TYPES = ['VAN', 'CAR', 'TRUCK', 'OTHER'] as const;
export type VehicleType = (typeof VEHICLE_TYPES)[number];
export const VEHICLE_TYPE_LABELS: Record<VehicleType, string> = { VAN: 'Utilitaire', CAR: 'Voiture', TRUCK: 'Poids lourd', OTHER: 'Autre' };

export const VEHICLE_STATUSES = ['ACTIVE', 'IMMOBILIZED', 'RETIRED'] as const;
export type VehicleStatus = (typeof VEHICLE_STATUSES)[number];
export const VEHICLE_STATUS_LABELS: Record<VehicleStatus, string> = { ACTIVE: 'En service', IMMOBILIZED: 'Immobilisé', RETIRED: 'Sorti du parc' };

export const OWNERSHIPS = ['OWNED', 'LEASED', 'RENTED'] as const;
export type Ownership = (typeof OWNERSHIPS)[number];
export const OWNERSHIP_LABELS: Record<Ownership, string> = { OWNED: 'Propriété', LEASED: 'Location longue durée', RENTED: 'Location courte' };

/** Échéances suivies pour chaque véhicule */
export const VEHICLE_DEADLINE_KINDS = ['SERVICE', 'TECH_INSPECTION', 'INSURANCE', 'TIRES', 'LEASE_END', 'OTHER'] as const;
export type VehicleDeadlineKind = (typeof VEHICLE_DEADLINE_KINDS)[number];
export const VEHICLE_DEADLINE_LABELS: Record<VehicleDeadlineKind, string> = {
  SERVICE: 'Entretien / révision',
  TECH_INSPECTION: 'Contrôle technique',
  INSURANCE: 'Assurance',
  TIRES: 'Pneus',
  LEASE_END: 'Fin de location',
  OTHER: 'Autre',
};

/** Événements du carnet d'entretien */
export const VEHICLE_EVENT_KINDS = ['SERVICE', 'REPAIR', 'TECH_INSPECTION', 'TIRES', 'ACCIDENT', 'MILEAGE', 'OTHER'] as const;
export type VehicleEventKind = (typeof VEHICLE_EVENT_KINDS)[number];
export const VEHICLE_EVENT_LABELS: Record<VehicleEventKind, string> = {
  SERVICE: 'Entretien',
  REPAIR: 'Réparation',
  TECH_INSPECTION: 'Contrôle technique',
  TIRES: 'Pneus',
  ACCIDENT: 'Sinistre',
  MILEAGE: 'Relevé kilométrique',
  OTHER: 'Autre',
};

/** Alerte : 30 jours ou 1 500 km avant l'échéance */
export const VEHICLE_WARNING_DAYS = 30;
export const VEHICLE_WARNING_KM = 1_500;

/** Une échéance est due à une date, à un kilométrage, ou au premier des deux */
export function vehicleDeadlineState(
  d: { dueDate: string | null; dueMileage: number | null },
  today: string,
  mileage: number | null,
): DueState {
  const states: DueState[] = [];
  if (d.dueDate) {
    states.push(d.dueDate < today ? 'OVERDUE' : daysBetween(today, d.dueDate) <= VEHICLE_WARNING_DAYS ? 'SOON' : 'OK');
  }
  if (d.dueMileage != null && mileage != null) {
    states.push(mileage >= d.dueMileage ? 'OVERDUE' : d.dueMileage - mileage <= VEHICLE_WARNING_KM ? 'SOON' : 'OK');
  }
  if (!states.length) return 'NONE';
  return states.includes('OVERDUE') ? 'OVERDUE' : states.includes('SOON') ? 'SOON' : 'OK';
}

/** Après un entretien fait : prochaine échéance = date + intervalle, kilométrage + intervalle */
export function nextVehicleDeadline(
  d: { intervalMonths: number | null; intervalKm: number | null },
  doneOn: string,
  doneMileage: number | null,
): { dueDate: string | null; dueMileage: number | null } {
  return {
    dueDate: d.intervalMonths ? addMonths(doneOn, d.intervalMonths) : null,
    dueMileage: d.intervalKm && doneMileage != null ? doneMileage + d.intervalKm : null,
  };
}

// ─── Photos de la fiche ──────────────────────────────────────────────────

export const PHOTO_KINDS = ['BEFORE', 'AFTER', 'OTHER'] as const;
export type PhotoKind = (typeof PHOTO_KINDS)[number];
/** Nombre maximum de photos sur une fiche (le PDF reste lisible et léger) */
export const MAX_PHOTOS_PER_REPORT = 20;

// ─── Modèles de fiches ───────────────────────────────────────────────────
// Une fiche est décrite par un modèle (JSON) : des sections contenant des champs.
// Chaque société peut avoir ses propres modèles ; sinon les modèles neutres s'appliquent.

export const FIELD_TYPES = [
  'text', 'textarea', 'number', 'date', 'time', 'select', 'checkbox', 'checklist',
] as const;
export type FieldType = (typeof FIELD_TYPES)[number];

export const FIELD_TYPE_LABELS: Record<FieldType, string> = {
  text: 'Texte court',
  textarea: 'Texte long',
  number: 'Nombre',
  date: 'Date',
  time: 'Heure',
  select: 'Choix unique',
  checkbox: 'Case à cocher',
  checklist: 'Liste à cocher',
};

/** Informations connues à l'avance, qui peuvent pré-remplir un champ de la fiche */
export const PREFILL_SOURCES: { path: string; label: string }[] = [
  { path: 'intervention.reason', label: "Motif de l'intervention" },
  { path: 'intervention.number', label: "N° d'intervention" },
  { path: 'client.name', label: 'Nom du client' },
  { path: 'client.fullAddress', label: 'Adresse du client' },
  { path: 'client.phone', label: 'Téléphone du client' },
  { path: 'client.email', label: 'E-mail du client' },
  { path: 'client.subscriberNumber', label: 'N° d’abonné du client' },
  { path: 'site.name', label: 'Nom du site' },
  { path: 'site.fullAddress', label: 'Adresse du site' },
  { path: 'equipment.category', label: 'Type de matériel' },
  { path: 'equipment.brand', label: 'Marque du matériel' },
  { path: 'equipment.model', label: 'Modèle du matériel' },
  { path: 'equipment.serialNumber', label: 'N° de série du matériel' },
  { path: 'equipment.location', label: 'Emplacement du matériel' },
  { path: 'technician.fullName', label: 'Nom du technicien' },
  { path: 'company.name', label: 'Nom de la société' },
];

/** Limites d'un modèle : une fiche reste remplissable sur un téléphone */
export const TEMPLATE_LIMITS = { sections: 30, fieldsPerSection: 40, options: 50, label: 200 } as const;

export interface TemplateField {
  id: string;
  label: string;
  type: FieldType;
  required?: boolean;
  /** Valeurs possibles pour select et checklist */
  options?: string[];
  /** Pré-remplissage depuis le contexte, ex. "client.name", "equipment.serialNumber" */
  prefill?: string;
  /** Le champ accepte la dictée vocale */
  dictation?: boolean;
  help?: string;
}

export interface TemplateSection {
  id: string;
  title: string;
  fields: TemplateField[];
}

export interface TemplateSchema {
  /** Langue du modèle, ex. "fr" ou "en" */
  lang?: string;
  sections: TemplateSection[];
}

export type ReportData = Record<string, string | number | boolean | string[] | null>;

/**
 * Identifiant technique d'un champ, tiré de son libellé : « N° de série » → "n_de_serie".
 * Il sert de clé aux valeurs saisies : il ne change plus une fois le champ créé.
 */
export function fieldIdFromLabel(label: string, taken: Iterable<string>): string {
  const base = label
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '')
    .slice(0, 40) || 'champ';
  const start = /^[a-z]/.test(base) ? base : `f_${base}`;
  const used = new Set(taken);
  if (!used.has(start)) return start;
  let n = 2;
  while (used.has(`${start}_${n}`)) n++;
  return `${start}_${n}`;
}

/** Vérifie les champs obligatoires et renvoie la liste des libellés manquants. */
export function missingRequiredFields(schema: TemplateSchema, data: ReportData): string[] {
  const missing: string[] = [];
  for (const section of schema.sections) {
    for (const field of section.fields) {
      if (!field.required) continue;
      const v = data[field.id];
      const empty =
        v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0);
      if (empty) missing.push(field.label);
    }
  }
  return missing;
}

// ─── Import de clients, sites et matériels (fichier CSV ou Excel) ─────────

/**
 * Colonnes reconnues à l'import. Une ligne du fichier = un matériel (ou un site, ou un client sans matériel) :
 * les lignes d'un même client sont regroupées, puis celles d'un même site.
 */
export const CLIENT_IMPORT_FIELDS = [
  'clientName', 'clientType', 'clientRef', 'subscriberNumber', 'email', 'phone', 'address', 'postalCode', 'city',
  'siren', 'vatNumber', 'clientNotes', 'contactName', 'contactPhone', 'contactEmail',
  'siteName', 'siteAddress', 'sitePostalCode', 'siteCity', 'accessNotes',
  'category', 'brand', 'model', 'serialNumber', 'location', 'installedAt', 'warrantyUntil', 'underContract', 'equipmentNotes',
] as const;
export type ClientImportField = (typeof CLIENT_IMPORT_FIELDS)[number];

/** Libellé (français, traduit à l'écran) et groupe de chaque colonne */
export const CLIENT_IMPORT_FIELD_LABELS: Record<ClientImportField, string> = {
  clientName: 'Nom du client',
  clientType: 'Type (entreprise ou particulier)',
  clientRef: 'Référence client (autre logiciel)',
  subscriberNumber: 'N° d’abonné',
  email: 'E-mail',
  phone: 'Téléphone',
  address: 'Adresse',
  postalCode: 'Code postal',
  city: 'Ville',
  siren: 'SIREN ou SIRET',
  vatNumber: 'N° de TVA intracommunautaire',
  clientNotes: 'Notes du client',
  contactName: 'Nom du contact',
  contactPhone: 'Téléphone du contact',
  contactEmail: 'E-mail du contact',
  siteName: 'Nom du site',
  siteAddress: 'Adresse du site',
  sitePostalCode: 'Code postal du site',
  siteCity: 'Ville du site',
  accessNotes: 'Accès et consignes du site',
  category: 'Type de matériel',
  brand: 'Marque',
  model: 'Modèle|matériel',
  serialNumber: 'N° de série',
  location: 'Emplacement',
  installedAt: 'Date de pose',
  warrantyUntil: 'Fin de garantie',
  underContract: 'Sous contrat (oui/non)',
  equipmentNotes: 'Notes du matériel',
};

export type ClientImportIssueCode =
  | 'missingName' | 'badEmail' | 'badSiren' | 'badDate' | 'otherSubscriber' | 'duplicateEquipment' | 'tooManyRows';

export interface ClientImportIssue {
  /** N° de ligne dans le fichier (1 = ligne des titres) */
  line: number;
  code: ClientImportIssueCode;
  value?: string;
}

export interface ClientImportPreview {
  /** Titres des colonnes du fichier et colonne Itinéos associée (null = ignorée) */
  columns: { header: string; field: ClientImportField | null }[];
  rows: number;
  clientsNew: number;
  clientsExisting: number;
  sitesNew: number;
  equipmentsNew: number;
  equipmentsExisting: number;
  contactsNew: number;
  /** Lignes ignorées (sans nom de client) */
  rowsSkipped: number;
  issues: ClientImportIssue[];
  /** Les premiers clients tels qu'ils seront créés, pour vérifier à l'écran */
  sample: { name: string; existing: boolean; subscriberNumber: string | null; sites: { name: string; city: string | null; equipments: string[] }[] }[];
}
