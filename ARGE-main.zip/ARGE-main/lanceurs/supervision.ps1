﻿<#
  Lance la console de supervision sur ce PC : http://localhost:4000
  Base « supervision » dans le PostgreSQL de Docker (comme les éditions d'essai). Au premier lancement, crée
  votre compte de la console et affiche son mot de passe provisoire.

  Pour que les Itinéos installés chez les clients la joignent, la console devra être mise en ligne (adresse https) :
  sur ce PC, seules les installations de ce réseau (ou de ce PC) peuvent s'y inscrire.
#>
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
$Host.UI.RawUI.WindowTitle = 'Itinéos Supervision'
function Say([string]$text, [string]$color = 'Gray') { Write-Host $text -ForegroundColor $color }
function Fail([string]$text) { Say ''; Say $text 'Red'; Read-Host 'Appuyez sur Entrée pour fermer'; exit 1 }

Say ''
Say '  Itinéos Supervision' 'Cyan'
Say '  ─────────────────────────────────────────'
docker info *> $null
if ($LASTEXITCODE -ne 0) { Fail 'Docker Desktop n''est pas lancé : démarrez-le, puis relancez ce raccourci.' }
Push-Location $root
docker compose up -d db *> $null
Pop-Location
for ($i = 0; $i -lt 30; $i++) { docker exec itineo-db-1 pg_isready -U itineo *> $null; if ($LASTEXITCODE -eq 0) { break }; Start-Sleep 1 }
$exists = (docker exec itineo-db-1 psql -U itineo -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='supervision'") -eq '1'
if (-not $exists) { docker exec itineo-db-1 psql -U itineo -d postgres -c 'CREATE DATABASE supervision' *> $null }

$env:DATABASE_URL = 'postgres://itineo:itineo@localhost:5432/supervision'
$env:PORT = '4000'
$env:DATA_DIR = Join-Path $root 'apps\supervision\donnees'
$env:WEB_DIR = Join-Path $root 'apps\supervision\dist'
Push-Location (Join-Path $root 'apps\supervision')
if (-not (Test-Path $env:WEB_DIR)) { Say '  Construction de l''interface…'; npm run build --silent *> $null }
if (-not $exists) {
  Say ''
  $email = Read-Host '  Votre e-mail (identifiant de la console)'
  $name = Read-Host '  Votre nom'
  npx tsx src/create-operator.ts --email $email --name $name
}
Say '  Démarrage…'
Start-Process 'http://localhost:4000'
Say '  Console ouverte : http://localhost:4000   (fermer cette fenêtre l''arrête)' 'Green'
npx tsx src/index.ts
Pop-Location
