@echo off
rem Lance TECH : base de donnees, serveur et appli, puis ouvre le navigateur
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lancer.ps1" -Edition TECH
