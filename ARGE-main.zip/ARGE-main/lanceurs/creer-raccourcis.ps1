﻿<#
  Crée sur le Bureau un dossier « Itinéos – essais » avec un raccourci par logiciel, chacun avec son icône
  aux couleurs de l'édition. À relancer si le dossier du projet est déplacé.
#>
Add-Type -AssemblyName System.Drawing
$here = $PSScriptRoot
$icons = Join-Path $here 'icones'
New-Item -ItemType Directory -Force $icons | Out-Null

# Couleurs de chaque édition (EDITION_THEMES dans packages/shared)
$editions = [ordered]@{
  'Itinéos'           = @{ Code = 'TECH';      Ink = '#14181F'; Accent = '#C2410C' }
  'Itinéos Vigie'     = @{ Code = 'SECURITY';  Ink = '#0F1A2E'; Accent = '#2563EB' }
  'Itinéos Constat'   = @{ Code = 'BAILIFF';   Ink = '#1F1418'; Accent = '#9F1239' }
  'Itinéos Expertise' = @{ Code = 'EXPERTISE'; Ink = '#0E1F1D'; Accent = '#0F766E' }
  'Itinéos Clés'      = @{ Code = 'RENTAL';    Ink = '#17132A'; Accent = '#7C3AED' }
  'Itinéos Services'  = @{ Code = 'SERVICES';  Ink = '#10201A'; Accent = '#15803D' }
  # Version A.R.G.E. : le bleu marine de son logo
  'Itinéos ARGE'      = @{ Code = 'ARGE';      Ink = '#002B56'; Accent = '#FFFFFF' }
}

# Icône : carré arrondi foncé, repère de lieu de la couleur de l'édition (comme l'icône de l'appli)
function New-EditionIcon([string]$path, [string]$ink, [string]$accent) {
  $size = 256
  $bmp = New-Object System.Drawing.Bitmap $size, $size
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = 'AntiAlias'
  $g.Clear([System.Drawing.Color]::Transparent)
  $bg = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml($ink))
  $r = 56; $rect = New-Object System.Drawing.Drawing2D.GraphicsPath
  $rect.AddArc(0, 0, $r, $r, 180, 90); $rect.AddArc($size - $r, 0, $r, $r, 270, 90)
  $rect.AddArc($size - $r, $size - $r, $r, $r, 0, 90); $rect.AddArc(0, $size - $r, $r, $r, 90, 90); $rect.CloseFigure()
  $g.FillPath($bg, $rect)
  $pen = New-Object System.Drawing.Pen ([System.Drawing.ColorTranslator]::FromHtml($accent)), 18
  $pen.LineJoin = 'Round'
  # Repère : cercle du haut prolongé en pointe vers le bas
  $pin = New-Object System.Drawing.Drawing2D.GraphicsPath
  # Arc de 150° à 30° (centre 128,116 ; rayon 56), dont les extrémités rejoignent la pointe
  $pin.AddArc(72, 60, 112, 112, 150, 240)
  $pin.AddLine(176.5, 144, 128, 212)
  $pin.AddLine(128, 212, 79.5, 144)
  $pin.CloseFigure()
  $g.DrawPath($pen, $pin)
  $g.DrawEllipse($pen, 108, 96, 40, 40)
  $g.Dispose()
  # Fichier .ico contenant une image PNG (accepté par Windows depuis Vista)
  $ms = New-Object System.IO.MemoryStream
  $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
  $png = $ms.ToArray()
  $bmp.Dispose()
  $out = New-Object System.IO.MemoryStream
  $w = New-Object System.IO.BinaryWriter $out
  $w.Write([UInt16]0); $w.Write([UInt16]1); $w.Write([UInt16]1)
  $w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0)
  $w.Write([UInt16]1); $w.Write([UInt16]32); $w.Write([UInt32]$png.Length); $w.Write([UInt32]22)
  $w.Write($png)
  [IO.File]::WriteAllBytes($path, $out.ToArray())
}

$desktop = [Environment]::GetFolderPath('Desktop')
$folder = Join-Path $desktop 'Itinéos – essais'
New-Item -ItemType Directory -Force $folder | Out-Null
$shell = New-Object -ComObject WScript.Shell
foreach ($name in $editions.Keys) {
  $ed = $editions[$name]
  $ico = Join-Path $icons "$($ed.Code.ToLower()).ico"
  New-EditionIcon $ico $ed.Ink $ed.Accent
  $lnk = $shell.CreateShortcut((Join-Path $folder "$name.lnk"))
  $lnk.TargetPath = Join-Path $here "$name.cmd"
  $lnk.WorkingDirectory = $here
  $lnk.IconLocation = "$ico,0"
  $lnk.Description = "Ouvrir $name pour l'essayer"
  $lnk.Save()
  Write-Host "  $name"
}
$reset = $shell.CreateShortcut((Join-Path $folder 'Remettre à zéro les données de démonstration.lnk'))
$reset.TargetPath = Join-Path $here 'Remettre a zero les demos.cmd'
$reset.WorkingDirectory = $here
$reset.IconLocation = "$env:SystemRoot\System32\shell32.dll,238"
$reset.Save()
Write-Host "  Raccourcis créés dans : $folder"
