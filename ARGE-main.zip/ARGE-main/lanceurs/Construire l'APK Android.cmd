@echo off
rem Construit l'appli Android d'essai (apk\ARGE-terrain.apk)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0construire-apk.ps1"
