@echo off
rem Installe ou met a jour A.R.G.E. sur la VM de la Freebox (voir FREEBOX-VM.md)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer-vm.ps1"
