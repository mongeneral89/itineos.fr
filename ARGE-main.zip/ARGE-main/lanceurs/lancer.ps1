﻿<#
  Lance une édition d'Itinéos pour l'essayer : base de données, serveur, appli web, puis ouverture du navigateur.
  Chaque édition a sa propre base de démonstration et ses propres ports : on peut en ouvrir plusieurs à la fois,
  sans toucher à l'environnement de développement (ports 3000 / 5173, base « itineo »).

    lancer.ps1 -Edition SECURITY          (Itinéos Vigie)
    lancer.ps1 -Edition SECURITY -Reset   (remet les données de démonstration à zéro avant de lancer)
    lancer.ps1 -Edition ARGE              (version A.R.G.E. : édition Itinéos, société, documents et catalogue ARGE)

  Utilisé par les fichiers « Itinéos ….cmd » de ce dossier.
#>
param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('TECH', 'SECURITY', 'BAILIFF', 'EXPERTISE', 'RENTAL', 'SERVICES', 'ARGE')]
  [string]$Edition,
  [switch]$Reset
)

# Docker et npm écrivent leurs messages normaux sur la sortie d'erreur : ce ne sont pas des erreurs
$ErrorActionPreference = 'Continue'
$editions = @{
  TECH      = @{ Name = 'Itinéos';           Db = 'itineo_tech';      Api = 3100; Web = 5190 }
  SECURITY  = @{ Name = 'Itinéos Vigie';     Db = 'itineo_vigie';     Api = 3101; Web = 5191 }
  BAILIFF   = @{ Name = 'Itinéos Constat';   Db = 'itineo_constat';   Api = 3102; Web = 5192 }
  EXPERTISE = @{ Name = 'Itinéos Expertise'; Db = 'itineo_expertise'; Api = 3103; Web = 5193 }
  RENTAL    = @{ Name = 'Itinéos Clés';      Db = 'itineo_cles';      Api = 3104; Web = 5194 }
  SERVICES  = @{ Name = 'Itinéos Services';  Db = 'itineo_services';  Api = 3105; Web = 5195 }
  # Version d'un client : l'édition Itinéos (TECH) avec ses propres données (db/seed-arge.ts)
  ARGE      = @{ Name = 'Itinéos ARGE';      Db = 'itineo_arge';      Api = 3106; Web = 5196; Edition = 'TECH'; Seed = 'src/db/seed-arge.ts' }
}
$e = $editions[$Edition]
$code = if ($e.Edition) { $e.Edition } else { $Edition }
$seed = if ($e.Seed) { $e.Seed } else { 'src/db/seed.ts' }
$root = Split-Path -Parent $PSScriptRoot
$Host.UI.RawUI.WindowTitle = "$($e.Name) – essai"

function Say([string]$text, [string]$color = 'Gray') { Write-Host $text -ForegroundColor $color }
function Fail([string]$text) {
  foreach ($p in @($script:web, $script:api)) { if ($p -and -not $p.HasExited) { taskkill /PID $p.Id /T /F *> $null } }
  Say ''
  Say $text 'Red'
  Say ''
  Read-Host 'Appuyez sur Entrée pour fermer'
  exit 1
}
function PortOpen([int]$port) {
  $c = New-Object Net.Sockets.TcpClient
  try { $c.Connect('127.0.0.1', $port); return $true } catch { return $false } finally { $c.Dispose() }
}
function WaitPort([int]$port, [int]$seconds, $process) {
  for ($i = 0; $i -lt $seconds; $i++) {
    if (PortOpen $port) { return $true }
    if ($process -and $process.HasExited) { return $false }
    Start-Sleep -Seconds 1
  }
  return $false
}

Say ''
Say "  $($e.Name)" 'Cyan'
Say '  ─────────────────────────────────────────'

# ─── Vérifications ───
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Fail 'Node.js n''est pas installé (https://nodejs.org).' }
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Fail 'Docker Desktop n''est pas installé.' }
if (-not (Test-Path (Join-Path $root 'node_modules'))) {
  Say '  Première utilisation : installation des dépendances (quelques minutes)…'
  Push-Location $root; npm install --no-audit --no-fund | Out-Null; Pop-Location
}
if ((PortOpen $e.Api) -or (PortOpen $e.Web)) {
  Say "  $($e.Name) semble déjà ouvert : ouverture du navigateur." 'Yellow'
  Start-Process "http://localhost:$($e.Web)"
  Start-Sleep -Seconds 3
  exit 0
}

# ─── Base de données (Docker) ───
Say '  Démarrage de la base de données…'
docker info *> $null
if ($LASTEXITCODE -ne 0) {
  Say '  Docker Desktop n''est pas lancé : je le démarre (cela peut prendre une minute)…' 'Yellow'
  $dd = Join-Path $env:ProgramFiles 'Docker\Docker\Docker Desktop.exe'
  if (Test-Path $dd) { Start-Process $dd }
  for ($i = 0; $i -lt 90; $i++) { Start-Sleep -Seconds 2; docker info *> $null; if ($LASTEXITCODE -eq 0) { break } }
  if ($LASTEXITCODE -ne 0) { Fail 'Docker ne répond pas. Lancez Docker Desktop, puis relancez ce raccourci.' }
}
Push-Location $root
docker compose up -d db mail *> $null
Pop-Location
for ($i = 0; $i -lt 30; $i++) {
  docker exec itineo-db-1 pg_isready -U itineo *> $null
  if ($LASTEXITCODE -eq 0) { break }
  Start-Sleep -Seconds 1
}

$exists = (docker exec itineo-db-1 psql -U itineo -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$($e.Db)'") -eq '1'
if (-not $exists) {
  docker exec itineo-db-1 psql -U itineo -d postgres -c "CREATE DATABASE $($e.Db)" *> $null
}

# ─── Variables de cette édition (reprises par le serveur et l'appli) ───
$env:EDITION = $code
$env:DATABASE_URL = "postgres://itineo:itineo@localhost:5432/$($e.Db)"
$env:PORT = "$($e.Api)"
# http://localhost : l'appli Android (APK), capacitor://localhost : l'appli iPhone ; elles appellent le serveur directement
$env:WEB_ORIGIN = "http://localhost:$($e.Web),http://localhost,capacitor://localhost"
$env:WEB_PORT = "$($e.Web)"
$env:API_URL = "http://localhost:$($e.Api)"
$env:SMTP_URL = 'smtp://localhost:1025'

if (-not $exists -or $Reset) {
  Say '  Création des données de démonstration…'
  Push-Location (Join-Path $root 'apps\api')
  $out = & npx tsx $seed --reset 2>&1 | Out-String
  Pop-Location
  if ($out -notmatch '(exemple|A.R.G.E.) cr') { Say $out 'DarkGray'; Fail 'Les données de démonstration n''ont pas pu être créées.' }
}

# ─── Serveur et appli web ───
# Ils tournent dans cette fenêtre (fermer la fenêtre les arrête) ; leurs messages vont dans lanceurs\journaux
$logs = Join-Path $PSScriptRoot 'journaux'
New-Item -ItemType Directory -Force $logs | Out-Null
$log = { param($name) Join-Path $logs "$($Edition.ToLower())-$name.log" }
Say '  Démarrage du serveur…'
$api = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', 'npx tsx src/index.ts' -WorkingDirectory (Join-Path $root 'apps\api') `
  -NoNewWindow -PassThru -RedirectStandardOutput (& $log 'serveur') -RedirectStandardError (& $log 'serveur-erreurs')
if (-not (WaitPort $e.Api 90 $api)) { Fail "Le serveur n'a pas démarré. Détail : $(& $log 'serveur-erreurs')" }
Say '  Démarrage de l''appli…'
$web = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', 'npx vite' -WorkingDirectory (Join-Path $root 'apps\web') `
  -NoNewWindow -PassThru -RedirectStandardOutput (& $log 'appli') -RedirectStandardError (& $log 'appli-erreurs')
if (-not (WaitPort $e.Web 90 $web)) { Fail "L'appli n'a pas démarré. Détail : $(& $log 'appli-erreurs')" }

$url = "http://localhost:$($e.Web)"
Start-Process $url

# Adresse sur le réseau local : celle de la carte qui a une passerelle (Wi-Fi ou câble), pas des cartes virtuelles
$ip = (Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq 'Up' } | Select-Object -First 1).IPv4Address.IPAddress

Say ''
Say "  $($e.Name) est ouvert : $url" 'Green'
if ($ip) {
  Say "  Sur une tablette ou un téléphone du même Wi-Fi : http://$($ip):$($e.Web)"
  Say "  Appli Android (APK), adresse du serveur : $($ip):$($e.Api)"
}
Say ''
Say '  Comptes d''essai (mot de passe : demo1234)' 'Cyan'
if ($Edition -eq 'ARGE') {
  Say '    admin@arge.test             administrateur (tout voir)'
  Say '    direction@arge.test         direction'
  Say '    chef.dijon@arge.test        chef de l''agence de Dijon (siège)'
  Say '    planning.dijon@arge.test    planification, agence de Dijon'
  Say '    admin.ventes@arge.test      service administratif'
  Say '    tech.dijon@arge.test        appli terrain (3 rendez-vous aujourd''hui)'
  Say '    tech.nancy@arge.test        appli terrain, agence de Nancy'
  Say "  Espace client : $url/portail  (contact@pharmacie-du-lac.client.test)"
} else {
  Say '    admin@exemple.test          administrateur (tout voir)'
  Say '    direction.fr@exemple.test   direction France'
  Say '    chef.est@exemple.test       chef de l''agence Est'
  Say '    planning.est@exemple.test   planification, agence Est'
  Say '    compta.fr@exemple.test      comptabilité France'
  Say '    tech1.est@exemple.test      appli terrain (4 rendez-vous aujourd''hui)'
  Say '    tech.uk@exemple.test        appli terrain en anglais'
  Say "  Espace client : $url/portail  (contact.durand@client.test)"
}
Say '  E-mails envoyés (fiches, alertes SOS…) : http://localhost:8025'
Say ''
Say '  Laissez cette fenêtre ouverte pendant vos essais.' 'Yellow'
try {
  Read-Host '  Appuyez sur Entrée (ou fermez la fenêtre) pour arrêter le logiciel'
} finally {
  Say '  Arrêt…'
  foreach ($p in @($web, $api)) { if ($p -and -not $p.HasExited) { taskkill /PID $p.Id /T /F *> $null } }
}
