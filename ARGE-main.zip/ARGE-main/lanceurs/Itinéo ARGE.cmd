@echo off
rem Lance la version A.R.G.E. : base de donnees, serveur et appli, puis ouvre le navigateur
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lancer.ps1" -Edition ARGE
