﻿<#
  Construit l'appli Android A.R.G.E. (APK) et la publie pour les téléphones. Voir ANDROID.md.

    construire-apk.ps1                        (demande les nouveautés, puis construit et publie)
    construire-apk.ps1 -Notes "Correctifs"    (sans question)
    construire-apk.ps1 -NoPublish             (construit seulement : apk\ARGE-terrain.apk)

  Chaque construction reçoit un numéro de version plus grand que la précédente. Publier :
    - sur le serveur Itinéos de ce PC (dossier storage\app), pour les essais ;
    - sur le FTP OVH, dossier /ARGE/appli = https://arge.events-gs.fr/appli/ : l'appli installée y voit la nouvelle
      version et propose la mise à jour ; la page sert aussi à installer l'appli sur un nouveau téléphone.

  Identifiants FTP : %USERPROFILE%\.arge\ftp.ini, sinon ceux de LanShare (%USERPROFILE%\.lanshare\ftp.ini), même
  format (host, user, password, tls, et remote_dir facultatif). Ils ne sont jamais affichés ni mis dans le projet.

  Utilisé par « Construire l'APK Android.cmd » de ce dossier.
#>
param([string]$Notes, [switch]$NoPublish, [switch]$NoPause)
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
$Host.UI.RawUI.WindowTitle = 'A.R.G.E. – construction de l''APK'
$publicUrl = 'https://arge.events-gs.fr/appli'

function Say([string]$text, [string]$color = 'Gray') { Write-Host $text -ForegroundColor $color }
function Done([int]$code) {
  if (-not $NoPause) { Say ''; Read-Host '  Appuyez sur Entrée pour fermer' }
  exit $code
}
function Fail([string]$text) { Say ''; Say "  $text" 'Red'; Done 1 }

Say ''
Say '  A.R.G.E. – appli Android' 'Cyan'
Say '  ─────────────────────────────────────────'

# ─── Vérifications : Java et SDK d'Android Studio ───
$jbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
if (-not $env:JAVA_HOME -and (Test-Path $jbr)) { $env:JAVA_HOME = $jbr }
if (-not $env:JAVA_HOME) { Fail 'Java introuvable : installez Android Studio (https://developer.android.com/studio).' }
$sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
if (-not (Test-Path $sdk)) { Fail 'SDK Android introuvable : ouvrez Android Studio une fois pour l''installer.' }
$android = Join-Path $root 'apps\web\android'
# Emplacement du SDK pour Gradle (barres obliques : le format .properties lit « \ » comme un échappement)
Set-Content -Encoding ascii (Join-Path $android 'local.properties') "sdk.dir=$($sdk -replace '\\', '/')"
if (-not (Test-Path (Join-Path $root 'node_modules'))) {
  Say '  Première utilisation : installation des dépendances (quelques minutes)…'
  Push-Location $root; npm install --no-audit --no-fund | Out-Null; Pop-Location
}

# ─── Clé de publication A.R.G.E. (créée une seule fois, hors du projet) ───
# Les téléphones n'acceptent une mise à jour que signée avec la même clé : le dossier .arge est à sauvegarder.
$argeDir = Join-Path $env:USERPROFILE '.arge'
$signing = Join-Path $argeDir 'signature.properties'
if (-not (Test-Path $signing)) {
  Say '  Première construction : création de la clé de publication A.R.G.E.…' 'Yellow'
  New-Item -ItemType Directory -Force $argeDir | Out-Null
  $chars = [char[]]'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
  $bytes = New-Object byte[] 32
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $pass = -join ($bytes | ForEach-Object { $chars[$_ % $chars.Length] })
  $store = Join-Path $argeDir 'arge-release.jks'
  & (Join-Path $env:JAVA_HOME 'bin\keytool.exe') -genkeypair -keystore $store -alias arge -keyalg RSA -keysize 4096 -validity 36500 `
    -storepass $pass -keypass $pass -dname 'CN=Groupe A.R.G.E., O=Groupe A.R.G.E., C=FR' *> $null
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path $store)) { Fail 'Création de la clé impossible (keytool).' }
  $props = "storeFile=arge-release.jks`r`nstorePassword=$pass`r`nkeyAlias=arge`r`nkeyPassword=$pass`r`n"
  [IO.File]::WriteAllText($signing, $props, (New-Object System.Text.UTF8Encoding($false)))
  Say "  Clé créée dans $argeDir : SAUVEGARDEZ ce dossier (clé USB, coffre…)." 'Yellow'
  Say '  Sans lui, les téléphones ne pourront plus recevoir de mises à jour.' 'Yellow'
}

# ─── Numéro de version : minutes écoulées depuis le 1er janvier 2026, toujours croissant ───
$now = Get-Date
$code = [int][math]::Floor(($now.ToUniversalTime() - [datetime]::new(2026, 1, 1, 0, 0, 0, [DateTimeKind]::Utc)).TotalMinutes)
$name = $now.ToString('yyyy.MM.dd-HHmm')
$env:APP_VERSION_CODE = "$code"; $env:APP_VERSION_NAME = $name
$env:VITE_APP_VERSION_CODE = "$code"; $env:VITE_APP_VERSION_NAME = $name
# Notifications : seulement si le projet Firebase est relié (google-services.json), sinon l'appli planterait en s'y inscrivant
$firebase = Test-Path (Join-Path $root 'apps\web\android\app\google-services.json')
$env:VITE_PUSH = if ($firebase) { '1' } else { '' }
if (-not $firebase) { Say '  Sans google-services.json (Firebase) : pas de notifications dans cette version. Voir ANDROID.md.' 'DarkYellow' }
Say "  Version $name ($code)"

if (-not $NoPublish -and -not $PSBoundParameters.ContainsKey('Notes')) {
  Say ''
  $Notes = Read-Host '  Nouveautés de cette version (affichées sur les téléphones, Entrée pour aucune)'
}
if (-not $Notes) { $Notes = '' }
$Notes = $Notes.Trim()

# ─── Écrans (Vite), copiés dans le projet Android ───
Say '  Préparation des écrans…'
Push-Location $root
npm run android:sync -w @itineo/web *> $null
$ok = $LASTEXITCODE -eq 0
Pop-Location
if (-not $ok) { Fail 'La préparation des écrans a échoué. Lancez « npm run android:sync -w @itineo/web » pour voir le détail.' }

# ─── APK ───
Say '  Construction de l''APK (la première fois : plusieurs minutes)…'
Push-Location $android
& .\gradlew.bat assembleRelease --console=plain *> $null
$ok = $LASTEXITCODE -eq 0
Pop-Location
if (-not $ok) { Fail 'La construction a échoué. Dans apps\web\android, lancez « gradlew assembleRelease » pour voir le détail.' }
$built = Join-Path $android 'app\build\outputs\apk\release\app-release.apk'
if (-not (Test-Path $built)) { Fail "APK signée introuvable ($built) : vérifiez $signing." }

$out = Join-Path $root 'apk'
New-Item -ItemType Directory -Force $out | Out-Null
$apk = Join-Path $out 'ARGE-terrain.apk'
Copy-Item $built $apk -Force
Say "  APK prête : $apk" 'Green'
if ($NoPublish) { Done 0 }

# ─── Publication sur le serveur de ce PC (essais) ───
Push-Location (Join-Path $root 'apps\api')
$local = & npx tsx src/db/publish-apk.ts $apk $code $name $Notes 2>&1 | Out-String
Pop-Location
if ($LASTEXITCODE -eq 0) { Say '  Publiée sur le serveur de ce PC.' } else { Say "  Serveur de ce PC : $($local.Trim())" 'Yellow' }

# ─── Publication en ligne (FTP OVH) ───
function Read-Ini([string]$file) {
  $v = @{}
  foreach ($line in Get-Content $file -Encoding UTF8) {
    if ($line -match '^\s*([a-z_]+)\s*=\s*(.*?)\s*$') { $v[$Matches[1]] = $Matches[2] }
  }
  return $v
}
$ini = @("$env:USERPROFILE\.arge\ftp.ini", "$env:USERPROFILE\.lanshare\ftp.ini") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $ini) { Fail "Identifiants FTP introuvables : créez $env:USERPROFILE\.arge\ftp.ini (voir ANDROID.md)." }
$ftp = Read-Ini $ini
foreach ($k in 'host', 'user', 'password') { if (-not $ftp[$k]) { Fail "$ini incomplet : $k manquant." } }
# Le dossier de LanShare ne convient pas : sans remote_dir propre à A.R.G.E., c'est /ARGE/appli
$remote = if ($ini -like '*\.arge\*' -and $ftp['remote_dir']) { $ftp['remote_dir'] } else { '/ARGE/appli' }
$remote = '/' + $remote.Trim('/') + '/'
$remoteRoot = '/' + ($remote.Trim('/') -split '/')[0] + '/'
$tls = $ftp['tls'] -match '^(1|true|yes|oui)$'
# L'hébergement OVH actuel n'accepte ni FTPS ni SFTP : le mot de passe FTP passe en clair. L'APK, elle, est protégée
# par sa signature et son empreinte (sha256), vérifiées sur le téléphone.
if (-not $tls) { Say '  Attention : FTP sans chiffrement (hébergement OVH). Voir ANDROID.md, « Mises à jour automatiques ».' 'DarkYellow' }
$quote = { param($s) '"' + $s.Replace('\', '\\').Replace('"', '\"') + '"' }
$auth = "user = $(& $quote "$($ftp['user']):$($ftp['password'])")"

function Send([string]$file, [string]$dir, [string]$as) {
  # Identifiants dans un fichier de réglages de curl (-K), propre à cet envoi, dans le dossier temporaire du compte
  # Windows, effacé aussitôt : jamais sur la ligne de commande ni à l'écran. Écrit sans BOM : sinon curl ne
  # reconnaît pas l'option « user » (l'entrée standard de PowerShell 5.1 en ajoute un selon la façon de le lancer).
  $authFile = Join-Path $env:TEMP ("arge-ftp-" + [guid]::NewGuid().ToString('N') + '.conf')
  try {
    [IO.File]::WriteAllText($authFile, $auth, (New-Object System.Text.UTF8Encoding $false))
    $curlArgs = @('--fail', '--show-error', '--silent', '--ftp-create-dirs', '--retry', '2', '-T', $file, "ftp://$($ftp['host'])$dir$as", '-K', $authFile)
    if ($tls) { $curlArgs = @('--ssl-reqd') + $curlArgs }
    $err = & curl.exe @curlArgs 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) { Fail "Envoi FTP de $as impossible : $($err.Trim())" }
  } finally {
    Remove-Item -Force $authFile -ErrorAction SilentlyContinue
  }
}

Say "  Envoi sur $publicUrl …"
$tmp = Join-Path $env:TEMP "arge-appli-$code"
New-Item -ItemType Directory -Force $tmp | Out-Null
$apkName = "ARGE-terrain-$code.apk"
$size = (Get-Item $apk).Length
$utf8 = New-Object System.Text.UTF8Encoding($false)
$web = Join-Path $PSScriptRoot 'appli-en-ligne'

# Page de téléchargement, avec la version du jour
$enc = { param($s) [System.Net.WebUtility]::HtmlEncode($s) }
$page = Get-Content (Join-Path $web 'index.html') -Raw -Encoding UTF8
$page = $page.Replace('{{APK}}', $apkName).Replace('{{VERSION}}', (& $enc $name))
$page = $page.Replace('{{DATE}}', $now.ToString('dd/MM/yyyy à HH:mm')).Replace('{{SIZE}}', ('{0:N1} Mo' -f ($size / 1MB)))
$page = $page.Replace('{{NOTES}}', (& $enc $Notes)).Replace('{{NOTES_HIDDEN}}', $(if ($Notes) { '' } else { 'hidden' }))
[IO.File]::WriteAllText((Join-Path $tmp 'index.html'), $page, $utf8)

# Fiche lue par l'appli : envoyée en dernier, quand l'APK est déjà en place
$info = [ordered]@{
  versionCode = $code; versionName = $name; notes = $Notes; url = "$publicUrl/$apkName"; size = $size
  sha256 = (Get-FileHash $apk -Algorithm SHA256).Hash.ToLowerInvariant()
  publishedAt = $now.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
}
[IO.File]::WriteAllText((Join-Path $tmp 'android.json'), ($info | ConvertTo-Json), $utf8)

Send $apk $remote $apkName
Send (Join-Path $root 'apps\web\brand\arge-logo.png') $remote 'logo.png'
Send (Join-Path $web '.htaccess') $remote '.htaccess'
Send (Join-Path $tmp 'index.html') $remote 'index.html'
Send (Join-Path $web 'racine.htaccess') $remoteRoot '.htaccess'
Send (Join-Path $web 'racine.html') $remoteRoot 'index.html'
Send (Join-Path $tmp 'android.json') $remote 'android.json'
Remove-Item $tmp -Recurse -Force

# ─── Vérification ───
try {
  $online = Invoke-RestMethod "$publicUrl/android.json?t=$code" -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 20
  if ($online.versionCode -ne $code) { Fail "La version en ligne ($($online.versionCode)) n'est pas celle envoyée : vérifiez le dossier FTP." }
} catch { Fail "Vérification en ligne impossible : $($_.Exception.Message)" }

Say ''
Say "  Publiée : $publicUrl/" 'Green'
Say '  Les téléphones proposeront la mise à jour à la prochaine ouverture de l''appli.'
Done 0
