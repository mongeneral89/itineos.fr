﻿<#
  Efface les bases de démonstration des six éditions : elles seront recréées, avec des données neuves,
  au prochain lancement de chaque logiciel. La base de développement « itineo » n'est pas touchée.
#>
$dbs = 'itineo_tech', 'itineo_vigie', 'itineo_constat', 'itineo_expertise', 'itineo_cles', 'itineo_services', 'itineo_arge'
Write-Host ''
Write-Host '  Remise à zéro des données de démonstration des six éditions' -ForegroundColor Cyan
Write-Host '  Fermez d''abord les logiciels ouverts (Entrée dans leur fenêtre).' -ForegroundColor Yellow
$ok = Read-Host '  Tout effacer ? (o/n)'
if ($ok -notmatch '^[oOyY]') { exit 0 }
docker info *> $null
if ($LASTEXITCODE -ne 0) { Write-Host '  Docker Desktop n''est pas lancé.' -ForegroundColor Red; Read-Host '  Entrée pour fermer'; exit 1 }
foreach ($db in $dbs) {
  docker exec itineo-db-1 psql -U itineo -d postgres -c "DROP DATABASE IF EXISTS $db WITH (FORCE)" *> $null
  Write-Host "  $db effacée"
}
Write-Host ''
Write-Host '  Terminé : chaque logiciel repartira de données neuves à son prochain lancement.' -ForegroundColor Green
Read-Host '  Entrée pour fermer'
