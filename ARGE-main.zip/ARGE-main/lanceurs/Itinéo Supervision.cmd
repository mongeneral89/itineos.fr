@echo off
rem Lance la console de supervision (http://localhost:4000)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0supervision.ps1"
