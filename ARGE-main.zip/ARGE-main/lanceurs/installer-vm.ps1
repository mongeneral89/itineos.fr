﻿<#
  Installe ou met à jour A.R.G.E. sur la VM Linux de la Freebox (voir FREEBOX-VM.md).

  Envoie le code de ce PC (dernier commit de la branche en cours) et l'appli web construite ici (la VM n'a
  qu'1 Go de mémoire) vers la VM par SSH, puis y lance
  deploy/installer-vm.sh : Docker, base de données, https automatique et sauvegardes.
  Les réglages (adresse de la VM, utilisateur, domaine) sont gardés dans %USERPROFILE%\.arge\vm.ini.
  La première fois, le mot de passe de la VM est demandé une fois pour y déposer une clé SSH ; ensuite plus rien.
#>
param([switch]$NoPause)

# Continue : en PowerShell 5.1, « Stop » transforme en erreur tout message de ssh sur stderr.
# Chaque commande est vérifiée par son code de retour.
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
$conf = Join-Path $env:USERPROFILE '.arge\vm.ini'

function Say($text, $color = 'Gray') { Write-Host $text -ForegroundColor $color }
function Ask($question, $default) {
  $hint = if ($default) { " [$default]" } else { '' }
  $answer = Read-Host "  $question$hint"
  if ([string]::IsNullOrWhiteSpace($answer)) { return $default }
  return $answer.Trim()
}
# Texte entre apostrophes pour bash
function Quote($s) { return "'" + ($s -replace "'", "'\''") + "'" }
function WriteUnix($path, $text) {
  [IO.File]::WriteAllText($path, ($text -replace "`r`n", "`n"), (New-Object Text.UTF8Encoding $false))
}
function Done($code) {
  if (-not $NoPause) { Read-Host '  Appuyez sur Entrée pour fermer' | Out-Null }
  exit $code
}

try {
  Say ''
  Say '  Installation d''A.R.G.E. sur la VM de la Freebox' 'Cyan'
  Say ''

  foreach ($tool in @('ssh', 'scp', 'ssh-keygen', 'git')) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
      throw "$tool est introuvable. Windows : Paramètres > Système > Fonctionnalités facultatives > Client OpenSSH."
    }
  }

  # ─── Réglages ───
  $cfg = @{ hote = ''; utilisateur = ''; domaine = 'serveur.arge.events-gs.fr' }
  if (Test-Path $conf) {
    foreach ($line in Get-Content $conf -Encoding UTF8) {
      if ($line -match '^\s*(\w+)\s*=\s*(.*?)\s*$') { $cfg[$Matches[1]] = $Matches[2] }
    }
  }
  $cfg.hote = Ask 'Adresse de la VM sur le réseau de la box (ex. 192.168.1.50)' $cfg.hote
  $cfg.utilisateur = Ask 'Utilisateur de la VM' $cfg.utilisateur
  $cfg.domaine = Ask 'Adresse internet du serveur' $cfg.domaine
  if (-not $cfg.hote -or -not $cfg.utilisateur -or -not $cfg.domaine) { throw 'Adresse, utilisateur et domaine sont obligatoires.' }
  New-Item -ItemType Directory -Force (Split-Path $conf) -ErrorAction Stop | Out-Null
  WriteUnix $conf "hote=$($cfg.hote)`nutilisateur=$($cfg.utilisateur)`ndomaine=$($cfg.domaine)`n"
  $target = "$($cfg.utilisateur)@$($cfg.hote)"

  # ─── Clé SSH : le mot de passe de la VM n'est demandé qu'une fois ───
  $key = Join-Path $env:USERPROFILE '.ssh\id_ed25519'
  if (-not (Test-Path $key)) {
    Say '  Création d''une clé SSH pour ce PC' 'Cyan'
    New-Item -ItemType Directory -Force (Split-Path $key) | Out-Null
    & ssh-keygen -q -t ed25519 -f $key -N '""' -C "arge-$env:COMPUTERNAME"
    if ($LASTEXITCODE -ne 0) { throw 'Création de la clé SSH impossible.' }
  }
  & ssh -o BatchMode=yes -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new $target true 2>$null
  if ($LASTEXITCODE -ne 0) {
    Say "  Première connexion à $target : tapez le mot de passe de la VM (il ne s'affiche pas)." 'Yellow'
    Get-Content "$key.pub" | & ssh -o StrictHostKeyChecking=accept-new $target 'umask 077; mkdir -p ~/.ssh; cat >> ~/.ssh/authorized_keys'
    if ($LASTEXITCODE -ne 0) { throw "Connexion à $target impossible. Vérifiez l'adresse, l'utilisateur et que la VM est démarrée." }
  }

  # ─── Première installation ou mise à jour ? ───
  & ssh $target 'test -f /opt/arge/.env.production' 2>$null
  $first = ($LASTEXITCODE -ne 0)
  $args2 = @('--domaine', $cfg.domaine)
  if ($first) {
    Say ''
    Say '  Première installation : quel premier compte ?' 'Cyan'
    Say '    1. Un vrai compte administrateur (conseillé)'
    Say '    2. Les données d''essai A.R.G.E. (comptes fictifs, mot de passe demo1234, visibles depuis Internet)'
    if ((Ask 'Votre choix' '1') -eq '2') {
      $args2 += '--demo'
    } else {
      $args2 += @('--email', (Ask 'E-mail de l''administrateur' ''), '--prenom', (Ask 'Prénom' ''), '--nom', (Ask 'Nom' ''))
    }
  } else {
    Say '  A.R.G.E. est déjà installé sur la VM : mise à jour (réglages et données gardés).' 'Green'
  }

  # ─── Code à envoyer : le dernier commit ───
  $dirty = & git -C $root status --porcelain
  if ($dirty) {
    Say '  Attention : des modifications ne sont pas enregistrées (commit). Le code envoyé est celui du dernier' 'Yellow'
    Say '  commit, mais l''appli web est construite depuis les fichiers actuels.' 'Yellow'
    if ((Ask 'Continuer quand même ? (o/n)' 'n') -notmatch '^[oO]') { throw 'Arrêté : faites d''abord un commit.' }
  }
  $branch = (& git -C $root rev-parse --abbrev-ref HEAD).Trim()
  $commit = (& git -C $root rev-parse --short HEAD).Trim()
  Say "  Envoi de la branche $branch ($commit)" 'Cyan'

  $tmp = Join-Path $env:TEMP 'arge-vm'
  New-Item -ItemType Directory -Force $tmp -ErrorAction Stop | Out-Null
  $tar = Join-Path $tmp 'arge.tar'
  & git -C $root archive --format=tar -o $tar HEAD
  if ($LASTEXITCODE -ne 0) { throw 'Préparation du code impossible (git archive).' }

  # Appli web construite ici : la VM (1 Go de mémoire) n'en a pas assez pour le faire
  Say '  Construction de l''appli web sur ce PC (1 à 2 minutes)' 'Cyan'
  $env:EDITION = 'TECH'
  Push-Location $root
  & npm run build -w '@itineo/web' '--' '--mode' 'arge'
  $built = $LASTEXITCODE
  Pop-Location
  if ($built -ne 0) { throw 'Construction de l''appli web impossible (voir les messages ci-dessus).' }
  # Lien « Ouvrir l'appli » des invitations : Android ne l'ouvre dans l'appli que si le serveur publie l'empreinte
  # de la clé qui la signe (App Link). Empreinte publique, lue dans la clé de %USERPROFILE%\.arge
  $props = Join-Path $env:USERPROFILE '.arge\signature.properties'
  if (Test-Path $props) {
    $sig = @{}
    foreach ($line in Get-Content $props -Encoding UTF8) { if ($line -match '^\s*(\w+)\s*=\s*(.*?)\s*$') { $sig[$Matches[1]] = $Matches[2] } }
    $jbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr\bin\keytool.exe'
    $keytool = if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin\keytool.exe'))) { Join-Path $env:JAVA_HOME 'bin\keytool.exe' } else { $jbr }
    # Chemin de la clé : relatif au dossier .arge (comme pour Gradle)
    $store = if ([IO.Path]::IsPathRooted($sig['storeFile'])) { $sig['storeFile'] } else { Join-Path (Split-Path $props) $sig['storeFile'] }
    if (Test-Path $keytool) {
      # Mot de passe passé par une variable d'environnement : jamais sur la ligne de commande ; keytool en anglais
      # (sa version française plante sur -list -v)
      $env:ARGE_STOREPASS = $sig['storePassword']
      $listing = & $keytool '-J-Duser.language=en' -list -v -keystore $store -alias $sig['keyAlias'] '-storepass:env' ARGE_STOREPASS 2>$null | Out-String
      Remove-Item Env:ARGE_STOREPASS -ErrorAction SilentlyContinue
      if ($listing -match 'SHA256:\s*([0-9A-F:]{95})') {
        $wk = Join-Path $root 'apps\web\dist\.well-known'
        New-Item -ItemType Directory -Force $wk -ErrorAction Stop | Out-Null
        $links = '[{"relation":["delegate_permission/common.handle_all_urls"],"target":{"namespace":"android_app","package_name":"fr.arge.terrain","sha256_cert_fingerprints":["' + $Matches[1] + '"]}}]'
        WriteUnix (Join-Path $wk 'assetlinks.json') $links
      } else { Say '  Empreinte de la clé introuvable : « Ouvrir l''appli » des invitations ouvrira le navigateur.' 'Yellow' }
    }
  }
  $web = Join-Path $tmp 'web.tar'
  & tar.exe -cf $web -C (Join-Path $root 'apps\web\dist') .
  if ($LASTEXITCODE -ne 0) { throw 'Préparation de l''appli web impossible.' }

  # Fichiers déposés dans un dossier privé du compte (pas dans /tmp, ouvert à tous les comptes de la VM)
  $quoted = ($args2 | ForEach-Object { Quote $_ }) -join ' '
  WriteUnix (Join-Path $tmp 'arge-go.sh') @"
set -e
D="`$HOME/.arge-envoi"
trap 'rm -rf "`$D"' EXIT
sudo mkdir -p /opt/arge
# Ancienne version effacée, sauf les réglages, les secrets et les sauvegardes
sudo find /opt/arge -mindepth 1 -maxdepth 1 ! -name .env.production ! -name backups ! -name secrets -exec rm -rf {} +
sudo tar -xf "`$D/arge.tar" -C /opt/arge
sudo mkdir -p /opt/arge/deploy/web-dist
sudo tar -xf "`$D/web.tar" -C /opt/arge/deploy/web-dist
# Compte de service Firebase (notifications de l'appli), s'il a été envoyé
if [ -f "`$D/firebase-service-account.json" ]; then
  sudo mkdir -p /opt/arge/secrets
  sudo install -m 600 "`$D/firebase-service-account.json" /opt/arge/secrets/firebase-service-account.json
fi
sudo bash /opt/arge/deploy/installer-vm.sh $quoted
"@

  & ssh $target 'rm -rf ~/.arge-envoi; umask 077; mkdir ~/.arge-envoi'
  if ($LASTEXITCODE -ne 0) { throw 'Préparation de la VM impossible.' }
  $files = @($tar, $web, (Join-Path $tmp 'arge-go.sh'))
  # Notifications de l'appli Android : compte de service Firebase (secret), gardé dans %USERPROFILE%\.arge
  $fcm = Join-Path $env:USERPROFILE '.arge\firebase-service-account.json'
  if (Test-Path $fcm) { $files += $fcm; Say '  Compte de service Firebase envoyé (notifications de l''appli).' 'Cyan' }
  else { Say '  Pas de compte de service Firebase : l''appli Android ne recevra pas de notification.' 'Yellow' }
  & scp -q @files "${target}:.arge-envoi/"
  if ($LASTEXITCODE -ne 0) { throw 'Envoi du code vers la VM impossible.' }
  Remove-Item -Recurse -Force $tmp

  Say '  Installation sur la VM (la première fois : 10 à 30 minutes, laissez la fenêtre ouverte)' 'Cyan'
  & ssh -t $target 'bash ~/.arge-envoi/arge-go.sh'
  if ($LASTEXITCODE -ne 0) { throw 'L''installation sur la VM a échoué (voir les messages ci-dessus).' }

  Say ''
  Say "  Terminé. Logiciel du bureau : https://$($cfg.domaine)" 'Green'
  Say "  Appli Android, champ « Serveur » : $($cfg.domaine)" 'Green'
  Done 0
} catch {
  Say ''
  Say "  ERREUR : $($_.Exception.Message)" 'Red'
  Done 1
}
