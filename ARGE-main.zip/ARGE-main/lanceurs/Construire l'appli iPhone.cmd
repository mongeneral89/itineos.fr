@echo off
rem Lance la construction de l'appli iPhone sur GitHub (voir IPHONE.md) : le dernier commit envoye sur GitHub
cd /d "%~dp0.."
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmm"') do set ETIQUETTE=iphone-%%i
git tag %ETIQUETTE% && git push origin %ETIQUETTE%
if errorlevel 1 (
  echo.
  echo   Envoi impossible : verifiez la connexion a GitHub.
  pause
  exit /b 1
)
echo.
echo   Construction lancee sur GitHub (10 a 15 minutes). Le fichier .ipa sera dans "Artifacts".
start "" "https://github.com/gyann4398-sketch/ARGE/actions/workflows/iphone.yml"
pause
