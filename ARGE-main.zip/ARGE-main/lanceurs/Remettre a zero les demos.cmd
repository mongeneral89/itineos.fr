@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0remettre-a-zero.ps1"
