# Appli iPhone d'A.R.G.E. (essais, sans compte Apple payant)

Même appli que sur Android (Capacitor, projet `apps/web/ios`), construite par un **Mac de GitHub** puis installée
depuis un **PC Windows** avec **Sideloadly** et un **identifiant Apple gratuit**.

| | Essais (gratuit) | Plus tard (compte Apple Developer, 99 €/an) |
|---|---|---|
| Installation | iPhone branché en USB sur un PC | TestFlight, sans câble |
| Durée | l'appli s'arrête après **7 jours** : la réinstaller | sans limite |
| Téléphones | quelques-uns par identifiant Apple | tous les techniciens |
| Notifications | non (réservées aux comptes payants) | oui (Firebase + clé Apple) |

## 1. Construire l'appli (sur GitHub)

1. Les modifications doivent être envoyées sur GitHub.
2. Double-clic sur **`lanceurs\Construire l'appli iPhone.cmd`** : il pose une étiquette `iphone-AAAAMMJJ-HHMM` sur
   le dernier commit, l'envoie, et ouvre la page de la construction.
3. Après 10 à 15 minutes, la ligne de la construction passe au vert ✓. Cliquez dessus : en bas, **Artifacts** →
   **ARGE-iphone-…** se télécharge (un `.zip` qui contient le fichier **`.ipa`** : dézippez-le).

La construction utilise les minutes gratuites de GitHub (un Mac compte 10 fois plus : une vingtaine de
constructions par mois avec l'offre gratuite).

## 2. Préparer le PC (une seule fois)

1. **iTunes** et **iCloud** depuis le site d'Apple (pas la version du Microsoft Store) :
   https://www.apple.com/fr/itunes/ — Sideloadly en a besoin pour parler à l'iPhone.
2. **Sideloadly** : https://sideloadly.io (gratuit).

## 3. Installer sur un iPhone

1. Branchez l'iPhone au PC en USB, déverrouillez-le, touchez **Faire confiance** à cet ordinateur.
2. Ouvrez Sideloadly : l'iPhone apparaît en haut. Glissez le fichier **`.ipa`** dans la fenêtre.
3. **Apple ID** : votre identifiant Apple (ou celui du propriétaire de l'iPhone), puis **Start**. Le mot de passe et
   le code de validation à deux facteurs sont demandés : ils vont à Apple, pas au projet.
4. Sur l'iPhone, la première fois :
   - **Réglages → Général → VPN et gestion de l'appareil** → votre identifiant → **Faire confiance** ;
   - iOS 16 et plus : **Réglages → Confidentialité et sécurité → Mode développeur** → activer, redémarrer, confirmer.
5. Ouvrez **A.R.G.E.** : champ **Serveur** = `serveur.arge.events-gs.fr`, puis le compte.

**Tous les 7 jours** : rebranchez l'iPhone et refaites **Start** dans Sideloadly avec le même `.ipa` (les données et
la connexion sont gardées). Sideloadly peut aussi le faire tout seul par le Wi-Fi si le PC reste allumé (option
« Automatic refresh »).

## Ce qui diffère d'Android

- **Mises à jour** : pas de bandeau « Mettre à jour » sur iPhone (Apple interdit d'installer une appli depuis une
  autre appli) : construire une nouvelle version (étape 1) et la réinstaller avec Sideloadly.
- **Notifications** : seulement avec le compte payant (prévu : Firebase sait aussi les envoyer aux iPhone).
- Le serveur accepte l'appli iPhone (`capacitor://localhost` dans `WEB_ORIGIN`, `docker-compose.prod.yml`).
