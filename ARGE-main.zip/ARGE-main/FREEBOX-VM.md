# A.R.G.E. sur la Freebox Delta (machine virtuelle)

Le serveur A.R.G.E. tourne dans une petite machine Linux à l'intérieur de la Freebox : allumé jour et nuit,
sans PC à laisser allumé, sans abonnement. Le logiciel du bureau et l'appli Android s'y connectent par
`https://serveur.arge.events-gs.fr`, depuis le bureau comme depuis la 4G.

```
Téléphone (4G, Wi-Fi) / navigateur du bureau
        │  https://serveur.arge.events-gs.fr
        ▼
DNS chez OVH ──► adresse IP de la Freebox ──► ports 80 et 443 redirigés vers la VM
        ▼
VM Linux : serveur A.R.G.E. + base de données + https (Let's Encrypt) + sauvegardes quotidiennes
```

Les noms de menus de Freebox OS et d'OVH peuvent varier un peu selon les versions.

## 1. Créer la VM (Freebox OS)

1. Ouvrez **http://mafreebox.freebox.fr** et connectez-vous.
2. Il faut un **disque** branché à la Freebox (interne ou USB, idéalement un SSD) : la VM et les photos y sont rangées.
3. Ouvrez **VMs** puis **Ajouter une VM** :
   - système pré-installé : **Debian 12 (Bookworm)** ;
   - utilisateur par défaut : `arge` ;
   - clé SSH : le contenu de `%USERPROFILE%\.ssh\id_ed25519.pub` de ce PC (s'il n'existe pas :
     `ssh-keygen -t ed25519` dans un terminal) ;
   - mot de passe : mettez-en un aussi et notez-le (demandé par `sudo` pendant l'installation) ;
   - accès aux disques Freebox : inutile ;
   - mémoire : le maximum proposé (**1000 Mo** sur la Delta S, c'est suffisant : l'appli web est construite sur
     ce PC, et l'installation ajoute 3 Go de mémoire d'appoint sur le disque) ;
   - processeurs : le maximum proposé ;
   - disque : **32 Go** au moins.
4. Démarrez la VM.
5. Dans **Paramètres de la Freebox > Mode avancé > DHCP**, donnez à la VM une **adresse fixe** (bail statique),
   par exemple `192.168.1.50`. Elle apparaît dans la liste des appareils connectés.

## 2. Une adresse IP fixe et complète chez Free

Dans l'**espace abonné Free** (Ma Freebox > Paramétrer mon routeur Freebox), demandez une **adresse IPv4 fixe
« full-stack »** si ce n'est pas déjà le cas : avec une adresse partagée, les ports 80 et 443 ne sont pas joignables.
Notez votre adresse IPv4 (elle s'affiche aussi dans Freebox OS, **État de la Freebox**).

## 3. Rediriger les ports vers la VM (Freebox OS)

**Paramètres de la Freebox > Mode avancé > Gestion des ports**, ajoutez deux redirections vers l'adresse de la VM :

| Port externe | Port de destination | Protocole | Vers |
|---|---|---|---|
| 80 | 80 | TCP | 192.168.1.50 |
| 443 | 443 | TCP | 192.168.1.50 |

Si Freebox OS refuse le port 80 ou 443 parce que l'**accès à distance** de la Freebox l'utilise, changez le port de
l'accès à distance (Paramètres > Accès à distance), puis recommencez.

## 4. Faire pointer le domaine vers la Freebox (OVH)

Espace client OVH > **Noms de domaine > events-gs.fr > Zone DNS > Ajouter une entrée** :

- type **A** ;
- sous-domaine **serveur.arge** ;
- cible : **l'adresse IPv4 de la Freebox**.

Comptez de quelques minutes à quelques heures. L'appli en ligne (`arge.events-gs.fr/appli`) reste chez OVH :
elle n'est pas touchée.

## 5. Installer A.R.G.E. (depuis ce PC)

Double-cliquez sur **`lanceurs\Installer sur la VM Freebox.cmd`**. Il demande :

1. l'adresse de la VM (`192.168.1.50`) et son utilisateur ;
2. l'adresse internet (`serveur.arge.events-gs.fr`, proposée) ;
3. la première fois, le **mot de passe de la VM** (une seule fois : une clé SSH est ensuite déposée) ;
4. le premier compte : un **vrai administrateur** (conseillé ; un mot de passe provisoire s'affiche **une seule
   fois**, notez-le), ou les **données d'essai** A.R.G.E. (comptes fictifs `demo1234`, à réserver aux essais car ils
   sont accessibles depuis Internet).

La première installation dure **10 à 30 minutes** : la Freebox construit tout elle-même. Ensuite :

- **logiciel du bureau** : https://serveur.arge.events-gs.fr ;
- **appli Android** : champ **Serveur** = `serveur.arge.events-gs.fr`.

Le code envoyé est le **dernier commit** de la branche ouverte sur ce PC (aujourd'hui `feat/app-android-arge`).
L'appli web est construite sur ce PC (Node.js nécessaire, comme pour les lanceurs) puis envoyée toute prête.

## Mettre à jour

Même double-clic. Une sauvegarde est faite avant, les réglages et les données sont gardés.

## Sauvegardes

Chaque jour dans `/opt/arge/backups` sur la VM (base de données + photos et PDF, 14 jours gardés).
**Une sauvegarde sur la Freebox ne protège pas d'une panne de la Freebox** : copiez-les régulièrement ailleurs,
par exemple sur ce PC :

```bash
scp -r UTILISATEUR@192.168.1.50:/opt/arge/backups .
```

Gardez aussi une copie de `/opt/arge/.env.production` (les secrets du serveur) en lieu sûr. Restauration :
[DEPLOIEMENT.md](DEPLOIEMENT.md), « Restaurer une sauvegarde » (ici, le volume s'appelle `arge_storage` et les
commandes prennent `-p arge`).

## En cas de souci

Sur la VM (`ssh UTILISATEUR@192.168.1.50`) :

```bash
cd /opt/arge
sudo docker compose -f docker-compose.prod.yml --env-file .env.production -p arge ps
sudo docker compose -f docker-compose.prod.yml --env-file .env.production -p arge logs web --tail 50
sudo docker compose -f docker-compose.prod.yml --env-file .env.production -p arge logs api --tail 50
```

- **https ne marche pas** (journal `web` : erreurs de certificat) : la zone DNS (étape 4) ou les redirections de ports
  (étape 3) ne sont pas encore bonnes. Le certificat est redemandé tout seul dès qu'elles le sont.
- **Ça marche en 4G mais pas depuis le Wi-Fi du bureau** : certaines box ne savent pas « revenir » vers elles-mêmes.
  Essayez depuis un téléphone en 4G pour vérifier, puis signalez-le.
- **E-mails** (fiches PDF, mot de passe oublié) : renseignez `SMTP_URL` dans `/opt/arge/.env.production`, puis
  relancez l'installation.
