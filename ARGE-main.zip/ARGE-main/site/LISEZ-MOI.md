# La page d'accueil d'itineos.fr

Une seule page statique : `index.html`, le dossier `img` et le dossier `fonts`. Pas de programme, pas de base de données, pas de cookie. Les polices sont hébergées sur le site lui-même, pour que les visiteurs ne se connectent pas aux serveurs de Google.

## Avant de la mettre en ligne

Le téléphone, l'adresse e-mail (créée), l'adresse postale, le SIRET et l'hébergeur sont remplis (23/10/2026). L'adresse de l'hébergeur vient des conditions générales d'IONOS SARL France (ionos.fr/terms-gtc/cgv/). Si tu changes d'hébergeur, change aussi cette ligne. Il reste :

1. **Ta photo** (facultatif, mais recommandé : c'est la réponse à « qui est derrière ? ») : mets `justin.jpg` dans `img`, puis remplace `JS` par `<img src="img/justin.jpg" alt="Justin Simonetti">`.

À tenir à jour ensuite :
- **Le nombre de places libres** (« 5 places sur 5 ») : il doit toujours être le vrai nombre.
- **La mention « Contrat de dépôt et support de secours en cours de mise en place »** : à retirer une fois les deux contrats signés, pas avant (voir `founder/launch.md`).
- **La vidéo de 30 secondes** : un emplacement est prévu sous la première partie, en commentaire.

## Où le site est publié (depuis le 23/10/2026)

L'offre IONOS du compte est un **MyWebsite Now Plus** (créateur de site) : elle ne permet pas d'envoyer ses propres fichiers. La page est donc publiée **gratuitement sur GitHub Pages** :

- dépôt public : https://github.com/mongeneral89/itineos.fr (compte GitHub **mongeneral89**, dédié à Itinéos) ;
- il ne contient que la page : `index.html`, `img/`, `fonts/`, `CNAME` (le domaine) et `.nojekyll`. Rien du logiciel ;
- les mentions légales indiquent GitHub, Inc. comme hébergeur.

**Réglages DNS chez IONOS** (Domaines & SSL → itineos.fr → DNS) :
- 4 enregistrements **A** sur `@` : 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153 (GitHub Pages) ;
- un **CNAME** `www` → `mongeneral89.github.io` ;
- les enregistrements **e-mail** (MX, SPF, DKIM, DMARC, autodiscover) sont ceux d'IONOS : **ne pas y toucher**, sinon justin.simonetti@itineos.fr ne marche plus.

## Modifier la page

1. Modifie les fichiers dans ce dossier `site`.
2. Copie `index.html`, `img/`, `fonts/` (et `CNAME`, `.nojekyll` s'ils ont changé) dans une copie locale du dépôt `mongeneral89/itineos.fr` (`git clone https://mongeneral89@github.com/mongeneral89/itineos.fr.git`).
3. `git add -A`, `git commit -m "…"`, `git push`. La page en ligne est à jour en une à deux minutes.

## itineos.com, .info, .store

Ils sont dans le compte IONOS mais ne sont pas utilisés. Pour les renvoyer vers le site : Domaines & SSL → le domaine → **Rediriger** vers `https://itineos.fr` (redirection permanente, 301).

## Voir la page sur ton PC

Ouvre `index.html` dans ton navigateur. Si les polices ne s'affichent pas en ouvrant le fichier directement, lance un petit serveur depuis le dossier du projet :

```
python -m http.server 5199 --directory site
```

puis ouvre http://localhost:5199.
