# Buyer panel: Itinéos Sécurité : logiciel de gestion d'interventions (bureau + appli terrain) pour installateurs d'alarme, de vidéosurveillance et de télésurveillance

**2 buy · 18 pass** (10% buy) out of 20 simulated buyers. Seed 916646, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

## By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Directeur des opérations d'un groupe multi-agences type ARGE (26 à 50 techniciens, 3 à 5 agences, télésurveillance via un partenaire) | 4 | 25%  (thin) |
| Dirigeant d'une petite entreprise d'alarme (3 à 8 techniciens, une seule agence, le dirigeant fait encore des interventions) | 9 | 11% |
| Dirigeant ou responsable d'exploitation d'une PME de sécurité (9 à 25 techniciens, une ou deux agences, une assistante au planning) | 7 | 0%  (thin) |

## By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Cherche à se structurer pour grandir | 2 | 100%  (thin) |
| Méfiant envers les petits éditeurs | 3 | 0%  (thin) |
| Regarde d'abord le prix | 3 | 0%  (thin) |
| Déjà équipé d'un ERP sécurité | 4 | 0%  (thin) |
| Encore au papier | 5 | 0%  (thin) |
| Déjà sur un outil de terrain généraliste | 3 | 0%  (thin) |

## By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| under $53,000 | 6 | 17%  (thin) |
| $74,000 and up | 7 | 14%  (thin) |
| $53,000 to $74,000 | 7 | 0%  (thin) |

## Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| trust | 7 | "Vous me dites vous-même que les premières références dans la sécurité, ce sera moi : je ne mets pas mon planning, mes contrats de maintenance et mes abonnés entre les mains d'un éditeur que personne du métier n'a encore testé. Et sans le prélèvement SEPA des abonnements de télésurveillance, je garde de toute façon un deuxième outil pour ce qui fait l'essentiel de mon chiffre." (P001) · "Vous me dites vous-même qu'il n'y a encore aucune référence dans la sécurité, et que les premières ce sera moi : j'ai déjà vu un éditeur disparaître, je ne veux pas servir de cobaye avec mes contrats de maintenance et mes abonnés. En plus, sans prélèvement SEPA des abonnements de télésurveillance, je garde mon outil actuel pour ce qui fait mon chiffre." (P004) |
| habit | 7 | "Mon ERP gère déjà les abonnements et le prélèvement, et tout mon historique est dedans ; votre logiciel ne fait pas le SEPA, donc au mieux c'est un deuxième outil à payer et à faire tenir à côté. Je reçois ce genre de proposition chaque semaine, je ne change pas pour une meilleure appli mobile." (P007) · "Le papier carboné et la ressaisie du vendredi, ça me coûte du temps mais ça marche, et je n'ai pas la tête à changer tout l'atelier cette semaine. L'essai gratuit avec reprise des données, c'est bien vu, mais je mets ça de côté pour « plus tard », comme d'habitude." (P009) |
| price | 3 | "Avec 35 techniciens, la formule Sécurité recommandée, c'est autour de 1 200 € HT par mois même après la remise, soit plus de 14 000 € par an, et je dois quand même garder mon ERP pour le prélèvement SEPA des abonnements. Sur nos marges de pose, je ne rajoute pas un abonnement de cette taille à côté de ce qu'on paie déjà, surtout pour un éditeur qui n'a encore aucune référence dans la sécurité." (P003) · "Avec 5 techniciens, la formule Sécurité c'est près de 200 € HT par mois de plus, tous les mois, alors que mes marges sur la pose sont déjà serrées et que je m'en sors avec ce que j'ai. Je reçois ce genre d'offre chaque semaine ; un éditeur sans aucune référence dans la sécurité, je préfère attendre de voir." (P005) |
| need | 1 | "Ma première question c'était le prélèvement de mes abonnements de télésurveillance, et c'est justement ce que ça ne fait pas. Je garderais donc EBP pour ça, plus un nouveau logiciel à côté, et après trente ans de papier je ne change pas tout pour avoir deux outils au lieu d'un." (P011) |

## Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |
| convenience | 1 | "Je viens de passer à deux agences et je fais mes devis et factures le samedi matin : si le gars vient reprendre mes données lui-même et former mes techniciens, je tente les 60 jours sur une agence, ça ne me coûte rien. Mais je signe l'essai, pas encore le reste : je paierai seulement si mes techniciens l'adoptent." (P002) |
| need | 1 | "Je viens de racheter une agence et chacun a ses outils et ses papiers ; un planning multi-agences avec une appli qui marche dans les sous-sols, c'est exactement ce qu'il me faut. Un essai gratuit sur une seule agence avec la reprise des données faite par eux, ça ne me coûte rien d'essayer, mais je ne m'engage pas sur tout le groupe avant d'avoir vu." (P010) |

## What would flip a no

- Parler à deux ou trois installateurs comme moi qui l'utilisent depuis plus de six mois, et savoir qui assure le support à part le fondateur.
- Que le prélèvement SEPA des abonnements de télésurveillance soit fait, pour pouvoir résilier mon ERP et que le coût total baisse, ou une formule Terrain autour de 15 € par technicien pour l'utiliser à côté.
- Parler à deux ou trois installateurs d'alarme qui l'utilisent depuis au moins six mois, et savoir qui d'autre que le fondateur assure le support.
- Un installateur de ma taille que je connais qui l'utilise depuis quelques mois et me dit qu'il gagne du temps sur la paperasse, avec la formule Terrain à 25 € qui suffit pour moi.
- Un chiffrage écrit montrant que le coût total par mois est inférieur à ce qu'on paie aujourd'hui (logiciel actuel plus temps de ressaisie des bons et rapports), ou un forfait groupe plafonné autour de 1 000 € HT par mois.
- Une synchronisation automatique prouvée avec mon ERP (clients, sites, interventions remontés sans ressaisie), montrée chez un installateur qui l'utilise déjà.
- Pouvoir appeler deux ou trois installateurs d'alarme qui l'utilisent depuis plusieurs mois et savoir qu'il y a plus d'une personne derrière le support.
- Voir un installateur comme moi, avec des techniciens de mon âge, qui l'utilise depuis six mois et qui me dise au téléphone que ses gars n'ont pas lâché.
- Que le prélèvement SEPA des abonnements soit fait avant mon échéance de facture électronique, ou que mon comptable me confirme que l'export vers EBP couvre bien la facture électronique sans ressaisie.
- Un collègue installateur que je connais qui l'utilise depuis quelques mois et qui me dit qu'il a récupéré ses samedis matins.
- Une liaison directe avec le portail de mon télésurveilleur pour pousser les consignes sans ressaisie, et un confrère installateur que je peux appeler qui l'utilise déjà.
- Que mon ERP actuel ne passe pas la facture électronique à temps, ou qu'un confrère installateur que je connais me dise qu'il l'utilise depuis six mois sans problème.

Buyers say they would buy **1.0 times** in the first month on average.

20 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.
