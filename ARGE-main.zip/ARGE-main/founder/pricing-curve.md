# Price sensitivity

20 complete answers. Simulated buyers: use this to pick what to test, not as the final word.

| point | price | what it means |
| --- | ---: | --- |
| PMC | $15.20 | below this, too many think it is too cheap to be good |
| OPP | $15.20 | as many say too cheap as too expensive: the least resistance |
| IPP | $30.20 | as many call it a bargain as call it expensive |
| PME | $54.83 | above this, too many say it is too expensive to buy |

**Acceptable range: $15.20 to $54.83.**

Median answers: too cheap $12.00, a bargain $25.00, getting expensive $40.00, too expensive $60.00.

Your current price, $45.00, is **inside** the acceptable range.
