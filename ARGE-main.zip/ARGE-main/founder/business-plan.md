# Itinéos Sécurité (nom de travail) : Itinéos recentré sur l'alarme et la vidéosurveillance · Business plan

**Verdict: Not yet**

- ✓ Each technicien payé par mois earns $25.22 before fixed costs (72% contribution).
- ✓ Year 1 operating profit: $2,483.
- ✗ 0 of 20 simulated buyers buy (0%, the bar is 25%).

| key number | |
| --- | ---: |
| Price | $35.00 a technicien payé par mois |
| Profit margin at plan | 61% per technicien payé par mois |
| Break-even | 17 technicien payé par moiss a day |
| Year 1 operating profit | $2,483 |
| Startup spend | $2,580 |
| Cash needed before it pays for itself | $4,030 |
| Startup money earned back | not in year 1 |
| Buyer panel | 0 buy · 20 pass |

## The idea

- What it is: un logiciel de gestion d'interventions (bureau + appli terrain) réservé aux entreprises qui installent et entretiennent des systèmes d'alarme intrusion, de vidéosurveillance (vidéoprotection), de contrôle d'accès et qui raccordent leurs clients à la télésurveillance.
- Who it is for: les installateurs de sécurité électronique en France, de 3 à 50 techniciens, mono ou multi-agences, souvent autorisés par le CNAPS. Profil type : A.R.G.E. (siège à Quetigny, agences Nancy, Lille, Fontainebleau ; alarme, vidéo, télésurveillance via un télésurveilleur partenaire, défibrillateurs). Acheteur : le dirigeant ou le responsable d'exploitation.
- What it sells, at what price: un abonnement par technicien de terrain et par mois, bureau illimité. Grille actuelle (identique au produit généraliste) : Essentiel 29 € HT, Pro 45 € HT, Entreprise 65 € HT, avec engagement 12 mois (environ +20 % sans engagement), dès 3 techniciens. Mise en service dès 300 € HT (import des clients et des documents, paramétrage, formation). Essai gratuit 30 jours.
- Where and how: France. Prospection directe par le fondateur (e-mails personnalisés, téléphone, démonstration de 30 minutes sur les documents du prospect). Installé chez le client (programme Windows, serveur au siège) ou hébergé en France ; mises à jour la nuit, sauvegardes, suivi à distance par l'éditeur.
- Budget and constraints: non précisés par le fondateur (question ouverte). Le logiciel existe déjà et fonctionne de bout en bout ; une version complète aux couleurs d'ARGE a été construite (ses documents, son catalogue de 131 articles, ses 4 agences). ARGE ne peut pas être cité comme client ou référence sans son accord écrit. Le fondateur, Justin Simonetti, vend seul pour l'instant.

## Summary

**Verdict : Pas encore (« Not yet »).** Les chiffres tiennent, mais pas assez d'acheteurs disent oui. **Seuls 2 installateurs simulés sur 20 achètent avec l'offre actuelle (10 %)**, pour un seuil fixé à 25 %. Avec l'ancien pitch, aucun sur 20 n'achetait. Et les deux oui portent sur l'essai gratuit, pas encore sur l'abonnement.

**Ce qui doit changer :** la preuve, plus que l'offre.
- Le premier frein est la confiance (7 refus sur 20) : « une seule personne, aucun confrère à appeler ».
- Ce qui le lèvera : **ARGE en usage réel, avec son accord écrit pour être cité**, et un **support de secours** nommé dans le contrat.
- Ensuite, on remplace le panel simulé par de **vrais installateurs**. C'est le test 1 de [launch.md](launch.md) : 20 appels en novembre, réussi s'il donne au moins 6 démonstrations et 2 oui à l'essai.
- S'il échoue, on revient à `/founder-offer`.

**Ce que c'est.** Itinéos Sécurité est un logiciel de bureau et une appli terrain hors réseau, pour les installateurs d'alarme et de vidéosurveillance de 3 à 50 techniciens. Il reprend leurs propres fiches, consignes de télésurveillance et bons de sortie, et produit les factures Factur-X. C'est un abonnement par technicien : de 25 à 49 € HT par mois, 35 € en moyenne, sans engagement.

**Les trois chiffres du verdict** (estimations, mois 1 = novembre 2026) :
- **Ce qui reste par technicien** : 25,22 € sur 35 € (72 %) ;
- **Le seuil de rentabilité** : 17 techniciens payés par mois ;
- **L'année 1** : bénéfice d'exploitation de 2 483 € sur 10 290 € de chiffre d'affaires. Après les dépenses de départ, il reste −97 €.

Pour te verser 2 500 € net, il faut **116 techniciens payés**, vers **septembre 2028** au rythme prévu.

**Ce sur quoi le conseil et le panel sont d'accord.**
- Le produit colle au métier : le relevé des concurrents montre que personne n'offre à la fois les documents du métier, une appli hors réseau au centre du produit et un prix public.
- Le frein n° 1 est l'absence de preuve chez un vrai client.
- La mise en route dépend trop du fondateur.

**Là où ils divergent.** Le conseil imaginait une formule clé en main peut-être plus chère. Les acheteurs, eux, tirent le prix vers le bas : il commence à paraître cher vers 35 €.

**Le risque principal.** Trop peu de prospects. Avec deux fois moins de clients, l'année 1 finit en perte de 1 225 €. On compte les appels et les démonstrations chaque lundi, avec des seuils d'alerte ([launch.md](launch.md), § 4).

**Ce qu'il faut pour démarrer.**
- **4 030 € de trésorerie**, alors que tu disposes de moins de 2 000 €. L'écart est comblé par **un an d'avance payé par ARGE** (environ 3 600 €).
- L'import de fichiers et l'export complet, construits avant le 11 janvier 2027.

**À faire cette semaine.**
- Copier la clé de signature Android hors du PC.
- Dresser la liste des 60 installateurs à appeler.
- Préparer la négociation ARGE : prix réduit **contre** un an payé d'avance, l'accord écrit pour être cité et des présentations à des confrères.

*Le panel est fait d'acheteurs simulés, et les chiffres sont des projections. Seuls de vrais clients et de vrais devis les confirment. Ce n'est pas un conseil financier, juridique ou fiscal.*

## What the board said

**Vote : 3 « financer sous conditions » (FUND IF), 0 « financer », 0 « refuser ». Note moyenne : 5,3 / 10** (Offre 5, Monopole 5, Produit 6).

Mémos complets : [offers.md](board/offers.md), [monopoly.md](board/monopoly.md), [product.md](board/product.md).

### Les risques soulevés par plusieurs membres (en premier)

1. **Aucune preuve client** (les trois). Aucun client payant, et ARGE ne peut pas être cité sans son accord écrit. Les dirigeants du secteur changent rarement de logiciel ; sans référence du métier, la confiance reste basse et la distribution n'est pas démontrée.
2. **Un produit et une offre généralistes sous une étiquette sectorielle** (les trois). La grille 29/45/65 € est reprise telle quelle ; le produit garde 16 langues, multi-sociétés, six éditions et deux modes d'installation. Rien dans le prix, le nom ou les écrans ne dit encore « fait pour l'installateur de sécurité ».
3. **Taille du marché, équipement actuel et coût d'acquisition inconnus** (Offre, Monopole). Combien d'installateurs de 3 à 50 techniciens en France, et combien ont déjà un logiciel ? Un fondateur seul qui prospecte par e-mails et appels peut ne pas atteindre assez d'acheteurs.
4. **Une mise en route qui dépend du fondateur** (Produit, et Monopole sur la distribution). ARGE a été préparé à la main ; si chaque client exige la même préparation, la mise en service à 300 € et l'essai de 30 jours ne tiennent pas, et la cadence non plus.

### Les risques propres à un seul membre

- **Pas de barrière à la copie** (Monopole). Les documents métier se reproduisent en quelques semaines par un éditeur concurrent. Il faut une piste de barrière durable : intégration avec les télésurveilleurs, historique du parc installé, partenariat de distribution.
- **La jointure avec le télésurveilleur** (Produit). Ce que deviennent les consignes et bons de sortie après signature n'est pas décrit : c'est là que l'expérience peut casser.

### Où les membres ne sont pas d'accord

- **Le levier principal.** Le prisme Offre veut d'abord une offre et un prix construits pour le secteur (et pense que le prix pourrait monter avec une formule « clé en main sécurité ») ; le prisme Produit veut d'abord épurer le produit lui-même ; le prisme Monopole veut d'abord la carte concurrentielle et une barrière.
- **L'installation chez le client.** Le prisme Monopole y voit un atout pour des entreprises de sécurité attachées à leurs données ; le prisme Produit y voit une complexité de plus à trancher (garder un seul mode ?).

### Les conditions, fusionnées (liste à cocher pour la suite)

- [ ] **Marché dimensionné** : nombre d'installateurs cibles, part déjà équipée, outils en place et leurs prix, plaintes des clients. → `/founder-competitors`
- [ ] **Un angle où Itinéos est nettement supérieur**, ou la preuve qu'aucun acteur ne domine la niche. → `/founder-competitors`
- [ ] **Le résultat que le dirigeant veut vraiment** (moins de ressaisie, contrats facturés à temps, conformité CNAPS, Factur-X…) et sa volonté de payer. → `/founder-consumer`
- [ ] **Un prix propre au secteur**, testé (y compris une formule plus chère « clé en main »). → `/founder-pricing`, `/founder-offer`
- [ ] **Une offre propre au secteur** : nom, contenu, reprise des documents et du parc incluse dans la mise en service, garantie chiffrée. → `/founder-offer`
- [ ] **Une garantie et un coût de mise en service réels**, validés par les chiffres. → `/founder-cfo`
- [ ] **Coût d'acquisition d'un client mesuré** et un objectif de part de marché crédible sur un sous-segment (une région, ou les multi-agences). → `/founder-cfo`, `/founder-marketing`
- [ ] **Une édition sécurité réellement épurée** : écrans, vocabulaire, modèles et offres du métier ; le reste caché. → décision produit
- [ ] **Une mise en route reproductible sans le fondateur** : import des clients, sites et matériels, modèles sécurité prêts à l'emploi, testés chez un installateur autre qu'ARGE. → `/founder-ops`
- [ ] **La jointure télésurveilleur traitée** (ou déclarée hors périmètre), validée auprès d'installateurs réels. → `/founder-ops`
- [ ] **Une piste de barrière** engagée : télésurveilleurs partenaires, grossistes, fédérations, historique du parc. → `/founder-marketing`, `/founder-ops`
- [ ] **Une preuve réelle** : ARGE (ou un autre installateur) client payant, retour écrit des techniciens, résultat mesuré, accord écrit pour être cité. → `/founder-launch`

### La version la plus forte que le conseil voit

Pas « Itinéos pour tous les métiers, avec une version sécurité », mais **le logiciel de terrain de l'installateur de sécurité électronique**, et rien d'autre : un produit épuré dont la fiche s'ouvre déjà remplie avec la centrale, le numéro d'abonné et l'historique du site, qui produit les consignes et bons de sortie que le télésurveilleur attend, et qui facture les contrats de maintenance à temps (Factur-X compris). Il se vendrait comme une formule clé en main, peut-être plus chère que la grille actuelle, mise en service à partir des documents et du parc du client, avec une garantie de démarrage. Il commencerait par un sous-segment que le fondateur peut dominer seul (par exemple les multi-agences d'une région) et s'appuierait sur ARGE comme première référence écrite. Cela diffère du projet présenté sur deux points : le prix et l'offre ne seraient plus ceux du produit généraliste, et la priorité ne serait pas d'élargir la prospection mais d'obtenir d'abord une preuve chez un vrai client.

## The competition

Relevé du 23 octobre 2026, sources publiques uniquement (pages des éditeurs, comparateurs). Données brutes : [competitors.csv](competitors.csv).

**Limite importante :** Capterra, GetApp et Google Play ont refusé la lecture (erreurs 403/404). Je n'ai donc **pas pu lire d'avis négatifs** de clients. La partie « plaintes » ci-dessous est **mince** et doit être complétée à la main (voir la fin).

### 1. Le tableau, du plus direct au moins direct

| Concurrent | Type | Ce qu'il vend | Prix comparable | Sa phrase d'accroche |
|---|---|---|---|---|
| [Le Terrain](https://leterrain.co/securite-electronique) | Direct | Interventions, rapports de maintenance, parc par site, contrats, devis/factures par IA, dictée par WhatsApp. **En accès anticipé.** | Non publié (démo 15 min) | « Arrêtez la paperasse de maintenance. Gagnez 15 heures par semaine grâce à l'IA. » |
| [Sustencio](https://www.sustencio.com/systemes-securite) | Direct | Contrats de maintenance incendie, alarme et vidéo, planning, rapports signés, espace client | Forfait : 30 € (solo), 100 € (TPE/PME < 100 utilisateurs), 500 € (entreprise), période non précisée | « Simplifiez vos interventions d'entretien de systèmes de sécurité. » |
| [CMII – W'IPSOS](https://cmii.fr/logiciel-gestion/securite-incendie/alarme-intrusion/) | Direct | ERP complet : contrats, facturation récurrente, **prélèvement des abonnements**, visites préventives, parc et n° de série, appli IP'Connect, stock | Non publié | « Spécialiste de votre métier depuis 1979 » ; références affichées : Scutum, Securitas, Def Sûreté… |
| [Capasoft – Kéops](https://www.capasoft.fr/e-r-p-securite/) | Direct | ERP cloud sécurité électronique : facturation périodique et prélèvement SEPA, maintenance préventive, chantiers, devis, stock par dépôt et véhicule | Non publié | « Logiciels pour l'industrie de la sécurité électronique » ; « plus de 25 ans » |
| [Praxedo](https://www.praxedo.com/our-industries/remote-monitoring-and-electronic-security/) | Direct (généraliste avec page sécurité) | Gestion d'interventions, appli mobile hors ligne, rapports, portail client, connecteurs ERP ; clients cités : **Nexecur**, Intelgest | [35 / 59 / 89 / 129 € par utilisateur/mois, minimum 5](https://www.praxedo.fr/tarifs/) | « Security solution providers: give your customers top-notch service quality. » |
| [Infocob](https://www.infocob.com/logiciel-prevention-securite-incendie/) | Indirect | CRM incendie/télésurveillance : parc par site, n° de série, historique, branché sur EBP/Sage/Cegid | Non publié | « Maintenance et suivi réglementaire » |
| [Organilog](https://www.blogdumoderateur.com/tools/organilog/) | Indirect (généraliste) | Planning et appli d'intervention pour TPE/PME | 19 / 35 / 59 € HT par utilisateur/mois (annuel) | — |
| [ArtisanSmart](https://artisansmart.fr/metiers/installateur-securite.html) | Indirect | Devis et factures pour installateurs de sécurité (NF A2P, RGPD vidéo, Factur-X), **sans** interventions ni appli terrain | 29 € HT/mois, sans engagement | « Logiciel de devis et factures pour installateurs de sécurité » |
| [Kizeo Forms](https://www.appvizer.fr/operations/gestion-des-interventions/kizeo-forms) | Substitut | Formulaires mobiles (bons d'intervention, photos, signature) | 15 €/utilisateur/mois (annuel), 22 € (mensuel) | — |
| [Odoo](https://www.odoo.com/zh_TW/customers/groupe-rvj-paca-11140374) | Substitut | ERP généraliste paramétré par un intégrateur ; un installateur alarme/vidéo (Groupe RVJ PACA) l'utilise pour interventions et contrats de télésurveillance | Non relevé | — |
| Papier + tableur + EBP/Sage | Substitut | Ce que les e-mails d'Itinéos disent remplacer : fiches papier ressaisies, facturation à part | Coût caché (ressaisie, retard de facturation) | — |

### 2. Fourchette de prix (par utilisateur et par mois, offres publiées)

- **Plus bas : 15 €** (Kizeo Forms, simples formulaires).
- **Médiane : 35 €** (Praxedo Basic, Organilog Business).
- **Plus haut : 129 €** (Praxedo Automated).
- Hors grille par utilisateur : ArtisanSmart 29 €/mois au total (devis/factures seulement) ; Sustencio au forfait (100 € pour une PME).
- **Les quatre spécialistes sécurité les plus complets (Le Terrain, CMII, Capasoft, Infocob) ne publient aucun prix.**
- Itinéos : 29 / 45 / 65 €. Essentiel est sous la médiane ; Pro (45 €) et Entreprise (65 €) restent nettement sous Praxedo à fonctions comparables.

### 3. Carte de positionnement (en texte)

Axes qui comptent pour l'installateur : **spécialisation sécurité** (horizontal) et **terrain/mobile d'abord vs. gestion/ERP d'abord** (vertical).

```
                       TERRAIN / APPLI D'ABORD
                                 |
      Kizeo Forms   Organilog    |   Le Terrain (accès anticipé)
                Praxedo          |        [ITINÉOS visé ici]
                                 |   Sustencio
 GÉNÉRALISTE --------------------+-------------------- SPÉCIALISTE SÉCURITÉ
                                 |
      Odoo                       |   Infocob
      EBP / Sage + papier        |   CMII W'IPSOS   Capasoft Kéops
                ArtisanSmart (devis)
                                 |
                        GESTION / ERP D'ABORD
```

- En haut à gauche : de bons outils de terrain, mais qui ne parlent pas le métier (pas de consignes de télésurveillance, de bons de sortie ni de n° d'abonné).
- En bas à droite : des ERP anciens et spécialisés, forts sur la facturation récurrente et le prélèvement des abonnements, avec une appli mobile secondaire et des prix non publiés.
- En haut à droite : **seuls Le Terrain (pas encore lancé) et Sustencio (léger, sans appli décrite)**.

### 4. Les plaintes des clients

**Mince : moins de trois avis lus pour chaque thème.** Les plateformes d'avis ont bloqué la lecture automatique.

- **Ergonomie et apprentissage (Organilog), mince.** Un comparatif relève une interface « parfois peu intuitive » avec une courbe d'apprentissage ([La Fabrique du Net](https://www.lafabriquedunet.fr/logiciel/organilog), résumé, pas un avis direct).
- **Fonctions contre prix (Synchroteam/Praxedo), mince.** Un utilisateur dit avoir choisi Synchroteam parce que le prix était plus intéressant, même avec moins de fonctions ([Capterra, résumé de recherche](https://www.capterra.com/p/129634/Synchroteam/reviews/?page=2)).
- **Rien de lisible** pour Le Terrain, Sustencio, CMII, Capasoft et Infocob.

Ce qu'il faut faire à la main : sur Capterra.fr et Google Play, lire les avis 1 à 3 étoiles de Praxedo, Organilog et Kizeo (mots-clés « synchro », « hors ligne », « prix », « support »). Mieux encore : poser la question directement à ARGE et à 5 installateurs.

### 5. Le trou (le « gap »)

D'après ce relevé, **personne ne propose publiquement les trois à la fois** :

1. **Les documents propres au métier**, repris tels quels : consignes de télésurveillance, bons de sortie télésurveillance et vidéoprotection, mentions CNAPS en pied de page. Aucune page lue ne mentionne les consignes ni les bons de sortie, et seul l'ERP de CMII parle du parc par abonnement.
2. **Une appli terrain moderne qui marche sans réseau**, au centre du produit. Les ERP spécialisés (CMII, Capasoft) la traitent en module annexe ; seul Praxedo, généraliste, met en avant le hors ligne.
3. **Un prix public, par technicien, avec bureau illimité.** Les spécialistes ne publient aucun prix ; Praxedo exige 5 utilisateurs minimum et facture chaque utilisateur.

Le trou existe, mais il est **étroit et temporaire** : Le Terrain vise exactement la même case, avec l'IA comme argument, et lance en ce moment.

**Ce qu'Itinéos n'a pas et que les spécialistes ont :** le **prélèvement automatique des abonnements de télésurveillance** (CMII, Capasoft). Pour un installateur, ces abonnements sont souvent un revenu récurrent important ; c'est à vérifier avec ARGE.

### 6. La menace : qui peut copier le plus vite

- **Le Terrain** : même cible, même promesse, en lancement. S'il ajoute consignes et bons de sortie, il occupe la case. C'est le concurrent à surveiller en premier.
- **Praxedo** : déjà chez Nexecur, appli hors ligne, connecteurs ERP, page sécurité dédiée. Il lui suffirait de modèles de documents sécurité pour couvrir le terrain ; il est en revanche plus cher et ne vend pas en dessous de 5 utilisateurs.
- **CMII et Capasoft** : ils ont la clientèle et la facturation récurrente. Une appli terrain plus moderne les rendrait très difficiles à déloger.

Prochaines étapes : `/founder-consumer` utilisera ces points pour écrire les objections des acheteurs, et `/founder-pricing` utilisera la fourchette de prix (15 à 129 €, médiane 35 €).

## The buyer panel

**0 buy · 20 pass** (0% buy) out of 20 simulated buyers. Seed 916646, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

### By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Dirigeant ou responsable d'exploitation d'une PME de sécurité (9 à 25 techniciens, une ou deux agences, une assistante au planning) | 7 | 0%  (thin) |
| Dirigeant d'une petite entreprise d'alarme (3 à 8 techniciens, une seule agence, le dirigeant fait encore des interventions) | 9 | 0% |
| Directeur des opérations d'un groupe multi-agences type ARGE (26 à 50 techniciens, 3 à 5 agences, télésurveillance via un partenaire) | 4 | 0%  (thin) |

### By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Méfiant envers les petits éditeurs | 3 | 0%  (thin) |
| Cherche à se structurer pour grandir | 2 | 0%  (thin) |
| Regarde d'abord le prix | 3 | 0%  (thin) |
| Déjà équipé d'un ERP sécurité | 4 | 0%  (thin) |
| Encore au papier | 5 | 0%  (thin) |
| Déjà sur un outil de terrain généraliste | 3 | 0%  (thin) |

### By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| $53,000 to $74,000 | 7 | 0%  (thin) |
| under $53,000 | 6 | 0%  (thin) |
| $74,000 and up | 7 | 0%  (thin) |

### Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| habit | 9 | "Ça me parle, surtout les devis et factures qui me bouffent mes samedis, mais là je viens de m'agrandir et je n'ai pas la tête à changer de logiciel en plus. Je demanderais peut-être l'essai, mais signer 12 mois ce mois-ci, non." (P002) · "J'ai tout mon historique et mes abonnements de télésurveillance dans mon ERP depuis des années, avec le prélèvement automatique. Votre offre parle de fiches et de factures, mais rien sur la facturation récurrente des abonnements, donc je devrais garder mon ERP en plus et payer deux outils." (P007) |
| trust | 8 | "Sur le papier ça colle à notre métier, les numéros d'abonné et les bons de sortie télésurveillance, ce n'est pas du généraliste. Mais « vendu et suivi par son créateur, en direct », pour moi ça veut dire une seule personne : j'ai déjà vu un éditeur disparaître avec nos fiches dedans, je ne remets pas mes contrats de maintenance et mes abonnements sur un logiciel tenu par un seul homme." (P001) · "Ça a l'air pensé pour mon métier, mais « vendu et suivi par son créateur, en direct », pour moi ça veut dire une seule personne. J'ai déjà vu un éditeur disparaître avec mes données dedans, je ne mets pas mes contrats de maintenance et mes abonnés télésurveillance sur un seul homme." (P004) |
| price | 2 | "Avec 40 techniciens et 4 agences, je suis obligée de prendre la formule à 65 € pour le multi-agences : ça fait plus de 2 500 € HT par mois, plus de 30 000 € par an, engagés 12 mois, alors que nos marges sur la pose sont serrées. L'appli hors réseau pour les caves m'intéresse vraiment, mais pas à ce prix-là, et pas sans garantie que ça tienne." (P003) · "Avec 4 ou 5 techniciens à 45 € plus 300 € de mise en service et 12 mois d'engagement, ça fait plus de 2 500 € par an pour une boîte où je suis encore sur les chantiers ; mes fiches papier et mon tableur font le travail, je ne vois pas ce que je gagne en marge." (P005) |
| need | 1 | "Mon vrai problème c'est la facture électronique et mes abonnements de télésurveillance, et je ne vois écrit nulle part que ça facture et prélève mes abonnements tous les mois. Pour des fiches et un planning, mon papier carbone marche encore, alors je ne vais pas tout chambouler et engager 12 mois pour ça." (P011) |

### Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |

### What would flip a no

- Deux ou trois installateurs du métier que je peux appeler, et un engagement écrit : support assuré par quelqu'un d'autre que le fondateur et récupération de toutes mes données dans un format standard si l'éditeur s'arrête.
- Que le créateur vienne reprendre lui-même mes clients et mes fiches pendant l'essai, et que je puisse arrêter sans frais au bout des 30 jours si mes techniciens n'en veulent pas.
- Un tarif dégressif au-delà de 20 techniciens avec le multi-agences sans passer à la formule la plus chère, plus un essai sur une agence pilote dans de vraies caves sans réseau et une garantie de réversibilité des données si l'éditeur disparaît.
- Deux ou trois installateurs d'alarme de ma taille que je peux appeler et qui l'utilisent depuis plus d'un an, plus un engagement écrit : hébergé en France avec sauvegardes incluses, export complet de mes données à tout moment et un support de secours si le fondateur n'est pas là.
- Une offre hébergée sans engagement de 12 mois, avec la mise en service offerte, et un installateur de ma taille qui me confirme que ça lui a fait gagner du temps sur la paperasse.
- Un hébergement en France avec sauvegardes et support garantis par écrit (délai d'intervention, réversibilité des données), et un tarif dégressif ou un premier engagement court sur une seule agence pilote.
- Une preuve que les abonnements récurrents et le prélèvement SEPA sont gérés, avec la reprise complète de mon historique et de mes contrats depuis mon ERP actuel.
- Deux ou trois installateurs d'alarme que je peux appeler et qui l'utilisent depuis au moins un an, plus un engagement écrit que je récupère toutes mes données dans un format lisible si l'éditeur s'arrête.
- Qu'un confrère de ma taille me montre que ses vieux techniciens s'en servent vraiment, et que la mise en service reprenne tout pour moi sans que j'y passe mes soirées.
- Deux ou trois installateurs de ma taille, multi-agences, que je peux appeler et qui l'utilisent depuis au moins six mois, plus un essai sur une seule agence sans engagement 12 mois pour le reste du groupe.
- Qu'on me montre, avec mon comptable, la facturation récurrente et le prélèvement automatique de mes abonnements de télésurveillance en Factur-X, avec reprise de mes contrats depuis EBP, sans engagement de 12 mois au départ.
- Qu'il vienne lui-même reprendre mes données et former mes gars un jour où je ne suis pas sur le terrain, avec un collègue installateur du coin qui l'utilise déjà et me dit que ses samedis de facturation ont disparu.

20 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.

## Pricing

Sources : [pricing-curve.md](pricing-curve.md) (20 acheteurs simulés), [competitors.md](competitors.md) (prix publics relevés le 23/10/2026). Tous les prix sont en € HT par technicien de terrain et par mois.

### Ce que disent les trois sources

**Les acheteurs (simulés, à confirmer).** Plage acceptable : **15 € à 55 €**. Point d'équilibre « bonne affaire = cher » (IPP) : **30 €**. Médianes : bonne affaire 25 €, devient cher 40 €, trop cher 60 €.
→ Ta formule Pro à 45 € dépasse déjà le seuil où la plupart disent « ça devient cher ». La formule Entreprise à 65 € est au-delà de la limite (55 €).

**Les concurrents.** Médiane des offres publiées : **35 €** (Praxedo Basic, Organilog Business). Praxedo va de 35 à 129 € avec au moins 5 utilisateurs. Les ERP spécialisés (CMII, Capasoft) ne publient pas leurs prix.

**Ce que l'entreprise doit gagner.** **Inconnu pour l'instant** : il n'y a pas encore de `founder/numbers.json` (coût d'hébergement par client, temps de support, revenu dont tu as besoin). Je n'ai donc **pas** calculé de marge. Le directeur financier (`/founder-cfo`) doit vérifier la grille ci-dessous avant tout envoi.

**Le panel montre aussi que le montant n'est pas le premier frein.** Seuls 2 acheteurs sur 20 refusent pour le prix. En revanche, **l'engagement de 12 mois apparaît dans 12 réponses sur 20**, et le passage obligé par la formule la plus chère pour avoir le multi-agences gêne les 4 acheteurs multi-agences.

### 1. Le prix recommandé : 39 € pour la formule principale

La formule que la plupart des installateurs doivent prendre (devis, contrats, factures) passe de 45 € à **39 €**, **sans engagement**.

- Elle reste sous le seuil « ça devient cher » (40 €) et au-dessus de la médiane des concurrents (35 €), ce qui est justifié par les documents propres au métier.
- Un installateur de 10 techniciens paie 390 €/mois, contre 450 € aujourd'hui.
- Cette baisse n'a de sens que si **la facturation des abonnements de télésurveillance** fait partie de la formule (voir plus bas). Sans cela, l'acheteur qui a déjà un ERP ne gagne rien, quel que soit le prix.

### 2. La grille proposée

| Formule | Prix | Pour qui | Contenu |
|---|---:|---|---|
| **Terrain** | **25 €** | Ceux qui gardent leur ERP sécurité ou EBP | Planning par agence, appli hors réseau, fiches d'intervention, consignes de télésurveillance, bons de sortie, parc et n° d'abonné, export vers leur ERP |
| **Sécurité** *(recommandée)* | **39 €** | La plupart des installateurs | Tout Terrain, plus devis, contrats de maintenance, **facturation des abonnements**, factures Factur-X, espace client, **stock par camionnette** |
| **Groupe** | **49 €** | Multi-sociétés, plus de 25 techniciens | Tout Sécurité, plus habilitations, parc véhicules, plusieurs sociétés, **support prioritaire avec délai écrit** |

Ce qui change, et pourquoi :
- **Le multi-agences est inclus dans toutes les formules.** Un groupe de 4 agences n'est plus obligé de prendre la formule la plus chère (demandé par P003, P006, P010, P019).
- **Le stock par camionnette passe dans la formule Sécurité** (demandé par P008).
- **La formule Terrain à 25 € vient compléter l'ERP en place au lieu de le remplacer.** C'est la porte d'entrée pour les 4 acheteurs déjà équipés d'un ERP sécurité, qui refusaient d'avoir deux logiciels à facturer.
- **Tarif dégressif** : −15 % sur chaque technicien au-delà du 20e. Pour 40 techniciens en formule Sécurité : 20 × 39 + 20 × 33,15 = **1 443 €/mois**, contre 2 600 € aujourd'hui en formule Entreprise.
- **Sans engagement par défaut**, et −10 % avec un engagement de 12 mois. Le prix affiché est celui qu'on paie vraiment : pas de faux « prix barré ».
- **Mise en service** : elle reste payante, mais elle est **déduite de la première année** si le client reste après l'essai. Elle est **offerte** pour les clients fondateurs (voir 3).

### 3. L'offre de lancement : « 5 installateurs fondateurs »

- **Réservée à 5 entreprises, jusqu'au 31 mars 2027** (limite réelle, à respecter).
- Essai de **60 jours sur une seule agence**, avec **reprise des données faite par toi**, sur place si possible.
- **Mise en service offerte**, et **prix fondateur garanti 24 mois** (le prix de la grille, bloqué : pas une remise).
- En échange : un **retour écrit** des techniciens et du dirigeant, et l'**accord écrit d'être cité** si le client reste.

Cette offre répond aux trois premières demandes du panel (références, reprise faite pour eux, pas d'engagement) sans habituer le marché à attendre des soldes. ARGE devrait être le premier fondateur.

### 4. À tester avec de vrais acheteurs

- **35 € contre 39 €** pour la formule Sécurité : deux versions de la fiche tarifs, envoyées en alternance dans la séquence d'e-mails (une version sur deux). On compare le nombre de démonstrations obtenues et d'essais signés. Il faut environ 20 démonstrations par version avant de conclure.
- **La formule Terrain à 25 € face aux clients équipés d'un ERP** : la proposer à 5 installateurs qui ont CMII, Capasoft ou équivalent, et compter combien acceptent un essai.
- Avant tout : demander à ARGE combien il paie aujourd'hui ses outils, et ce qu'il trouverait juste.

### 5. Les objections de prix du panel, mot pour mot (pour le marketing)

Ce sont des acheteurs simulés, **pas des témoignages**.

1. Sur l'engagement : « si mes techniciens n'adoptent pas l'appli je suis coincé un an avec un engagement que je paie quand même. » (P002)
2. Sur le multi-agences : « je suis obligée de prendre la formule à 65 € pour le multi-agences : ça fait plus de 2 500 € HT par mois » (P003)
3. Sur le doublon avec l'ERP : « je garde mon ERP et je paierais deux logiciels, plus 300 € et des samedis à tout reprendre. » (P020)

### Préalable produit (à ne pas oublier)

La formule Sécurité promet la **facturation des abonnements**. Aujourd'hui, Itinéos facture un contrat à la main, un par un, et « Prélèvement » n'est qu'un mode de paiement. Il manque trois choses : la facturation en lot chaque mois, les mandats SEPA et le fichier de prélèvement à envoyer à la banque. **Tant que ce n'est pas construit, on ne peut pas l'écrire dans l'offre.** Dans ce cas, on la vend comme « bientôt disponible », à une date précise que tu peux tenir.

## The offer

Méthode : le prisme Offre (équation de valeur), appliqué aux objections du [panel](panel/results.md), aux conditions du [conseil](board.md) et aux [prix](pricing.md). Ancien pitch : [pitch-v1.md](pitch-v1.md). Nouveau pitch : [pitch.md](pitch.md).

**Limite :** il n'existe pas encore de `founder/numbers.json`. Les coûts ci-dessous sont des **estimations en temps** (le tien) et des points à chiffrer, pas des montants vérifiés. `/founder-cfo` doit les valider avant toute signature.

### 1. La liste des problèmes (en mots d'acheteur)

**Avant d'acheter**
1. « Une seule personne : qui me dépanne si le créateur est malade ou arrête ? » (8 acheteurs sur 20)
2. « Qui d'autre dans la sécurité l'utilise déjà ? »
3. « Mes données coincées chez un éditeur qui disparaît. »
4. « 12 mois d'engagement pour un logiciel que je n'ai pas vu tourner chez moi. » (12 sur 20)
5. « Pour le multi-agences, je dois prendre la formule la plus chère. »
6. « 45 € par technicien, ça fait plus de 500 € par mois. »
7. « Ça ne facture pas et ne prélève pas mes abonnements de télésurveillance. »
8. « J'ai déjà un ERP : je paierais deux logiciels. »
9. « Un généraliste repeint aux couleurs de la sécurité. »
10. « Le serveur chez moi, c'est moi qui gère pannes et sauvegardes. »

**Pendant la mise en route**
11. « Reprendre clients, centrales et numéros d'abonné, c'est des semaines. »
12. « Je n'ai pas le temps, je suis sur les chantiers. »
13. « Mes techniciens de plus de 50 ans ne voudront pas d'une appli. »
14. « Je vais encore ressaisir les consignes pour mon télésurveilleur. »
15. « Ça remplace ou ça se branche sur EBP ? »

**Après**
16. « Si mes techniciens n'adoptent pas, je suis coincé. »
17. « Et la facture électronique obligatoire, c'est réglé ? »
18. « Le stock par camionnette n'est que dans la formule la plus chère. »
19. « Quand on sera nombreux à appeler en même temps, il suivra ? »

### 2. Solutions, notées et triées

Valeur pour l'acheteur et coût pour toi, de 1 (faible) à 5 (fort).

| # | Solution | Valeur | Coût | Garder ? |
|---|---|:-:|:-:|---|
| 1, 19 | Délai de réponse du support écrit au contrat (4 h ouvrées) | 5 | 2 | Oui |
| 1, 3 | Code source déposé chez un tiers de confiance, remis aux clients si l'éditeur cesse son activité | 5 | 2 (coût annuel à chiffrer) | Oui |
| 3 | Export complet des données en fichiers standards sous 5 jours ouvrés | 5 | 1 (fait à la main aujourd'hui : pas d'écran d'export) | Oui |
| 2 | Programme limité à 5 « fondateurs » qui deviennent les références | 5 | 1 | Oui |
| 4, 16 | Sans engagement + essai de 60 jours sur une agence, arrêt sans frais | 5 | 2 (ton temps pendant l'essai) | Oui |
| 5, 18 | Multi-agences dans toutes les formules ; stock dans la formule Sécurité | 4 | 1 | Oui |
| 6 | Sécurité à 39 € ; −15 % au-delà du 20e technicien | 4 | 2 (revenu en moins, à faire valider par le CFO) | Oui |
| 8, 15 | Formule Terrain à 25 € qui se branche à côté de l'ERP (export) | 4 | 3 (export à construire ou à faire à la main) | Oui, à préciser |
| 11, 12 | Reprise des données faite par le créateur, sur place | 5 | 4 (1 à 3 jours par client) | **Oui, seulement pour les 5 fondateurs** |
| 13 | Formation des techniciens sur place, une demi-journée | 4 | 3 | Oui, pour les fondateurs |
| 10 | Hébergé en France, sauvegarde chaque nuit, ou installé chez le client | 4 | 2 (coût d'hébergement à chiffrer) | Oui |
| 7 | Facturation en lot et prélèvement SEPA des abonnements | 5 | 5 (à développer) | **Pas promis : affiché comme « pas encore disponible »** |
| 14 | Envoi automatique des consignes au télésurveilleur | 4 | 5 (dépend de chaque télésurveilleur) | Non pour l'instant ; à explorer avec le partenaire d'ARGE |
| 17 | Factur-X déjà en place | 4 | 1 | Oui (déjà construit) |

### 3. Le montage

- **Le cœur** (décrit par le résultat) : *vos techniciens remplissent vos propres fiches, consignes et bons de sortie sur leur téléphone, même au sous-sol, et le client signe ; au bureau, la facture est prête le soir même.*
- **Bonus 1 : la reprise faite pour vous.** Le créateur reprend clients, sites, centrales et documents. Il répond à « des semaines de reprise » et « je n'ai pas le temps ».
- **Bonus 2 : une demi-journée de formation des techniciens sur place.** Elle répond à « mes techniciens de 50 ans ».
- **Bonus 3 : le prix bloqué 24 mois.** Il répond à la peur d'une hausse une fois le client installé.
- **Les garanties (écrites dans le contrat) :**
  - sans engagement, arrêt sans frais à la fin de l'essai ;
  - export complet de toutes les données sous 5 jours ouvrés, à tout moment ;
  - réponse du support sous 4 h ouvrées ;
  - code source déposé chez un tiers de confiance.
- **Ce qui est rare, et vrai :** 5 places de fondateurs, jusqu'au 31 mars 2027. Tu ne peux pas faire la reprise sur place pour plus de 5 clients à la fois. La limite est donc réelle : il faut la respecter.
- **Le nom :** « Installateurs fondateurs ».
- **Ce qui est dit honnêtement :** le prélèvement SEPA automatique n'existe pas encore. Pour ceux qui l'ont dans leur ERP, la formule Terrain se branche à côté.

**Ce qui doit être vrai avant d'envoyer cette offre :**
- un contrat de dépôt du code source chez un tiers (par exemple l'APP, l'Agence pour la protection des programmes) ;
- une procédure d'export complet ;
- un hébergement en France chiffré ;
- l'avis d'un juriste sur les clauses (délai de support, réversibilité). Ce n'est pas un conseil juridique.

### 4. L'équation de valeur, avant et après

Note de 1 à 10 ; pour le temps et l'effort, une note haute veut dire « court » ou « faible ».

| Élément | Avant | Après | Ce qui le fait bouger |
|---|:-:|:-:|---|
| Résultat rêvé | 6 | 7 | Le cœur est décrit par le résultat (facture le soir même), plus par la liste des modules |
| Probabilité perçue d'y arriver | 2 | 5 | Garanties écrites, dépôt du code, export, programme de références. Le plafond reste bas tant qu'aucun vrai client n'est cité |
| Délai avant le résultat | 4 | 6 | Essai sur une seule agence, reprise faite pour le client |
| Effort et sacrifice | 3 | 7 | Reprise et formation sur place, sans engagement, arrêt sans frais |

Le point faible reste la **probabilité perçue**. Seul un vrai client cité (ARGE) peut la faire monter au-delà de 5.

### 5. Nouveau test sur le panel

Mêmes 20 acheteurs (graine 916646), même méthode, nouveau [pitch](pitch.md). Détail : [panel-v2/results.md](panel-v2/results.md).

| | Panel 1 (ancien pitch) | Panel 2 (offre fondateurs) |
|---|:-:|:-:|
| Acheteurs qui disent oui | 0 sur 20 (0 %) | 2 sur 20 (10 %) |
| Refus pour confiance | 8 | 7 |
| Refus par habitude | 9 | 7 |
| Refus pour le prix | 2 | 3 |
| Refus par besoin (SEPA) | 1 | 1 |
| Prix « une bonne affaire » (médiane, € HT/technicien/mois) | 25 | 20 |
| Prix « cher » (médiane) | 40 | 35 |
| Prix « trop cher » (médiane) | 60 | 50 |

**Ce qui a marché.** Les deux oui viennent d'entreprises qui grandissent (P002 vient de passer à deux agences, P010 vient d'en racheter une). Ils citent tous les deux la même chose : l'essai gratuit sur une seule agence, avec la reprise des données et la formation faites par le créateur. Les objections « 12 mois d'engagement », « multi-agences réservé à la formule la plus chère » et « reprise des données » ont disparu des refus.

**Attention : ces deux oui sont des oui à l'essai, pas à l'abonnement.** Les deux disent qu'ils paieront seulement si leurs techniciens adoptent l'outil. C'est un premier pas réel, mais ce n'est pas encore un client qui paie.

**Ce qui n'a pas bougé.**
- **La confiance** (7 refus). Les garanties écrites (export, dépôt du code, support sous 4 h) ne suffisent pas. Ce qui ferait changer d'avis est presque toujours le même : *parler à deux ou trois installateurs qui l'utilisent depuis six mois* et *savoir qui assure le support à part le fondateur*. La phrase « les premières références, ce sera vous » est honnête, mais plusieurs acheteurs l'ont lue comme « vous serez le cobaye ».
- **Le prélèvement SEPA** des abonnements de télésurveillance. Il revient dans 5 réponses. Pour les entreprises déjà sur un ERP, sans SEPA, Itinéos reste « un deuxième logiciel à payer ».
- **Le prix pour les gros.** À 35 techniciens, la formule Sécurité fait environ 1 200 € HT par mois ; un acheteur demande un forfait groupe plafonné vers 1 000 €.

**Prix.** Les prix jugés acceptables ont baissé d'environ 5 € par rapport au premier panel. C'est en partie normal : les acheteurs se calent sur les prix affichés, qui ont baissé eux aussi (Sécurité passe de 45 à 39 €). La formule Sécurité à 39 € se situe pile au seuil « cher » (35 €) et sous le « trop cher » (50 €). À vérifier avec `/founder-pricing` sur `panel-v2/answers`.

**Conclusion.** L'offre a levé les freins pratiques (engagement, reprise, essai). Le frein principal est maintenant la preuve : aucun prospect simulé ne croit un éditeur d'une seule personne sans confrère à appeler. La suite la plus utile n'est pas de retoucher l'offre, mais de :
1. faire d'ARGE une référence citable (avec leur accord écrit) : c'est le seul levier qui peut faire monter la probabilité perçue au-delà de 5 ;
2. nommer un support de secours (une personne ou une société partenaire) et l'écrire dans le contrat ;
3. décider si le prélèvement SEPA entre dans la feuille de route avant le lancement.

Ces 20 acheteurs sont simulés. Il faut confirmer ces trois points avec de vrais installateurs avant de dépenser.

## The numbers

Entrées : [numbers.json](numbers.json). Source de chaque chiffre : [cfo-sources.md](cfo-sources.md) et [ops.md](ops.md). Le tableau détaillé, plus bas, sort de l'outil de calcul : il affiche « $ », mais **ce sont des euros HT**. Beaucoup de coûts restent des **estimations** : il faut les remplacer par de vrais devis.

*Mise à jour du 23/10/2026 après [ops.md](ops.md) : taux de cotisations 2026 corrigé (25,8 %), frais GoCardless plafonnés, support de secours (150 € par mois) et plateforme agréée (10 € par mois) ajoutés. Puis après [launch.md](launch.md) : montée en charge recalée sur l'envoi de l'offre le 11 janvier 2027 (ARGE n'utilise pas encore le logiciel ; il paie à partir de février 2027).*

### La note du CFO

**La marge.** Sur 35 € payés par technicien et par mois (prix moyen, ARGE compris à prix réduit), il reste **25,22 €** une fois payés les cotisations, le prélèvement et l'hébergement, soit 72 %. Les coûts fixes sont de **411 € par mois**, dont 150 € pour le support de secours. L'activité couvre ses frais à partir de **17 techniciens payés**. Ce n'est pas la marge qui pose problème.

**La vraie question : quand peux-tu te verser 2 500 € net ?**
- Il faut environ **116 techniciens payés** chaque mois. Calcul fait avec l'outil, en ajoutant la paie aux coûts fixes : seuil de 115,4.
- Le plan prévoit **54 techniciens au mois 12** (octobre 2027). Il te resterait alors **951 €** par mois.
- Au même rythme (6 techniciens de plus par mois), tu atteins 116 techniciens vers le **mois 23, soit septembre 2028**.
- Si tu te versais 2 500 € dès le mois 1, il manquerait **30 097 €** de trésorerie sur l'année. Ne pas te payer au début n'est donc pas un choix, c'est obligatoire.

**Le chiffre qui pèse le plus : le rythme des nouveaux clients.** Avec deux fois moins de techniciens chaque mois (variante « volume × 0,5 »), le bénéfice de l'année 1 passe de 2 483 € à **une perte de 1 225 €**, et il faut 4 549 € de trésorerie. Une baisse du prix de 10 % ne retire que 1 029 €. Le plan suppose environ 50 prospects sérieux en 5 mois pour obtenir 5 essais (taux de 10 % du panel). C'est l'hypothèse à vérifier en premier : compte chaque semaine tes appels et tes démonstrations ([ops.md](ops.md), semaine type).

**La trésorerie.** Il faut **4 030 €** avant que l'activité paie ses frais : 2 580 € de dépenses de départ, plus les cinq premiers mois en perte (rien n'est encaissé avant février 2027). C'est **environ 2 000 € de plus que les 2 000 € dont tu disposes**. Les dépenses de départ ne sont pas tout à fait récupérées en fin d'année 1 (−97 €). Pour combler l'écart sans emprunter :
- **indispensable :** demander à ARGE de payer **un an d'avance** à son prix réduit (12 techniciens × 25 € × 12 mois = 3 600 €), ce qui est cohérent avec un prix réduit ;
- étaler les déplacements chez les fondateurs : 1 250 € sont prévus, mais pas tous le premier mois ;
- ne démarrer l'astreinte du support de secours qu'au premier fondateur hors ARGE. Elle doit quand même être signée avant d'envoyer l'offre.

**Trois façons d'améliorer le résultat** (techniciens nécessaires pour 2 500 € net ; aujourd'hui 116) :
1. **Vendre surtout la formule Sécurité à 39 €, plutôt qu'un prix moyen de 35 €.** Il te faut alors environ **104 techniciens**. Calcul à la main, car l'outil ne fait pas bouger les cotisations avec le prix : 39 − (39 × 25,8 % + 0,75) = 28,19 € par technicien, et 2 911 / 28,19 = 104.
2. **Faire confirmer par un comptable la catégorie de ton activité.** Au taux BIC (environ 21,4 %) au lieu du taux BNC (25,8 %), il reste 26,76 € par technicien. Il te faut alors environ **109 techniciens** (calcul à la main).
3. **Fixer le prix réduit d'ARGE en échange d'une contrepartie mesurable.** Si ARGE payait le prix normal (39 €), le prix moyen serait d'environ 37,3 € et il te faudrait environ **109 techniciens**. Le prix réduit coûte donc à peu près 7 techniciens. Il vaut la peine s'il t'apporte au moins un client.

**Le passage en SASU.** Pour 2 500 € net, une SASU coûte nettement plus cher qu'une micro-entreprise : le président est assimilé salarié, avec des charges élevées sur sa paie, et il faut un expert-comptable. Le seuil passera donc bien au-dessus de 116 techniciens. À chiffrer avec un comptable avant de changer de statut, et seulement quand le chiffre d'affaires le justifie.

**Les plafonds.** À 116 techniciens × 35 € × 12 mois, cela fait 48 720 € par an : tu restes sous le plafond de chiffre d'affaires de la micro-entreprise pour les services. En revanche, tu dépasses le seuil de **franchise de TVA** vers 90 techniciens payés. Il faudra alors facturer la TVA en plus, ce qui ne change rien pour des clients professionnels qui la récupèrent. Ces plafonds et seuils changent souvent : à vérifier.

**Le coût réel de la mise en service** (calcul dans [ops.md](ops.md), § 8) :
- chez un fondateur, sur place, elle coûte au moins **820 €** : environ 250 € de frais et 3 jours de ton temps à 190 € de chiffre d'affaires par jour ;
- les 300 € de la grille actuelle ne couvrent donc que les frais ;
- proposition hors programme fondateurs : **450 € HT à distance**, **950 € HT sur place**, déduits de la première année si le client reste.

**Les conditions du conseil liées à l'argent** ([board.md](board.md)) :
- *Garantie et mise en service à leur coût réel, validées par les chiffres* : **remplie sur le papier.** Le coût de la mise en service est calculé et un prix est proposé. Les garanties (export, support sous 4 heures, séquestre, support de secours) sont comptées dans les coûts fixes. À confirmer par de vrais devis : séquestre, assurance, astreinte.
- *Coût pour gagner un client, mesuré* : **non remplie.** Il n'existe pas encore de vraie donnée. On le mesurera pendant le lancement : temps et frais par essai signé.

*Ce n'est pas un conseil financier, fiscal ou juridique. Un comptable doit vérifier le statut, le taux de cotisations, la TVA et le passage en SASU avant que l'argent ne bouge.*

---

## Le détail du calcul (sortie de l'outil, montants en euros HT)

Every number below comes from the input file. Nothing is looked up or guessed.

### One technicien payé par mois

| line | per technicien payé par mois |
| --- | ---: |
| Price | $35.00 |
| Cotisations sociales micro-entreprise (25,8 % du chiffre : BNC 2026 25,6 % + formation 0,2 %) | -$9.03 |
| Frais de prélèvement GoCardless (1 % + 0,20 €, plafonné à 2 € par client de 8 techniciens) | -$0.25 |
| Hébergement et stockage en plus (photos, PDF) | -$0.50 |
| **Contribution** (what each technicien payé par mois leaves to pay the fixed costs) | **$25.22** (72%) |

### The margin that matters

Fixed costs: $411 a month (Serveur en France avec sauvegarde chaque nuit $20, Nom de domaine et messagerie pro $8, Assurance responsabilité civile pro (informatique) $40, Dépôt du code source chez un tiers (abonnement annuel / 12) $40, Compte développeur Apple (99 $ par an / 12) $8, Compte bancaire pro $10, Téléphone et outils $25, Déplacements de prospection et de démonstration $100, Support de secours (astreinte d'un développeur indépendant) $150, Plateforme agréée pour tes propres factures $10).

- **Break-even: 17 technicien payé par moiss a day.** Below that you lose money every month.
- **Profit margin at your plan** (110 a day): **61%** of every sale, after every cost.

### Year 1, month by month

| month | technicien payé par moiss a day | revenue | profit | cumulative (after $2,580 startup) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 0 | $0 | -$411 | -$2,991 |
| 2 | 0 | $0 | -$411 | -$3,402 |
| 3 | 0 | $0 | -$411 | -$3,813 |
| 4 | 12 | $420 | -$108 | -$3,921 |
| 5 | 12 | $420 | -$108 | -$4,030 |
| 6 | 20 | $700 | $93 | -$3,936 |
| 7 | 28 | $980 | $295 | -$3,641 |
| 8 | 36 | $1,260 | $497 | -$3,144 |
| 9 | 42 | $1,470 | $648 | -$2,496 |
| 10 | 42 | $1,470 | $648 | -$1,848 |
| 11 | 48 | $1,680 | $800 | -$1,048 |
| 12 | 54 | $1,890 | $951 | -$97 |

- **Year 1 operating profit: $2,483** on $10,290 of revenue.
- After the $2,580 startup spend: -$97.
- Startup money earned back: not within year 1.
- Cash you need before it pays for itself: **$4,030**.

### What if

| scenario | margin at plan | break-even a day | year 1 profit |
| --- | ---: | ---: | ---: |
| Base plan | 61% | 17 | $2,483 |
| Price -10% | 57% | 19 | $1,454 |
| Volume -20% | 59% | 17 | $1,000 |
| Unit costs +15% | 57% | 18 | $2,051 |

### Red flags

- The startup spend is not earned back within year 1.

## Marketing

Sources : [panel-v2/results.md](panel-v2/results.md) (l'offre actuelle) et [panel/results.md](panel/results.md) (l'ancien pitch), [competitors.md](competitors.md), [offer.md](offer.md), [pricing.md](pricing.md), [numbers.json](numbers.json), [launch.md](launch.md) (envoi le **lundi 11 janvier 2027**).

**Règle de base.** Les phrases du panel viennent d'acheteurs **simulés** : elles servent à comprendre, jamais de témoignages dans un e-mail ou une publication. Pas de faux avis, pas de « x heures gagnées » tant que ce n'est pas mesuré chez un vrai client, et **ARGE n'est nommé nulle part sans son accord écrit**.

### 1. Le premier public

Dans le panel de l'offre actuelle, **les deux seuls oui viennent d'entreprises qui grandissent** :
- l'une vient de passer à deux agences ;
- l'autre vient de racheter une agence.

Leur comportement d'achat : « cherche à se structurer pour grandir ». C'est **2 acheteurs sur 2** dans ce groupe, et 0 sur 18 ailleurs. L'échantillon est très petit : c'est une piste, pas une preuve. Les deux citent la même chose : *l'essai sur une seule agence, avec la reprise des données et la formation faites par le créateur*.

**Le premier public est donc : les installateurs de 5 à 40 techniciens qui ouvrent, rachètent ou regroupent une agence.** On les repère par les annonces d'ouverture d'agence, les offres d'emploi de techniciens dans une nouvelle ville, les rachats publiés et leurs propres publications LinkedIn.

Ce que le marketing doit d'abord lever (refus du panel actuel) :
- **la confiance** (7 refus) : « une seule personne », « aucune référence du métier » ;
- **l'habitude** (7 refus) : « mon ERP fait déjà le prélèvement », « le papier marche » ;
- **le prix** (3 refus), surtout pour les grandes équipes.

### 2. Le positionnement

**A (recommandé) : l'installateur qui grandit**
> Pour les installateurs d'alarme et de vidéosurveillance qui ouvrent une nouvelle agence et dont chaque agence a encore ses papiers, Itinéos Sécurité est le logiciel de terrain qui reprend **leurs propres** fiches, consignes de télésurveillance et bons de sortie, marche au sous-sol sans réseau et réunit toutes les agences dans un seul planning. Son prix est public, par technicien et sans engagement. Les ERP spécialisés, eux, ne publient pas leurs prix et traitent l'appli terrain comme un module annexe.

*Ce qui le soutient :* les 2 oui du panel ; le multi-agences était le premier frein des groupes au premier panel (P003, P006, P010, P019) ; le « trou » relevé chez les concurrents (documents du métier + appli hors réseau + prix public).

**B : celui qui a déjà un ERP**
> Pour les installateurs qui gardent leur ERP pour les abonnements, Itinéos Sécurité Terrain est l'appli du technicien qui se branche à côté, à 25 €, au lieu de tout remplacer.

*Pourquoi pas en premier :* 0 sur 4 chez les acheteurs déjà équipés d'un ERP. Ils refusent toujours, faute de prélèvement SEPA et par peur d'avoir « deux outils ».

**C : celui qui est encore au papier**
> Pour les installateurs encore au papier carbone, Itinéos Sécurité remplace la ressaisie du vendredi par une fiche signée sur place.

*Pourquoi pas en premier :* 0 sur 5 chez les acheteurs au papier. L'habitude l'emporte (« je mets ça de côté pour plus tard »).

### 3. Les canaux

**On en garde trois :**

| Canal | Pourquoi il convient à cet acheteur | Coût | Comment on sait que ça marche |
|---|---|---|---|
| **1. Appel + e-mail personnalisé** au dirigeant | Les dirigeants du métier achètent après une démonstration sur leurs propres documents, pas après une publicité. C'est déjà le plan ([launch.md](launch.md)) | Ton temps (environ 20 appels et 10 e-mails par jour de lancement) | Au moins 15 % des appels donnent une démonstration, et au moins 1 démonstration sur 5 donne un essai |
| **2. [Expoprotection](https://www.expoprotection.com/), du 3 au 5 novembre 2026, Paris Porte de Versailles** | Le salon de la sécurité (tous les deux ans) : les dirigeants et responsables d'exploitation y sont en personne. Ça tombe la semaine du test 1. Tu viens **en visiteur**, pas avec un stand | Train et repas, environ 100 € (déjà dans les 100 € par mois de déplacements). Badge visiteur : à vérifier sur le site | Au moins 15 contacts d'installateurs avec un nom et un téléphone, et au moins 4 démonstrations fixées pour novembre |
| **3. Ton profil LinkedIn** (le tien, pas une page d'entreprise) | Les dirigeants d'installateurs y sont. Un fondateur qui montre son travail répond directement à « qui est derrière ? » (la confiance) | 0 € ; 2 publications par semaine | Messages reçus et demandes de démonstration venues de LinkedIn ; nombre de prospects qui disent « je vous ai vu sur LinkedIn » |

**Ce qu'on ne fait pas (pour l'instant), et pourquoi :**
- **Publicité Google** : très peu de recherches sur « logiciel installateur alarme ». De plus, la trésorerie manque déjà de 2 000 €.
- **Facebook, Instagram, TikTok** : ce n'est pas là qu'un dirigeant choisit le logiciel de ses techniciens.
- **Un stand à un salon** : plusieurs milliers d'euros. À reconsidérer en 2028, avec des références.
- **Partenariats avec les grossistes de matériel et les télésurveilleurs, adhésion à une fédération** (GPMSE) : c'est la bonne « barrière » à long terme (recommandation du conseil). Mais il faut d'abord des clients à montrer. À ouvrir au 2e trimestre 2027, en commençant par le télésurveilleur partenaire d'ARGE.
- **Le parrainage entre clients** : pas avant d'avoir des clients satisfaits. À prévoir pour le premier fondateur qui paie (par exemple : un mois offert par confrère qui signe).

### 4. Les dix accroches

Chacune répond à un refus du panel. Format : **objet d'e-mail**, **première ligne LinkedIn** ou **première phrase au téléphone**.

| # | Accroche | Elle répond à | Format |
|---|---|---|---|
| 1 | « Vous ouvrez une agence ? Un seul planning pour toutes, dès le premier jour. » | Le premier public (croissance) | Objet d'e-mail |
| 2 | « Si je m'arrête demain : votre code est chez un tiers, vos données vous reviennent sous 5 jours. C'est écrit au contrat. » | Confiance : « une seule personne » | LinkedIn |
| 3 | « 60 jours sur une seule agence. Si vos techniciens n'en veulent pas, vous arrêtez, sans frais. » | Engagement, « je suis coincé » | Téléphone |
| 4 | « Je reprends moi-même vos clients, vos sites et vos centrales. Vous n'y passez pas vos soirées. » | « Des semaines de reprise » | Objet d'e-mail |
| 5 | « La fiche se remplit au sous-sol, sans réseau. Elle part quand le téléphone remonte. » | Le hors ligne, attendu par les groupes | LinkedIn, vidéo de 30 s |
| 6 | « Vos consignes de télésurveillance et vos bons de sortie, avec votre logo et vos mentions CNAPS. Pas un formulaire générique. » | « Un généraliste repeint » | LinkedIn, photo du document (données fictives) |
| 7 | « Le multi-agences est inclus dans toutes les formules. » | Prix des groupes | Objet d'e-mail |
| 8 | « Vous gardez votre ERP. La formule Terrain à 25 € se branche à côté. » | Habitude, « deux logiciels » | Téléphone, pour les clients équipés d'un ERP |
| 9 | « Une demi-journée sur place avec vos techniciens, dans une vraie cave, pas en visio. » | « Mes techniciens de 50 ans » | LinkedIn |
| 10 | « 39 € HT par technicien et par mois, affiché, sans engagement. » | Les prix cachés des spécialistes | Objet d'e-mail, fiche tarifs |

**Ce qu'on dit franchement quand on nous le demande :** le prélèvement SEPA automatique des abonnements n'existe pas encore. Si une date est décidée (voir [ops.md](ops.md), risque n° 10), on la donne, et seulement celle-là.

### 5. Le calendrier, du 28 décembre 2026 au 27 janvier 2027

Jour J = lundi 11 janvier 2027. Jours ouvrés seulement : pas de prospection le week-end ni les jours fériés.

**La séquence d'e-mails** (prospects répartis en 5 lots de 10, un lot par jour du 11 au 15 janvier) :
- **E1 (jour J)** : accroche 1 ou 4, trois lignes, une proposition de démonstration de 30 minutes sur leurs propres documents.
- **E2 (J + 3)** : accroche 2 ou 3, une capture d'écran de la fiche remplie.
- **E3 (J + 8)** : dernier message court, avec le nombre **réel** de places restantes.

Sous chaque e-mail : ton nom, ton numéro, et une ligne pour ne plus en recevoir. La prospection par e-mail entre professionnels est permise si elle concerne leur métier et permet de s'opposer facilement ([CNIL](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique)). Ce n'est pas un conseil juridique.

| Date | Jour | Ce qui part | Canal | Message |
|---|---|---|---|---|
| lun. 28 déc. | J − 14 | Profil mis à jour : « Je crée Itinéos Sécurité, le logiciel de terrain des installateurs d'alarme et de vidéo » ; écrire E1, E2, E3 | LinkedIn, e-mail | — |
| mar. 29 déc. | J − 13 | **Publication 1** : pourquoi ce logiciel (les fiches carbonées, la ressaisie du vendredi, sans nommer ARGE) | LinkedIn | Coulisses |
| mer. 30 déc. | J − 12 | Fiche tarifs en deux versions (35 € et 39 €) | — | — |
| jeu. 31 déc. | J − 11 | Support seulement | — | — |
| lun. 4 janv. | J − 7 | **Publication 2** : vidéo de 30 s d'une fiche remplie sans réseau, filmée pendant la mise en service de décembre (**avec l'accord d'ARGE pour filmer**, sinon dans ta propre cave) | LinkedIn | Accroche 5 |
| mar. 5 janv. | J − 6 | Répétition de la démonstration n° 1 (un installateur du test 1) | Visio | — |
| mer. 6 janv. | J − 5 | **Publication 3** : photo d'un bon de sortie télésurveillance avec données fictives | LinkedIn | Accroche 6 |
| jeu. 7 janv. | J − 4 | Répétition n° 2 ; envoi d'essai d'E1 sur tes propres adresses (vérifier qu'il n'arrive pas en indésirables) | Visio, e-mail | — |
| ven. 8 janv. | J − 3 | **Publication 4** : « Lundi, j'ouvre 5 places pour des installateurs fondateurs » | LinkedIn | Annonce |
| **lun. 11 janv.** | **J** | **Lot 1 : E1** ; appels aux « oui » du test 1 ; **publication 5** : le programme (5 places, jusqu'au 31 mars, 60 jours d'essai, mise en service offerte, prix bloqué 24 mois) | E-mail, téléphone, LinkedIn | Accroches 1, 3 |
| mar. 12 janv. | J + 1 | Lot 2 : E1 ; appels de relance du lot 1 | E-mail, téléphone | Accroche 4 |
| mer. 13 janv. | J + 2 | Lot 3 : E1 ; **publication 6** : ce que garantit le contrat | E-mail, LinkedIn | Accroche 2 |
| jeu. 14 janv. | J + 3 | Lot 4 : E1 ; **lot 1 : E2** | E-mail | Accroches 7, 2 |
| ven. 15 janv. | J + 4 | Lot 5 : E1 ; lot 2 : E2 ; bilan de la semaine (chiffres du § 6) | E-mail | Accroche 10 |
| lun. 18 janv. | J + 7 | **Bilan du jour 7** ; lot 3 : E2 ; **publication 7** : les coulisses d'une reprise de données (anonymisée) | E-mail, LinkedIn | Accroche 4 |
| mar. 19 janv. | J + 8 | Lot 4 : E2 ; **lot 1 : E3** ; appels aux lots 1 et 2 sans réponse | E-mail, téléphone | Places restantes |
| mer. 20 janv. | J + 9 | Lot 5 : E2 ; lot 2 : E3 ; **publication 8** : la formation sur place | E-mail, LinkedIn | Accroche 9 |
| jeu. 21 janv. | J + 10 | Lot 3 : E3 ; démonstrations | E-mail, visio | — |
| ven. 22 janv. | J + 11 | Lot 4 : E3 ; bilan de la semaine | E-mail | — |
| lun. 25 janv. | J + 14 | **Bilan du jour 14** ; lot 5 : E3 ; **publication 9** : le multi-agences inclus. *Si moins de 3 démonstrations :* 20 nouveaux prospects, appel d'abord, puis e-mail | E-mail, LinkedIn, téléphone | Accroche 7 |
| mar. 26 janv. | J + 15 | Appels aux lots 3 à 5 sans réponse ; démonstrations | Téléphone | Accroche 3 |
| mer. 27 janv. | J + 16 | **Publication 10** : le prix public, et l'état réel des places | LinkedIn | Accroche 10 |

**Quand il n'y a rien de neuf à dire** (une publication sur deux au-delà du 27 janvier) :
- les coulisses du développement (l'import, l'export, le prélèvement SEPA quand il arrive) ;
- une fonction en 30 secondes ;
- un document du métier expliqué (à quoi sert un bon de sortie) ;
- une question au métier : « Comment transmettez-vous vos consignes au télésurveilleur ? » ;
- une mise en service racontée, avec l'accord du client.

### 6. Budget et chiffres

**Budget de lancement : environ 150 €**, déjà compris dans les 100 € par mois de déplacements de [numbers.json](numbers.json) :
- Expoprotection : environ 100 € ;
- impression de 30 fiches A4 de présentation pour le salon et les visites : environ 50 € (estimation).

E-mails : Brevo, formule gratuite au départ. LinkedIn : 0 €. On n'ajoute rien à la trésorerie, puisqu'il manque déjà 2 000 €.

**Ce que tu peux dépenser au maximum pour gagner un client :**
- Ce qui reste par technicien : **25,22 €** par mois ([cfo.md](cfo.md)).
- Client moyen : 8 techniciens, soit 8 × 25,22 € = **201,76 € par mois et par client**.
- Le panel annonce **1,0 achat par acheteur** le premier mois. Pour un abonnement, ça veut dire un abonnement, pas un achat répété.
- Règle de prudence : le client doit rembourser ce qu'il a coûté en **6 mois** : 6 × 201,76 € = **1 211 €**.
- Un fondateur sur cinq arrête après l'essai : 0,8 × 1 211 € = **969 € au maximum par essai signé**.
- Or la mise en service sur place d'un fondateur coûte déjà environ **820 €** (frais et 3 jours de ton temps, [ops.md](ops.md) § 8).
- **Il reste donc environ 150 € par essai signé pour trouver le client.** C'est pour ça que le plan repose sur le téléphone, LinkedIn et un salon en visiteur, et pas sur la publicité.

**Les trois chiffres à suivre chaque lundi :**

| Chiffre | Bon niveau | Il faut changer quelque chose si… |
|---|---|---|
| Appels → démonstrations | 15 % ou plus | moins de 15 % après 40 appels : changer l'accroche d'ouverture (passer de la 1 à la 3) ou la liste (garder les installateurs qui grandissent) |
| Démonstrations → essais signés | 1 sur 5 ou mieux | 0 essai après 10 démonstrations : reprendre les objections notées, puis `/founder-offer` ou `/founder-pricing` |
| Coût par essai signé (temps + frais, hors mise en service) | 150 € ou moins | plus de 300 € : moins de déplacements, démonstrations en visio |

*Les chiffres du panel viennent d'acheteurs simulés, et les montants sont des projections. Seuls les vrais appels et les vraies démonstrations les confirment. Ce n'est pas un conseil juridique.*

## Brand

Sources : [marketing.md](marketing.md) (positionnement A : l'installateur qui grandit), [competitors.md](competitors.md), [panel-v2/results.md](panel-v2/results.md), [pitch.md](pitch.md). Ce qui existe déjà : le nom **Itinéos** (choisi et vérifié par toi le 22/10/2026), le logo (commit 01c23ea), et les couleurs et polices du logiciel (`apps/web/brand/`, `apps/web/src/styles.css`).

**Ce que ce document ne refait pas.** Le nom de l'entreprise et du logiciel, **Itinéos**, est décidé, et le logo existe : version sur fond noir uniquement, à ta demande. On ne propose donc pas de nouveau nom ni de nouveau logo. La seule question de nom ouverte est celle de **l'édition** vendue aux installateurs, aujourd'hui appelée « Itinéos Sécurité » (nom de travail).

### 1. Le nom de l'édition

**Le problème du nom de travail.** Itinéos a déjà une édition pour la **sécurité privée** (Vigie : gardiennage, agents). Dans le métier, « sécurité » désigne souvent ces sociétés-là, que le CNAPS encadre aussi. Un installateur d'alarme qui lit « Itinéos Sécurité » peut croire que c'est un logiciel pour agents de sécurité. Et l'ARGE tourne aujourd'hui sur l'édition TECH, pas sur Vigie.

#### Dix pistes

| # | Nom | Style | Ce qu'il dit | À l'oral | Sur l'icône ou une plaquette | Risque |
|---|---|---|---|---|---|---|
| 1 | **Itinéos Sécurité** | Descriptif | Le domaine, en général | Clair | Bien | Confusion avec la sécurité privée (Vigie, gardiennage) |
| 2 | **Itinéos Sûreté** | Descriptif, mot du métier | La protection contre la malveillance : alarme, vidéo, accès | « sû-re-té » : un peu soutenu | Court, lisible | Moins parlant pour un petit installateur qui dit « alarme » |
| 3 | **Itinéos Alarme** | Descriptif étroit | Le cœur du métier | Très clair | Court | Laisse de côté la vidéo et le contrôle d'accès |
| 4 | **Itinéos Installateur** | Descriptif (l'acheteur) | « C'est pour moi » | Clair | Long sur une icône | Les électriciens et plombiers sont aussi des installateurs |
| 5 | **Itinéos Sécurité électronique** | Descriptif complet | Le nom exact de la filière | Long | Trop long | Lourd au quotidien |
| 6 | **Itinéos SE** | Sigle | Sécurité électronique, pour les initiés | « S-E » : sec | Très court | Ne dit rien à qui ne connaît pas le sigle |
| 7 | **Itinéos Centrale** | Évocateur | La centrale d'alarme, objet du métier | Facile | Bien | Confusion avec « centrale de télésurveillance » (le télésurveilleur) |
| 8 | **Itinéos Veille** | Évocateur | Surveiller, protéger | Doux | Bien | Trop proche de Vigie, l'autre édition |
| 9 | **Itinéos Pose & Maintenance** | Descriptif (les tâches) | Ce que font les techniciens | Long | Mauvais | Vrai pour tous les métiers |
| 10 | **Itinéos**, sans suffixe, + une phrase descriptive | Une seule marque | « Le logiciel de terrain des installateurs d'alarme et de vidéosurveillance » | Le plus simple | Le logo existant suffit | La phrase doit toujours accompagner le nom |

#### Les trois retenues

1. **Itinéos, sans suffixe, avec la phrase descriptive (recommandé).**
   - Une seule marque à faire connaître, un seul dépôt (« Itinéos », déjà prévu à l'INPI), le logo tel quel.
   - Pour le client, il n'existe qu'un produit : les autres éditions ne sont jamais montrées aux installateurs. Le nom d'édition reste donc un nom **interne**.
   - La phrase porte le métier : *« Itinéos, le logiciel de terrain des installateurs d'alarme et de vidéosurveillance. »*
2. **Itinéos Sûreté** : si tu tiens à un suffixe. C'est le mot exact de la profession pour la malveillance, et il évite la confusion avec la sécurité privée.
3. **Itinéos Sécurité** : seulement si les installateurs eux-mêmes le préfèrent. À tester au téléphone pendant le test des 20 appels : « Vous diriez plutôt sécurité ou sûreté ? »

#### Les vérifications à finir toi-même

- **La marque** (Itinéos, en classes 9 et 42, déjà prévue dans [ops.md](ops.md)) : base des marques de l'[INPI](https://data.inpi.fr/), et [TMview](https://www.tmdn.org/tmview/) pour l'Union européenne. Une simple phrase descriptive comme « pour les installateurs d'alarme » ne se dépose pas. Si tu choisis un suffixe (« Sûreté »), vérifie que « Itinéos Sûreté » ne crée pas de conflit dans les mêmes classes. Je ne peux faire que des recherches publiques : seul un conseil en propriété industrielle confirme, et rien n'est protégé tant que le dépôt n'est pas fait. Ce n'est pas un conseil juridique.
- **Les domaines (vérifiés le 23/10/2026)** :
  - **itineos.fr est à toi** (confirmé le 23/10/2026). C'est l'adresse du site et des e-mails.
  - **itineos.com** a été enregistré à la même minute (23/10/2026, 13 h 50), chez le même hébergeur (IONOS). Il est sans doute dans ton compte IONOS : à vérifier. S'il y est, fais-le rediriger vers itineos.fr.
  - itineos.app et itineos-securite.fr sont libres à ce jour. Inutile de les prendre.
- **Les comptes sur les réseaux** : je n'ai pas pu les vérifier. Ouvre ces adresses une par une : linkedin.com/company/itineos (la priorité, c'est le canal choisi), youtube.com/@itineos (vidéos de démonstration), instagram.com/itineos et x.com/itineos (seulement pour réserver le nom : ce ne sont pas des canaux prévus).
- **Pas de confusion avec un concurrent** : aucun nom du relevé n'est proche (Le Terrain, Sustencio, CMII W'IPSOS, Capasoft Kéops, Praxedo, Infocob, Organilog, ArtisanSmart, Kizeo Forms).

### 2. La promesse et la voix

**La promesse (ce sur quoi le client peut compter, chaque jour) :**
> Ce que vos techniciens remplissent sur le terrain, même sans réseau, arrive au bureau le soir même, sur vos propres documents.

**Trois signatures possibles :**
1. **« Du terrain à la facture, le soir même. »** *(recommandée : c'est le résultat qui fait gagner les samedis, cité par les deux oui du panel)*
2. « Vos fiches. Votre métier. Même au sous-sol. »
3. « Le logiciel de terrain des installateurs d'alarme. »

**La voix, en trois mots :**

| Mot | À faire | À éviter |
|---|---|---|
| **Concret** | Parler de la cave sans réseau, de la centrale, du numéro d'abonné, du bon de sortie | « Solution innovante », « transformation digitale », « IA » (c'est l'argument de Le Terrain) |
| **Franc** | Dire ce qui n'existe pas encore (le prélèvement SEPA) et donner une date seulement si elle est tenue | Promettre « bientôt » sans date, laisser croire qu'il y a déjà des clients référents |
| **Proche** | Écrire « je » : le créateur parle, avec son nom et son numéro | Le « nous » d'une grande entreprise qui n'existe pas. Le panel l'a montré : la confiance passe par la personne et par des garanties écrites, pas par une fausse taille |

**Avant / après, sur une phrase de [pitch.md](pitch.md) :**
- *Avant :* « Ce que ça fait : planning par agence (multi-agences inclus), appli du technicien qui marche sans réseau, fiche déjà remplie (site, centrale, n° de série, n° d'abonné)… »
- *Après :* « Votre technicien ouvre la fiche au sous-sol, sans réseau : le site, la centrale et le numéro d'abonné sont déjà remplis. Le client signe, le PDF part tout seul, et le soir la facture est prête. »

### 3. L'identité visuelle

Tout existe déjà dans le logiciel. On l'écrit ici pour que les e-mails, la fiche A4, LinkedIn et le futur site restent cohérents.

#### Les couleurs

| Couleur | Code | À quoi elle sert |
|---|---|---|
| **Encre** | `#14181F` | Fond du logo (toujours sur noir, à ta demande), texte principal |
| **Papier** | `#F4F2EE` | Fond des pages et des documents ; texte et lettres du logo sur l'encre |
| **Orange signal** | `#F97316` | Le repère et le « é » du logo, **uniquement sur fond encre** |
| **Orange texte** | `#C2410C` | Liens et boutons sur fond clair (déjà `--accent` dans le logiciel) |

**Le contraste (calculé avec la formule WCAG) :**
- papier sur encre : **15,9:1**, excellent ;
- orange signal sur encre : **6,35:1**, conforme AA ;
- orange texte sur papier : **4,63:1**, conforme AA pour le texte courant ;
- texte blanc sur un bouton orange texte : **5,18:1**, conforme AA.
- **À ne jamais faire :**
  - du texte blanc sur l'orange signal : 2,8:1, échoue ;
  - de l'orange signal sur papier : 2,51:1, échoue.

  C'est pour ça que le logiciel utilise déjà l'orange foncé `#C2410C` pour ses boutons.

#### Les polices
- **Titres : Archivo**. **Texte : IBM Plex Sans.**
- Les deux sont déjà utilisées dans le logiciel et sont sous licence libre SIL Open Font License, téléchargeables sur [Google Fonts](https://fonts.google.com/). Tu peux les utiliser partout : site, PDF, fiche A4, vidéos.

#### Le logo : ce qu'il doit tenir
- Le logo actuel (écran de bureau → route en pointillés → repère orange avec une coche ; « itinéos » avec le « é » orange) raconte déjà la promesse : du bureau au terrain, et c'est fait. **On n'y touche pas.**
- **À vérifier, à 32 pixels** (icône de l'appli, onglet du navigateur) : les pointillés de la route risquent de disparaître. L'icône `apps/web/brand/icon.svg` existe ; si elle devient illisible à cette taille, garder seulement le repère orange avec sa coche sur fond encre.
- **Pour l'édition installateurs :** pas de logo à part. On met le logo, puis la phrase descriptive en dessous, en IBM Plex Sans, couleur papier sur encre.
- **À éviter :** un bouclier, un cadenas ou un œil. Ce sont les images de tous les acteurs de la sécurité, et elles rapprocheraient Itinéos de la sécurité privée.

### 4. Les cinq premiers contacts avec le client

1. **L'e-mail de prospection (E1, [marketing.md](marketing.md)).** C'est la vitrine. Trois lignes, en « je ». Une capture de la fiche remplie. Ta signature : nom, « créateur d'Itinéos », téléphone portable, itineos.fr. Pas de logo en grand : un e-mail de personne à personne passe mieux.
2. **La page d'accueil itineos.fr** (à créer, une seule page) :
   - la signature en titre ;
   - la vidéo de 30 secondes au sous-sol ;
   - trois points : vos documents, sans réseau, facture le soir même ;
   - l'offre fondateurs avec le nombre **réel** de places restantes ;
   - les prix publics ;
   - les garanties écrites ;
   - un bouton « Une démonstration de 30 minutes sur vos documents » ;
   - ta photo, ton nom et ton téléphone.

   Pas de logos de clients tant qu'aucun n'a donné son accord écrit.
3. **Les documents vus par les clients de l'installateur** (le « paquet ») : les fiches signées et les PDF portent **le logo et les mentions de l'installateur**, pas ceux d'Itinéos. Une mention discrète « Créé avec Itinéos » en pied de page est possible, **désactivable** par l'installateur, et à lui demander.
4. **La confirmation après la signature de l'essai** : un e-mail le jour même, avec la date de mise en service, la liste de ce qu'il faut préparer pour J − 10 (routine R2 de [ops.md](ops.md)), ton numéro et le rappel des garanties.
5. **La réponse à la première plainte** (routine R3, ton franc et proche) :
   > « Bonjour [prénom], merci de me l'avoir dit tout de suite. Je comprends : [ce qui s'est passé, avec ses mots]. Voici ce que je fais : [action] d'ici [date et heure]. Je vous rappelle à [heure] pour vérifier avec vous. — Justin, [téléphone] »

*Recherches publiques seulement. Rien n'est déposé ni réservé tant que tu ne l'as pas fait toi-même. Ce n'est pas un conseil juridique sur les marques.*

## Operations

Entrées : [idea.md](idea.md), [offer.md](offer.md), [numbers.json](numbers.json), [cfo.md](cfo.md), et ce qui existe déjà dans le logiciel ([DEPLOIEMENT.md](../DEPLOIEMENT.md), console de supervision, mises à jour la nuit, sauvegardes).

**Le constat principal.** Tout repose sur toi. Le conseil le disait (« une mise en route qui dépend du fondateur »), et le panel le confirme : 7 refus sur 20 viennent de la peur qu'une seule personne tienne le logiciel. Ce document organise donc ta semaine pour que ça tienne avec 5 fondateurs. Il indique aussi les trois choses à mettre en place pour ne plus être le seul point de passage : **l'import de fichiers**, **l'export complet en un clic** et **un support de secours nommé**.

### 1. Le cycle d'une journée

Les techniciens des clients commencent tôt : le support doit être ouvert avant eux. 👁 = ce que le client voit.

| Heure | Étape | 👁 |
|---|---|:-:|
| 7 h 15 | Console de supervision : tous les serveurs clients en ligne, sauvegardes de la nuit réussies, mise à jour de nuit passée | |
| 7 h 30 | Support ouvert (téléphone, e-mail). Les techniciens se connectent, synchronisent l'appli et partent sur les chantiers | 👁 |
| 8 h | Lecture du résumé e-mail de 8 h (pannes, bugs, mises à jour ratées). Tri des demandes de la veille | |
| 8 h 30 – 12 h | Selon le jour : démonstrations, mise en service chez un fondateur, ou prospection | 👁 |
| 12 h – 13 h 30 | Créneau de rappel support (heure de pause des techniciens) | 👁 |
| 13 h 30 – 17 h | Développement (corrections, import, export, prélèvement SEPA) ou suite de la mise en service | |
| 17 h – 18 h | Fin de tournée des techniciens : fiches signées, PDF envoyés, factures préparées au bureau du client. Réponse aux demandes du jour | 👁 |
| Nuit | Mise à jour automatique (si une version est prête) et sauvegarde | |

Le délai de support promis est de **4 heures ouvrées**. Avec ce cycle, une demande reçue le matin a une réponse avant 12 h 30, une demande de l'après-midi avant 17 h ou le lendemain à 8 h.

### 2. Les fournisseurs

| Besoin | Fournisseurs possibles | Prix public relevé | Ce qu'il faut savoir |
|---|---|---|---|
| Serveur en France | [OVHcloud VPS](https://www.ovhcloud.com/fr/vps/) (Gravelines, Roubaix, Strasbourg) · [Scaleway](https://www.scaleway.com/fr/tarifs/virtual-instances/) (Paris) · Infomaniak (Suisse, hors France) | OVH VPS-1 : environ 6,50 € par mois avant la hausse de 2026, [hausse annoncée](https://next.ink/225720/ovhcloud-augmente-fortement-le-prix-de-ses-vps-2026-et-ipv4/) · Scaleway PLAY2-PICO : environ 10 € par mois hors disque, [hausse au 1er juin 2026](https://www.scaleway.com/fr/blog/a-transparent-update-on-scaleway-pricing/) | Sans engagement, paiement mensuel par carte. Il faut **deux** machines : le serveur des clients et la console de supervision (5 à 10 € selon [son LISEZ-MOI](../deploy/supervision/LISEZ-MOI.md)), plus une copie des sauvegardes **hors du serveur** (stockage objet, quelques euros). Les 20 € par mois de numbers.json tiennent. |
| Prélèvement des abonnements | [GoCardless](https://gocardless.com/fr/tarifs/) · Stripe (prélèvement SEPA) · simple virement | GoCardless : **1 % + 0,20 € par prélèvement, plafonné à 2 €** en France ([page GoCardless](https://gocardless.com/fr-fr/solutions/en-savoir-plus-sepa)) ; rejet 7,50 € | Pour un client de 8 techniciens à 35 €, le prélèvement de 280 € coûte 2 €, soit **0,25 € par technicien** (au lieu des 0,38 € estimés). Tarif Stripe à vérifier sur son site. Le virement ne coûte rien, mais il faut relancer. |
| Dépôt du code source chez un tiers | [APP, Agence pour la protection des programmes](https://www.app.asso.fr/) · Logitas | **Pas de grille publique trouvée.** Ordre de grandeur donné par [un article d'octobre 2026](https://kolonell.com/fr/blog/sequestre-code-source-logiciel-metier-agence-cout-2026) : 300 à 700 € HT par an (APP), 400 à 900 € (Logitas) | **Devis à demander.** Il faut un contrat de séquestre à trois (toi, l'agence, le client) et une mise à jour du dépôt à chaque version importante. Les 40 € par mois de numbers.json (480 € par an) sont dans la fourchette. |
| Marque | [INPI](https://www.inpi.fr/la-marque/en-pratique-le-depot) | **190 € en ligne pour une classe, 40 € par classe en plus** (prix officiel) | Classes 9 (logiciel) et 42 (logiciel en ligne) : 230 €, confirmé. Renouvellement au bout de 10 ans. |
| Assurance responsabilité civile pro | Hiscox · Stello · un courtier (par exemple Coover) | Hiscox à partir d'environ 150 à 270 € par an, Stello à partir de 15 € par mois, selon [des comparatifs](https://lefreelance.fr/articles/assurance-rc-pro-freelance/) ([autre comparatif](https://independant.io/assurance-rc-pro-informatique/)) | Ces prix d'appel concernent un développeur indépendant. Un éditeur qui **héberge les données de ses clients** doit demander l'option cyber et la perte de données : **devis à demander**. Les 40 € par mois prévus laissent cette marge. |
| Envoi des e-mails (fiches PDF, mots de passe) | Brevo · Mailjet (hébergés en Europe, cités dans [DEPLOIEMENT.md](../DEPLOIEMENT.md)) | Brevo a une formule gratuite avec une limite d'envois par jour (à vérifier sur son site) | Suffisant au début. À surveiller au-delà de 10 clients : chaque fiche signée envoie un e-mail. |
| Plateforme agréée pour **tes propres** factures | Ta banque pro ou ton logiciel de comptabilité, s'il en propose une | Prix non trouvé | Tu dois **recevoir** des factures électroniques depuis le 1er septembre 2026 et en **émettre** à partir du 1er septembre 2027 (micro-entreprise comprise) ([calendrier](https://www.ag2rlamondiale.fr/groupe/magazines/expertises/reglementation/facturation-electronique-etes-vous-pret)). Tu peux facturer tes clients depuis Itinéos (Factur-X déjà en place), puis déposer sur la plateforme choisie. |
| Prise de main à distance | RustDesk (déjà intégré à la console de supervision) | Gratuit, installé sur ton serveur | Rien à acheter. |

### 3. Les personnes

**Aujourd'hui : toi seul.** Pas de salaire au départ (ta réponse), objectif de 2 500 € net. Il n'y a pas de paie à prévoir, donc pas de charges sociales d'employeur. En micro-entreprise, tes cotisations sont calculées sur le chiffre d'affaires et sont déjà dans les coûts par technicien.

**Le support de secours, à nommer avant d'envoyer l'offre.** C'est la demande n° 1 du panel. La solution la moins chère est un **développeur indépendant sous contrat d'astreinte légère**. Il connaît le code, a accès à la console et à la procédure de reprise, et prend le relais si tu es absent plus de 2 jours ouvrés. Il est nommé dans le contrat client. Proposition : un forfait de quelques heures par mois pour se tenir à jour, plus un tarif journalier en cas d'intervention. **J'ai estimé 150 € par mois** (environ 3 heures au tarif courant d'un indépendant, à négocier). Il est ajouté à numbers.json.

#### Semaine type pendant le premier mois (novembre 2026 : ARGE, aucun fondateur payant)

| | Lundi | Mardi | Mercredi | Jeudi | Vendredi |
|---|---|---|---|---|---|
| Matin | Ouverture, puis prospection (10 appels) | Démonstrations | Mise en service ARGE / suivi | Démonstrations | Ouverture, puis prospection (10 appels) |
| Après-midi | Développement : **import de fichiers** | Développement | Développement : **export complet** | Relances après démonstration | Développement, mise à jour prête pour la nuit |

Environ 20 appels et 4 à 6 démonstrations par semaine. C'est le rythme nécessaire pour voir passer environ 50 prospects sérieux en 5 mois ([cfo-sources.md](cfo-sources.md)).

#### Semaine type à plein régime (environ 110 techniciens, 14 à 15 clients)

| Tâche | Heures par semaine | Comment je l'ai estimé |
|---|---:|---|
| Support | 8 h | Environ 30 minutes par client et par semaine une fois installé (estimation, à mesurer) |
| Mises en service (1 nouveau client par mois, 1 à 3 jours chacun) | 4 à 6 h | D'après [offer.md](offer.md) |
| Prospection et démonstrations | 10 h | |
| Développement et mises à jour | 15 h | |
| Administration (facturation, URSSAF, comptabilité) | 2 h | |
| **Total** | **39 à 41 h** | Tenable seul, à condition que les mises en service ne se chevauchent pas |

**La limite réelle : 2 mises en service par mois au maximum.** C'est pour ça que le programme fondateurs est limité à 5 places jusqu'à fin mars : la limite est vraie.

### 4. Les routines

#### R1. L'ouverture du matin (15 minutes, chaque jour ouvré)
1. Ouvrir la console de supervision. Chaque client doit être en vert.
2. Vérifier la sauvegarde de la nuit pour chaque client : date du jour, taille normale.
3. Vérifier la mise à jour de nuit : version attendue partout.
4. Lire le résumé e-mail de 8 h.
5. Trier les demandes : **bloquant** (un technicien ne peut pas travailler), **gênant**, **question**.
6. Si un client est en rouge, passer directement à R4.

#### R2. La mise en service d'un fondateur (le cœur du service)
1. **J − 10** : visio de 30 minutes pour récupérer les fichiers du client : liste des clients et sites (export de son logiciel ou tableur), centrales et numéros d'abonné, modèles de fiches, consignes, bons de sortie, logo, mentions CNAPS, liste des techniciens et des agences.
2. **J − 7** : préparer la société dans Itinéos (agences, réglages de facturation : taux horaire et déplacement, sinon les factures sortent à 0 €), puis les modèles de documents à son logo.
3. **J − 5 à J − 1** : reprendre les données. *Aujourd'hui c'est à la main ; avec l'outil d'import, ce sera un fichier.* Faire vérifier 10 fiches clients par le client.
4. **J 0, matin (sur place)** : comptes des techniciens, installation de l'appli sur leurs téléphones, une intervention d'essai **dans une cave sans réseau**.
5. **J 0, après-midi** : demi-journée de formation des techniciens, puis une heure avec la personne du planning.
6. **J + 2** : appel au dirigeant. **J + 7** : appel aux techniciens. Noter ce qui bloque.
7. **J + 30** : bilan à mi-parcours. Combien de fiches faites dans Itinéos, et combien encore sur papier ?
8. **J + 50** : bilan de fin d'essai et décision du client. S'il reste : mandat de prélèvement, **accord écrit pour être cité**, retour écrit.
9. **J + 60** : premier prélèvement ; ou, si le client arrête, export complet de ses données (R6) et désactivation de la société.

#### R3. Une demande au support (réponse sous 4 heures ouvrées)
1. Répondre tout de suite : « Bien reçu, je regarde, retour avant [heure] ».
2. Classer la demande : bloquant, gênant ou question.
3. Bloquant : prise en main à distance (RustDesk) ou appel au technicien sur le chantier. Contournement d'abord, correction ensuite.
4. Noter la demande et la solution dans le suivi (la console a une liste de bugs).
5. Si c'est un défaut du logiciel : correction, test, mise à jour de nuit, prévenir le client le lendemain matin.
6. Une **plainte** (pas un bug) : appeler le dirigeant le jour même, écouter jusqu'au bout, proposer une action datée, la confirmer par écrit.

#### R4. Une panne de serveur
1. Prévenir les clients concernés dans l'heure (e-mail et SMS au dirigeant). L'appli terrain continue de marcher hors réseau, et les fiches remontent au retour du serveur.
2. Redémarrer, puis lire les journaux ([DEPLOIEMENT.md](../DEPLOIEMENT.md), « En cas de souci »).
3. Si la machine est perdue : nouveau serveur, restauration de la dernière sauvegarde copiée hors du serveur.
4. Écrire au client ce qui s'est passé et ce qui change pour que ça ne se reproduise pas.

#### R5. La mise à jour (le soir)
1. Tous les tests passent (`npm test`, `npm run test:integration`).
2. Faire une sauvegarde manuelle avant la mise à jour.
3. Publier pour la nuit. Si l'appli terrain change : construire l'APK et vérifier qu'elle se met à jour sur un téléphone.
4. Le lendemain, R1 vérifie que tout le monde est passé.

#### R6. Une demande d'export complet (promis sous 5 jours ouvrés)
1. Accuser réception et noter la date limite.
2. Exporter la base du client, ses PDF et ses photos. *Aujourd'hui, à la main ; à remplacer par un bouton « Exporter toutes mes données ».*
3. Remettre des fichiers lisibles sans Itinéos (CSV pour les tableaux, PDF pour les documents) et un mode d'emploi d'une page.
4. Garder la preuve d'envoi.

#### R7. Le mois (le 1er de chaque mois)
1. Compter les techniciens actifs de chaque client le dernier jour du mois.
2. Faire les factures d'abonnement **depuis Itinéos** (Factur-X), puis lancer les prélèvements.
3. Suivre les rejets de prélèvement : appel au client sous 48 heures.
4. Déclarer le chiffre d'affaires à l'URSSAF (chaque mois ou chaque trimestre selon ton choix).
5. Tenir le livre des recettes.
6. Une fois par mois : **essai de restauration** d'une sauvegarde sur une machine de test.
7. Une fois par trimestre : mettre à jour le dépôt du code source chez le tiers.

### 5. Les outils (le minimum)

| Besoin | Outil | Prix | Pourquoi |
|---|---|---|---|
| Facturer tes clients | **Itinéos lui-même** | 0 € | Factur-X déjà en place, et c'est la meilleure démonstration |
| Prélever | GoCardless | 1 % + 0,20 €, plafonné à 2 € | Prélèvement automatique, mandats en ligne |
| Banque | Compte pro en ligne | Environ 10 € par mois (estimation) | Obligatoire en micro-entreprise au-delà de 10 000 € de chiffre deux années de suite ; pratique dès maintenant |
| Comptabilité | Livre des recettes + export comptable d'Itinéos | 0 € | Suffisant en micro-entreprise. Expert-comptable au passage en SASU |
| Support à distance | Console de supervision + RustDesk | Prix du serveur | Déjà construits |
| Prospects | Un tableur partagé (nom, date, étape, prochaine action) | 0 € | Inutile d'acheter un logiciel de suivi commercial pour 50 prospects |
| E-mails | Brevo | Formule gratuite au départ | Hébergé en Europe |

### 6. Démarches, contrats et assurances

Ces règles changent et dépendent de ta situation. **Confirme chaque point auprès de l'administration ou d'un professionnel.** Ce n'est pas un conseil juridique.

- [ ] **Immatriculation** en micro-entreprise (déjà faite) : vérifier sur le [guichet unique](https://formalites.entreprises.gouv.fr/) que l'activité déclarée correspond bien à « édition de logiciels / logiciel en ligne ». C'est ce qui décide entre BIC et BNC.
- [ ] **Taux de cotisations** : 25,6 % pour les BNC du régime général des indépendants en 2026 (la hausse prévue à 26,1 % a été plafonnée), plus environ 0,2 % pour la formation professionnelle ([source](https://www.lecoindesentrepreneurs.fr/taux-cotisations-sociales-2026-micro-entrepreneur/)). Environ 21,2 % si l'activité relève des BIC. À confirmer sur [autoentrepreneur.urssaf.fr](https://www.autoentrepreneur.urssaf.fr/).
- [ ] **TVA** : vérifier le seuil de franchise en base sur [impots.gouv.fr](https://www.impots.gouv.fr/). D'après [cfo.md](cfo.md), tu le dépasseras vers 90 techniciens payés. Prépare tes factures avec TVA à partir de là.
- [ ] **Conditions générales de vente entre professionnels** : mentions obligatoires (pénalités de retard, indemnité forfaitaire de 40 €), délai de support, réversibilité, séquestre. → juriste (800 € prévus).
- [ ] **RGPD : tu es sous-traitant des données de tes clients.** Il faut un contrat de sous-traitance avec chaque client (article 28), un registre des traitements et des mesures de sécurité écrites ([CNIL, guide du sous-traitant](https://www.cnil.fr/fr/reglement-europeen-sur-la-protection-des-donnees-un-guide-pour-accompagner-les-sous-traitants)). La **géolocalisation des véhicules** impose au client d'informer ses salariés ([CNIL, géolocalisation des véhicules](https://www.cnil.fr/fr/la-geolocalisation-des-vehicules-des-salaries)) : à rappeler dans la mise en service.
- [ ] **Facture électronique pour tes propres factures** : réception depuis le 1er septembre 2026, émission au 1er septembre 2027. Choisir une plateforme agréée avant l'été 2027.
- [ ] **Marque Itinéos** à l'INPI, classes 9 et 42 : 230 €.
- [ ] **Séquestre du code source** : contrat signé avant d'écrire la garantie dans l'offre.
- [ ] **Assurance responsabilité civile pro** avec option cyber et perte de données : devis.
- [ ] **CNAPS** : pas de démarche pour toi. L'autorisation CNAPS concerne tes clients, pas l'éditeur du logiciel.
- [ ] **Comptes développeur** : Apple (99 $ par an), Google Play (déjà ouvert pour l'appli Android).

### 7. Les risques

Probabilité et gravité : faible, moyenne ou forte.

| # | Ce qui peut arriver | Probabilité | Gravité | Ce qu'on fait |
|---|---|:-:|:-:|---|
| 1 | **Tu es malade ou indisponible une semaine** | Moyenne | Forte | Support de secours nommé dans le contrat, accès à la console, procédure écrite (R1, R3, R4). Message d'absence qui donne son numéro. |
| 2 | **Trop peu de prospects** : moins de 10 démonstrations par mois | Forte | Forte | C'est le premier facteur du CFO (volume divisé par 2 : bénéfice de l'année 1 de 2 483 € → perte de 1 225 €). Compter chaque semaine les appels et les démonstrations, et faire de la référence ARGE la priorité. |
| 3 | **Un fondateur arrête après l'essai** | Forte | Moyenne | Déjà prévu dans le plan (1 sur 5). Bilans à J + 7 et J + 30 pour voir l'abandon venir. Comprendre pourquoi, par écrit. |
| 4 | **Deux mises en service en même temps** | Moyenne | Moyenne | 2 par mois au maximum, dates fixées à la signature, 5 places en tout. |
| 5 | **Une mise à jour casse l'appli terrain** un matin | Moyenne | Forte | R5 : tests, sauvegarde avant, mise à jour la nuit, contrôle à 7 h 15. Garder la version précédente prête à être remise. |
| 6 | **Perte de la clé de signature de l'appli Android** (dossier `%USERPROFILE%\.arge`) | Faible | Forte | Sans elle, plus de mise à jour possible de l'appli installée. Copie chiffrée hors du PC, aujourd'hui. |
| 7 | **Panne du serveur ou perte de données** | Faible | Forte | Sauvegarde copiée hors du serveur, restauration essayée chaque mois (R7), R4. |
| 8 | **Faille de sécurité / fuite de données** | Faible | Forte | Double authentification sur la console, pare-feu (déjà documentés), assurance cyber, procédure de notification CNIL sous 72 heures. |
| 9 | **ARGE ne veut pas être cité** ou ne ramène personne | Moyenne | Forte | Mettre la contrepartie du prix réduit **par écrit** : accord pour être cité, nombre de présentations à des confrères. Sinon, prix normal. |
| 10 | **Le prélèvement SEPA des abonnements manque** et bloque les ventes | Forte | Moyenne | Il revient dans 5 réponses du panel. Décider d'une date et la tenir. En attendant, la formule Terrain qui se branche à côté de l'ERP. |

### 8. Les conditions du conseil

- **Une mise en route reproductible sans le fondateur** : **pas remplie.** Il manque trois choses, à mettre en tête de la feuille de route avant le 1er fondateur hors ARGE :
  1. **l'import de fichiers** (clients, sites, centrales, numéros d'abonné, matériels depuis un tableur) ;
  2. **l'export complet en un clic** (c'est aussi la garantie de l'offre) ;
  3. **des modèles « sécurité » prêts à l'emploi**, testés chez un installateur autre qu'ARGE.
- **La jointure avec le télésurveilleur** : **déclarée hors périmètre** pour l'instant, comme le dit l'offre. Les consignes sont produites en PDF ; l'envoi automatique est à explorer avec le partenaire d'ARGE.
- **Le vrai coût de la mise en service** (question posée au CFO) :
  - pour un fondateur : environ **250 € de frais** et 2 à 3 jours de ton temps ;
  - à 2 500 € net par mois, une journée de ton temps vaut au moins **190 € de chiffre d'affaires** (environ 3 400 € de chiffre par mois, divisés par 18 jours de travail, en comptant les cotisations) ;
  - une mise en service sur place coûte donc au moins 250 € + 3 × 190 € = **environ 820 €**. Les 300 € de la grille actuelle ne couvrent que les frais.
  - **Proposition** pour les clients hors programme fondateurs : **à distance 450 € HT** (import du fichier + 2 heures de formation en visio) ; **sur place 950 € HT** (1 jour sur place + préparation + frais). Dans les deux cas, déduite de la première année si le client reste, comme prévu dans [pricing.md](pricing.md).

### Changements apportés à numbers.json

| Ligne | Avant | Après | Pourquoi |
|---|---:|---:|---|
| Cotisations sociales | 9,21 € (26,3 %) | **9,03 € (25,8 %)** | Taux BNC 2026 plafonné à 25,6 %, plus 0,2 % de formation |
| Frais de prélèvement | 0,38 € | **0,25 €** | GoCardless plafonné à 2 € par prélèvement, soit 2 € / 8 techniciens |
| Support de secours (nouveau) | — | **150 € par mois** | Demande n° 1 du panel ; estimation à négocier |
| Plateforme agréée pour tes factures (nouveau) | — | **10 € par mois** | Estimation, prix non trouvé |

Le calcul du CFO a été relancé avec ces chiffres (voir [cfo.md](cfo.md)) :
- il reste 25,22 € par technicien (au lieu de 24,91 €) ;
- les coûts fixes passent à 411 € par mois et l'activité couvre ses frais à partir de 17 techniciens ;
- il faut **116 techniciens** pour te verser 2 500 € net ;
- il faut **3 208 €** de trésorerie au départ, et les dépenses de départ sont récupérées au mois 9.

*Depuis, la montée en charge a été recalée sur l'envoi de l'offre le 11 janvier 2027 ([launch.md](launch.md)). Il faut maintenant 4 030 € de trésorerie, et les dépenses de départ ne sont pas récupérées en fin d'année 1. Voir [cfo.md](cfo.md).*

## Launch plan

**Envoi aux premiers prospects : lundi 11 janvier 2027** (ton choix). Fin du programme fondateurs : 31 mars 2027.
Entrées : [offer.md](offer.md), [pitch.md](pitch.md), [cfo.md](cfo.md), [ops.md](ops.md), [panel-v2/results.md](panel-v2/results.md).

**Où en est ARGE (ta réponse du 23/10/2026).** La direction a vu une première présentation. La deuxième est prévue avec l'équipe, en même temps que la négociation du contrat. ARGE n'utilise donc pas encore le logiciel. La montée en charge du CFO a été recalée en conséquence : premier paiement d'ARGE en février 2027. Résultat : il faut **4 030 € de trésorerie** avant que l'activité paie ses frais, et tu disposes de moins de 2 000 €. **Le contrat ARGE, avec un an payé d'avance, est donc la première tâche du plan.**

Il n'y a pas encore de `marketing.md` ni de `brand.md`. Ce plan s'appuie sur la prospection directe déjà prévue (e-mails personnalisés, téléphone, démonstration). `/founder-marketing` pourra ensuite écrire un calendrier plus complet.

### 1. Tester avant de dépenser

Les grosses dépenses de départ sont le juriste (800 €), le séquestre (300 €), la marque (230 €) et l'astreinte du support de secours. Avant de les engager, on vérifie sur de vrais installateurs ce que le panel simulé a dit.

#### Test 1 : 20 appels en novembre (coût : ton temps)
- **Quoi :** appeler 20 installateurs d'alarme et de vidéosurveillance proches des agences d'ARGE (Bourgogne, Grand Est, Hauts-de-France, Île-de-France). Leur présenter l'offre telle qu'elle est écrite dans [pitch.md](pitch.md), avec les vrais prix, et proposer une démonstration de 30 minutes sur leurs propres documents.
- **Ce qu'on ne dit pas :** que le contrat est prêt. On dit qu'il le sera pour le 11 janvier et on demande : « Si c'était prêt aujourd'hui, est-ce que vous signeriez l'essai de 60 jours ? »
- **Seuil de réussite, écrit avant de commencer : au moins 6 démonstrations obtenues sur 20 appels, et au moins 2 installateurs qui disent qu'ils signeraient l'essai.** Le panel prévoit 2 sur 20 (10 %).
- **Si on obtient 0 ou 1 oui à l'essai :** on fait confiance aux vrais acheteurs, pas au panel. On n'engage pas le juriste ni le séquestre. On note les objections mot pour mot, puis on retourne à `/founder-offer`. Le plus probable est la confiance : il faudra alors attendre qu'ARGE soit en usage et accepte d'être cité.
- **Si on obtient 2 oui ou plus :** on lance les dépenses de la semaine du 16 novembre.

#### Test 2 : le vrai lancement, du 11 janvier au 31 mars (le programme fondateurs lui-même)
- **Seuils de réussite :**
  - au moins **15 démonstrations** et **5 essais signés** au 31 mars ;
  - au moins **4 clients qui paient** au 30 juin, ce qui correspond à la montée en charge du CFO.
- **En dessous de 3 essais au 31 mars :** le plan du CFO ne tient pas (avec deux fois moins de clients, l'année 1 finit en perte de 1 225 €). On revoit l'offre ou le prix avant de prolonger.

### 2. Le compte à rebours

Les tâches marquées **⚠** sont sur le **chemin critique** : si elles glissent, le 11 janvier glisse, ou la première mise en service glisse. « Toi » = Justin.

| Semaine | Tâche | Qui | Pour le |
|---|---|---|---|
| **26 oct. – 1er nov.** | Copier la clé de signature Android (`%USERPROFILE%\.arge`) hors du PC, chiffrée (risque n° 6) | Toi | 27 oct. |
| | Liste de 60 installateurs cibles près des agences d'ARGE : nom du dirigeant, téléphone, taille, outil actuel | Toi | 1er nov. |
| | ⚠ Commencer **l'import de fichiers** (clients, sites, centrales, n° d'abonné, matériels depuis un tableur) | Toi | — |
| **2 – 8 nov.** | **Test 1** : 20 appels, prise de rendez-vous de démonstration | Toi | 8 nov. |
| | **[Expoprotection](https://www.expoprotection.com/), du 3 au 5 novembre, Paris**, en visiteur : au moins 15 contacts d'installateurs, au moins 4 démonstrations fixées (voir [marketing.md](marketing.md)). Ils comptent dans le test 1 | Toi | 5 nov. |
| | Demandes de devis : séquestre (APP, Logitas), assurance avec option cyber (2 ou 3 courtiers), juriste (2 devis) | Toi | 6 nov. |
| | Contacter 2 ou 3 développeurs indépendants pour l'astreinte de secours | Toi | 8 nov. |
| **9 – 15 nov.** | ⚠ **Présentation à l'équipe ARGE et négociation** : prix réduit, **un an payé d'avance**, **accord écrit pour être cité**, nombre de présentations à des confrères en contrepartie | Toi + direction ARGE | 15 nov. |
| | Démonstrations issues du test 1 | Toi | 15 nov. |
| | ⚠ Import de fichiers terminé et testé | Toi | 15 nov. |
| **16 – 22 nov.** | **Bilan du test 1 face au seuil. On continue ou pas ?** | Toi | 16 nov. |
| | Si on continue : commander le juriste (contrat d'abonnement, conditions générales, contrat de sous-traitance RGPD, clauses de support, réversibilité, séquestre) | Toi → juriste | 20 nov. |
| | ⚠ Commencer **l'export complet en un clic** | Toi | — |
| **23 – 29 nov.** | ⚠ **Contrat ARGE signé** et premier paiement annuel encaissé | ARGE | 27 nov. |
| | Choisir le développeur de secours ; contrat d'astreinte (début au 1er fondateur hors ARGE) | Toi + dév. | 29 nov. |
| | Déposer la marque Itinéos à l'INPI, classes 9 et 42 (230 €) | Toi | 29 nov. |
| **30 nov. – 6 déc.** | ⚠ Export complet terminé et testé | Toi | 6 déc. |
| | Modèles « sécurité » prêts : fiche d'intervention, consignes de télésurveillance, bons de sortie | Toi | 6 déc. |
| **7 – 13 déc.** | ⚠ Contrat de séquestre signé et premier dépôt du code (300 €) | Toi + APP ou Logitas | 11 déc. |
| | Assurance responsabilité civile pro avec option cyber souscrite | Toi | 11 déc. |
| | Compte GoCardless ouvert, mandat de prélèvement d'essai sur toi-même | Toi | 13 déc. |
| | Mise en service ARGE : préparation (routine R2, J − 10) | Toi + ARGE | 13 déc. |
| **14 – 20 déc.** | ⚠ Contrats finaux reçus du juriste | Juriste | 18 déc. |
| | Mise en service ARGE sur **une agence** (R2, J 0) | Toi | 17 déc. |
| | **Import testé chez un installateur autre qu'ARGE**, sur ses vrais fichiers (une condition du conseil) : prendre un « oui » du test 1 | Toi | 20 déc. |
| **21 déc. – 3 janv.** | Fêtes : support assuré pour ARGE (R1 chaque matin ouvré) | Toi | — |
| | Écrire la séquence d'e-mails, avec deux versions de la fiche tarifs (35 € et 39 €, voir [pricing.md](pricing.md)) | Toi | 3 janv. |
| | Vérifier la configuration e-mail de ton domaine (SPF, DKIM) pour que tes e-mails n'arrivent pas en indésirables | Toi | 3 janv. |
| | Liste finale de 50 prospects, avec nom et téléphone | Toi | 3 janv. |
| **4 – 10 janv.** | ARGE passe sur **ses 4 agences** | Toi + ARGE | 8 janv. |
| | **Répétition** : démonstration complète, contrat et mandat à 2 installateurs du test 1, comme si c'était pour de vrai | Toi | 8 janv. |
| | Revoir l'offre et ses garanties avec ce qui est vraiment signé : ne garder que ce qui est en place | Toi | 10 janv. |
| **Lundi 11 janv.** | **Lancement** | Toi | |

**Ce qui doit être vrai le 10 janvier au soir, sinon on décale :**
- le contrat ARGE est signé ;
- les contrats du juriste sont prêts ;
- le séquestre et le support de secours sont signés : ce sont deux garanties écrites dans l'offre, on ne promet pas ce qui n'existe pas ;
- l'import et l'export fonctionnent.

Si seul l'accord d'ARGE pour être cité manque, on lance quand même, sans citer ARGE.

### 3. Le jour du lancement : lundi 11 janvier 2027

| Heure | Ce qui se passe | Canal |
|---|---|---|
| 7 h 15 | Ouverture du matin (R1) : console de supervision, sauvegardes, mise à jour de la nuit | — |
| 7 h 30 | Support ouvert : les techniciens d'ARGE commencent | Téléphone |
| 8 h 30 | **Envoi des 10 premiers e-mails personnalisés** (sur 50). D'abord les installateurs qui ont dit oui au test 1 : « comme promis, c'est prêt » | E-mail |
| 9 h 30 – 12 h | **Appels** aux installateurs du test 1, pour fixer une date de démonstration ou d'essai | Téléphone |
| 12 h – 13 h 30 | Rappels du support (pause des techniciens) | Téléphone |
| 14 h | Annonce du programme : 5 places jusqu'au 31 mars. **ARGE n'y est cité que si son accord écrit est signé** | LinkedIn, e-mail aux contacts |
| 14 h 30 – 16 h 30 | Appels de relance aux prospects qui ont reçu l'e-mail le matin | Téléphone |
| 17 h – 18 h | Tableau de suivi : e-mails envoyés, réponses, démonstrations fixées. Préparer les 10 e-mails du lendemain | Tableur |

**L'offre d'ouverture**, telle qu'elle est écrite dans [pitch.md](pitch.md) :
- 60 jours d'essai sur une agence ;
- la reprise des données et la formation faites par toi ;
- la mise en service offerte ;
- le prix bloqué 24 mois ;
- 5 places jusqu'au 31 mars.

Rien de plus : pas de fausse remise, pas de faux compte à rebours.

**Si quelque chose casse le jour J** (registre des risques de [ops.md](ops.md)) :
- *Panne de serveur* → R4. On prévient ARGE dans l'heure, et les rendez-vous de démonstration passent sur le serveur de démonstration.
- *Un problème chez ARGE* → il passe avant la prospection : appel immédiat, contournement, puis correction.
- *Les e-mails reviennent ou arrivent en indésirables* → on arrête l'envoi, on vérifie SPF et DKIM, et on passe ces prospects au téléphone.
- *Un prospect veut signer tout de suite* → date de mise en service fixée tout de suite, 2 par mois au maximum.

### 4. Les 30 premiers jours (11 janvier – 10 février 2027)

#### Les chiffres à suivre chaque lundi

| Chiffre | Objectif sur 30 jours | Seuil d'alerte |
|---|---|---|
| E-mails envoyés | 50 | — |
| Appels passés | 80 (environ 20 par semaine) | — |
| Démonstrations faites | 8 | **moins de 3 à la fin de la semaine 2** |
| Essais signés | 2 | **0 après 10 démonstrations** |
| Mises en service planifiées | 2 par mois au maximum | 3 dans le même mois |
| Heures de support par semaine | moins de 8 h | **plus de 10 h** |
| Techniciens payés | 12 en février (ARGE) | ARGE ne paie pas en février |
| Trésorerie | au-dessus de 500 € | **sous 500 €** |

Repères du CFO : l'activité couvre ses frais à **17 techniciens payés**, et il en faut **116** pour te verser 2 500 € net.

#### Ce qu'on change si une alerte se déclenche
- **Moins de 3 démonstrations à la fin de la semaine 2** : le message ne passe pas. On appelle d'abord et on envoie l'e-mail ensuite. On raccourcit l'e-mail à trois lignes, avec une preuve (ARGE si l'accord est signé, sinon une capture de la fiche remplie).
- **Aucun essai après 10 démonstrations** : on reprend les objections notées mot pour mot. Si c'est la confiance, la priorité devient la référence ARGE. Si c'est le prix, on passe sur la fiche tarifs à 35 €. Puis retour à `/founder-offer` ou `/founder-pricing`.
- **3 mises en service dans le même mois** : la troisième passe au mois suivant, à une date écrite. On ne baisse pas la qualité de la mise en service.
- **Plus de 10 heures de support par semaine** : on arrête les nouvelles mises en service jusqu'à ce que la cause soit corrigée.
- **Trésorerie sous 500 €** : plus de déplacements, démonstrations et formation à distance. On relance ARGE si son paiement annuel n'est pas encore arrivé.

#### Les trois bilans

**Jour 7 (lundi 18 janvier).**
- Combien de réponses aux 50 e-mails, et lesquelles ?
- Quelle objection revient le plus ?
- Le support d'ARGE reste-t-il sous 8 heures par semaine ?

**Jour 14 (lundi 25 janvier).**
- Le seuil de 3 démonstrations est-il atteint ?
- Les installateurs du test 1 ont-ils tenu leur « oui » ?
- Le vrai taux d'essai est-il proche des 10 % du panel ? S'il est nettement plus bas, on fait confiance aux vrais acheteurs.

**Jour 30 (mercredi 10 février).**
- Combien d'essais signés, et à quelles dates de mise en service ?
- ARGE a-t-il payé, et a-t-il signé l'accord pour être cité ?
- La montée en charge du CFO (20 techniciens payés en avril, 28 en mai) tient-elle encore ? Si non, on relance `/founder-cfo` avec les vrais chiffres.
- On continue, on corrige ou on s'arrête ?

### La suite

`/founder-plan` rassemble le tout dans un plan d'affaires, avec un verdict calculé à partir des chiffres.

_The panel is simulated buyers and the numbers are projections from your inputs. Confirm demand with real customers and costs with real quotes before you spend. Not financial, legal or tax advice._
