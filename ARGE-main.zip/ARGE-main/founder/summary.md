**Verdict : Pas encore (« Not yet »).** Les chiffres tiennent, mais pas assez d'acheteurs disent oui. **Seuls 2 installateurs simulés sur 20 achètent avec l'offre actuelle (10 %)**, pour un seuil fixé à 25 %. Avec l'ancien pitch, aucun sur 20 n'achetait. Et les deux oui portent sur l'essai gratuit, pas encore sur l'abonnement.

**Ce qui doit changer :** la preuve, plus que l'offre.
- Le premier frein est la confiance (7 refus sur 20) : « une seule personne, aucun confrère à appeler ».
- Ce qui le lèvera : **ARGE en usage réel, avec son accord écrit pour être cité**, et un **support de secours** nommé dans le contrat.
- Ensuite, on remplace le panel simulé par de **vrais installateurs**. C'est le test 1 de [launch.md](launch.md) : 20 appels en novembre, réussi s'il donne au moins 6 démonstrations et 2 oui à l'essai.
- S'il échoue, on revient à `/founder-offer`.

**Ce que c'est.** Itinéos Sécurité est un logiciel de bureau et une appli terrain hors réseau, pour les installateurs d'alarme et de vidéosurveillance de 3 à 50 techniciens. Il reprend leurs propres fiches, consignes de télésurveillance et bons de sortie, et produit les factures Factur-X. C'est un abonnement par technicien : de 25 à 49 € HT par mois, 35 € en moyenne, sans engagement.

**Les trois chiffres du verdict** (estimations, mois 1 = novembre 2026) :
- **Ce qui reste par technicien** : 25,22 € sur 35 € (72 %) ;
- **Le seuil de rentabilité** : 17 techniciens payés par mois ;
- **L'année 1** : bénéfice d'exploitation de 2 483 € sur 10 290 € de chiffre d'affaires. Après les dépenses de départ, il reste −97 €.

Pour te verser 2 500 € net, il faut **116 techniciens payés**, vers **septembre 2028** au rythme prévu.

**Ce sur quoi le conseil et le panel sont d'accord.**
- Le produit colle au métier : le relevé des concurrents montre que personne n'offre à la fois les documents du métier, une appli hors réseau au centre du produit et un prix public.
- Le frein n° 1 est l'absence de preuve chez un vrai client.
- La mise en route dépend trop du fondateur.

**Là où ils divergent.** Le conseil imaginait une formule clé en main peut-être plus chère. Les acheteurs, eux, tirent le prix vers le bas : il commence à paraître cher vers 35 €.

**Le risque principal.** Trop peu de prospects. Avec deux fois moins de clients, l'année 1 finit en perte de 1 225 €. On compte les appels et les démonstrations chaque lundi, avec des seuils d'alerte ([launch.md](launch.md), § 4).

**Ce qu'il faut pour démarrer.**
- **4 030 € de trésorerie**, alors que tu disposes de moins de 2 000 €. L'écart est comblé par **un an d'avance payé par ARGE** (environ 3 600 €).
- L'import de fichiers et l'export complet, construits avant le 11 janvier 2027.

**À faire cette semaine.**
- Copier la clé de signature Android hors du PC.
- Dresser la liste des 60 installateurs à appeler.
- Préparer la négociation ARGE : prix réduit **contre** un an payé d'avance, l'accord écrit pour être cité et des présentations à des confrères.

*Le panel est fait d'acheteurs simulés, et les chiffres sont des projections. Seuls de vrais clients et de vrais devis les confirment. Ce n'est pas un conseil financier, juridique ou fiscal.*
