# Faire tourner Itinéos Sécurité au quotidien

Entrées : [idea.md](idea.md), [offer.md](offer.md), [numbers.json](numbers.json), [cfo.md](cfo.md), et ce qui existe déjà dans le logiciel ([DEPLOIEMENT.md](../DEPLOIEMENT.md), console de supervision, mises à jour la nuit, sauvegardes).

**Le constat principal.** Tout repose sur toi. Le conseil le disait (« une mise en route qui dépend du fondateur »), et le panel le confirme : 7 refus sur 20 viennent de la peur qu'une seule personne tienne le logiciel. Ce document organise donc ta semaine pour que ça tienne avec 5 fondateurs. Il indique aussi les trois choses à mettre en place pour ne plus être le seul point de passage : **l'import de fichiers**, **l'export complet en un clic** et **un support de secours nommé**.

## 1. Le cycle d'une journée

Les techniciens des clients commencent tôt : le support doit être ouvert avant eux. 👁 = ce que le client voit.

| Heure | Étape | 👁 |
|---|---|:-:|
| 7 h 15 | Console de supervision : tous les serveurs clients en ligne, sauvegardes de la nuit réussies, mise à jour de nuit passée | |
| 7 h 30 | Support ouvert (téléphone, e-mail). Les techniciens se connectent, synchronisent l'appli et partent sur les chantiers | 👁 |
| 8 h | Lecture du résumé e-mail de 8 h (pannes, bugs, mises à jour ratées). Tri des demandes de la veille | |
| 8 h 30 – 12 h | Selon le jour : démonstrations, mise en service chez un fondateur, ou prospection | 👁 |
| 12 h – 13 h 30 | Créneau de rappel support (heure de pause des techniciens) | 👁 |
| 13 h 30 – 17 h | Développement (corrections, import, export, prélèvement SEPA) ou suite de la mise en service | |
| 17 h – 18 h | Fin de tournée des techniciens : fiches signées, PDF envoyés, factures préparées au bureau du client. Réponse aux demandes du jour | 👁 |
| Nuit | Mise à jour automatique (si une version est prête) et sauvegarde | |

Le délai de support promis est de **4 heures ouvrées**. Avec ce cycle, une demande reçue le matin a une réponse avant 12 h 30, une demande de l'après-midi avant 17 h ou le lendemain à 8 h.

## 2. Les fournisseurs

| Besoin | Fournisseurs possibles | Prix public relevé | Ce qu'il faut savoir |
|---|---|---|---|
| Serveur en France | [OVHcloud VPS](https://www.ovhcloud.com/fr/vps/) (Gravelines, Roubaix, Strasbourg) · [Scaleway](https://www.scaleway.com/fr/tarifs/virtual-instances/) (Paris) · Infomaniak (Suisse, hors France) | OVH VPS-1 : environ 6,50 € par mois avant la hausse de 2026, [hausse annoncée](https://next.ink/225720/ovhcloud-augmente-fortement-le-prix-de-ses-vps-2026-et-ipv4/) · Scaleway PLAY2-PICO : environ 10 € par mois hors disque, [hausse au 1er juin 2026](https://www.scaleway.com/fr/blog/a-transparent-update-on-scaleway-pricing/) | Sans engagement, paiement mensuel par carte. Il faut **deux** machines : le serveur des clients et la console de supervision (5 à 10 € selon [son LISEZ-MOI](../deploy/supervision/LISEZ-MOI.md)), plus une copie des sauvegardes **hors du serveur** (stockage objet, quelques euros). Les 20 € par mois de numbers.json tiennent. |
| Prélèvement des abonnements | [GoCardless](https://gocardless.com/fr/tarifs/) · Stripe (prélèvement SEPA) · simple virement | GoCardless : **1 % + 0,20 € par prélèvement, plafonné à 2 €** en France ([page GoCardless](https://gocardless.com/fr-fr/solutions/en-savoir-plus-sepa)) ; rejet 7,50 € | Pour un client de 8 techniciens à 35 €, le prélèvement de 280 € coûte 2 €, soit **0,25 € par technicien** (au lieu des 0,38 € estimés). Tarif Stripe à vérifier sur son site. Le virement ne coûte rien, mais il faut relancer. |
| Dépôt du code source chez un tiers | [APP, Agence pour la protection des programmes](https://www.app.asso.fr/) · Logitas | **Pas de grille publique trouvée.** Ordre de grandeur donné par [un article d'octobre 2026](https://kolonell.com/fr/blog/sequestre-code-source-logiciel-metier-agence-cout-2026) : 300 à 700 € HT par an (APP), 400 à 900 € (Logitas) | **Devis à demander.** Il faut un contrat de séquestre à trois (toi, l'agence, le client) et une mise à jour du dépôt à chaque version importante. Les 40 € par mois de numbers.json (480 € par an) sont dans la fourchette. |
| Marque | [INPI](https://www.inpi.fr/la-marque/en-pratique-le-depot) | **190 € en ligne pour une classe, 40 € par classe en plus** (prix officiel) | Classes 9 (logiciel) et 42 (logiciel en ligne) : 230 €, confirmé. Renouvellement au bout de 10 ans. |
| Assurance responsabilité civile pro | Hiscox · Stello · un courtier (par exemple Coover) | Hiscox à partir d'environ 150 à 270 € par an, Stello à partir de 15 € par mois, selon [des comparatifs](https://lefreelance.fr/articles/assurance-rc-pro-freelance/) ([autre comparatif](https://independant.io/assurance-rc-pro-informatique/)) | Ces prix d'appel concernent un développeur indépendant. Un éditeur qui **héberge les données de ses clients** doit demander l'option cyber et la perte de données : **devis à demander**. Les 40 € par mois prévus laissent cette marge. |
| Envoi des e-mails (fiches PDF, mots de passe) | Brevo · Mailjet (hébergés en Europe, cités dans [DEPLOIEMENT.md](../DEPLOIEMENT.md)) | Brevo a une formule gratuite avec une limite d'envois par jour (à vérifier sur son site) | Suffisant au début. À surveiller au-delà de 10 clients : chaque fiche signée envoie un e-mail. |
| Plateforme agréée pour **tes propres** factures | Ta banque pro ou ton logiciel de comptabilité, s'il en propose une | Prix non trouvé | Tu dois **recevoir** des factures électroniques depuis le 1er septembre 2026 et en **émettre** à partir du 1er septembre 2027 (micro-entreprise comprise) ([calendrier](https://www.ag2rlamondiale.fr/groupe/magazines/expertises/reglementation/facturation-electronique-etes-vous-pret)). Tu peux facturer tes clients depuis Itinéos (Factur-X déjà en place), puis déposer sur la plateforme choisie. |
| Prise de main à distance | RustDesk (déjà intégré à la console de supervision) | Gratuit, installé sur ton serveur | Rien à acheter. |

## 3. Les personnes

**Aujourd'hui : toi seul.** Pas de salaire au départ (ta réponse), objectif de 2 500 € net. Il n'y a pas de paie à prévoir, donc pas de charges sociales d'employeur. En micro-entreprise, tes cotisations sont calculées sur le chiffre d'affaires et sont déjà dans les coûts par technicien.

**Le support de secours, à nommer avant d'envoyer l'offre.** C'est la demande n° 1 du panel. La solution la moins chère est un **développeur indépendant sous contrat d'astreinte légère**. Il connaît le code, a accès à la console et à la procédure de reprise, et prend le relais si tu es absent plus de 2 jours ouvrés. Il est nommé dans le contrat client. Proposition : un forfait de quelques heures par mois pour se tenir à jour, plus un tarif journalier en cas d'intervention. **J'ai estimé 150 € par mois** (environ 3 heures au tarif courant d'un indépendant, à négocier). Il est ajouté à numbers.json.

### Semaine type pendant le premier mois (novembre 2026 : ARGE, aucun fondateur payant)

| | Lundi | Mardi | Mercredi | Jeudi | Vendredi |
|---|---|---|---|---|---|
| Matin | Ouverture, puis prospection (10 appels) | Démonstrations | Mise en service ARGE / suivi | Démonstrations | Ouverture, puis prospection (10 appels) |
| Après-midi | Développement : **import de fichiers** | Développement | Développement : **export complet** | Relances après démonstration | Développement, mise à jour prête pour la nuit |

Environ 20 appels et 4 à 6 démonstrations par semaine. C'est le rythme nécessaire pour voir passer environ 50 prospects sérieux en 5 mois ([cfo-sources.md](cfo-sources.md)).

### Semaine type à plein régime (environ 110 techniciens, 14 à 15 clients)

| Tâche | Heures par semaine | Comment je l'ai estimé |
|---|---:|---|
| Support | 8 h | Environ 30 minutes par client et par semaine une fois installé (estimation, à mesurer) |
| Mises en service (1 nouveau client par mois, 1 à 3 jours chacun) | 4 à 6 h | D'après [offer.md](offer.md) |
| Prospection et démonstrations | 10 h | |
| Développement et mises à jour | 15 h | |
| Administration (facturation, URSSAF, comptabilité) | 2 h | |
| **Total** | **39 à 41 h** | Tenable seul, à condition que les mises en service ne se chevauchent pas |

**La limite réelle : 2 mises en service par mois au maximum.** C'est pour ça que le programme fondateurs est limité à 5 places jusqu'à fin mars : la limite est vraie.

## 4. Les routines

### R1. L'ouverture du matin (15 minutes, chaque jour ouvré)
1. Ouvrir la console de supervision. Chaque client doit être en vert.
2. Vérifier la sauvegarde de la nuit pour chaque client : date du jour, taille normale.
3. Vérifier la mise à jour de nuit : version attendue partout.
4. Lire le résumé e-mail de 8 h.
5. Trier les demandes : **bloquant** (un technicien ne peut pas travailler), **gênant**, **question**.
6. Si un client est en rouge, passer directement à R4.

### R2. La mise en service d'un fondateur (le cœur du service)
1. **J − 10** : visio de 30 minutes pour récupérer les fichiers du client : liste des clients et sites (export de son logiciel ou tableur), centrales et numéros d'abonné, modèles de fiches, consignes, bons de sortie, logo, mentions CNAPS, liste des techniciens et des agences.
2. **J − 7** : préparer la société dans Itinéos (agences, réglages de facturation : taux horaire et déplacement, sinon les factures sortent à 0 €), puis les modèles de documents à son logo.
3. **J − 5 à J − 1** : reprendre les données. *Aujourd'hui c'est à la main ; avec l'outil d'import, ce sera un fichier.* Faire vérifier 10 fiches clients par le client.
4. **J 0, matin (sur place)** : comptes des techniciens, installation de l'appli sur leurs téléphones, une intervention d'essai **dans une cave sans réseau**.
5. **J 0, après-midi** : demi-journée de formation des techniciens, puis une heure avec la personne du planning.
6. **J + 2** : appel au dirigeant. **J + 7** : appel aux techniciens. Noter ce qui bloque.
7. **J + 30** : bilan à mi-parcours. Combien de fiches faites dans Itinéos, et combien encore sur papier ?
8. **J + 50** : bilan de fin d'essai et décision du client. S'il reste : mandat de prélèvement, **accord écrit pour être cité**, retour écrit.
9. **J + 60** : premier prélèvement ; ou, si le client arrête, export complet de ses données (R6) et désactivation de la société.

### R3. Une demande au support (réponse sous 4 heures ouvrées)
1. Répondre tout de suite : « Bien reçu, je regarde, retour avant [heure] ».
2. Classer la demande : bloquant, gênant ou question.
3. Bloquant : prise en main à distance (RustDesk) ou appel au technicien sur le chantier. Contournement d'abord, correction ensuite.
4. Noter la demande et la solution dans le suivi (la console a une liste de bugs).
5. Si c'est un défaut du logiciel : correction, test, mise à jour de nuit, prévenir le client le lendemain matin.
6. Une **plainte** (pas un bug) : appeler le dirigeant le jour même, écouter jusqu'au bout, proposer une action datée, la confirmer par écrit.

### R4. Une panne de serveur
1. Prévenir les clients concernés dans l'heure (e-mail et SMS au dirigeant). L'appli terrain continue de marcher hors réseau, et les fiches remontent au retour du serveur.
2. Redémarrer, puis lire les journaux ([DEPLOIEMENT.md](../DEPLOIEMENT.md), « En cas de souci »).
3. Si la machine est perdue : nouveau serveur, restauration de la dernière sauvegarde copiée hors du serveur.
4. Écrire au client ce qui s'est passé et ce qui change pour que ça ne se reproduise pas.

### R5. La mise à jour (le soir)
1. Tous les tests passent (`npm test`, `npm run test:integration`).
2. Faire une sauvegarde manuelle avant la mise à jour.
3. Publier pour la nuit. Si l'appli terrain change : construire l'APK et vérifier qu'elle se met à jour sur un téléphone.
4. Le lendemain, R1 vérifie que tout le monde est passé.

### R6. Une demande d'export complet (promis sous 5 jours ouvrés)
1. Accuser réception et noter la date limite.
2. Exporter la base du client, ses PDF et ses photos. *Aujourd'hui, à la main ; à remplacer par un bouton « Exporter toutes mes données ».*
3. Remettre des fichiers lisibles sans Itinéos (CSV pour les tableaux, PDF pour les documents) et un mode d'emploi d'une page.
4. Garder la preuve d'envoi.

### R7. Le mois (le 1er de chaque mois)
1. Compter les techniciens actifs de chaque client le dernier jour du mois.
2. Faire les factures d'abonnement **depuis Itinéos** (Factur-X), puis lancer les prélèvements.
3. Suivre les rejets de prélèvement : appel au client sous 48 heures.
4. Déclarer le chiffre d'affaires à l'URSSAF (chaque mois ou chaque trimestre selon ton choix).
5. Tenir le livre des recettes.
6. Une fois par mois : **essai de restauration** d'une sauvegarde sur une machine de test.
7. Une fois par trimestre : mettre à jour le dépôt du code source chez le tiers.

## 5. Les outils (le minimum)

| Besoin | Outil | Prix | Pourquoi |
|---|---|---|---|
| Facturer tes clients | **Itinéos lui-même** | 0 € | Factur-X déjà en place, et c'est la meilleure démonstration |
| Prélever | GoCardless | 1 % + 0,20 €, plafonné à 2 € | Prélèvement automatique, mandats en ligne |
| Banque | Compte pro en ligne | Environ 10 € par mois (estimation) | Obligatoire en micro-entreprise au-delà de 10 000 € de chiffre deux années de suite ; pratique dès maintenant |
| Comptabilité | Livre des recettes + export comptable d'Itinéos | 0 € | Suffisant en micro-entreprise. Expert-comptable au passage en SASU |
| Support à distance | Console de supervision + RustDesk | Prix du serveur | Déjà construits |
| Prospects | Un tableur partagé (nom, date, étape, prochaine action) | 0 € | Inutile d'acheter un logiciel de suivi commercial pour 50 prospects |
| E-mails | Brevo | Formule gratuite au départ | Hébergé en Europe |

## 6. Démarches, contrats et assurances

Ces règles changent et dépendent de ta situation. **Confirme chaque point auprès de l'administration ou d'un professionnel.** Ce n'est pas un conseil juridique.

- [ ] **Immatriculation** en micro-entreprise (déjà faite) : vérifier sur le [guichet unique](https://formalites.entreprises.gouv.fr/) que l'activité déclarée correspond bien à « édition de logiciels / logiciel en ligne ». C'est ce qui décide entre BIC et BNC.
- [ ] **Taux de cotisations** : 25,6 % pour les BNC du régime général des indépendants en 2026 (la hausse prévue à 26,1 % a été plafonnée), plus environ 0,2 % pour la formation professionnelle ([source](https://www.lecoindesentrepreneurs.fr/taux-cotisations-sociales-2026-micro-entrepreneur/)). Environ 21,2 % si l'activité relève des BIC. À confirmer sur [autoentrepreneur.urssaf.fr](https://www.autoentrepreneur.urssaf.fr/).
- [ ] **TVA** : vérifier le seuil de franchise en base sur [impots.gouv.fr](https://www.impots.gouv.fr/). D'après [cfo.md](cfo.md), tu le dépasseras vers 90 techniciens payés. Prépare tes factures avec TVA à partir de là.
- [ ] **Conditions générales de vente entre professionnels** : mentions obligatoires (pénalités de retard, indemnité forfaitaire de 40 €), délai de support, réversibilité, séquestre. → juriste (800 € prévus).
- [ ] **RGPD : tu es sous-traitant des données de tes clients.** Il faut un contrat de sous-traitance avec chaque client (article 28), un registre des traitements et des mesures de sécurité écrites ([CNIL, guide du sous-traitant](https://www.cnil.fr/fr/reglement-europeen-sur-la-protection-des-donnees-un-guide-pour-accompagner-les-sous-traitants)). La **géolocalisation des véhicules** impose au client d'informer ses salariés ([CNIL, géolocalisation des véhicules](https://www.cnil.fr/fr/la-geolocalisation-des-vehicules-des-salaries)) : à rappeler dans la mise en service.
- [ ] **Facture électronique pour tes propres factures** : réception depuis le 1er septembre 2026, émission au 1er septembre 2027. Choisir une plateforme agréée avant l'été 2027.
- [ ] **Marque Itinéos** à l'INPI, classes 9 et 42 : 230 €.
- [ ] **Séquestre du code source** : contrat signé avant d'écrire la garantie dans l'offre.
- [ ] **Assurance responsabilité civile pro** avec option cyber et perte de données : devis.
- [ ] **CNAPS** : pas de démarche pour toi. L'autorisation CNAPS concerne tes clients, pas l'éditeur du logiciel.
- [ ] **Comptes développeur** : Apple (99 $ par an), Google Play (déjà ouvert pour l'appli Android).

## 7. Les risques

Probabilité et gravité : faible, moyenne ou forte.

| # | Ce qui peut arriver | Probabilité | Gravité | Ce qu'on fait |
|---|---|:-:|:-:|---|
| 1 | **Tu es malade ou indisponible une semaine** | Moyenne | Forte | Support de secours nommé dans le contrat, accès à la console, procédure écrite (R1, R3, R4). Message d'absence qui donne son numéro. |
| 2 | **Trop peu de prospects** : moins de 10 démonstrations par mois | Forte | Forte | C'est le premier facteur du CFO (volume divisé par 2 : bénéfice de l'année 1 de 2 483 € → perte de 1 225 €). Compter chaque semaine les appels et les démonstrations, et faire de la référence ARGE la priorité. |
| 3 | **Un fondateur arrête après l'essai** | Forte | Moyenne | Déjà prévu dans le plan (1 sur 5). Bilans à J + 7 et J + 30 pour voir l'abandon venir. Comprendre pourquoi, par écrit. |
| 4 | **Deux mises en service en même temps** | Moyenne | Moyenne | 2 par mois au maximum, dates fixées à la signature, 5 places en tout. |
| 5 | **Une mise à jour casse l'appli terrain** un matin | Moyenne | Forte | R5 : tests, sauvegarde avant, mise à jour la nuit, contrôle à 7 h 15. Garder la version précédente prête à être remise. |
| 6 | **Perte de la clé de signature de l'appli Android** (dossier `%USERPROFILE%\.arge`) | Faible | Forte | Sans elle, plus de mise à jour possible de l'appli installée. Copie chiffrée hors du PC, aujourd'hui. |
| 7 | **Panne du serveur ou perte de données** | Faible | Forte | Sauvegarde copiée hors du serveur, restauration essayée chaque mois (R7), R4. |
| 8 | **Faille de sécurité / fuite de données** | Faible | Forte | Double authentification sur la console, pare-feu (déjà documentés), assurance cyber, procédure de notification CNIL sous 72 heures. |
| 9 | **ARGE ne veut pas être cité** ou ne ramène personne | Moyenne | Forte | Mettre la contrepartie du prix réduit **par écrit** : accord pour être cité, nombre de présentations à des confrères. Sinon, prix normal. |
| 10 | **Le prélèvement SEPA des abonnements manque** et bloque les ventes | Forte | Moyenne | Il revient dans 5 réponses du panel. Décider d'une date et la tenir. En attendant, la formule Terrain qui se branche à côté de l'ERP. |

## 8. Les conditions du conseil

- **Une mise en route reproductible sans le fondateur** : **pas remplie.** Il manque trois choses, à mettre en tête de la feuille de route avant le 1er fondateur hors ARGE :
  1. **l'import de fichiers** (clients, sites, centrales, numéros d'abonné, matériels depuis un tableur) ;
  2. **l'export complet en un clic** (c'est aussi la garantie de l'offre) ;
  3. **des modèles « sécurité » prêts à l'emploi**, testés chez un installateur autre qu'ARGE.
- **La jointure avec le télésurveilleur** : **déclarée hors périmètre** pour l'instant, comme le dit l'offre. Les consignes sont produites en PDF ; l'envoi automatique est à explorer avec le partenaire d'ARGE.
- **Le vrai coût de la mise en service** (question posée au CFO) :
  - pour un fondateur : environ **250 € de frais** et 2 à 3 jours de ton temps ;
  - à 2 500 € net par mois, une journée de ton temps vaut au moins **190 € de chiffre d'affaires** (environ 3 400 € de chiffre par mois, divisés par 18 jours de travail, en comptant les cotisations) ;
  - une mise en service sur place coûte donc au moins 250 € + 3 × 190 € = **environ 820 €**. Les 300 € de la grille actuelle ne couvrent que les frais.
  - **Proposition** pour les clients hors programme fondateurs : **à distance 450 € HT** (import du fichier + 2 heures de formation en visio) ; **sur place 950 € HT** (1 jour sur place + préparation + frais). Dans les deux cas, déduite de la première année si le client reste, comme prévu dans [pricing.md](pricing.md).

## Changements apportés à numbers.json

| Ligne | Avant | Après | Pourquoi |
|---|---:|---:|---|
| Cotisations sociales | 9,21 € (26,3 %) | **9,03 € (25,8 %)** | Taux BNC 2026 plafonné à 25,6 %, plus 0,2 % de formation |
| Frais de prélèvement | 0,38 € | **0,25 €** | GoCardless plafonné à 2 € par prélèvement, soit 2 € / 8 techniciens |
| Support de secours (nouveau) | — | **150 € par mois** | Demande n° 1 du panel ; estimation à négocier |
| Plateforme agréée pour tes factures (nouveau) | — | **10 € par mois** | Estimation, prix non trouvé |

Le calcul du CFO a été relancé avec ces chiffres (voir [cfo.md](cfo.md)) :
- il reste 25,22 € par technicien (au lieu de 24,91 €) ;
- les coûts fixes passent à 411 € par mois et l'activité couvre ses frais à partir de 17 techniciens ;
- il faut **116 techniciens** pour te verser 2 500 € net ;
- il faut **3 208 €** de trésorerie au départ, et les dépenses de départ sont récupérées au mois 9.

*Depuis, la montée en charge a été recalée sur l'envoi de l'offre le 11 janvier 2027 ([launch.md](launch.md)). Il faut maintenant 4 030 € de trésorerie, et les dépenses de départ ne sont pas récupérées en fin d'année 1. Voir [cfo.md](cfo.md).*
