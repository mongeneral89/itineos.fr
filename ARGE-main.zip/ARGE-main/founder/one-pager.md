# Itinéos Sécurité, en une page

**Verdict : Not yet (pas encore).** Les chiffres tiennent, mais la demande n'est pas encore prouvée.

## Le problème
Les installateurs d'alarme et de vidéosurveillance remplissent encore des fiches papier carbonées, ressaisissent tout le vendredi et font leurs factures le samedi. Les logiciels spécialisés (CMII, Capasoft) ne publient pas leurs prix et traitent l'appli terrain comme un module annexe. Les logiciels généralistes (Praxedo, Organilog) ne connaissent pas leurs documents : consignes de télésurveillance, bons de sortie, mentions CNAPS.

## Le client
Le dirigeant ou le responsable d'exploitation d'une entreprise française d'installation et de maintenance d'alarme, de vidéoprotection et de contrôle d'accès, de 3 à 50 techniciens.

## L'offre et le prix
- **Ce que fait le logiciel :** les techniciens remplissent les fiches, consignes et bons de sortie **de leur entreprise** sur leur téléphone, même au sous-sol sans réseau. Le client signe sur place, et au bureau la facture Factur-X est prête le soir même.
- **Les prix :** abonnement par technicien et par mois, sans engagement. Terrain 25 € HT, Sécurité 39 € HT, Groupe 49 € HT, −15 % au-delà du 20e technicien.
- **Le programme « Installateurs fondateurs » (5 places, jusqu'au 31 mars 2027) :**
  - 60 jours d'essai sur une agence ;
  - reprise des données et formation faites sur place ;
  - mise en service offerte ;
  - prix bloqué 24 mois.
- **Les garanties écrites :** export complet de toutes les données, réponse du support sous 4 heures ouvrées, code source déposé chez un tiers et support de secours.

## Les chiffres
Estimations ; mois 1 = novembre 2026 ; montants HT.

| Chiffre clé | |
| --- | ---: |
| Prix moyen | 35,00 € par technicien payé et par mois |
| Ce qui reste par technicien | 25,22 € (72 %) |
| Marge au volume visé | 61 % |
| Seuil de rentabilité | 17 techniciens payés par mois |
| Bénéfice d'exploitation, année 1 | 2 483 € |
| Dépenses de départ | 2 580 € |
| Trésorerie nécessaire avant d'être rentable | 4 030 € |
| Dépenses de départ récupérées | pas dans l'année 1 |
| Techniciens payés pour verser 2 500 € net au fondateur | 116 (vers septembre 2028) |

## Les preuves, et ce qui manque encore
- **Panel d'acheteurs simulés.** Avec l'ancien pitch : 0 achat · 20 refus. Avec l'offre fondateurs : 2 achats · 18 refus (10 %), et ces deux oui portent sur l'essai seulement. Le seuil est de 25 %. Premier frein : la confiance (7 refus).
- **Concurrence.** Personne ne propose publiquement à la fois les documents du métier, une appli hors réseau au centre du produit et un prix public. Cette place est étroite et temporaire : un nouvel acteur, Le Terrain, vise la même.
- **Vrai test.** Aucun pour l'instant. Le logiciel fonctionne de bout en bout. ARGE (siège à Quetigny et agences à Nancy, Lille et Fontainebleau) a vu une présentation de la direction, et la négociation du contrat est en cours. ARGE ne peut pas être cité sans son accord écrit.

## À quoi sert l'argent (4 030 €)
- **2 580 € de dépenses de départ :**
  - juriste : 800 € ;
  - dépôt initial du code source : 300 € ;
  - marque Itinéos à l'INPI : 230 € ;
  - reprise et formation sur place chez 5 fondateurs : 1 250 €.
- **Le reste :** les mois de novembre 2026 à mai 2027, avant que les abonnements paient les frais fixes (411 € par mois).

## La demande
- **Au premier client (ARGE) :** un prix réduit **en échange** d'un an d'abonnement payé d'avance (environ 3 600 €), d'un accord écrit pour être cité et de présentations à des confrères installateurs.
- **À un partenaire ou un financeur :** rien avant le test de novembre. Il s'agit de 20 appels à de vrais installateurs. Il est réussi s'il donne au moins 6 démonstrations et 2 oui à l'essai.

*Le panel est fait d'acheteurs simulés, et les chiffres sont des projections. Seuls de vrais clients et de vrais devis les confirment. Ce n'est pas un conseil financier, juridique ou fiscal.*
