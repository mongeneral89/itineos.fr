# Le lancement de l'offre « Installateurs fondateurs »

**Envoi aux premiers prospects : lundi 11 janvier 2027** (ton choix). Fin du programme fondateurs : 31 mars 2027.
Entrées : [offer.md](offer.md), [pitch.md](pitch.md), [cfo.md](cfo.md), [ops.md](ops.md), [panel-v2/results.md](panel-v2/results.md).

**Où en est ARGE (ta réponse du 23/10/2026).** La direction a vu une première présentation. La deuxième est prévue avec l'équipe, en même temps que la négociation du contrat. ARGE n'utilise donc pas encore le logiciel. La montée en charge du CFO a été recalée en conséquence : premier paiement d'ARGE en février 2027. Résultat : il faut **4 030 € de trésorerie** avant que l'activité paie ses frais, et tu disposes de moins de 2 000 €. **Le contrat ARGE, avec un an payé d'avance, est donc la première tâche du plan.**

Il n'y a pas encore de `marketing.md` ni de `brand.md`. Ce plan s'appuie sur la prospection directe déjà prévue (e-mails personnalisés, téléphone, démonstration). `/founder-marketing` pourra ensuite écrire un calendrier plus complet.

## 1. Tester avant de dépenser

Les grosses dépenses de départ sont le juriste (800 €), le séquestre (300 €), la marque (230 €) et l'astreinte du support de secours. Avant de les engager, on vérifie sur de vrais installateurs ce que le panel simulé a dit.

### Test 1 : 20 appels en novembre (coût : ton temps)
- **Quoi :** appeler 20 installateurs d'alarme et de vidéosurveillance proches des agences d'ARGE (Bourgogne, Grand Est, Hauts-de-France, Île-de-France). Leur présenter l'offre telle qu'elle est écrite dans [pitch.md](pitch.md), avec les vrais prix, et proposer une démonstration de 30 minutes sur leurs propres documents.
- **Ce qu'on ne dit pas :** que le contrat est prêt. On dit qu'il le sera pour le 11 janvier et on demande : « Si c'était prêt aujourd'hui, est-ce que vous signeriez l'essai de 60 jours ? »
- **Seuil de réussite, écrit avant de commencer : au moins 6 démonstrations obtenues sur 20 appels, et au moins 2 installateurs qui disent qu'ils signeraient l'essai.** Le panel prévoit 2 sur 20 (10 %).
- **Si on obtient 0 ou 1 oui à l'essai :** on fait confiance aux vrais acheteurs, pas au panel. On n'engage pas le juriste ni le séquestre. On note les objections mot pour mot, puis on retourne à `/founder-offer`. Le plus probable est la confiance : il faudra alors attendre qu'ARGE soit en usage et accepte d'être cité.
- **Si on obtient 2 oui ou plus :** on lance les dépenses de la semaine du 16 novembre.

### Test 2 : le vrai lancement, du 11 janvier au 31 mars (le programme fondateurs lui-même)
- **Seuils de réussite :**
  - au moins **15 démonstrations** et **5 essais signés** au 31 mars ;
  - au moins **4 clients qui paient** au 30 juin, ce qui correspond à la montée en charge du CFO.
- **En dessous de 3 essais au 31 mars :** le plan du CFO ne tient pas (avec deux fois moins de clients, l'année 1 finit en perte de 1 225 €). On revoit l'offre ou le prix avant de prolonger.

## 2. Le compte à rebours

Les tâches marquées **⚠** sont sur le **chemin critique** : si elles glissent, le 11 janvier glisse, ou la première mise en service glisse. « Toi » = Justin.

| Semaine | Tâche | Qui | Pour le |
|---|---|---|---|
| **26 oct. – 1er nov.** | Copier la clé de signature Android (`%USERPROFILE%\.arge`) hors du PC, chiffrée (risque n° 6) | Toi | 27 oct. |
| | Liste de 60 installateurs cibles près des agences d'ARGE : nom du dirigeant, téléphone, taille, outil actuel | Toi | 1er nov. |
| | ⚠ Commencer **l'import de fichiers** (clients, sites, centrales, n° d'abonné, matériels depuis un tableur) | Toi | — |
| **2 – 8 nov.** | **Test 1** : 20 appels, prise de rendez-vous de démonstration | Toi | 8 nov. |
| | **[Expoprotection](https://www.expoprotection.com/), du 3 au 5 novembre, Paris**, en visiteur : au moins 15 contacts d'installateurs, au moins 4 démonstrations fixées (voir [marketing.md](marketing.md)). Ils comptent dans le test 1 | Toi | 5 nov. |
| | Demandes de devis : séquestre (APP, Logitas), assurance avec option cyber (2 ou 3 courtiers), juriste (2 devis) | Toi | 6 nov. |
| | Contacter 2 ou 3 développeurs indépendants pour l'astreinte de secours | Toi | 8 nov. |
| **9 – 15 nov.** | ⚠ **Présentation à l'équipe ARGE et négociation** : prix réduit, **un an payé d'avance**, **accord écrit pour être cité**, nombre de présentations à des confrères en contrepartie | Toi + direction ARGE | 15 nov. |
| | Démonstrations issues du test 1 | Toi | 15 nov. |
| | ⚠ Import de fichiers terminé et testé | Toi | 15 nov. |
| **16 – 22 nov.** | **Bilan du test 1 face au seuil. On continue ou pas ?** | Toi | 16 nov. |
| | Si on continue : commander le juriste (contrat d'abonnement, conditions générales, contrat de sous-traitance RGPD, clauses de support, réversibilité, séquestre) | Toi → juriste | 20 nov. |
| | ⚠ Commencer **l'export complet en un clic** | Toi | — |
| **23 – 29 nov.** | ⚠ **Contrat ARGE signé** et premier paiement annuel encaissé | ARGE | 27 nov. |
| | Choisir le développeur de secours ; contrat d'astreinte (début au 1er fondateur hors ARGE) | Toi + dév. | 29 nov. |
| | Déposer la marque Itinéos à l'INPI, classes 9 et 42 (230 €) | Toi | 29 nov. |
| **30 nov. – 6 déc.** | ⚠ Export complet terminé et testé | Toi | 6 déc. |
| | Modèles « sécurité » prêts : fiche d'intervention, consignes de télésurveillance, bons de sortie | Toi | 6 déc. |
| **7 – 13 déc.** | ⚠ Contrat de séquestre signé et premier dépôt du code (300 €) | Toi + APP ou Logitas | 11 déc. |
| | Assurance responsabilité civile pro avec option cyber souscrite | Toi | 11 déc. |
| | Compte GoCardless ouvert, mandat de prélèvement d'essai sur toi-même | Toi | 13 déc. |
| | Mise en service ARGE : préparation (routine R2, J − 10) | Toi + ARGE | 13 déc. |
| **14 – 20 déc.** | ⚠ Contrats finaux reçus du juriste | Juriste | 18 déc. |
| | Mise en service ARGE sur **une agence** (R2, J 0) | Toi | 17 déc. |
| | **Import testé chez un installateur autre qu'ARGE**, sur ses vrais fichiers (une condition du conseil) : prendre un « oui » du test 1 | Toi | 20 déc. |
| **21 déc. – 3 janv.** | Fêtes : support assuré pour ARGE (R1 chaque matin ouvré) | Toi | — |
| | Écrire la séquence d'e-mails, avec deux versions de la fiche tarifs (35 € et 39 €, voir [pricing.md](pricing.md)) | Toi | 3 janv. |
| | Vérifier la configuration e-mail de ton domaine (SPF, DKIM) pour que tes e-mails n'arrivent pas en indésirables | Toi | 3 janv. |
| | Liste finale de 50 prospects, avec nom et téléphone | Toi | 3 janv. |
| **4 – 10 janv.** | ARGE passe sur **ses 4 agences** | Toi + ARGE | 8 janv. |
| | **Répétition** : démonstration complète, contrat et mandat à 2 installateurs du test 1, comme si c'était pour de vrai | Toi | 8 janv. |
| | Revoir l'offre et ses garanties avec ce qui est vraiment signé : ne garder que ce qui est en place | Toi | 10 janv. |
| **Lundi 11 janv.** | **Lancement** | Toi | |

**Ce qui doit être vrai le 10 janvier au soir, sinon on décale :**
- le contrat ARGE est signé ;
- les contrats du juriste sont prêts ;
- le séquestre et le support de secours sont signés : ce sont deux garanties écrites dans l'offre, on ne promet pas ce qui n'existe pas ;
- l'import et l'export fonctionnent.

Si seul l'accord d'ARGE pour être cité manque, on lance quand même, sans citer ARGE.

## 3. Le jour du lancement : lundi 11 janvier 2027

| Heure | Ce qui se passe | Canal |
|---|---|---|
| 7 h 15 | Ouverture du matin (R1) : console de supervision, sauvegardes, mise à jour de la nuit | — |
| 7 h 30 | Support ouvert : les techniciens d'ARGE commencent | Téléphone |
| 8 h 30 | **Envoi des 10 premiers e-mails personnalisés** (sur 50). D'abord les installateurs qui ont dit oui au test 1 : « comme promis, c'est prêt » | E-mail |
| 9 h 30 – 12 h | **Appels** aux installateurs du test 1, pour fixer une date de démonstration ou d'essai | Téléphone |
| 12 h – 13 h 30 | Rappels du support (pause des techniciens) | Téléphone |
| 14 h | Annonce du programme : 5 places jusqu'au 31 mars. **ARGE n'y est cité que si son accord écrit est signé** | LinkedIn, e-mail aux contacts |
| 14 h 30 – 16 h 30 | Appels de relance aux prospects qui ont reçu l'e-mail le matin | Téléphone |
| 17 h – 18 h | Tableau de suivi : e-mails envoyés, réponses, démonstrations fixées. Préparer les 10 e-mails du lendemain | Tableur |

**L'offre d'ouverture**, telle qu'elle est écrite dans [pitch.md](pitch.md) :
- 60 jours d'essai sur une agence ;
- la reprise des données et la formation faites par toi ;
- la mise en service offerte ;
- le prix bloqué 24 mois ;
- 5 places jusqu'au 31 mars.

Rien de plus : pas de fausse remise, pas de faux compte à rebours.

**Si quelque chose casse le jour J** (registre des risques de [ops.md](ops.md)) :
- *Panne de serveur* → R4. On prévient ARGE dans l'heure, et les rendez-vous de démonstration passent sur le serveur de démonstration.
- *Un problème chez ARGE* → il passe avant la prospection : appel immédiat, contournement, puis correction.
- *Les e-mails reviennent ou arrivent en indésirables* → on arrête l'envoi, on vérifie SPF et DKIM, et on passe ces prospects au téléphone.
- *Un prospect veut signer tout de suite* → date de mise en service fixée tout de suite, 2 par mois au maximum.

## 4. Les 30 premiers jours (11 janvier – 10 février 2027)

### Les chiffres à suivre chaque lundi

| Chiffre | Objectif sur 30 jours | Seuil d'alerte |
|---|---|---|
| E-mails envoyés | 50 | — |
| Appels passés | 80 (environ 20 par semaine) | — |
| Démonstrations faites | 8 | **moins de 3 à la fin de la semaine 2** |
| Essais signés | 2 | **0 après 10 démonstrations** |
| Mises en service planifiées | 2 par mois au maximum | 3 dans le même mois |
| Heures de support par semaine | moins de 8 h | **plus de 10 h** |
| Techniciens payés | 12 en février (ARGE) | ARGE ne paie pas en février |
| Trésorerie | au-dessus de 500 € | **sous 500 €** |

Repères du CFO : l'activité couvre ses frais à **17 techniciens payés**, et il en faut **116** pour te verser 2 500 € net.

### Ce qu'on change si une alerte se déclenche
- **Moins de 3 démonstrations à la fin de la semaine 2** : le message ne passe pas. On appelle d'abord et on envoie l'e-mail ensuite. On raccourcit l'e-mail à trois lignes, avec une preuve (ARGE si l'accord est signé, sinon une capture de la fiche remplie).
- **Aucun essai après 10 démonstrations** : on reprend les objections notées mot pour mot. Si c'est la confiance, la priorité devient la référence ARGE. Si c'est le prix, on passe sur la fiche tarifs à 35 €. Puis retour à `/founder-offer` ou `/founder-pricing`.
- **3 mises en service dans le même mois** : la troisième passe au mois suivant, à une date écrite. On ne baisse pas la qualité de la mise en service.
- **Plus de 10 heures de support par semaine** : on arrête les nouvelles mises en service jusqu'à ce que la cause soit corrigée.
- **Trésorerie sous 500 €** : plus de déplacements, démonstrations et formation à distance. On relance ARGE si son paiement annuel n'est pas encore arrivé.

### Les trois bilans

**Jour 7 (lundi 18 janvier).**
- Combien de réponses aux 50 e-mails, et lesquelles ?
- Quelle objection revient le plus ?
- Le support d'ARGE reste-t-il sous 8 heures par semaine ?

**Jour 14 (lundi 25 janvier).**
- Le seuil de 3 démonstrations est-il atteint ?
- Les installateurs du test 1 ont-ils tenu leur « oui » ?
- Le vrai taux d'essai est-il proche des 10 % du panel ? S'il est nettement plus bas, on fait confiance aux vrais acheteurs.

**Jour 30 (mercredi 10 février).**
- Combien d'essais signés, et à quelles dates de mise en service ?
- ARGE a-t-il payé, et a-t-il signé l'accord pour être cité ?
- La montée en charge du CFO (20 techniciens payés en avril, 28 en mai) tient-elle encore ? Si non, on relance `/founder-cfo` avec les vrais chiffres.
- On continue, on corrige ou on s'arrête ?

## La suite

`/founder-plan` rassemble le tout dans un plan d'affaires, avec un verdict calculé à partir des chiffres.
