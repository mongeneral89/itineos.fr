# La marque : Itinéos pour les installateurs d'alarme et de vidéosurveillance

Sources : [marketing.md](marketing.md) (positionnement A : l'installateur qui grandit), [competitors.md](competitors.md), [panel-v2/results.md](panel-v2/results.md), [pitch.md](pitch.md). Ce qui existe déjà : le nom **Itinéos** (choisi et vérifié par toi le 22/10/2026), le logo (commit 01c23ea), et les couleurs et polices du logiciel (`apps/web/brand/`, `apps/web/src/styles.css`).

**Ce que ce document ne refait pas.** Le nom de l'entreprise et du logiciel, **Itinéos**, est décidé, et le logo existe : version sur fond noir uniquement, à ta demande. On ne propose donc pas de nouveau nom ni de nouveau logo. La seule question de nom ouverte est celle de **l'édition** vendue aux installateurs, aujourd'hui appelée « Itinéos Sécurité » (nom de travail).

## 1. Le nom de l'édition

**Le problème du nom de travail.** Itinéos a déjà une édition pour la **sécurité privée** (Vigie : gardiennage, agents). Dans le métier, « sécurité » désigne souvent ces sociétés-là, que le CNAPS encadre aussi. Un installateur d'alarme qui lit « Itinéos Sécurité » peut croire que c'est un logiciel pour agents de sécurité. Et l'ARGE tourne aujourd'hui sur l'édition TECH, pas sur Vigie.

### Dix pistes

| # | Nom | Style | Ce qu'il dit | À l'oral | Sur l'icône ou une plaquette | Risque |
|---|---|---|---|---|---|---|
| 1 | **Itinéos Sécurité** | Descriptif | Le domaine, en général | Clair | Bien | Confusion avec la sécurité privée (Vigie, gardiennage) |
| 2 | **Itinéos Sûreté** | Descriptif, mot du métier | La protection contre la malveillance : alarme, vidéo, accès | « sû-re-té » : un peu soutenu | Court, lisible | Moins parlant pour un petit installateur qui dit « alarme » |
| 3 | **Itinéos Alarme** | Descriptif étroit | Le cœur du métier | Très clair | Court | Laisse de côté la vidéo et le contrôle d'accès |
| 4 | **Itinéos Installateur** | Descriptif (l'acheteur) | « C'est pour moi » | Clair | Long sur une icône | Les électriciens et plombiers sont aussi des installateurs |
| 5 | **Itinéos Sécurité électronique** | Descriptif complet | Le nom exact de la filière | Long | Trop long | Lourd au quotidien |
| 6 | **Itinéos SE** | Sigle | Sécurité électronique, pour les initiés | « S-E » : sec | Très court | Ne dit rien à qui ne connaît pas le sigle |
| 7 | **Itinéos Centrale** | Évocateur | La centrale d'alarme, objet du métier | Facile | Bien | Confusion avec « centrale de télésurveillance » (le télésurveilleur) |
| 8 | **Itinéos Veille** | Évocateur | Surveiller, protéger | Doux | Bien | Trop proche de Vigie, l'autre édition |
| 9 | **Itinéos Pose & Maintenance** | Descriptif (les tâches) | Ce que font les techniciens | Long | Mauvais | Vrai pour tous les métiers |
| 10 | **Itinéos**, sans suffixe, + une phrase descriptive | Une seule marque | « Le logiciel de terrain des installateurs d'alarme et de vidéosurveillance » | Le plus simple | Le logo existant suffit | La phrase doit toujours accompagner le nom |

### Les trois retenues

1. **Itinéos, sans suffixe, avec la phrase descriptive (recommandé).**
   - Une seule marque à faire connaître, un seul dépôt (« Itinéos », déjà prévu à l'INPI), le logo tel quel.
   - Pour le client, il n'existe qu'un produit : les autres éditions ne sont jamais montrées aux installateurs. Le nom d'édition reste donc un nom **interne**.
   - La phrase porte le métier : *« Itinéos, le logiciel de terrain des installateurs d'alarme et de vidéosurveillance. »*
2. **Itinéos Sûreté** : si tu tiens à un suffixe. C'est le mot exact de la profession pour la malveillance, et il évite la confusion avec la sécurité privée.
3. **Itinéos Sécurité** : seulement si les installateurs eux-mêmes le préfèrent. À tester au téléphone pendant le test des 20 appels : « Vous diriez plutôt sécurité ou sûreté ? »

### Les vérifications à finir toi-même

- **La marque** (Itinéos, en classes 9 et 42, déjà prévue dans [ops.md](ops.md)) : base des marques de l'[INPI](https://data.inpi.fr/), et [TMview](https://www.tmdn.org/tmview/) pour l'Union européenne. Une simple phrase descriptive comme « pour les installateurs d'alarme » ne se dépose pas. Si tu choisis un suffixe (« Sûreté »), vérifie que « Itinéos Sûreté » ne crée pas de conflit dans les mêmes classes. Je ne peux faire que des recherches publiques : seul un conseil en propriété industrielle confirme, et rien n'est protégé tant que le dépôt n'est pas fait. Ce n'est pas un conseil juridique.
- **Les domaines (vérifiés le 23/10/2026)** :
  - **itineos.fr est à toi** (confirmé le 23/10/2026). C'est l'adresse du site et des e-mails.
  - **itineos.com** a été enregistré à la même minute (23/10/2026, 13 h 50), chez le même hébergeur (IONOS). Il est sans doute dans ton compte IONOS : à vérifier. S'il y est, fais-le rediriger vers itineos.fr.
  - itineos.app et itineos-securite.fr sont libres à ce jour. Inutile de les prendre.
- **Les comptes sur les réseaux** : je n'ai pas pu les vérifier. Ouvre ces adresses une par une : linkedin.com/company/itineos (la priorité, c'est le canal choisi), youtube.com/@itineos (vidéos de démonstration), instagram.com/itineos et x.com/itineos (seulement pour réserver le nom : ce ne sont pas des canaux prévus).
- **Pas de confusion avec un concurrent** : aucun nom du relevé n'est proche (Le Terrain, Sustencio, CMII W'IPSOS, Capasoft Kéops, Praxedo, Infocob, Organilog, ArtisanSmart, Kizeo Forms).

## 2. La promesse et la voix

**La promesse (ce sur quoi le client peut compter, chaque jour) :**
> Ce que vos techniciens remplissent sur le terrain, même sans réseau, arrive au bureau le soir même, sur vos propres documents.

**Trois signatures possibles :**
1. **« Du terrain à la facture, le soir même. »** *(recommandée : c'est le résultat qui fait gagner les samedis, cité par les deux oui du panel)*
2. « Vos fiches. Votre métier. Même au sous-sol. »
3. « Le logiciel de terrain des installateurs d'alarme. »

**La voix, en trois mots :**

| Mot | À faire | À éviter |
|---|---|---|
| **Concret** | Parler de la cave sans réseau, de la centrale, du numéro d'abonné, du bon de sortie | « Solution innovante », « transformation digitale », « IA » (c'est l'argument de Le Terrain) |
| **Franc** | Dire ce qui n'existe pas encore (le prélèvement SEPA) et donner une date seulement si elle est tenue | Promettre « bientôt » sans date, laisser croire qu'il y a déjà des clients référents |
| **Proche** | Écrire « je » : le créateur parle, avec son nom et son numéro | Le « nous » d'une grande entreprise qui n'existe pas. Le panel l'a montré : la confiance passe par la personne et par des garanties écrites, pas par une fausse taille |

**Avant / après, sur une phrase de [pitch.md](pitch.md) :**
- *Avant :* « Ce que ça fait : planning par agence (multi-agences inclus), appli du technicien qui marche sans réseau, fiche déjà remplie (site, centrale, n° de série, n° d'abonné)… »
- *Après :* « Votre technicien ouvre la fiche au sous-sol, sans réseau : le site, la centrale et le numéro d'abonné sont déjà remplis. Le client signe, le PDF part tout seul, et le soir la facture est prête. »

## 3. L'identité visuelle

Tout existe déjà dans le logiciel. On l'écrit ici pour que les e-mails, la fiche A4, LinkedIn et le futur site restent cohérents.

### Les couleurs

| Couleur | Code | À quoi elle sert |
|---|---|---|
| **Encre** | `#14181F` | Fond du logo (toujours sur noir, à ta demande), texte principal |
| **Papier** | `#F4F2EE` | Fond des pages et des documents ; texte et lettres du logo sur l'encre |
| **Orange signal** | `#F97316` | Le repère et le « é » du logo, **uniquement sur fond encre** |
| **Orange texte** | `#C2410C` | Liens et boutons sur fond clair (déjà `--accent` dans le logiciel) |

**Le contraste (calculé avec la formule WCAG) :**
- papier sur encre : **15,9:1**, excellent ;
- orange signal sur encre : **6,35:1**, conforme AA ;
- orange texte sur papier : **4,63:1**, conforme AA pour le texte courant ;
- texte blanc sur un bouton orange texte : **5,18:1**, conforme AA.
- **À ne jamais faire :**
  - du texte blanc sur l'orange signal : 2,8:1, échoue ;
  - de l'orange signal sur papier : 2,51:1, échoue.

  C'est pour ça que le logiciel utilise déjà l'orange foncé `#C2410C` pour ses boutons.

### Les polices
- **Titres : Archivo**. **Texte : IBM Plex Sans.**
- Les deux sont déjà utilisées dans le logiciel et sont sous licence libre SIL Open Font License, téléchargeables sur [Google Fonts](https://fonts.google.com/). Tu peux les utiliser partout : site, PDF, fiche A4, vidéos.

### Le logo : ce qu'il doit tenir
- Le logo actuel (écran de bureau → route en pointillés → repère orange avec une coche ; « itinéos » avec le « é » orange) raconte déjà la promesse : du bureau au terrain, et c'est fait. **On n'y touche pas.**
- **À vérifier, à 32 pixels** (icône de l'appli, onglet du navigateur) : les pointillés de la route risquent de disparaître. L'icône `apps/web/brand/icon.svg` existe ; si elle devient illisible à cette taille, garder seulement le repère orange avec sa coche sur fond encre.
- **Pour l'édition installateurs :** pas de logo à part. On met le logo, puis la phrase descriptive en dessous, en IBM Plex Sans, couleur papier sur encre.
- **À éviter :** un bouclier, un cadenas ou un œil. Ce sont les images de tous les acteurs de la sécurité, et elles rapprocheraient Itinéos de la sécurité privée.

## 4. Les cinq premiers contacts avec le client

1. **L'e-mail de prospection (E1, [marketing.md](marketing.md)).** C'est la vitrine. Trois lignes, en « je ». Une capture de la fiche remplie. Ta signature : nom, « créateur d'Itinéos », téléphone portable, itineos.fr. Pas de logo en grand : un e-mail de personne à personne passe mieux.
2. **La page d'accueil itineos.fr** (à créer, une seule page) :
   - la signature en titre ;
   - la vidéo de 30 secondes au sous-sol ;
   - trois points : vos documents, sans réseau, facture le soir même ;
   - l'offre fondateurs avec le nombre **réel** de places restantes ;
   - les prix publics ;
   - les garanties écrites ;
   - un bouton « Une démonstration de 30 minutes sur vos documents » ;
   - ta photo, ton nom et ton téléphone.

   Pas de logos de clients tant qu'aucun n'a donné son accord écrit.
3. **Les documents vus par les clients de l'installateur** (le « paquet ») : les fiches signées et les PDF portent **le logo et les mentions de l'installateur**, pas ceux d'Itinéos. Une mention discrète « Créé avec Itinéos » en pied de page est possible, **désactivable** par l'installateur, et à lui demander.
4. **La confirmation après la signature de l'essai** : un e-mail le jour même, avec la date de mise en service, la liste de ce qu'il faut préparer pour J − 10 (routine R2 de [ops.md](ops.md)), ton numéro et le rappel des garanties.
5. **La réponse à la première plainte** (routine R3, ton franc et proche) :
   > « Bonjour [prénom], merci de me l'avoir dit tout de suite. Je comprends : [ce qui s'est passé, avec ses mots]. Voici ce que je fais : [action] d'ici [date et heure]. Je vous rappelle à [heure] pour vérifier avec vous. — Justin, [téléphone] »

*Recherches publiques seulement. Rien n'est déposé ni réservé tant que tu ne l'as pas fait toi-même. Ce n'est pas un conseil juridique sur les marques.*
