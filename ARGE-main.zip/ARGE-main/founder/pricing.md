# Prix : Itinéos pour installateurs d'alarme et de vidéosurveillance

Sources : [pricing-curve.md](pricing-curve.md) (20 acheteurs simulés), [competitors.md](competitors.md) (prix publics relevés le 23/10/2026). Tous les prix sont en € HT par technicien de terrain et par mois.

## Ce que disent les trois sources

**Les acheteurs (simulés, à confirmer).** Plage acceptable : **15 € à 55 €**. Point d'équilibre « bonne affaire = cher » (IPP) : **30 €**. Médianes : bonne affaire 25 €, devient cher 40 €, trop cher 60 €.
→ Ta formule Pro à 45 € dépasse déjà le seuil où la plupart disent « ça devient cher ». La formule Entreprise à 65 € est au-delà de la limite (55 €).

**Les concurrents.** Médiane des offres publiées : **35 €** (Praxedo Basic, Organilog Business). Praxedo va de 35 à 129 € avec au moins 5 utilisateurs. Les ERP spécialisés (CMII, Capasoft) ne publient pas leurs prix.

**Ce que l'entreprise doit gagner.** **Inconnu pour l'instant** : il n'y a pas encore de `founder/numbers.json` (coût d'hébergement par client, temps de support, revenu dont tu as besoin). Je n'ai donc **pas** calculé de marge. Le directeur financier (`/founder-cfo`) doit vérifier la grille ci-dessous avant tout envoi.

**Le panel montre aussi que le montant n'est pas le premier frein.** Seuls 2 acheteurs sur 20 refusent pour le prix. En revanche, **l'engagement de 12 mois apparaît dans 12 réponses sur 20**, et le passage obligé par la formule la plus chère pour avoir le multi-agences gêne les 4 acheteurs multi-agences.

## 1. Le prix recommandé : 39 € pour la formule principale

La formule que la plupart des installateurs doivent prendre (devis, contrats, factures) passe de 45 € à **39 €**, **sans engagement**.

- Elle reste sous le seuil « ça devient cher » (40 €) et au-dessus de la médiane des concurrents (35 €), ce qui est justifié par les documents propres au métier.
- Un installateur de 10 techniciens paie 390 €/mois, contre 450 € aujourd'hui.
- Cette baisse n'a de sens que si **la facturation des abonnements de télésurveillance** fait partie de la formule (voir plus bas). Sans cela, l'acheteur qui a déjà un ERP ne gagne rien, quel que soit le prix.

## 2. La grille proposée

| Formule | Prix | Pour qui | Contenu |
|---|---:|---|---|
| **Terrain** | **25 €** | Ceux qui gardent leur ERP sécurité ou EBP | Planning par agence, appli hors réseau, fiches d'intervention, consignes de télésurveillance, bons de sortie, parc et n° d'abonné, export vers leur ERP |
| **Sécurité** *(recommandée)* | **39 €** | La plupart des installateurs | Tout Terrain, plus devis, contrats de maintenance, **facturation des abonnements**, factures Factur-X, espace client, **stock par camionnette** |
| **Groupe** | **49 €** | Multi-sociétés, plus de 25 techniciens | Tout Sécurité, plus habilitations, parc véhicules, plusieurs sociétés, **support prioritaire avec délai écrit** |

Ce qui change, et pourquoi :
- **Le multi-agences est inclus dans toutes les formules.** Un groupe de 4 agences n'est plus obligé de prendre la formule la plus chère (demandé par P003, P006, P010, P019).
- **Le stock par camionnette passe dans la formule Sécurité** (demandé par P008).
- **La formule Terrain à 25 € vient compléter l'ERP en place au lieu de le remplacer.** C'est la porte d'entrée pour les 4 acheteurs déjà équipés d'un ERP sécurité, qui refusaient d'avoir deux logiciels à facturer.
- **Tarif dégressif** : −15 % sur chaque technicien au-delà du 20e. Pour 40 techniciens en formule Sécurité : 20 × 39 + 20 × 33,15 = **1 443 €/mois**, contre 2 600 € aujourd'hui en formule Entreprise.
- **Sans engagement par défaut**, et −10 % avec un engagement de 12 mois. Le prix affiché est celui qu'on paie vraiment : pas de faux « prix barré ».
- **Mise en service** : elle reste payante, mais elle est **déduite de la première année** si le client reste après l'essai. Elle est **offerte** pour les clients fondateurs (voir 3).

## 3. L'offre de lancement : « 5 installateurs fondateurs »

- **Réservée à 5 entreprises, jusqu'au 31 mars 2027** (limite réelle, à respecter).
- Essai de **60 jours sur une seule agence**, avec **reprise des données faite par toi**, sur place si possible.
- **Mise en service offerte**, et **prix fondateur garanti 24 mois** (le prix de la grille, bloqué : pas une remise).
- En échange : un **retour écrit** des techniciens et du dirigeant, et l'**accord écrit d'être cité** si le client reste.

Cette offre répond aux trois premières demandes du panel (références, reprise faite pour eux, pas d'engagement) sans habituer le marché à attendre des soldes. ARGE devrait être le premier fondateur.

## 4. À tester avec de vrais acheteurs

- **35 € contre 39 €** pour la formule Sécurité : deux versions de la fiche tarifs, envoyées en alternance dans la séquence d'e-mails (une version sur deux). On compare le nombre de démonstrations obtenues et d'essais signés. Il faut environ 20 démonstrations par version avant de conclure.
- **La formule Terrain à 25 € face aux clients équipés d'un ERP** : la proposer à 5 installateurs qui ont CMII, Capasoft ou équivalent, et compter combien acceptent un essai.
- Avant tout : demander à ARGE combien il paie aujourd'hui ses outils, et ce qu'il trouverait juste.

## 5. Les objections de prix du panel, mot pour mot (pour le marketing)

Ce sont des acheteurs simulés, **pas des témoignages**.

1. Sur l'engagement : « si mes techniciens n'adoptent pas l'appli je suis coincé un an avec un engagement que je paie quand même. » (P002)
2. Sur le multi-agences : « je suis obligée de prendre la formule à 65 € pour le multi-agences : ça fait plus de 2 500 € HT par mois » (P003)
3. Sur le doublon avec l'ERP : « je garde mon ERP et je paierais deux logiciels, plus 300 € et des samedis à tout reprendre. » (P020)

## Préalable produit (à ne pas oublier)

La formule Sécurité promet la **facturation des abonnements**. Aujourd'hui, Itinéos facture un contrat à la main, un par un, et « Prélèvement » n'est qu'un mode de paiement. Il manque trois choses : la facturation en lot chaque mois, les mandats SEPA et le fichier de prélèvement à envoyer à la banque. **Tant que ce n'est pas construit, on ne peut pas l'écrire dans l'offre.** Dans ce cas, on la vend comme « bientôt disponible », à une date précise que tu peux tenir.
