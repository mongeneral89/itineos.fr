# Brief du conseil : Itinéos recentré sur l'alarme et la vidéosurveillance

Ce brief se suffit à lui-même. Il décrit le projet tel que le fondateur le présente ; il ne contient aucun avis.

## L'idée en une phrase
Prendre Itinéos, un logiciel de gestion d'interventions déjà construit pour tous les métiers de techniciens itinérants, et le vendre **uniquement** aux entreprises françaises d'installation et de maintenance d'alarme, de vidéosurveillance et de télésurveillance, sur le modèle de la version construite pour A.R.G.E.

## Le client visé
- Installateurs de sécurité électronique en France : alarme intrusion, vidéoprotection, contrôle d'accès, raccordement à la télésurveillance (le plus souvent via un télésurveilleur partenaire), parfois défibrillateurs et incendie.
- Taille : 3 à 50 techniciens, une ou plusieurs agences. Ces entreprises sont généralement soumises à l'autorisation du CNAPS et doivent porter leurs numéros d'agrément sur leurs documents.
- Acheteur : dirigeant ou responsable d'exploitation. Utilisateurs : techniciens sur le terrain, planificateurs, administratif, direction.
- Exemple réel servant de modèle : A.R.G.E. (siège Quetigny, agences Nancy, Lille, Fontainebleau). Son logiciel est déjà préparé : ses fiches d'intervention, ses consignes de télésurveillance, ses bons de sortie télésurveillance et vidéoprotection, son catalogue de 131 articles, son logo. **Statut commercial d'ARGE avec Itinéos : non confirmé dans le brief (prospect ou client pilote) ; ARGE ne peut pas être cité comme référence sans son accord écrit.**

## Ce que fait le produit (déjà construit)
- Planning par agence en glisser-déposer, vue d'ensemble pour la direction ; le technicien est prévenu sur son téléphone.
- Appli terrain (Android, iPhone, navigateur), qui fonctionne sans réseau : fiche pré-remplie (client, site, matériel, numéro de série), dictée vocale, photos, pièces posées, temps passé, double signature au doigt, PDF envoyé aussitôt au client.
- Documents propres au métier, repris tels quels avec le logo de l'entreprise : fiche d'intervention technique, consignes de télésurveillance (personnes à prévenir, codes, procédure), bon de sortie télésurveillance, bon de sortie vidéoprotection. Mentions CNAPS en pied de document.
- Clients, sites et matériel installé (centrale, numéro de série, numéro d'abonné) avec l'historique de chaque appareil.
- Devis depuis un catalogue, contrats d'entretien avec visites créées automatiquement, factures (facture électronique Factur-X prévue par la réforme), avoirs, export comptable, espace client en ligne.
- Stock par dépôt et par véhicule, bons de sortie, parc de véhicules, habilitations des techniciens avec alertes d'expiration.
- Multi-sociétés, multi-agences, 16 langues.
- Installé chez le client (programme Windows, serveur au siège, sauvegarde chaque nuit, mises à jour la nuit avec retour arrière automatique, suivi à distance par l'éditeur) ou hébergé en France.

## Prix (grille actuelle, reprise telle quelle du produit généraliste)
Par technicien de terrain et par mois, bureau illimité, dès 3 techniciens, engagement 12 mois (sans engagement : environ +20 %) :
- Essentiel 29 € HT : planning, appli terrain, fiches PDF, clients/sites/matériel, modèles personnalisés, tableau de bord.
- Pro 45 € HT : + devis, contrats d'entretien, factures, export comptable, espace client.
- Entreprise 65 € HT : + stock, véhicules, habilitations, multi-sociétés, assistance prioritaire.
- Mise en service dès 300 € HT. Essai gratuit 30 jours.

## Comment il est vendu
- Le fondateur (Justin Simonetti) prospecte seul : séquence de 4 e-mails personnalisés, appels, démonstration de 30 minutes sur les propres documents du prospect. Une variante d'e-mail « entreprises de sécurité multi-agences » existe déjà.
- Supports : fiche commerciale 3 pages, maquette, vidéos de 2 min 34 et plus longue.

## Ce qui change par rapport à aujourd'hui
Aujourd'hui Itinéos se présente comme « six logiciels, un même socle » pour de nombreux métiers (chauffage, climatisation, électricité, sécurité, commissaires de justice, experts, états des lieux, nettoyage…). Le projet est de **ne plus viser qu'un seul secteur** : l'alarme et la vidéosurveillance.

## Ce qui n'est pas connu (à ne pas inventer)
- Budget du fondateur, temps disponible, besoin de revenu personnel.
- Nombre d'entreprises cibles en France, coût d'acquisition d'un client, taux de conversion.
- Concurrents précis et leurs prix (à établir par l'analyse concurrentielle).
- Clients payants actuels : aucun n'est mentionné.
