# Lens Produit (Product lens)
Score : 6/10 | Vote : FUND IF

## Ce qui est fort
- **Le recentrage est le bon geste.** Passer de « six logiciels, un même socle » à un seul secteur, c'est exactement le « dire non » que demande le Product lens. Le pitch tient enfin en une phrase : le logiciel d'intervention des installateurs d'alarme et de vidéosurveillance.
- **Le produit part du geste du technicien.** Fiche pré-remplie (site, centrale, numéro de série, numéro d'abonné), fonctionnement sans réseau, double signature, PDF envoyé aussitôt : c'est le moment client décrit, puis construit à rebours.
- **Les documents du métier, repris tels quels.** Consignes de télésurveillance, bons de sortie télésurveillance et vidéoprotection, mentions CNAPS en pied de page : c'est du soin sur des détails qu'un logiciel généraliste n'a pas. Le cas ARGE (fiches, catalogue de 131 articles, logo) montre que ce soin peut se reproduire pour un client précis.
- **La démo sur les propres documents du prospect** fait vivre l'expérience avant l'achat.

## Ce qui le tuerait (les 3 premiers, le plus dangereux d'abord)
1. **Le produit reste généraliste sous une étiquette sectorielle.** 16 langues, multi-sociétés, six éditions, deux modes d'installation (Windows sur serveur au siège ou hébergé), trois offres héritées du produit généraliste : le recentrage est dans le discours, pas encore dans le produit. Si l'installateur voit des écrans, des options et une grille de prix pensés pour le chauffagiste, la promesse « fait pour vous » s'effondre.
2. **Les jointures avec le télésurveilleur et le parc existant.** Le raccordement passe « le plus souvent via un télésurveilleur partenaire ». Ce qui arrive aux consignes et aux bons de sortie après la signature (ressaisie, e-mail, rien ?) n'est pas décrit. C'est là que l'expérience casse. De même, la reprise des clients, sites et matériels déjà installés conditionne la fiche pré-remplie : sans elle, le premier jour est vide.
3. **Les cinq premières minutes ne sont pas reproductibles sans le fondateur.** ARGE a été préparé à la main. Si chaque nouveau client exige la même préparation (modèles, catalogue, import), la mise en service « dès 300 € » et l'essai de 30 jours ne livrent pas l'expérience promise, et un fondateur seul ne peut pas tenir la cadence.

## Les questions que je poserais au fondateur
- Quelle est la seule chose qu'Itinéos doit faire mieux que quiconque pour un installateur d'alarme ? (La fiche d'intervention ? Les consignes de télésurveillance ? Les contrats de maintenance ?)
- Que retirez-vous de l'édition sécurité : quelles langues, quels modules, quel mode d'installation ?
- Décrivez la première heure d'un nouveau client sans vous : qui importe les sites et le matériel, combien de temps cela prend-il ?
- Que devient une consigne de télésurveillance une fois signée : comment arrive-t-elle chez le télésurveilleur ?
- ARGE est-il client pilote, prospect, utilisateur réel ? Qu'est-ce que ses techniciens ont trouvé pénible ? (Inconnu dans le brief.)
- Quels outils les installateurs utilisent-ils aujourd'hui, et qu'est-ce qui les fait souffrir ? (Question ouverte : /founder-competitors pour les outils et leurs prix, /founder-consumer pour la douleur et la volonté d'acheter.)
- La grille 29/45/65 € a-t-elle un sens pour ce secteur et pour vos coûts ? (Question ouverte : /founder-cfo et /founder-pricing.)

## Si FUND IF : les conditions
1. **Une édition sécurité réellement épurée** : écrans, vocabulaire, modèles et offres propres au métier ; tout ce qui sert d'autres secteurs est caché ou retiré.
2. **Une mise en route reproductible** : import des clients, sites et matériels et modèles de documents sécurité prêts à l'emploi, testés sur au moins un installateur autre qu'ARGE, sans intervention du fondateur au-delà de la démo.
3. **La jointure télésurveilleur décrite et traitée** (ou explicitement hors périmètre), validée auprès d'installateurs réels.
4. **Un premier utilisateur réel sur le terrain**, avec retour écrit des techniciens, avant d'élargir la prospection.
