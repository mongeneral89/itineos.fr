# Offers lens

Score: 5/10 | Vote: FUND IF

## Ce qui est fort
- **Un marché mieux choisi que le précédent.** Passer de « six logiciels, un même socle » à un seul secteur rend l'acheteur trouvable : les installateurs de sécurité soumis au CNAPS forment une population identifiable, avec un acheteur précis (dirigeant ou responsable d'exploitation).
- **Une douleur métier concrète, déjà traitée dans le produit.** Consignes de télésurveillance, bons de sortie télésurveillance et vidéoprotection, mentions CNAPS, numéros de série et d'abonné par centrale : ce sont des documents que l'acheteur reconnaîtra comme les siens. Cela fait monter la vraisemblance perçue.
- **Délai et effort faibles en apparence.** Démo de 30 minutes sur les propres documents du prospect, appli hors réseau, PDF envoyé aussitôt, essai de 30 jours : le résultat se voit dès la première intervention.
- **Matière pour une vraie pile d'offre.** Contrats d'entretien avec visites automatiques, habilitations avec alertes, Factur-X, stock par véhicule : chacun répond à un problème distinct que l'acheteur rencontre.

## Ce qui le tuerait (les 3 premiers, du plus dangereux au moins dangereux)
1. **Aucune preuve.** Aucun client payant n'est mentionné, et ARGE ne peut pas être cité sans accord écrit. Sans référence du secteur, la vraisemblance perçue (le facteur où la plupart des offres échouent) reste basse face à des dirigeants qui changent rarement de logiciel.
2. **Une offre généraliste dans un habit sectoriel.** La grille (29/45/65 € par technicien) est reprise telle quelle du produit généraliste. Rien dans le prix, le nom, la garantie ou la mise en service ne dit « fait pour l'alarme et la vidéo ». Le risque est d'être comparé ligne à ligne, donc sur le prix, à des outils déjà en place.
3. **Taille et accessibilité du marché inconnues.** Nombre d'entreprises ciblables, coût d'acquisition et conversion ne sont pas connus ; un fondateur seul qui prospecte par e-mails et appels peut ne pas atteindre assez d'acheteurs si le marché est étroit ou déjà équipé.

## Les questions que je poserais au fondateur
- Combien d'installateurs de 3 à 50 techniciens existent en France, et quelle part a déjà un logiciel métier ? (/founder-competitors)
- Quels outils utilisent-ils aujourd'hui, à quel prix, et de quoi se plaignent-ils ? (/founder-competitors)
- ARGE va-t-il payer, et accepterait-il d'être cité, chiffres à l'appui (temps gagné, factures émises plus vite) ? 
- Quel résultat le dirigeant veut-il vraiment : moins de ressaisie, contrats d'entretien facturés à temps, conformité CNAPS, passage à Factur-X ? (/founder-consumer)
- Le prix pourrait-il doubler pour une offre « clé en main sécurité » (reprise des fiches et consignes existantes, import du parc installé, formation) ? (/founder-consumer, /founder-cfo)
- Quelle garantie l'entreprise peut-elle se permettre, et que coûte une mise en service réelle ? (/founder-cfo)

## Si FUND IF : les conditions
1. **Une preuve avant l'échelle** : ARGE ou un autre installateur passe en client payant et accepte par écrit d'être cité, avec au moins un résultat mesuré.
2. **Une offre propre au secteur** : nom, pile et prix construits pour l'installateur de sécurité (reprise de ses documents et de son parc incluse dans la mise en service, contrats d'entretien et Factur-X mis en avant), au lieu de la grille généraliste.
3. **Une garantie chiffrée** que le CFO valide (par exemple sur la mise en service ou le délai de démarrage), pour réduire le risque perçu de changer de logiciel.
4. **Le marché dimensionné** par /founder-competitors (nombre de cibles, équipement actuel, prix concurrents) avant d'abandonner les autres secteurs.
