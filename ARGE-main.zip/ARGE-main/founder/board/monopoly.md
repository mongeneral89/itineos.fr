# Le prisme Monopole
Score : 5/10 | Vote : FUND IF

## Ce qui est solide
- **Le bon geste : rétrécir le marché.** Passer de « six logiciels, un même socle » à un seul secteur, c'est précisément ce que demande le prisme Monopole : un petit marché qu'on peut dominer avant de s'étendre. Les installateurs d'alarme et de vidéosurveillance de 3 à 50 techniciens forment une niche nette, avec un vocabulaire et des documents propres.
- **Un savoir-faire métier déjà incorporé.** Consignes de télésurveillance, bons de sortie télésurveillance et vidéoprotection, numéro d'abonné par centrale, mentions CNAPS en pied de document, habilitations avec alertes : un logiciel généraliste ne fait pas cela tel quel. C'est le début d'un avantage propriétaire, pas encore un avantage dix fois supérieur.
- **Un modèle réel (ARGE) et un produit déjà construit.** Le coût de la spécialisation est surtout commercial, pas technique.
- **Une option d'installation sur serveur au siège** qui peut séduire des entreprises de sécurité attachées à garder leurs données chez elles.

## Ce qui le tuerait (les 3 plus dangereux d'abord)
1. **Pas de secret, donc pas de barrière.** Les documents métier se reproduisent en quelques semaines par un éditeur concurrent de gestion d'interventions, ou par un éditeur déjà spécialisé sécurité. Rien dans le brief ne montre un avantage dix fois supérieur, un effet de réseau ou une économie d'échelle. Question ouverte : qui vend déjà cela à ces installateurs, et à quel prix ? (/founder-competitors)
2. **La distribution repose sur une seule personne.** Un fondateur seul, quatre e-mails et une démo de 30 minutes : aucun chiffre sur le nombre d'entreprises cibles, le coût d'acquisition ni la conversion, et aucun client payant mentionné. Sans chemin vers les 100 premiers clients, ce n'est pas encore une entreprise. (/founder-consumer, /founder-cfo)
3. **Une niche peut-être trop petite, ou déjà prise.** Le nombre d'installateurs autorisés par le CNAPS dans la tranche 3-50 techniciens n'est pas connu. Si la niche est petite ET qu'un acteur y est installé, il n'y a ni domination possible ni marge. Le prix, repris tel quel du produit généraliste, ne dit rien d'une position dominante. (/founder-competitors, /founder-cfo)

## Les questions que je poserais au fondateur
- Quel est votre secret : que savez-vous des installateurs de sécurité que les éditeurs en place ignorent ?
- Combien d'entreprises cibles en France, et quelle part pouvez-vous prendre en deux ans ?
- Qui d'autre vend un logiciel d'intervention à ces mêmes acheteurs ? Pourquoi vous quitteraient-ils ?
- ARGE est-il client payant, pilote ou prospect ? Acceptera-t-il d'être cité ?
- Qu'est-ce qui empêche un concurrent de copier vos documents métier au sixième mois ?
- Y a-t-il un levier de distribution collectif : télésurveilleurs partenaires, grossistes en matériel, fédérations professionnelles ? Un accord avec un télésurveilleur (consignes et bons de sortie partagés) pourrait créer un début d'effet de réseau.
- Pourquoi maintenant : la réforme de la facture électronique force-t-elle ces entreprises à changer d'outil ?

## Conditions du FUND IF
1. **Carte concurrentielle établie** (/founder-competitors) montrant qu'aucun acteur ne domine déjà cette niche, ou un angle précis où Itinéos est nettement supérieur.
2. **Taille de la niche chiffrée** et un objectif de part de marché crédible sur un sous-segment (par exemple une région ou les multi-agences).
3. **Une preuve de distribution** : ARGE confirmé client payant avec accord de référence, et quelques clients supplémentaires signés par la prospection, avec le coût par client mesuré (/founder-cfo).
4. **Une piste de barrière durable** identifiée et engagée : intégration avec les télésurveilleurs, données d'historique du parc installé, ou partenariat de distribution.
