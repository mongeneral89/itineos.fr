Itinéos Sécurité, le logiciel des installateurs d'alarme et de vidéosurveillance : planning par agence au bureau, et une appli sur le téléphone du technicien qui fonctionne sans réseau.
La fiche s'ouvre déjà remplie (client, site, centrale, numéro de série, numéro d'abonné) ; le technicien ajoute photos, pièces et temps, le client signe sur l'écran et le PDF part aussitôt.
Vos propres documents sont repris avec votre logo et vos mentions CNAPS : fiche d'intervention, consignes de télésurveillance, bons de sortie télésurveillance et vidéoprotection.
Prix par technicien de terrain et par mois, comptes du bureau illimités, dès 3 techniciens, engagement 12 mois : 29 € HT (planning, appli, fiches), 45 € HT (+ devis, contrats de maintenance, factures Factur-X, espace client), 65 € HT (+ stock par véhicule, habilitations, multi-agences).
Mise en service dès 300 € HT (reprise de vos clients et documents, formation), essai gratuit 30 jours. Installé sur un ordinateur de votre siège ou hébergé en France ; vendu et suivi par son créateur, en direct.
(Pour les questions de prix : répondez en euros HT par technicien et par mois.)
