# Les chiffres de l'offre « Installateurs fondateurs »

Entrées : [numbers.json](numbers.json). Source de chaque chiffre : [cfo-sources.md](cfo-sources.md) et [ops.md](ops.md). Le tableau détaillé, plus bas, sort de l'outil de calcul : il affiche « $ », mais **ce sont des euros HT**. Beaucoup de coûts restent des **estimations** : il faut les remplacer par de vrais devis.

*Mise à jour du 23/10/2026 après [ops.md](ops.md) : taux de cotisations 2026 corrigé (25,8 %), frais GoCardless plafonnés, support de secours (150 € par mois) et plateforme agréée (10 € par mois) ajoutés. Puis après [launch.md](launch.md) : montée en charge recalée sur l'envoi de l'offre le 11 janvier 2027 (ARGE n'utilise pas encore le logiciel ; il paie à partir de février 2027).*

## La note du CFO

**La marge.** Sur 35 € payés par technicien et par mois (prix moyen, ARGE compris à prix réduit), il reste **25,22 €** une fois payés les cotisations, le prélèvement et l'hébergement, soit 72 %. Les coûts fixes sont de **411 € par mois**, dont 150 € pour le support de secours. L'activité couvre ses frais à partir de **17 techniciens payés**. Ce n'est pas la marge qui pose problème.

**La vraie question : quand peux-tu te verser 2 500 € net ?**
- Il faut environ **116 techniciens payés** chaque mois. Calcul fait avec l'outil, en ajoutant la paie aux coûts fixes : seuil de 115,4.
- Le plan prévoit **54 techniciens au mois 12** (octobre 2027). Il te resterait alors **951 €** par mois.
- Au même rythme (6 techniciens de plus par mois), tu atteins 116 techniciens vers le **mois 23, soit septembre 2028**.
- Si tu te versais 2 500 € dès le mois 1, il manquerait **30 097 €** de trésorerie sur l'année. Ne pas te payer au début n'est donc pas un choix, c'est obligatoire.

**Le chiffre qui pèse le plus : le rythme des nouveaux clients.** Avec deux fois moins de techniciens chaque mois (variante « volume × 0,5 »), le bénéfice de l'année 1 passe de 2 483 € à **une perte de 1 225 €**, et il faut 4 549 € de trésorerie. Une baisse du prix de 10 % ne retire que 1 029 €. Le plan suppose environ 50 prospects sérieux en 5 mois pour obtenir 5 essais (taux de 10 % du panel). C'est l'hypothèse à vérifier en premier : compte chaque semaine tes appels et tes démonstrations ([ops.md](ops.md), semaine type).

**La trésorerie.** Il faut **4 030 €** avant que l'activité paie ses frais : 2 580 € de dépenses de départ, plus les cinq premiers mois en perte (rien n'est encaissé avant février 2027). C'est **environ 2 000 € de plus que les 2 000 € dont tu disposes**. Les dépenses de départ ne sont pas tout à fait récupérées en fin d'année 1 (−97 €). Pour combler l'écart sans emprunter :
- **indispensable :** demander à ARGE de payer **un an d'avance** à son prix réduit (12 techniciens × 25 € × 12 mois = 3 600 €), ce qui est cohérent avec un prix réduit ;
- étaler les déplacements chez les fondateurs : 1 250 € sont prévus, mais pas tous le premier mois ;
- ne démarrer l'astreinte du support de secours qu'au premier fondateur hors ARGE. Elle doit quand même être signée avant d'envoyer l'offre.

**Trois façons d'améliorer le résultat** (techniciens nécessaires pour 2 500 € net ; aujourd'hui 116) :
1. **Vendre surtout la formule Sécurité à 39 €, plutôt qu'un prix moyen de 35 €.** Il te faut alors environ **104 techniciens**. Calcul à la main, car l'outil ne fait pas bouger les cotisations avec le prix : 39 − (39 × 25,8 % + 0,75) = 28,19 € par technicien, et 2 911 / 28,19 = 104.
2. **Faire confirmer par un comptable la catégorie de ton activité.** Au taux BIC (environ 21,4 %) au lieu du taux BNC (25,8 %), il reste 26,76 € par technicien. Il te faut alors environ **109 techniciens** (calcul à la main).
3. **Fixer le prix réduit d'ARGE en échange d'une contrepartie mesurable.** Si ARGE payait le prix normal (39 €), le prix moyen serait d'environ 37,3 € et il te faudrait environ **109 techniciens**. Le prix réduit coûte donc à peu près 7 techniciens. Il vaut la peine s'il t'apporte au moins un client.

**Le passage en SASU.** Pour 2 500 € net, une SASU coûte nettement plus cher qu'une micro-entreprise : le président est assimilé salarié, avec des charges élevées sur sa paie, et il faut un expert-comptable. Le seuil passera donc bien au-dessus de 116 techniciens. À chiffrer avec un comptable avant de changer de statut, et seulement quand le chiffre d'affaires le justifie.

**Les plafonds.** À 116 techniciens × 35 € × 12 mois, cela fait 48 720 € par an : tu restes sous le plafond de chiffre d'affaires de la micro-entreprise pour les services. En revanche, tu dépasses le seuil de **franchise de TVA** vers 90 techniciens payés. Il faudra alors facturer la TVA en plus, ce qui ne change rien pour des clients professionnels qui la récupèrent. Ces plafonds et seuils changent souvent : à vérifier.

**Le coût réel de la mise en service** (calcul dans [ops.md](ops.md), § 8) :
- chez un fondateur, sur place, elle coûte au moins **820 €** : environ 250 € de frais et 3 jours de ton temps à 190 € de chiffre d'affaires par jour ;
- les 300 € de la grille actuelle ne couvrent donc que les frais ;
- proposition hors programme fondateurs : **450 € HT à distance**, **950 € HT sur place**, déduits de la première année si le client reste.

**Les conditions du conseil liées à l'argent** ([board.md](board.md)) :
- *Garantie et mise en service à leur coût réel, validées par les chiffres* : **remplie sur le papier.** Le coût de la mise en service est calculé et un prix est proposé. Les garanties (export, support sous 4 heures, séquestre, support de secours) sont comptées dans les coûts fixes. À confirmer par de vrais devis : séquestre, assurance, astreinte.
- *Coût pour gagner un client, mesuré* : **non remplie.** Il n'existe pas encore de vraie donnée. On le mesurera pendant le lancement : temps et frais par essai signé.

*Ce n'est pas un conseil financier, fiscal ou juridique. Un comptable doit vérifier le statut, le taux de cotisations, la TVA et le passage en SASU avant que l'argent ne bouge.*

---

# Le détail du calcul (sortie de l'outil, montants en euros HT)

Every number below comes from the input file. Nothing is looked up or guessed.

## One technicien payé par mois

| line | per technicien payé par mois |
| --- | ---: |
| Price | $35.00 |
| Cotisations sociales micro-entreprise (25,8 % du chiffre : BNC 2026 25,6 % + formation 0,2 %) | -$9.03 |
| Frais de prélèvement GoCardless (1 % + 0,20 €, plafonné à 2 € par client de 8 techniciens) | -$0.25 |
| Hébergement et stockage en plus (photos, PDF) | -$0.50 |
| **Contribution** (what each technicien payé par mois leaves to pay the fixed costs) | **$25.22** (72%) |

## The margin that matters

Fixed costs: $411 a month (Serveur en France avec sauvegarde chaque nuit $20, Nom de domaine et messagerie pro $8, Assurance responsabilité civile pro (informatique) $40, Dépôt du code source chez un tiers (abonnement annuel / 12) $40, Compte développeur Apple (99 $ par an / 12) $8, Compte bancaire pro $10, Téléphone et outils $25, Déplacements de prospection et de démonstration $100, Support de secours (astreinte d'un développeur indépendant) $150, Plateforme agréée pour tes propres factures $10).

- **Break-even: 17 technicien payé par moiss a day.** Below that you lose money every month.
- **Profit margin at your plan** (110 a day): **61%** of every sale, after every cost.

## Year 1, month by month

| month | technicien payé par moiss a day | revenue | profit | cumulative (after $2,580 startup) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 0 | $0 | -$411 | -$2,991 |
| 2 | 0 | $0 | -$411 | -$3,402 |
| 3 | 0 | $0 | -$411 | -$3,813 |
| 4 | 12 | $420 | -$108 | -$3,921 |
| 5 | 12 | $420 | -$108 | -$4,030 |
| 6 | 20 | $700 | $93 | -$3,936 |
| 7 | 28 | $980 | $295 | -$3,641 |
| 8 | 36 | $1,260 | $497 | -$3,144 |
| 9 | 42 | $1,470 | $648 | -$2,496 |
| 10 | 42 | $1,470 | $648 | -$1,848 |
| 11 | 48 | $1,680 | $800 | -$1,048 |
| 12 | 54 | $1,890 | $951 | -$97 |

- **Year 1 operating profit: $2,483** on $10,290 of revenue.
- After the $2,580 startup spend: -$97.
- Startup money earned back: not within year 1.
- Cash you need before it pays for itself: **$4,030**.

## What if

| scenario | margin at plan | break-even a day | year 1 profit |
| --- | ---: | ---: | ---: |
| Base plan | 61% | 17 | $2,483 |
| Price -10% | 57% | 19 | $1,454 |
| Volume -20% | 59% | 17 | $1,000 |
| Unit costs +15% | 57% | 18 | $2,051 |

## Red flags

- The startup spend is not earned back within year 1.
