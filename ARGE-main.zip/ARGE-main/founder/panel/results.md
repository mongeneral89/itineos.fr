# Buyer panel: Itinéos Sécurité : logiciel de gestion d'interventions (bureau + appli terrain) pour installateurs d'alarme, de vidéosurveillance et de télésurveillance

**0 buy · 20 pass** (0% buy) out of 20 simulated buyers. Seed 916646, so the same cards can be dealt again.

These are simulated buyers, not customers. Use this to find objections and weak spots, then confirm the big ones with real people before you spend.

## By segment

| group | buyers | buy rate |
| --- | ---: | ---: |
| Dirigeant ou responsable d'exploitation d'une PME de sécurité (9 à 25 techniciens, une ou deux agences, une assistante au planning) | 7 | 0%  (thin) |
| Dirigeant d'une petite entreprise d'alarme (3 à 8 techniciens, une seule agence, le dirigeant fait encore des interventions) | 9 | 0% |
| Directeur des opérations d'un groupe multi-agences type ARGE (26 à 50 techniciens, 3 à 5 agences, télésurveillance via un partenaire) | 4 | 0%  (thin) |

## By buying behaviour

| group | buyers | buy rate |
| --- | ---: | ---: |
| Méfiant envers les petits éditeurs | 3 | 0%  (thin) |
| Cherche à se structurer pour grandir | 2 | 0%  (thin) |
| Regarde d'abord le prix | 3 | 0%  (thin) |
| Déjà équipé d'un ERP sécurité | 4 | 0%  (thin) |
| Encore au papier | 5 | 0%  (thin) |
| Déjà sur un outil de terrain généraliste | 3 | 0%  (thin) |

## By income

| group | buyers | buy rate |
| --- | ---: | ---: |
| $53,000 to $74,000 | 7 | 0%  (thin) |
| under $53,000 | 6 | 0%  (thin) |
| $74,000 and up | 7 | 0%  (thin) |

## Why they pass

| reason | buyers | in their words |
| --- | ---: | --- |
| habit | 9 | "Ça me parle, surtout les devis et factures qui me bouffent mes samedis, mais là je viens de m'agrandir et je n'ai pas la tête à changer de logiciel en plus. Je demanderais peut-être l'essai, mais signer 12 mois ce mois-ci, non." (P002) · "J'ai tout mon historique et mes abonnements de télésurveillance dans mon ERP depuis des années, avec le prélèvement automatique. Votre offre parle de fiches et de factures, mais rien sur la facturation récurrente des abonnements, donc je devrais garder mon ERP en plus et payer deux outils." (P007) |
| trust | 8 | "Sur le papier ça colle à notre métier, les numéros d'abonné et les bons de sortie télésurveillance, ce n'est pas du généraliste. Mais « vendu et suivi par son créateur, en direct », pour moi ça veut dire une seule personne : j'ai déjà vu un éditeur disparaître avec nos fiches dedans, je ne remets pas mes contrats de maintenance et mes abonnements sur un logiciel tenu par un seul homme." (P001) · "Ça a l'air pensé pour mon métier, mais « vendu et suivi par son créateur, en direct », pour moi ça veut dire une seule personne. J'ai déjà vu un éditeur disparaître avec mes données dedans, je ne mets pas mes contrats de maintenance et mes abonnés télésurveillance sur un seul homme." (P004) |
| price | 2 | "Avec 40 techniciens et 4 agences, je suis obligée de prendre la formule à 65 € pour le multi-agences : ça fait plus de 2 500 € HT par mois, plus de 30 000 € par an, engagés 12 mois, alors que nos marges sur la pose sont serrées. L'appli hors réseau pour les caves m'intéresse vraiment, mais pas à ce prix-là, et pas sans garantie que ça tienne." (P003) · "Avec 4 ou 5 techniciens à 45 € plus 300 € de mise en service et 12 mois d'engagement, ça fait plus de 2 500 € par an pour une boîte où je suis encore sur les chantiers ; mes fiches papier et mon tableur font le travail, je ne vois pas ce que je gagne en marge." (P005) |
| need | 1 | "Mon vrai problème c'est la facture électronique et mes abonnements de télésurveillance, et je ne vois écrit nulle part que ça facture et prélève mes abonnements tous les mois. Pour des fiches et un planning, mon papier carbone marche encore, alors je ne vais pas tout chambouler et engager 12 mois pour ça." (P011) |

## Why they buy

| reason | buyers | in their words |
| --- | ---: | --- |

## What would flip a no

- Deux ou trois installateurs du métier que je peux appeler, et un engagement écrit : support assuré par quelqu'un d'autre que le fondateur et récupération de toutes mes données dans un format standard si l'éditeur s'arrête.
- Que le créateur vienne reprendre lui-même mes clients et mes fiches pendant l'essai, et que je puisse arrêter sans frais au bout des 30 jours si mes techniciens n'en veulent pas.
- Un tarif dégressif au-delà de 20 techniciens avec le multi-agences sans passer à la formule la plus chère, plus un essai sur une agence pilote dans de vraies caves sans réseau et une garantie de réversibilité des données si l'éditeur disparaît.
- Deux ou trois installateurs d'alarme de ma taille que je peux appeler et qui l'utilisent depuis plus d'un an, plus un engagement écrit : hébergé en France avec sauvegardes incluses, export complet de mes données à tout moment et un support de secours si le fondateur n'est pas là.
- Une offre hébergée sans engagement de 12 mois, avec la mise en service offerte, et un installateur de ma taille qui me confirme que ça lui a fait gagner du temps sur la paperasse.
- Un hébergement en France avec sauvegardes et support garantis par écrit (délai d'intervention, réversibilité des données), et un tarif dégressif ou un premier engagement court sur une seule agence pilote.
- Une preuve que les abonnements récurrents et le prélèvement SEPA sont gérés, avec la reprise complète de mon historique et de mes contrats depuis mon ERP actuel.
- Deux ou trois installateurs d'alarme que je peux appeler et qui l'utilisent depuis au moins un an, plus un engagement écrit que je récupère toutes mes données dans un format lisible si l'éditeur s'arrête.
- Qu'un confrère de ma taille me montre que ses vieux techniciens s'en servent vraiment, et que la mise en service reprenne tout pour moi sans que j'y passe mes soirées.
- Deux ou trois installateurs de ma taille, multi-agences, que je peux appeler et qui l'utilisent depuis au moins six mois, plus un essai sur une seule agence sans engagement 12 mois pour le reste du groupe.
- Qu'on me montre, avec mon comptable, la facturation récurrente et le prélèvement automatique de mes abonnements de télésurveillance en Factur-X, avec reprise de mes contrats depuis EBP, sans engagement de 12 mois au départ.
- Qu'il vienne lui-même reprendre mes données et former mes gars un jour où je ne suis pas sur le terrain, avec un collègue installateur du coin qui l'utilise déjà et me dit que ses samedis de facturation ont disparu.

20 buyers gave all four price answers. Run founder-pricing's van_westendorp.py on the answers folder.
