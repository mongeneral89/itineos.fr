# Le marketing : comment les premiers installateurs entendent parler d'Itinéos Sécurité

Sources : [panel-v2/results.md](panel-v2/results.md) (l'offre actuelle) et [panel/results.md](panel/results.md) (l'ancien pitch), [competitors.md](competitors.md), [offer.md](offer.md), [pricing.md](pricing.md), [numbers.json](numbers.json), [launch.md](launch.md) (envoi le **lundi 11 janvier 2027**).

**Règle de base.** Les phrases du panel viennent d'acheteurs **simulés** : elles servent à comprendre, jamais de témoignages dans un e-mail ou une publication. Pas de faux avis, pas de « x heures gagnées » tant que ce n'est pas mesuré chez un vrai client, et **ARGE n'est nommé nulle part sans son accord écrit**.

## 1. Le premier public

Dans le panel de l'offre actuelle, **les deux seuls oui viennent d'entreprises qui grandissent** :
- l'une vient de passer à deux agences ;
- l'autre vient de racheter une agence.

Leur comportement d'achat : « cherche à se structurer pour grandir ». C'est **2 acheteurs sur 2** dans ce groupe, et 0 sur 18 ailleurs. L'échantillon est très petit : c'est une piste, pas une preuve. Les deux citent la même chose : *l'essai sur une seule agence, avec la reprise des données et la formation faites par le créateur*.

**Le premier public est donc : les installateurs de 5 à 40 techniciens qui ouvrent, rachètent ou regroupent une agence.** On les repère par les annonces d'ouverture d'agence, les offres d'emploi de techniciens dans une nouvelle ville, les rachats publiés et leurs propres publications LinkedIn.

Ce que le marketing doit d'abord lever (refus du panel actuel) :
- **la confiance** (7 refus) : « une seule personne », « aucune référence du métier » ;
- **l'habitude** (7 refus) : « mon ERP fait déjà le prélèvement », « le papier marche » ;
- **le prix** (3 refus), surtout pour les grandes équipes.

## 2. Le positionnement

**A (recommandé) : l'installateur qui grandit**
> Pour les installateurs d'alarme et de vidéosurveillance qui ouvrent une nouvelle agence et dont chaque agence a encore ses papiers, Itinéos Sécurité est le logiciel de terrain qui reprend **leurs propres** fiches, consignes de télésurveillance et bons de sortie, marche au sous-sol sans réseau et réunit toutes les agences dans un seul planning. Son prix est public, par technicien et sans engagement. Les ERP spécialisés, eux, ne publient pas leurs prix et traitent l'appli terrain comme un module annexe.

*Ce qui le soutient :* les 2 oui du panel ; le multi-agences était le premier frein des groupes au premier panel (P003, P006, P010, P019) ; le « trou » relevé chez les concurrents (documents du métier + appli hors réseau + prix public).

**B : celui qui a déjà un ERP**
> Pour les installateurs qui gardent leur ERP pour les abonnements, Itinéos Sécurité Terrain est l'appli du technicien qui se branche à côté, à 25 €, au lieu de tout remplacer.

*Pourquoi pas en premier :* 0 sur 4 chez les acheteurs déjà équipés d'un ERP. Ils refusent toujours, faute de prélèvement SEPA et par peur d'avoir « deux outils ».

**C : celui qui est encore au papier**
> Pour les installateurs encore au papier carbone, Itinéos Sécurité remplace la ressaisie du vendredi par une fiche signée sur place.

*Pourquoi pas en premier :* 0 sur 5 chez les acheteurs au papier. L'habitude l'emporte (« je mets ça de côté pour plus tard »).

## 3. Les canaux

**On en garde trois :**

| Canal | Pourquoi il convient à cet acheteur | Coût | Comment on sait que ça marche |
|---|---|---|---|
| **1. Appel + e-mail personnalisé** au dirigeant | Les dirigeants du métier achètent après une démonstration sur leurs propres documents, pas après une publicité. C'est déjà le plan ([launch.md](launch.md)) | Ton temps (environ 20 appels et 10 e-mails par jour de lancement) | Au moins 15 % des appels donnent une démonstration, et au moins 1 démonstration sur 5 donne un essai |
| **2. [Expoprotection](https://www.expoprotection.com/), du 3 au 5 novembre 2026, Paris Porte de Versailles** | Le salon de la sécurité (tous les deux ans) : les dirigeants et responsables d'exploitation y sont en personne. Ça tombe la semaine du test 1. Tu viens **en visiteur**, pas avec un stand | Train et repas, environ 100 € (déjà dans les 100 € par mois de déplacements). Badge visiteur : à vérifier sur le site | Au moins 15 contacts d'installateurs avec un nom et un téléphone, et au moins 4 démonstrations fixées pour novembre |
| **3. Ton profil LinkedIn** (le tien, pas une page d'entreprise) | Les dirigeants d'installateurs y sont. Un fondateur qui montre son travail répond directement à « qui est derrière ? » (la confiance) | 0 € ; 2 publications par semaine | Messages reçus et demandes de démonstration venues de LinkedIn ; nombre de prospects qui disent « je vous ai vu sur LinkedIn » |

**Ce qu'on ne fait pas (pour l'instant), et pourquoi :**
- **Publicité Google** : très peu de recherches sur « logiciel installateur alarme ». De plus, la trésorerie manque déjà de 2 000 €.
- **Facebook, Instagram, TikTok** : ce n'est pas là qu'un dirigeant choisit le logiciel de ses techniciens.
- **Un stand à un salon** : plusieurs milliers d'euros. À reconsidérer en 2028, avec des références.
- **Partenariats avec les grossistes de matériel et les télésurveilleurs, adhésion à une fédération** (GPMSE) : c'est la bonne « barrière » à long terme (recommandation du conseil). Mais il faut d'abord des clients à montrer. À ouvrir au 2e trimestre 2027, en commençant par le télésurveilleur partenaire d'ARGE.
- **Le parrainage entre clients** : pas avant d'avoir des clients satisfaits. À prévoir pour le premier fondateur qui paie (par exemple : un mois offert par confrère qui signe).

## 4. Les dix accroches

Chacune répond à un refus du panel. Format : **objet d'e-mail**, **première ligne LinkedIn** ou **première phrase au téléphone**.

| # | Accroche | Elle répond à | Format |
|---|---|---|---|
| 1 | « Vous ouvrez une agence ? Un seul planning pour toutes, dès le premier jour. » | Le premier public (croissance) | Objet d'e-mail |
| 2 | « Si je m'arrête demain : votre code est chez un tiers, vos données vous reviennent sous 5 jours. C'est écrit au contrat. » | Confiance : « une seule personne » | LinkedIn |
| 3 | « 60 jours sur une seule agence. Si vos techniciens n'en veulent pas, vous arrêtez, sans frais. » | Engagement, « je suis coincé » | Téléphone |
| 4 | « Je reprends moi-même vos clients, vos sites et vos centrales. Vous n'y passez pas vos soirées. » | « Des semaines de reprise » | Objet d'e-mail |
| 5 | « La fiche se remplit au sous-sol, sans réseau. Elle part quand le téléphone remonte. » | Le hors ligne, attendu par les groupes | LinkedIn, vidéo de 30 s |
| 6 | « Vos consignes de télésurveillance et vos bons de sortie, avec votre logo et vos mentions CNAPS. Pas un formulaire générique. » | « Un généraliste repeint » | LinkedIn, photo du document (données fictives) |
| 7 | « Le multi-agences est inclus dans toutes les formules. » | Prix des groupes | Objet d'e-mail |
| 8 | « Vous gardez votre ERP. La formule Terrain à 25 € se branche à côté. » | Habitude, « deux logiciels » | Téléphone, pour les clients équipés d'un ERP |
| 9 | « Une demi-journée sur place avec vos techniciens, dans une vraie cave, pas en visio. » | « Mes techniciens de 50 ans » | LinkedIn |
| 10 | « 39 € HT par technicien et par mois, affiché, sans engagement. » | Les prix cachés des spécialistes | Objet d'e-mail, fiche tarifs |

**Ce qu'on dit franchement quand on nous le demande :** le prélèvement SEPA automatique des abonnements n'existe pas encore. Si une date est décidée (voir [ops.md](ops.md), risque n° 10), on la donne, et seulement celle-là.

## 5. Le calendrier, du 28 décembre 2026 au 27 janvier 2027

Jour J = lundi 11 janvier 2027. Jours ouvrés seulement : pas de prospection le week-end ni les jours fériés.

**La séquence d'e-mails** (prospects répartis en 5 lots de 10, un lot par jour du 11 au 15 janvier) :
- **E1 (jour J)** : accroche 1 ou 4, trois lignes, une proposition de démonstration de 30 minutes sur leurs propres documents.
- **E2 (J + 3)** : accroche 2 ou 3, une capture d'écran de la fiche remplie.
- **E3 (J + 8)** : dernier message court, avec le nombre **réel** de places restantes.

Sous chaque e-mail : ton nom, ton numéro, et une ligne pour ne plus en recevoir. La prospection par e-mail entre professionnels est permise si elle concerne leur métier et permet de s'opposer facilement ([CNIL](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique)). Ce n'est pas un conseil juridique.

| Date | Jour | Ce qui part | Canal | Message |
|---|---|---|---|---|
| lun. 28 déc. | J − 14 | Profil mis à jour : « Je crée Itinéos Sécurité, le logiciel de terrain des installateurs d'alarme et de vidéo » ; écrire E1, E2, E3 | LinkedIn, e-mail | — |
| mar. 29 déc. | J − 13 | **Publication 1** : pourquoi ce logiciel (les fiches carbonées, la ressaisie du vendredi, sans nommer ARGE) | LinkedIn | Coulisses |
| mer. 30 déc. | J − 12 | Fiche tarifs en deux versions (35 € et 39 €) | — | — |
| jeu. 31 déc. | J − 11 | Support seulement | — | — |
| lun. 4 janv. | J − 7 | **Publication 2** : vidéo de 30 s d'une fiche remplie sans réseau, filmée pendant la mise en service de décembre (**avec l'accord d'ARGE pour filmer**, sinon dans ta propre cave) | LinkedIn | Accroche 5 |
| mar. 5 janv. | J − 6 | Répétition de la démonstration n° 1 (un installateur du test 1) | Visio | — |
| mer. 6 janv. | J − 5 | **Publication 3** : photo d'un bon de sortie télésurveillance avec données fictives | LinkedIn | Accroche 6 |
| jeu. 7 janv. | J − 4 | Répétition n° 2 ; envoi d'essai d'E1 sur tes propres adresses (vérifier qu'il n'arrive pas en indésirables) | Visio, e-mail | — |
| ven. 8 janv. | J − 3 | **Publication 4** : « Lundi, j'ouvre 5 places pour des installateurs fondateurs » | LinkedIn | Annonce |
| **lun. 11 janv.** | **J** | **Lot 1 : E1** ; appels aux « oui » du test 1 ; **publication 5** : le programme (5 places, jusqu'au 31 mars, 60 jours d'essai, mise en service offerte, prix bloqué 24 mois) | E-mail, téléphone, LinkedIn | Accroches 1, 3 |
| mar. 12 janv. | J + 1 | Lot 2 : E1 ; appels de relance du lot 1 | E-mail, téléphone | Accroche 4 |
| mer. 13 janv. | J + 2 | Lot 3 : E1 ; **publication 6** : ce que garantit le contrat | E-mail, LinkedIn | Accroche 2 |
| jeu. 14 janv. | J + 3 | Lot 4 : E1 ; **lot 1 : E2** | E-mail | Accroches 7, 2 |
| ven. 15 janv. | J + 4 | Lot 5 : E1 ; lot 2 : E2 ; bilan de la semaine (chiffres du § 6) | E-mail | Accroche 10 |
| lun. 18 janv. | J + 7 | **Bilan du jour 7** ; lot 3 : E2 ; **publication 7** : les coulisses d'une reprise de données (anonymisée) | E-mail, LinkedIn | Accroche 4 |
| mar. 19 janv. | J + 8 | Lot 4 : E2 ; **lot 1 : E3** ; appels aux lots 1 et 2 sans réponse | E-mail, téléphone | Places restantes |
| mer. 20 janv. | J + 9 | Lot 5 : E2 ; lot 2 : E3 ; **publication 8** : la formation sur place | E-mail, LinkedIn | Accroche 9 |
| jeu. 21 janv. | J + 10 | Lot 3 : E3 ; démonstrations | E-mail, visio | — |
| ven. 22 janv. | J + 11 | Lot 4 : E3 ; bilan de la semaine | E-mail | — |
| lun. 25 janv. | J + 14 | **Bilan du jour 14** ; lot 5 : E3 ; **publication 9** : le multi-agences inclus. *Si moins de 3 démonstrations :* 20 nouveaux prospects, appel d'abord, puis e-mail | E-mail, LinkedIn, téléphone | Accroche 7 |
| mar. 26 janv. | J + 15 | Appels aux lots 3 à 5 sans réponse ; démonstrations | Téléphone | Accroche 3 |
| mer. 27 janv. | J + 16 | **Publication 10** : le prix public, et l'état réel des places | LinkedIn | Accroche 10 |

**Quand il n'y a rien de neuf à dire** (une publication sur deux au-delà du 27 janvier) :
- les coulisses du développement (l'import, l'export, le prélèvement SEPA quand il arrive) ;
- une fonction en 30 secondes ;
- un document du métier expliqué (à quoi sert un bon de sortie) ;
- une question au métier : « Comment transmettez-vous vos consignes au télésurveilleur ? » ;
- une mise en service racontée, avec l'accord du client.

## 6. Budget et chiffres

**Budget de lancement : environ 150 €**, déjà compris dans les 100 € par mois de déplacements de [numbers.json](numbers.json) :
- Expoprotection : environ 100 € ;
- impression de 30 fiches A4 de présentation pour le salon et les visites : environ 50 € (estimation).

E-mails : Brevo, formule gratuite au départ. LinkedIn : 0 €. On n'ajoute rien à la trésorerie, puisqu'il manque déjà 2 000 €.

**Ce que tu peux dépenser au maximum pour gagner un client :**
- Ce qui reste par technicien : **25,22 €** par mois ([cfo.md](cfo.md)).
- Client moyen : 8 techniciens, soit 8 × 25,22 € = **201,76 € par mois et par client**.
- Le panel annonce **1,0 achat par acheteur** le premier mois. Pour un abonnement, ça veut dire un abonnement, pas un achat répété.
- Règle de prudence : le client doit rembourser ce qu'il a coûté en **6 mois** : 6 × 201,76 € = **1 211 €**.
- Un fondateur sur cinq arrête après l'essai : 0,8 × 1 211 € = **969 € au maximum par essai signé**.
- Or la mise en service sur place d'un fondateur coûte déjà environ **820 €** (frais et 3 jours de ton temps, [ops.md](ops.md) § 8).
- **Il reste donc environ 150 € par essai signé pour trouver le client.** C'est pour ça que le plan repose sur le téléphone, LinkedIn et un salon en visiteur, et pas sur la publicité.

**Les trois chiffres à suivre chaque lundi :**

| Chiffre | Bon niveau | Il faut changer quelque chose si… |
|---|---|---|
| Appels → démonstrations | 15 % ou plus | moins de 15 % après 40 appels : changer l'accroche d'ouverture (passer de la 1 à la 3) ou la liste (garder les installateurs qui grandissent) |
| Démonstrations → essais signés | 1 sur 5 ou mieux | 0 essai après 10 démonstrations : reprendre les objections notées, puis `/founder-offer` ou `/founder-pricing` |
| Coût par essai signé (temps + frais, hors mise en service) | 150 € ou moins | plus de 300 € : moins de déplacements, démonstrations en visio |

*Les chiffres du panel viennent d'acheteurs simulés, et les montants sont des projections. Seuls les vrais appels et les vraies démonstrations les confirment. Ce n'est pas un conseil juridique.*
