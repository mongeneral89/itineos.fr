# L'offre : programme « Installateurs fondateurs » d'Itinéos Sécurité

Méthode : le prisme Offre (équation de valeur), appliqué aux objections du [panel](panel/results.md), aux conditions du [conseil](board.md) et aux [prix](pricing.md). Ancien pitch : [pitch-v1.md](pitch-v1.md). Nouveau pitch : [pitch.md](pitch.md).

**Limite :** il n'existe pas encore de `founder/numbers.json`. Les coûts ci-dessous sont des **estimations en temps** (le tien) et des points à chiffrer, pas des montants vérifiés. `/founder-cfo` doit les valider avant toute signature.

## 1. La liste des problèmes (en mots d'acheteur)

**Avant d'acheter**
1. « Une seule personne : qui me dépanne si le créateur est malade ou arrête ? » (8 acheteurs sur 20)
2. « Qui d'autre dans la sécurité l'utilise déjà ? »
3. « Mes données coincées chez un éditeur qui disparaît. »
4. « 12 mois d'engagement pour un logiciel que je n'ai pas vu tourner chez moi. » (12 sur 20)
5. « Pour le multi-agences, je dois prendre la formule la plus chère. »
6. « 45 € par technicien, ça fait plus de 500 € par mois. »
7. « Ça ne facture pas et ne prélève pas mes abonnements de télésurveillance. »
8. « J'ai déjà un ERP : je paierais deux logiciels. »
9. « Un généraliste repeint aux couleurs de la sécurité. »
10. « Le serveur chez moi, c'est moi qui gère pannes et sauvegardes. »

**Pendant la mise en route**
11. « Reprendre clients, centrales et numéros d'abonné, c'est des semaines. »
12. « Je n'ai pas le temps, je suis sur les chantiers. »
13. « Mes techniciens de plus de 50 ans ne voudront pas d'une appli. »
14. « Je vais encore ressaisir les consignes pour mon télésurveilleur. »
15. « Ça remplace ou ça se branche sur EBP ? »

**Après**
16. « Si mes techniciens n'adoptent pas, je suis coincé. »
17. « Et la facture électronique obligatoire, c'est réglé ? »
18. « Le stock par camionnette n'est que dans la formule la plus chère. »
19. « Quand on sera nombreux à appeler en même temps, il suivra ? »

## 2. Solutions, notées et triées

Valeur pour l'acheteur et coût pour toi, de 1 (faible) à 5 (fort).

| # | Solution | Valeur | Coût | Garder ? |
|---|---|:-:|:-:|---|
| 1, 19 | Délai de réponse du support écrit au contrat (4 h ouvrées) | 5 | 2 | Oui |
| 1, 3 | Code source déposé chez un tiers de confiance, remis aux clients si l'éditeur cesse son activité | 5 | 2 (coût annuel à chiffrer) | Oui |
| 3 | Export complet des données en fichiers standards sous 5 jours ouvrés | 5 | 1 (fait à la main aujourd'hui : pas d'écran d'export) | Oui |
| 2 | Programme limité à 5 « fondateurs » qui deviennent les références | 5 | 1 | Oui |
| 4, 16 | Sans engagement + essai de 60 jours sur une agence, arrêt sans frais | 5 | 2 (ton temps pendant l'essai) | Oui |
| 5, 18 | Multi-agences dans toutes les formules ; stock dans la formule Sécurité | 4 | 1 | Oui |
| 6 | Sécurité à 39 € ; −15 % au-delà du 20e technicien | 4 | 2 (revenu en moins, à faire valider par le CFO) | Oui |
| 8, 15 | Formule Terrain à 25 € qui se branche à côté de l'ERP (export) | 4 | 3 (export à construire ou à faire à la main) | Oui, à préciser |
| 11, 12 | Reprise des données faite par le créateur, sur place | 5 | 4 (1 à 3 jours par client) | **Oui, seulement pour les 5 fondateurs** |
| 13 | Formation des techniciens sur place, une demi-journée | 4 | 3 | Oui, pour les fondateurs |
| 10 | Hébergé en France, sauvegarde chaque nuit, ou installé chez le client | 4 | 2 (coût d'hébergement à chiffrer) | Oui |
| 7 | Facturation en lot et prélèvement SEPA des abonnements | 5 | 5 (à développer) | **Pas promis : affiché comme « pas encore disponible »** |
| 14 | Envoi automatique des consignes au télésurveilleur | 4 | 5 (dépend de chaque télésurveilleur) | Non pour l'instant ; à explorer avec le partenaire d'ARGE |
| 17 | Factur-X déjà en place | 4 | 1 | Oui (déjà construit) |

## 3. Le montage

- **Le cœur** (décrit par le résultat) : *vos techniciens remplissent vos propres fiches, consignes et bons de sortie sur leur téléphone, même au sous-sol, et le client signe ; au bureau, la facture est prête le soir même.*
- **Bonus 1 : la reprise faite pour vous.** Le créateur reprend clients, sites, centrales et documents. Il répond à « des semaines de reprise » et « je n'ai pas le temps ».
- **Bonus 2 : une demi-journée de formation des techniciens sur place.** Elle répond à « mes techniciens de 50 ans ».
- **Bonus 3 : le prix bloqué 24 mois.** Il répond à la peur d'une hausse une fois le client installé.
- **Les garanties (écrites dans le contrat) :**
  - sans engagement, arrêt sans frais à la fin de l'essai ;
  - export complet de toutes les données sous 5 jours ouvrés, à tout moment ;
  - réponse du support sous 4 h ouvrées ;
  - code source déposé chez un tiers de confiance.
- **Ce qui est rare, et vrai :** 5 places de fondateurs, jusqu'au 31 mars 2027. Tu ne peux pas faire la reprise sur place pour plus de 5 clients à la fois. La limite est donc réelle : il faut la respecter.
- **Le nom :** « Installateurs fondateurs ».
- **Ce qui est dit honnêtement :** le prélèvement SEPA automatique n'existe pas encore. Pour ceux qui l'ont dans leur ERP, la formule Terrain se branche à côté.

**Ce qui doit être vrai avant d'envoyer cette offre :**
- un contrat de dépôt du code source chez un tiers (par exemple l'APP, l'Agence pour la protection des programmes) ;
- une procédure d'export complet ;
- un hébergement en France chiffré ;
- l'avis d'un juriste sur les clauses (délai de support, réversibilité). Ce n'est pas un conseil juridique.

## 4. L'équation de valeur, avant et après

Note de 1 à 10 ; pour le temps et l'effort, une note haute veut dire « court » ou « faible ».

| Élément | Avant | Après | Ce qui le fait bouger |
|---|:-:|:-:|---|
| Résultat rêvé | 6 | 7 | Le cœur est décrit par le résultat (facture le soir même), plus par la liste des modules |
| Probabilité perçue d'y arriver | 2 | 5 | Garanties écrites, dépôt du code, export, programme de références. Le plafond reste bas tant qu'aucun vrai client n'est cité |
| Délai avant le résultat | 4 | 6 | Essai sur une seule agence, reprise faite pour le client |
| Effort et sacrifice | 3 | 7 | Reprise et formation sur place, sans engagement, arrêt sans frais |

Le point faible reste la **probabilité perçue**. Seul un vrai client cité (ARGE) peut la faire monter au-delà de 5.

## 5. Nouveau test sur le panel

Mêmes 20 acheteurs (graine 916646), même méthode, nouveau [pitch](pitch.md). Détail : [panel-v2/results.md](panel-v2/results.md).

| | Panel 1 (ancien pitch) | Panel 2 (offre fondateurs) |
|---|:-:|:-:|
| Acheteurs qui disent oui | 0 sur 20 (0 %) | 2 sur 20 (10 %) |
| Refus pour confiance | 8 | 7 |
| Refus par habitude | 9 | 7 |
| Refus pour le prix | 2 | 3 |
| Refus par besoin (SEPA) | 1 | 1 |
| Prix « une bonne affaire » (médiane, € HT/technicien/mois) | 25 | 20 |
| Prix « cher » (médiane) | 40 | 35 |
| Prix « trop cher » (médiane) | 60 | 50 |

**Ce qui a marché.** Les deux oui viennent d'entreprises qui grandissent (P002 vient de passer à deux agences, P010 vient d'en racheter une). Ils citent tous les deux la même chose : l'essai gratuit sur une seule agence, avec la reprise des données et la formation faites par le créateur. Les objections « 12 mois d'engagement », « multi-agences réservé à la formule la plus chère » et « reprise des données » ont disparu des refus.

**Attention : ces deux oui sont des oui à l'essai, pas à l'abonnement.** Les deux disent qu'ils paieront seulement si leurs techniciens adoptent l'outil. C'est un premier pas réel, mais ce n'est pas encore un client qui paie.

**Ce qui n'a pas bougé.**
- **La confiance** (7 refus). Les garanties écrites (export, dépôt du code, support sous 4 h) ne suffisent pas. Ce qui ferait changer d'avis est presque toujours le même : *parler à deux ou trois installateurs qui l'utilisent depuis six mois* et *savoir qui assure le support à part le fondateur*. La phrase « les premières références, ce sera vous » est honnête, mais plusieurs acheteurs l'ont lue comme « vous serez le cobaye ».
- **Le prélèvement SEPA** des abonnements de télésurveillance. Il revient dans 5 réponses. Pour les entreprises déjà sur un ERP, sans SEPA, Itinéos reste « un deuxième logiciel à payer ».
- **Le prix pour les gros.** À 35 techniciens, la formule Sécurité fait environ 1 200 € HT par mois ; un acheteur demande un forfait groupe plafonné vers 1 000 €.

**Prix.** Les prix jugés acceptables ont baissé d'environ 5 € par rapport au premier panel. C'est en partie normal : les acheteurs se calent sur les prix affichés, qui ont baissé eux aussi (Sécurité passe de 45 à 39 €). La formule Sécurité à 39 € se situe pile au seuil « cher » (35 €) et sous le « trop cher » (50 €). À vérifier avec `/founder-pricing` sur `panel-v2/answers`.

**Conclusion.** L'offre a levé les freins pratiques (engagement, reprise, essai). Le frein principal est maintenant la preuve : aucun prospect simulé ne croit un éditeur d'une seule personne sans confrère à appeler. La suite la plus utile n'est pas de retoucher l'offre, mais de :
1. faire d'ARGE une référence citable (avec leur accord écrit) : c'est le seul levier qui peut faire monter la probabilité perçue au-delà de 5 ;
2. nommer un support de secours (une personne ou une société partenaire) et l'écrire dans le contrat ;
3. décider si le prélèvement SEPA entre dans la feuille de route avant le lancement.

Ces 20 acheteurs sont simulés. Il faut confirmer ces trois points avec de vrais installateurs avant de dépenser.
