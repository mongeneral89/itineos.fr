# D'où viennent les chiffres de numbers.json

Légende : **[toi]** = ta réponse du 23/10/2026 ; **[public]** = prix public à revérifier sur le site ; **[estimation]** = mon estimation, à remplacer par un vrai devis.

Tous les montants sont en euros HT. L'outil de calcul affiche « $ », mais ce sont des euros.

## Ce que tu as dit [toi]
- Micro-entreprise aujourd'hui, passage en SASU prévu.
- Pas de salaire tout de suite ; objectif : **2 500 € net par mois minimum, le plus vite possible**.
- ARGE : une version à part, **pas gratuite mais à prix réduit**, en échange de sa communication sur Itinéos et de clients apportés.
- Mise de départ : **moins de 2 000 €**.

## Le prix : 35 € par technicien et par mois [estimation]
Prix moyen pondéré, pas un prix de la grille :
- ARGE : 12 techniciens (estimation : 4 agences ; la version ARGE n'a que des personnes fictives) à **25 €** (prix réduit supposé, à fixer avec ARGE).
- Les autres clients : environ 37 € en moyenne (mélange supposé de 20 % Terrain à 25 €, 70 % Sécurité à 39 €, 10 % Groupe à 49 €, voir [pricing.md](pricing.md)).
- À 74 techniciens (mois 12) : (12 × 25 + 62 × 37) / 74 ≈ 35 €.

## Coûts par technicien et par mois
| Ligne | Montant | Source |
|---|---:|---|
| Cotisations sociales micro-entreprise | 9,03 € | [public, à confirmer] 25,6 % (taux BNC 2026, plafonné par décret) + 0,2 % de formation professionnelle, sur 35 € (voir ops.md, § 6). Si l'URSSAF classe ton activité en prestations de services commerciales (BIC), le taux est d'environ 21,2 %. **À confirmer avec un comptable.** |
| Frais de prélèvement SEPA | 0,25 € | [public] GoCardless : 1 % + 0,20 €, plafonné à 2 € par prélèvement ; 2 € / 8 techniciens (voir ops.md, § 2) |
| Hébergement et stockage en plus | 0,50 € | [estimation] photos et PDF des interventions |

## Coûts fixes par mois
| Ligne | Montant | Source |
|---|---:|---|
| Serveur en France avec sauvegarde | 20 € | [estimation] serveur 2 processeurs / 4 Go (voir DEPLOIEMENT.md) chez OVHcloud ou Scaleway, plus sauvegarde |
| Domaine et messagerie pro | 8 € | [estimation] |
| Responsabilité civile pro informatique | 40 € | [estimation] environ 500 € par an ; demander un devis |
| Dépôt du code source chez un tiers | 40 € | [estimation] abonnement annuel (par exemple à l'APP) ; demander le tarif |
| Compte développeur Apple | 8 € | [public] 99 $ par an |
| Compte bancaire pro | 10 € | [estimation] |
| Téléphone et outils | 25 € | [estimation] |
| Déplacements de prospection et de démonstration | 100 € | [estimation] |
| Support de secours (astreinte d'un développeur indépendant) | 150 € | [estimation] environ 3 heures par mois, à négocier (voir ops.md, § 3) |
| Plateforme agréée pour tes propres factures | 10 € | [estimation] prix non trouvé (voir ops.md, § 2) |

## Dépenses de départ
| Ligne | Montant | Source |
|---|---:|---|
| Avis d'un juriste (contrat, conditions générales, clauses support et réversibilité) | 800 € | [estimation] |
| Dépôt initial du code source chez un tiers | 300 € | [estimation] |
| Marque Itinéos à l'INPI, 2 classes (9 et 42) | 230 € | [public, à vérifier] 190 € pour une classe en ligne + 40 € par classe en plus |
| Reprise et formation sur place chez 5 fondateurs | 1 250 € | [estimation] 250 € de trajet et de nuit par client |

## La montée en charge (techniciens payés chaque mois)
Mois 1 = novembre 2026. Recalée le 23/10/2026 sur l'envoi de l'offre le **11 janvier 2027** (voir [launch.md](launch.md)).

| Mois | nov. | déc. | janv. | févr. | mars | avr. | mai | juin | juil. | août | sept. | oct. |
|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| Techniciens payés | 0 | 0 | 0 | 12 | 12 | 20 | 28 | 36 | 42 | 42 | 48 | 54 |

Comment je l'ai construite [estimation] :
- ARGE : présentation à la direction faite, présentation à l'équipe et négociation du contrat à venir. Je suppose une signature en décembre, une mise en route en janvier et un **premier paiement en février 2027** (12 techniciens, nombre estimé).
- Fondateurs : l'offre part le 11 janvier. 5 essais signés entre fin janvier et fin mars (2 mises en service par mois au maximum, voir [ops.md](ops.md)). Chaque client a 8 techniciens en moyenne et **paie après les 60 jours d'essai**, donc d'avril à juin.
- **Un fondateur sur cinq arrête après l'essai.** Les deux « oui » du panel étaient des oui à l'essai seulement.
- À partir de juillet, un nouveau client de 6 techniciens par mois, sauf en août.
- Vérification avec le panel : 10 % des prospects acceptent l'essai. Pour 5 essais, il faut donc environ **50 prospects sérieux** entre janvier et mars. C'est le point le moins sûr du plan.
