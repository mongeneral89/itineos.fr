# Conseil d'administration : Itinéos recentré sur l'alarme et la vidéosurveillance

**Vote : 3 « financer sous conditions » (FUND IF), 0 « financer », 0 « refuser ». Note moyenne : 5,3 / 10** (Offre 5, Monopole 5, Produit 6).

Mémos complets : [offers.md](board/offers.md), [monopoly.md](board/monopoly.md), [product.md](board/product.md).

## Les risques soulevés par plusieurs membres (en premier)

1. **Aucune preuve client** (les trois). Aucun client payant, et ARGE ne peut pas être cité sans son accord écrit. Les dirigeants du secteur changent rarement de logiciel ; sans référence du métier, la confiance reste basse et la distribution n'est pas démontrée.
2. **Un produit et une offre généralistes sous une étiquette sectorielle** (les trois). La grille 29/45/65 € est reprise telle quelle ; le produit garde 16 langues, multi-sociétés, six éditions et deux modes d'installation. Rien dans le prix, le nom ou les écrans ne dit encore « fait pour l'installateur de sécurité ».
3. **Taille du marché, équipement actuel et coût d'acquisition inconnus** (Offre, Monopole). Combien d'installateurs de 3 à 50 techniciens en France, et combien ont déjà un logiciel ? Un fondateur seul qui prospecte par e-mails et appels peut ne pas atteindre assez d'acheteurs.
4. **Une mise en route qui dépend du fondateur** (Produit, et Monopole sur la distribution). ARGE a été préparé à la main ; si chaque client exige la même préparation, la mise en service à 300 € et l'essai de 30 jours ne tiennent pas, et la cadence non plus.

## Les risques propres à un seul membre

- **Pas de barrière à la copie** (Monopole). Les documents métier se reproduisent en quelques semaines par un éditeur concurrent. Il faut une piste de barrière durable : intégration avec les télésurveilleurs, historique du parc installé, partenariat de distribution.
- **La jointure avec le télésurveilleur** (Produit). Ce que deviennent les consignes et bons de sortie après signature n'est pas décrit : c'est là que l'expérience peut casser.

## Où les membres ne sont pas d'accord

- **Le levier principal.** Le prisme Offre veut d'abord une offre et un prix construits pour le secteur (et pense que le prix pourrait monter avec une formule « clé en main sécurité ») ; le prisme Produit veut d'abord épurer le produit lui-même ; le prisme Monopole veut d'abord la carte concurrentielle et une barrière.
- **L'installation chez le client.** Le prisme Monopole y voit un atout pour des entreprises de sécurité attachées à leurs données ; le prisme Produit y voit une complexité de plus à trancher (garder un seul mode ?).

## Les conditions, fusionnées (liste à cocher pour la suite)

- [ ] **Marché dimensionné** : nombre d'installateurs cibles, part déjà équipée, outils en place et leurs prix, plaintes des clients. → `/founder-competitors`
- [ ] **Un angle où Itinéos est nettement supérieur**, ou la preuve qu'aucun acteur ne domine la niche. → `/founder-competitors`
- [ ] **Le résultat que le dirigeant veut vraiment** (moins de ressaisie, contrats facturés à temps, conformité CNAPS, Factur-X…) et sa volonté de payer. → `/founder-consumer`
- [ ] **Un prix propre au secteur**, testé (y compris une formule plus chère « clé en main »). → `/founder-pricing`, `/founder-offer`
- [ ] **Une offre propre au secteur** : nom, contenu, reprise des documents et du parc incluse dans la mise en service, garantie chiffrée. → `/founder-offer`
- [ ] **Une garantie et un coût de mise en service réels**, validés par les chiffres. → `/founder-cfo`
- [ ] **Coût d'acquisition d'un client mesuré** et un objectif de part de marché crédible sur un sous-segment (une région, ou les multi-agences). → `/founder-cfo`, `/founder-marketing`
- [ ] **Une édition sécurité réellement épurée** : écrans, vocabulaire, modèles et offres du métier ; le reste caché. → décision produit
- [ ] **Une mise en route reproductible sans le fondateur** : import des clients, sites et matériels, modèles sécurité prêts à l'emploi, testés chez un installateur autre qu'ARGE. → `/founder-ops`
- [ ] **La jointure télésurveilleur traitée** (ou déclarée hors périmètre), validée auprès d'installateurs réels. → `/founder-ops`
- [ ] **Une piste de barrière** engagée : télésurveilleurs partenaires, grossistes, fédérations, historique du parc. → `/founder-marketing`, `/founder-ops`
- [ ] **Une preuve réelle** : ARGE (ou un autre installateur) client payant, retour écrit des techniciens, résultat mesuré, accord écrit pour être cité. → `/founder-launch`

## La version la plus forte que le conseil voit

Pas « Itinéos pour tous les métiers, avec une version sécurité », mais **le logiciel de terrain de l'installateur de sécurité électronique**, et rien d'autre : un produit épuré dont la fiche s'ouvre déjà remplie avec la centrale, le numéro d'abonné et l'historique du site, qui produit les consignes et bons de sortie que le télésurveilleur attend, et qui facture les contrats de maintenance à temps (Factur-X compris). Il se vendrait comme une formule clé en main, peut-être plus chère que la grille actuelle, mise en service à partir des documents et du parc du client, avec une garantie de démarrage. Il commencerait par un sous-segment que le fondateur peut dominer seul (par exemple les multi-agences d'une région) et s'appuierait sur ARGE comme première référence écrite. Cela diffère du projet présenté sur deux points : le prix et l'offre ne seraient plus ceux du produit généraliste, et la priorité ne serait pas d'élargir la prospection mais d'obtenir d'abord une preuve chez un vrai client.
