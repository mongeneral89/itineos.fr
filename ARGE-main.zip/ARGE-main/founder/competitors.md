# Concurrents : Itinéos pour installateurs d'alarme et de vidéosurveillance

Relevé du 23 octobre 2026, sources publiques uniquement (pages des éditeurs, comparateurs). Données brutes : [competitors.csv](competitors.csv).

**Limite importante :** Capterra, GetApp et Google Play ont refusé la lecture (erreurs 403/404). Je n'ai donc **pas pu lire d'avis négatifs** de clients. La partie « plaintes » ci-dessous est **mince** et doit être complétée à la main (voir la fin).

## 1. Le tableau, du plus direct au moins direct

| Concurrent | Type | Ce qu'il vend | Prix comparable | Sa phrase d'accroche |
|---|---|---|---|---|
| [Le Terrain](https://leterrain.co/securite-electronique) | Direct | Interventions, rapports de maintenance, parc par site, contrats, devis/factures par IA, dictée par WhatsApp. **En accès anticipé.** | Non publié (démo 15 min) | « Arrêtez la paperasse de maintenance. Gagnez 15 heures par semaine grâce à l'IA. » |
| [Sustencio](https://www.sustencio.com/systemes-securite) | Direct | Contrats de maintenance incendie, alarme et vidéo, planning, rapports signés, espace client | Forfait : 30 € (solo), 100 € (TPE/PME < 100 utilisateurs), 500 € (entreprise), période non précisée | « Simplifiez vos interventions d'entretien de systèmes de sécurité. » |
| [CMII – W'IPSOS](https://cmii.fr/logiciel-gestion/securite-incendie/alarme-intrusion/) | Direct | ERP complet : contrats, facturation récurrente, **prélèvement des abonnements**, visites préventives, parc et n° de série, appli IP'Connect, stock | Non publié | « Spécialiste de votre métier depuis 1979 » ; références affichées : Scutum, Securitas, Def Sûreté… |
| [Capasoft – Kéops](https://www.capasoft.fr/e-r-p-securite/) | Direct | ERP cloud sécurité électronique : facturation périodique et prélèvement SEPA, maintenance préventive, chantiers, devis, stock par dépôt et véhicule | Non publié | « Logiciels pour l'industrie de la sécurité électronique » ; « plus de 25 ans » |
| [Praxedo](https://www.praxedo.com/our-industries/remote-monitoring-and-electronic-security/) | Direct (généraliste avec page sécurité) | Gestion d'interventions, appli mobile hors ligne, rapports, portail client, connecteurs ERP ; clients cités : **Nexecur**, Intelgest | [35 / 59 / 89 / 129 € par utilisateur/mois, minimum 5](https://www.praxedo.fr/tarifs/) | « Security solution providers: give your customers top-notch service quality. » |
| [Infocob](https://www.infocob.com/logiciel-prevention-securite-incendie/) | Indirect | CRM incendie/télésurveillance : parc par site, n° de série, historique, branché sur EBP/Sage/Cegid | Non publié | « Maintenance et suivi réglementaire » |
| [Organilog](https://www.blogdumoderateur.com/tools/organilog/) | Indirect (généraliste) | Planning et appli d'intervention pour TPE/PME | 19 / 35 / 59 € HT par utilisateur/mois (annuel) | — |
| [ArtisanSmart](https://artisansmart.fr/metiers/installateur-securite.html) | Indirect | Devis et factures pour installateurs de sécurité (NF A2P, RGPD vidéo, Factur-X), **sans** interventions ni appli terrain | 29 € HT/mois, sans engagement | « Logiciel de devis et factures pour installateurs de sécurité » |
| [Kizeo Forms](https://www.appvizer.fr/operations/gestion-des-interventions/kizeo-forms) | Substitut | Formulaires mobiles (bons d'intervention, photos, signature) | 15 €/utilisateur/mois (annuel), 22 € (mensuel) | — |
| [Odoo](https://www.odoo.com/zh_TW/customers/groupe-rvj-paca-11140374) | Substitut | ERP généraliste paramétré par un intégrateur ; un installateur alarme/vidéo (Groupe RVJ PACA) l'utilise pour interventions et contrats de télésurveillance | Non relevé | — |
| Papier + tableur + EBP/Sage | Substitut | Ce que les e-mails d'Itinéos disent remplacer : fiches papier ressaisies, facturation à part | Coût caché (ressaisie, retard de facturation) | — |

## 2. Fourchette de prix (par utilisateur et par mois, offres publiées)

- **Plus bas : 15 €** (Kizeo Forms, simples formulaires).
- **Médiane : 35 €** (Praxedo Basic, Organilog Business).
- **Plus haut : 129 €** (Praxedo Automated).
- Hors grille par utilisateur : ArtisanSmart 29 €/mois au total (devis/factures seulement) ; Sustencio au forfait (100 € pour une PME).
- **Les quatre spécialistes sécurité les plus complets (Le Terrain, CMII, Capasoft, Infocob) ne publient aucun prix.**
- Itinéos : 29 / 45 / 65 €. Essentiel est sous la médiane ; Pro (45 €) et Entreprise (65 €) restent nettement sous Praxedo à fonctions comparables.

## 3. Carte de positionnement (en texte)

Axes qui comptent pour l'installateur : **spécialisation sécurité** (horizontal) et **terrain/mobile d'abord vs. gestion/ERP d'abord** (vertical).

```
                       TERRAIN / APPLI D'ABORD
                                 |
      Kizeo Forms   Organilog    |   Le Terrain (accès anticipé)
                Praxedo          |        [ITINÉOS visé ici]
                                 |   Sustencio
 GÉNÉRALISTE --------------------+-------------------- SPÉCIALISTE SÉCURITÉ
                                 |
      Odoo                       |   Infocob
      EBP / Sage + papier        |   CMII W'IPSOS   Capasoft Kéops
                ArtisanSmart (devis)
                                 |
                        GESTION / ERP D'ABORD
```

- En haut à gauche : de bons outils de terrain, mais qui ne parlent pas le métier (pas de consignes de télésurveillance, de bons de sortie ni de n° d'abonné).
- En bas à droite : des ERP anciens et spécialisés, forts sur la facturation récurrente et le prélèvement des abonnements, avec une appli mobile secondaire et des prix non publiés.
- En haut à droite : **seuls Le Terrain (pas encore lancé) et Sustencio (léger, sans appli décrite)**.

## 4. Les plaintes des clients

**Mince : moins de trois avis lus pour chaque thème.** Les plateformes d'avis ont bloqué la lecture automatique.

- **Ergonomie et apprentissage (Organilog), mince.** Un comparatif relève une interface « parfois peu intuitive » avec une courbe d'apprentissage ([La Fabrique du Net](https://www.lafabriquedunet.fr/logiciel/organilog), résumé, pas un avis direct).
- **Fonctions contre prix (Synchroteam/Praxedo), mince.** Un utilisateur dit avoir choisi Synchroteam parce que le prix était plus intéressant, même avec moins de fonctions ([Capterra, résumé de recherche](https://www.capterra.com/p/129634/Synchroteam/reviews/?page=2)).
- **Rien de lisible** pour Le Terrain, Sustencio, CMII, Capasoft et Infocob.

Ce qu'il faut faire à la main : sur Capterra.fr et Google Play, lire les avis 1 à 3 étoiles de Praxedo, Organilog et Kizeo (mots-clés « synchro », « hors ligne », « prix », « support »). Mieux encore : poser la question directement à ARGE et à 5 installateurs.

## 5. Le trou (le « gap »)

D'après ce relevé, **personne ne propose publiquement les trois à la fois** :

1. **Les documents propres au métier**, repris tels quels : consignes de télésurveillance, bons de sortie télésurveillance et vidéoprotection, mentions CNAPS en pied de page. Aucune page lue ne mentionne les consignes ni les bons de sortie, et seul l'ERP de CMII parle du parc par abonnement.
2. **Une appli terrain moderne qui marche sans réseau**, au centre du produit. Les ERP spécialisés (CMII, Capasoft) la traitent en module annexe ; seul Praxedo, généraliste, met en avant le hors ligne.
3. **Un prix public, par technicien, avec bureau illimité.** Les spécialistes ne publient aucun prix ; Praxedo exige 5 utilisateurs minimum et facture chaque utilisateur.

Le trou existe, mais il est **étroit et temporaire** : Le Terrain vise exactement la même case, avec l'IA comme argument, et lance en ce moment.

**Ce qu'Itinéos n'a pas et que les spécialistes ont :** le **prélèvement automatique des abonnements de télésurveillance** (CMII, Capasoft). Pour un installateur, ces abonnements sont souvent un revenu récurrent important ; c'est à vérifier avec ARGE.

## 6. La menace : qui peut copier le plus vite

- **Le Terrain** : même cible, même promesse, en lancement. S'il ajoute consignes et bons de sortie, il occupe la case. C'est le concurrent à surveiller en premier.
- **Praxedo** : déjà chez Nexecur, appli hors ligne, connecteurs ERP, page sécurité dédiée. Il lui suffirait de modèles de documents sécurité pour couvrir le terrain ; il est en revanche plus cher et ne vend pas en dessous de 5 utilisateurs.
- **CMII et Capasoft** : ils ont la clientèle et la facturation récurrente. Une appli terrain plus moderne les rendrait très difficiles à déloger.

Prochaines étapes : `/founder-consumer` utilisera ces points pour écrire les objections des acheteurs, et `/founder-pricing` utilisera la fourchette de prix (15 à 129 €, médiane 35 €).
