#!/bin/sh
# Sauvegarde quotidienne : base de données + fichiers (PDF des fiches, photos).
# Une sauvegarde au démarrage, puis toutes les 24 h. Les plus anciennes que BACKUP_KEEP_DAYS sont supprimées.
set -eu
KEEP="${BACKUP_KEEP_DAYS:-14}"

backup() {
  stamp="$(date +%Y-%m-%d_%H%M)"
  pg_dump --format=custom --file="/backups/itineo-db-$stamp.dump"
  tar -czf "/backups/itineo-fichiers-$stamp.tar.gz" -C /data storage
  find /backups -name 'itineo-*' -mtime +"$KEEP" -delete
  echo "[sauvegarde] $stamp terminée"
}

if [ "${1:-}" = "now" ]; then
  # Sauvegarde immédiate à la demande : docker compose … exec backup sh /scripts/backup.sh now
  backup
  exit 0
fi

# Au démarrage, on laisse le serveur créer ou mettre à jour la base avant la première sauvegarde
sleep 300
while true; do
  backup || echo "[sauvegarde] ÉCHEC $(date)" >&2
  sleep 86400
done
