# Mettre la console de supervision en ligne

La console doit être joignable par les Itinéos installés chez vos clients : il lui faut un serveur internet avec une
adresse https. Comptez une petite machine (2 Go de mémoire, 40 Go de disque, environ 5 à 10 € par mois chez OVH,
Scaleway, Hetzner, Infomaniak…) avec Docker.

## 1. Le serveur et l'adresse

1. Louez le serveur (Ubuntu ou Debian), installez Docker : `curl -fsSL https://get.docker.com | sh`.
2. Chez votre registraire de nom de domaine, faites pointer `supervision.votre-domaine.fr` vers l'adresse IP du serveur.
3. Ouvrez sur le pare-feu du serveur : **80 et 443** (console), **21115 à 21117 en TCP et 21116 en UDP** (RustDesk).

## 2. Installation

```bash
git clone https://github.com/gyann4398-sketch/ARGE.git itineo && cd itineo
cp deploy/supervision/.env.example deploy/supervision/.env
nano deploy/supervision/.env          # DOMAIN, deux secrets (openssl rand -base64 32), SMTP pour les alertes
docker compose -f deploy/supervision/docker-compose.yml --env-file deploy/supervision/.env up -d --build
```

Le certificat https est obtenu tout seul au premier accès à `https://supervision.votre-domaine.fr`.

## 3. Premier compte, puis double authentification

```bash
docker compose -f deploy/supervision/docker-compose.yml exec console npx tsx src/create-operator.ts --email vous@votre-domaine.fr --name "Prénom Nom"
```

Connectez-vous, puis **Mon compte → Activer la double authentification** (application Google Authenticator,
Microsoft Authenticator, 2FAS…). Sans elle, la prise en main, l'accès support, les mises à jour et les réglages sont
bloqués.

## 4. Clés de signature des mises à jour — à faire tout de suite

La console signe chaque version ; les installations refusent tout le reste. **Perdre la clé = ne plus pouvoir mettre
à jour vos clients.** Deux précautions, faites depuis votre PC ou le serveur :

```bash
# Clé de secours : créée une fois, gardée HORS du serveur (clé USB rangée, coffre-fort de mots de passe)
docker compose -f deploy/supervision/docker-compose.yml exec console npx tsx src/cles.ts secours /data/cle-secours-CHIFFREE.json
docker compose -f deploy/supervision/docker-compose.yml cp console:/data/cle-secours-CHIFFREE.json .
docker compose -f deploy/supervision/docker-compose.yml exec console rm /data/cle-secours-CHIFFREE.json

# Copie chiffrée de la clé principale
docker compose -f deploy/supervision/docker-compose.yml exec console npx tsx src/cles.ts sauvegarde /data/cle-principale-CHIFFREE.json
docker compose -f deploy/supervision/docker-compose.yml cp console:/data/cle-principale-CHIFFREE.json .
```

Les deux fichiers sont protégés par un mot de passe (12 caractères au moins) : gardez-le séparément. Les installations
apprennent la clé de secours à leur passage suivant. Si la clé principale est perdue ou volée : copiez la clé de
secours sur le serveur et `npx tsx src/cles.ts restaurer /data/cle-secours-CHIFFREE.json` ; les installations
oublient alors l'ancienne clé. Créez ensuite une nouvelle clé de secours.

## 5. Serveur RustDesk (prise en main)

Récupérez la clé publique du serveur RustDesk :

```bash
docker compose -f deploy/supervision/docker-compose.yml exec rustdesk-hbbs cat /root/id_ed25519.pub
```

Dans la console : **Réglages → Serveur de prise en main** : `supervision.votre-domaine.fr` et cette clé. Les
installations s'y règlent à leur passage suivant.

## 6. Sauvegardes

Chaque nuit, la base et les données de la console vont dans `deploy/supervision/sauvegardes` (30 jours). Copiez ce
dossier ailleurs régulièrement (autre serveur, stockage en ligne). Sauvegarde immédiate :
`docker compose -f deploy/supervision/docker-compose.yml exec backup sh /scripts/backup.sh now`.

## 7. Relier une installation

Console → **Clients → Nouvelle installation** : un code d'inscription complet, qui contient l'adresse de la console
(`https://supervision.votre-domaine.fr/ABCD-EFGH-JKLM`). Chez le client, il se colle dans l'installateur d'Itinéos.
