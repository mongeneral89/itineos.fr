#!/bin/sh
# Sauvegarde quotidienne de la console : base (installations, bugs, historique) et données (versions publiées,
# clé de signature). Copiez aussi le dossier des sauvegardes ailleurs. La clé de signature n'est pas chiffrée ici :
# gardez EN PLUS sa copie chiffrée (npm run cles -- sauvegarde) et la clé de secours hors du serveur.
set -eu
KEEP="${BACKUP_KEEP_DAYS:-30}"
backup() {
  stamp="$(date +%Y-%m-%d_%H%M)"
  pg_dump --format=custom --file="/backups/supervision-base-$stamp.dump"
  tar -czf "/backups/supervision-donnees-$stamp.tar.gz" -C /data console
  find /backups -name 'supervision-*' -mtime +"$KEEP" -delete
  echo "[sauvegarde] $stamp terminée"
}
if [ "${1:-}" = "now" ]; then backup; exit 0; fi
sleep 300
while true; do
  backup || echo "[sauvegarde] ÉCHEC $(date)" >&2
  sleep 86400
done
