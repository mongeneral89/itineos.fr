#!/bin/bash
# Installe ou met à jour A.R.G.E. sur une machine Linux (VM de la Freebox Delta, Debian ou Ubuntu, ARM ou x64).
# Lancé depuis le PC par lanceurs\installer-vm.ps1, qui copie d'abord le code dans /opt/arge.
#
#   sudo bash /opt/arge/deploy/installer-vm.sh --domaine serveur.arge.events-gs.fr \
#        --email vous@arge.fr --prenom Prénom --nom Nom     (première installation : compte administrateur)
#   sudo bash /opt/arge/deploy/installer-vm.sh               (mise à jour : les réglages sont gardés)
#
#   --demo : remplit la base avec les données d'essai A.R.G.E. (comptes fictifs, mot de passe demo1234).
#            Seulement pour essayer : ces comptes sont accessibles depuis Internet.
set -euo pipefail

DIR=/opt/arge
ENVF="$DIR/.env.production"
DOMAINE="" EMAIL="" PRENOM="" NOM="" DEMO=0

while [ $# -gt 0 ]; do
  case "$1" in
    --domaine) DOMAINE="$2"; shift 2 ;;
    --email) EMAIL="$2"; shift 2 ;;
    --prenom) PRENOM="$2"; shift 2 ;;
    --nom) NOM="$2"; shift 2 ;;
    --demo) DEMO=1; shift ;;
    *) echo "Option inconnue : $1" >&2; exit 1 ;;
  esac
done

say() { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
fail() { printf '\n\033[1;31mERREUR : %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "lancez ce script avec sudo"
[ -f "$DIR/docker-compose.prod.yml" ] || fail "le code d'A.R.G.E. n'est pas dans $DIR"
cd "$DIR"

# ─── Docker ───
if ! command -v docker >/dev/null 2>&1; then
  say "Installation de Docker (quelques minutes)"
  apt-get update -qq
  apt-get install -y -qq curl ca-certificates openssl >/dev/null
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker >/dev/null 2>&1 || true
command -v openssl >/dev/null 2>&1 || { apt-get update -qq; apt-get install -y -qq openssl >/dev/null; }

# ─── Mémoire d'appoint : la VM de la Freebox n'a qu'1 Go (installation des modules, base, serveur) ───
mem_mb=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
if [ "$mem_mb" -lt 3500 ] && ! swapon --show | grep -q .; then
  say "Ajout de 3 Go de mémoire d'appoint (fichier d'échange)"
  fallocate -l 3G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=3072 status=none
  chmod 600 /swapfile
  mkswap /swapfile >/dev/null
  swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

# ─── Réglages (créés une seule fois, gardés ensuite) ───
FIRST=0
if [ ! -f "$ENVF" ]; then
  [ -n "$DOMAINE" ] || fail "première installation : indiquez --domaine"
  FIRST=1
  say "Création des réglages ($ENVF)"
  # Secrets en hexadécimal : pas de caractère spécial dans l'adresse de la base
  umask 077
  cat > "$ENVF" <<EOF
# Réglages d'A.R.G.E. sur ce serveur. À garder précieusement (copie hors du serveur) : sans ce fichier,
# impossible de relire les sauvegardes de la base. Ne l'envoyez jamais par e-mail.
EDITION=TECH
# Logo et nom A.R.G.E. sur l'écran de connexion (apps/web/.env.arge)
WEB_MODE=arge
# Appli web construite sur le PC (deploy/web-dist) : la VM n'a pas assez de mémoire pour le faire
PREBUILT_WEB=1
DOMAIN=$DOMAINE
POSTGRES_PASSWORD=$(openssl rand -hex 32)
JWT_SECRET=$(openssl rand -hex 48)
# Envoi des e-mails (fiches PDF, mots de passe oubliés), ex. smtps://utilisateur:motdepasse@smtp.fournisseur.fr:465
SMTP_URL=
MAIL_FROM="A.R.G.E. <no-reply@$DOMAINE>"
VAPID_PUBLIC_KEY=
VAPID_PRIVATE_KEY=
BACKUP_KEEP_DAYS=14
EOF
  umask 022
elif [ -n "$DOMAINE" ] && ! grep -q "^DOMAIN=$DOMAINE\$" "$ENVF"; then
  sed -i "s|^DOMAIN=.*|DOMAIN=$DOMAINE|" "$ENVF"
  say "Adresse changée : $DOMAINE"
fi
grep -q '^PREBUILT_WEB=' "$ENVF" || echo 'PREBUILT_WEB=1' >> "$ENVF"

# ─── Notifications de l'appli Android : compte de service Firebase (secret, lisible par le serveur seulement) ───
mkdir -p secrets
FCM_FILE=secrets/firebase-service-account.json
if [ -f "$FCM_FILE" ]; then
  chown -R 1000:1000 secrets   # utilisateur « node » du conteneur
  chmod 700 secrets; chmod 600 "$FCM_FILE"
  grep -q '^FCM_SERVICE_ACCOUNT_FILE=' "$ENVF"     || echo 'FCM_SERVICE_ACCOUNT_FILE=/run/arge-secrets/firebase-service-account.json' >> "$ENVF"
fi
DOMAINE=$(sed -n 's/^DOMAIN=//p' "$ENVF")

dc() { docker compose -f docker-compose.prod.yml --env-file "$ENVF" -p arge "$@"; }

# ─── Sauvegarde avant une mise à jour ───
if [ "$FIRST" -eq 0 ] && dc ps --status running --services 2>/dev/null | grep -qx backup; then
  say "Sauvegarde avant la mise à jour"
  dc exec -T backup sh /scripts/backup.sh now || echo "(sauvegarde impossible, on continue)"
fi

say "Construction et démarrage (la première fois : 10 à 30 minutes sur la Freebox)"
mkdir -p backups
dc up -d --build --remove-orphans

say "Attente du serveur"
for i in $(seq 1 90); do
  if dc exec -T api wget -qO- http://127.0.0.1:3000/api/health >/dev/null 2>&1; then break; fi
  [ "$i" -eq 90 ] && { dc logs api --tail 50; fail "le serveur ne répond pas"; }
  sleep 4
done

# ─── Premier compte ───
if [ "$FIRST" -eq 1 ]; then
  if [ "$DEMO" -eq 1 ]; then
    say "Données d'essai A.R.G.E."
    dc exec -T api npm run -s db:seed-arge
    echo "ATTENTION : comptes d'essai (demo1234) accessibles depuis Internet. Changez leurs mots de passe ou"
    echo "désactivez-les avant d'y mettre de vraies données."
  elif [ -n "$EMAIL" ] && [ -n "$PRENOM" ] && [ -n "$NOM" ]; then
    say "Compte administrateur"
    dc exec -T api npm run -s admin:create -- --email "$EMAIL" --first "$PRENOM" --last "$NOM" --group "Groupe A.R.G.E."
  else
    echo "Aucun compte créé (ni --email/--prenom/--nom, ni --demo)."
  fi
fi

dc image prune -f >/dev/null 2>&1 || true

say "A.R.G.E. est en place"
echo "  Logiciel du bureau : https://$DOMAINE"
echo "  Appli Android, champ « Serveur » : $DOMAINE"
echo "  Sauvegardes : $DIR/backups (chaque jour, 14 jours gardés)"
echo
echo "  Si https://$DOMAINE ne s'ouvre pas : vérifiez la zone DNS chez OVH et la redirection des"
echo "  ports 80 et 443 de la Freebox vers cette machine (voir FREEBOX-VM.md), puis : sudo bash $0"
