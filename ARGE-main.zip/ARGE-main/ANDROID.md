# Appli Android A.R.G.E. (APK d'essai)

L'appli terrain existe aussi en **vraie appli Android**. Ce sont les mêmes écrans que dans le navigateur (dossier
`apps/web`), rangés dans l'APK avec [Capacitor](https://capacitorjs.com). Seul le serveur est ailleurs : son adresse
se choisit sur l'écran de connexion.

C'est la **version A.R.G.E.** : appli nommée « A.R.G.E. » (identifiant `fr.arge.terrain`), logo du Groupe A.R.G.E.
en icône, à l'ouverture et sur l'écran de connexion (`apps/web/.env.arge`, `src/client.ts`). Après la connexion, ce sont
les données de la société A.R.G.E. du serveur (logo, agences, modèles de fiches).

| | Navigateur (bureau, téléphone) | Appli Android |
|---|---|---|
| Écrans | téléchargés depuis le site | rangés dans l'APK (s'ouvre sans réseau) |
| Serveur | la même adresse que le site | l'adresse saisie à la connexion, gardée ensuite |
| PDF, fichiers | nouvel onglet | ouverts dans l'appli du téléphone (lecteur PDF…) |
| Notifications | Web Push | pas encore (voir « À faire ») |

## Navigation de l'appli terrain

Pensée pour une main, dans le camion ou chez le client (`apps/web/src/tech/FieldShell.tsx`) :

- **Onglets en bas** : Journée, Messagerie (messages non lus), Annuaire, Notices, Plus.
- **Barre du haut** : le titre de la page, une flèche de retour sur les sous-pages, et l'état des envois quand il y a
  quelque chose à signaler (hors ligne, en attente, refusé).
- **Ma journée** : la date et l'avancement, puis l'intervention en cours (ou la prochaine) en grand avec toutes ses
  actions (ouvrir la fiche, je pars, sur place, Y aller), puis les suivantes, puis celles déjà faites.
- **Plus** : profil et logo de la société, planning de l'équipe, mon compte, accès au bureau, serveur, déconnexion.
- La **fiche d'intervention** reste en plein écran, sans les onglets.

Messagerie, annuaire, notices et compte s'affichent dans ce cadre pour les techniciens (navigateur compris) et pour
tout le monde dans l'appli Android ; les autres utilisateurs du navigateur les gardent dans le bureau.

## Construire l'APK

Il faut **Android Studio** sur le PC (pour Java et le SDK Android ; déjà installé sur ce PC).

Double-cliquez sur **`lanceurs\Construire l'APK Android.cmd`** : l'APK est construite (`apk\ARGE-terrain.apk`) puis
publiée (voir « Mises à jour automatiques »).

À la main :

```bash
npm run android:sync -w @itineo/web          # construit les écrans (mode arge) et les copie dans apps/web/android
cd apps/web/android && gradlew assembleDebug  # → app/build/outputs/apk/debug/app-debug.apk
```

Java 25 (celui d'Android Studio) demande Gradle 9 : c'est la version réglée dans
`apps/web/android/gradle/wrapper/gradle-wrapper.properties`.

## Mises à jour automatiques

Chaque construction avec **`lanceurs\Construire l'APK Android.cmd`** :

1. reçoit un numéro de version plus grand que le précédent (minutes écoulées depuis le 1er janvier 2026) et un nom
   daté (`2026.10.16-1212`) ;
2. demande les **nouveautés** à afficher sur les téléphones (Entrée pour aucune) ;
3. publie l'APK sur le serveur de ce PC (`apps/api/storage/app`) et **sur le FTP OVH**, dossier `/ARGE/appli`, soit
   **https://arge.events-gs.fr/appli/** : la page de téléchargement, l'APK et `android.json` (lu par l'appli).

Sur le téléphone, au lancement et à chaque retour dans l'appli (au plus toutes les 10 minutes), l'appli lit
`android.json`. Si la version est plus récente, un bandeau propose **Mettre à jour** : l'APK se télécharge, puis
Android ouvre son écran d'installation. **Plus tard** cache le bandeau jusqu'au prochain lancement. Onglet **Plus** :
version installée et « Rechercher une mise à jour ».

- La première fois, Android demande d'**autoriser l'installation depuis A.R.G.E.** (Paramètres, une seule fois).
- Android n'installe une mise à jour que si elle est **signée avec la même clé** que l'appli installée. Les APK
  publiées sont des versions « release » (non inspectables par câble), signées avec la **clé A.R.G.E.** créée à la
  première construction dans `%USERPROFILE%\.arge` (`arge-release.jks` et son mot de passe dans
  `signature.properties`). **Sauvegardez ce dossier** (clé USB, coffre-fort de mots de passe) : sans lui, les
  téléphones ne pourront plus recevoir de mises à jour (il faudrait désinstaller l'appli partout).
- L'appli vérifie l'**empreinte SHA-256** publiée dans `android.json` avant d'installer, et ne télécharge que depuis
  l'adresse https du fichier de version (ou depuis le serveur Itinéos lui-même). Au premier téléchargement, Android
  demande d'autoriser l'installation depuis A.R.G.E., puis Play Protect avertit que l'appli ne vient pas du Play
  Store : « Installer quand même ».
- **FTP sans chiffrement** : l'hébergement OVH actuel n'accepte ni FTPS ni SFTP, le mot de passe FTP circule donc en
  clair (comme pour LanShare). Conseil : dans l'espace client OVH, créer un utilisateur FTP réservé au dossier
  `/ARGE` et mettre ses identifiants dans `%USERPROFILE%\.arge\ftp.ini` ; l'APK, elle, reste protégée par sa
  signature et son empreinte.
- Identifiants FTP : `%USERPROFILE%\.arge\ftp.ini` (même format que celui de LanShare, avec `remote_dir`
  facultatif), sinon ceux de LanShare (`%USERPROFILE%\.lanshare\ftp.ini`). Jamais dans le projet.
- Construire sans publier : `lanceurs\construire-apk.ps1 -NoPublish`.
- Adresse lue par l'appli : `VITE_UPDATE_URL` dans `apps/web/.env.arge`. Sans elle, l'appli interroge le serveur
  Itinéos (`GET /api/app/android`, publication par un administrateur : `PUT /api/app/android?versionCode=…`).
- Fichiers envoyés sur le FTP : `lanceurs/appli-en-ligne` (page, règles du serveur : `android.json` lisible par
  l'appli et jamais gardé en cache, pas de liste des fichiers).

## Notifications (Firebase)

L'appli installée ne reçoit pas le Web Push des navigateurs : ses notifications (nouveau message, intervention
attribuée ou déplacée, document à valider) passent par **Firebase Cloud Messaging**, gratuit.

1. Projet sur https://console.firebase.google.com, appli Android `fr.arge.terrain`.
2. `google-services.json` dans `apps/web/android/app/` (hors Git) : sans lui, `construire-apk.ps1` construit une
   APK sans notifications (`VITE_PUSH`).
3. Compte de service (Paramètres du projet → Comptes de service → Générer une nouvelle clé privée), **secret**,
   rangé dans `%USERPROFILE%\.arge\firebase-service-account.json` : `Installer sur la VM Freebox.cmd` l'envoie dans
   `/opt/arge/secrets` et le serveur le lit par `FCM_SERVICE_ACCOUNT_FILE` (`apps/api/src/services/fcm.ts`).

À la connexion, l'appli demande l'autorisation, donne le jeton du téléphone au serveur (`/notifications/device`) et le
retire à la déconnexion. Une notification touchée ouvre sa page. Réglages par événement : Plus → Mon compte.

## Installer sur le téléphone

1. Sur le téléphone, ouvrez **https://arge.events-gs.fr/appli/** et touchez « Télécharger l'appli Android »
   (ou copiez `apk\ARGE-terrain.apk` par câble USB).
2. Ouvrez-le : Android demande d'autoriser l'installation depuis cette source (Fichiers, Drive…). Acceptez.
3. Une nouvelle version s'installe par-dessus l'ancienne, sans perdre la connexion.

## Se connecter

**Essais sur le PC** (même Wi-Fi que le téléphone) :

1. Lancez **Itinéos ARGE** (`lanceurs`) : la fenêtre affiche
   « Appli Android (APK), adresse du serveur : 192.168.x.x:3106 ».
2. Dans l'appli, saisissez cette adresse dans **Adresse du serveur**, puis un compte d'essai
   (`tech.dijon@arge.test`, mot de passe `demo1234`).
3. Si l'appli dit « Serveur injoignable » : autorisez Node.js dans le pare-feu Windows (réseau privé).

**Version en ligne** : saisissez l'adresse du site (par exemple `itineo.votre-societe.fr`, sans `https://`).

Pour changer de serveur : Déconnexion, puis une autre adresse sur l'écran de connexion.

## Comment c'est fait

- `apps/web/capacitor.config.ts` : nom, identifiant (`fr.arge.terrain`), pages servies en `http://localhost`
  (le téléphone le considère comme sûr : appareil photo et position marchent) et appels en http autorisés pour le
  PC de test.
- `apps/web/src/native.ts` : adresse du serveur et ouverture des fichiers. Dans le navigateur, rien ne change.
- Le serveur accepte l'appli grâce à `http://localhost` dans `WEB_ORIGIN` (`.env`, lanceurs,
  `docker-compose.prod.yml`). Les connexions passent par un jeton, pas par un cookie : l'autoriser ne donne accès
  à rien sans mot de passe.
- Sécurité : `http` n'est accepté que pour les adresses du réseau local (192.168…, 10…, 172.16–31…) ; toute autre
  adresse passe en `https`, pour que le mot de passe ne circule jamais en clair sur Internet (`normalizeServer`).
  Pour la version publiée, retirer `cleartext: true` et limiter le http aux adresses de test.
- Permissions Android (`apps/web/android/app/src/main/AndroidManifest.xml`) : appareil photo, position, micro.
- Icône (logo A.R.G.E. sur son bleu #002B56) : `apps/web/assets` → `npx capacitor-assets generate --android` (dans `apps/web`).

Vérifié sur l'émulateur Android 16 avec les données A.R.G.E. (`db:seed-arge`) : logo à la connexion, journée de
`tech.dijon@arge.test` (3 interventions, logo de la société), fiche d'intervention technique A.R.G.E.

## À faire

- **Notifications** : la WebView d'Android ne reçoit pas les Web Push. Il faudra Firebase Cloud Messaging
  (`@capacitor/push-notifications`) et un envoi côté serveur.
- **Dictée** : la reconnaissance vocale du navigateur n'existe pas dans la WebView ; le bouton n'apparaît pas.
  Le micro du clavier Android (Gboard) fait la même chose. Sinon : `@capacitor-community/speech-recognition`.
- **Autres clients ou éditions** : ajouter un client dans `src/client.ts` et un fichier `.env.<client>` ; l'identifiant
  et le nom Android sont dans `capacitor.config.ts`, `android/app/build.gradle` et `res/values/strings.xml`.
- **Publication sur le Play Store** : APK signée (`gradlew bundleRelease` avec une clé), compte développeur Google.
