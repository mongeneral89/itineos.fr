# Où en est le développement (note de reprise)

Dernière mise à jour : 12 octobre 2026. Pour reprendre avec Claude, il suffit de dire : « reprends le développement
d'Itinéos, lis REPRISE.md ».

## Fait

Socle, mots de passe, photos sur les fiches, appli terrain hors connexion, éditeur de modèles de fiches, tests
d'intégration, hébergement préparé ([DEPLOIEMENT.md](DEPLOIEMENT.md)), limitation des tentatives de connexion,
**devis et contrats d'entretien**, **facturation et export comptable**, **stock et bons de sortie**,
**parc véhicules** et **habilitations**, **carte Échéances** et **e-mail du matin**,
**traduction complète** en 16 langues (bureau, appli terrain, espace client ; voir README, « Langues de l'interface »),
**planning global** : vues jour, semaine et mois, toutes agences, charge par technicien,
**documents clients dans la langue du client** (16 langues, polices Noto pour toutes les écritures),
**messagerie interne** (à deux et en groupe, photos et fichiers joints) et **annuaire** (équipe, contacts utiles, agences),
**notices et procédures** (publiées par le bureau, proposées par les techniciens puis validées),
**cartes SIM** (inventaire et suivi de l'activation faite sur le site du prestataire),
**statistiques à la carte** (indicateurs × critères, tableau croisé, export CSV),
**suggestion d'attribution** (distance, charge, stock du véhicule, habilitations ; à activer par société),
reprises de l'« App technicien admin » : **« Y aller »** (Waze, Google Maps, Plans), **scanner** de codes,
**recherche client avancée**, **matériel difficile à repérer**, document **« Consignes de télésurveillance »**,
**notifications** (téléphone et/ou e-mail), **planning de l'équipe** pour les techniciens (choisi par le bureau),
**rester connecté** un an et « déconnecter tous mes appareils », **copie au bureau** et réponse du client au technicien,
**espace client (portail)** : invitations, interventions et fiches signées, devis acceptés ou refusés en ligne,
factures, contrats, demandes d'intervention (voir README, « Espace client »),
**géolocalisation des véhicules** : position envoyée par le téléphone du conducteur (partage activé par lui),
carte du parc et trajet du jour, historique effacé après 30 jours (voir README),
**six éditions, une par métier** (12 octobre 2026) : Itinéos, Vigie (sécurité privée), Constat (commissaires de
justice), Expertise, Clés (états des lieux), Services. Même code, une installation par édition (variable `EDITION`) :
nom, couleurs, icône, vocabulaire, menus et 4 modèles de fiches par métier (voir README, « Six éditions »).
Tous testés dans le navigateur.

Vidéo de présentation (19 min, avec le portail client, voix Piper) : dossier `app tech\video-itineo` (voir son LISEZ-MOI.txt pour la refaire).

Tests : 69 unitaires (`npm test`) et 93 d'intégration (`npm run test:integration`), tous au vert.

Les traductions autres que l'anglais ont été écrites par Claude : à faire relire par une personne de langue
maternelle avant de vendre dans le pays concerné.

## Appli Android (15 octobre 2026)

APK d'essai de l'appli terrain (Capacitor) : mêmes écrans, serveur choisi à la connexion (PC du Wi-Fi pour les
essais, puis la version en ligne). `lanceurs\Construire l'APK Android.cmd` → `apk\ARGE-terrain.apk` (version A.R.G.E. : nom, logo).
Mises à jour automatiques (16 octobre 2026) : chaque construction est publiée sur https://arge.events-gs.fr/appli/
(FTP OVH, identifiants de LanShare) et l'appli propose la mise à jour. APK « release » signées avec la clé A.R.G.E. : **sauvegarder le dossier `%USERPROFILE%\.arge`**.
Voir [ANDROID.md](ANDROID.md). Restent : notifications (Firebase), dictée, une appli par édition.

## À noter

- La société de démo n'a ni taux horaire ni forfait de déplacement : à renseigner dans Organisation → Réglages de
  facturation, sinon une facture faite depuis une fiche a des lignes à 0 € (et ne peut pas être émise).
- À vérifier : en tapant très vite dans le champ « pièce » de l'appli terrain, les lettres se sont mélangées pendant
  le tournage automatique de la vidéo. Pas encore reproduit à la main.

## En attente de l'utilisateur

- Points de [COMPARAISON-APP-TECHNICIEN.md](COMPARAISON-APP-TECHNICIEN.md) non retenus pour l'instant : 3, 7, 8, 10, 11,
  12, 15, 17.
- À essayer sur un vrai téléphone : scanner (appareil photo) et notifications (il faut l'adresse https en ligne).
- Cartes SIM : décider plus tard comment se fera l'activation (liaison avec le prestataire ?).

## Prochaine étape : mise en ligne

Suivre [DEPLOIEMENT.md](DEPLOIEMENT.md) : serveur, nom de domaine, HTTPS, e-mails réels, sauvegardes.
Puis essai sur le terrain avec de vraies tablettes.

## Éditions par métier : suite possible

Fait le 12 octobre 2026 : données d'exemple par édition et fonctions des métiers (points de passage et SOS pour
Vigie, photos probantes pour Constat et Expertise, délais pour Expertise, comparaison entrée / sortie pour Clés,
registre des traitements pour Services). Voir README, « Six éditions ».
Logo de chaque société (Organisation) : menu, appli terrain, espace client, en-tête des PDF. Vidéo de présentation
refaite avec les versions par métier, « Vos documents » et le sur-mesure (28 chapitres, 25 min 32).

- Vocabulaire des métiers dans les 14 autres langues (laissé de côté à la demande de l'utilisateur).
- À essayer sur un vrai téléphone : scan des points de passage, alerte SOS (position, notification).
- Possibles ensuite : pointage NFC, alerte « homme mort » (absence de mouvement), signature électronique qualifiée
  pour les procès-verbaux, photos de comparaison entrée / sortie côte à côte.
- Nom du logiciel : « Itinéos » est une marque déposée par d'autres (Bouygues Telecom, classes 9 et 42).
  Changement de nom envisagé (Kadrio), à faire une fois la marque déposée : il suffit de changer `BRAND`
  (packages/shared) et les textes qui citent le nom.

## Ensuite (à décider)

Photos jointes aux demandes de l'espace client, paiement des factures en ligne, connexion unique (SSO) pour les
grands comptes.
