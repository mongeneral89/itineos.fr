# Mettre Itinéos en ligne

Ce guide installe Itinéos sur un serveur, avec :

- **HTTPS automatique** : certificat gratuit (Let's Encrypt), renouvelé tout seul. Le HTTPS est aussi ce qui permet
  à l'appli terrain de **démarrer sans réseau** sur les tablettes.
- **Sauvegardes quotidiennes** de la base, des PDF et des photos, gardées 14 jours.
- Mises à jour en une commande.

Tout tient dans [`docker-compose.prod.yml`](docker-compose.prod.yml). Cette installation a été testée de bout en bout
(HTTPS, connexion, sauvegarde puis restauration).

---

## 1. Ce qu'il vous faut

| Quoi | Conseil |
|---|---|
| Un serveur (VPS) **en Europe** | Linux Ubuntu 24.04, 2 processeurs, 4 Go de mémoire, 40 Go de disque. Chez OVHcloud, Scaleway ou Hetzner par exemple. |
| Un nom de domaine | Par exemple `itineo.votre-societe.fr`, chez votre registraire habituel. |
| Un service d'envoi d'e-mails (SMTP) | Pour les fiches PDF et les mots de passe oubliés. Par exemple Brevo ou Mailjet (hébergés en Europe), ou le SMTP de votre messagerie professionnelle. |

> Les données de vos clients (adresses, signatures, photos) seront sur ce serveur : choisissez un hébergeur en Europe
> pour rester simplement dans le cadre du RGPD.

## 2. Faire pointer le domaine vers le serveur

Chez votre registraire, ajoutez un enregistrement **A** : `itineo.votre-societe.fr` → adresse IP du serveur.
Comptez de quelques minutes à quelques heures avant qu'il soit pris en compte.

## 3. Préparer le serveur

Connectez-vous au serveur (`ssh root@ADRESSE-IP`), puis :

```bash
# Docker
curl -fsSL https://get.docker.com | sh

# Pare-feu : seulement SSH, HTTP et HTTPS
ufw allow OpenSSH && ufw allow 80 && ufw allow 443 && ufw --force enable
```

## 4. Installer Itinéos

Copiez le dossier du projet sur le serveur (par Git, ou depuis votre PC avec `scp -r itineo root@ADRESSE-IP:/opt/`), puis :

```bash
cd /opt/itineo
cp .env.production.example .env.production
nano .env.production
```

Remplissez :

- `EDITION` : le logiciel installé. `TECH` (Itinéos), `SECURITY` (Itinéos Vigie), `BAILIFF` (Itinéos Constat),
  `EXPERTISE` (Itinéos Expertise), `RENTAL` (Itinéos Clés) ou `SERVICES` (Itinéos Services). **Une installation par
  édition** : chacune a son serveur (ou sa machine virtuelle), son nom de domaine (`vigie.votre-societe.fr`…), sa base
  et ses sauvegardes. Ne changez pas l'édition d'une installation déjà utilisée : ses sociétés prendraient le
  vocabulaire et les modèles de fiches de l'autre métier.
- `DOMAIN` : votre adresse, sans `https://`
- `POSTGRES_PASSWORD` et `JWT_SECRET` : deux longues chaînes aléatoires **différentes**. Pour en générer une : `openssl rand -base64 32`
- `SMTP_URL` et `MAIL_FROM` : fournis par votre service d'e-mails (mettez le nom de l'édition dans `MAIL_FROM`)
- `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY` (notifications sur les téléphones) : laissez vide, Itinéos les crée tout seul.
  Les notifications demandent une adresse en **https** (c'est le cas avec ce déploiement). Sur iPhone, Itinéos doit être
  ajouté à l'écran d'accueil.

Puis démarrez :

```bash
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
```

La première fois, comptez quelques minutes. Vérifiez que tout tourne :

```bash
docker compose -f docker-compose.prod.yml --env-file .env.production ps
```

Les 4 services doivent être « Up » : `db`, `api`, `web`, `backup`.

## 5. Créer le premier compte administrateur

```bash
docker compose -f docker-compose.prod.yml --env-file .env.production exec api \
  npm run admin:create -- --email vous@votre-societe.fr --first Prénom --last Nom --group "Nom de votre groupe"
```

Un **mot de passe provisoire** s'affiche une seule fois. Ouvrez `https://votre-domaine`, connectez-vous, puis :

1. **Mon compte** → changez le mot de passe.
2. **Organisation** → créez vos sociétés (une par pays) et vos agences, puis les comptes des collaborateurs.
3. **Modèles de fiches** → personnalisez vos fiches si besoin.

> Les données d'exemple (`npm run db:seed`) ne servent qu'à la démonstration : ne les lancez pas en production.

## 6. Les sauvegardes

Chaque jour, dans le dossier `/opt/itineo/backups` du serveur :

- `itineo-db-AAAA-MM-JJ_HHMM.dump` : la base de données
- `itineo-fichiers-AAAA-MM-JJ_HHMM.tar.gz` : les PDF archivés et les photos

**Important :** une sauvegarde qui reste sur le même serveur ne protège pas d'une panne de ce serveur. Copiez
régulièrement ce dossier ailleurs : un autre hébergeur, un stockage en ligne (par exemple avec l'outil `rclone`), ou
votre PC.

Sauvegarde immédiate, par exemple avant une mise à jour :

```bash
docker compose -f docker-compose.prod.yml --env-file .env.production exec backup sh /scripts/backup.sh now
```

### Restaurer une sauvegarde

```bash
cd /opt/itineo
docker compose -f docker-compose.prod.yml --env-file .env.production stop api
# Base de données (remplace le contenu actuel)
docker compose -f docker-compose.prod.yml --env-file .env.production exec backup \
  pg_restore --clean --if-exists --no-owner -d itineo /backups/itineo-db-AAAA-MM-JJ_HHMM.dump
# PDF et photos
docker compose -f docker-compose.prod.yml --env-file .env.production run --rm --entrypoint sh \
  -v "$PWD/backups:/restore:ro" -v itineo_storage:/data/storage api \
  -c "cd /data && tar -xzf /restore/itineo-fichiers-AAAA-MM-JJ_HHMM.tar.gz"
docker compose -f docker-compose.prod.yml --env-file .env.production start api
```

> Le volume s'appelle `<nom du dossier>_storage`, donc `itineo_storage` si le projet est dans `/opt/itineo`.
> `docker volume ls` permet de le vérifier.

## 7. Mettre à jour Itinéos

```bash
cd /opt/itineo
docker compose -f docker-compose.prod.yml --env-file .env.production exec backup sh /scripts/backup.sh now
# … récupérez la nouvelle version du code (git pull, ou copie du dossier) …
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
```

Les changements de base de données s'appliquent tout seuls au démarrage. Les tablettes chargent la nouvelle version de
l'appli à leur prochaine ouverture avec du réseau.

## 8. En cas de souci

```bash
# Journaux du serveur, de la page web (HTTPS), des sauvegardes
docker compose -f docker-compose.prod.yml --env-file .env.production logs api --tail 100
docker compose -f docker-compose.prod.yml --env-file .env.production logs web --tail 100
docker compose -f docker-compose.prod.yml --env-file .env.production logs backup --tail 20
```

- **Le site ne s'ouvre pas en HTTPS :** vérifiez que le domaine pointe bien vers le serveur (étape 2) et que les ports
  80 et 443 sont ouverts. Le certificat ne peut être obtenu qu'à ces deux conditions.
- **Les e-mails ne partent pas :** vérifiez `SMTP_URL`, puis relancez avec `up -d`. Sans `SMTP_URL`, les e-mails ne
  sont pas envoyés, seulement notés dans le journal du serveur.

## Carte des véhicules

La carte utilise par défaut les serveurs d'OpenStreetMap, qui demandent de ne pas s'en servir pour un usage
intensif. En production, prenez un fournisseur de fonds de carte (par exemple la Géoplateforme de l'IGN, ou un
service comme MapTiler ou Stadia Maps) et indiquez son adresse au moment de construire l'appli :
`VITE_MAP_TILES_URL=https://…/{z}/{x}/{y}.png`. La géolocalisation des téléphones ne fonctionne qu'en HTTPS.

## Avant d'ouvrir à de vrais clients

- [ ] Domaine en HTTPS, cadenas affiché dans le navigateur
- [ ] Mot de passe administrateur changé
- [ ] Un e-mail de test reçu (fiche envoyée, mot de passe oublié)
- [ ] Une sauvegarde copiée **hors du serveur**, et une restauration essayée au moins une fois
- [ ] `.env.production` conservé en lieu sûr : sans lui, impossible de relancer l'installation
- [ ] Techniciens informés par écrit de la géolocalisation (finalité, conservation 30 jours, droit d'arrêter)
